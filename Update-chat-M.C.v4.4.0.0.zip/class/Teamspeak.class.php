<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.

Aufruf: index.php?Teamspeak
*/

class Teamspeak extends DbConectionMaker
{
    private string $teamspeak_server = '';
    private string $teamspeak_password = '';
    
    // Status-Einstellungen
    private int $display_mode = 0;
    private string $query_host = '';
    private int $query_port = 10011;
    private string $query_pass = '';

    public function __construct()
    {
        parent::__construct();

        require_once './class/ZugriffsGuard.class.php';
        new ZugriffsGuard();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        $this->lang = new LangJson();

        $this->config = $this->dbObj->sqlGet("
            SELECT etchat_config_lang, etchat_config_style,
                   etchat_ts3_enabled, etchat_ts3_host, etchat_ts3_port,
                   etchat_ts3_join_password, etchat_ts3_display_mode,
                   etchat_ts3_query_password
            FROM {$this->_prefix}etchat_config
            LIMIT 1
        ") ?: [];

        $this->dbObj->close();

        $host = trim((string)($this->config[0]['etchat_ts3_host'] ?? ''));
        $port = (int)($this->config[0]['etchat_ts3_port'] ?? 9987);
        if ($port < 1 || $port > 65535) $port = 9987;

        if ($host !== '') {
            $this->teamspeak_server = "ts3server://{$host}?port={$port}";
            $this->teamspeak_password = trim((string)($this->config[0]['etchat_ts3_join_password'] ?? ''));
            
            $this->query_host = $host;
            $this->display_mode = (int)($this->config[0]['etchat_ts3_display_mode'] ?? 0);
            $this->query_pass = trim((string)($this->config[0]['etchat_ts3_query_password'] ?? ''));
        }

        // ===== AJAX-MODUS =====
        // Aufruf: index.php?Teamspeak&ajax=1
        // Wird vom JS genutzt, um den Status ohne Seiten-Reload zu holen
        if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
            $this->outputAjaxStatus();
            exit;
        }

        $this->render();
    }

    private function getText(string $key, string $default = ''): string
    {
        return $this->lang->get($key, $default);
    }

    private function isConfigured(): bool
    {
        return $this->teamspeak_server !== '';
    }
	
    private function outputAjaxStatus(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');

        if (!$this->isConfigured()) {
            echo json_encode(['online' => false, 'error' => 'not_configured']);
            return;
        }

        $status = $this->getTs3Status();
        echo json_encode($status ?? ['online' => false, 'error' => 'unavailable']);
    }

    public function render(): void
    {
        $style = $this->config[0]['etchat_config_style'] ?? 'etchat_dino_styles';
        echo "<link rel='stylesheet' type='text/css' href='styles/{$style}/style.css'>";
        echo "<body id='body'>";
        $this->renderContent();
        echo "</body>";
    }

    private function renderContent(): void
    {
        echo "<div id='inhalt'>";
        echo "<h2 class='headline'>" . $this->getText('teamspeak_title', 'Teamspeak 3') . "</h2>";

        if (!$this->isConfigured()) {
            echo "<p style='color:#ff8080;'>" . $this->getText('teamspeak_not_configured', 'Nicht eingetragen.') . "</p></div>";
            return;
        }

        echo "<div style='display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; align-items: flex-start;'>";
        
        // LINKS: Formular
        echo "<div style='flex: 1 1 300px; max-width: 400px;'>";
        $this->renderForm();
        echo "</div>";

        // RECHTS: Status
        if ($this->display_mode > 0) {
            echo "<div style='flex: 1 1 300px; max-width: 400px;'>";
            $this->renderStatus();
            echo "</div>";
        }
        echo "</div>";

        // UNTEN: Info
        echo "<p><strong>" . $this->getText('teamspeak_info_title', 'Kurzanleitung') . "</strong></p>";
        $defaultInfoText = '<ol style="text-align: left;">'
            . '<li style="margin-bottom: 10px;">Teamspeak-3-Client noch nicht installiert? Oben auf das Banner klicken, herunterladen und installieren.</li>'
            . '<li style="margin-bottom: 10px;">Nickname eingeben und auf Verbinden drücken.</li>'
            . '<li style="margin-bottom: 10px;">Du wirst nun automatisch mit unserem TS3-Server verbunden.</li>'
            . '</ol>';
            
        echo $this->getText('teamspeak_info_text', $defaultInfoText);

        echo "</div>";
    }

    private function renderForm(): void
    {
		
		$chatUsername = $_SESSION['etchat_' . $this->_prefix . 'username'] ?? '';
		$safeUsername = htmlspecialchars($chatUsername, ENT_QUOTES, 'UTF-8');
		
        echo "<div style='border: 1px solid var(--color-border); border-radius: 10px; padding: 15px; background: rgba(0,0,0,0.3); text-align: left;'><center><p><a href='https://www.teamspeak.com/de/downloads/#ts3client' target='_blank'><img class='img_button' src='img/ts3_download_banner.png'></a></p>";
        
        echo "<form id='tsform' onsubmit='return connectTS();'>";
		echo "<input id='username' name='NICKNAME' type='text' value='" . $safeUsername . "' placeholder='" . $this->getText('teamspeak_nickname_placeholder', 'Nickname') . "' maxlength='30' required><br><br>";
        
        echo "<input type='submit' id='submit_button' value='" . $this->getText('teamspeak_connect', 'Verbinden') . "'>";
        echo "</form></center></div>";

        echo "<script>
            function connectTS() {
                var nick = document.getElementById('username').value.trim();
                if (!nick) { alert('Bitte Nicknamen eingeben.'); return false; }
                var server = " . json_encode($this->teamspeak_server) . ";
                var password = " . json_encode($this->teamspeak_password) . ";
                var sep = server.indexOf('?') === -1 ? '?' : '&';
                var url = server + sep + 'nickname=' + encodeURIComponent(nick);
                if (password) url += '&password=' + encodeURIComponent(password);
                window.location.href = url;
                return false;
            }
        </script>";
    }

    private function renderStatus(): void
    {
        echo "<div id='ts3_status_box'
                data-endpoint='index.php?Teamspeak&ajax=1'
                style='border:1px solid var(--color-border);border-radius:10px;
                       padding:15px;background:rgba(0,0,0,0.3);text-align:left;'>";
        echo "<h3 style='margin-top:0;'>"
           . $this->getText('teamspeak_status_title', 'Serverstatus') . "</h3>";
        echo "<div class='ts3_status_body'>";

        // Erster Render serverseitig – sofort was da
        $this->renderStatusBody($this->getTs3Status());

        echo "</div></div>";

        $this->renderStatusScript();
    }

    private function renderStatusBody(?array $status): void
    {
        if ($status === null) {
            echo "<p style='opacity:0.7;'>" . $this->getText('teamspeak_status_unavailable', 'Status derzeit nicht verfügbar.') . "</p>";
            return;
        }
        if (!$status['online']) {
            echo "<p style='color:#ff6666;font-weight:bold;'>" . $this->getText('teamspeak_status_offline', '🔴 Server offline') . "</p>";
            return;
        }

        echo "<p style='color:#00ff00;font-weight:bold;margin-bottom:15px;'>"
           . $this->getText('teamspeak_status_online', '🟢 Server online') . "</p>";

        $userText = $this->getText('teamspeak_status_users', 'User online: {clients} / {max}');
        $userText = str_replace(['{clients}', '{max}'], [$status['clients'], $status['max_clients']], $userText);
        echo "<p style='margin:0 0 15px 0;'>" . $userText . "</p>";

        if ($this->display_mode === 2 && !empty($status['client_list'])) {
            echo "<hr style='border-color:var(--color-border);margin-bottom:15px;'>";
            foreach ($status['client_list'] as $room => $users) {
                echo "<div style='margin-bottom:12px;'>";
                echo "<strong style='font-size:0.95em;color:var(--color-button-zeilen);'>" . htmlspecialchars($room) . "</strong>";
                echo "<ul style='padding-left:15px;list-style:none;margin:5px 0 0 0;'>";
                foreach ($users as $c) {
                    echo "<li style='margin-bottom:3px;'>👤 " . htmlspecialchars($c) . "</li>";
                }
                echo "</ul></div>";
            }
        }
    }

    private function renderStatusScript(): void
    {
        $onlineText  = json_encode($this->getText('teamspeak_status_online', '🟢 Server online'));
        $offlineText = json_encode($this->getText('teamspeak_status_offline', '🔴 Server offline'));
        $unavailText = json_encode($this->getText('teamspeak_status_unavailable', 'Status derzeit nicht verfügbar.'));
        $usersText   = json_encode($this->getText('teamspeak_status_users', 'User online: {clients} / {max}'));
        $modeJs      = (int)$this->display_mode;

        echo <<<JS
<script>
(function() {
    var box = document.getElementById('ts3_status_box');
    if (!box) return;
    var endpoint  = box.getAttribute('data-endpoint');
    var body      = box.querySelector('.ts3_status_body');
    var mode      = {$modeJs};
    var INTERVAL  = 120000;   // 150 Sekunden = 2,5 Minuten
    var timer     = null;
    var abortCtrl = null;

    function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

    function render(data) {
        if (!data || data.error === 'not_configured') {
            body.innerHTML = '<p style="opacity:0.7;">' + esc({$unavailText}) + '</p>';
            return;
        }
        if (!data.online) {
            body.innerHTML = '<p style="color:#ff6666;font-weight:bold;">' + esc({$offlineText}) + '</p>';
            return;
        }
        var html = '<p style="color:#00ff00;font-weight:bold;margin-bottom:15px;">' + esc({$onlineText}) + '</p>';
        var userText = {$usersText};
        userText = userText.replace('{clients}', data.clients).replace('{max}', data.max_clients);
        html += '<p style="margin:0 0 15px 0;">' + esc(userText) + '</p>';
        if (mode === 2 && data.client_list && Object.keys(data.client_list).length) {
            html += '<hr style="border-color:var(--color-border);margin-bottom:15px;">';
            for (var room in data.client_list) {
                if (!data.client_list.hasOwnProperty(room)) continue;
                html += '<div style="margin-bottom:12px;">';
                html += '<strong style="font-size:0.95em;color:var(--color-button-zeilen);">' + esc(room) + '</strong>';
                html += '<ul style="padding-left:15px;list-style:none;margin:5px 0 0 0;">';
                data.client_list[room].forEach(function(u){
                    html += '<li style="margin-bottom:3px;">👤 ' + esc(u) + '</li>';
                });
                html += '</ul></div>';
            }
        }
        body.innerHTML = html;
    }

    function poll() {
        if (abortCtrl) abortCtrl.abort();
        abortCtrl = new AbortController();
        fetch(endpoint, {cache:'no-store', signal: abortCtrl.signal})
            .then(function(r){ return r.json(); })
            .then(render)
            .catch(function(){});
    }

    function startTimer() {
        if (timer !== null) return;
        timer = setInterval(poll, INTERVAL);
    }
    function stopTimer() {
        if (timer === null) return;
        clearInterval(timer);
        timer = null;
    }

    // Tab wechselt in den Hintergrund → Timer stoppen
    // Tab kommt zurück → sofort 1× poll, dann wieder alle 150 s
    document.addEventListener('visibilitychange', function(){
        if (document.hidden) {
            stopTimer();
        } else {
            poll();
            startTimer();
        }
    });

    // Wenn Tab beim Laden schon sichtbar ist: Timer starten
    // (Erst-Render ist bereits im HTML, also kein sofortiger poll nötig)
    if (!document.hidden) {
        startTimer();
    }
})();
</script>
JS;
    }

    private function getTs3Status(): ?array
    {
        $cacheFile = __DIR__ . '/../cache/ts3_status.json';
        if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 30) {
            $cached = json_decode((string)file_get_contents($cacheFile), true);
            if (is_array($cached)) return $cached;
        }

        $fp = @fsockopen($this->query_host, $this->query_port, $errno, $errstr, 2);
        if (!$fp) {
            $this->writeCache($cacheFile, ['online' => false, 'clients' => 0, 'max_clients' => 0, 'client_list' => []]);
            return ['online' => false, 'clients' => 0, 'max_clients' => 0, 'client_list' => []];
        }

        stream_set_timeout($fp, 2);
        fgets($fp); // Willkommensnachricht

        $isLoggedIn = false;
        if ($this->query_pass !== '') {
            $safePass = str_replace(' ', '\\s', $this->query_pass);
            fwrite($fp, "login serveradmin " . $safePass . "\n");
            while (($line = fgets($fp)) !== false) {
                if (strpos($line, 'error id=0') !== false) { $isLoggedIn = true; break; }
                if (strpos($line, 'error id=') !== false) { break; }
            }
        }

        if ($isLoggedIn) {
            fwrite($fp, "use 1\n");
            while (($line = fgets($fp)) !== false) {
                if (strpos($line, 'error id=0') !== false) break;
                if (strpos($line, 'error id=') !== false) break;
            }
        }

        $status = ['online' => true, 'clients' => 0, 'max_clients' => 0, 'client_list' => []];
        $channels = [];
        $channelOrderList = []; // Speichert die IDs in der Reihenfolge, wie der TS3 sie liefert

        if ($isLoggedIn) {
            // Channel-Liste holen
            fwrite($fp, "channellist\n");
            while (($line = fgets($fp)) !== false) {
                if (strpos($line, 'error id=0') !== false) break;
                $parts = explode('|', $line);
                foreach ($parts as $part) {
                    if (preg_match('/cid=(\d+)/', $part, $mCid) && preg_match('/channel_name=([^ ]+)/', $part, $mName)) {
                        $cName = str_replace('\s', ' ', $mName[1]);
                        $cid = (int)$mCid[1];
                        $channels[$cid] = $cName;
                        $channelOrderList[] = $cid; // Merken, in welcher Reihenfolge der TS3 sie schickt
                    }
                }
            }
        }

        // Serverinfo abfragen
        fwrite($fp, "serverinfo\n");
        while (($line = fgets($fp)) !== false) {
            if (strpos($line, 'error id=0') !== false) break;
            
            if (preg_match('/virtualserver_clientsonline=(\d+)/', $line, $m)) {
                $status['clients'] = max(0, (int)$m[1] - ($isLoggedIn ? 1 : 0));
            }
            if (preg_match('/virtualserver_maxclients=(\d+)/', $line, $m)) {
                $status['max_clients'] = (int)$m[1];
            }
        }

        // Userliste abfragen
        if ($isLoggedIn && $this->display_mode === 2) {
            $tempList = [];
            
            fwrite($fp, "clientlist -uid\n");
            while (($line = fgets($fp)) !== false) {
                if (strpos($line, 'error id=0') !== false) break;
                
                $parts = explode('|', $line);
                foreach ($parts as $part) {
                    if (preg_match('/client_nickname=([^ ]+)/', $part, $m)) {
                        $nick = str_replace('\s', ' ', $m[1]);
                        
                        $cid = 0;
                        if (preg_match('/ cid=(\d+)/', $part, $mCid)) {
                            $cid = (int)$mCid[1];
                        }

                        if ($nick !== 'serveradmin' && $nick !== 'serverquery' && strpos($nick, 'query') === false) {
                            $tempList[$cid][] = $nick; // User nach Channel-ID gruppieren
                        }
                    }
                }
            }

            // Jetzt bauen wir die finale Liste in der exakten TS3-Reihenfolge zusammen
            foreach ($channelOrderList as $cid) {
                if (isset($tempList[$cid])) {
                    $roomName = $channels[$cid];
                    sort($tempList[$cid]); // User im Raum alphabetisch
                    $status['client_list'][$roomName] = $tempList[$cid];
                }
            }
        }

        if ($isLoggedIn) {
            fwrite($fp, "logout\n");
            fgets($fp);
        }
        fwrite($fp, "quit\n");
        fclose($fp);

        // Fallback für User-Anzahl
        $totalUsers = 0;
        foreach ($status['client_list'] as $users) {
            $totalUsers += count($users);
        }
        if ($totalUsers > $status['clients']) {
            $status['clients'] = $totalUsers;
        }
        
        if ($status['max_clients'] === 0 && $isLoggedIn) {
            $status['max_clients'] = 32;
        }

        $this->writeCache($cacheFile, $status);
        return $status;
    }

    private function writeCache(string $file, array $data): void
    {
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0777, true);
        @file_put_contents($file, json_encode($data));
    }
}