<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Info extends DbConectionMaker
{
    private ?object $lang = null;
    private array $config = [];

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();
		
		// Zugriffsschutz
		require_once './class/ZugriffsGuard.class.php';
		new ZugriffsGuard(true);

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        // ===== MODERNE SPRACHE LADEN =====
        try {
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }

        // Style aus DB laden
        $this->config = $this->dbObj->sqlGet("
            SELECT etchat_config_style
            FROM {$this->_prefix}etchat_config
            LIMIT 1
        ") ?: [];

        $this->dbObj->close();

        $style = $this->config[0]['etchat_config_style'] ?? 'default';

        $this->render($style);
    }

    private function render(string $style): void
    {
        // ===== TEXTE AUS JSON HOLEN =====
        $title              = $this->getText('info_title', 'Info');
        $mainText           = $this->getText('info_main_text', '');
        $contributorsTitle  = $this->getText('info_contributors_title', 'Mitwirkende:');
        $copyrightNotice    = $this->getText('info_copyright_notice', 'Copyright Hinweis verwendeter Fremdcode:');
        $emailLink          = $this->getText('info_email_link', 'Anfragen per E-Mail');
        $emailAddress       = $this->getText('info_email_address', 'et-chat-mod@abwesend.de');
        $contactForm        = $this->getText('info_contact_form', 'Kontakt per Formular');
        $forumLink          = $this->getText('info_forum_link', 'Forum &amp; Download');
        $forumUrl           = $this->getText('info_forum_url', 'https://et-chat-mod.42web.io/forum/');

        // ===== CONTRIBUTORS =====
        $contributors = [];
        for ($i = 1; $i <= 6; $i++) {
            $contributor = $this->getText("info_contributor_{$i}", '');
            if (!empty($contributor)) {
                $contributors[] = $contributor;
            }
        }

        // ===== LIBRARIES =====
        $libraries = [];
        for ($i = 1; $i <= 4; $i++) {
            $library = $this->getText("info_library_{$i}", '');
            if (!empty($library)) {
                $libraries[] = $library;
            }
        }

        // ===== FALLBACKS =====
        if (empty($contributors)) {
            $contributors = [
                '<strong>Powermen (Christian K.):</strong> Modulentwicklung - Programmierung - Betreuung',
                '<strong>Chrno (Herman):</strong> Modulentwicklung - Programmierung',
                '<strong>Micha (Michael Krissel):</strong> Mod-Entwicklung',
                '<strong>FizzyLemmon:</strong> Modulentwicklung - Programmierung',
                '<strong>Svensken:</strong> Programmierung',
                '<strong>Sascha:</strong> Codebereinigung'
            ];
        }

        if (empty($libraries)) {
            $libraries = [
                '<a href="https://github.com/PHPMailer/PHPMailer?tab=readme-ov-file" target="_blank">Copyright &#169; 2025 PHPMailer</a>',
                '<a href="https://codemirror.net/" target="_blank">Copyright &#169; 2025 CodeMirror</a>',
                '<a href="https://www.tiny.cloud/get-tiny/" target="_blank">Copyright &#169; 2024 TinyMCE</a>',
                '<a href="https://bgrins.github.io/spectrum/" target="_blank">Copyright &#169; Spectrum Colorpicker</a>'
            ];
        }
        ?>

		<!DOCTYPE html>
		<html lang="de">
		<head>
			<meta charset="UTF-8">
			<title><?= htmlspecialchars($title) ?></title>
		<?= SeoHelper::head(
			'info',
			SeoHelper::makeDescription($mainText, 160),
			'index, follow'
		) ?>
    <link href="styles/<?= htmlspecialchars($style) ?>/style.css" rel="stylesheet" type="text/css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
        <body id="body" style="margin-left: 20px; margin-right: 20px;">

        <br>
        <?= nl2br($mainText) ?>
        <br><br>

        <strong><?= htmlspecialchars($contributorsTitle) ?></strong><br>
        <ul>
            <?php foreach ($contributors as $contributor): ?>
                <li><?= $contributor ?></li>
            <?php endforeach; ?>
        </ul>

        <br><br>
        <strong><?= htmlspecialchars($copyrightNotice) ?></strong><br><br>

        <?php foreach ($libraries as $lib): ?>
            <?= $lib ?><br>
        <?php endforeach; ?>

        <br>

        <a href="mailto:<?= htmlspecialchars($emailAddress) ?>"><?= htmlspecialchars($emailLink) ?></a><br><br>

        <a href="kontakt.php"
           id="info_kontakt_link"
           data-popup-title="<?= htmlspecialchars($contactForm) ?>">
           <?= htmlspecialchars($contactForm) ?>
        </a>

        <br><br>

        <a href="<?= htmlspecialchars($forumUrl) ?>" target="_blank"><?= htmlspecialchars($forumLink) ?></a><br><br>

        <script>
        (function () {
            var link = document.getElementById('info_kontakt_link');
            if (!link) return;

            link.addEventListener('click', function (e) {
                e.preventDefault();
                var title = link.dataset.popupTitle || 'Kontakt';

                // ============================================
                // 1. INDEX-KONTEXT: Parent hat #menu-popup + openPane
                //    → Suche nach passendem Pane (URL enthält "kontakt")
                // ============================================
                try {
                    var p = window.parent;
                    if (p && p !== window && p.document) {
                        var panes = p.document.querySelectorAll('.menu-pane');
                        var foundPaneId = null;

                        for (var i = 0; i < panes.length; i++) {
                            var pane = panes[i];
                            var src = (pane.dataset.src || '').toLowerCase();
                            if (src.indexOf('kontakt') !== -1) {
                                foundPaneId = pane.id;
                                break;
                            }
                        }

                        if (foundPaneId && typeof p.openPane === 'function') {
                            p.openPane(foundPaneId, title);
                            return;
                        }
                    }
                } catch (err) { /* Cross-Origin ignorieren */ }

				// ============================================
				// 2. CHAT-KONTEXT: Parent hat ChatDialog
				// ============================================
				try {
					var p = window.parent;
					if (p && p !== window && p.ChatDialog && typeof p.ChatDialog.open === 'function') {
						// 🔥 NEU: Erst den aktuellen Info-Dialog schließen
						if (typeof p.ChatDialog.close === 'function') {
							p.ChatDialog.close();
						}
						// Dann den Kontakt-Dialog öffnen
						p.ChatDialog.open({
							title: title,
							showHeader: true,
							className: 'wide',
							html: '<iframe src="kontakt.php" style="width:100%; height:60vh; border:none;"></iframe>'
						});
						return;
					}
				} catch (err) { /* Cross-Origin ignorieren */ }

                // ============================================
                // 3. FALLBACK: eigenständige Seite → eigenes Fenster
                // ============================================
                window.open('kontakt.php', 'Kontakt', 'width=800,height=600,scrollbars=yes,resizable=yes');
            });
        })();
        </script>

        </body>
        </html>
        <?php
    }
}