<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class ConnectDBMysqli extends EtChatConfig
{
    protected ?mysqli $_connid = null;
    public int $lastId = 0;

    public function __construct()
    {
        parent::__construct();

        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        try {
            $this->_connid = new mysqli(
                $this->_sqlhost,
                $this->_sqluser,
                $this->_sqlpass,
                $this->_database
            );
            $this->_connid->set_charset("utf8mb4");
        } catch (mysqli_sql_exception $e) {
            error_log("MySQLi Verbindungsfehler: " . $e->getMessage());
            echo "<pre style='color:#ff5555;background:#2a1a1a;padding:10px;font-family:monospace'>";
            echo "Datenbankverbindung fehlgeschlagen.\n\n";
            echo "Details: " . htmlspecialchars($e->getMessage()) . "\n";
            echo "Host:    " . htmlspecialchars($this->_sqlhost) . "\n";
            echo "DB:      " . htmlspecialchars($this->_database) . "\n";
            echo "User:    " . htmlspecialchars($this->_sqluser) . "\n";
            echo "</pre>";
            exit;
        }
    }

    public function escape($value): string
    {
        return $this->_connid->real_escape_string((string)$value);
    }

    public function sqlGet(string $sql, array $params = []): array|false
    {
        if ($sql === '') {
            return false;
        }

        try {
            if (!empty($params)) {
                $stmt = $this->_connid->prepare($sql);
                if (!$stmt) {
                    return false;
                }

                $types = str_repeat('s', count($params));
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $result = $stmt->get_result();

                $data = [];
                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        $data[] = $row;
                    }
                }
                $stmt->close();
            } else {
                $result = $this->_connid->query($sql);
                if (!$result) {
                    return false;
                }
                $data = [];
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row;
                }
            }

            return empty($data) ? false : $data;

        } catch (Throwable $e) {
            error_log("MySQLi sqlGet Fehler: " . $e->getMessage());
            error_log("SQL: " . $sql);
            error_log("PARAMS: " . print_r($params, true));
            // Bei Installation/Debug sichtbar machen:
            if (defined('ETCHAT_DEBUG_SQL') && ETCHAT_DEBUG_SQL) {
                echo "<div style='color:#ff5555;background:#2a1a1a;padding:6px;font-family:monospace'>"
                   . "<b>MySQLi sqlGet Fehler:</b> " . htmlspecialchars($e->getMessage())
                   . "<br><small>SQL: " . htmlspecialchars(substr($sql, 0, 400)) . "</small></div>";
            }
            return false;
        }
    }

    public function sqlSet(string $sql, array $params = []): bool|int
    {
        try {
            if (!empty($params)) {
                $stmt = $this->_connid->prepare($sql);
                if (!$stmt) {
                    return false;
                }

                $types = str_repeat('s', count($params));
                $stmt->bind_param($types, ...$params);
                $stmt->execute();

                $this->lastId = $this->_connid->insert_id;
                $affected = $stmt->affected_rows;
                $stmt->close();

                return $affected;
            }

            $this->_connid->query($sql);
            $this->lastId = $this->_connid->insert_id;
            return $this->_connid->affected_rows;

        } catch (Throwable $e) {
            error_log("MySQLi sqlSet Fehler: " . $e->getMessage());
            error_log("SQL: " . $sql);
            error_log("PARAMS: " . print_r($params, true));
            // Bei Installation/Debug sichtbar machen:
            if (defined('ETCHAT_DEBUG_SQL') && ETCHAT_DEBUG_SQL) {
                echo "<div style='color:#ff5555;background:#2a1a1a;padding:6px;font-family:monospace'>"
                   . "<b>MySQLi sqlSet Fehler:</b> " . htmlspecialchars($e->getMessage())
                   . "<br><small>SQL: " . htmlspecialchars(substr($sql, 0, 400)) . "</small></div>";
            }
            return false;
        }
    }

    public function getConnection(): ?mysqli
    {
        return $this->_connid;
    }

    public function close(): void
    {
        if ($this->_connid instanceof mysqli) {
            $this->_connid->close();
        }
        $this->_connid = null;
    }
}