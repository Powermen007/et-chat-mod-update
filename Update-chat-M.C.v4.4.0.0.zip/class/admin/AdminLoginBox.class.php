<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminLoginBox extends DbConectionMaker
{
    private string $message = '';
    private string $csrfToken = '';

    /** @var string Loginbox-TXT (externe Login-Box) */
    private string $loginBoxFile;

    /** @var string Onlineliste-TXT (externe Online-Box) */
    private string $onlineBoxFile;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $lang = new LangJson();

        // Rollen prüfen (nur admin)
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($userRole !== 'admin') {
            echo $lang->get('admin_loginbox_error_access', 'Zugriff verweigert.');
            return;
        }

        // CSRF Token
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
		
		// Vorbelegung: Radio-Name aus der Admin-Config
		$defaultBoxTitle = $_SESSION['etchat_' . $this->_prefix . 'radio_name'] ?? '';

        // Pfade zu den beiden TXT-Dateien
        $this->loginBoxFile  = __DIR__ . '/../../cache/loginbox.txt';
        $this->onlineBoxFile = __DIR__ . '/../../cache/onlineliste.txt';

        // POST verarbeiten
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['save_login_domains'])) {
                $this->handlePost($lang, 'login');
            } elseif (isset($_POST['save_online_domains'])) {
                $this->handlePost($lang, 'online');
            }
        }

        // Aktuelle Domains laden
        $currentLoginDomains  = $this->loadDomains($this->loginBoxFile);
        $currentOnlineDomains = $this->loadDomains($this->onlineBoxFile);

        // Chat-URL ermitteln
        $chatUrl = $this->getChatUrl();

        // Template anzeigen
        $this->renderTemplate($lang, $chatUrl, $currentLoginDomains, $currentOnlineDomains, $defaultBoxTitle);
    }

    private function handlePost($lang, string $which): void
    {
        // CSRF prüfen
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            $this->message = '<div class="error" style="color:red;">'
                . ($lang->get('admin_loginbox_error_csrf', 'Ungültiger CSRF Token!'))
                . '</div>';
            return;
        }

        // Passende TXT auswählen
        $targetFile = ($which === 'online') ? $this->onlineBoxFile : $this->loginBoxFile;
        $postField  = ($which === 'online') ? 'allowed_online_domains' : 'allowed_login_domains';

        $domainsRaw = $_POST[$postField] ?? '';
        $lines = explode("\n", $domainsRaw);
        $cleanList = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;

            // Entferne http://, https://, www.
            $line = preg_replace('~^https?://~i', '', $line);
            $line = preg_replace('~^www\.~i', '', $line);

            // Alles nach erstem Slash weg
            $line = explode('/', $line)[0];
            $line = strtolower(trim($line));

            if ($line !== '') {
                $cleanList[] = $line;
            }
        }

        $cleanList = array_unique($cleanList);

        // Cache-Ordner anlegen, falls nötig
        $dir = dirname($targetFile);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }

        $success = file_put_contents($targetFile, implode("\n", $cleanList), LOCK_EX);

        if ($success !== false) {
            $label = ($which === 'online') ? 'Online-Box' : 'Login-Box';
            $this->message = '<div class="success-banner">    
                                <span>✅ '
                                    . ($lang->get('admin_loginbox_saved_success', 'Gespeichert erfolgreich!'))
                                    . ' (' . $label . ')
                                </span>
                                <span class="close-btn" onclick="closeSuccessBanner()">✖</span>
                              </div>';
        } else {
            $this->message = '<div class="error" style="color:red;">❌ '
                . ($lang->get('admin_loginbox_error_save', 'Fehler beim Speichern!'))
                . '</div>';
        }
    }

    private function loadDomains(string $file): string
    {
        if (!file_exists($file)) {
            return '';
        }

        $content = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($content === false) {
            return '';
        }

        return implode("\n", $content);
    }

    private function getChatUrl(): string
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
        $url = $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
        return rtrim($url, '/\\') . '/';
    }

    private function renderTemplate($lang, string $chatUrl, string $currentLoginDomains, string $currentOnlineDomains, string $defaultBoxTitle = ''): void
    {
        $message = $this->message;
        $csrfToken = $this->csrfToken;

        // Template-Variablen
        $current_login_domains  = $currentLoginDomains;
        $current_online_domains = $currentOnlineDomains;
        $chat_url = $chatUrl;
        $default_box_title      = $defaultBoxTitle;

        include_once("styles/admin_tpl/indexLoginBox.tpl.html");
    }
}