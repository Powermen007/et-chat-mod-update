<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
Hilfe-Seite für die Teamspeak-Integration
*/

class AdminTs3Help extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        $this->lang = new LangJson();
        
        // Style aus DB laden
        $config = $this->dbObj->sqlGet("
            SELECT etchat_config_style
            FROM {$this->_prefix}etchat_config
            LIMIT 1
        ") ?: [];
        $style = $config[0]['etchat_config_style'] ?? 'etchat_dino_styles';

        $this->dbObj->close();

        // CSS einbinden
        echo "<link rel='stylesheet' type='text/css' href='styles/{$style}/style.css'>";
        echo "<body id='body' style='padding: 15px;'>";
        
        echo "<div style='text-align: left; line-height: 1.6;'>";
        
        // --- JOIN PASSWORT ---
        echo "<h3 style='color: var(--color-link);'>" . $this->lang->get('admin_ts3_help_join_title', '🔗 Join-Passwort (optional)') . "</h3>";
        
        echo "<p>" . $this->lang->get('admin_ts3_help_join_text1', 'Das Join-Passwort ist ein globales Passwort...') . "<br>";
        echo $this->lang->get('admin_ts3_help_join_text2', 'Nur nötig, wenn der TS3-Server ein Passwort für normale User (Gast) hat...') . "</p>";
        
        echo "<p><strong>" . $this->lang->get('admin_ts3_help_join_howto_title', 'So öffnest du den Server für Gäste...') . "</strong><br>";
        echo $this->lang->get('admin_ts3_help_join_howto_step1', '1. Verbinde dich als Admin...') . "<br>";
        echo $this->lang->get('admin_ts3_help_join_howto_step2', '2. Rechtsklick auf den Servernamen...') . "<br>";
        echo $this->lang->get('admin_ts3_help_join_howto_step3', '3. Dort findest du das Feld für das Server-Passwort...') . "<br>";
        echo $this->lang->get('admin_ts3_help_join_howto_step4', '4. Speichern. Fertig.') . "</p>";
        
        echo "<hr style='border-color: var(--color-border); margin: 20px 0;'>";
        
        // --- QUERY PASSWORT ---
        echo "<h3 style='color: var(--color-link);'>" . $this->lang->get('admin_ts3_help_query_title', '📊 Statusanzeige & Query-Passwort') . "</h3>";
        echo "<p>" . $this->lang->get('admin_ts3_help_query_intro', 'Damit die User-Liste auf der Webseite angezeigt wird, gibt es zwei Wege:') . "</p>";
        
        echo "<p><strong>" . $this->lang->get('admin_ts3_help_query_way1_title', 'Weg 1 (ohne Passwort):') . "</strong><br>";
        echo $this->lang->get('admin_ts3_help_query_way1_text', 'Der TS3-Admin muss in den TS3-Einstellungen der Gruppe "Guest" die Leserechte...') . "</p>";
        
        echo "<p><strong>" . $this->lang->get('admin_ts3_help_query_way2_title', 'Weg 2 (mit Passwort):') . "</strong><br>";
        echo $this->lang->get('admin_ts3_help_query_way2_text', 'Wenn der ServerQuery-Zugriff nicht für Gäste freigegeben ist...') . "</p>";
        
        echo "<p><strong>" . $this->lang->get('admin_ts3_help_query_rented_title', 'Wichtig bei gemieteten Servern:') . "</strong><br>";
        echo $this->lang->get('admin_ts3_help_query_rented_text', 'Bei vielen gemieteten Servern ist der ServerQuery-Zugriff...') . "</p>";
        
        echo "<p><strong>" . $this->lang->get('admin_ts3_help_query_fail_title', 'Was passiert, wenn es nicht geht?') . "</strong><br>";
        echo $this->lang->get('admin_ts3_help_query_fail_text', 'Der Serverstatus (Online/Offline) funktioniert trotzdem...') . "</p>";

        echo "</div>";
        echo "</body>";
    }
}