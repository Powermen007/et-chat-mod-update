<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.

Aufruf: index.php?PrivateWindow&partnerId=X&partnerName=Y
Rendert das Popup-Fenster für den Privatchat mit einem Partner.
Die eigentliche Chat-Logik steckt in js/chat-private.js.
*/

class PrivateWindow extends DbConectionMaker
{
    private LangJson $lang;
    private array $config;
    private int $partner_id = 0;
    private string $partner_name = '';
    private int $my_user_id = 0;
    private string $my_user_name = '';
    private string $style = 'etchat_dino_styles';

    public function __construct()
    {
        parent::__construct();

        require_once './class/ZugriffsGuard.class.php';
        new ZugriffsGuard();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        $this->lang = new LangJson();

        // Config laden (nur das, was wir brauchen)
        $this->config = $this->dbObj->sqlGet(
            "SELECT etchat_config_style
             FROM {$this->_prefix}etchat_config
             LIMIT 1"
        ) ?: [];

        $this->dbObj->close();

        $this->style = $this->config[0]['etchat_config_style'] ?? 'etchat_dino_styles';

        // ============================================================
        // Parameter einlesen und validieren
        // ============================================================
        $this->my_user_id   = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        $this->my_user_name = (string)($_SESSION['etchat_' . $this->_prefix . 'username'] ?? '');

        $this->partner_id   = (int)($_GET['partnerId'] ?? 0);
        $this->partner_name = trim((string)($_GET['partnerName'] ?? ''));

        if ($this->my_user_id === 0) {
            $this->renderError($this->getText('private_window_error_not_logged_in',
                'Sie sind nicht eingeloggt.'));
            return;
        }

        if ($this->partner_id === 0 || $this->partner_id === $this->my_user_id) {
            $this->renderError($this->getText('private_window_error_invalid_partner',
                'Ungültiger Chat-Partner.'));
            return;
        }

        if ($this->partner_name === '') {
            $this->partner_name = 'Partner #' . $this->partner_id;
        }

        $this->render();
    }

    private function getText(string $key, string $default = ''): string
    {
        return $this->lang->get($key, $default);
    }

    // ============================================================
    // Fehlerausgabe (wenn z. B. nicht eingeloggt)
    // ============================================================
    private function renderError(string $message): void
    {
        echo "<!DOCTYPE html><html lang='de'><head><meta charset='UTF-8'>";
        echo "<title>" . htmlspecialchars($this->getText('private_window_title',
            'Privat mit {name}'), ENT_QUOTES, 'UTF-8') . "</title>";
        echo "</head><body style='background:#1a1a1a;color:#f0f0f0;font-family:Arial,sans-serif;";
        echo "display:flex;align-items:center;justify-content:center;height:100vh;margin:0;'>";
        echo "<div style='text-align:center;padding:20px;max-width:400px;'>";
        echo "<div style='font-size:48px;margin-bottom:20px;'>⚠️</div>";
        echo "<p style='font-size:16px;'>" . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . "</p>";
        echo "</div></body></html>";
    }

    // ============================================================
    // Haupt-Rendering
    // ============================================================
    private function render(): void
    {
        $partner_name_safe = htmlspecialchars($this->partner_name, ENT_QUOTES, 'UTF-8');
        $title = str_replace('{name}', $partner_name_safe,
            $this->getText('private_window_title', 'Privat mit {name}'));

        // ============================================================
        // Kopfbereich (HTML-Header, Styles, inline CSS fürs Popup)
        // ============================================================
        echo "<!DOCTYPE html>";
        echo "<html lang='de'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
        echo "<title>" . $title . "</title>";
        echo "<link rel='stylesheet' type='text/css' href='styles/{$this->style}/style.css'>";
        echo $this->getInlineCss();
        echo "</head>";
        echo "<body id='body' class='private-window-body'>";

        // ============================================================
        // Haupt-Container
        // ============================================================
        echo "<div id='private-window'>";

        // ---------- Header ----------
        echo "<div id='private-header'>";
        echo "<span class='private-header-title'>💬 " . $title . "</span>";
        echo "<button type='button' id='private-back-btn' class='private-header-btn' ";
        echo "title='" . htmlspecialchars($this->getText('private_window_back_to_chat',
            'Zurück in den Chat'), ENT_QUOTES, 'UTF-8') . "'>📂</button>";
        echo "</div>";

        // ---------- Nachrichten-Bereich ----------
        echo "<div id='private-messages'>";
        echo "<div class='private-loading'>" .
            htmlspecialchars($this->getText('private_window_loading', 'Lade Nachrichten...'),
                ENT_QUOTES, 'UTF-8') . "</div>";
        echo "</div>";

        // ---------- Smiley-Panel (versteckt) ----------
        echo "<div id='private-smiley-panel' style='display:none;'>";
        echo "<div class='private-smiley-loading'>" .
            htmlspecialchars($this->getText('smileys_loading', 'Lade Smileys...'),
                ENT_QUOTES, 'UTF-8') . "</div>";
        echo "</div>";

		// ---------- Eingabe-Bereich ----------
		echo "<div id='private-input-area'>";
		echo "<input type='text' id='private-input' class='private-input' ";
		echo "placeholder='" . htmlspecialchars($this->getText('private_window_placeholder',
			'Nachricht schreiben...'), ENT_QUOTES, 'UTF-8') . "' ";
		echo "autocomplete='off' maxlength='1000'>";
		echo "<button type='button' id='private-send-btn' class='private-input-btn private-send-btn' ";
		echo "title='" . htmlspecialchars($this->getText('private_window_send', 'Senden'),
			ENT_QUOTES, 'UTF-8') . "'>📨</button>";
		echo "<button type='button' id='private-smiley-btn' class='private-input-btn' ";
		echo "title='" . htmlspecialchars($this->getText('private_window_smiley', 'Smileys'),
			ENT_QUOTES, 'UTF-8') . "'>😊</button>";
		echo "</div>";

        // ---------- Opener-weg-Meldung (versteckt) ----------
        echo "<div id='private-left-overlay' style='display:none;'>";
        echo "<div class='private-left-box'>";
        echo "<div style='font-size:48px;margin-bottom:15px;'>👋</div>";
        echo "<h3>" . htmlspecialchars($this->getText('private_window_left',
            'Sie haben den Chat verlassen'), ENT_QUOTES, 'UTF-8') . "</h3>";
        echo "<p>" . htmlspecialchars($this->getText('private_window_left_hint',
            'Bitte öffnen Sie das Hauptfenster erneut, um weiter zu schreiben.'),
            ENT_QUOTES, 'UTF-8') . "</p>";
        echo "</div>";
        echo "</div>";

        echo "</div>"; // #private-window

        // ============================================================
        // JS-Konfiguration + chat-private.js
        // ============================================================
        echo $this->getJsConfig();
        echo "<script src='js/chat-private.js'></script>";

        echo "</body>";
        echo "</html>";
    }

    // ============================================================
    // JS-Konfiguration (window.PRIVATE_CONFIG)
    // ============================================================
    private function getJsConfig(): string
    {
        $config = [
            'partnerId'    => $this->partner_id,
            'partnerName'  => $this->partner_name,
            'myUserId'     => $this->my_user_id,
            'myUserName'   => $this->my_user_name,
            'messagesUrl'  => './?PrivateMessages',
            'smileysUrl'   => './?Smileys',
            'pollInterval' => 2000, // ms
            'lang'         => [
                'empty'         => $this->getText('private_window_empty', 'Noch keine Nachrichten.'),
                'error'         => $this->getText('private_window_error', 'Fehler beim Laden der Nachrichten.'),
                'offline'       => $this->getText('private_window_offline', 'Benutzer nicht erreichbar'),
                'offline_text'  => $this->getText('private_window_offline_text', 'Der Benutzer ist nicht mehr online.'),
                'send'          => $this->getText('private_window_send', 'Senden'),
            ],
        ];

        $json = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

        return "<script>window.PRIVATE_CONFIG = {$json};</script>";
    }

    // ============================================================
    // Inline-CSS für das Popup
    // (bewusst inline, damit das Popup unabhängig vom Chat-Style funktioniert)
    // ============================================================
    private function getInlineCss(): string
    {
        return <<<CSS
<style>
/* ============================================================
   Privatchat-Popup – eigenständiges Layout
   ============================================================ */
html, body {
    margin: 0;
    padding: 0;
    height: 100%;
    background: #1a1a1a;
    color: #f0f0f0;
    font-family: Arial, sans-serif;
    font-size: 14px;
    overflow: hidden;
}

#private-window {
    display: flex;
    flex-direction: column;
    height: 100vh;
    position: relative;
}

/* ---------- Header ---------- */
#private-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 14px;
    background: rgba(0, 0, 0, 0.55);
    border-bottom: 1px solid #333;
    flex-shrink: 0;
}

.private-header-title {
    font-weight: bold;
    font-size: 14px;
    color: #f0f0f0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    flex: 1;
    margin-right: 10px;
}

.private-header-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 18px;
    padding: 0 5px;
    opacity: 0.7;
    transition: opacity 0.15s ease;
    color: #f0f0f0;
}

.private-header-btn:hover {
    opacity: 1;
}

/* ---------- Nachrichten-Bereich ---------- */
#private-messages {
    flex: 1;
    overflow-y: auto;
    padding: 12px;
    background: rgba(51, 51, 51, 0.85);
    min-height: 0;
}

.private-message {
    margin: 4px 0;
    word-wrap: break-word;
    line-height: 1.4;
}

.private-message.own {
    text-align: right;
}

.private-message.other {
    text-align: left;
}

.private-message .msg-bubble {
    display: inline-block;
    padding: 8px 12px;
    border-radius: 18px;
    max-width: 80%;
}

.private-message.own .msg-bubble {
    background: #5cb85c;
    color: #fff;
}

.private-message.other .msg-bubble {
    background: #444;
    color: #f0f0f0;
}

.private-message .msg-user {
    font-weight: bold;
    color: #5cb85c;
    margin-right: 4px;
}

.private-message .msg-time {
    display: block;
    font-size: 10px;
    opacity: 0.6;
    margin-top: 3px;
}

.private-message.system {
    text-align: center;
}

.private-message.system .msg-bubble {
    background: #d9534f;
    color: #fff;
    font-size: 12px;
    padding: 4px 10px;
}

.private-loading,
.private-empty {
    text-align: center;
    padding: 40px 20px;
    color: #888;
    font-style: italic;
}

/* ---------- Smiley-Panel ---------- */
#private-smiley-panel {
    overflow-y: auto;
    border-top: 1px solid #333;
    background: rgba(21, 21, 21, 0.95);
    padding: 8px;
    flex-shrink: 0;
}

.private-smiley-loading {
    text-align: center;
    padding: 10px;
    color: #888;
}

#private-smiley-panel .kat-header {
    margin-bottom: 6px;
}

#private-smiley-panel .kat {
    margin: 2px;
    cursor: pointer;
    display: inline-block;
    padding: 3px 8px;
    border-radius: 4px;
    background: #333;
    font-size: 12px;
}

#private-smiley-panel .kat.active-kat,
#private-smiley-panel .kat:hover {
    background: #5cb85c;
}

#private-smiley-panel .smiley-container {
    display: none;
    text-align: center;
}

#private-smiley-panel .smiley-container.active {
    display: block;
}

#private-smiley-panel .smiley-box {
    display: inline-block;
    margin: 3px;
    cursor: pointer;
}

#private-smiley-panel .img_smiley {
    cursor: pointer;
    max-height: 32px;
    vertical-align: middle;
}

/* ---------- Eingabe-Bereich ---------- */
#private-input-area {
    display: flex;
    gap: 6px;
    align-items: center;
    padding: 8px 10px;
    border-top: 1px solid #333;
    background: rgba(26, 26, 26, 0.95);
    flex-shrink: 0;
}

.private-input {
    flex: 1;
    padding: 8px 12px;
    border: 1px solid #444;
    background: #222;
    color: #f0f0f0;
    border-radius: 20px;
    outline: none;
    font-size: 14px;
}

.private-input::placeholder {
    color: #f0f0f0;
    opacity: 0.6;
}

.private-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.private-input-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 20px;
    padding: 4px;
    border-radius: 50%;
    transition: background 0.15s ease;
    line-height: 1;
}

.private-input-btn:hover {
    background: rgba(255, 255, 255, 0.1);
}

.private-send-btn {
    color: #5cb85c;
}

/* ---------- Opener-weg-Overlay ---------- */
#private-left-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.9);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 100;
    text-align: center;
    padding: 20px;
}

.private-left-box {
    max-width: 320px;
}

.private-left-box h3 {
    margin: 0 0 10px 0;
    color: #d9534f;
}

.private-left-box p {
    margin: 0;
    color: #ccc;
    font-size: 13px;
    line-height: 1.5;
}

/* ---------- Scrollbar (optional, für Webkit) ---------- */
#private-messages::-webkit-scrollbar,
#private-smiley-panel::-webkit-scrollbar {
    width: 8px;
}

#private-messages::-webkit-scrollbar-thumb,
#private-smiley-panel::-webkit-scrollbar-thumb {
    background: #444;
    border-radius: 4px;
}

#private-messages::-webkit-scrollbar-thumb:hover,
#private-smiley-panel::-webkit-scrollbar-thumb:hover {
    background: #555;
}
</style>
CSS;
    }
}