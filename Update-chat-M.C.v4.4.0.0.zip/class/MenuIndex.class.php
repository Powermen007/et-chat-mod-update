<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class MenuIndex extends DbConectionMaker
{
    /** @var array<int,array{id:string,title:string,src:string}> */
    public static array $panes = [];

    /**
     * Analysiert den DB-`url`-Wert.
     * Rückgabe:
     *   mode = 'window'  → window.open mit Größe (PC: eigenes Fenster, Handy: Pane)
     *   mode = 'pane'    → reine URL (immer Pane)
     *   mode = 'none'    → leer / ungültig (normaler Link)
     */
    private function parseMenuUrl(string $raw, string $target = ''): array
    {
        $raw = trim($raw);
        if ($raw === '' || $raw === '#') {
            return ['mode' => 'none', 'url' => '', 'width' => 0, 'height' => 0];
        }

        // window.open('URL','','width=...,height=...'); return false;
        if (stripos($raw, 'window.open') !== false) {
            if (preg_match(
                "/window\.open\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"][^'\"]*['\"]\s*,\s*['\"]([^'\"]*)['\"]/i",
                $raw, $m
            )) {
                $url    = $m[1];
                $params = $m[2];
                $w = 0; $h = 0;
                if (preg_match('/width=(\d+)/i',  $params, $mw)) $w = (int)$mw[1];
                if (preg_match('/height=(\d+)/i', $params, $mh)) $h = (int)$mh[1];

                return [
                    'mode'   => 'window',
                    'url'    => $url,
                    'width'  => $w > 0 ? $w : 900,
                    'height' => $h > 0 ? $h : 600,
                ];
            }
            return ['mode' => 'none', 'url' => '', 'width' => 0, 'height' => 0];
        }

        // reine URL: target entscheidet
        if ($target === '_blank') {
            return [
                'mode'   => 'blank',
                'url'    => $raw,
                'width'  => 0,
                'height' => 0,
            ];
        }

        // _top / _self / _parent / leer → Pane
        return [
            'mode'   => 'pane',
            'url'    => $raw,
            'width'  => 0,
            'height' => 0,
        ];
    }

    /**
     * Gibt die DB-Links aus (innerhalb des Wrappers).
     * Wrapper wird vom Template geöffnet/geschlossen.
     */
    public function renderLinks(): void
    {
        parent::__construct();

        $feld = $this->dbObj->sqlGet(
            "SELECT id, menu, link_text, image_active, image, url, target, gewicht
             FROM {$this->_prefix}etchat_menu
             WHERE menu = 2
             ORDER BY gewicht"
        );

        if (!empty($feld)) {
            foreach ($feld as $datasets) {
                $rawUrl = $datasets['url']       ?? '';
                $text   = $datasets['link_text'] ?? '';
                $img    = $datasets['image']     ?? '';
                $target = $datasets['target']    ?? '_blank';

                $parsed   = $this->parseMenuUrl($rawUrl, $target);
                $mode     = $parsed['mode'];
                $popupSrc = $parsed['url'];

                $textSafe = htmlspecialchars($text, ENT_QUOTES);
                $srcSafe  = htmlspecialchars($popupSrc, ENT_QUOTES);
                $idSafe   = 'menu-pane-' . (int)($datasets['id'] ?? 0);

                // data-Attribute je nach Modus
                // data-Attribute je nach Modus
                $dataAttrs = '';
                if ($mode === 'window') {
                    // PC: window.open mit Größe / Handy: Pane
                    $dataAttrs = " data-popup-mode=\"window\""
                               . " data-popup-src=\"{$srcSafe}\""
                               . " data-popup-title=\"{$textSafe}\""
                               . " data-popup-width=\"{$parsed['width']}\""
                               . " data-popup-height=\"{$parsed['height']}\""
                               . " data-pane-id=\"{$idSafe}\"";
                } elseif ($mode === 'blank') {
                    // Immer neues Fenster / neuer Tab (PC + Handy)
                    $dataAttrs = " data-popup-mode=\"blank\""
                               . " data-popup-src=\"{$srcSafe}\""
                               . " data-popup-title=\"{$textSafe}\"";
                } elseif ($mode === 'pane') {
                    $dataAttrs = " data-popup-mode=\"pane\""
                               . " data-popup-src=\"{$srcSafe}\""
                               . " data-popup-title=\"{$textSafe}\""
                               . " data-pane-id=\"{$idSafe}\"";
                }

                $href = ($mode === 'none') ? htmlspecialchars($rawUrl, ENT_QUOTES) : '#';
                $tgt  = ($mode === 'none') ? " target=\"{$target}\"" : '';

                if (($datasets['image_active'] ?? 0) == 1 && !empty($img)) {
                    $imgSafe = htmlspecialchars($img, ENT_QUOTES);
                    echo "<a class=\"start_text popup_link\"{$dataAttrs} id=\"{$textSafe}\""
                       . " href=\"{$href}\"{$tgt}>"
                       . "<img height=\"55\" alt=\"{$textSafe}\" title=\"{$textSafe}\" src=\"img/menu/{$imgSafe}\" />"
                       . "</a>&nbsp;&nbsp;&nbsp;";
                } else {
                    echo "<a class=\"start_text popup_link\"{$dataAttrs} id=\"{$textSafe}\""
                       . " href=\"{$href}\"{$tgt}>"
                       . "{$textSafe}</a>&nbsp;&nbsp;&nbsp;";
                }

                // Pane für 'pane' UND 'window' registrieren
                // ('window' braucht ein Pane für den Handy-Fallback;
                //  'blank' braucht KEIN Pane – geht immer in neues Fenster)
                if ($mode === 'pane' || $mode === 'window') {
                    self::$panes[] = [
                        'id'    => $idSafe,
                        'title' => $textSafe,
                        'src'   => $srcSafe,
                    ];
                }
            }
        }

        $this->dbObj->close();
    }

    /** Popup-Gerüst mit allen gesammelten Panes ausgeben. */
    public static function renderPopupShell(): void
    {
        echo '
        <div class="menu-popup" id="menu-popup" aria-hidden="true">
            <div class="menu-popup-backdrop" data-popup-close></div>
            <div class="menu-popup-box" role="dialog" aria-modal="true" aria-labelledby="menu-popup-title">
                <div class="menu-popup-header">
                    <span id="menu-popup-title">&nbsp;</span>
                    <button class="menu-popup-close" type="button" data-popup-close aria-label="Schließen">&times;</button>
                </div>
                <div class="menu-popup-content">';

        foreach (self::$panes as $p) {
            echo '<div class="menu-pane" id="' . $p['id'] . '" data-src="' . $p['src'] . '">'
               . '<iframe src="about:blank" title="' . $p['title'] . '"></iframe>'
               . '</div>';
        }

        echo '  </div>
            </div>
        </div>';
    }
}