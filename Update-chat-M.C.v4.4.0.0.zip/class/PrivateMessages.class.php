<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.

Aufruf: index.php?PrivateMessages
Liefert NUR die Nachrichten zwischen dem eingeloggten User und einem Partner.
Wird vom Privatchat-Popup (PrivateWindow) genutzt.

POST-Parameter:
  partnerId  (int, Pflicht)  – die User-ID des Chat-Partners

Die last_id wird pro Partner in der Session verwaltet:
  $_SESSION['etchat_<prefix>private_last_id_<partnerId>']
Beim Logout wird sie automatisch mit der Session gelöscht.
*/

class PrivateMessages extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Zugriffsschutz
        require_once './class/ZugriffsGuard.class.php';
        new ZugriffsGuard();

        // ============================================================
        // Logout-Marker prüfen (Race-Condition-Schutz, wie ReloaderMessages)
        // ============================================================
        if (!empty($_SESSION['etchat_' . $this->_prefix . 'logging_out'])) {
            $logoutAge = time() - (int)$_SESSION['etchat_' . $this->_prefix . 'logging_out'];
            if ($logoutAge < 60) {
                die(json_encode(["error" => "logging_out"]));
            }
            unset($_SESSION['etchat_' . $this->_prefix . 'logging_out']);
        }

        if (!isset($_SESSION['etchat_' . $this->_prefix . 'user_id'])) {
            die(json_encode(["error" => "Session user_id nicht gesetzt"]));
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: application/json; charset=utf-8');

        // ============================================================
        // Parameter validieren
        // ============================================================
        $my_user_id = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        $partner_id = (int)($_POST['partnerId'] ?? 0);

        if ($my_user_id === 0) {
            $this->errorOutput(json_encode(["error" => "Ungültige User-ID"]));
            return;
        }

        if ($partner_id === 0 || $partner_id === $my_user_id) {
            $this->errorOutput(json_encode(["error" => "Ungültige Partner-ID"]));
            return;
        }

        // ============================================================
        // Nachrichten laden und ausgeben
        // ============================================================
        $messages = $this->selectPrivateMessages($my_user_id, $partner_id);
        $this->makeJsonOutput($messages);
    }

    // ============================================================
    // Nachrichten zwischen zwei Usern laden
    // ============================================================
    private function selectPrivateMessages(int $my_user_id, int $partner_id): array
    {
        $show_sys = !(isset($_SESSION['etchat_' . $this->_prefix . 'sys_messages'])
            && !$_SESSION['etchat_' . $this->_prefix . 'sys_messages']);

        // ============================================================
        // last_id pro Partner aus der Session
        // ============================================================
        $sessionKey = 'etchat_' . $this->_prefix . 'private_last_id_' . $partner_id;
        $last_id    = (int)($_SESSION[$sessionKey] ?? 0);

        // ============================================================
        // Limit: messages_im_chat geteilt durch 2, max. 100
        // ============================================================
        $limit = (int)$this->_messages_shown_on_entrance;
        if ($limit < 1) $limit = 50;
        $limit = (int)floor($limit / 2);
        if ($limit > 100) $limit = 100;
        if ($limit < 1)   $limit = 1;

        // ============================================================
        // Erste Query: alle Nachrichten (last_id = 0)
        // ============================================================
if ($last_id === 0) {
    // 🔥 NEU: Beim ersten Aufruf NUR die last_id setzen, aber KEINE Nachrichten liefern.
    // (Der Verlauf kommt per postMessage vom Dialog – sonst doppelt.)
    $maxRow = $this->dbObj->sqlGet(
        "SELECT MAX(etchat_id) as max_id
         FROM {$this->_prefix}etchat_messages
         WHERE etchat_privat <> 0
           AND (
                 (etchat_user_fid = ? AND etchat_privat = ?)
              OR (etchat_user_fid = ? AND etchat_privat = ?)
           )",
        [$my_user_id, $partner_id, $partner_id, $my_user_id]
    );
    $maxId = (int)($maxRow[0]['max_id'] ?? 0);
    $_SESSION[$sessionKey] = $maxId;
    return [];
}

        // ============================================================
        // Folgequery: nur neue Nachrichten seit last_id
        // ============================================================
        $sql = "SELECT etchat_id, etchat_username, etchat_text, etchat_timestamp,
                       etchat_fid_room, etchat_privat, etchat_user_id,
                       etchat_text_css, etchat_userprivilegien, etchat_usersex,
                       etchat_avatar
                FROM {$this->_prefix}etchat_messages
                JOIN {$this->_prefix}etchat_user
                  ON etchat_user_id = etchat_user_fid
                WHERE etchat_privat <> 0
                  AND etchat_id > ?
                  AND (
                        (etchat_user_fid = ? AND etchat_privat = ?)
                     OR (etchat_user_fid = ? AND etchat_privat = ?)
                  )";

        $params = [$last_id, $my_user_id, $partner_id, $partner_id, $my_user_id];

        if (!$show_sys) {
            $sql .= " AND etchat_user_fid <> 1";
        }

        $sql .= " ORDER BY etchat_id";

        $feld = $this->dbObj->sqlGet($sql, $params);

        if (is_array($feld) && !empty($feld)) {
            // Session-last_id aktualisieren
            $_SESSION[$sessionKey] = (int)($feld[count($feld) - 1]['etchat_id'] ?? $last_id);
        } else {
            $feld = [];
        }

        return $feld;
    }

    // ============================================================
    // JSON-Ausgabe (1:1 wie ReloaderMessages)
    // ============================================================
    private function makeJsonOutput(array $feld): void
    {
        $ausgabeJSON_Inhalt = [];

        static $sml = null;

        if ($sml === null) {
            $sml = $this->dbObj->sqlGet(
                "SELECT etchat_smileys_sign, etchat_smileys_img FROM {$this->_prefix}etchat_smileys"
            ) ?: [];
        }

        if (!empty($feld) && is_array($feld)) {
            foreach ($feld as $row) {
                $user_id   = $row['etchat_user_id'] ?? 0;
                $privat_id = $row['etchat_privat'] ?? 0;

                // Blockierte User ausblenden
                if ($this->blockiere($user_id, $privat_id)) {
                    continue;
                }

                $message2send = addslashes(
                    StaticMethods::filtering(stripslashes($row['etchat_text'] ?? ''), $sml, $this->_prefix)
                );

                // /window:-Präfix entfernen
                if (substr($message2send, 0, 8) === "/window:" && $privat_id != 0) {
                    $message2send = substr($message2send, 8);
                    $normal_message_counter = "";
                } else {
                    $_SESSION['etchat_' . $this->_prefix . 'count'] ??= 0;
                    $_SESSION['etchat_' . $this->_prefix . 'count']++;
                    $normal_message_counter = $_SESSION['etchat_' . $this->_prefix . 'count'];
                }

                $ausgabeJSON_Inhalt[] = "{\"id\":\"" . $normal_message_counter .
                    "\",\"user\":\"" . addslashes($row['etchat_username'] ?? '') .
                    "\",\"user_id\":\"" . addslashes($user_id) .
                    "\",\"message\":\"" . $message2send .
                    "\",\"time\":\"" . date("H:i", $row['etchat_timestamp'] ?? 0) .
                    "\",\"privat\":\"" . $privat_id .
                    "\",\"css\":\"" . ($row['etchat_text_css'] ?? '') .
                    "\",\"priv\":\"" . ($row['etchat_userprivilegien'] ?? '') .
                    "\",\"sex\":\"" . ($row['etchat_usersex'] ?? '') .
                    "\",\"avatar\":\"" . ($row['etchat_avatar'] ?? '') . "\"}";
            }
        }

        $this->dbObj->close();

        if (count($ausgabeJSON_Inhalt) > 0) {
            echo '{"data":[' . implode(",", $ausgabeJSON_Inhalt) . ']}';
        } else {
            echo '{"data":[]}';
        }
    }

    // ============================================================
    // Blockiere-Logik (1:1 aus ReloaderMessages kopiert)
    // ============================================================
    private function blockiere($user_id, $privat_id): bool
    {
        if (isset($_SESSION['etchat_' . $this->_prefix . 'block_all']) &&
            is_array($_SESSION['etchat_' . $this->_prefix . 'block_all']) &&
            in_array($user_id, $_SESSION['etchat_' . $this->_prefix . 'block_all'])) {
            return true;
        }

        if (isset($_SESSION['etchat_' . $this->_prefix . 'block_priv']) &&
            is_array($_SESSION['etchat_' . $this->_prefix . 'block_priv']) &&
            in_array($user_id, $_SESSION['etchat_' . $this->_prefix . 'block_priv']) &&
            $privat_id == $_SESSION['etchat_' . $this->_prefix . 'user_id']) {
            return true;
        }

        return false;
    }

    private function errorOutput(string $message): void
    {
        echo $message;
        $this->dbObj->close();
    }
}