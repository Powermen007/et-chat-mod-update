
ALTER TABLE `etchat_config` ADD `etchat_ts3_enabled`        TINYINT(1)   NOT NULL DEFAULT 0;
ALTER TABLE `etchat_config` ADD `etchat_ts3_host`           VARCHAR(100) NOT NULL DEFAULT '';
ALTER TABLE `etchat_config` ADD `etchat_ts3_port`           INT(5)       NOT NULL DEFAULT 9987;
ALTER TABLE `etchat_config` ADD `etchat_ts3_join_password`  VARCHAR(50)  NOT NULL DEFAULT '';
ALTER TABLE `etchat_config` ADD `etchat_ts3_query_password` VARCHAR(100) NOT NULL DEFAULT '';
ALTER TABLE `etchat_config` ADD `etchat_ts3_display_mode`   TINYINT(1)   NOT NULL DEFAULT 0;


INSERT INTO `etchat_wunschbox_config` (`config_key`, `config_value`, `description`)
SELECT 'wunschbox_close_before_end', '10', 'Wunschbox schlie�t X Minuten vor Sendungsende'
WHERE NOT EXISTS (
    SELECT 1 FROM `etchat_wunschbox_config` WHERE `config_key` = 'wunschbox_close_before_end'
);