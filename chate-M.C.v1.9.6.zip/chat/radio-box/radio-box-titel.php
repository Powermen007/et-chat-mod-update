<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

// Cache-Header setzen
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$GLOBALS["path"] = "./../";

spl_autoload_register(function($class_name) {
    require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class ExternUserViewTitelRadio extends DbConectionMaker
{
    public function __construct (){

        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        unset($GLOBALS["path"]);

        // Style laden
        $desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

        // --- Datumsauswahl vorbereiten ---
        $dates = $this->dbObj->sqlGet("
            SELECT DISTINCT DATE(FROM_UNIXTIME(etchat_played_at)) as played_date
            FROM {$this->_prefix}etchat_radio_history
            ORDER BY played_date DESC
        ");

        // ausgewÃ¤hltes Datum (Standard = heute)
        $selectedDate = isset($_GET['date']) ? $_GET['date'] : date("Y-m-d");

        // Pagination vorbereiten
        $perPage = 25;
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $offset = ($page - 1) * $perPage;

        // Gesamtanzahl fÃ¼r die Pagination
        $countResult = $this->dbObj->sqlGet("
            SELECT COUNT(*) as cnt
            FROM {$this->_prefix}etchat_radio_history
            WHERE DATE(FROM_UNIXTIME(etchat_played_at)) = '{$selectedDate}'
        ");
        $total = $countResult[0]['cnt'] ?? 0;
        $totalPages = ceil($total / $perPage);

        // Daten fÃ¼r die gewÃ¤hlte Seite laden
        $radio=$this->dbObj->sqlGet("
            SELECT etchat_id, etchat_song_title, etchat_song_artist, etchat_dj_name, etchat_played_at
            FROM {$this->_prefix}etchat_radio_history
            WHERE DATE(FROM_UNIXTIME(etchat_played_at)) = '{$selectedDate}'
            ORDER BY etchat_played_at DESC
            LIMIT {$offset}, {$perPage}
        ");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="de" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link href="player.css" rel="stylesheet" type="text/css">
<?php
    if (is_array($desei)){
        foreach($desei as $data){
            echo"<link href=\"../styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        }
    }
?>
<title>Titel-Liste</title>

</head>
<body id="body">

<div class="radio-history">
    <form method="get">
        <label for="date">Datum w&auml;hlen:</label>
        <select name="date" id="date" onchange="this.form.submit()">
            <?php
            if (is_array($dates)) {
                foreach ($dates as $row) {
                    $d = $row['played_date'];
                    $sel = ($d == $selectedDate) ? "selected" : "";
                    echo "<option value='{$d}' {$sel}>".date("d.m.Y", strtotime($d))."</option>";
                }
            }
            ?>
        </select>
    </form>

    <h3>&#127926; Zuletzt gespielt Titel(<?php echo date("d.m.Y", strtotime($selectedDate)); ?>) w&auml;rend der Moderierten Sendungen</h3>
    <ul>
    <?php
    if (is_array($radio) && count($radio) > 0) {
        foreach ($radio as $data_radio) {
            $titel  = htmlspecialchars($data_radio[1]);
            $artist = htmlspecialchars($data_radio[2]);
            $djname = htmlspecialchars($data_radio[3]);
            $played = date("H:i", $data_radio[4]);

            if ($djname === "Auto DJ") {
                echo "<li>[$played] <b>$artist</b> &ndash; $titel</li>";
            } else {
                echo "<li>[$played] <b>$artist</b> &ndash; $titel <span class='dj'>(mit DJ $djname)</span></li>";
            }
        }
    } else {
        echo "<li>Keine Titel fÃ¼r diesen Tag.</li>";
    }
    ?>
    </ul>

    <div class="pagination">
        <?php
        if ($totalPages > 1) {
            for ($i=1; $i <= $totalPages; $i++) {
                $active = ($i == $page) ? "class='active'" : "";
                echo "<a href='?date={$selectedDate}&page={$i}' {$active}>{$i}</a>";
            }
        }
        ?>
    </div>
</div>
<!-- Auto-Refresh Script -->
<script>
    setInterval(function(){
        fetch(window.location.href)
            .then(response => response.text())
            .then(html => {
                // Neuen Inhalt parsen
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newList = doc.querySelector('.radio-history');
                if (newList) {
                    document.querySelector('.radio-history').innerHTML = newList.innerHTML;
                }
            })
            .catch(err => console.error('Fehler beim Aktualisieren der Titelliste:', err));
    }, 30000); // alle 30 Sekunden
</script>
</body>
</html>
<?php
    }
}
new ExternUserViewTitelRadio();
?>