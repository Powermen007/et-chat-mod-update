<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

session_start();

// 1. Config laden
require_once __DIR__ . "/config.php";

// 2. Klassen laden
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/Kontakt.class.php";

// 3. Bewerbung-Objekt
$kontakt = new Kontakt();
$style = $kontakt->getStyleName();
$meldung = '';

// Formularverarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 1) {
    $meldung = $kontakt->senden($_POST);
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Kontakt</title>
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style.css" rel="stylesheet">
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style-mobil-index.css" rel="stylesheet">

</head>
<body id="body">

    <center><h2>Kontakt</h2></center>

<?php if ($meldung): ?>
    <div class="meldung" style="background: <?= strpos($meldung, 'Fehler') !== false ? '#ff4c4c' : '#4caf50' ?>;">
    <?= htmlspecialchars($meldung) ?>
</div>

<?php endif; ?>

<form method="POST" action="" class="bewerbung-form">
    <input type="hidden" name="action" value="1">

	    <!-- Hidden-Felder für Spam-Schutz -->
	<input type="hidden" name="https_ceck" value="">
	<input type="hidden" name="www" value="">


    Bitte f&uuml;llen Sie die mit <span class="pflichthinweis">*</span> gekennzeichneten Felder aus (Pflichtfelder).

<?php
$fields = $kontakt->getDb()->sqlGet("
    SELECT *
    FROM {$prefix}etchat_kontakt_fields
    WHERE etchat_visible=1
    ORDER BY etchat_sort_order ASC
");

foreach ($fields as $f) {
    $rawName = $f['etchat_field_name']; // Originalname aus DB
    $name = preg_replace('/[^a-zA-Z0-9_]/', '_', $rawName); // für HTML-Safe Name/ID
    $label = htmlspecialchars($rawName); // für Anzeige unverändert
    $required = $f['etchat_required'] ? 'required' : '';
    $pflichthinweis = $f['etchat_required'] ? ' <span class="pflichthinweis">*</span>' : '';
    $type = $f['etchat_field_type'] ?? 'text';

    switch ($type) {
        case 'text':
        case 'email':
        case 'date':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<input type='{$type}' name='{$name}' id='{$name}' {$required} value='" . htmlspecialchars($_POST[$name] ?? '') . "'>";
            break;

        case 'textarea':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<textarea name='{$name}' id='{$name}' {$required}>" . htmlspecialchars($_POST[$name] ?? '') . "</textarea>";
            break;

        case 'select':
            $options = json_decode($f['etchat_options'], true) ?: [];
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<select name='{$name}' id='{$name}' {$required}>";
            echo "<option value=''>Bitte ausw&auml;hlen:</option>";
            foreach ($options as $opt) {
                $sel = (($_POST[$name] ?? '') == $opt) ? 'selected' : '';
                echo "<option value='{$opt}' {$sel}>{$opt}</option>";
            }
            echo "</select>";
            break;

        case 'checkbox':
            $options = json_decode($f['etchat_options'], true) ?: [];
            echo "<label>{$label}:{$pflichthinweis}</label>";
            echo '<div class="musikrichtungen">';
            foreach ($options as $opt) {
                $chk = in_array($opt, $_POST[$name] ?? []) ? 'checked' : '';
                echo '<div class="musikrichtung-option">';
                echo "<label><input type='checkbox' name='{$name}[]' value='" . htmlspecialchars($opt) . "' $chk> " . htmlspecialchars($opt) . "</label>";
                echo '</div>';
            }
            echo '</div>';
            break;
    }
}


?>

        <label for="web_php_de">Bitte geben Sie die Zeichen ein:<span class="pflichthinweis">*</span></label>
    <div class="captcha-group">
        <img src="captcha.php" alt="Captcha" onclick="this.src='captcha.php?'+Math.random();" title="Klicken zum Neuladen">
        <input type="text" name="web_php_de" id="web_php_de" maxlength="5" required>
    </div>

    <button type="submit">Anfrage senden</button>
</form>

</body>
</html>