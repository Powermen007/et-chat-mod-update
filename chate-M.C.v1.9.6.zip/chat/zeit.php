<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

echo "<script language=\"javascript\" type=\"text/javascript\" src=\"js/uhr.js\"></script><center style=\"margin-top: 20px;\"><b>";

$d = date('N');

switch ($d) {
    case 1:
        $dd = "Mo.";
        break;
    case 2:
        $dd = "Di.";
        break;
    case 3:
        $dd = "Mi.";
        break;
    case 4:
        $dd = "Do.";
        break;
    case 5:
        $dd = "Fr.";
        break;
    case 6:
        $dd = "Sa.";
        break;
    case 7:
        $dd = "So.";
        break;
}

$m = date('m');

switch ($m) {
    case 1:
        $mm = "Januar";
        break;
    case 2:
        $mm = "Februar";
        break;
    case 3:
        $mm = "M&auml;rz";
        break;
    case 4:
        $mm = "April";
        break;
    case 5:
        $mm = "Mai";
        break;
    case 6:
        $mm = "Juni";
        break;
    case 7:
        $mm = "Juli";
        break;
    case 8:
        $mm = "August";
        break;
    case 9:
        $mm = "September";
        break;
    case 10:
        $mm = "Oktober";
        break;
    case 11:
        $mm = "November";
        break;
    case 12:
        $mm = "Dezember";
        break;
}

echo "$dd ";
echo date('d');
echo ". $mm ";
echo date('Y');

echo "<br><span id=\"localtime\"></span></center></b>";

?>