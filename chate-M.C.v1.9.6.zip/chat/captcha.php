<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

session_start();

// Captcha-Zeichenfolge generieren (5 Zeichen)
$zeichen = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
$captcha_text = '';
for ($i = 0; $i < 5; $i++) {
    $captcha_text .= $zeichen[rand(0, strlen($zeichen)-1)];
}

// In Session speichern (korrekter Name)
$_SESSION['captcha_text'] = $captcha_text;

// Bildgröße
$breite = 140;
$hoehe = 50;
$bild = imagecreatetruecolor($breite, $hoehe);

// Farben
$hintergrund = imagecolorallocate($bild, 255, 255, 255);
$schriftfarbe = imagecolorallocate($bild, 0, 0, 0);
$störfarbe = imagecolorallocate($bild, 150, 150, 150);

// Hintergrund füllen
imagefilledrectangle($bild, 0, 0, $breite, $hoehe, $hintergrund);

// Captcha-Text ins Bild schreiben
$fontSize = 8;
$x = 10;
$y = 10;
imagestring($bild, $fontSize, $x, $y, $captcha_text, $schriftfarbe);

// Optional: leichtes Rauschen hinzufügen
for ($i = 0; $i < 100; $i++) {
    imagesetpixel($bild, rand(0,$breite-1), rand(0,$hoehe-1), $störfarbe);
}

// Header und Bild ausgeben
header('Content-Type: image/png');
imagepng($bild);
imagedestroy($bild);