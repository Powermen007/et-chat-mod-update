<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Profil extends DbConectionMaker
{
    public function __construct() {
        parent::__construct();

        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');

        if (empty($_SESSION['etchat_' . $this->_prefix . 'user_id'])) {
            echo "Sie sind nicht angemeldet im Chat.";
            $this->dbObj->close();
            exit();
        }

		$user_id = filter_input(INPUT_GET, 'user_id', FILTER_SANITIZE_NUMBER_INT);

        $userId = $_SESSION['etchat_' . $this->_prefix . 'user_id'];
        $feld = $this->dbObj->sqlGet("SELECT
            etchat_username,
            etchat_userprivilegien,
            etchat_reg_timestamp,
            etchat_usersex,
            etchat_avatar,
            etchat_geb_tag,
            etchat_geb_monat,
            etchat_geb_jahr,
            etchat_ort,
            etchat_beschreibung
        FROM {$this->_prefix}etchat_user
        WHERE etchat_user_id = $user_id
        LIMIT 1");

        $this->dbObj->close();

        if (empty($feld)) {
            echo "Benutzerdaten konnten nicht geladen werden.";
            exit();
        }

        $gebTag   = (int)($feld[0][5] ?? 0);
        $gebMonat = (int)($feld[0][6] ?? 0);
        $gebJahr  = (int)($feld[0][7] ?? 0);
		$alter = null;
		$geburtstagsGruss = '';
		$heute = new DateTime();

		if ($gebTag && $gebMonat) {
		    if ($gebJahr > 0 && checkdate($gebMonat, $gebTag, $gebJahr)) {
		        // Jahr vorhanden ? Alter berechnen
		        $geburtsdatum = new DateTime("$gebJahr-$gebMonat-$gebTag");
		        $alter = $heute->diff($geburtsdatum)->y;

		        // Geburtstag heute?
		        if ((int)$heute->format('j') === $gebTag && (int)$heute->format('n') === $gebMonat) {
		            $geburtstagsGruss = "<b><p style=\"color:red\">" 
		                . htmlspecialchars($feld[0][0]) 
		                . " hat heute Geburtstag! Und wird $alter Jahre alt.</p></b>";
		        }
		    } elseif (checkdate($gebMonat, $gebTag, 2000)) {
		        // Jahr fehlt ? nur Tag/Monat vergleichen
		        if ((int)$heute->format('j') === $gebTag && (int)$heute->format('n') === $gebMonat) {
		            $geburtstagsGruss = "<b><p style=\"color:red\">" 
		                . htmlspecialchars($feld[0][0]) 
		                . " hat heute Geburtstag!</p></b>";
		        }
		    }
		}

		$geburt = '';
		if ($geburtstagsGruss) {
		    $geburt = "<div>$geburtstagsGruss</div>";
		}

        // Alter in assoziatives Array für Template
        $feld[0]['alter'] = $alter;

        $uploadDir = './userpic/';
        $userImages = [];

        foreach (scandir($uploadDir) as $file) {
            $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'JPG', 'JPEG', 'PNG', 'GIF'])) {
                $metaFile = $uploadDir . $file . '.txt';
                if (file_exists($metaFile)) {
                    $meta = file_get_contents($metaFile);
                    list($uploader, $datum) = explode('|', $meta);

                    if ($uploader == $feld[0][0]) {
                        $userImages[] = [
                            'image' => $file,
                            'datum' => $datum
                        ];
                    }
                }
            }
        }

		//Sotiere die bilder nach neuste zu erst
   		usort($userImages, function ($a, $b) {
		    return strtotime($b['datum']) - strtotime($a['datum']);
		});

        $feld[0][10] = $userImages;

       $avatar_an_aus = $_SESSION['etchat_'.$this->_prefix.'be_info_pic'];


        $this->initTemplate($feld, $geburt, $avatar_an_aus);
    }

    private function initTemplate($feld, $geburt, $avatar_an_aus) {
        include_once("styles/".$_SESSION['etchat_'.$this->_prefix.'style']."/profil.tpl.html");
    }
}
?>