<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class AfterKicklistInsertion extends DbConectionMaker
{

	public function __construct (){ 
		
		parent::__construct(); 

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		
		$this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = ".$_SESSION['etchat_'.$this->_prefix.'user_id']);
		$this->dbObj->close();
		
		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->kick[0];
		
		$this->initTemplate($lang);
		
		@session_unset();
		@session_destroy();
		
	}

	private function initTemplate($lang){
		include_once("styles/".$_SESSION['etchat_'.$this->_prefix.'style']."/kicked.tpl.html");
	}
}
