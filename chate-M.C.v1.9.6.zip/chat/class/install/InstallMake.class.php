<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class InstallMake extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (!isset($_GET['runInstall'])) {
            $this->showInstallLoadingScreen();
            return;
        }

        $this->runInstall();
    }

private function showInstallLoadingScreen()
{
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Installation wird ausgef&uuml;hrt.</title>
        <style>
            body {
                background: #1f2430;
                color: #ffffff;
                font-family: Arial, sans-serif;
                text-align: center;
                padding-top: 100px;
            }
            .spinner {
                margin: 40px auto;
                width: 60px;
                height: 60px;
                border: 8px solid #3a4050;
                border-top: 8px solid #00e676;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            .message {
                font-size: 18px;
                color: #ccc;
            }
            #result {
                margin-top: 30px;
            }
        </style>
    </head>
    <body>
        <div class="spinner"></div>
        <div class="message">Installation wird ausgef&uuml;hrt... Bitte einen Moment Geduld.</div>
        <div id="result"></div>

        <script>
            let params = new URLSearchParams(window.location.search);
            params.set("runInstall", "1"); // runInstall ergänzen
            let newUrl = window.location.pathname + "?" + params.toString();

            let iframe = document.createElement("iframe");
            iframe.style.display = "none";
            iframe.src = newUrl;
            document.body.appendChild(iframe);

            iframe.onload = function () {
                document.getElementById("result").innerHTML = iframe.contentDocument.body.innerHTML;
                document.querySelector(".spinner").style.display = "none";
                document.querySelector(".message").innerText = "Installation abgeschlossen!";
            };
        </script>
    </body>
    </html>
    <?php
    exit;
}


    private function runInstall()
    {
        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

        if ($this->_usedDatabase == "mysql") $sql_dump = "install/mysql_db.sql";
        if ($this->_usedDatabase == "pgsql") $sql_dump = "install/postgres_db.sql";

        if (file_exists($sql_dump)) {
            $sql = explode("-- limit --", file_get_contents($sql_dump));
            for ($a = 0; $a < count($sql); $a++) {
                $zeile = trim($sql[$a]);
                if (!empty($zeile)) {
                    $zeile = str_replace("###prefix###", $this->_prefix, $zeile);
                    $this->dbObj->sqlSet($zeile);
                }
            }
            $this->dbObj->close();

            // Ergebnis nur ausgeben – wird in das IFrame geladen
            include_once("styles/install_tpl/installed.tpl.html");
        } else {
            echo "<p style='color:red'>Install directory was not found.</p>";
        }
    }
}

