<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminPropertyIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$this->configTabData2Session();
		$this->dbObj->close();

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_prop[0];


		if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "co_admin"])) {

			$handle = opendir("styles/");
			$print_styles = '';
			while($files = readdir($handle))
			{
				if($files != "." && $files != "..")
				{
					if (is_dir("styles/".$files) && $files!="admin_tpl" && $files!="install_tpl") {
                        if ($_SESSION['etchat_'.$this->_prefix.'style']==$files) $print_styles.= "<option value=\"".$files."\" selected>".$files."</option>\n";
                        else $print_styles.= "<option value=\"".$files."\">".$files."</option>\n";
					}
				}
			}

			$handle = opendir("lang/");
			$print_lang_files = '';
			while($files = readdir($handle))
			{
				if (!is_dir("lang/".$files) && stripos($files, '.xml')!==false && substr($files,0,5)=='lang_') {

					$xml_file = file_get_contents('lang/'.$files);
					$p = new AAFParser($xml_file);
					$p->Parse();
					if ($files == $_SESSION['etchat_'.$this->_prefix.'lang_xml_file']) $print_lang_files.= "<option value=\"".$files."\" selected>".$p->document->tagAttrs['lang']."</option>";
					else $print_lang_files.=  "<option value=\"".$files."\">".$p->document->tagAttrs['lang']."</option>";
				}
			}

			    // NEUE BEDINGUNG FÜR TEMPLATE
			    if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] === "admin") {
			        include_once("styles/admin_tpl/indexProperty.tpl.html");
			    } elseif ($_SESSION["etchat_" . $this->_prefix . "user_priv"] === "co_admin") {
			        include_once("styles/admin_tpl/indexPropertyCoAdmin.tpl.html");
			    }

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}

	}
}
