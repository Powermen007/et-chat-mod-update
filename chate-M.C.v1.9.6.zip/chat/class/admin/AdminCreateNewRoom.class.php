<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminCreateNewRoom extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_rooms[0];


		if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "co_admin"])) {

			if ($_POST['room_priv']==3)
				$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_rooms (etchat_roomname, etchat_room_goup, etchat_room_pw) VALUES ('".$_POST['room']."', ".((int)$_POST['room_priv']).", '".$_POST['roompw']."')");
			else
				$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_rooms (etchat_roomname, etchat_room_goup) VALUES ('".$_POST['room']."', ".((int)$_POST['room_priv']).")");

			$this->dbObj->close();
			header("Location: ./?AdminRoomsIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
