<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminDeleteFromBlacklist extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_blacklist[0];


		if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "chatwache", "co_admin"])) {

			if($_GET['cs4rue']!=$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] || !isset($_GET['cs4rue']) || !isset($_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'])){
				echo "Dear Admin this User tried to fake you. ;-)";
				return false;
			}

			$this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_blacklist WHERE etchat_blacklist_id = ".(int)$_GET['id']);
			$this->dbObj->close();
			header("Location: ./?AdminBlacklistIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
