<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminEditRoom extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_rooms[0];


		if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "co_admin"])) {

			$feld=$this->dbObj->sqlGet("SELECT etchat_id_room, etchat_roomname, etchat_room_goup, etchat_room_pw, etchat_room_message FROM {$this->_prefix}etchat_rooms WHERE etchat_id_room = ".(int)$_GET['id']);
			$this->dbObj->close();

			$this->initTemplate($lang, $feld);

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}

	private function initTemplate($lang, $feld){
		include_once("styles/admin_tpl/editRoom.tpl.html");
	}
}
