<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminKontakt extends DbConectionMaker
{
    private array $kontakte = [];
    private string $filter = '';
    private int $perPage = 10;

    private array $statusLabels = [
        'neu' => 'Neu',
        'bearbeitung_admin' => 'In Bearbeitung v. Admin',
        'bearbeitung_coadmin' => 'In Bearbeitung v. Co-Admin',
		'bearbeitung_chatwache' => 'In Bearbeitung v. Chatwache',
        'abgeschlossen' => 'Abgeschlossen'
    ];

    public function __construct()
    {
        parent::__construct();
        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $allowedRoles = ["admin", "co_admin", "chatwache"];
        if (!in_array($_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? '', $allowedRoles)) {
            header("Location: ./");
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['save_kontakt'])) {
                $this->saveStatus($_POST);
            } elseif (!empty($_POST['delete_kontakt'])) {
                $this->deleteKontakt($_POST);
            }
        } else {
            $this->showList();
        }
    }

    private function showList(): void
    {
        $this->filter = $_GET['status_filter'] ?? '';
        $search = $_GET['search'] ?? '';
        $saved = isset($_GET['saved']);
        $page = max(1, (int)($_GET['page'] ?? 1));
        $offset = ($page - 1) * $this->perPage;

        $sqlCount = "SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_kontakt WHERE 1";
        $sql = "SELECT * FROM {$this->_prefix}etchat_kontakt WHERE 1";

        if (!empty($this->filter)) {
            $filterEsc = $this->dbObj->escape($this->filter);
            $sql .= " AND etchat_status='{$filterEsc}'";
            $sqlCount .= " AND etchat_status='{$filterEsc}'";
        }

        if (!empty($search)) {
            $searchEsc = $this->dbObj->escape('%'.$search.'%');
            $sql .= " AND etchat_kontakt_daten LIKE '{$searchEsc}'";
            $sqlCount .= " AND etchat_kontakt_daten LIKE '{$searchEsc}'";
        }

        $sql .= " ORDER BY etchat_erstellt_am DESC LIMIT {$this->perPage} OFFSET {$offset}";
        $result = $this->dbObj->sqlGet($sql);
        $this->kontakte = is_array($result) ? $result : [];

        $totalAll = $this->dbObj->sqlGet($sqlCount)[0]['cnt'] ?? 0;
        $totalPages = ceil($totalAll / $this->perPage);

        $this->renderHTML($page, $totalPages, $totalAll, $saved);
    }

    private function renderHTML(int $currentPage, int $totalPages, int $totalAll, bool $saved): void
    {
        $filter = $this->filter;
        $kontakte = $this->kontakte;
        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Kontakt Admin</title>
            <link href="styles/<?php echo $_SESSION['etchat_'.$this->_prefix.'style']; ?>/style.css" rel="stylesheet">
            <style>
                table { border-collapse: collapse; width: 100%; }
                th, td { border: 1px solid #ccc; padding: 5px; vertical-align: top; }
                select, textarea { width: 100%; }
                textarea { min-height: 60px; }
                .filter { margin-bottom: 10px; }
                .save-btn { padding: 5px 10px; }
                .success-banner { background-color: #4CAF50; color: white; padding: 10px; border-radius: 5px; margin-bottom: 10px; position: relative; }
                .close-btn { position: absolute; right: 10px; top: 5px; cursor: pointer; font-weight: bold; }
            </style>
            <script>
                function closeBanner() { document.getElementById('successBanner').style.display = 'none'; }
                window.addEventListener('DOMContentLoaded', function() {
                    let banner = document.getElementById('successBanner');
                    if (banner) setTimeout(() => banner.style.display='none', 5000);
                });
            </script>
        </head>
        <body id="adminbereich_body">
		<?php
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $roleLinks = [
            "admin"     => "./?AdminIndex",
            "chatwache" => "./?AdminIndexChatwache",
            "co_admin"  => "./?AdminIndexCoAdmin"
        ];
        $backlinkUrl = $roleLinks[$role] ?? "./";
        echo "<a href=\"$backlinkUrl\">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml; </a><hr size=\"1\">";

        if ($role === "admin") {
            echo '<a href="./?AdminKontaktform">Kontakt Formular bearbeiten</a><br>';
        }

        if ($saved): ?>
            <br><div class="success-banner" id="successBanner">
                Änderungen erfolgreich gespeichert
                <span class="close-btn" onclick="closeBanner()">X</span>
            </div>
        <?php endif; ?>

        <h2>Alle Kontakte<?php 
            if($filter){
                echo " mit Status '".$this->statusLabels[$filter] ?? $filter."'";
            } 
        ?> (<?php echo $totalAll; ?> insgesamt)</h2>

        <div class="filter-row" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">

            <!-- Filter -->
            <form method="GET" action="./?AdminKontakt" class="filter" style="margin: 0;">
			<input type="hidden" name="AdminKontakt" value="">
                <label style="display:inline-flex; align-items:center; gap:4px; white-space:nowrap;">Status filtern:
                    <select name="status_filter" onchange="this.form.submit()">
                        <option value="">Alle</option>
                        <?php foreach($this->statusLabels as $key => $label): ?>
                            <option value="<?php echo $key; ?>" <?php if($filter === $key) echo 'selected'; ?>><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </form>

            <!-- Suche -->
            <form method="GET" action="./?AdminKontakt" class="filter" style="display: flex; align-items: center; gap: 5px; margin: 0;">
			<input type="hidden" name="AdminKontakt" value="">
                <input type="hidden" name="status_filter" value="<?php echo htmlspecialchars($_GET['status_filter'] ?? ''); ?>">
                <input type="text" name="search" placeholder="Suche..." 
                       value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" style="padding: 3px 6px;">
                <button type="submit">Suchen</button>
            </form>

            <!-- Reset -->
            <a href="./?AdminKontakt" class="reset-btn"
               style="padding: 1px 8px; background: #ccc; color: #000; text-decoration: none; border-radius: 4px;">
               🔄 Reset
            </a>
        </div>

        <!-- Pagination -->
        <div style="margin-top:10px;">
            <?php if($currentPage > 1): ?>
                <a href="./?AdminKontakt&status_filter=<?php echo urlencode($filter); ?>&page=<?php echo $currentPage-1; ?>">&laquo; Vorherige</a>
            <?php endif; ?>
            Seite <?php echo $currentPage; ?> von <?php echo $totalPages; ?>
            <?php if($currentPage < $totalPages): ?>
                <a href="./?AdminKontakt&status_filter=<?php echo urlencode($filter); ?>&page=<?php echo $currentPage+1; ?>">Nächste &raquo;</a>
            <?php endif; ?>
        </div><br>

        <form method="POST">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Erstellt am</th>
                    <th>Kontakt-Daten</th>
                    <th>Status</th>
                    <th>Kommentar</th>
                    <th>Aktion</th>
                </tr>
            </thead>
            <tbody>
            <?php if(empty($kontakte)): ?>
                <tr><td colspan="6" style="text-align:center;">Keine Kontakte gefunden.</td></tr>
            <?php endif; ?>

            <?php foreach($kontakte as $k): ?>
                <tr>
                    <td><?php echo $k['etchat_id']; ?></td>
                    <td><?php echo $k['etchat_erstellt_am']; ?></td>
                    <td>
                        <?php
                        $data = json_decode($k['etchat_kontakt_daten'], true);
                        if (is_array($data)) {
                            foreach($data as $key => $val) {
                                if(is_array($val)) $val = implode(", ", $val);
                                echo "<strong>".htmlspecialchars($key).":</strong> ".htmlspecialchars($val)."<br>";
                            }
                        } else echo "Keine Daten vorhanden.";
                        ?>
                    </td>
                    <td>
                        <select name="status[<?php echo $k['etchat_id']; ?>]">
                            <?php foreach($this->statusLabels as $key => $label): ?>
                                <option value="<?php echo $key; ?>" <?php if($k['etchat_status'] === $key) echo 'selected'; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <textarea name="kommentar[<?php echo $k['etchat_id']; ?>]"><?php echo htmlspecialchars($k['etchat_kommentar'] ?? ''); ?></textarea>
                    </td>
                    <td>
                        <center>
                            <button type="submit" name="save_kontakt" value="1" class="save-btn">Speichern</button><br><br>
                            <button type="submit" name="delete_kontakt[<?php echo $k['etchat_id']; ?>]" value="1" style="background:red;color:white;" onclick="return confirm('Wirklich löschen?')">Löschen</button>
                        </center>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </form>

        </body>
        </html>
        <?php
    }

    private function saveStatus(array $post): void
    {
        if(!empty($post['status'])){
            foreach($post['status'] as $id => $status){
                $statusEsc = $this->dbObj->escape($status);
                $kommentar = $post['kommentar'][$id] ?? '';
                $kommentarEsc = $this->dbObj->escape($kommentar);

                $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_kontakt
                    SET etchat_status='{$statusEsc}', etchat_kommentar='{$kommentarEsc}'
                    WHERE etchat_id='{$id}'");
            }
        }
        header("Location: ./?AdminKontakt&saved=1");
        exit;
    }

    private function deleteKontakt(array $post): void
    {
        if(!empty($post['delete_kontakt'])){
            foreach($post['delete_kontakt'] as $id => $v){
                $idEsc = (int)$id;
                $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_kontakt WHERE etchat_id={$idEsc}");
            }
        }
        header("Location: ./?AdminKontakt");
        exit;
    }
}
