<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateUserUser extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_user[0];

        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (in_array($role, ["admin", "chatwache", "co_admin"]) && !empty($_POST['id'])) {

            $pass = (!empty($_POST['pw'])) ? "etchat_userpw = '" . md5($_POST['pw']) . "'," : "";

            // Prüfen, ob letzte Admin entfernt wird
            if ($_POST['priv'] == "mod") {
                $res = $this->dbObj->sqlGet("SELECT count(etchat_user_id) FROM {$this->_prefix}etchat_user WHERE etchat_user_id <> " . (int)$_POST['id'] . " AND etchat_userprivilegien = 'admin'");
                if ($res[0][0] == 0) {
                    $this->showError("Not possible. There will be no administrators in chat.", "./?AdminRegUserIndex");
                    return false;
                }
            }

            // Prüfen, ob Username schon existiert
            $res_dop = $this->dbObj->sqlGet("SELECT count(etchat_user_id) FROM {$this->_prefix}etchat_user WHERE etchat_username = '" . htmlspecialchars($_POST['user'], ENT_QUOTES, "UTF-8") . "' AND etchat_userprivilegien <> 'gast' AND etchat_user_id <> " . (int)$_POST['id']);
            if ($res_dop[0][0] > 0) {
                $this->showError("Ein User mit diesem Namen existiert schon.", "./?AdminRegUserIndex");
                return false;
            }

            // Update ausführen
            $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET " . $pass . " etchat_username = '" . htmlspecialchars($_POST['user'], ENT_QUOTES, "UTF-8") . "', etchat_userprivilegien = '" . htmlspecialchars($_POST['priv'], ENT_QUOTES, "UTF-8") . "', etchat_email = '" . htmlspecialchars($_POST['mail'], ENT_QUOTES, "UTF-8") . "' WHERE etchat_user_id=" . (int)$_POST['id']);

            $this->dbObj->close();

            // Weiterleitung nach erfolgreichem Update
            header("Location: ./?AdminRegUserIndex");
            exit;

        } else {
            $this->showError($lang->error[0]->tagData, "./");
            return false;
        }
    }

    /**
     * Fehlermeldung mit CSS ausgeben
     */
    private function showError(string $message, string $backLink)
    {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Adminbereich</title>
            <link href="styles/<?php echo $_SESSION['etchat_'.$this->_prefix.'style']; ?>/style.css" rel="stylesheet" type="text/css"/>
        </head>
        <body id="adminbereich_body">

        <?php
        // Rollenbasierten Link setzen
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $roleLinks = [
            "admin"     => "./?AdminIndex",
            "chatwache" => "./?AdminIndexChatwache",
            "co_admin"  => "./?AdminIndexCoAdmin"
        ];
        $backlinkUrl = $roleLinks[$role] ?? "./";

        echo "<a href=\"$backlinkUrl\">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml;</a><hr size=\"1\">";
        ?>

        <div class="error">
            <?php echo $message; ?><br><br>
            <a href="<?php echo $backLink; ?>">Zur&uuml;ck</a>
        </div>
        </body>
        </html>
        <?php
    }
}

