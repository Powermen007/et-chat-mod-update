<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminBewer extends DbConectionMaker
{
    private array $bewerbungen = [];
    private string $filter = '';
    private int $perPage = 5;

    public function __construct()
    {
        parent::__construct();
        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        if (!isset($this->dbObj)) {
            die("Datenbankverbindung nicht vorhanden!");
        }

        $allowedRoles = ["admin", "co_admin", "chatwache"];
        if (!in_array($_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? '', $allowedRoles)) {
            header("Location: ./");
            exit;
        }

        // POST-Verarbeitung
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['save_bewerbung'])) {
                $this->saveStatus($_POST);
            } elseif (!empty($_POST['delete_bewerbung'])) {
                $this->deleteBewerbung($_POST);
            }
        } else {
            $this->showList();
        }
    }

    private function showList(): void
    {
        $this->filter = $_GET['status_filter'] ?? '';
        $search = $_GET['search'] ?? '';
        $saved = isset($_GET['saved']) ? true : false; // <-- Flag für gespeicherte Daten
        $page = max(1, (int)($_GET['page'] ?? 1));
        $offset = ($page - 1) * $this->perPage;

        $totalAll = $this->dbObj->sqlGet("SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_bewerbungen")[0]['cnt'] ?? 0;

        $sql = "SELECT * FROM {$this->_prefix}etchat_bewerbungen WHERE 1";
        if (!empty($this->filter)) {
            $filterEsc = $this->dbObj->escape($this->filter);
            if (strpos($filterEsc, "'") === false) $filterEsc = "'{$filterEsc}'";
            $sql .= " AND status={$filterEsc}";
        }

        if (!empty($search)) {
            $searchEsc = $this->dbObj->escape('%' . $search . '%');
            if (strpos($searchEsc, "'") === false) $searchEsc = "'{$searchEsc}'";
            $sql .= " AND bewerber_daten LIKE {$searchEsc}";
        }

        $sql .= " ORDER BY erstellt_am DESC LIMIT {$this->perPage} OFFSET {$offset}";

        try {
            $result = $this->dbObj->sqlGet($sql);
            $this->bewerbungen = is_array($result) ? $result : [];
        } catch (PDOException $e) {
            echo "<pre style='color:red;'><strong>SQL-Fehler:</strong> {$e->getMessage()}</pre>";
            echo "<pre><strong>Ausgeführtes SQL:</strong> {$sql}</pre>";
            $this->bewerbungen = [];
        }

        $countSql = "SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_bewerbungen WHERE 1";
        if (!empty($this->filter)) $countSql .= " AND status={$filterEsc}";
        if (!empty($search))  $countSql .= " AND bewerber_daten LIKE {$searchEsc}";

        $totalCount = $this->dbObj->sqlGet($countSql)[0]['cnt'] ?? 0;
        $totalPages = ceil($totalCount / $this->perPage);

        $this->renderHTML($page, $totalPages, $totalAll, $saved);
    }

    private function renderHTML(int $currentPage, int $totalPages, int $totalAll, bool $saved): void
    {
        $filter = $this->filter;
        $bewerbungen = $this->bewerbungen;
        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Bewerbungen Admin</title>
            <link href="styles/<?php echo $_SESSION['etchat_'.$this->_prefix.'style']; ?>/style.css" rel="stylesheet">
            <style>
                table { border-collapse: collapse; width: 100%; }
                th, td { border: 1px solid #ccc; padding: 5px; vertical-align: top; }
                select, textarea { width: 100%; }
                textarea { min-height: 60px; }
                .filter { margin-bottom: 10px; }
                .save-btn { padding: 5px 10px; }
                .success-banner {
                    background-color: #4CAF50;
                    color: white;
                    padding: 10px;
                    position: relative;
                    border-radius: 5px;
                    margin-bottom: 10px;
                }
                .close-btn {
                    position: absolute;
                    right: 10px;
                    top: 5px;
                    cursor: pointer;
                    font-weight: bold;
                }
				.filter {
					display: inline-block; /* oder flex, siehe unten */
					margin-right: 10px;
				}
			</style>
            <script>
                function confirmDelete() {
                    return confirm("Sind Sie sicher, dass Sie diese Bewerbung löschen möchten?");
                }
                function closeBanner() {
                    document.getElementById('successBanner').style.display = 'none';
                }
                window.addEventListener('DOMContentLoaded', function() {
                    let banner = document.getElementById('successBanner');
                    if (banner) {
                        setTimeout(() => banner.style.display = 'none', 5000);
                    }
                });
            </script>
        </head>
        <body id="adminbereich_body">
        <?php
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $roleLinks = [
            "admin"     => "./?AdminIndex",
            "chatwache" => "./?AdminIndexChatwache",
            "co_admin"  => "./?AdminIndexCoAdmin"
        ];
        $backlinkUrl = $roleLinks[$role] ?? "./";
        echo "<a href=\"$backlinkUrl\">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml; </a><hr size=\"1\">";

        if ($role === "admin") {
            echo '<a href="./?AdminBewerform">Bewerbungs Formular bearbeiten</a><br>';
        }

        if ($saved) {
            echo '<br><div class="success-banner" id="successBanner">
                    &Auml;nderungen wurden erfolgreich gespeichert.
                    <span class="close-btn" onclick="closeBanner()">X</span>
                  </div>';
        }
        ?>

        <h2>Alle Bewerbungen<?php echo $filter ? " mit Status '{$filter}'" : ""; ?> (<?php echo $totalAll; ?> insgesamt)</h2>

<div style="display: flex; align-items: center; gap: 10px;">
    <!-- Filter -->
    <form method="GET" action="./?AdminBewer" class="filter">
        <input type="hidden" name="AdminBewer" value="">
        <label style="display:inline-flex; align-items:center; gap:4px; white-space:nowrap;">Status filtern:
            <select name="status_filter" onchange="this.form.submit()">
                <option value="">Alle</option>
                <option value="neu" <?php if($filter==='neu') echo 'selected'; ?>>Neu</option>
                <option value="in Bearbeitung" <?php if($filter==='in Bearbeitung') echo 'selected'; ?>>In Bearbeitung</option>
                <option value="angenommen" <?php if($filter==='angenommen') echo 'selected'; ?>>Angenommen</option>
                <option value="abgelehnt" <?php if($filter==='abgelehnt') echo 'selected'; ?>>Abgelehnt</option>
                <option value="gegangen" <?php if($filter==='gegangen') echo 'selected'; ?>>Gegangen</option>
            </select>
        </label>
    </form>

    <!-- Suche -->
    <form method="GET" action="./?AdminBewer" class="filter">
        <input type="hidden" name="AdminBewer" value="">
        <?php if(!empty($filter)): ?>
            <input type="hidden" name="status_filter" value="<?php echo htmlspecialchars($filter); ?>">
        <?php endif; ?>
        <label>Suche Bewerber:
            <input type="text" name="search" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
        </label>
        <input type="submit" value="🔍">
        <button type="button" onclick="window.location.href='./?AdminBewer'">🔄 Reset</button>
    </form>
</div>

        <!-- Pagination -->
        <div style="margin-top:10px;">
            <?php if($currentPage > 1): ?>
                <a href="./?AdminBewer&status_filter=<?php echo urlencode($filter); ?>&page=<?php echo $currentPage-1; ?>">&laquo; Vorherige</a>
            <?php endif; ?>
            Seite <?php echo $currentPage; ?> von <?php echo $totalPages; ?>
            <?php if($currentPage < $totalPages): ?>
                <a href="./?AdminBewer&status_filter=<?php echo urlencode($filter); ?>&page=<?php echo $currentPage+1; ?>">N&auml;chste &raquo;</a>
            <?php endif; ?>
        </div><br>

        <form method="POST" id="bewerbungenForm">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Erstellt am</th>
                    <th>Bewerber</th>
                    <th>Status</th>
                    <th>Kommentar</th>
                    <th>Aktion</th>
                </tr>
            </thead>
            <tbody>
            <?php if(empty($bewerbungen)): ?>
                <tr>
                    <td colspan="6" style="text-align:center;">Keine Bewerbungen gefunden.</td>
                </tr>
            <?php endif; ?>

            <?php foreach($bewerbungen as $b): ?>
                <tr>
                    <td><?php echo $b['id']; ?></td>
                    <td><?php echo $b['erstellt_am']; ?></td>
                    <td>
                        <?php
                        $data = json_decode($b['bewerber_daten'], true);
                        if (is_array($data)) {
                            foreach($data as $key => $val){
                                if(is_array($val)) $val = implode(", ", $val);
                                echo "<strong>".htmlspecialchars($key).":</strong> ".htmlspecialchars($val)."<br>";
                            }
                        } else {
                            echo "Keine Daten vorhanden.";
                        }
                        ?>
                    </td>
                    <td>
                        <select name="status[<?php echo $b['id']; ?>]">
                            <option value="neu" <?php if($b['status']==='neu') echo 'selected'; ?>>Neu</option>
                            <option value="in Bearbeitung" <?php if($b['status']==='in Bearbeitung') echo 'selected'; ?>>In Bearbeitung</option>
                            <option value="angenommen" <?php if($b['status']==='angenommen') echo 'selected'; ?>>Angenommen</option>
                            <option value="abgelehnt" <?php if($b['status']==='abgelehnt') echo 'selected'; ?>>Abgelehnt</option>
                            <option value="gegangen" <?php if($b['status']==='gegangen') echo 'selected'; ?>>Gegangen</option>
                        </select>
                    </td>
                    <td>
                        <textarea name="kommentar[<?php echo $b['id']; ?>]" style="width:250px; height: 300px;"><?php echo htmlspecialchars($b['kommentar'] ?? ''); ?></textarea>
                    </td>
                    <td>
                        <center>
                            <button type="submit" name="save_bewerbung" value="1" class="save-btn">Speichern</button><br><br>
                            <button type="submit" name="delete_bewerbung[<?php echo $b['id']; ?>]" value="1" class="save-btn" style="background:red;color:white;" onclick="return confirm('Wirklich lÃ¶schen?')">L&ouml;schen</button>
                        </center>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </form>

        </body>
        </html>
        <?php
    }

    private function saveStatus(array $post): void
    {
        if(!empty($post['status'])){
            foreach($post['status'] as $id => $status){
                $statusEsc = $this->dbObj->escape($status);
                $kommentar = $post['kommentar'][$id] ?? '';
                $kommentarEsc = $this->dbObj->escape($kommentar);

                $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_bewerbungen
                    SET status='{$statusEsc}', kommentar='{$kommentarEsc}'
                    WHERE id='{$id}'");
            }
        }
        header("Location: ./?AdminBewer&saved=1"); // Flag setzen
        exit;
    }

    private function deleteBewerbung(array $post): void
    {
        if(!empty($post['delete_bewerbung'])){
            foreach($post['delete_bewerbung'] as $id => $v){
                $idEsc = (int)$id;
                $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_bewerbungen WHERE id={$idEsc}");
            }
        }
        header("Location: ./?AdminBewer");
        exit;
    }
}

