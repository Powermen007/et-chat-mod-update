<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminOnOffSmiliesCat extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();
        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
        header("content-type: text/html; charset=utf-8");
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];
        if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "co_admin"])) {
            if ($_GET["cs4rue"] != $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] || !isset($_GET["cs4rue"]) || !isset($_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"])) {
                echo "Dear Admin this User tried to fake you. ;-)";
                return false;
            }

            $ononoff1 = filter_var($_GET["on_on_off"], FILTER_SANITIZE_STRING);
            $off11 = $ononoff1;
            $off22 = 'off';

           if ($off11 === $off22){
            		$onoffoff = 'on';
            	}
            	else{
            		$onoffoff = "off";
             	}

            $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_smileys_cat SET aktiv = '$onoffoff' WHERE id = ".(int)$_GET["id"]);
            $this->dbObj->close();
            header("Location: ./?AdminSmiliesCatIndex");
        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }
}

?>
