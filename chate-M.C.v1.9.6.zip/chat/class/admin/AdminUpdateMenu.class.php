<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateMenu extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_rooms[0];


		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin" && !empty($_POST['id'])){

				$ueber = $_POST['url'];
				$ueber = addslashes($ueber);

				$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_menu SET menu = '".$_POST['menu']."', link_text = '".$_POST['link_text']."', image_active = '".$_POST['image_active']."', image = '".$_POST['image']."', url = '".$ueber."', target = '".$_POST['target']."', gewicht = '".$_POST['gewicht']."' WHERE id = ".(int)$_POST['id']);

			$this->dbObj->close();
			header("Location: ./?AdminMenusIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
