<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateSmilies extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_smilies[0];

		if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "co_admin"])) {

		// === Kürzel ändern ===
			$res = $this->dbObj->sqlGet("select etchat_smileys_id FROM {$this->_prefix}etchat_smileys where etchat_smileys_sign = '".$_POST['smileys_sing']."'");


				if (is_array($res)){
					$print_smil_edit_1 = "K&uuml;rzel nicht ge&auml;ndert<br>";
				}else{
					$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_smileys SET etchat_smileys_sign = '".$_POST["smileys_sing"]."' WHERE etchat_smileys_id = ".(int)$_POST["id"]);
					$print_smil_edit_1 = "<span class='rot'>K&uuml;rzel ge&auml;ndert</span><br>";
					}

		// === Kategorie ändern ===
		if (!empty($_POST["opfad"]) && $_POST["name"] != $_POST["oname"]) {

		    $oldImgPath = $_POST["opfad"];
		    $filename = basename($oldImgPath);

		    // Zielordner erstellen
		    $newCat = preg_replace('/[^a-zA-Z0-9_-]/', '_', $_POST["name"]);
		    $newFolder = "./smilies/" . $newCat . "/";
		    if (!is_dir($newFolder)) mkdir($newFolder, 0777, true);

		    $targetFile = $newFolder . $filename;

		    // Datei umbenennen, falls schon vorhanden
		    if (file_exists($targetFile)) {
		        $targetFile = $newFolder . time() . "_" . $filename;
		    }

		    // Datei verschieben
		    if (file_exists($oldImgPath)) {
		        if (!rename($oldImgPath, $targetFile)) {
        		    $print_smil_edit_2 = "<span class='rot'>Kategorie ge&auml;ndert, Datei konnte NICHT verschoben werden!</span><br>";
		        } else {
        		    $print_smil_edit_2 = "<span class='rot'>Kategorie ge&auml;ndert und Datei verschoben</span><br>";
		        }
		    } else {
		        $print_smil_edit_2 = "<span class='rot'>Kategorie ge&auml;ndert, alte Datei nicht gefunden</span><br>";
		    }

		    // DB aktualisieren
		    $this->dbObj->sqlSet(
		        "UPDATE {$this->_prefix}etchat_smileys
		         SET etchat_smileys_kat = '" . addslashes($_POST["name"]) . "',
        		     etchat_smileys_img = '" . addslashes($targetFile) . "'
		         WHERE etchat_smileys_id = " . (int)$_POST["id"]
		    );

		} else {
		    $print_smil_edit_2 = "Kategorie nicht ge&auml;ndert<br>";
		}

		// === Gewicht ändern ===
				if ($_POST["gw"] == $_POST["ogw"])	{
					$print_smil_edit_3 = "Gewicht nicht ge&auml;ndert<br>";
				}else{
					$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_smileys SET etchat_smileys_gewicht = '".$_POST["gw"]."' WHERE etchat_smileys_id = ".(int)$_POST["id"]);
					$print_smil_edit_3 = "<span class='rot'>Gewicht ge&auml;ndert</span><br>";
					}
				$this->dbObj->close();

			 $this->initTemplate($lang, $print_smil_edit_1, $print_smil_edit_2, $print_smil_edit_3);
		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}

	    private function initTemplate($lang, $print_smil_edit_1,  $print_smil_edit_2, $print_smil_edit_3)
    {
        include_once "styles/admin_tpl/errorSmileySignExists.tpl.html";
    }

}
?>
