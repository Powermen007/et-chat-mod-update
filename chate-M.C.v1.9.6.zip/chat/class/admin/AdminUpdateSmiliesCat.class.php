<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/


class AdminUpdateSmiliesCat extends DbConectionMaker
{
    public function __construct (){
        parent::__construct();
        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "co_admin"])) {

            $res = $this->dbObj->sqlGet("SELECT id FROM {$this->_prefix}etchat_smileys_cat WHERE name = '".$_POST["name"]."'");

            if (is_array($res)) {
                $print_smil_edit_1 = "Kategorie nicht ge&auml;ndert oder schon vorhanden<br>";
            } else {
                // DB: Kategorie umbenennen
                $this->dbObj->sqlSet("
                    UPDATE {$this->_prefix}etchat_smileys_cat
                    SET name = '" . $_POST["name"] . "'
                    WHERE id = " . (int)$_POST["id"]
                );

                // Zuordnung der Smileys anpassen
                $this->dbObj->sqlSet("
                    UPDATE {$this->_prefix}etchat_smileys
                    SET etchat_smileys_kat = '" . $_POST["name"] . "'
                    WHERE etchat_smileys_kat = '" . $_POST["name_old"] . "'
                ");

                // Bildpfade in DB aktualisieren
                $oldSafe = $this->makeSafeDirName($_POST["name_old"]);
                $newSafe = $this->makeSafeDirName($_POST["name"]);
                $this->dbObj->sqlSet("
                    UPDATE {$this->_prefix}etchat_smileys
                    SET etchat_smileys_img = REPLACE(etchat_smileys_img, './smilies/$oldSafe/', './smilies/$newSafe/')
                    WHERE etchat_smileys_kat = '" . $_POST["name"] . "'
                ");

                $print_smil_edit_1 = "<span class='rot'>Kategorie ge&auml;ndert, die Smileys und Bildpfade wurden angepasst</span><br>";

                // === Ordner im Dateisystem umbenennen ===
                $oldDir = "./smilies/" . $oldSafe;
                $newDir = "./smilies/" . $newSafe;

                if (is_dir($oldDir)) {
                    if (!is_dir($newDir)) {
                        if (@rename($oldDir, $newDir)) {
                            $print_smil_edit_1 .= "<span class='rot'>Ordner wurde auch umbenannt</span><br>";
                        } else {
                            $print_smil_edit_1 .= "<span class='rot'>Fehler: Ordner konnte nicht umbenannt werden!</span><br>";
                        }
                    } else {
                        $print_smil_edit_1 .= "<span class='rot'>Neuer Ordner existiert schon, nicht verschoben!</span><br>";
                    }
                }
            }

            // Gewicht prüfen
            if ($_POST['gw_old'] == $_POST['gw']) {
                $print_smil_edit_2 = "Gewicht nicht ge&auml;ndert<br>";
            } else {
                $this->dbObj->sqlSet("
                    UPDATE {$this->_prefix}etchat_smileys_cat
                    SET gewicht = '" . $_POST["gw"] . "'
                    WHERE id = " . (int)$_POST["id"]
                );
                $print_smil_edit_2 = "<span class='rot'>Gewicht ge&auml;ndert</span><br>";
            }

            $this->dbObj->close();
            $this->initTemplate($lang, $print_smil_edit_1, $print_smil_edit_2);

        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }

    // Hilfsfunktion für sicheren Ordnernamen
    private function makeSafeDirName($name) {
        // Alle nicht-alphanumerischen Zeichen durch "__" ersetzen
        return preg_replace('/[^a-zA-Z0-9]/', '__', $name);
    }

    private function initTemplate($lang, $print_smil_edit_1, $print_smil_edit_2) {
        include_once "styles/admin_tpl/errorSmileyCatExists.tpl.html";
    }
}
?>
