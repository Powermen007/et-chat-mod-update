<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class Colorizer extends EtChatConfig
{

	public $lang;

	public function __construct (){

		parent::__construct();
		
		session_start();
		
		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
	
		$langObj = new LangXml();
		$this->lang=$langObj->getLang()->farben_fenster_php[0];
	
		include_once("./styles/colorizer.tpl.html");
	}
}
