<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class StaticMethods{

	static function filtering($str, $sml, $_prefix){

		$count_all = 0;
		$str = preg_replace('/[\x00-\x1F]/', '', $str);

		for ($a=0; $a<count($sml); $a++){
                 $img = getimagesize("./".$sml[$a][1]);
				 $str = str_replace($sml[$a][0], "<img class=\"img_smiley\" src=\"".$sml[$a][1]."\" ".$img[3]." id=\"smilchat_".$sml[$a][0]."\" style=\"cursor:pointer\">", $str, $count);
				 if ($count>0) $count_all+=$count;
		}

			$max_smilies = (int) ($_SESSION['etchat_'.$_prefix.'chat_anzsmily'] ?? 6);
		if ($count_all > $max_smilies) $str = "Max $max_smilies Smilies erlaubt!";


		if (stripos($str, ']http://')===false &&  stripos($str, ']https://')===false)
				$str = preg_replace("/([\w]+:\/\/[\w\-?&;#~=\.\/\@]+[\w\/])/i","<a target=\"_blank\" href=\"weiterleitung.php?url=$1\">Externer Link</a>",$str);
		else {
				$str = str_replace("http://www.youtube.com/watch?v=", "", $str);
				$str = str_replace("https://www.youtube.com/watch?v=", "", $str);
				$str = preg_replace('/\[pvi\](.*?)\[\/pvi\]/',"&nbsp;&nbsp;<a href=\"$1\" target=\"_blank\"><img class=\"img_chat\" src=\"$1\" alt=\"Bild gepostet\" title=\"Klicken, um das Bild zu vergr&ouml;&szlig;ern.\"/></a>",$str);
		}

		if (!isset($_SESSION['etchat_'.$_prefix.'_badwords']) && file_exists("./lang/bad_words.xml")){
			$xml = @file_get_contents("./lang/bad_words.xml");
			$parser = new AAFParser($xml);
			$parser->Parse();

			foreach($parser->document->word as $bword){

				$exceptions = array();

				if (isset($bword->except) && is_array($bword->except))
					foreach ($bword->except as $except)
						$exceptions[] = $except->tagData;

				$_SESSION['etchat_'.$_prefix.'_badwords'][] = array(
					'in' => chop(trim($bword->tagAttrs['in'])),
					'out' => chop(trim($bword->tagAttrs['out'])),
					'except' => $exceptions
				);
			}
		}

		if (isset($_SESSION['etchat_'.$_prefix.'_badwords'])){

			foreach($_SESSION['etchat_'.$_prefix.'_badwords'] as $key =>$bword){
				if (count($bword['except'])>0)
					foreach($bword['except'] as $key_ex => $ex){
						$str = str_replace($ex, "<norepl>".$ex."</norepl>" , $str);
					}
			}

			foreach($_SESSION['etchat_'.$_prefix.'_badwords'] as $bword){
				$bad_word = $bword['in'];
				$good_word = $bword['out'];

				$pattern = '/(?<!\<norepl\>)'.$bad_word.'(?!\<\/norepl\>)/ui';
				$str = preg_replace($pattern, $good_word, $str);
			}

			$str = str_ireplace("<norepl>", "", $str);
			$str = str_ireplace("</norepl>", "", $str);
		}


		$video =  '<iframe width="425" height="344" src="https://www.youtube-nocookie.com/embed/$1" frameborder="0" allowfullscreen></iframe>';

		if (substr($str, 0, 8)!="/window:"){
			if (stripos($str, '[img]')!==false && stripos($str, '[/img]')!==false){
				$image_path = preg_replace('/\[img\](.*?)\[\/img\]/', '$1', $str);
					if (!empty($image_path) && stripos($str, '?admin')===false)
					$str = preg_replace('/\[img\](.*?)\[\/img\]/', ' <a href="$1" target="_blank"><img class="img_chat" src="$1" alt="Bild gepostet" title="Klicken, um das Bild zu vergrößern."/></a>', $str);
			}
			$str = preg_replace('/\[video\](.*?)\[\/video\]/', $video, $str);
		}

		return $str;
	}
}