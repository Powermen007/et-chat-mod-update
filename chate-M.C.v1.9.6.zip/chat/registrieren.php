<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require __DIR__ . "/config.php";

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
$hosto = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$domain = $protocol . "://" . $hosto . ($scriptDir !== '' && $scriptDir !== '/' ? $scriptDir : '');


// Funktion: Passwortstärke prüfen
function isPasswordStrongEnough($password): bool {
    $criteriaMet = 0;
    $criteriaMet += (int) preg_match("/[A-Z]/", $password);   // Großbuchstaben
    $criteriaMet += (int) preg_match("/[a-z]/", $password);   // Kleinbuchstaben
    $criteriaMet += (int) preg_match("/[0-9]/", $password);   // Zahlen
    $criteriaMet += (int) preg_match("/[\W_]/", $password);   // Sonderzeichen

    return strlen($password) >= 8 && $criteriaMet >= 3;
}

if (
    !file_exists("PHPMailer/src/PHPMailer.php") ||
    !file_exists("PHPMailer/src/SMTP.php") ||
    !file_exists("PHPMailer/src/Exception.php")
) {
    echo "<script>alert('Die PHPMailer-Bibliothek fehlt.\nBitte stellen Sie sicher, dass sie korrekt installiert ist.');</script>";
    die(
        "PHPMailer konnte nicht gefunden werden. Bitte installieren oder Überprüfen Sie die Bibliothek."
    );
}

require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";
require "PHPMailer/src/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$conn = new mysqli($sqlhost, $sqluser, $sqlpass, $database);
if ($conn->connect_error) {
    die("Verbindung zur Datenbank fehlgeschlagen: " . $conn->connect_error);
}
$content = "";
$mode = $_GET["passwort"] ?? "registrieren";
$style = '
<style>
input,
label,
button,
small {
  margin-bottom: 15px;
}
small {
  font-size: 11px;
  color: red;
}
</style>';
ob_start();
switch ($mode) {
    case "vergessen":

        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $username = trim($_POST["username"]);

            $stmt = $conn->prepare("SELECT etchat_user_id, etchat_email FROM {$prefix}etchat_user WHERE etchat_username = ? AND etchat_userprivilegien != 'gast'");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                echo "<h2><font color='#FF0000'><b>Benutzer nicht gefunden.</b></font></h2><br>";
                echo "<button id=\"submit_button\" type=\"button\" onclick=\"window.location.href='$domain'\">Zur&uuml;ck zum Login</button><br><br>";
                break;
            }
            $user = $result->fetch_assoc();
            $email = $user["etchat_email"];
            $userId = $user["etchat_user_id"];
            $token = bin2hex(random_bytes(32)); // ZufÃ¤lliger 64-stelliger Hex-Token
            $expiry = date("Y-m-d H:i:s", strtotime("+15 minutes")); // Ablaufzeit in 15 Minuten

            $stmt = $conn->prepare("UPDATE {$prefix}etchat_user SET etchat_reset_token = ?, etchat_reset_token_expiry = ? WHERE etchat_user_id = ?");
            $stmt->bind_param("ssi", $token, $expiry, $userId);
            $stmt->execute();
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = $host;
                $mail->SMTPAuth = true;
                $mail->Username = $sendemail;
                $mail->Password = $mailpass;
                $mail->SMTPSecure = $smtpsecure;
                $mail->Port = $port;
                $mail->CharSet = "UTF-8";
                $mail->Encoding = "base64";
                $mail->setFrom($sendemail, "Passwort vergessen");
                $mail->addAddress($email, $username);
                $mail->isHTML(true);
                $mail->Subject = "Passwort zurücksetzen";
                $resetLink = "{$domain}/?passwort=zuruecksetzen&token={$token}&user={$username}";
                $mail->Body = "<p>Hallo {$username},</p><p>Hier ist dein Link zum &Auml;ndern deines Passworts:</p><a href='{$resetLink}'>{$resetLink}</a><br>Dieser Aktivierungs-Link ist 15 Minuten g&uuml;ltig.";
                $mail->send();
                $escapedDomain = htmlspecialchars($domain, ENT_QUOTES);
                echo "<script type='text/javascript'> alert('E-Mail wurde versendet.\\nBitte überprüfe dein E-Mail-Postfach.'); window.location.href='{$escapedDomain}';</script>";
            } catch (Exception $e) {
                echo "E-Mail konnte nicht gesendet werden: {$mail->ErrorInfo}";
            }
        }
        echo $style;
        ?>
        <h2>Passwort vergessen</h2>
        <form id="reg" method="POST">
            <input name="username" id="username" placeholder="Dein Chatname" required /><br>
            <button type="submit" id="submit_button">Passwort &Auml;ndern</button>
			<button id="submit_button" type="button" onclick="window.location.href='<?php echo $domain; ?>'">Zur&uuml;ck zum Login</button>
        </form>
        <?php break;
    case "zuruecksetzen":

        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $token = $_POST["token"];
            $newPassword = $_POST["password"];

            // Passwortstärke prüfen
            if (!isPasswordStrongEnough($newPassword)) {
                echo "<script>alert('Fehler: Das Passwort muss mindestens 8 Zeichen lang sein und 3 der folgenden Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.'); window.history.back();</script>";
                exit();
            }

            $stmt = $conn->prepare("SELECT etchat_user_id, etchat_reset_token_expiry FROM {$prefix}etchat_user WHERE etchat_reset_token = ? AND etchat_reset_token_expiry > UTC_TIMESTAMP()");
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                echo "Token Expiry: " .
                    $user["etchat_reset_token_expiry"] .
                    "<br>";
                echo "Current Time: " . date("Y-m-d H:i:s") . "<br>";
                $hashedPassword = md5($newPassword);
                $stmt = $conn->prepare("UPDATE {$prefix}etchat_user SET etchat_userpw = ?, etchat_reset_token = NULL, etchat_reset_token_expiry = NULL WHERE etchat_user_id = ?");
                $stmt->bind_param(
                    "si",
                    $hashedPassword,
                    $user["etchat_user_id"]
                );
                $stmt->execute();
                $escapedDomain = htmlspecialchars($domain, ENT_QUOTES);
                echo "<script>alert('Passwort zurückgesetzt.'); window.location.href='{$escapedDomain}';</script>";
            } else {
                echo "<script>alert('Ungültiger Token oder Token ist abgelaufen.'); window.location.href='{$escapedDomain}';</script>";
            }
        }
        echo $style;
        ?>
			<h2>Passwort zur&uuml;cksetzen</h2>
			<?php if (isset($_GET['user'])): ?>
			    <p style="text-align: center; color: red; font-weight: bold;">Benutzer: <?php echo htmlspecialchars($_GET['user']); ?></p>
			<?php endif; ?>
		<form id="reg" method="POST">
			<input type="hidden" name="token" value="<?php echo htmlspecialchars(
       $_GET["token"]
   ); ?>" />

		   	<p style="text-align: center;margin-top: 0px;">Das Passwort muss mindestens 8 Zeichen lang sein und 3 der folgenden Kriterien enthalten: Gro&szlig;buchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.</p>
			<input name="password" id="password" placeholder="Neues Passwort" required type="password" />
			<small id="pw_strength" style="color: red;"></small><br>
			<input id="confirm_password" name="confirm_password" placeholder="Passwort wiederholen" type="password" required />
			<small id="pwcheck" style="display:none;">Die Passw&ouml;rter stimmen nicht &Uuml;berein.</small>
			<p style="text-align: center;margin-top: 0px;margin-bottom: 0px;"><input type="checkbox" onclick="machText(this.checked,this.form)">Passwort anzeigen</p>
			<button type="submit" id="submit_button">Neues Passwort speichern</button>
			<button id="submit_button" type="button" onclick="window.location.href='<?php echo $domain; ?>'">Zur&uuml;ck zum Login</button>
		</form>
<script>
		document.getElementById("password").addEventListener("input", function() {
		    const pw = this.value;
		    const criteria = [
        		/[A-Z]/.test(pw),
		        /[a-z]/.test(pw),
		        /[0-9]/.test(pw),
		        /[\W_]/.test(pw)
		    ];
		    const strength = criteria.filter(Boolean).length;
		    let msg = "";
		    if (pw.length < 8 || strength < 3) {
        		msg = "Passwort ist zu schwach";
		    }
		    document.getElementById("pw_strength").textContent = msg;
		});

		function checkPasswords() {
		    const e = document.getElementById("password"),
        		n = document.getElementById("confirm_password"),
		        t = document.getElementById("pwcheck");
		    return e.value !== n.value ? (t.style.display = "inline", !1) : (t.style.display = "none", !0)
		}
		document.getElementById("confirm_password").addEventListener("input", (function() {
		    checkPasswords()
		}));

		function machText(chk, frm) {
		    var p = frm.password;
		    var p2 = frm.confirm_password;
		    try {
        		var val1 = p.value;
		        var val2 = p2.value;
        		p.type = chk ? 'text' : 'password';
		        p2.type = chk ? 'text' : 'password';
        		p.value = val1;
		        p2.value = val2;
		    } catch (e) {
        		var neuInp = document.createElement('input');
		        var neuInp2 = document.createElement('input');
        		neuInp.type = chk ? 'text' : 'password';
		        neuInp2.type = chk ? 'text' : 'password';
        		neuInp.value = p.value;
		        neuInp2.value = p2.value;
        		neuInp.name = neuInp.id = 'password';
		        neuInp2.name = neuInp2.id = 'confirm_password';
        		p.parentNode.replaceChild(neuInp, p);
		        p2.parentNode.replaceChild(neuInp2, p2);
		    }
		}
</script>
		<?php break;
    default:

        if (isset($_GET["token"])) {
            $token = $_GET["token"];
			$stmt = $conn->prepare("SELECT etchat_user_id FROM {$prefix}etchat_user WHERE etchat_reset_token = ? AND etchat_reset_token_expiry > NOW() AND etchat_userprivilegien = 'gast'");
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                $stmt = $conn->prepare(
                    "SELECT etchat_user_id FROM {$prefix}etchat_user WHERE etchat_reset_token = ? AND etchat_userprivilegien = 'gast'"
                );
                $stmt->bind_param("s", $token);
                $stmt->execute();
                $expiredResult = $stmt->get_result();
                if ($expiredResult->num_rows > 0) {
                    $expiredUser = $expiredResult->fetch_assoc();
                    $stmt = $conn->prepare(
                        "UPDATE {$prefix}etchat_user SET etchat_reset_token = NULL, etchat_reset_token_expiry = NULL WHERE etchat_user_id = ?"
                    );
                    $stmt->bind_param("i", $expiredUser["etchat_user_id"]);
                    $stmt->execute();
                }
                $escapedDomain = htmlspecialchars($domain, ENT_QUOTES);
                echo "<script>alert('Aktivierungs-Token ungültig oder abgelaufen. Bitte registriere dich erneut.'); window.location.href='{$escapedDomain}';</script>";
                exit();
            }
            $user = $result->fetch_assoc();
            $stmt = $conn->prepare(
                "UPDATE {$prefix}etchat_user SET etchat_userprivilegien = 'user', etchat_reset_token = NULL, etchat_reset_token_expiry = NULL WHERE etchat_user_id = ?"
            );
            $stmt->bind_param("i", $user["etchat_user_id"]);
            $stmt->execute();
            $escapedDomain = htmlspecialchars($domain, ENT_QUOTES);
            echo "<script>alert('Dein Account wurde erfolgreich aktiviert!\\nDu kannst dich jetzt einloggen.'); window.location.href='{$escapedDomain}';</script>";
            exit();
        }
        if (
            $_SERVER["REQUEST_METHOD"] === "POST" &&
            isset($_POST["username"])
        ) {
            $username = trim($_POST["username"]);
            $password = trim($_POST["password"]);
            $confirm_password = trim($_POST["confirm_password"]);
            $email = trim($_POST["email"]);
            $reg_ip = $_SERVER["REMOTE_ADDR"];
            $usersex = "n"; // Falls benötigt, sonst weglassen

			$username = trim($_POST['username'] ?? '');
			if (strlen($username) < 4 || strlen($username) > 25) {
			    echo "<script>alert('Der Benutzername muss zwischen 4 und max. 25 Zeichen lang sein.'); window.history.back();</script>";
			    exit();
			}

			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			    echo "<script>alert('Ungültige E-Mail-Adresse.'); window.history.back();</script>";
			    exit();
			}

            if ($password !== $confirm_password) {
                echo "<script>alert('Die Passwßrter stimmen nicht Überein.'); window.history.back();</script>";
                exit();
            }

            // Passwortstärke prüfen
            if (!isPasswordStrongEnough($password)) {
                echo "<script>alert('Fehler: Das Passwort muss mindestens 8 Zeichen lang sein und 3 der folgenden Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.'); window.history.back();</script>";
                exit();
            }

            $stmt = $conn->prepare(
                "SELECT etchat_user_id, etchat_reset_token_expiry, etchat_userprivilegien FROM {$prefix}etchat_user WHERE etchat_username = ? OR etchat_email = ?"
            );
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $stmt = $conn->prepare(
                "SELECT etchat_user_id, etchat_reset_token_expiry, etchat_userprivilegien FROM {$prefix}etchat_user WHERE etchat_username = ? OR etchat_email = ?"
            );
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();

                // PrÃ¼fen, ob Nutzer kein Gast ist (also schon registriert/aktiviert)
                if ($user["etchat_userprivilegien"] !== "gast") {
                    echo "<script>
		    	        alert('Dieser Benutzername oder diese E-Mail ist bereits registriert und aktiviert.');
		        	    window.history.back();
			        </script>";
                    exit();
                }

                // PrÃ¼fen, ob der Reset-Token noch gÃ¼ltig ist (Token Ablauf in der Zukunft)
                if (strtotime($user["etchat_reset_token_expiry"]) > time()) {
                    echo "<script>
		            alert('Für diese Daten wurde bereits eine Registrierung gestartet.\nBitte bestätige deine E-Mail oder warte, bis der Link abläuft.');
        		    window.history.back();
			        </script>";
                    exit();
                }
            }

            $hashedPassword = md5($password);
            $userprivilegien = "gast";
            $reg_timestamp = date("Y-m-d H:i:s");
            $token = bin2hex(random_bytes(16));
            $token_expiry = date(
                "Y-m-d H:i:s", // Format: Jahr-Monat-Tag Stunde:Minute:Sekunde
                strtotime("+30 minutes") // Zeit in 30 Minuten ab jetzt
            );
            if (
                $result->num_rows > 0 &&
                $user["etchat_userprivilegien"] === "gast"
            ) {
                $user_id = $user["etchat_user_id"];
                $stmt = $conn->prepare(
                    "UPDATE {$prefix}etchat_user
			        SET
			            etchat_userpw=?,
			            etchat_userprivilegien=?,
			            etchat_usersex=?,
			            etchat_email=?,
			            etchat_reg_timestamp=?,
			            etchat_reg_ip=?,
			            etchat_reset_token=?,
			            etchat_reset_token_expiry=?
			        WHERE etchat_user_id=?"
                );
                $stmt->bind_param(
                    "ssssssssi",
                    $hashedPassword,
                    $userprivilegien,
                    $usersex,
                    $email,
                    $reg_timestamp,
                    $reg_ip,
                    $token,
                    $token_expiry,
                    $user_id
                );
                $stmt->execute();
                $infoText = "Gast-Account Ã¼bernehmen.";
            } else {
                $stmt = $conn->prepare(
                    "INSERT INTO {$prefix}etchat_user (
			            etchat_username,
			            etchat_userpw,
            			etchat_userprivilegien,
			            etchat_usersex,
            			etchat_email,
			            etchat_reg_timestamp,
            			etchat_reg_ip,
			            etchat_reset_token,
            			etchat_reset_token_expiry
			        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );

                $stmt->bind_param(
                    "sssssssss", // 9 Parameter, alle Strings
                    $username,
                    $hashedPassword,
                    $userprivilegien,
                    $usersex,
                    $email,
                    $reg_timestamp,
                    $reg_ip,
                    $token,
                    $token_expiry
                );

                $stmt->execute();

                $infoText = "Registrierung erfolgreich!";
            }

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = $host;
                $mail->SMTPAuth = true;
                $mail->Username = $sendemail;
                $mail->Password = $mailpass;
                $mail->SMTPSecure = $smtpsecure;
                $mail->Port = $port;
                $mail->CharSet = "UTF-8";
                $mail->Encoding = "base64";
                $mail->setFrom($sendemail, "Registrierung bestätigend");

                $mail->addAddress($email, $username);
                $mail->isHTML(true);
                $mail->Subject = "Registrierung bestätigend";
                $confirmLink = "{$domain}/?token={$token}";
                $mail->Body = "<p>Hallo {$username},</p><p>Bitte best&auml;tige deine Registrierung:</p><a href='{$confirmLink}'>{$confirmLink}</a><br>Dieser Aktivierungs-Link ist 30 Minuten g&uuml;ltig.<br><br>Sollten sie sich nicht bei uns Registriert haben, k&ouml;nnen sie diese E-Mail ignorieren.<br><br>Nach der Aktivierung sind sie kein Gast mehr und k&ouml;nnen sich mit Ihren<br>Benutzernname : {$username}<br>und Ihren<br>Passwort: {$password}<br>Ein Locken auf<br><a href='{$domain}'>{$domain}</a><br><br>Viel Spa&szlig;";
                $mail->send();
                $escapedDomain = htmlspecialchars($domain, ENT_QUOTES);
                echo "<script>alert('{$infoText}\\nBitte bestätige deine E-Mail-Adresse.'); window.location.href='{$escapedDomain}';</script>";
            } catch (Exception $e) {
                echo "E-Mail konnte nicht gesendet werden: {$mail->ErrorInfo}";
            }
        }
        echo $style;
        ?>

        <h2>Benutzer registrieren</h2>
		<form id="reg" method="POST" onsubmit="return checkPasswords();">
			<input name="username" id="username" placeholder="Dein Chatname min.4 Zeichen max.25" required minlength="4"/>
			<p style="text-align: center;margin-top: 0px;">Das Passwort muss mindestens 8 Zeichen lang sein und 3 der folgenden Kriterien enthalten: Gro&szlig;buchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.</p>
			<input id="password" name="password" placeholder="Dein Passwort" type="password" required />
			<small id="pw_strength" style="color: red;"></small>
			<br>
			<input id="confirm_password" name="confirm_password" placeholder="Passwort wiederholen" type="password" required />
			<small id="pwcheck" style="display:none;">Die Passw&ouml;rter stimmen nicht &Uuml;berein.</small>
			<p style="text-align: center;margin-top: 0px;margin-bottom: 0px;"><input type="checkbox" onclick="machText(this.checked,this.form)">Passwort anzeigen</p>
			<input name="email" id="email" placeholder="E-Mail-Adresse" type="email" required /><br>
			<small id="emailcheck" style="display:none; color:red; text-align:center;">Bitte gib eine g&uuml;ltige E-Mail-Adresse ein.</small><br>
			<button id="submit_button" type="submit">Registrieren</button>
			<button id="submit_button" type="button" onclick="window.location.href='?passwort=vergessen'">Passwort vergessen?</button>
			<button id="submit_button" type="button" onclick="window.location.href='<?php echo $domain; ?>'">Zur&uuml;ck zum Login</button>
		</form>
<script>
		document.getElementById("password").addEventListener("input", function() {
		    const pw = this.value;
		    const criteria = [
        		/[A-Z]/.test(pw),
		        /[a-z]/.test(pw),
		        /[0-9]/.test(pw),
		        /[\W_]/.test(pw)
		    ];
		    const strength = criteria.filter(Boolean).length;
		    let msg = "";
		    if (pw.length < 8 || strength < 3) {
        		msg = "Passwort ist zu schwach";
		    }
		    document.getElementById("pw_strength").textContent = msg;
		});

		function checkPasswords() {
		    const e = document.getElementById("password"),
        		n = document.getElementById("confirm_password"),
		        t = document.getElementById("pwcheck");
		    return e.value !== n.value ? (t.style.display = "inline", !1) : (t.style.display = "none", !0)
		}
		document.getElementById("confirm_password").addEventListener("input", (function() {
		    checkPasswords()
		}));

		function machText(chk, frm) {
		    var p = frm.password;
		    var p2 = frm.confirm_password;
		    try {
        		var val1 = p.value;
		        var val2 = p2.value;
        		p.type = chk ? 'text' : 'password';
		        p2.type = chk ? 'text' : 'password';
        		p.value = val1; // ben�tigt z. B. in Opera
		        p2.value = val2;
		    } catch (e) {
        		var neuInp = document.createElement('input');
		        var neuInp2 = document.createElement('input');
        		neuInp.type = chk ? 'text' : 'password';
		        neuInp2.type = chk ? 'text' : 'password';
        		neuInp.value = p.value;
		        neuInp2.value = p2.value;
        		neuInp.name = neuInp.id = 'password';
		        neuInp2.name = neuInp2.id = 'confirm_password';
        		p.parentNode.replaceChild(neuInp, p);
		        p2.parentNode.replaceChild(neuInp2, p2);
		    }
		}

		document.getElementById("email").addEventListener("input", function () {
		    const emailField = this;
		    const emailCheck = document.getElementById("emailcheck");
		    const email = emailField.value;

		    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		    if (!emailPattern.test(email)) {
        		emailCheck.style.display = "block";
		    } else {
		        emailCheck.style.display = "none";
		    }
		});
</script>
        <?php break;
}
$content = ob_get_clean();
echo $content; ?>

