<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

$GLOBALS["path"] = "./../";

spl_autoload_register(function($class_name) {
		require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class Toolbox extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();
		
		session_start();

		unset($GLOBALS["path"]);

if (isset($_SESSION['etchat_'.$this->_prefix.'user_priv']) && $_SESSION['etchat_'.$this->_prefix.'user_priv'] == "admin"){
	
// Style-Pfade
$style = $_SESSION['etchat_'.$this->_prefix.'style'] ?? 'style_chat';
$css = "../styles/admin_tpl/admin.css";

include('../config.php');

$db = mysqli_connect($sqlhost, $sqluser, $sqlpass, $database);
if (!$db) {
    die("<div style='color:white;'>Verbindung zur Datenbank fehlgeschlagen: " . mysqli_connect_error() . "</div>");
}

$message = '';
$message2 = '';
$message3 = '';

$tabellen = [
    'messages' => [
        'tabelle' => $prefix . 'etchat_messages',
        'id' => 'etchat_id',
        'desc' => 'Nachricht(en)'
    ],
    'smileys' => [
        'tabelle' => $prefix . 'etchat_smileys',
        'id' => 'etchat_smileys_id',
        'desc' => 'Smiley(s)'
    ]
];

function resetAutoIncrementAndSortIDs(mysqli $db, string $table, string $idColumn, string $beschreibung): string {
    $result = mysqli_query($db, "SELECT COUNT(*) FROM `$table`");
    if (!$result) {
        return "Fehler beim Zählen der Einträge: " . mysqli_error($db);
    }

    $anzahl = mysqli_fetch_row($result)[0];

    if ($anzahl > 0) {
        mysqli_query($db, "SET @new_id = 0");
        mysqli_query($db, "UPDATE `$table` SET `$idColumn` = (@new_id := @new_id + 1) ORDER BY `$idColumn`");
        mysqli_query($db, "ALTER TABLE `$table` AUTO_INCREMENT = " . ($anzahl + 1));
    } else {
        mysqli_query($db, "ALTER TABLE `$table` AUTO_INCREMENT = 1");
    }

    return "$anzahl $beschreibung wurden bearbeitet. IDs wurden neu gesetzt.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // IDs neu sortieren
    if (isset($_POST['ids_sortieren']) && isset($tabellen[$_POST['ids_sortieren']])) {
        $t = $tabellen[$_POST['ids_sortieren']];
        $message = resetAutoIncrementAndSortIDs($db, $t['tabelle'], $t['id'], $t['desc']);
    }

    // Themebild-Datei aktualisieren
    if (isset($_POST['update_themenbild'])) {
        $ordnerPfad = '../thema/';
        $bilder = [];

        if ($handle = opendir($ordnerPfad)) {
            while (false !== ($datei = readdir($handle))) {
                if ($datei != '.' && $datei != '..') {
                    if (preg_match('/^(\d+)_/', $datei, $matches)) {
                        $zahl = $matches[1];
                        $bildName = substr($datei, strlen($zahl) + 1);
                        $bilder[$zahl] = $bildName;
                    }
                }
            }
            closedir($handle);
        }

        $phpDateiInhalt = "<?php\n";
        $phpDateiInhalt .= "    // Sendeplan-Themenbild von Chrono © 2025 | Für ET-Chat_T-FISH-MOD\n";
        $phpDateiInhalt .= "    // Bitte hier keine Änderungen vornehmen.\n";
        $phpDateiInhalt .= "    \$bilder = array(\n";
        foreach ($bilder as $thema => $datei) {
            $phpDateiInhalt .= "        \"$thema\" => \"$datei\",\n";
        }
        $phpDateiInhalt .= "    );\n?>";

        $message3 = file_put_contents('themenbild.php', $phpDateiInhalt)
            ? "Die Datei <strong>themenbild.php</strong> wurde erfolgreich aktualisiert!"
            : "Fehler beim Schreiben der Datei <strong>themenbild.php</strong>!";
    }

    // Test-E-Mail senden
    if (isset($_POST['emailtest_senden']) && filter_var($_POST['testemail'], FILTER_VALIDATE_EMAIL)) {
        require '../PHPMailer/src/Exception.php';
        require '../PHPMailer/src/PHPMailer.php';
        require '../PHPMailer/src/SMTP.php';

        $mail = new PHPMailer\PHPMailer\PHPMailer(true);

        try {
            $mail->SMTPDebug = 0;
            $mail->isSMTP();
            $mail->Host = $host;
            $mail->SMTPAuth = true;
            $mail->Username = $sendemail;
            $mail->Password = $mailpass;
            $mail->SMTPSecure = $smtpsecure;
            $mail->Port = $port;

            $mail->setFrom($sendemail, 'Toolbox Test');
            $mail->addAddress($_POST['testemail']);
            $mail->Subject = 'Toolbox E-Mail-Test';
            $mail->Body = 'Dies ist ein erfolgreicher Testversand aus der Toolbox.';

            $mail->send();
            $message4 = 'Test-E-Mail erfolgreich an <strong>' . htmlspecialchars($_POST['testemail']) . '</strong> gesendet!';
        } catch (Exception $e) {
            $message4 = 'Fehler beim E-Mail-Versand: ' . $mail->ErrorInfo;
        }
    }
}

mysqli_close($db);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Toolbox</title>
	
	<link href="<?php echo htmlspecialchars($css); ?>" rel="stylesheet">
	
    <style>
        form {
            background: #2c2c2c;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 20px;
            max-width: 620px;
        }
        input[type="submit"], button {
            padding: 5px 10px;
            margin-top: 10px;
            background: #444;
            color: var(--color-link);
            border: none;
            border-radius: 5px;
        }
        .message {
            margin-top: 20px;
            color: lightgreen;
        }
		textarea {
			width: 98%;
		}
    </style>
</head>
<body id="adminbereich_body">

<div><a href="../?AdminIndex"><<< Zurück zum Adminbereich</a></div>
<hr size="1">

<div style="text-align: center;float:center">
<h2>Toolbox</h2>
<p>Bei Problemen kannst du mir hier gerne eine kurze Nachricht oder Fehlerbericht schicken.</p>
</div>

<div style="float:left; width:500px">
<!-- ID-Zurücksetzen -->
<form method="post">
    <label>Datenbanken-IDs zurücksetzen</label><br>
    <button type="submit" name="ids_sortieren" value="messages">Nachrichten-ID zurücksetzen</button><br>

    <button type="submit" name="ids_sortieren" value="smileys">Smiley-ID zurücksetzen</button>

    <?php if(!empty($message)):?>
        <div class="message"><?= htmlspecialchars($message)?></div>
    <?php endif;?>
</form>

<!-- E-Mail-Test -->
<form method="post">
    <label for="testemail">Teste deine E-Mail-Konfiguration:</label><br>
    <input type="email" name="testemail" style="width: 50%;" required placeholder="z. B. admin@deine-domain.de"><br>
    <input type="submit" name="emailtest_senden" value="Test-E-Mail senden">
    <?php if(!empty($message4)):?>
        <div class="message"><?= $message4 ?></div>
    <?php endif;?>
</form>
<div style="display: inline-block; border: 2px solid red; padding: 4px;">

<h1><center>Beta Testbereich !!</h1></center>

<!-- Themenbilder aktualisieren -->
<form method="post">
    <label>Sendeplan-Themenbilder aktualisieren f&uuml;r WEB-PHP CMS Plugins</label><br>
    <input type="hidden" name="update_themenbild" value="1">
    <input type="submit" value="Themenbilder aktualisieren">
    <?php if(!empty($message3)):?>
        <div class="message"><?= $message3 ?></div>
    <?php endif;?>
</form>
Für die volle Funktion muss die "box_config.php" im Ordner toolbox <br>mit den Daten von "WEB-PHP" Editiert werden.<br>
<a href="../?AdminCSSsIndex&data3=../../toolbox/box_config.php">WEB-PHP-Config Editor</a><br>
<br>Wunschbox Link ist<br>

https://dein Chat.xx/toolbox/wunschbox.php?wunschbox<br>

------------------------------------------------------------------------------------<br>

DJ Box Link ist<br>

https://dein Chat.xx/toolbox/wunschbox.php?djbox<br>

------------------------------------------------------------------------------------<br>

Sendeplan Link ist<br>

https://dein Chat.xx/toolbox/sendeplan.php?sendeplan<br>
</div>
</div>

<!-- Nachricht senden -->
<div style="float:right; width:500px">
<!-- Nachricht senden -->
<form method="post" action="ntfy.php">
    <input type="hidden" name="action" value="textnachricht">
    <label for="nachricht">Nachricht:</label><br>
    <textarea name="nachricht" rows="4" cols="40" required></textarea><br>
    <button type="submit">Absenden</button>
</form>

<!-- Bug-Report senden -->
<form method="post" action="ntfy.php">
    <input type="hidden" name="action" value="bugreport">
    <label for="nachricht">Fehlerbeschreibung:</label><br>
    <textarea name="nachricht" rows="4" cols="40" required></textarea><br>
    <button type="submit">Bug melden</button>
</form>

</div>

<?php

		}else{
			header("Location: ../");
		}


  }}
new Toolbox();
?>
</body>
</html>