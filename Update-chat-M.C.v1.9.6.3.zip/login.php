<!--
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/
	 Loginformular wie bisher -->

    <form id="login" action="">
        <input type="hidden" name="<?php echo $_SESSION[$this->_prefix.'set_check']; ?>" value="<?php echo $this->aktuell_date_u; ?>" />
        <br />
        <input type="text" name="username" id="username" value="" minlength="4" maxlength="25" placeholder="<?php echo $this->lang->name[0]->tagData; ?> min.4 Zeichen max.25" required /> <br />
        <br />
			<div id="lay_pw" style="display: none; position: relative;">
				<input type="password" name="pw" value="" id="pw" placeholder="<?php echo $this->lang->pw[0]->tagData; ?>" />
				<span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; bottom: 6px;" id="togglePassword">👁️</span>
				<span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; display: none; bottom: 6px;" id="togglePasswordOff">🙈</span>
				<br>
			</div>
        <div id="lay_invisible" style="display: none;">
            <input type="checkbox" name="status_invisible" value="1" />
            <?php echo $this->lang->invisible[0]->tagData; ?>
        </div>
        <div id="lay_gender">
<select hidden id="gender" name="gender" size="1">
<input type="radio" name="gender" value="m" id="sex_m" class="gender-input">
<label for="sex_m" class="gender-label"><?php echo $this->lang->sex[1]->tagData; ?></label>
<input type="radio" name="gender" value="f" id="sex_f" class="gender-input">
<label for="sex_f" class="gender-label"><?php echo $this->lang->sex[2]->tagData; ?></label>
<input type="radio" name="gender" value="d" id="sex_d" class="gender-input">
<label for="sex_d" class="gender-label"><?php echo $this->lang->sex[3]->tagData; ?></label><br><br>
<input type="radio" name="gender" value="n" id="sex_n" class="gender-input" checked>
<label for="sex_n" class="gender-label"><?php echo $this->lang->sex[0]->tagData; ?></label>
</select>
            <br />
        </div>
        <br />
        <input type="checkbox" name="privacy_policy" value="true" title="" required />
        <?php echo $this->lang->datenschutz2[0]->tagData; ?>
        <a onclick="self.location.href='#datenschutzbestimmung'"> <?php echo $this->lang->datenschutz1[0]->tagData; ?></a>
        <div class="popup" id="datenschutzbestimmung">
            <div class="popup_text">
                <iframe class="datenschutzbestimmung" src="?Text&id=2" style="position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%);"></iframe>
            </div>
            <a class="popup_close" onclick="self.location.href='#'">X</a>
        </div>
		
		<br>
		sowie die <a onclick="self.location.href='#chatregeln'"> Chatregeln</a> akzeptieren.
		<div class="popup" id="chatregeln">
            <div class="popup_text">
                <iframe class="chatregeln" src="?Text&amp;id=4" style="position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%);"></iframe>
            </div>
            <a class="popup_close" onclick="self.location.href='#'">X</a>
        </div>
		
		
        <br />
        <br />
        <input type="submit" id="submit_button" name="go" value="<?php echo $this->lang->submit[0]->tagData; ?>" />
  		<br />
        <?php if ($_SESSION['etchat_'.$this->_prefix.'reg_an_aus'] == '1') { ?>

        <button type="button" id="submit_button_reg" style="margin: 15px 0;" onclick="window.location.href='?register=1';">Registrieren / Passwort vergessen</button>
        <?php } else { echo '<br/>';} ?>
    </form>
