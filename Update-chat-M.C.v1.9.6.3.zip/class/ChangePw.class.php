<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ChangePw extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);

        if ($userId <= 0) {
            echo "No Session";
            $this->dbObj->close();
            return;
        }

        // Privileg lesen
        $userpriv = $this->dbObj->sqlGet("
            SELECT etchat_userprivilegien
            FROM {$this->_prefix}etchat_user
            WHERE etchat_user_id = {$userId}
        ");

        $priv = $userpriv[0][0] ?? '';

        // Rechte prüfen:
        if (!in_array($priv, ['admin', 'mod', 'user', 'gast'], true)) {
            echo "Permission denied";
            $this->dbObj->close();
            return;
        }

        // ==============================
        // Passwort ändern (normal)
        // ==============================
        if (!empty($_POST['modpw'])) {
            $newPw = trim($_POST['modpw']);

            if (!$this->validatePassword($newPw)) {
                $this->dbObj->close();
                echo "Passwort muss mindestens 8 Zeichen lang sein und 3 der 4 Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.";
                return;
            }

            $hash = password_hash($newPw, PASSWORD_DEFAULT);

            $this->dbObj->sqlSet("
                UPDATE {$this->_prefix}etchat_user
                SET etchat_userpw = '" . $this->dbObj->escape($hash) . "'
                WHERE etchat_user_id = {$userId}
            ");

            echo "1";
            $this->dbObj->close();
            return;
        }

        // ==============================
        // Gast -> interne Registrierung
        // ==============================
        if ($priv === "gast" && !empty($_POST['user_pw'])) {

            // Cookie-Sperre: einmal pro Tag
            if (isset($_COOKIE['cookie_etchat_nik_registered'])) {
                $langObj = new LangXml();
                $lang = $langObj->getLang()->changepw_php[0];
                echo $lang->warning[0]->tagData;
                $this->dbObj->close();
                return;
            }

            $newPw = trim($_POST['user_pw']);

            if (!$this->validatePassword($newPw)) {
                $this->dbObj->close();
                echo "Passwort muss mindestens 8 Zeichen lang sein und 3 der 4 Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.";
                return;
            }

            $hash = password_hash($newPw, PASSWORD_DEFAULT);

            setcookie("cookie_etchat_nik_registered", "1", [
                "expires" => time() + 43200,
                "path" => "/",
                "samesite" => "Lax"
            ]);

            $ip = addslashes($_SERVER['REMOTE_ADDR'] ?? '');

            $this->dbObj->sqlSet("
                UPDATE {$this->_prefix}etchat_user
                SET
                    etchat_userpw = '" . $this->dbObj->escape($hash) . "',
                    etchat_userprivilegien = 'user',
                    etchat_reg_timestamp = NOW(),
                    etchat_reg_ip = '" . $this->dbObj->escape($ip) . "'
                WHERE etchat_user_id = {$userId}
            ");

            echo "1";
            $this->dbObj->close();
            return;
        }

        $this->dbObj->close();
    }

    /**
     * Passwort validieren:
     * - min. 8 Zeichen
     * - mind. 3 von 4 Kriterien: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen
     */
    private function validatePassword(string $password): bool
    {
        if (strlen($password) < 8) {
            return false;
        }

        $criteriaMet = 0;
        $criteriaMet += preg_match('/[A-Z]/', $password) ? 1 : 0;
        $criteriaMet += preg_match('/[a-z]/', $password) ? 1 : 0;
        $criteriaMet += preg_match('/[0-9]/', $password) ? 1 : 0;
        $criteriaMet += preg_match('/[!@#$%^&*()_\-=\[\]{};\'":\\\\|,.<>\/?]/', $password) ? 1 : 0;

        return $criteriaMet >= 3;
    }
}