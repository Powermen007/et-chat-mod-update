<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminPropertyIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Session-Daten aus Config in $_SESSION laden
        $this->configTabData2Session();

        // DB schließen
        $this->dbObj->close();

        // Sprachobjekt laden
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_prop[0] ?? (object)[
            'error' => [(object)['tagData' => 'Zugriff verweigert']]
        ];

        // Benutzerrolle
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        // CSRF Token setzen (nur wenn noch nicht vorhanden)
        $sessionKey = 'etchat_' . $this->_prefix . 'csrf_token';
        if (empty($_SESSION[$sessionKey])) {
            $_SESSION[$sessionKey] = bin2hex(random_bytes(16));
        }
        $csrfToken = $_SESSION[$sessionKey];

        // Styles laden
        $print_styles = '';
        $styleDir = "styles/";
        if (is_dir($styleDir) && ($handle = opendir($styleDir))) {
            while (($file = readdir($handle)) !== false) {
                if ($file === '.' || $file === '..') continue;
                $fullPath = $styleDir . $file;
                if (is_dir($fullPath) && !in_array($file, ["admin_tpl", "install_tpl"], true)) {
                    $selected = ($_SESSION['etchat_'.$this->_prefix.'style'] ?? '') === $file
                        ? ' selected'
                        : '';
                    $safeName = htmlspecialchars($file, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                    $print_styles .= "<option value=\"{$safeName}\"{$selected}>{$safeName}</option>\n";
                }
            }
            closedir($handle);
        }

        // Sprachdateien laden
        $print_lang_files = '';
        $langDir = "lang/";
        if (is_dir($langDir) && ($handle = opendir($langDir))) {
            while (($file = readdir($handle)) !== false) {
                if (is_dir($langDir . $file)) continue;
                if (!str_ends_with($file, '.xml')) continue;
                if (!str_starts_with($file, 'lang_')) continue;

                $langName = $file;
                libxml_use_internal_errors(true);
                $xml = simplexml_load_file($langDir . $file, 'SimpleXMLElement', LIBXML_NOCDATA);
                if ($xml !== false && isset($xml['lang'])) {
                    $langName = (string)$xml['lang'];
                }

                $selected = ($_SESSION['etchat_'.$this->_prefix.'lang_xml_file'] ?? '') === $file
                    ? ' selected'
                    : '';

                $safeFile = htmlspecialchars($file, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                $safeLang = htmlspecialchars($langName, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

                $print_lang_files .= "<option value=\"{$safeFile}\"{$selected}>{$safeLang}</option>";
            }
            closedir($handle);
        }
		
		// Prüfen, ob Erfolgsbanner angezeigt werden soll
		$showBanner = false;
		if (isset($_SESSION['show_success_banner']) && $_SESSION['show_success_banner'] === true) {
			$showBanner = true;
			unset($_SESSION['show_success_banner']); // Zurücksetzen, damit er nicht wieder kommt
		}

        // 🔹 Template laden – auch wenn kein Admin, zeigen wir Fehlermeldung im Template
        if ($role === "admin") {
            include("styles/admin_tpl/indexProperty.tpl.html");
        } elseif ($role === "co_admin") {
            include("styles/admin_tpl/indexPropertyCoAdmin.tpl.html");
        } else {
            // Fehlermeldung im Template anzeigen
            echo $lang->error[0]->tagData;
        }
    }
}