<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateConfigTab extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache sicher laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();

        $lang = $langData->admin[0]->admin_prop[0] ?? (object)[
            'error' => [(object)['tagData' => 'Fehler']]
        ];

        // Token holen
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // 🔐 CSRF prüfen
        if ($token === '' || !$this->isValidCsrfToken($token)) {
            echo htmlspecialchars(($lang->error[0]->tagData ?? 'Fehler') . ' (CSRF)', ENT_QUOTES, 'UTF-8');
            exit;
        }

        // 🔐 Berechtigungs-Check
        $role = (string)($_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '');

        if (!in_array($role, ['admin', 'co_admin'], true)) {
            echo htmlspecialchars($lang->error[0]->tagData ?? 'Fehler', ENT_QUOTES, 'UTF-8');
            exit;
        }

        $updates = [];
        $params  = [];

        // === TEXTFELDER ===
        $textFields = [
            'radio_name'       => 'etchat_config_radio_name',
            'style'            => 'etchat_config_style',
            'lang'             => 'etchat_config_lang',
            'radio_box_li'     => 'etchat_config_radio_box_li',
            'radio_wb_li'      => 'etchat_config_wb_li',
            'list_user_online' => 'etchat_config_user_online',
            'vb'               => 'etchat_config_vollbild',
            'c_admin'          => 'etchat_config_admin_color',
            'c_mod'            => 'etchat_config_mod_color',
            'c_user'           => 'etchat_config_user_color',
            'c_gast'           => 'etchat_config_gast_color',
            'zeit'             => 'etchat_config_time',
            'gender'           => 'etchat_config_chat_gender',
            'privi'            => 'etchat_config_chat_privi',
            'privi_ol'         => 'etchat_config_ol_privi',
            'pic_ben_info'     => 'etchat_config_be_in_pic',
            'pic_chat'         => 'etchat_config_chat_pic',
            'sc'               => 'etchat_config_scroll',
            'radio_dj_box_li'  => 'etchat_config_dj_box_li',
            'radio_sendeplan_li'=> 'etchat_config_radio_se_li'
        ];

        foreach ($textFields as $postKey => $dbField) {
            if (isset($_POST[$postKey])) {
                $updates[] = "$dbField = :$postKey";
                $params[$postKey] = trim((string)$_POST[$postKey]);
            }
        }

        // === ZAHLENFELDER ===
        $intFields = [
            'wartung' => 'etchat_config_wartung',
            'gast_zugang' => 'etchat_config_gast',
            'reg_an_aus' => 'etchat_config_reg_an_aus',
            'reload' => 'etchat_config_reloadsequenz',
            'anz_mess' => 'etchat_config_messages_im_chat',
            'loeschen_nach' => 'etchat_config_loeschen_nach',
            'wu' => 'etchat_config_wu',
            'wuan' => 'etchat_config_wuan',
            'wuza' => 'etchat_config_wuza',
            'wupau' => 'etchat_config_wupau',
            'yo' => 'etchat_config_yo',
            'bi' => 'etchat_config_bi',
            'biup' => 'etchat_config_biup',
            'av' => 'etchat_config_av',
            'pro' => 'etchat_config_pro',
            'online_li' => 'etchat_config_onlie_li',
            'radio_box' => 'etchat_config_radio_box',
            'radio_box_hi' => 'etchat_config_radio_box_hi',
            'radio_wb' => 'etchat_config_wb',
            'name_user_online' => 'etchat_config_name_user',
            'name_user_anz' => 'etchat_config_name_user_anz',
            'chat_anzsmily' => 'etchat_config_chat_anzsmily',
            'radio_dj_box' => 'etchat_config_dj_box',
            'radio_sendeplan' => 'etchat_config_radio_se',
            'reg_user_an' => 'etchat_config_reg_user_an',
            'index_team' => 'etchat_config_index_team',
            'team' => 'etchat_config_team',
            'index_bewer' => 'etchat_config_index_bewer',
            'bewer' => 'etchat_config_bewer',
            'top_user_onoff' => 'etchat_top_user_onoff',
            'top_user' => 'etchat_top_user',
            'tab_away_delay' => 'etchat_tab_away_delay'
        ];

        foreach ($intFields as $postKey => $dbField) {
            if (isset($_POST[$postKey])) {
                $updates[] = "$dbField = :$postKey";
                $params[$postKey] = (int)$_POST[$postKey];
            }
        }

        // === UPDATE ===
        if (!empty($updates)) {
            $sql = "UPDATE {$this->_prefix}etchat_config 
                    SET " . implode(", ", $updates) . " 
                    WHERE etchat_config_id = 1";

            $this->dbObj->sqlSet($sql, $params);
        }

        $this->dbObj->close();
		
		$_SESSION['show_success_banner'] = true;

        header("Location: ./?AdminPropertyIndex");
        exit;
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        return isset($_SESSION[$key]) && hash_equals($_SESSION[$key], $token);
    }
}