<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminLoginBox extends DbConectionMaker
{
	private $message = '';
	
    public function __construct()
    {
        parent::__construct();

        if (session_id() == '') {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0];

        if ($_SESSION['etchat_' . $this->_prefix . 'user_priv'] != "admin") {
            echo "Zugriff verweigert.";
            return false;
        }

		$domain_file = 'cache/loginbox.txt';

		if (isset($_POST['save_domains'])) {
			$domains_raw = $_POST['allowed_domains_list'] ?? '';
			
			$lines = explode("\n", $domains_raw);
			$clean_list = [];

			foreach ($lines as $line) {
				$line = trim($line);
				if (empty($line)) continue;

				$line = preg_replace('~^https?://~i', '', $line);
				$line = explode('/', $line)[0];
				$line = strtolower(trim($line));

				if (!empty($line)) {
					$clean_list[] = $line;
				}
			}

			file_put_contents($domain_file, implode("\n", array_unique($clean_list)));
			
				$this->message = '<div class="success-banner">    
							<span>Gespeichert erfolgreich!</span>
							<span class="close-btn" onclick="closeSuccessBanner()">✖</span>
						</div>';
			
		}

		$current_domains = "";
		if (file_exists($domain_file)) {
			$content = file($domain_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
			$current_domains = implode("\n", $content);
		}

        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
        $chat_url = $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
        
        $chat_url = rtrim($chat_url, '/\\') . '/';

        $this->initTemplate($lang, $chat_url, $current_domains);
    }

    private function initTemplate($lang, $chat_url, $current_domains)
    {
		
		    $message = $this->message;
		
        include_once("styles/admin_tpl/indexLoginBox.tpl.html");
    }
}
?>