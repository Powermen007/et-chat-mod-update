<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminSmiliesCatIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        // 🔐 Zugriff prüfen (unverändert)
        if (!$this->hasAccess()) {
            echo $lang->error[0]->tagData;
            return;
        }

        // 🔐 CSRF bleibt wie er ist (noch NICHT modernisiert!)
        if (empty($_SESSION['etchat_' . $this->_prefix . 'csrf_token'])) {
            $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] = bin2hex(random_bytes(16));
        }
		
		$savedMsg = '';

		if (isset($_GET['saved']) && $_GET['saved'] === '1') {
			$savedMsg = "
				<div id='successBanner' class='success-banner'>
					<span>Reihenfolge gespeichert</span>
					<span class='close-btn' onclick='closeSuccessBanner()'>×</span>
				</div>
			";
		}

        // Kategorien holen (jetzt PDO clean)
        $cats = $this->getCategories();
		$categoryCount = count($cats);
        $print_cat_list = $this->buildCategoryRows($cats, $lang);

        $this->initTemplate($lang, $print_cat_list, $savedMsg, $categoryCount);
    }
	
    private function hasAccess(): bool
    {
		$allowedRoles = ["admin", "co_admin", "grafik"];
		$userRole = isset($_SESSION['etchat_'.$this->_prefix.'user_priv'])
			? (string) $_SESSION['etchat_'.$this->_prefix.'user_priv']
			: '';
        
		if (!in_array($userRole, $allowedRoles, true)) {
			header("Location: ./");
			exit;
		}

		return true;
    }

    /**
     * ✅ PDO prepared (auch wenn keine Parameter → sauber vorbereitet)
     */
    private function getCategories(): array
    {
        $sql = "SELECT id, name, aktiv, gewicht
                FROM {$this->_prefix}etchat_smileys_cat
                ORDER BY gewicht ASC";

        // prepared auch ohne params → einheitlich
        $result = $this->dbObj->sqlGet($sql, []);

        $this->dbObj->close();

        return is_array($result) ? $result : [];
    }

	private function buildCategoryRows(array $cats, $lang): string
	{
		$html = "";
		$i = 0;

		$csrf = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

		foreach ($cats as $row) {
			$i++;

			// 🔐 Daten sauber holen
			$idRaw      = $row["id"] ?? $row[0] ?? 0;
			$nameRaw    = $row["name"] ?? $row[1] ?? '';
			$aktivRaw   = $row["aktiv"] ?? $row[2] ?? 0;
			$gewichtRaw = $row["gewicht"] ?? $row[3] ?? 0;

			// 🔐 Typen fixen
			$id       = (int)$idRaw;
			$currentStatus = ($aktivRaw === 'on') ? 'on' : 'off';
			$newStatus     = ($currentStatus === 'on') ? 'off' : 'on';
			$gewicht  = (int)$gewichtRaw;

			// 🔐 Output vs URL trennen
			$name     = htmlspecialchars((string)$nameRaw, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
			$catUrl   = urlencode($nameRaw);

			$bgclass = ($i % 2 === 0) ? "ungerade" : "gerade";

			$html .= "
				<tr class='{$bgclass}' data-id='{$id}'>
					<td align='center'>
						<img class='img_verschieben' src='./img/verschieben.png' draggable='false'>
					</td>
					<td>{$i}.</td>
					<td>{$name}</td>
					<td>
						<a href='./?AdminRenameSmiliesCat&id={$id}&csrf_token={$csrf}'>
							{$lang->rename[0]->tagData}
						</a>
					</td>
					<td>
						<a href='./?AdminDeleteSmiliesCat&id={$id}&cat={$catUrl}&csrf_token={$csrf}'
						onclick=\"return confirm('Wirklich löschen?\\nEs werden auch alle Smilys aus der Kategorie mit gelöscht');\">
						{$lang->delete[0]->tagData}
						</a>
					</td>
					<td>
						<a href='./?AdminOnOffSmiliesCat&id={$id}&on_on_off={$newStatus}&csrf_token={$csrf}'>
							{$currentStatus}
						</a>
					</td>
					<td>{$gewicht}</td>
				</tr>";
		}

		return $html;
	}

	private function initTemplate($lang, $print_cat_list, $savedMsg, int $categoryCount): void
	{
		$csrf = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];
		$totalCategories = $categoryCount;  // ← zusätzliche Variable
		include_once "styles/admin_tpl/indexSmiliesCat.tpl.html";
	}
}