<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ChangeStatus extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session starten, falls noch nicht
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        // === Systemmeldungen speichern ===
        if (isset($_POST['sys_messages'])) {
            $_SESSION['etchat_' . $this->_prefix . 'sys_messages'] = $_POST['sys_messages'];
            exit;
        }

        // === Session prüfen ===
        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        if ($userId <= 0) {
            exit("Invalid session.");
        }

        // === Input sicher lesen ===
        $img  = $_POST['img']  ?? '';
        $text = $_POST['text'] ?? '';

        $img  = preg_replace("/[^a-zA-Z0-9_\-.]/", "", $img);
        $text = preg_replace('/[\x00-\x1F]/u', '', $text);
        $text = mb_substr($text, 0, 255);

        // === Rechte prüfen ===
        if (!$this->checkRightsOfStatus($img)) {
            exit("Not allowed operation.");
        }

        // Neutraler Status
        if ($img === "status_online") {
            $img = '';
            $text = '';
        }

        // Datei prüfen
        $imgPath = __DIR__ . "/../img/{$img}.png";
        if (!empty($img) && !is_file($imgPath)) {
            $img = '';
            $text = '';
        }

        // DB-escape
        $img  = $this->dbObj->escape($img);
        $text = $this->dbObj->escape($text);

        // === DB Update ===
        $this->dbObj->sqlSet("
            UPDATE {$this->_prefix}etchat_useronline SET
                etchat_user_online_user_status_img = '$img',
                etchat_user_online_user_status_text = '$text'
            WHERE etchat_onlineuser_fid = $userId
        ");

        $this->dbObj->close();

        echo "1";
    }

    /**
     * Prüft, ob der Benutzer die Rechte hat, einen Status zu setzen
     */
    private function checkRightsOfStatus($statusImagename)
    {
        // Gültigkeit des Status-Namens prüfen
        if (substr($statusImagename, 0, 7) !== 'status_') {
            return false;
        }

        // Sprachdatei laden
        $langObj = new LangXml();
        $lang = $langObj->getLang();

        $requiredRights = [];

        // Alle <status>-Einträge mit dem gewünschten Bildnamen prüfen
        foreach ($lang->chat_js[0]->status as $status_value) {
            if ($status_value->tagAttrs['imagename'] == $statusImagename) {
                $right = $status_value->tagAttrs['rights'];

                // "all" bedeutet: jeder darf diesen Status verwenden
                if ($right === 'all') {
                    return true;
                }

                $requiredRights[] = $right;
            }
        }

        // Keine Rechte gefunden ? Status darf jeder verwenden
        if (empty($requiredRights)) {
            return true;
        }

        // Aktuelles Benutzerrecht aus der Session holen
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'];

        // Darf der User einen der erlaubten Werte?
        return in_array($userPriv, $requiredRights);
    }
}