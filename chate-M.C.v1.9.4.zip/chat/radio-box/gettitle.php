<?php
function getStreamTitle($url) {
  $parsed = parse_url($url);
  $host = $parsed['host'] ?? '';
  $port = $parsed['port'] ?? 80;

  // Laut.fm
  if (strpos($host, 'laut.fm') !== false) {
    $path = trim($parsed['path'] ?? '', '/');
    if (!empty($path)) {
      $station = explode('/', $path)[0];
      $lautUrl = "https://api.laut.fm/station/{$station}/current_song";
      $lautJson = @file_get_contents($lautUrl);
      if ($lautJson) {
        $lautData = json_decode($lautJson, true);
        if (isset($lautData['title']) && isset($lautData['artist']['name'])) {
          return $lautData['artist']['name'] . " - " . $lautData['title'];
        }
      }
    }
  }

  // Shoutcast /currentsong
  $shoutcastCurrent = $parsed['scheme'] . "://" . $host . ":" . $port . "/currentsong";
  $title = @file_get_contents($shoutcastCurrent);
  if ($title && strlen(trim($title)) > 0 && stripos($title, 'html') === false) {
    return trim($title);
  }

  // Shoutcast /7.html
  $fp = @fsockopen($host, $port, $errno, $errstr, 1);
  if ($fp) {
    fputs($fp, "GET /7.html HTTP/1.0\r\n");
    fputs($fp, "User-Agent: Mozilla\r\n\r\n");
    $response = '';
    while (!feof($fp)) {
      $response .= fgets($fp, 1024);
    }
    fclose($fp);

    if (preg_match('/<body>(.*?)<\/body>/i', $response, $matches)) {
      $parts = explode(",", $matches[1]);
      if (isset($parts[6]) && trim($parts[6]) !== '-') {
        return trim($parts[6]);
      }
    }
  }

  // Icecast /status-json.xsl
  $statusUrl = $parsed['scheme'] . "://" . $host . ":" . $port . "/status-json.xsl";
  $json = @file_get_contents($statusUrl);
  if ($json) {
    $data = json_decode($json, true);
    if (!empty($data['icestats']['source'])) {
      $source = $data['icestats']['source'];
      if (isset($source['title'])) return $source['title'];
      if (is_array($source)) {
        foreach ($source as $mount) {
          if (isset($mount['title'])) return $mount['title'];
        }
      }
    }
  }

  return "Titel konnte nicht geladen werden";
}

if (isset($_GET['url'])) {
  $streamUrl = urldecode($_GET['url']);
  echo getStreamTitle($streamUrl);
} else {
  echo "Keine Stream-URL angegeben";
}
