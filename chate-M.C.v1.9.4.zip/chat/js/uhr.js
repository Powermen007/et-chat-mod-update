window.setInterval(function () {
  document.getElementById("localtime").innerHTML =
    new Date().toLocaleTimeString()
}, 1000)