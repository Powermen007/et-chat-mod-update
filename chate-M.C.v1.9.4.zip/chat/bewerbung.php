<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// 1. Config laden
require_once __DIR__ . "/config.php";

// 2. Klassen laden
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/Bewerbung.class.php";

// 3. Bewerbung-Objekt
$bewerbung = new Bewerbung();
$style = $bewerbung->getStyleName();
$meldung = '';

// Formularverarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 1) {
    $meldung = $bewerbung->senden($_POST);
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Bewerbung</title>
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style.css" rel="stylesheet">
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style-mobil-index.css" rel="stylesheet">
    <style>
    .bewerbung-form { max-width: 650px; margin: 0 auto; background: rgba(255, 255, 255, 0.17); padding: 20px; border-radius: 8px; }
    .bewerbung-form label { display: block; margin-top: 10px; font-weight: bold; }
    .bewerbung-form input[type="text"], .bewerbung-form input[type="email"], .bewerbung-form select, .bewerbung-form textarea { width: 100%; padding: 8px; margin-top: 4px; border: 1px solid #ccc; border-radius: 6px; }
    .bewerbung-form textarea { min-height: 120px; }
    .musikrichtungen { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 5px; }
    .bewerbung-form button { margin-top: 15px; padding: 10px 20px; background: #0078d7; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
    .bewerbung-form button:hover { background: #005a9e; }
    .captcha-group { display: flex; align-items: center; gap: 10px; }
    .meldung { max-width: 650px; margin: 10px auto; padding: 10px; background: #ff0404d4; border-radius: 6px; text-align: center; }
    .pflichthinweis { color: red; margin-left: 3px; }
    .musikrichtungen {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 5px;
}

.musikrichtung-option label {
    display: flex;
    align-items: center;
    gap: 5px;
}

    </style>
</head>
<body id="body">

    <center><h2>Bewerbung</h2></center>

<?php if ($meldung): ?>
    <div class="meldung"><?php echo htmlspecialchars($meldung); ?></div>
<?php endif; ?>

<form method="POST" action="" class="bewerbung-form">
    <input type="hidden" name="action" value="1">

	    <!-- Hidden-Felder f�r Spam-Schutz -->
	<input type="hidden" name="https_ceck" value="">
	<input type="hidden" name="www" value="">


    Bitte f&uuml;llen Sie die mit <span class="pflichthinweis">*</span> gekennzeichneten Felder aus (Pflichtfelder).

<?php
$fields = $bewerbung->getDb()->sqlGet("
    SELECT *
    FROM {$prefix}etchat_bewerbung_fields
    WHERE etchat_visible=1
    ORDER BY etchat_sort_order ASC
");

foreach ($fields as $f) {
    $rawName = $f['etchat_field_name']; // Originalname aus DB
    $name = preg_replace('/[^a-zA-Z0-9_]/', '_', $rawName); // f�r HTML-Safe Name/ID
    $label = htmlspecialchars($rawName); // f�r Anzeige unver�ndert
    $required = $f['etchat_required'] ? 'required' : '';
    $pflichthinweis = $f['etchat_required'] ? ' <span class="pflichthinweis">*</span>' : '';
    $type = $f['etchat_field_type'] ?? 'text';

    switch ($type) {
        case 'text':
        case 'email':
        case 'date':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<input type='{$type}' name='{$name}' id='{$name}' {$required} value='" . htmlspecialchars($_POST[$name] ?? '') . "'>";
            break;

        case 'textarea':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<textarea name='{$name}' id='{$name}' {$required}>" . htmlspecialchars($_POST[$name] ?? '') . "</textarea>";
            break;

        case 'select':
            $options = json_decode($f['etchat_options'], true) ?: [];
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<select name='{$name}' id='{$name}' {$required}>";
            echo "<option value=''>Bitte ausw&auml;hlen:</option>";
            foreach ($options as $opt) {
                $sel = (($_POST[$name] ?? '') == $opt) ? 'selected' : '';
                echo "<option value='{$opt}' {$sel}>{$opt}</option>";
            }
            echo "</select>";
            break;

        case 'checkbox':
            $options = json_decode($f['etchat_options'], true) ?: [];
            echo "<label>{$label}:{$pflichthinweis}</label>";
            echo '<div class="musikrichtungen">';
            foreach ($options as $opt) {
                $chk = in_array($opt, $_POST[$name] ?? []) ? 'checked' : '';
                echo '<div class="musikrichtung-option">';
                echo "<label><input type='checkbox' name='{$name}[]' value='{$opt}' $chk> $opt</label>";
                echo '</div>';
            }
            echo '</div>';
            break;
    }
}


?>

        <label for="web_php_de">Bitte geben Sie die Zeichen ein:<span class="pflichthinweis">*</span></label>
    <div class="captcha-group">
        <img src="captcha.php" alt="Captcha">
        <input type="text" name="web_php_de" id="web_php_de" maxlength="5" required>
    </div>

    <button type="submit">Anfrage senden</button>
</form>

</body>
</html>