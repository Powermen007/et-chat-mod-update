<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class CompactModView extends DbConectionMaker
{
    public array $rolesFound = [];  // <--- NEU: hier sammeln wir die Rollen

    protected $roleNames = [
        'admin'     => 'Administrator',
        'co_admin'  => 'Co-Administrator',
        'mod'       => 'Moderator',
        'chatwache' => 'Chatwache',
        'grafik'    => 'Grafiker',
        'user'      => 'Benutzer'
    ];

    public function __construct() {
        parent::__construct();

        // --- 1. Config auslesen: Farben + Style ---
        $config = $this->dbObj->sqlGet("
            SELECT etchat_config_admin_color, etchat_config_mod_color, etchat_config_user_color, etchat_config_style
            FROM {$this->_prefix}etchat_config
            WHERE etchat_config_id = '1'
        ");

        $adminc = $config[0][0] ?? '#FF0000';
        $modc   = $config[0][1] ?? '#00AAFF';
        $userc  = $config[0][2] ?? '#CCCCCC';
        $styleName = $config[0][3] ?? 'default';

        echo '<link href="styles/' . htmlspecialchars($styleName) . '/style.css" rel="stylesheet">';
        echo '<link href="styles/' . htmlspecialchars($styleName) . '/style-mobil-index.css" rel="stylesheet">';

        // --- 2. User holen ---
        $users = $this->dbObj->sqlGet("
            SELECT etchat_username, etchat_userprivilegien, etchat_reg_timestamp, etchat_usersex,
                   etchat_avatar, etchat_email, etchat_geb_tag, etchat_geb_monat, etchat_geb_jahr,
                   etchat_ort, etchat_beschreibung
            FROM {$this->_prefix}etchat_user
            WHERE etchat_userprivilegien IN ('admin','co_admin','mod','chatwache','grafik')
            ORDER BY etchat_user_id DESC
        ");

        $this->dbObj->close();

        // --- 3. Grid starten ---
        echo '<div class="compact-mod-row">';

        if (is_array($users)) {
            foreach ($users as $user) {
                $role = $user[1];

                // Rolle merken:
                $this->rolesFound[$role] = true;

                // Farben usw.
                $colors = [
                    'admin'     => $adminc,
                    'co_admin'  => $adminc,
                    'mod'       => $modc,
                    'chatwache' => $adminc,
                    'grafik'    => $adminc,
                    'user'      => $userc
                ];

                $color    = $colors[$role] ?? '#CCCCCC';
                $roleName = $this->roleNames[$role] ?? ucfirst($role);
                $regDate  = date('d.m.Y', strtotime($user[2]));

                $gender = match($user[3]) {
                    'm' => 'M&auml;nnlich',
                    'f' => 'Weiblich',
                    'n' => 'keine Angabe',
                    'd' => 'Divers',
                    default => ''
                };

                // Geburtstag / Alter berechnen (wie gehabt)
                $birth = '';
                $today = new DateTime('today');
                if (!empty($user[6]) && !empty($user[7]) && !empty($user[8])) {
                    $birthDate = sprintf("%04d-%02d-%02d", $user[8], $user[7], $user[6]);
                    $birthFormatted = sprintf("%02d.%02d.%04d", $user[6], $user[7], $user[8]);
                    $birthDateObj = new DateTime($birthDate);
                    $age = $birthDateObj->diff($today)->y;
                    $isBirthday = ($today->format('d') == $user[6] && $today->format('m') == $user[7]);
                    if ($isBirthday) {
                        $birth = "<span style='color:red; font-weight:bold;'>{$birthFormatted} ({$age})
                                  <img src=\"img/cake.png\" alt=\"Geburtstag\" style=\"width:16px; height:16px; vertical-align:middle;\"></span>";
                    } else {
                        $birth = "{$birthFormatted} ({$age})";
                    }
                } elseif (!empty($user[6]) && !empty($user[7])) {
                    $birthFormatted = sprintf("%02d.%02d.", $user[6], $user[7]);
                    $isBirthday = ($today->format('d') == $user[6] && $today->format('m') == $user[7]);
                    if ($isBirthday) {
                        $birth = "<span style='color:red; font-weight:bold;'>{$birthFormatted}
                                  <img src=\"img/cake.png\" alt=\"Geburtstag\" style=\"width:16px; height:16px; vertical-align:middle;\"></span>";
                    } else {
                        $birth = $birthFormatted;
                    }
                }

                $username     = htmlspecialchars($user[0]);
                $email        = htmlspecialchars($user[5]);
                $emailk       = mb_strimwidth($email, 0, 15, " ....");
                $ort          = $user[9] ? htmlspecialchars($user[9]) : '-';
                $beschreibung = $user[10] ? htmlspecialchars($user[10]) : '-';
                $beschreibung = nl2br($beschreibung);

                $maxLength = 40;
                if (mb_strlen(strip_tags($beschreibung)) > $maxLength) {
                    $shortDesc = mb_substr(strip_tags($beschreibung), 0, $maxLength);
                    $shortDesc = nl2br($shortDesc);
                    $beschreibungHTML = <<<HTML
<div class="beschreibung-full" data-short="{$shortDesc}" data-full="{$beschreibung}">
    {$shortDesc}... <a href="#" class="toggle-full">mehr</a>
</div>
HTML;
                } else {
                    $beschreibungHTML = "<div class='beschreibung-full'>{$beschreibung}</div>";
                }

                echo <<<HTML
<div class="compact-mod-card" data-role="{$role}" style="border-color:{$color}">
    <div class="top-row">
        <div class="avatar-mod">
            <img src="avatar/{$user[4]}" alt="{$username}">
        </div>
        <div class="modinfo">
            <strong>{$username}</strong><br>
            Rolle: {$roleName}<br>
            Geschlecht: {$gender}<br>
            Registriert: {$regDate}<br>
            Geburtstag: {$birth}<br>
            Ort: {$ort}<br>
            Email: <a href="mailto:{$email}">{$emailk}</a><br>
        </div>
    </div>
    {$beschreibungHTML}
</div>
HTML;
            }
        }

        echo '</div>'; // Grid Ende
    }
}
