<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Erg�nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

require_once __DIR__ . '/ConnectDB.class.php';
require_once __DIR__ . '/DbConectionMaker.class.php';

require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Bewerbung extends DbConectionMaker
{
    protected string $styleName;

    public function __construct() {
        parent::__construct();

        $config = $this->dbObj->sqlGet("
            SELECT etchat_config_style
            FROM {$this->_prefix}etchat_config
            WHERE etchat_config_id = 1
        ");

        $this->styleName = $config[0][0] ?? 'default';
    }

    public function getStyleName(): string {
        return $this->styleName;
    }

    // NEU: DB Getter
    public function getDb(): ConnectDB {
        return $this->dbObj;
    }

    public function senden(array $daten): string {
        // Spam-Felder
        if (!empty($daten['https_ceck']) || !empty($daten['www'])) {
            return "Spam erkannt!";
        }

        // Captcha pr�fen
        if (!isset($_SESSION['captcha_text']) || strtolower($daten['web_php_de']) !== strtolower($_SESSION['captcha_text'])) {
            return "Falsches Captcha! Bitte erneut versuchen.";
        }

// --- Bewerbung in DB speichern ---
$saveData = $daten;
unset($saveData['https_ceck'], $saveData['www'], $saveData['web_php_de'], $saveData['action']);

// JSON kodieren
$jsonData = $this->dbObj->escape(json_encode($saveData, JSON_UNESCAPED_UNICODE));

$this->dbObj->sqlSet("
    INSERT INTO {$this->_prefix}etchat_bewerbungen (bewerber_daten, status)
    VALUES ('{$jsonData}', 'neu')
");



        global $host, $sendemail, $mailpass, $smtpsecure, $port;

        try {
            // --- Mail an Admin ---
            $mailAdmin = new PHPMailer(true);
            $mailAdmin->CharSet = 'UTF-8';
            $mailAdmin->Encoding = 'base64';
            $mailAdmin->isSMTP();
            $mailAdmin->Host       = $host;
            $mailAdmin->SMTPAuth   = true;
            $mailAdmin->Username   = $sendemail;
            $mailAdmin->Password   = $mailpass;
            $mailAdmin->SMTPSecure = $smtpsecure;
            $mailAdmin->Port       = $port;

            $mailAdmin->setFrom($sendemail, 'Chat Bewerbungformular');
            $mailAdmin->addAddress($sendemail);

            // Betreff aus Formular
            $betreff = $daten['Betreff'] ?? 'Unbekannte Bewerbung';
            $mailAdmin->Subject = "Neue Bewerbung: {$betreff}";

$fixedOrder = ['Betreff', 'Anrede', 'Name', 'Modiename']; // gew�nschte Reihenfolge

$message = "<h2>Neue Bewerbung eingegangen</h2><table>";

// 1. Feste Felder in gew�nschter Reihenfolge
foreach ($fixedOrder as $field) {
    if (!empty($daten[$field])) {
        $message .= "<tr><td><strong>{$field}:</strong></td><td>" . htmlspecialchars($daten[$field]) . "</td></tr>";
    }
}

// 2. Restliche Felder automatisch
$skip = array_merge($fixedOrder, ['https_ceck','www','web_php_de','action']);
foreach ($daten as $key => $val) {
    if (in_array($key, $skip)) continue;
    if (is_array($val)) $val = implode(", ", $val);
    $message .= "<tr><td><strong>{$key}:</strong></td><td>" . htmlspecialchars($val) . "</td></tr>";
}

$message .= "</table>";


            $mailAdmin->Body = $message;
            $mailAdmin->AltBody = strip_tags($message);
            $mailAdmin->send();

            // --- Best�tigungsmail an Bewerber ---
            if (!empty($daten['E_Mail'])) {
                $mailBewerber = new PHPMailer(true);
                $mailBewerber->CharSet = 'UTF-8';
                $mailBewerber->Encoding = 'base64';
                $mailBewerber->isSMTP();
                $mailBewerber->Host       = $host;
                $mailBewerber->SMTPAuth   = true;
                $mailBewerber->Username   = $sendemail;
                $mailBewerber->Password   = $mailpass;
                $mailBewerber->SMTPSecure = $smtpsecure;
                $mailBewerber->Port       = $port;

                $mailBewerber->setFrom($sendemail, 'Chat Bewerbungformular');
                $mailBewerber->addAddress($daten['E_Mail'], $daten['Name'] ?? 'Bewerber');
                $mailBewerber->Subject = "Ihre Bewerbung: {$betreff}";

                $bestaetigung = "Hallo " . ($daten['Name'] ?? '') . ",\n\n"
                    . "vielen Dank f&uuml;r Ihre Bewerbung als " . $betreff . ".\n"
                    . "Wir haben Ihre Bewerbung erhalten und melden uns zeitnah bei Ihnen.\n\n"
                    . "Viele Gr&uuml;&szlig;e\nDas Team";

                $mailBewerber->isHTML(true);
                $mailBewerber->Body = nl2br($bestaetigung);
                $mailBewerber->AltBody = html_entity_decode($bestaetigung, ENT_QUOTES | ENT_HTML5, 'UTF-8');

                $mailBewerber->send();
            }

            return "Bewerbung erfolgreich gesendet!";

        } catch (Exception $e) {
            return "Fehler beim Versenden: " . $e->getMessage();
        }
    }
}