<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminWunschboxConfig extends DbConectionMaker
{
    private string $csrfToken = '';
    private object $lang;
    private string $userRole = '';
    private array $config = [];
    private string $message = '';
    private bool $saved = false;
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        
        $this->lang = new LangJson('', 'wb_sendeplan_admin.json');
        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
        
        // 🔥 NUR Admin und Co-Admin
        $allowedRoles = ['admin', 'co_admin'];
        if (!in_array($this->userRole, $allowedRoles, true)) {
            header('Location: ./');
            exit;
        }
        
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
        
        $this->loadConfig();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        } else {
            $this->showConfig();
        }
    }
    
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_wunschbox_config"
        );
        
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
private function handlePost(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($this->csrfToken, $token)) {
        http_response_code(403);
        exit($this->lang->get('admin_kontakt_error_csrf', 'Ungültiger CSRF Token'));
    }
    
    // 🔥 NEU: Alle Config-Keys (inkl. Audio)
    $configs = [
        'mod_can_delete',
        'mod_can_see_all',
        'rate_limit_seconds',
        'admin_refresh_seconds',
        'auto_delete_enabled',
        'auto_delete_after_days',
        'wunschbox_cleanup_hours',
        // 🔥 NEU: Audio-Wünsche
        'wunschbox_audio_enabled',
        'wunschbox_audio_max_seconds',
        'wunschbox_audio_max_size',
    ];
    
    foreach ($configs as $key) {
        $value = $_POST[$key] ?? '';
        
        // Checkboxen
        if ($key === 'auto_delete_enabled' || $key === 'wunschbox_audio_enabled') {
            $value = isset($_POST[$key]) ? '1' : '0';
        }
        
        // Zahlen mit Grenzen
        if ($key === 'rate_limit_seconds' || $key === 'admin_refresh_seconds') {
            $value = (int)$value;
            if ($value < 5) $value = 5;
            if ($value > 3600) $value = 3600;
        }
        
        if ($key === 'auto_delete_after_days') {
            $value = (int)$value;
            if ($value < 1) $value = 1;
            if ($value > 365) $value = 365;
        }
        
        if ($key === 'wunschbox_cleanup_hours') {
            $value = (int)$value;
            if ($value < 1) $value = 1;
            if ($value > 24) $value = 24;
        }
        
        // 🔥 NEU: Audio-Zahlen
        if ($key === 'wunschbox_audio_max_seconds') {
            $value = (int)$value;
            if ($value < 5) $value = 5;
            if ($value > 300) $value = 300;
        }
        
        if ($key === 'wunschbox_audio_max_size') {
            $value = (int)$value;
            if ($value < 1) $value = 1;
            if ($value > 50) $value = 50;
        }
        
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_wunschbox_config 
             SET config_value = :value 
             WHERE config_key = :key",
            [':value' => (string)$value, ':key' => $key]
        );
    }
    
    $this->saved = true;
    $this->message = $this->lang->get('admin_wunschbox_config_saved', 'Einstellungen wurden erfolgreich gespeichert!');
    $this->loadConfig();
    $this->showConfig();
}
    
    private function showConfig(): void
    {
        $config = $this->config;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;
        $userRole = $this->userRole;
        $saved = $this->saved;
        $message = $this->message;
        
        include "styles/admin_tpl/indexWunschboxConfig.tpl.html";
    }
}