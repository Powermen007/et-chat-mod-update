<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.

SEO-Helper – zentrale Klasse für Canonical, Description, Robots-Meta.
Ermittelt die Basis-URL und den Basispfad automatisch – keine manuelle Anpassung nötig.
*/

class SeoHelper
{
    /**
     * Basis-URL – dynamisch, funktioniert bei jeder Installation.
     * Erkennt HTTP/HTTPS automatisch, nutzt den aktuellen Host.
     */
    public static function baseUrl(): string
    {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return $scheme . '://' . $host;
    }

    /**
     * Ermittelt automatisch den Basispfad des Chats.
     * Beispiel: "/Chat", "/meinchat", "" (wenn direkt im Root).
     *
     * Nutzt SCRIPT_NAME – das ist immer der Pfad der aktuell ausgeführten Datei,
     * unabhängig davon, wie die URL aussieht (durch .htaccess-Rewrite).
     */
    public static function basePath(): string
    {
        $script = $_SERVER['SCRIPT_NAME'] ?? '';

        // Dateinamen abschneiden → Verzeichnis
        $dir = str_replace('\\', '/', dirname($script));
        $dir = rtrim($dir, '/');

        // Bei Aufruf direkt aus dem Root: dirname gibt "." oder "/" zurück
        if ($dir === '.' || $dir === '') {
            return '';
        }

        return $dir;
    }

    /**
     * Baut eine absolute Canonical-URL.
     *
     * @param string $path Relativer Pfad, z. B. 'impressum' oder '' (Startseite)
     */
    public static function canonical(string $path = ''): string
    {
        $base = self::baseUrl() . self::basePath();

        // Startseite: mit Trailing Slash
        if ($path === '' || $path === '/') {
            return $base . '/';
        }

        return $base . '/' . ltrim($path, '/');
    }

    /**
     * Erzeugt den kompletten SEO-Head-Block (Canonical, Robots, Description).
     *
     * @param string $path        Relativer Pfad, z. B. 'impressum'
     * @param string $description Meta-Description (leer = wird weggelassen)
     * @param string $robots      'index, follow' (Standard) oder 'noindex, nofollow'
     * @return string             HTML-Zeilen (mit \n getrennt)
     */
    public static function head(
        string $path,
        string $description = '',
        string $robots = 'index, follow'
    ): string {
        $canonical = self::canonical($path);

        $html  = '    <link rel="canonical" href="' . htmlspecialchars($canonical, ENT_QUOTES, 'UTF-8') . '">' . "\n";
        $html .= '    <meta name="robots" content="' . htmlspecialchars($robots, ENT_QUOTES, 'UTF-8') . '">' . "\n";

        if ($description !== '') {
            $html .= '    <meta name="description" content="'
                  . htmlspecialchars($description, ENT_QUOTES, 'UTF-8')
                  . '">' . "\n";
        }

        return $html;
    }

    /**
     * Erzeugt eine Description aus beliebigem HTML-Text.
     * Entfernt Tags, normalisiert Whitespace, kürzt auf $maxLength Zeichen.
     */
    public static function makeDescription(string $html, int $maxLength = 160): string
    {
        $text = strip_tags($html);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\s+/', ' ', $text);
        $text = trim($text);

        if (mb_strlen($text, 'UTF-8') <= $maxLength) {
            return $text;
        }

        return mb_substr($text, 0, $maxLength - 3, 'UTF-8') . '...';
    }
}