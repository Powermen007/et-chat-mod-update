<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.

ZugriffsGuard - Zentrale Zugriffskontrolle für sensible Klassen und PHP-Dateien.
Schützt vor Direktaufruf im Browser - erlaubt nur Aufrufe aus dem Chat selbst
oder von Domains, die in cache/loginbox.txt oder cache/onlineliste.txt stehen.

WICHTIG: Diese Klasse erbt NICHT von DbConectionMaker, damit sie
          überall funktioniert, ohne dass der Autoloader registriert sein muss.

Verwendung:
    new ZugriffsGuard();          // Direktaufruf verboten (Standard)
    new ZugriffsGuard(true);      // Direktaufruf erlaubt (Sonderfälle)

Verhalten:
    - Admin eingeloggt           -> immer erlaubt (Notausgang)
    - Referer = eigene Domain    -> erlaubt
    - Referer in einer der TXT   -> erlaubt (mit Subdomain-Regel, www egal)
    - Kein Referer (direkt)      -> nur erlaubt wenn $allowDirect = true
    - Alles andere               -> Weiterleitung zur Startseite
*/

declare(strict_types=1);

class ZugriffsGuard
{
    /** @var string Host des Referers (normalisiert, ohne www.) */
    private string $refererHost = '';

    /** @var string Eigene Domain (HTTP_HOST, normalisiert, ohne www.) */
    private string $ownHost = '';

    /** @var array Erlaubte Domains aus beiden TXT-Dateien */
    private array $allowedDomains = [];

    /** @var bool Ist der aktuelle User Admin? */
    private bool $isAdmin = false;

    /** @var bool Direktaufruf erlaubt? */
    private bool $allowDirect = false;

    public function __construct(bool $allowDirect = false)
    {
        $this->allowDirect = $allowDirect;

        // ===== SESSION SICHERSTELLEN =====
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        // ===== SPRACHE LADEN (optional, darf fehlschlagen) =====
        $lang = null;
        if (class_exists('LangJson')) {
            try {
                $lang = new LangJson();
            } catch (Throwable $e) {
                $lang = null;
            }
        }

        // ===== PRÜFUNGEN =====
        $this->detectAdmin();
        $this->checkHosts();
        $this->loadAllowedDomains();

        // ===== ENTSCHEIDUNG =====
        if ($this->isAllowed()) {
            return;
        }

        // Zugriff verweigert -> Weiterleitung
        $this->redirectToHome($lang);
    }

    /* =========================================================
     *  PRÜFLOGIK
     * ========================================================= */

    private function detectAdmin(): void
    {
        foreach ($_SESSION as $key => $value) {
            if (strpos($key, 'etchat_') === 0
                && strpos($key, '_user_priv') !== false
                && $value === 'admin') {
                $this->isAdmin = true;
                return;
            }
        }
    }

    private function checkHosts(): void
    {
        // Eigene Domain
        $own = strtolower($_SERVER['HTTP_HOST'] ?? '');
        if (strpos($own, 'www.') === 0) {
            $own = substr($own, 4);
        }
        $this->ownHost = $own;

        // Referer-Host
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        if ($referer === '') {
            $this->refererHost = '';
            return;
        }

        $ref = strtolower((string)parse_url($referer, PHP_URL_HOST));
        if (strpos($ref, 'www.') === 0) {
            $ref = substr($ref, 4);
        }
        $this->refererHost = $ref;
    }

    private function loadAllowedDomains(): void
    {
        // Wir suchen die TXT-Dateien an mehreren möglichen Stellen
        // -> funktioniert je nach Aufrufkontext (Root, class/, radio-box/)
        $basePaths = [
            '.',              // Root
            '..',             // eine Ebene höher
            dirname(__DIR__)  // Parent-Verzeichnis von class/
        ];

        $files = [];
        foreach ($basePaths as $base) {
            $files[] = $base . '/cache/loginbox.txt';
            $files[] = $base . '/cache/onlineliste.txt';
            $files[] = $base . '/loginbox.txt';
            $files[] = $base . '/onlineliste.txt';
        }

        $seen = [];

        foreach ($files as $file) {
            if (!file_exists($file)) {
                continue;
            }

            $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if ($lines === false) {
                continue;
            }

            foreach ($lines as $line) {
                $clean = preg_replace('/[^a-zA-Z0-9\.\-]/', '', $line);
                if ($clean === '') {
                    continue;
                }
                $clean = strtolower($clean);
                if (strpos($clean, 'www.') === 0) {
                    $clean = substr($clean, 4);
                }
                if (!isset($seen[$clean])) {
                    $seen[$clean] = true;
                    $this->allowedDomains[] = $clean;
                }
            }
        }
    }

    private function isAllowed(): bool
    {
        // 1) Admin -> immer erlaubt
        if ($this->isAdmin) {
            return true;
        }

        // 2) Kein Referer -> direkter Aufruf
        if ($this->refererHost === '') {
            return $this->allowDirect;
        }

        // 3) Referer = eigene Domain -> erlaubt
        if ($this->ownHost !== '' && $this->refererHost === $this->ownHost) {
            return true;
        }

        // 4) In einer der TXT-Dateien? (Subdomain-Regel)
        foreach ($this->allowedDomains as $allowed) {
            if ($this->refererHost === $allowed) {
                return true;
            }
            if (strlen($this->refererHost) > strlen($allowed)
                && substr($this->refererHost, -(strlen($allowed) + 1)) === '.' . $allowed) {
                return true;
            }
        }

        // 5) Nichts passt -> verweigern
        return false;
    }

    /* =========================================================
     *  VERWEIGERUNG: Weiterleitung zur Startseite
     * ========================================================= */

    private function redirectToHome($lang): void
    {
        // Startseite ermitteln
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
        $homeUrl  = $protocol . ($_SERVER['HTTP_HOST'] ?? '') . '/';

        // Sprache mit Fallback (wie überall im System)
        // -> Wenn Key in JSON existiert: wird genutzt (auch wenn leer!)
        // -> Wenn Key fehlt: deutscher Fallback
        $title = 'Weiterleitung';
        $text  = 'Diese Seite ist nur im Chat verfügbar. Du wirst zur Startseite weitergeleitet...';

        if ($lang !== null && is_object($lang) && method_exists($lang, 'get')) {
            $title = $lang->get('guard_redirect_title', $title);
            $text  = $lang->get('guard_redirect_text', $text);
        }

        // Escapen
        $homeSafe  = htmlspecialchars($homeUrl, ENT_QUOTES, 'UTF-8');
        $titleSafe = htmlspecialchars((string)$title, ENT_QUOTES, 'UTF-8');
        $textSafe  = htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');

        header('Content-Type: text/html; charset=utf-8');
        header('Refresh: 2; url=' . $homeUrl);

        die('<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="2;url=' . $homeSafe . '">
<title>' . $titleSafe . '</title>
</head>
<body style="background:#000;color:#f00;margin:0;padding:20px;font-family:Arial;text-align:center;">
<h3 style="margin-top:40px;">' . $titleSafe . '</h3>
<p>' . $textSafe . '</p>
<p style="margin-top:20px;">
<a href="' . $homeSafe . '" style="color:#f80;">Zur Startseite</a>
</p>
</body>
</html>');
    }
}