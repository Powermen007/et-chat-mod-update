<?php
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Wunschbox extends DbConectionMaker
{
    private $user_id;
    private $user_priv;
    private $lang;
    private array $config = [];
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $this->user_id = (int)($_SESSION['etchat_'.$this->_prefix.'user_id'] ?? 0);
        $this->user_priv = $_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? 'gast';
		$this->lang = new LangJson('', 'wb_sendeplan.json');
        
        $this->loadConfig();
    }
    
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_wunschbox_config"
        );
    
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    
        // Sendeplan-Config (für Vorab-Wünsche)
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_sendeplan_config"
        );
    
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
    public function getConfig(string $key, string $default = ''): string
    {
        return $this->config[$key] ?? $default;
    }
    
    private function getText(string $key, string $default = ''): string
    {
        return $this->lang ? $this->lang->get($key, $default) : $default;
    }
    
    public function isAuthorized(): bool
    {
        return in_array($this->user_priv, ['admin', 'mod', 'co_admin']);
    }
    
    public function getWishes(int $sendungsId = null, string $filter = 'all', int $limit = 0, int $offset = 0): array
	{
		$params = [];
		$sql = "SELECT w.*, 
					u.etchat_username as username,
					m.etchat_username as moderator_name,
					s.etchat_username as sendung_moderator_name,
					sp.datum as sendung_datum,
					sp.zeit_von as sendung_zeit_von,
					sp.zeit_bis as sendung_zeit_bis
				FROM {$this->_prefix}etchat_wunschbox w
				LEFT JOIN {$this->_prefix}etchat_user u 
					ON w.erstellt_von = u.etchat_user_id
				LEFT JOIN {$this->_prefix}etchat_user m
					ON w.gespielt_von = m.etchat_user_id
				LEFT JOIN {$this->_prefix}etchat_sendeplan sp
					ON w.sendungs_id = sp.id
				LEFT JOIN {$this->_prefix}etchat_user s
					ON sp.moderator_id = s.etchat_user_id";
        
        $conditions = [];
        
        if ($sendungsId !== null && $sendungsId > 0) {
            $conditions[] = "w.sendungs_id = :sendungs_id";
            $params[':sendungs_id'] = $sendungsId;
        }
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            // Offene: gespielt = 0
            $conditions[] = "w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            // Gespielte: 1 oder 3 (gespielter Vorab)
            $conditions[] = "w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            // Vorgemerkt: 2
            $conditions[] = "w.gespielt = 2";
        }
        
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
        
        // 🔥 NEU: Sortierung abhängig vom Filter
		if ($filter === 'vorab') {
			// Vorgemerkt: Erst nach Sendungstermin, dann nach Wunsch-Zeitstempel (ältester zuerst)
			$sql .= " ORDER BY sp.datum ASC, sp.zeit_von ASC, w.created_at ASC";
		} else {
			// Andere Filter: Neueste Wünsche zuerst
			$sql .= " ORDER BY w.created_at DESC";
		}
        
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
        }
        
        return $this->dbObj->sqlGet($sql, $params) ?: [];
    }
    
    public function getWishesCount(int $sendungsId = null, string $filter = 'all'): int
    {
        $params = [];
        $sql = "SELECT COUNT(*) as total 
                FROM {$this->_prefix}etchat_wunschbox w";
        
        $conditions = [];
        
        if ($sendungsId !== null && $sendungsId > 0) {
            $conditions[] = "w.sendungs_id = :sendungs_id";
            $params[':sendungs_id'] = $sendungsId;
        }
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            $conditions[] = "w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            $conditions[] = "w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            $conditions[] = "w.gespielt = 2";
        }
        
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
        
        $result = $this->dbObj->sqlGet($sql, $params);
        return !empty($result) ? (int)$result[0]['total'] : 0;
    }

    /**
     * Wünsche für mehrere Sendungs-IDs holen
     */
    public function getWishesBySendungsIds(array $sendungsIds, string $filter = 'all', int $limit = 0, int $offset = 0): array
    {
        if (empty($sendungsIds)) {
            return [];
        }
        
        $params = [];
        $placeholders = [];
        foreach ($sendungsIds as $index => $id) {
            $key = ':sendungs_id_' . $index;
            $placeholders[] = $key;
            $params[$key] = $id;
        }
        
        $sql = "SELECT w.*, 
                    u.etchat_username as username,
                    m.etchat_username as moderator_name,
                    s.etchat_username as sendung_moderator_name,
                    sp.datum as sendung_datum,
                    sp.zeit_von as sendung_zeit_von,
                    sp.zeit_bis as sendung_zeit_bis
                FROM {$this->_prefix}etchat_wunschbox w
                LEFT JOIN {$this->_prefix}etchat_user u 
                    ON w.erstellt_von = u.etchat_user_id
                LEFT JOIN {$this->_prefix}etchat_user m
                    ON w.gespielt_von = m.etchat_user_id
                LEFT JOIN {$this->_prefix}etchat_sendeplan sp
                    ON w.sendungs_id = sp.id
                LEFT JOIN {$this->_prefix}etchat_user s
                    ON sp.moderator_id = s.etchat_user_id
                WHERE w.sendungs_id IN (" . implode(',', $placeholders) . ")";
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            $sql .= " AND w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            $sql .= " AND w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            $sql .= " AND w.gespielt = 2";
        }
        
        // 🔥 NEU: Sortierung abhängig vom Filter
		if ($filter === 'vorab') {
			// Vorgemerkt: Erst nach Sendungstermin, dann nach Wunsch-Zeitstempel (ältester zuerst)
			$sql .= " ORDER BY sp.datum ASC, sp.zeit_von ASC, w.created_at ASC";
		} else {
			// Andere Filter: Neueste Wünsche zuerst
			$sql .= " ORDER BY w.created_at DESC";
		}
        
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
        }
        
        return $this->dbObj->sqlGet($sql, $params) ?: [];
    }

    /**
     * Gesamtanzahl für mehrere Sendungs-IDs
     */
    public function getWishesCountBySendungsIds(array $sendungsIds, string $filter = 'all'): int
    {
        if (empty($sendungsIds)) {
            return 0;
        }
        
        $params = [];
        $placeholders = [];
        foreach ($sendungsIds as $index => $id) {
            $key = ':sendungs_id_' . $index;
            $placeholders[] = $key;
            $params[$key] = $id;
        }
        
        $sql = "SELECT COUNT(*) as total 
                FROM {$this->_prefix}etchat_wunschbox w
                WHERE w.sendungs_id IN (" . implode(',', $placeholders) . ")";
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            $sql .= " AND w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            $sql .= " AND w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            $sql .= " AND w.gespielt = 2";
        }
        
        $result = $this->dbObj->sqlGet($sql, $params);
        return !empty($result) ? (int)$result[0]['total'] : 0;
    }

    /**
     * Prüft ob es neue offene Wünsche gibt (für Badge)
     * Zählt NUR gespielt = 0 (frische Wünsche), NICHT Vorab (2)
     */
    public function hasNewOpenWishes(int $lastChecked = 0, ?int $sendungsId = null, array $sendungsIds = []): array
    {
        $params = [];
        $sql = "SELECT COUNT(*) as count, MAX(created_at) as latest 
                FROM {$this->_prefix}etchat_wunschbox 
                WHERE gespielt = 0";
        
        if ($sendungsId !== null && $sendungsId > 0) {
            $sql .= " AND sendungs_id = :sendungs_id";
            $params[':sendungs_id'] = $sendungsId;
        } elseif (!empty($sendungsIds)) {
            $placeholders = [];
            foreach ($sendungsIds as $index => $id) {
                $key = ':sid_' . $index;
                $placeholders[] = $key;
                $params[$key] = (int)$id;
            }
            $sql .= " AND sendungs_id IN (" . implode(',', $placeholders) . ")";
        }
        
        if ($lastChecked > 0) {
            $sql .= " AND created_at > FROM_UNIXTIME(:last_checked)";
            $params[':last_checked'] = $lastChecked;
        }
        
        $result = $this->dbObj->sqlGet($sql, $params);
        
        if (empty($result)) {
            return ['count' => 0, 'latest' => null];
        }
        
        return [
            'count' => (int)$result[0]['count'],
            'latest' => $result[0]['latest']
        ];
    }
    
public function saveWish(array $data): array
{
    if (empty($data['name'])) {
        return [
            'success' => false,
            'error' => $this->getText('wunschbox_fields_missing', 'Bitte Name ausfüllen'),
        ];
    }
    
    // Sendungs-Prüfung wenn sendungs_id angegeben
    $audioAllowed = false;
    if (!empty($data['sendungs_id'])) {
        $sendungsId = (int)$data['sendungs_id'];
        
        $entry = $this->dbObj->sqlGet(
            "SELECT id, datum, zeit_von, zeit_bis, wunschbox_aktiv 
            FROM {$this->_prefix}etchat_sendeplan 
            WHERE id = :id",
            [':id' => $sendungsId]
        );
        
        if (empty($entry)) {
            return ['success' => false, 'error' => $this->getText('wunschbox_sendung_not_found', 'Sendung nicht gefunden.')];
        }
        
        $entry = $entry[0];
        $wbMode = (int)$entry['wunschbox_aktiv'];
        
        if ($wbMode === 0) {
            return ['success' => false, 'error' => $this->getText('wunschbox_wb_closed', 'Die Wunschbox ist für diese Sendung geschlossen.')];
        }
        
        // 🔥 NEU: Prüfen, ob Audio erlaubt ist
        $globalAudioEnabled = ($this->getConfig('wunschbox_audio_enabled', '0')) == '1';
        $audioAllowed = in_array($wbMode, [3, 4], true) && $globalAudioEnabled;
        
        // Zeitliche Prüfung
        $now = time();
        $zeitVon = $entry['zeit_von'];
        $zeitBis = $entry['zeit_bis'];
        if (strlen($zeitVon) === 5) $zeitVon .= ':00';
        if (strlen($zeitBis) === 5) $zeitBis .= ':00';
        
        $isOvernight = $zeitBis < $zeitVon;
        $startTs = strtotime($entry['datum'] . ' ' . $zeitVon);
        $endTs = $isOvernight 
            ? strtotime($entry['datum'] . ' ' . $zeitBis . ' +1 day')
            : strtotime($entry['datum'] . ' ' . $zeitBis);
        
        $isLive = ($now >= $startTs && $now <= $endTs);
        $isPast = ($now > $endTs);
        
        if ($isPast) {
            return ['success' => false, 'error' => $this->getText('wunschbox_wb_past', 'Die Sendung ist bereits vorbei.')];
        }
        
        if (!$isLive) {
            $isVorabMode = in_array($wbMode, [2, 4], true);
            
            if (!$isVorabMode) {
                return ['success' => false, 'error' => $this->getText('wunschbox_wb_not_live', 'Die Wunschbox ist nur während der Sendung geöffnet.')];
            }
            
            $vorabEnabled = ($this->getConfig('wunschbox_vorab_enabled', '0')) == '1';
            if (!$vorabEnabled) {
                return ['success' => false, 'error' => $this->getText('wunschbox_vorab_disabled', 'Vorab-Wünsche sind deaktiviert.')];
            }
            
            $maxDays = (int)$this->getConfig('wunschbox_vorab_max_days', '30');
            if ($maxDays < 1) $maxDays = 30;
            
            $maxTs = $startTs - ($maxDays * 86400);
            
            if ($now < $maxTs) {
                return ['success' => false, 'error' => str_replace(
                    '{days}',
                    (string)$maxDays,
                    $this->getText('wunschbox_vorab_too_early', 'Wünsche für diese Sendung sind erst {days} Tage vorher möglich.')
                )];
            }
        }
    }
    
    $user_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $user_ip = trim($ips[0]);
    }
    
    if ($this->isRateLimited($user_ip)) {
        $limitSeconds = (int)$this->getConfig('rate_limit_seconds', '60');
        return [
            'success' => false, 
            'error' => str_replace(
                '{seconds}',
                (string)$limitSeconds,
                $this->getText('wunschbox_rate_limited', "Du hast bereits einen Wunsch abgesendet. Bitte warte {$limitSeconds} Sekunden.")
            )
        ];
    }
    
    $gruss = $data['gruss'] ?? '';
    if (strlen($gruss) > 500) {
        $gruss = substr($gruss, 0, 500);
    }
    
    // Vorab-Status bestimmen
    $gespieltStatus = 0;
    if (!empty($data['sendungs_id'])) {
        $sendungsId = (int)$data['sendungs_id'];
        $entryCheck = $this->dbObj->sqlGet(
            "SELECT datum, zeit_von FROM {$this->_prefix}etchat_sendeplan WHERE id = :id",
            [':id' => $sendungsId]
        );
        if (!empty($entryCheck)) {
            $sendungsStartTs = strtotime($entryCheck[0]['datum'] . ' ' . $entryCheck[0]['zeit_von']);
            if (time() < $sendungsStartTs) {
                $gespieltStatus = 2;
            }
        }
    }
    
    // 🔥 NEU: Audio-Datei verarbeiten (nur wenn erlaubt und vorhanden)
    $audioDatei    = null;
    $audioMime     = null;
    $audioDauer    = null;
    $audioGroesse  = null;
    $audioSaved    = false;
    $audioError    = null;
    
    if ($audioAllowed && !empty($_FILES['audio']) && $_FILES['audio']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['audio'];
        
        // Größe prüfen
        $maxSizeMB = (int)$this->getConfig('wunschbox_audio_max_size', '5');
        if ($maxSizeMB < 1) $maxSizeMB = 5;
        $maxSizeBytes = $maxSizeMB * 1024 * 1024;
        
        if ($file['size'] > $maxSizeBytes) {
            $audioError = 'too_large';
        } else {
            // MIME prüfen
            $finfo = new \finfo(FILEINFO_MIME_TYPE);
            $mimeDetected = $finfo->file($file['tmp_name']);
            
            $mimeMap = [
                'audio/webm' => 'webm',
                'audio/ogg'  => 'ogg',
                'audio/mp4'  => 'm4a',
                'audio/mpeg' => 'mp3',
            ];
            
            // Fallback: bei manchen Servern liefert finfo "application/octet-stream" bei WebM
            if (!isset($mimeMap[$mimeDetected])) {
                $originalExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (in_array($originalExt, ['webm', 'ogg', 'm4a', 'mp3'], true)) {
                    $mimeDetected = ($originalExt === 'm4a') ? 'audio/mp4' : 'audio/' . $originalExt;
                }
            }
            
            if (!isset($mimeMap[$mimeDetected])) {
                $audioError = 'wrong_type';
            } else {
                // Dauer (optional, kann 0 sein falls Browser nichts liefert)
                $dauer = isset($data['audio_dauer']) ? (int)$data['audio_dauer'] : 0;
                
                // Maximale Dauer prüfen
                $maxSeconds = (int)$this->getConfig('wunschbox_audio_max_seconds', '60');
                if ($maxSeconds < 5) $maxSeconds = 60;
                if ($dauer > 0 && $dauer > $maxSeconds) {
                    $audioError = 'too_long';
                } else {
                    // Dateiname erzeugen
                    $ext = $mimeMap[$mimeDetected];
                    $dateiname = $this->generateAudioFilename($ext);
                    $zielPfad  = $this->getAudioDir() . $dateiname;
                    
                    // Ordner prüfen
                    if (!$this->isAudioDirWritable()) {
                        $audioError = 'dir_not_writable';
                    } elseif (!move_uploaded_file($file['tmp_name'], $zielPfad)) {
                        $audioError = 'save_failed';
                    } else {
                        // Erfolg!
                        $audioDatei   = $dateiname;
                        $audioMime    = $mimeDetected;
                        $audioDauer   = ($dauer > 0) ? $dauer : null;
                        $audioGroesse = (int)$file['size'];
                        $audioSaved   = true;
                    }
                }
            }
        }
    }
    
    // Wunsch speichern
    $sql = "INSERT INTO {$this->_prefix}etchat_wunschbox
                (sendungs_id, name, wohnort, interpret, titel, gruss, 
                 erstellt_von, user_ip, gespielt,
                 audio_datei, audio_mime, audio_dauer, audio_groesse)
            VALUES
                (:sendungs_id, :name, :wohnort, :interpret, :titel, :gruss, 
                 :erstellt_von, :user_ip, :gespielt,
                 :audio_datei, :audio_mime, :audio_dauer, :audio_groesse)";
    
    $params = [
        ':sendungs_id'   => !empty($data['sendungs_id']) ? (int)$data['sendungs_id'] : null,
        ':name'          => substr($data['name'], 0, 100),
        ':wohnort'       => substr($data['wohnort'] ?? '', 0, 100),
        ':interpret'     => substr($data['interpret'] ?? '', 0, 100),
        ':titel'         => substr($data['titel'] ?? '', 0, 100),
        ':gruss'         => $gruss,
        ':erstellt_von'  => $this->user_id,
        ':user_ip'       => $user_ip,
        ':gespielt'      => $gespieltStatus,
        ':audio_datei'   => $audioDatei,
        ':audio_mime'    => $audioMime,
        ':audio_dauer'   => $audioDauer,
        ':audio_groesse' => $audioGroesse,
    ];
    
    $newId = $this->dbObj->sqlSet($sql, $params);
    
    if ($newId === false) {
        // Falls Audio gespeichert wurde und DB fehlschlägt → Datei wieder löschen
        if ($audioSaved && $audioDatei !== null) {
            $this->deleteAudio($audioDatei);
        }
        return [
            'success' => false,
            'error' => $this->getText('wunschbox_db_error', 'Fehler beim Speichern in der Datenbank.'),
        ];
    }
    
    return [
        'success'     => ($newId > 0),
        'id'          => $newId,
        'audio_saved' => $audioSaved,
        'audio_error' => $audioError,
    ];
}
    
    public function deleteWish(int $id): array
    {
        if (!$this->isAuthorized()) {
            return ['success' => false, 'error' => $this->getText('wunschbox_no_permission', 'Keine Berechtigung')];
        }
        
        // 🔥 NEU: Audio-Dateinamen vorher auslesen
        $wish = $this->dbObj->sqlGet(
            "SELECT audio_datei FROM {$this->_prefix}etchat_wunschbox WHERE id = :id",
            [':id' => $id]
        );
        
        $audioDatei = !empty($wish) ? ($wish[0]['audio_datei'] ?? null) : null;
        
        // DB-Eintrag löschen
        $success = $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_wunschbox WHERE id = :id",
            [':id' => $id]
        );
        
        // 🔥 NEU: Audio-Datei löschen (Original + MP3-Cache)
        if ($success && !empty($audioDatei)) {
            $this->deleteAudio($audioDatei);
        }
        
        return ['success' => $success];
    }
    
    public function isIpBanned(string $ip): bool
    {
        $result = $this->dbObj->sqlGet(
            "SELECT id FROM {$this->_prefix}etchat_wunschbox_ip_ban 
             WHERE ip_address = :ip AND ban_until > NOW()",
            [':ip' => $ip]
        );
        return !empty($result);
    }
    
    public function isRateLimited(string $ip): bool
    {
        $limitSeconds = (int)$this->getConfig('rate_limit_seconds', '60');
        
        $result = $this->dbObj->sqlGet(
            "SELECT COUNT(*) as count 
             FROM {$this->_prefix}etchat_wunschbox 
             WHERE user_ip = :ip 
             AND created_at > DATE_SUB(NOW(), INTERVAL :limit SECOND)",
            [
                ':ip' => $ip,
                ':limit' => $limitSeconds
            ]
        );
        
        return !empty($result) && (int)$result[0]['count'] > 0;
    }
	
public function maybeAutoCleanup(): void
{
    $enabled = (int)$this->getConfig('auto_delete_enabled', '0');
    if ($enabled !== 1) {
        return;
    }
    
    $days = (int)$this->getConfig('auto_delete_after_days', '30');
    if ($days < 1) $days = 1;
    
    // Vorlaufzeit für Vorgemerkte
    $vorabMaxDays = (int)$this->getConfig('wunschbox_vorab_max_days', '14');
    if ($vorabMaxDays < 0) $vorabMaxDays = 0;
    
    // Vorgemerkte: 30 + 14 = 44 Tage
    $daysVorab = $days + $vorabMaxDays;
    
    $cacheFile = __DIR__ . '/../cache/wunschbox_cleanup.txt';
    
    if (file_exists($cacheFile)) {
        $lastRun = filemtime($cacheFile);
        if ((time() - $lastRun) < 86400) {
            return;
        }
    }
    
    // 🔥 NEU: Sammel-Array für alle zu löschenden Audio-Dateien
    $audioFilesToDelete = [];
    
    // 1. Gespielte löschen (nach gespielt_am)
    $wishesPlayed = $this->dbObj->sqlGet(
        "SELECT audio_datei FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt IN (1, 3)
         AND gespielt_am < DATE_SUB(NOW(), INTERVAL :days DAY)
         AND audio_datei IS NOT NULL",
        [':days' => $days]
    );
    if (!is_array($wishesPlayed)) {
        $wishesPlayed = [];
    }
    foreach ($wishesPlayed as $row) {
        if (!empty($row['audio_datei'])) {
            $audioFilesToDelete[] = $row['audio_datei'];
        }
    }
    $deletedPlayed = count($wishesPlayed);
    
    $this->dbObj->sqlSet(
        "DELETE FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt IN (1, 3)
         AND gespielt_am < DATE_SUB(NOW(), INTERVAL :days DAY)",
        [':days' => $days]
    );
    
    // 2. Offene ungespielte löschen (nach created_at)
    $wishesOpen = $this->dbObj->sqlGet(
        "SELECT audio_datei FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 0
         AND created_at < DATE_SUB(NOW(), INTERVAL :days DAY)
         AND audio_datei IS NOT NULL",
        [':days' => $days]
    );
    if (!is_array($wishesOpen)) {
        $wishesOpen = [];
    }
    foreach ($wishesOpen as $row) {
        if (!empty($row['audio_datei'])) {
            $audioFilesToDelete[] = $row['audio_datei'];
        }
    }
    $deletedOpen = count($wishesOpen);
    
    $this->dbObj->sqlSet(
        "DELETE FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 0
         AND created_at < DATE_SUB(NOW(), INTERVAL :days DAY)",
        [':days' => $days]
    );
    
    // 3. Vorgemerkte ungespielte löschen (nach created_at + Vorlaufzeit)
    $wishesVorab = $this->dbObj->sqlGet(
        "SELECT audio_datei FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 2
         AND created_at < DATE_SUB(NOW(), INTERVAL :daysVorab DAY)
         AND audio_datei IS NOT NULL",
        [':daysVorab' => $daysVorab]
    );
    if (!is_array($wishesVorab)) {
        $wishesVorab = [];
    }
    foreach ($wishesVorab as $row) {
        if (!empty($row['audio_datei'])) {
            $audioFilesToDelete[] = $row['audio_datei'];
        }
    }
    $deletedVorab = count($wishesVorab);
    
    $this->dbObj->sqlSet(
        "DELETE FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 2
         AND created_at < DATE_SUB(NOW(), INTERVAL :daysVorab DAY)",
        [':daysVorab' => $daysVorab]
    );
    
    // 🔥 NEU: Alle gesammelten Audio-Dateien löschen
    $deletedAudioCount = 0;
    foreach ($audioFilesToDelete as $audioDatei) {
        $this->deleteAudio($audioDatei);
        $deletedAudioCount++;
    }
    
    if (!is_dir(__DIR__ . '/../cache')) {
        mkdir(__DIR__ . '/../cache', 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $total = $deletedPlayed + $deletedOpen + $deletedVorab;
    $logEntry = "{$timestamp} - Gelöscht: {$total} Wünsche ({$deletedPlayed} gespielt >{$days}T, {$deletedOpen} offen >{$days}T, {$deletedVorab} vorgemerkt >{$daysVorab}T) · {$deletedAudioCount} Audio-Dateien entfernt\n";
    file_put_contents($cacheFile, $logEntry);
}

    // ============================================================
    // AUDIO-HANDLING (Schritt 4)
    // ============================================================

    /**
     * Verzeichnis für Original-Audio-Dateien
     */
    public function getAudioDir(): string
    {
        return dirname(__DIR__) . '/sound/wunschbox/';
    }

    /**
     * Verzeichnis für konvertierte MP3-Dateien (Cache)
     */
    public function getMp3Dir(): string
    {
        return dirname(__DIR__) . '/sound/wunschbox/mp3/';
    }

    /**
     * Cache-Datei für FFmpeg-Status
     */
    private function getFfmpegCacheFile(): string
    {
        return dirname(__DIR__) . '/cache/ffmpeg_status.json';
    }

    /**
     * Prüft ob die Audio-Ordner existieren und beschreibbar sind
     */
    public function isAudioDirWritable(): bool
    {
        $audioDir = $this->getAudioDir();
        $mp3Dir   = $this->getMp3Dir();
        
        if (!is_dir($audioDir) || !is_writable($audioDir)) return false;
        if (!is_dir($mp3Dir)   || !is_writable($mp3Dir))   return false;
        
        return true;
    }
	
	 /**
     * 🔥 NEU: Erzeugt einen eindeutigen Dateinamen nach Schema
     * wunsch_DDMMYYYY_HHMM_<random3>.<ext>
     * 
     * Prüft, ob der Name bereits existiert – falls ja, wird neu gewürfelt.
     */
    public function generateAudioFilename(string $ext): string
    {
        $ext = strtolower(ltrim($ext, '.'));
        if (!in_array($ext, ['webm', 'ogg', 'm4a', 'mp3'], true)) {
            $ext = 'webm';
        }
        
        $audioDir = $this->getAudioDir();
        $maxTries = 20;
        
        for ($i = 0; $i < $maxTries; $i++) {
            $random = bin2hex(random_bytes(2)); // 4 hex-Zeichen, wir nehmen 3
            $random = substr($random, 0, 3);
            
            $name = sprintf(
                'wunsch_%s_%s.%s',
                date('dmY_Hi'),
                $random,
                $ext
            );
            
            if (!file_exists($audioDir . $name)) {
                return $name;
            }
        }
        
        // Fallback: Längerer Random-Teil, falls alle Versuche kollidierten
        return sprintf(
            'wunsch_%s_%s.%s',
            date('dmY_Hi'),
            bin2hex(random_bytes(4)),
            $ext
        );
    }

    /**
     * Erkennt, ob FFmpeg auf dem Server verfügbar ist.
     * Ergebnis wird in cache/ffmpeg_status.json zwischengespeichert.
     * 
     * @param bool $force  true = Cache ignorieren, neu erkennen
     * @return string      'server' | 'client'
     */
    public function detectFfmpeg(bool $force = false): string
    {
        $cacheFile = $this->getFfmpegCacheFile();
        
        // Cache prüfen
        if (!$force && file_exists($cacheFile)) {
            $data = json_decode(file_get_contents($cacheFile), true);
            if (is_array($data) && isset($data['mode'])) {
                // Falls Pfad gesetzt, prüfen ob Binary noch existiert
                if (!empty($data['path']) && !@is_executable($data['path'])) {
                    // Binary ist weg → neu erkennen
                    return $this->detectFfmpeg(true);
                }
                return $data['mode'];
            }
        }
        
        // Neu erkennen
        $execAllowed = function_exists('exec')
            && !in_array('exec', array_map('trim', explode(',', (string)ini_get('disable_functions'))));
        
        $ffmpegPath = null;
        
        if ($execAllowed) {
            // Übliche Pfade prüfen
            $candidates = [
                '/usr/bin/ffmpeg',
                '/usr/local/bin/ffmpeg',
                '/opt/bin/ffmpeg',
                '/bin/ffmpeg',
            ];
            foreach ($candidates as $path) {
                if (@is_executable($path)) {
                    $ffmpegPath = $path;
                    break;
                }
            }
            
            // Fallback: which ffmpeg
            if ($ffmpegPath === null) {
                @exec('which ffmpeg 2>/dev/null', $out, $rc);
                if ($rc === 0 && !empty($out[0])) {
                    $found = trim($out[0]);
                    if (@is_executable($found)) {
                        $ffmpegPath = $found;
                    }
                }
            }
        }
        
        $mode = ($ffmpegPath !== null) ? 'server' : 'client';
        
        // Cache schreiben
        $cacheDir = dirname($cacheFile);
        if (!is_dir($cacheDir)) {
            @mkdir($cacheDir, 0755, true);
        }
        @file_put_contents($cacheFile, json_encode([
            'path'       => $ffmpegPath,
            'mode'       => $mode,
            'checked_at' => time(),
        ], JSON_PRETTY_PRINT));
        
        return $mode;
    }

    /**
     * Liest den aktuellen FFmpeg-Modus aus dem Cache.
     * Erkennt automatisch, falls der Cache fehlt.
     * 
     * @return string  'server' | 'client'
     */
    public function getFfmpegMode(): string
    {
        $cacheFile = $this->getFfmpegCacheFile();
        
        if (!file_exists($cacheFile)) {
            return $this->detectFfmpeg();
        }
        
        $data = json_decode(file_get_contents($cacheFile), true);
        if (!is_array($data) || empty($data['mode'])) {
            return $this->detectFfmpeg(true);
        }
        
        // Falls Pfad gesetzt und nicht mehr vorhanden → neu erkennen
        if (!empty($data['path']) && !@is_executable($data['path'])) {
            return $this->detectFfmpeg(true);
        }
        
        return $data['mode'];
    }

    /**
     * Gibt den Pfad zur FFmpeg-Binary zurück (oder null)
     */
    private function getFfmpegPath(): ?string
    {
        $cacheFile = $this->getFfmpegCacheFile();
        if (!file_exists($cacheFile)) {
            return null;
        }
        $data = json_decode(file_get_contents($cacheFile), true);
        if (!is_array($data) || empty($data['path'])) {
            return null;
        }
        if (!@is_executable($data['path'])) {
            return null;
        }
        return $data['path'];
    }

    /**
     * Vollständiger Pfad zur Original-Audio-Datei
     */
    public function getAudioPath(string $dateiname): string
    {
        return $this->getAudioDir() . $dateiname;
    }

    /**
     * Vollständiger Pfad zur MP3-Datei (Cache)
     * Dateiendung wird durch .mp3 ersetzt
     */
    public function getMp3Path(string $dateiname): string
    {
        $mp3Name = preg_replace('/\.[a-zA-Z0-9]+$/', '.mp3', $dateiname);
        return $this->getMp3Dir() . $mp3Name;
    }

    /**
     * Stellt sicher, dass eine MP3-Version existiert.
     * Konvertiert mit FFmpeg, falls nötig.
     * 
     * @return string|null  Pfad zur MP3 bei Erfolg, sonst null
     */
    public function ensureMp3(string $dateiname): ?string
    {
        $originalPath = $this->getAudioPath($dateiname);
        $mp3Path      = $this->getMp3Path($dateiname);
        
        // Original muss existieren
        if (!file_exists($originalPath)) {
            return null;
        }
        
        // MP3 schon vorhanden → fertig
        if (file_exists($mp3Path) && filesize($mp3Path) > 0) {
            return $mp3Path;
        }
        
        // FFmpeg prüfen
        $ffmpegPath = $this->getFfmpegPath();
        if ($ffmpegPath === null) {
            return null;
        }
        
        // Konvertieren
        $cmd = sprintf(
            '%s -y -i %s -codec:a libmp3lame -q:a 4 %s 2>&1',
            escapeshellarg($ffmpegPath),
            escapeshellarg($originalPath),
            escapeshellarg($mp3Path)
        );
        
        $output = [];
        $exitCode = 0;
        @exec($cmd, $output, $exitCode);
        
        if ($exitCode !== 0 || !file_exists($mp3Path) || filesize($mp3Path) === 0) {
            // Fehler loggen
            $logFile = dirname(__DIR__) . '/cache/ffmpeg_errors.log';
            $logDir  = dirname($logFile);
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0755, true);
            }
            
            $logEntry = sprintf(
                "[%s] Datei: %s\nFFmpeg-Exit-Code: %d\nFFmpeg-Ausgabe:\n%s\n\n",
                date('Y-m-d H:i:s'),
                $dateiname,
                $exitCode,
                implode("\n", $output)
            );
            @file_put_contents($logFile, $logEntry, FILE_APPEND);
            
            // Falls eine kaputte MP3 entstanden ist, löschen
            if (file_exists($mp3Path) && filesize($mp3Path) === 0) {
                @unlink($mp3Path);
            }
            
            return null;
        }
        
        return $mp3Path;
    }

    /**
     * Löscht Original + MP3-Cache zu einer Datei
     */
    public function deleteAudio(string $dateiname): void
    {
        if ($dateiname === '') return;
        
        $originalPath = $this->getAudioPath($dateiname);
        $mp3Path      = $this->getMp3Path($dateiname);
        
        if (file_exists($originalPath)) @unlink($originalPath);
        if (file_exists($mp3Path))      @unlink($mp3Path);
    }

}