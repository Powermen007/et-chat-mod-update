<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class CookieManager extends DbConectionMaker
{
    private ?object $lang = null;
    private array $config = [];

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();
		
		// Zugriffsschutz
		require_once './class/ZugriffsGuard.class.php';
		new ZugriffsGuard();

        // ===== KEIN CACHING =====
        if (!headers_sent()) {
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Pragma: no-cache");
            header("Expires: 0");
        }

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        // ===== MODERNE SPRACHE LADEN =====
        try {
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }

        // Style aus DB laden
        $this->config = $this->dbObj->sqlGet("
            SELECT etchat_config_style
            FROM {$this->_prefix}etchat_config
            LIMIT 1
        ") ?: [];

        $this->dbObj->close();

        $style = $this->config[0]['etchat_config_style'] ?? 'default';

        $this->render($style);
    }

    private function render(string $style): void
    {
        // ===== TEXTE AUS JSON HOLEN =====
        $title         = $this->getText('cookie_manager_title', '🍪 Cookies & Speicher');
        $introText     = $this->getText('cookie_manager_intro', 'Hier siehst du, was auf deinem Gerät gespeichert ist.<br>Du kannst alles einzeln oder auf einmal löschen.');
        $sectionCookies = $this->getText('cookie_manager_section_cookies', '🍪 Cookies');
        $sectionLocal   = $this->getText('cookie_manager_section_local', '💾 Dauerhafter Speicher');
        $sectionSession = $this->getText('cookie_manager_section_session', '⏱ Sitzungs-Speicher');
        $subLocal       = $this->getText('cookie_manager_sub_local', '(bleibt auch nach Browser-Neustart)');
        $subSession     = $this->getText('cookie_manager_sub_session', '(verschwindet beim Schließen des Tabs)');
        $btnDeleteAll   = $this->getText('cookie_manager_btn_delete_all', '🗑 Alles löschen');
        $btnReload      = $this->getText('cookie_manager_btn_reload', '🔄 Neu laden');
        $footerNote     = $this->getText('cookie_manager_footer_note', 'ℹ️ <strong>Hinweis:</strong> Nach dem Löschen kehrst du zur Startseite zurück.<br>Deine gespeicherten Anmelde-Daten („Angemeldet bleiben") werden dabei entfernt.');
        $confirmDelete  = $this->getText('cookie_manager_confirm_delete', 'Möchtest du wirklich alle Cookies und Speicherstände löschen?');
        $toastDeleted   = $this->getText('cookie_manager_toast_deleted', 'Alle Daten wurden gelöscht!');
        $toastError     = $this->getText('cookie_manager_toast_error', 'Fehler beim Löschen aufgetreten!');
        $toastReloading = $this->getText('cookie_manager_toast_reloading', 'Aktualisiert...');
        $toastItemDel   = $this->getText('cookie_manager_toast_item_deleted', 'gelöscht');
        $httponlyHint   = $this->getText('cookie_manager_httponly_hint', '🔒 <strong>Hinweis:</strong> Einige Cookies (z.B. <code>PHPSESSID</code>) sind aus Sicherheitsgründen mit dem Flag <code>HttpOnly</code> geschützt.');

        // ===== HttpOnly-Zusatztexte =====
        $httponlyNotDeletable = $this->getText('cookie_manager_httponly_not_deletable', '🔒 Serverseitig geschützt – nicht über diese Seite löschbar.');
        $itemDeleteTitle      = $this->getText('cookie_manager_item_delete_title', 'Diesen Eintrag löschen');
        $itemHttponlyTitle    = $this->getText('cookie_manager_item_httponly_title', 'Nicht löschbar (HttpOnly)');

        // ===== KEY-ÜBERSETZUNGEN (aus JSON) =====
        // Struktur: key => ['title' => '...', 'desc' => '...', 'format' => '...', 'httponly' => bool]
        $keyTranslations = [
            'PHPSESSID' => [
                'title'    => $this->getText('cookie_manager_title_phpsessid', '🔒 PHP-Session (HttpOnly)'),
                'desc'     => $this->getText('cookie_manager_desc_phpsessid', 'Serverseitige Sitzungs-ID.'),
                'format'   => 'encrypted',
                'httponly' => true
            ],
            'gastFensterGezeigt' => [
                'title'  => $this->getText('cookie_manager_title_gast_fenster', '🎁 Begrüßungsfenster (Gast)'),
                'desc'   => $this->getText('cookie_manager_desc_gast_fenster', 'Wird Gästen nur alle 4 Stunden erneut angezeigt.'),
                'format' => 'timestamp'
            ],
            'userlistCollapsed' => [
                'title'  => $this->getText('cookie_manager_title_userlist_collapsed', '📋 Sendeplan – geöffneter Tag'),
                'desc'   => $this->getText('cookie_manager_desc_userlist_collapsed', 'Merkt sich, welcher Tag im Sendeplan gerade aufgeklappt ist.'),
                'format' => 'text'
            ],
            'clickTimestamps' => [
                'title'  => $this->getText('cookie_manager_title_click_timestamps', '🎲 Würfel-Wartezeit (Cooldown)'),
                'desc'   => $this->getText('cookie_manager_desc_click_timestamps', 'Verhindert zu schnelles Würfeln.'),
                'format' => 'timestamps_array'
            ],
            'db1_cookie_test' => [
                'title'  => $this->getText('cookie_manager_title_db1_cookie_test', '🧪 Cookie-Test'),
                'desc'   => $this->getText('cookie_manager_desc_db1_cookie_test', 'Test-Cookie zur Überprüfung, ob Cookies im Browser aktiviert sind.'),
                'format' => 'text'
            ],
            'guest_client_id' => [
                'title'  => $this->getText('cookie_manager_title_guest_client_id', '👤 Gast-Client-ID'),
                'desc'   => $this->getText('cookie_manager_desc_guest_client_id', 'Eindeutige Kennung für deinen Besuch in dieser Sitzung.'),
                'format' => 'text'
            ]
        ];

        // ===== PATTERN-ÜBERSETZUNGEN (aus JSON) =====
        // Struktur: [regex, title, desc, format, httponly]
        $patternTranslations = [
            [
                'regex'  => '/^saved_options_(.+)$/',
                'title'  => $this->getText('cookie_manager_title_saved_options', '⚙️ Gespeicherte Einstellungen') . ' ($1)',
                'desc'   => $this->getText('cookie_manager_desc_saved_options', 'Speichert deine persönlichen Chat-Einstellungen.'),
                'format' => 'json_object'
            ],
            [
                'regex'  => '/^chat_(.+)_session_active$/',
                'title'  => $this->getText('cookie_manager_title_session_active', '✅ Cookie-Einwilligung'),
                'desc'   => $this->getText('cookie_manager_desc_session_active', 'Speichert, ob du die Nutzung von Cookies akzeptiert hast.'),
                'format' => 'text'
            ],
            [
                'regex'  => '/^chat_(.+)_login_data$/',
                'title'  => $this->getText('cookie_manager_title_login_data', '🔐 Login-Daten (verschlüsselt)'),
                'desc'   => $this->getText('cookie_manager_desc_login_data', 'Speichert deine Anmeldedaten für "Angemeldet bleiben".'),
                'format' => 'encrypted'
            ],
            [
                'regex'    => '/^chat_(.+)_login_counter$/',
                'title'    => $this->getText('cookie_manager_title_login_counter', '🔒 Login-Zähler (HttpOnly)'),
                'desc'     => $this->getText('cookie_manager_desc_login_counter', 'Zählt Login-Versuche (Schutz vor Brute-Force).'),
                'format'   => 'text',
                'httponly' => true
            ],
            [
                'regex'  => '/^chatHistory_(.+)$/',
                'title'  => $this->getText('cookie_manager_title_chat_history', '💬 Chat-Verlauf'),
                'desc'   => $this->getText('cookie_manager_desc_chat_history', 'Speichert den Verlauf deines Chats in dieser Sitzung.'),
                'format' => 'json_object'
            ]
        ];

        // ===== SERVER-COOKIES (inkl. HttpOnly) =====
        $serverCookies = $_COOKIE ?? [];

        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title><?= htmlspecialchars(strip_tags($title)) ?></title>
            
            <!-- KEIN CACHING – Iframe lädt bei jedem Aufruf frisch -->
            <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
            <meta http-equiv="Pragma" content="no-cache">
            <meta http-equiv="Expires" content="0">
            
            <link href="styles/<?= htmlspecialchars($style) ?>/style.css" rel="stylesheet" type="text/css"/>
            <meta name="robots" content="noindex,nofollow">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    /* ===== Cookie-Manager – kompakt ===== */
    body {
        margin: 0;
        padding: 10px;
        color: var(--color-text-webfarbe);
        font-family: var(--font-family);
        font-size: var(--font-size-base);
    }
    .cm-wrapper { max-width: 600px; margin: 0 auto; }
    .cm-info-box, .cm-footer-note {
        background: var(--color-box);
        border: 1px solid var(--color-border);
        border-radius: 8px;
        padding: 10px 14px;
        margin-bottom: 14px;
        line-height: 1.4;
    }
    .cm-footer-note {
        margin-top: 14px;
        margin-bottom: 0;
        color: #bbb;
        border-left: 4px solid #f0ad4e;
    }
    /* HttpOnly-Hinweis – nutzt die cm-info-box, nur blaue linke Linie */
    .cm-info-box.httponly-hint {
        border-left: 4px solid #17a2b8;
        color: var(--color-text-webfarbe);
        margin-bottom: 14px;
    }
    .cm-section { margin-bottom: 14px; }
    .cm-section-title {
        display: flex;
        justify-content: space-between;
        font-weight: bold;
        margin-bottom: 6px;
    }
    .cm-subtitle, .cm-item-desc {
        font-size: var(--font-size-small);
        color: #888;
        font-style: italic;
        font-weight: normal;
    }
    .cm-count { color: #aaa; }
    .cm-list { display: flex; flex-direction: column; gap: 4px; }
    .cm-item {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 8px;
        padding: 8px 12px;
        background: var(--color-button-zeilen);
        border: 1px solid var(--color-border);
        border-radius: 6px;
    }
    /* HttpOnly-Item – leichte blaue Markierung, sonst identisch */
    .cm-item.httponly {
        border-color: rgba(23, 162, 184, 0.5);
    }
    .cm-item-info {
		display: flex;
		flex-direction: column;
		flex: 1;
		min-width: 0;
		overflow: hidden;
	}
    .cm-item-title { font-weight: bold; }
    .cm-item-key {
        font-size: var(--font-size-small);
        color: #777;
        font-family: monospace;
        word-break: break-all;
    }
    .cm-item-value { word-break: break-word; cursor: help; }
    .cm-item-desc { margin-top: 2px; }
    .cm-item-delete, .cm-btn {
        border: 1px solid var(--color-border);
        border-radius: 6px;
        cursor: pointer;
        font-family: var(--font-family);
    }
    .cm-item-delete {
        align-self: center;
        padding: 4px 8px;
        background: var(--color-box);
        color: #ff6b6b;
    }
    .cm-item-delete:hover { background: #552222; color: #fff; }
    /* Deaktivierter Lösch-Button für HttpOnly-Cookies */
    .cm-item-delete.disabled {
        opacity: 0.4;
        cursor: not-allowed;
        background: #333;
        color: #888;
    }
    .cm-item-delete.disabled:hover {
        background: #333;
        color: #888;
    }
    .cm-actions { display: flex; gap: 8px; margin-top: 14px; }
    .cm-btn {
        flex: 1;
        padding: 8px;
        font-size: var(--font-size-large);
        font-weight: bold;
    }
    .cm-btn-danger { background: #8b0000; color: #fff; }
    .cm-btn-danger:hover { background: #a00000; }
    .cm-btn-secondary {
        background: var(--color-button-zeilen);
        color: var(--color-text-webfarbe);
    }
    .cm-btn-secondary:hover { background: var(--color-button-hover); }

    /* Toasts – das Einzige, was der Chat noch nicht hat */
    .cm-toast-container {
        position: fixed;
        top: 15px;
        right: 15px;
        z-index: 99999;
        display: flex;
        flex-direction: column;
        gap: 8px;
        pointer-events: none;
    }
    .cm-toast {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 200px;
        padding: 10px 16px;
        border-radius: 6px;
        color: #fff;
        font-weight: bold;
        position: relative;
        overflow: hidden;
        pointer-events: auto;
        box-shadow: 0 4px 12px rgba(0,0,0,0.4);
        transform: translateX(120%);
        opacity: 0;
        transition: transform 0.4s, opacity 0.4s;
    }
    .cm-toast.show { transform: translateX(0); opacity: 1; }
    .cm-toast.hide { transform: translateX(120%); opacity: 0; }
    .cm-toast .toast-icon { font-size: var(--font-size-xlarge); }
    .cm-toast .toast-text { flex: 1; }
    .cm-toast .toast-progress {
        position: absolute;
        bottom: 0; left: 0;
        height: 3px;
        width: 100%;
        background: rgba(255,255,255,0.6);
    }
    .cm-toast.toast-success { background: #28a745; border-left: 5px solid #1e7e34; }
    .cm-toast.toast-error   { background: #dc3545; border-left: 5px solid #a71d2a; }
    .cm-toast.toast-info    { background: #17a2b8; border-left: 5px solid #117a8b; }
</style>
        </head>
        <body id="body">

        <!-- Toast-Container (oben rechts) -->
        <div class="cm-toast-container" id="toastContainer"></div>

        <div class="cm-wrapper">
            <div class="cm-header">
                <h2><?= $title ?></h2>
            </div>

            <div class="cm-info-box">
                <?= $introText ?>
            </div>

            <!-- HttpOnly-Hinweis (nutzt cm-info-box-Klasse) -->
            <div class="cm-info-box httponly-hint">
                <?= $httponlyHint ?>
            </div>

            <div class="cm-section">
                <div class="cm-section-title">
                    <span><?= $sectionCookies ?></span>
                    <span class="cm-count" id="count-cookies">(0)</span>
                </div>
                <div id="list-cookies" class="cm-list"></div>
            </div>

            <div class="cm-section">
                <div class="cm-section-title">
                    <span><?= $sectionLocal ?></span>
                    <span class="cm-subtitle"><?= $subLocal ?></span>
                </div>
                <div id="list-local" class="cm-list"></div>
            </div>

            <div class="cm-section">
                <div class="cm-section-title">
                    <span><?= $sectionSession ?></span>
                    <span class="cm-subtitle"><?= $subSession ?></span>
                </div>
                <div id="list-session" class="cm-list"></div>
            </div>

            <div class="cm-actions">
                <button id="btn-delete-all" class="cm-btn cm-btn-danger"><?= $btnDeleteAll ?></button>
                <button id="btn-reload" class="cm-btn cm-btn-secondary"><?= $btnReload ?></button>
            </div>

            <div class="cm-footer-note">
                <?= $footerNote ?>
            </div>
        </div>

        <script>
        /**
         * =====================================================================
         *  SERVER-COOKIES (inkl. HttpOnly)
         * =====================================================================
         */
        const SERVER_COOKIES = <?= json_encode($serverCookies, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

        /**
         * =====================================================================
         *  ÜBERSETZUNGEN (aus PHP / JSON)
         * =====================================================================
         */
        const CM_TEXTS = {
            confirmDelete:  <?= json_encode($confirmDelete) ?>,
            toastDeleted:   <?= json_encode($toastDeleted) ?>,
            toastError:     <?= json_encode($toastError) ?>,
            toastReload:    <?= json_encode($toastReloading) ?>,
            toastItemDel:   <?= json_encode($toastItemDel) ?>,
            httponlyNote:   <?= json_encode($httponlyNotDeletable) ?>,
            deleteTitle:    <?= json_encode($itemDeleteTitle) ?>,
            httponlyTitle:  <?= json_encode($itemHttponlyTitle) ?>
        };

        /**
         * =====================================================================
         *  KEY-ÜBERSETZUNGEN (aus PHP / JSON)
         * =====================================================================
         */
        const KEY_TRANSLATIONS = <?= json_encode($keyTranslations, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

        /**
         * =====================================================================
         *  PATTERN-ÜBERSETZUNGEN (aus PHP / JSON)
         * =====================================================================
         */
        const PATTERN_TRANSLATIONS = <?= json_encode($patternTranslations, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

        /**
         * =====================================================================
         *  EINSTELLUNGEN
         * =====================================================================
         */
        const TOAST_DEFAULT_DURATION = 5000;
        const TOAST_SUCCESS_DURATION = 4000;
        const TOAST_ERROR_DURATION   = 6000;
        const TOAST_RELOAD_DURATION  = 3000;
        const RELOAD_WAIT_TIME       = 3000;

        document.addEventListener('DOMContentLoaded', () => {
          renderStorage();

          // ===== "ALLES LÖSCHEN" =====
          document.getElementById('btn-delete-all').addEventListener('click', () => {
            if(confirm(CM_TEXTS.confirmDelete)) {
              try {
                document.cookie.split(";").forEach((c) => {
                  document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
                });
                localStorage.clear();
                sessionStorage.clear();
                showToast('🗑', CM_TEXTS.toastDeleted, 'success', TOAST_SUCCESS_DURATION);
                setTimeout(() => { window.location.reload(); }, 1500);
              } catch (err) {
                showToast('❌', CM_TEXTS.toastError, 'error', TOAST_ERROR_DURATION);
                console.error('Löschen fehlgeschlagen:', err);
              }
            }
          });

          // ===== "NEU LADEN" =====
          document.getElementById('btn-reload').addEventListener('click', () => {
            showToast('🔄', CM_TEXTS.toastReload, 'info', TOAST_RELOAD_DURATION);
            setTimeout(() => { window.location.reload(); }, RELOAD_WAIT_TIME);
          });
        });

        function showToast(icon, text, type = 'success', duration = TOAST_DEFAULT_DURATION) {
          const container = document.getElementById('toastContainer');
          const toast = document.createElement('div');
          toast.className = 'cm-toast toast-' + type;
          toast.innerHTML = `
            <span class="toast-icon">${icon}</span>
            <span class="toast-text">${escapeHtml(text)}</span>
            <div class="toast-progress" style="animation: none; transition: width ${duration}ms linear; width: 100%;"></div>
          `;
          container.appendChild(toast);
          const progress = toast.querySelector('.toast-progress');
          requestAnimationFrame(() => {
            requestAnimationFrame(() => { progress.style.width = '0%'; });
          });
          requestAnimationFrame(() => {
            requestAnimationFrame(() => { toast.classList.add('show'); });
          });
          setTimeout(() => {
            toast.classList.remove('show');
            toast.classList.add('hide');
            setTimeout(() => {
              if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 400);
          }, duration);
        }

        function renderStorage() {
          // ===== JS-sichtbare Cookies =====
          const cookies = document.cookie.split(";").filter(c => c.trim() !== "");
          const cookieList = document.getElementById('list-cookies');
          cookieList.innerHTML = '';
          const jsCookieKeys = new Set();

          cookies.forEach(cookie => {
            const [key, ...valParts] = cookie.split("=");
            const cleanKey = key.trim();
            jsCookieKeys.add(cleanKey);
            const value = valParts.join("=");
            cookieList.appendChild(createItem(cleanKey, value, 'cookie', false));
          });

          // ===== HttpOnly-Cookies (vom Server) – nur zusätzliche =====
          Object.keys(SERVER_COOKIES).forEach(key => {
            if (!jsCookieKeys.has(key)) {
              cookieList.appendChild(createItem(key, SERVER_COOKIES[key], 'cookie', true));
            }
          });

          // Zähler aktualisieren
          const totalCookies = jsCookieKeys.size + Object.keys(SERVER_COOKIES).filter(k => !jsCookieKeys.has(k)).length;
          document.getElementById('count-cookies').textContent = `(${totalCookies})`;

          // ===== LocalStorage =====
          const localList = document.getElementById('list-local');
          localList.innerHTML = '';
          Object.keys(localStorage).forEach(key => {
            localList.appendChild(createItem(key, localStorage.getItem(key), 'local', false));
          });

          // ===== SessionStorage =====
          const sessionList = document.getElementById('list-session');
          sessionList.innerHTML = '';
          Object.keys(sessionStorage).forEach(key => {
            sessionList.appendChild(createItem(key, sessionStorage.getItem(key), 'session', false));
          });
        }

        function findTranslation(key) {
          if (KEY_TRANSLATIONS[key]) return KEY_TRANSLATIONS[key];
          for (const pattern of PATTERN_TRANSLATIONS) {
            // Regex-String aus PHP kann führende/endende Slashes enthalten – entfernen
            const regexPattern = pattern.regex.replace(/^\/|\/$/g, '');
            const match = key.match(new RegExp(regexPattern));
            if (match) {
              // Wenn der Titel einen Platzhalter hat ($1), ersetzen
              let title = pattern.title;
              if (title.indexOf('$1') !== -1) {
                title = title.replace('$1', match[1] || '');
              }
              return {
                title: title,
                desc: pattern.desc,
                format: pattern.format,
                httponly: pattern.httponly || false
              };
            }
          }
          return null;
        }

        function createItem(key, value, type, isHttpOnly) {
          const div = document.createElement('div');
          div.className = 'cm-item' + (isHttpOnly ? ' httponly' : '');

          const translation = findTranslation(key);
          const rawValue = String(value);
          const httponly = isHttpOnly || (translation && translation.httponly);

          const titleHtml = translation 
            ? `<span class="cm-item-title">${escapeHtml(translation.title)}</span>
               <span class="cm-item-key">${escapeHtml(key)}</span>`
            : `<span class="cm-item-title">${escapeHtml(key)}</span>`;

          let displayValue;
          if (translation && translation.format) {
            displayValue = formatByType(rawValue, translation.format);
          } else {
            displayValue = formatValueAuto(rawValue);
          }

          let descHtml = translation && translation.desc
            ? `<span class="cm-item-desc">${escapeHtml(translation.desc)}</span>`
            : '';

          // HttpOnly-Zusatzhinweis (aus JSON)
          if (httponly) {
            descHtml += `<span class="cm-item-desc" style="color:#17a2b8; margin-top:4px;">${escapeHtml(CM_TEXTS.httponlyNote)}</span>`;
          }

          // Button: Aktiv oder deaktiviert
          const buttonHtml = httponly
            ? `<button class="cm-item-delete disabled" title="${escapeHtml(CM_TEXTS.httponlyTitle)}" disabled>🔒</button>`
            : `<button class="cm-item-delete" title="${escapeHtml(CM_TEXTS.deleteTitle)}">🗑</button>`;

          div.innerHTML = `
            <div class="cm-item-info">
              ${titleHtml}
              <span class="cm-item-value" title="${escapeHtml(rawValue)}">${escapeHtml(displayValue)}</span>
              ${descHtml}
            </div>
            ${buttonHtml}
          `;

          // Nur wenn nicht HttpOnly: Klick-Listener
          if (!httponly) {
            const btn = div.querySelector('.cm-item-delete');
            if (btn) {
              btn.addEventListener('click', () => {
                try {
                  const label = translation ? translation.title : key;
                  if (type === 'cookie') {
                    document.cookie = `${key}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
                  } else if (type === 'local') {
                    localStorage.removeItem(key);
                  } else if (type === 'session') {
                    sessionStorage.removeItem(key);
                  }
                  showToast('🗑', `${label} ${CM_TEXTS.toastItemDel}`, 'success', TOAST_SUCCESS_DURATION);
                  renderStorage();
                } catch (err) {
                  showToast('❌', CM_TEXTS.toastError, 'error', TOAST_ERROR_DURATION);
                  console.error('Löschen fehlgeschlagen:', err);
                }
              });
            }
          }

          return div;
        }

        function formatByType(value, type) {
          switch(type) {
            case 'timestamp': return formatTimestamp(value);
            case 'boolean': return value === 'true' ? '✓ Ja' : '✗ Nein';
            case 'timestamps_array': return formatTimestampsArray(value);
            case 'json_object': return formatJsonObject(value);
            case 'encrypted': return formatEncrypted(value);
            case 'text':
            default:
              return value.length > 50 ? value.substring(0, 50) + '...' : value;
          }
        }

        function formatTimestamp(value) {
          const str = String(value).trim();
          let ts = null;
          if (/^\d{13}$/.test(str)) ts = parseInt(str, 10);
          else if (/^\d{10}$/.test(str)) ts = parseInt(str, 10) * 1000;
          if (ts && ts > 1000000000000 && ts < 4102444800000) {
            return new Date(ts).toLocaleString('de-DE', {
              day: '2-digit', month: '2-digit', year: 'numeric',
              hour: '2-digit', minute: '2-digit'
            });
          }
          return str;
        }

        function formatTimestampsArray(value) {
          try {
            const arr = JSON.parse(value);
            if (!Array.isArray(arr)) return value;
            const count = arr.length;
            if (count === 0) return 'Keine Einträge';
            const lastTs = arr[arr.length - 1];
            const lastDate = formatTimestamp(String(lastTs));
            if (count === 1) return `Letzter Wurf: ${lastDate}`;
            return `${count} Würfe – Letzter: ${lastDate}`;
          } catch(e) { return value; }
        }

        function formatJsonObject(value) {
          const str = String(value).trim();
          if (!str.startsWith('{') || !str.endsWith('}')) {
            return str.length > 50 ? str.substring(0, 50) + '...' : str;
          }
          try {
            const obj = JSON.parse(str);
            const keys = Object.keys(obj);
            const count = keys.length;
            if (count === 0) return 'Leer';
            const preview = keys.slice(0, 3).map(k => {
              const v = obj[k];
              const valStr = typeof v === 'object' ? '…' : String(v);
              const shortVal = valStr.length > 15 ? valStr.substring(0, 15) + '…' : valStr;
              return `${k}: ${shortVal}`;
            }).join(', ');
            const more = count > 3 ? ` (+${count - 3} weitere)` : '';
            return `{${count}: ${preview}${more}}`;
          } catch(e) {
            return str.length > 50 ? str.substring(0, 50) + '...' : str;
          }
        }

        function formatEncrypted(value) {
          if (!value || value.length < 5) return '(leer)';
          return `🔒 Verschlüsselt (${value.length} Zeichen)`;
        }

        function formatValueAuto(value) {
          const str = String(value).trim();
          if (/^\d{13}$/.test(str)) {
            const ts = parseInt(str, 10);
            if (ts > 1000000000000 && ts < 4102444800000) {
              return new Date(ts).toLocaleString('de-DE', {
                day: '2-digit', month: '2-digit', year: 'numeric',
                hour: '2-digit', minute: '2-digit'
              });
            }
          }
          if (str.startsWith('[') && str.endsWith(']')) {
            try {
              const arr = JSON.parse(str);
              if (Array.isArray(arr)) {
                return arr.length === 1 ? '[1 Eintrag]' : `[${arr.length} Einträge]`;
              }
            } catch(e) {}
          }
          if (str.startsWith('{') && str.endsWith('}')) {
            try {
              const obj = JSON.parse(str);
              if (typeof obj === 'object' && obj !== null) {
                const count = Object.keys(obj).length;
                return count === 1 ? '{1 Eigenschaft}' : `{${count} Eigenschaften}`;
              }
            } catch(e) {}
          }
          if (str === 'true') return '✓ true';
          if (str === 'false') return '✗ false';
          return str.length > 40 ? str.substring(0, 40) + '...' : str;
        }

        function escapeHtml(text) {
          const div = document.createElement('div');
          div.textContent = text;
          return div.innerHTML;
        }
        </script>
        </body>
        </html>
        <?php
    }
}