<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class ConnectDB extends EtChatConfig
{
    protected ?PDO $_connid = null;
    public int $lastId = 0;

    public function __construct()
    {
        parent::__construct();

        try {
            $dsn = "{$this->_usedDatabase}:host={$this->_sqlhost};dbname={$this->_database};charset=utf8mb4";

            $this->_connid = new PDO(
                $dsn,
                $this->_sqluser,
                $this->_sqlpass,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,  // echte Prepared Statements
                ]
            );

        } catch (PDOException $e) {
            error_log("PDO Verbindungsfehler: " . $e->getMessage());
            echo "<pre style='color:#ff5555;background:#2a1a1a;padding:10px;font-family:monospace'>";
            echo "Datenbankverbindung fehlgeschlagen.\n\n";
            echo "Details: " . htmlspecialchars($e->getMessage()) . "\n";
            echo "DSN:     " . htmlspecialchars($dsn) . "\n";
            echo "Host:    " . htmlspecialchars($this->_sqlhost) . "\n";
            echo "DB:      " . htmlspecialchars($this->_database) . "\n";
            echo "User:    " . htmlspecialchars($this->_sqluser) . "\n";
            echo "</pre>";
            exit;
        }
    }

    public function sqlGet(string $sql, array $params = []): array|false
    {
        if ($sql === '') return false;

        try {
            $stmt = $this->_connid->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result ?: false;
        } catch (PDOException $e) {
            error_log("PDO sqlGet Fehler: " . $e->getMessage());
            error_log("SQL: " . $sql);
            error_log("PARAMS: " . print_r($params, true));
            return false;
        }
    }

    public function sqlSet(string $sql, array $params = []): bool|int
    {
        if ($sql === '') return false;

        try {
            // Statements OHNE Platzhalter (CREATE TABLE, ALTER, INSERT ohne Params, ...)
            // direkt per exec() ausführen — echte Prepared Statements können das nicht.
            if (empty($params)) {
                $affected = $this->_connid->exec($sql);
                if ($affected === false) {
                    return false;
                }
                $this->lastId = (int)$this->_connid->lastInsertId();
                return $affected;
            }

            // Statements MIT Platzhaltern → echtes Prepared Statement
            $stmt = $this->_connid->prepare($sql);
            $stmt->execute($params);
            $this->lastId = (int)$this->_connid->lastInsertId();
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("PDO sqlSet Fehler: " . $e->getMessage());
            error_log("SQL: " . $sql);
            error_log("PARAMS: " . print_r($params, true));
            error_log("BACKTRACE: " . print_r(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 6), true));
            return false;
        }
    }

    public function sqlExec(string $sql): bool|int
    {
        if ($sql === '') return false;

        try {
            $affected = $this->_connid->exec($sql);
            if ($affected === false) {
                return false;
            }
            $this->lastId = (int)$this->_connid->lastInsertId();
            return $affected;
        } catch (PDOException $e) {
            error_log("PDO sqlExec Fehler: " . $e->getMessage());
            return false;
        }
    }

    public function getConnection(): ?PDO
    {
        return $this->_connid;
    }

    public function close(): void
    {
        $this->_connid = null;
    }
}