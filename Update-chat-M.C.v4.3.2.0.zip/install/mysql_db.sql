ALTER TABLE `etchat_wunschbox`
  ADD COLUMN `audio_datei`   VARCHAR(255) DEFAULT NULL AFTER `gruss`,
  ADD COLUMN `audio_mime`    VARCHAR(50)  DEFAULT NULL AFTER `audio_datei`,
  ADD COLUMN `audio_dauer`   SMALLINT UNSIGNED DEFAULT NULL AFTER `audio_mime`,
  ADD COLUMN `audio_groesse` INT UNSIGNED DEFAULT NULL AFTER `audio_dauer`;



INSERT INTO `etchat_wunschbox_config` (`config_key`, `config_value`) VALUES
  ('wunschbox_audio_enabled',     '0'),
  ('wunschbox_audio_max_seconds', '60'),
  ('wunschbox_audio_max_size',    '5')
ON DUPLICATE KEY UPDATE `config_key` = `config_key`;
