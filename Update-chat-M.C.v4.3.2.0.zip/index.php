<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

// ============================================================
// AUTOLOADER
// ============================================================
spl_autoload_register(function(string $class_name): void {
    if (substr($class_name, 0, 5) === "Admin") {
        require_once 'class/admin/' . $class_name . '.class.php';
    } elseif (substr($class_name, 0, 7) === "Install") {
        require_once 'class/install/' . $class_name . '.class.php';
    } elseif (file_exists('class/' . $class_name . '.class.php')) {
        require_once 'class/' . $class_name . '.class.php';
    }
});

// Sonderfall-Keys
$special_keys = ['register', 'token'];
$passwort = $_GET['passwort'] ?? '';
$special_combination = in_array($passwort, ['vergessen', 'zuruecksetzen'], true);

$firstKey = array_keys($_GET)[0] ?? '';
$init_class = (in_array($firstKey, $special_keys, true) || $special_combination)
    ? "Index"
    : (!empty($firstKey) ? $firstKey : "Index");

// Nur alphanumerische Klassen erlauben
if (preg_match('/^[A-Za-z0-9_\-]+$/', $init_class)) {

    // Sonderfall: Smileys-Popup
    if ($init_class === 'Smileys' && isset($_GET['popup'])) {
        require_once 'smileys_popup_wrapper.php';
    } else {
        if (!class_exists($init_class)) {
            echo "Klasse '$init_class' nicht gefunden!";
        } else {
            // 🔥 NEU: Nur Klassen als Module zulassen, die OHNE Argumente
            //         instanziiert werden können. Interne Hilfsklassen
            //         wie Blacklist, ConnectDB, LangJson, EtChatConfig,
            //         DbConectionMaker etc. werden so automatisch geblockt.
            $ref = new ReflectionClass($init_class);
            $ctor = $ref->getConstructor();

            $hasRequiredArgs = $ctor !== null && $ctor->getNumberOfRequiredParameters() > 0;
            $isAbstract = $ref->isAbstract();
            $isInterface = $ref->isInterface();

            if ($hasRequiredArgs || $isAbstract || $isInterface) {
                // Kein gültiges Modul → auf die Startseite umleiten
                header('Location: ./');
                exit;
            }

            new $init_class;
        }
    }

} else {
    echo "Ungültiger Klassenname!";
}