<?php
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski
Reduzierte Version: Nur Titel-Lauftext mit Auto-Refresh für iframe-Einbindung.
Eigene Funktionen (radio_lauftext_*) → kein Konflikt mit radio-box.php
*/

// === CORS ===
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$GLOBALS["path"] = "./../";

$CACHE_DIR  = __DIR__ . "/cache";
$CACHE_TIME = 30;
$RELOAD     = 30;

function radio_lauftext_getCacheFile(string $key): string
{
    global $CACHE_DIR;
    return $CACHE_DIR . "/radio_" . md5($key) . ".cache";
}

function radio_lauftext_getCached(string $key): ?array
{
    global $CACHE_TIME;
    $file = radio_lauftext_getCacheFile($key);
    if (!file_exists($file)) return null;

    $data = json_decode(file_get_contents($file), true);
    if (!is_array($data) || !isset($data["time"], $data["value"])) return null;
    if (time() - $data["time"] > $CACHE_TIME) return null;

    // Robust: nur Array akzeptieren
    if (!is_array($data["value"])) return null;

    return $data["value"];
}

function radio_lauftext_setCache(string $key, array $value): void
{
    global $CACHE_DIR;
    if (!is_dir($CACHE_DIR)) mkdir($CACHE_DIR, 0777, true);
    file_put_contents(radio_lauftext_getCacheFile($key), json_encode([
        "time"  => time(),
        "value" => $value,
    ]));
}

spl_autoload_register(function ($class_name) {
    require_once $GLOBALS["path"] . "class/" . $class_name . ".class.php";
});

/* === Cache-Aufräumen === */
if (mt_rand(1, 100) === 1) {
    $dir = __DIR__ . "/cache";
    if (is_dir($dir)) {
        $limit = time() - 86400;
        foreach (glob($dir . "/*.cache") as $file) {
            if (is_file($file) && filemtime($file) < $limit) @unlink($file);
        }
    }
}

class RadioTitel extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        $radio = $this->dbObj->sqlGet(
            "SELECT etchat_radio_horst, etchat_radio_port, etchat_radio_typ
             FROM {$this->_prefix}etchat_radio_box
             WHERE etchat_radio_id = '1'"
        );

        $horst = $radio[0]['etchat_radio_horst'] ?? '';
        $port  = $radio[0]['etchat_radio_port']  ?? '';
        $type  = $radio[0]['etchat_radio_typ']   ?? '';

        $title = $this->getTitle($horst, $port, $type);
        $title = $this->stripDjName($title);

        $this->dbObj->close();

        global $RELOAD;
        $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $reloadSec = max(10, (int)$RELOAD);
        ?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="refresh" content="<?php echo $reloadSec; ?>">
<title>Radio Titel</title>
<style>
    html, body {
        margin: 0; padding: 0;
        background: transparent;
        overflow: hidden;
        font-family: Arial, sans-serif;
        font-size: 14px;
        height: 100%;
    }
    .radio-lauftext {
        width: 100%; height: 100%;
        min-height: 24px;
        line-height: 1.6;
        white-space: nowrap;
        overflow: hidden;
        box-sizing: border-box;
        display: flex;
        align-items: center;
    }
    .radio-lauftext .txt {
        display: inline-block;
        padding: 0 6px;
        will-change: transform;
    }
    .radio-lauftext.scroll .txt {
        padding-left: 100%;
        animation: radio-scroll var(--scroll-duration, 15s) linear infinite;
    }
    @keyframes radio-scroll {
        0%   { transform: translateX(0); }
        100% { transform: translateX(-100%); }
    }
</style>
</head>
<body>
<div class="radio-lauftext" id="radioLauftext">
    <span class="txt" id="radioTxt"><?php echo $safeTitle; ?></span>
</div>
<script>
    setTimeout(function () {
        window.location.reload();
    }, <?php echo $reloadSec * 1000; ?>);

    (function () {
        var container = document.getElementById('radioLauftext');
        var txt       = document.getElementById('radioTxt');
        if (!container || !txt) return;

        function checkOverflow() {
            container.classList.remove('scroll');
            txt.style.paddingLeft = '';
            void txt.offsetWidth;

            var containerW = container.clientWidth;
            var textW      = txt.scrollWidth;

            if (textW > containerW) {
                var duration = Math.max(10, Math.round(textW / 50));
                container.style.setProperty('--scroll-duration', duration + 's');
                container.classList.add('scroll');
            }
        }

        checkOverflow();
        window.addEventListener('resize', checkOverflow);
    })();
</script>
</body>
</html>
        <?php
    }

    private function stripDjName(string $title): string
    {
        if ($title === '') return '';
        $pos = mb_strpos($title, '|');
        if ($pos !== false) {
            $title = mb_substr($title, 0, $pos);
        }
        return trim($title);
    }

    private function getTitle(string $horst, string $port, string $type): string
    {
        // ✅ EIGENER Cache-Key → keine Kollision mit radio-box.php
        $cacheKey = "radio_lauftext_{$horst}_{$port}_{$type}";

        $cached = radio_lauftext_getCached($cacheKey);
        if ($cached !== null) {
            return $cached["title"] ?? "";
        }

        $title = "";
        $protocols = ["https", "http"];

        switch ($type) {
            case "lautfm":
                $url = "https://api.laut.fm/station/{$horst}/current_song";
                $ctx = stream_context_create(["http" => ["timeout" => 3]]);
                $json = @file_get_contents($url, false, $ctx);
                if ($json !== false) {
                    $data = json_decode($json, true);
                    if ($data && isset($data["title"])) {
                        $artist = $data["artist"]["name"] ?? "";
                        $song   = $data["title"] ?? "";
                        $title  = trim("$artist - $song", " -");
                    }
                }
                break;

            case "icecast":
                foreach ($protocols as $proto) {
                    $url = "$proto://$horst:$port/status-json.xsl";
                    $ctx = stream_context_create(["http" => ["timeout" => 3]]);
                    $json = @file_get_contents($url, false, $ctx);
                    if ($json !== false) {
                        $data = json_decode($json, true);
                        if (!empty($data["icestats"]["source"])) {
                            $source = $data["icestats"]["source"];
                            if (isset($source[0])) $source = $source[0];
                            $title = $source["title"] ?? "";
                            break;
                        }
                    }
                }
                break;

            case "shoutcast":
            default:
                foreach ($protocols as $proto) {
                    $url = "$proto://$horst:$port/stats?sid=1&mode=xml";
                    $ctx = stream_context_create(["http" => ["timeout" => 3]]);
                    $xml = @file_get_contents($url, false, $ctx);
                    if ($xml !== false) {
                        $x = simplexml_load_string($xml);
                        if ($x && $x->STREAMSTATUS == 1) {
                            $title = (string) $x->SONGTITLE;
                            break;
                        }
                    }
                }
                break;
        }

        if (!empty($title)) {
            radio_lauftext_setCache($cacheKey, ["title" => $title]);
        }

        return $title;
    }
}

new RadioTitel();