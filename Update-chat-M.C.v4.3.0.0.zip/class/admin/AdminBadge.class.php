<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminBadge extends DbConectionMaker
{
    private string $userRole = '';

    /** Erlaubte Rollen, die den Badge sehen dürfen */
    private const ALLOWED_ROLES = ['admin', 'co_admin', 'chatwache'];

    /** Poll-Intervall in Sekunden (Server-Vorgabe) */
    private const INTERVAL_SECONDS = 30;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate');

        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';

        // Nur erlaubte Rollen dürfen den Badge sehen
        if (!in_array($this->userRole, self::ALLOWED_ROLES, true)) {
            echo json_encode([
                'kontakt'   => 0,
                'bewerbung' => 0,
                'total'     => 0,
                'interval'  => self::INTERVAL_SECONDS * 1000,
                'error'     => 'no_permission'
            ]);
            exit;
        }

        $this->handleRequest();
    }

    private function handleRequest(): void
    {
        $kontaktCount   = $this->countNewKontakte();
        $bewerbungCount = $this->countNewBewerbungen();

        echo json_encode([
            'kontakt'   => $kontaktCount,
            'bewerbung' => $bewerbungCount,
            'total'     => $kontaktCount + $bewerbungCount,
            'interval'  => self::INTERVAL_SECONDS * 1000
        ]);
    }

    /**
     * Zählt Kontaktanfragen mit Status 'neu'
     */
    private function countNewKontakte(): int
    {
        $result = $this->dbObj->sqlGet(
            "SELECT COUNT(*) AS anzahl
             FROM {$this->_prefix}etchat_kontakt
             WHERE etchat_status = :status",
            [':status' => 'neu']
        );

        return !empty($result) ? (int)$result[0]['anzahl'] : 0;
    }

    /**
     * Zählt Bewerbungen mit Status 'neu'
     */
    private function countNewBewerbungen(): int
    {
        $result = $this->dbObj->sqlGet(
            "SELECT COUNT(*) AS anzahl
             FROM {$this->_prefix}etchat_bewerbungen
             WHERE status = :status",
            [':status' => 'neu']
        );

        return !empty($result) ? (int)$result[0]['anzahl'] : 0;
    }
}