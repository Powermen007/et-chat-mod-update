tinymce.init({
  selector: "textarea#mytextarea",
  
  setup: function (editor) {
    var closing = false;

    // Überlauf-Menü ("...") nach Ausführen einer Funktion automatisch schließen
    editor.on('ExecCommand', function (e) {
      var cmd = String(e.command || '').toLowerCase();
      if (closing || cmd === 'toggletoolbardrawer' || cmd === 'mcefocus') return;

      closing = true;
      try {
        if (editor.queryCommandState('ToggleToolbarDrawer')) {
                    editor.execCommand('ToggleToolbarDrawer');
        }
      } finally {
        closing = false;
      }
    });
  },
  
  license_key: 'gpl',
  language: 'de',
  skin: 'oxide-dark',
  content_css: './js/tinymce/style.css?v=2',
  promotion: false,

  height: 400,
  min_height: 300,
  resize: true,

  menubar: 'file edit insert view format table tools help',
  menu: {
    file:   { title: 'Datei',       items: 'save pagebreak' },
    edit:   { title: 'Bearbeiten',  items: 'undo redo | cut copy paste | selectall | searchreplace' },
    view:   { title: 'Ansicht',     items: 'code | preview | visualaid visualchars visualblocks | fullscreen' },
    insert: { title: 'Einfügen',    items: 'image link media codesample | charmap emoticons hr | pagebreak nonbreaking' },
    format: { title: 'Format',      items: 'bold italic underline strikethrough superscript subscript | formats | removeformat' },
    tools:  { title: 'Extras',      items: 'wordcount | code' }
  },

  plugins: [
    "anchor", "accordion", "advlist", "preview", "autosave", "autolink",
    "charmap", "codesample", "code", "directionality", "emoticons", "help",
    "image", "link", "lists", "media", "save", "searchreplace", "table",
    "visualblocks", "visualchars", "wordcount", "fullscreen",
    "pagebreak", "nonbreaking"
  ],

  toolbar: "save | undo redo | code preview searchreplace fullscreen | " +
           "blocks fontfamily fontsize | bold italic underline forecolor backcolor | link image media | " +
           "alignleft aligncenter alignright alignjustify lineheight | bullist numlist indent outdent | " +
           "removeformat | accordion anchor | pagebreak nonbreaking",
		   
  images_upload_url: './js/tinymce/postAcceptor.php',
  images_upload_credentials: true,
  images_reuse_filename: true,
  automatic_uploads: true,
  paste_data_images: true,
  image_title: true,
  image_advtab: true,

  // Links/Bilder-Pfade nicht relativ zur Admin-Seite speichern
  relative_urls: false,
  remove_script_host: true,
  


  table_default_attributes: { border: '1' },
  table_default_styles: { borderCollapse: 'collapse', width: '100%' }
});