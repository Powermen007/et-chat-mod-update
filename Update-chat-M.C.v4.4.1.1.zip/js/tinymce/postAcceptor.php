<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

  /*********************************************
   * Change this line to set the upload folder *
   *********************************************/
  $imageFolder = "../../img/images/";

  /* ---------------------------------------------------------
   * Automatische Base-URL-Berechnung
   * Funktioniert in Root, Unterordnern und Subdomains,
   * weil sie aus dem echten Speicherort dieses Skripts abgeleitet wird.
   * --------------------------------------------------------- */
  $upLevels  = substr_count($imageFolder, '../');
  $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
  $basePath  = $scriptDir;
  for ($i = 0; $i < $upLevels; $i++) {
      $basePath = dirname($basePath);
  }
  if ($basePath === '/' || $basePath === '\\' || $basePath === '.') {
      $basePath = '';
  }
  $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
  $baseurl  = $protocol . $_SERVER['HTTP_HOST'] . $basePath . '/';

  /* ---------------------------------------------------------
   * CORS: nur Requests von der eigenen Domain erlauben.
   * Kein manuelles Eintragen von Domains nötig.
   * --------------------------------------------------------- */
  if (isset($_SERVER['HTTP_ORIGIN'])) {
    $originHost = parse_url($_SERVER['HTTP_ORIGIN'], PHP_URL_HOST);
    if ($originHost === $_SERVER['HTTP_HOST']) {
      header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
      header('Vary: Origin');
    } else {
      header("HTTP/1.1 403 Origin Denied");
      return;
    }
  }

  // Don't attempt to process the upload on an OPTIONS request
  if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header("Access-Control-Allow-Methods: POST, OPTIONS");
    return;
  }

  reset ($_FILES);
  $temp = current($_FILES);
  if (is_uploaded_file($temp['tmp_name'])){
    /*
      If your script needs to receive cookies, set images_upload_credentials : true in
      the configuration and enable the following two headers.
    */
    // header('Access-Control-Allow-Credentials: true');
    // header('P3P: CP="There is no P3P policy."');

    // Sanitize input
    if (preg_match("/([^\w\s\d\-_~,;:\[\]\(\).])|([\.]{2,})/", $temp['name'])) {
        header("HTTP/1.1 400 Invalid file name.");
        return;
    }

    // Verify extension
    if (!in_array(strtolower(pathinfo($temp['name'], PATHINFO_EXTENSION)), array("gif", "jpg", "jpeg", "png"))) {
        header("HTTP/1.1 400 Invalid extension.");
        return;
    }

    // Accept upload if there was no origin, or if it is an accepted origin
    $filetowrite = $imageFolder . $temp['name'];
    move_uploaded_file($temp['tmp_name'], $filetowrite);

    // $baseurl endet bereits auf "/", $filetowrite beginnt mit "../../"
    // -> die "../" entfernen, damit die zurückgegebene URL sauber ist
    $fileUrl = preg_replace('#^(\.\./)+#', '', $filetowrite);
    echo json_encode(array('location' => $baseurl . $fileUrl));
  } else {
    // Notify editor that the upload failed
    header("HTTP/1.1 500 Server Error");
  }
?>