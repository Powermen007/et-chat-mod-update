<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

  /*********************************************
   * Change this line to set the upload folder *
   *********************************************/
  $imageFolder = "../../img/images/";

  $maxBytes    = 5 * 1024 * 1024; // 5 MB
  $allowedExt  = ['gif', 'jpg', 'jpeg', 'png', 'webp'];
  $allowedMime = ['image/gif', 'image/jpeg', 'image/png', 'image/webp'];

  /* ---------------------------------------------------------
   * Nur Admins dürfen hochladen (Session wie im restlichen Chat)
   * --------------------------------------------------------- */
  if (session_status() !== PHP_SESSION_ACTIVE) {
      session_start();
  }
  $isAdmin = false;
  foreach ($_SESSION as $key => $value) {
      if (is_string($key)
          && str_starts_with($key, 'etchat_')
          && str_ends_with($key, 'user_priv')
          && $value === 'admin') {
          $isAdmin = true;
          break;
      }
  }
  session_write_close();
  if (!$isAdmin) {
      http_response_code(403);
      exit('Forbidden');
  }

  /* ---------------------------------------------------------
   * Automatische Base-URL-Berechnung
   * --------------------------------------------------------- */
  $upLevels  = substr_count($imageFolder, '../');
  $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
  $basePath  = $scriptDir;
  for ($i = 0; $i < $upLevels; $i++) {
      $basePath = dirname($basePath);
  }
  if ($basePath === '/' || $basePath === '\\' || $basePath === '.') {
      $basePath = '';
  }
  $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
  $baseurl  = $protocol . $_SERVER['HTTP_HOST'] . $basePath . '/';

  /* ---------------------------------------------------------
   * CORS: nur Requests von der eigenen Domain erlauben.
   * --------------------------------------------------------- */
  if (isset($_SERVER['HTTP_ORIGIN'])) {
      $originHost = parse_url($_SERVER['HTTP_ORIGIN'], PHP_URL_HOST);
      if ($originHost === $_SERVER['HTTP_HOST']) {
          header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
          header('Vary: Origin');
      } else {
          http_response_code(403);
          exit('Origin Denied');
      }
  }

  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
      header("Access-Control-Allow-Methods: POST, OPTIONS");
      exit;
  }
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      http_response_code(405);
      exit;
  }

  /* ---------------------------------------------------------
   * Upload prüfen
   * --------------------------------------------------------- */
  $temp = !empty($_FILES) ? current($_FILES) : null;
  if (!$temp
      || !isset($temp['tmp_name'], $temp['name'], $temp['error'])
      || $temp['error'] !== UPLOAD_ERR_OK
      || !is_uploaded_file($temp['tmp_name'])) {
      http_response_code(500);
      exit('Upload failed');
  }

  if ($temp['size'] > $maxBytes) {
      http_response_code(413);
      exit('File too large');
  }

  // Dateiname prüfen
  if (preg_match("/([^\w\s\d\-_~,;:\[\]\(\).])|([\.]{2,})/", $temp['name'])) {
      http_response_code(400);
      exit('Invalid file name.');
  }

  // Endung prüfen
  $ext = strtolower(pathinfo($temp['name'], PATHINFO_EXTENSION));
  if (!in_array($ext, $allowedExt, true)) {
      http_response_code(400);
      exit('Invalid extension.');
  }

  // Inhalt prüfen: muss wirklich ein Bild sein
  $info = @getimagesize($temp['tmp_name']);
  if ($info === false || !in_array($info['mime'], $allowedMime, true)) {
      http_response_code(400);
      exit('Invalid image.');
  }

  // Punkte im Namen entfernen (verhindert z.B. "x.php.png")
  $base = str_replace('.', '_', pathinfo($temp['name'], PATHINFO_FILENAME));

  // Vorhandene Dateien nicht überschreiben
  $filetowrite = $imageFolder . $base . '.' . $ext;
  $n = 1;
  while (file_exists($filetowrite)) {
      $filetowrite = $imageFolder . $base . '_' . $n . '.' . $ext;
      $n++;
  }

  if (!is_dir($imageFolder) || !move_uploaded_file($temp['tmp_name'], $filetowrite)) {
      http_response_code(500);
      exit('Could not save file');
  }

  // $baseurl endet bereits auf "/", $filetowrite beginnt mit "../../"
  $fileUrl = preg_replace('#^(\.\./)+#', '', $filetowrite);
  header('Content-Type: application/json');
  echo json_encode(['location' => $baseurl . $fileUrl]);