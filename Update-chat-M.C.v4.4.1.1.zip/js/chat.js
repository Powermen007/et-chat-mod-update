/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/
// Prototype $() Ersatz - Brückenfunktion für die Migration
function $X(id) {
    if (typeof id === 'string') {
        return document.getElementById(id);
    }
    return id; // Falls bereits ein DOM-Element übergeben wurde
}
// HTML-escape für sichere Nachrichtendarstellung
function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}
// Prototype unescapeHTML Ersatz
if (!String.prototype.unescapeHTML) {
    String.prototype.unescapeHTML = function() {
        var text = this;
        return text
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .replace(/&#39;/g, "'");
    };
}
// (start) Zentrale Dialog-Funktion - MULTI-DIALOG Version
var ChatDialog = {
    dialogs: [], // Array für mehrere Dialoge
    open: function(options) {
        // Standard-Optionen
        var showHeader = options.showHeader !== false;
        var className = options.className || '';
        var isModal = options.modal !== false;
        var isDraggable = options.draggable === true;
        var isResizable = options.resizable === true;
        // Neues <dialog> Element erstellen
        var dialog = document.createElement('dialog');
        dialog.className = 'modern-dialog ' + className;
        dialog.setAttribute('tabindex', '0');
        if (isResizable) dialog.classList.add('resizable');
        // Header HTML
        var headerHtml = '';
        if (showHeader) {
            headerHtml = `
                <div class="dialog-header ${isDraggable ? 'draggable-header' : ''}">
                    <span class="dialog-title">${options.title || 'Fenster'}</span>
                    <button class="dialog-close" aria-label="Schließen">&times;</button>
                    ${isResizable ? '<span class="resize-handle">⤡</span>' : ''}
                </div>
            `;
        }
        dialog.innerHTML = headerHtml + `
            <div class="dialog-content">
                ${options.html || '<div class="loading">Laden...</div>'}
            </div>
        `;
        // Schließen-Button (schließt NUR diesen Dialog)
        if (showHeader) {
            dialog.querySelector('.dialog-close').onclick = () => {
                this.closeDialog(dialog);
            };
        }
        // Bei Klick außerhalb schließen (nur bei modalen Dialogen)
        if (isModal) {
            dialog.addEventListener('click', (e) => {
                if (e.target === dialog) this.closeDialog(dialog);
            });
        }
        document.body.appendChild(dialog);
        // 🔥 NEU: Dialog in den Vordergrund holen, wenn auf den Titel oder den Dialog selbst geklickt wird
        var titleBar = dialog.querySelector('.dialog-header');
        if (titleBar) {
            titleBar.addEventListener('mousedown', function(e) {
                ChatDialog.focusDialog(dialog);
            });
        }
        // AUCH: Ganzer Dialog → Vordergrund
        dialog.addEventListener('mousedown', function(e) {
            // Nicht wenn man auf den Close-Button klickt
            if (e.target.classList && e.target.classList.contains('dialog-close')) return;
            ChatDialog.focusDialog(dialog);
        });
        // Dialog speichern
        var dialogInfo = {
            dialog: dialog,
            onClose: options.onClose,
            onOpen: options.onOpen
        };
        this.dialogs.push(dialogInfo);
        // NUR BEI PROFILE-DIALOG: Content-Bereich für Iframe optimieren
        if (className && className.includes('profile-dialog')) {
            var contentDiv = dialog.querySelector('.dialog-content');
            if (contentDiv) {
                contentDiv.style.padding = '0';
                contentDiv.style.display = 'flex';
                contentDiv.style.flexDirection = 'column';
                var iframe = contentDiv.querySelector('iframe');
                if (iframe) {
                    iframe.style.flex = '1';
                    iframe.style.width = '100%';
                    iframe.style.height = '100%';
                    iframe.style.border = 'none';
                }
            }
        }
        // Wenn URL angegeben, Inhalt laden
        if (options.url) {
            this.loadContent(dialog, options.url);
        }
        // Callback
        if (options.onOpen) options.onOpen(dialog);
        // Position für nicht-modale Dialoge
        if (!isModal) {
            // ===== NEU: Optionale Positionierung =====
            if (options.position) {
                dialog.style.position = 'absolute';
                dialog.style.top = options.position.top;
                dialog.style.left = options.position.left;
                dialog.style.transform = 'translate(-50%, -50%)';
                dialog.style.margin = '0';
                dialog.style.zIndex = options.position.zIndex || '10002'; // ← NEU
            } else {
                dialog.style.position = 'absolute';
                dialog.style.top = '50%';
                dialog.style.left = '50%';
                dialog.style.transform = 'translate(-50%, -50%)';
                dialog.style.margin = '0';
                dialog.style.zIndex = '10000';
            }
            dialog.show();
        } else {
            dialog.showModal();
        }
        // Draggable Funktionalität
        if (isDraggable && showHeader && !isModal) {
            this.makeDraggable(dialog, dialog.querySelector('.draggable-header'));
        }
        // Resizable Funktionalität
        if (isResizable && !isModal) {
            this.makeResizable(dialog);
        }
        // ===== ESC-Taste schließt Dialog (GLOBAL - funktioniert auch bei Iframes) =====
        if (!isModal) {
            var self = this;
            var dialogRef = dialog;
            // Globaler Keydown-Listener auf window (fängt ESC auch aus Iframes ab)
            function globalEscapeHandler(e) {
                if (e.key === 'Escape') {
                    if (dialogRef && dialogRef.isConnected) {
                        e.preventDefault();
                        e.stopPropagation();
                        self.closeDialog(dialogRef);
                        window.removeEventListener('keydown', globalEscapeHandler);
                    }
                }
            }
            // Für showModal() - cancel Event
            dialog.addEventListener('cancel', function(e) {
                e.preventDefault();
                e.stopPropagation();
                self.closeDialog(dialog);
            });
            // Globalen Listener für alle Tastaturevents
            window.addEventListener('keydown', globalEscapeHandler);
            // Original onClose erweitern, um Listener zu entfernen
            var originalOnClose = options.onClose;
            options.onClose = function() {
                window.removeEventListener('keydown', globalEscapeHandler);
                if (originalOnClose) originalOnClose();
            };
            // Fokus für nicht-modale Dialoge
            setTimeout(function() {
                dialog.focus();
            }, 100);
        }
        return dialog;
    },
    // Bringt einen bestimmten Dialog in den Vordergrund
    focusDialog: function(dialog) {
        if (!dialog) return;
        // Höchsten Z-Index aller Dialoge finden
        var maxZIndex = 10000;
        var dialogs = document.querySelectorAll('.modern-dialog');
        for (var i = 0; i < dialogs.length; i++) {
            var dlg = dialogs[i];
            var zIndex = parseInt(window.getComputedStyle(dlg).zIndex, 10);
            if (!isNaN(zIndex) && zIndex > maxZIndex) {
                maxZIndex = zIndex;
            }
        }
        // Diesen Dialog nach oben holen
        dialog.style.zIndex = maxZIndex + 1;
    },
    // Schließt einen bestimmten Dialog
    closeDialog: function(dialog) {
        for (var i = 0; i < this.dialogs.length; i++) {
            if (this.dialogs[i].dialog === dialog) {
                dialog.remove();
                if (this.dialogs[i].onClose) this.dialogs[i].onClose();
                this.dialogs.splice(i, 1);
                break;
            }
        }
    },
    // Kompatibilität: Schließt den zuletzt geöffneten Dialog
    close: function() {
        if (this.dialogs.length > 0) {
            var lastDialog = this.dialogs[this.dialogs.length - 1];
            lastDialog.dialog.remove();
            if (lastDialog.onClose) lastDialog.onClose();
            this.dialogs.pop();
        }
    },
    // Draggable Funktion mit Begrenzung auf sichtbaren Bereich
    makeDraggable: function(dialog, handle) {
        if (!handle) return;
        var isDragging = false;
        var offsetX = 0,
            offsetY = 0;
        handle.style.cursor = 'move';

        function convertToAbsolutePosition() {
            var computedStyle = window.getComputedStyle(dialog);
            var transform = computedStyle.transform;
            if (transform !== 'none' && transform.includes('matrix')) {
                var rect = dialog.getBoundingClientRect();
                var scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
                var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                var currentWidth = dialog.offsetWidth;
                var currentHeight = dialog.offsetHeight;
                dialog.style.position = 'absolute';
                dialog.style.top = (rect.top + scrollTop) + 'px';
                dialog.style.left = (rect.left + scrollLeft) + 'px';
                dialog.style.transform = 'none';
                dialog.style.margin = '0';
                dialog.style.width = currentWidth + 'px';
                dialog.style.height = currentHeight + 'px';
            }
        }
        // Clamp-Funktion für Begrenzung
        function clamp(value, min, max) {
            return Math.min(Math.max(value, min), max);
        }

        function onPointerMove(e) {
            if (!isDragging) return;
            e.preventDefault();
            var newLeft = e.clientX - offsetX;
            var newTop = e.clientY - offsetY;
            // Begrenzung auf sichtbaren Bereich
            var maxLeft = window.innerWidth - dialog.offsetWidth;
            var maxTop = window.innerHeight - dialog.offsetHeight;
            newLeft = clamp(newLeft, 0, maxLeft);
            newTop = clamp(newTop, 0, maxTop);
            dialog.style.left = newLeft + 'px';
            dialog.style.top = newTop + 'px';
        }

        function stopDragging() {
            if (!isDragging) return;
            isDragging = false;
            document.body.style.userSelect = '';
        }
        handle.addEventListener('pointerdown', function(e) {
            if (e.target.classList.contains('dialog-close')) return;
            if (e.target.classList.contains('resize-handle')) return;
            if (e.target.classList.contains('smiley-popup-button')) return;
            if (e.target.classList.contains('admin-popup-button')) return;
            if (e.target.classList.contains('private-popup-button')) return;
            e.preventDefault();
            convertToAbsolutePosition();
            var rect = dialog.getBoundingClientRect();
            offsetX = e.clientX - rect.left;
            offsetY = e.clientY - rect.top;
            isDragging = true;
            document.body.style.userSelect = 'none';
            if (handle.setPointerCapture) {
                handle.setPointerCapture(e.pointerId);
            }
        });
        handle.addEventListener('pointermove', onPointerMove);
        handle.addEventListener('pointerup', stopDragging);
        handle.addEventListener('pointercancel', stopDragging);
        // zusätzliche Sicherheit
        window.addEventListener('blur', stopDragging);
    },
    // Resizable Funktion
    makeResizable: function(dialog) {
        var resizeHandle = dialog.querySelector('.resize-handle');
        if (!resizeHandle) return;
        resizeHandle.style.cursor = 'nw-resize';
        resizeHandle.style.position = 'absolute';
        resizeHandle.style.bottom = '8px';
        resizeHandle.style.right = '10px';
        resizeHandle.style.fontSize = '14px';
        resizeHandle.style.zIndex = '10001';
        var startX, startY, startWidth, startHeight;
        var isResizing = false;

        function onPointerMove(e) {
            if (!isResizing) return;
            var newWidth = startWidth + (e.clientX - startX);
            var newHeight = startHeight + (e.clientY - startY);
            if (newWidth > 280) {
                dialog.style.width = newWidth + 'px';
                dialog.style.maxWidth = 'none';
                dialog.style.minWidth = '280px';
            }
            if (newHeight > 200) {
                dialog.style.height = newHeight + 'px';
                dialog.style.maxHeight = 'none';
            }
        }

        function stopResize() {
            if (!isResizing) return;
            isResizing = false;
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
        }
        resizeHandle.addEventListener('pointerdown', function(e) {
            e.preventDefault();
            e.stopPropagation();
            isResizing = true;
            startX = e.clientX;
            startY = e.clientY;
            startWidth = dialog.offsetWidth;
            startHeight = dialog.offsetHeight;
            document.body.style.cursor = 'nw-resize';
            document.body.style.userSelect = 'none';
            // Sorgt dafür, dass pointermove/pointerup
            // auch außerhalb des Elements weiter ankommen
            resizeHandle.setPointerCapture(e.pointerId);
        });
        resizeHandle.addEventListener('pointermove', onPointerMove);
        resizeHandle.addEventListener('pointerup', stopResize);
        resizeHandle.addEventListener('pointercancel', stopResize);
        // Zusätzliche Sicherheit
        window.addEventListener('blur', stopResize);
    },
    loadContent: function(dialog, url) {
        var content = dialog.querySelector('.dialog-content');
        content.innerHTML = '<div class="loading">' + lang_loading + '</div>';
        fetch(url, {
                credentials: 'same-origin'
            })
            .then(res => res.text())
            .then(html => {
                content.innerHTML = html;
                this.executeScripts(content);
            })
            .catch(err => {
                content.innerHTML = '<div class="error">' + lang_loading_error + '</div>';
            });
    },
    executeScripts: function(container) {
        var scripts = container.querySelectorAll('script');
        scripts.forEach(function(oldScript) {
            var newScript = document.createElement('script');
            newScript.textContent = oldScript.textContent;
            oldScript.parentNode.replaceChild(newScript, oldScript);
        });
    }
};
// (stop) Zentrale Dialog-Funktion
// ========== NEU: Flag für laufenden Raumwechsel ==========
var roomChangeInProgress = false;
// Globale Funktion für Passwort-Sichtbarkeit (einmalig definiert)
window.togglePasswordVisibility = function(inputId) {
    var input = document.getElementById(inputId);
    var toggleBtn = input ? input.parentNode.querySelector('.password-toggle') : null;
    if (input) {
        if (input.type === "password") {
            input.type = "text";
            if (toggleBtn) toggleBtn.innerHTML = "🙈";
        } else {
            input.type = "password";
            if (toggleBtn) toggleBtn.innerHTML = "👁️";
        }
    }
};
// ============================================================
// NEUE EINHEITLICHE COOKIE-FUNKTIONEN (ersetzt die alten)
// ============================================================
// Speichern ALLER Optionen in EINEM Cookie
function saveUserOptions(username, options) {
    if (!username) return;
    var key = 'saved_options_' + username;
    try {
        var jsonString = JSON.stringify(options);
        // Für 30 Tage speichern
        var expires = new Date();
        expires.setTime(expires.getTime() + 30 * 24 * 60 * 60 * 1000);
        var secure = (window.location.protocol === 'https:') ? ';Secure' : '';
        document.cookie = key + '=' + encodeURIComponent(jsonString) +
            ';expires=' + expires.toUTCString() +
            ';path=/;SameSite=Lax' + secure;
    } catch (e) {
        console.warn('Cookie speichern fehlgeschlagen:', e);
    }
}
// Laden ALLER Optionen aus EINEM Cookie
function loadUserOptions(username) {
    if (!username) return null;
    var key = 'saved_options_' + username;
    var raw = getCookie(key);
    if (!raw) return null;
    try {
        return JSON.parse(decodeURIComponent(raw));
    } catch (e) {
        return null;
    }
}
// Einzelne Option laden (mit Default-Wert)
function getUserOption(username, optionName, defaultValue) {
    var options = loadUserOptions(username);
    if (options && options[optionName] !== undefined) {
        return options[optionName];
    }
    return defaultValue;
}
// Einzelne Option setzen (andere bleiben erhalten)
function setUserOption(username, optionName, value) {
    if (!username) return;
    var options = loadUserOptions(username) || {};
    options[optionName] = value;
    saveUserOptions(username, options);
}

function ET_Chat() {
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Deklaration globaler Attribute im Class ------------------------------------------------------------
    var self = this;
    this.u_bild; // Avatar An / Aus
    this.radio_wb_li; //Link zur Box
    this.co_admin; // Onlineliste Farbe Admin
    this.co_mod; // Onlineliste Farbe User
    this.co_user; // Onlineliste Farbe User
    this.co_gast; // Onlineliste Farbe Gast
    this.time_last_req = 0; //(privat) Zeit im Milisek seit der letzten AJAX-Anfrage
    this.time_last_send = 0; //(privat) Zeit im Milisek seit der letzten Message from User
    this.inactivity_message_flag = false; //(privat) TRUE wenn bereits eine Systemwarnmeldung an den User gesendet wurde
    this.active_get_message_req = false; //(privat) TRUE wenn gerade eine ReloaderMessage Anfrage ueber AJAX laeuft
    this.interval_for_inactivity = 1800000; //(public) Wie lange darf der User nichts schreiben bis er aus dem Chat rausfliegt
    this.TAB_AWAY_DELAY = 150; // Wie lange darf der user den tap im hintergrund haben bis es angezeigt wird
    this.allowed_privates_in_separate_win = true;
    this.allowed_privates_in_chat_win = true;
    this.anbindung_an_userverwaltung; //(privat) Wenn die Userverwaltung benutzt wird, soll der Mon kein PW ändern
    this.reload_interval; //(public) Reloadzeit
    this.show_history_all_user; //(public) [bool] Soll die History fuer alle Gezeigt wrden oder nur Admin/Mod-Team
    this.allow_nick_registration; //(public) [bool] Registrierung der Namen erlauben
    this.set_sys_messages = true; //(public) [bool] Show sys messages
    this.messages_im_chat; //(public) Anz. der Mess. im Fenster
    this.username = ""; //(public)
    this.user_id = ""; //(public)
    this.set_dynamic_height; //(public)
    this.textcolor; //(public)
    this.mouse_top = 0; //(privat) Cursorkoordueberwachung
    this.mouse_left = 0; //(privat) Cursorkoordueberwachung
    this.win_block = Array(); //(privat) Window-Object-Array zum Userblokieren
    this.win_block_ids = Array();
    this.win_private = []; //(privat) Window-Object-Array private message window
    this.win_color_content; //(privat) Inhalt des Colorfensters wird ueber AJAX onLoad gefuellt
    this.jsonObjUserGlobal; //(privat) Message JSON Array.
    this.userPrivilegienGlobal; //(public) Privilegien z.B.: Gast,User,Moderator,Admin
    this.privat_an; //(privat) Privat an User-ID
    this.sound_status = "none"; //(privat) Wann soll der Sound kommen, bei allen Messages oder nur Privat
    this.soundManager;
    this.audioBuffer = Array();
    this.random_user_number; //(public) generated user number to protect http GET requests
    this.title = document.title;
    this.intv_title_blink;
    this.window_focused = true;
    this.set_an_time = true; // Im Chatfenster Post Zeit An / Aus
    this.set_ch_an_gender; // Im Chatfenster User Gender geschlecht An / Aus
    this.set_ch_an_privi; // Im Chatfenster User Privilegen An / Aus
    this.set_ol_an_privi; // In der Onlineliste User Privilegen An / Aus
    this.set_be_info_pic; // Avatar PIC An / Aus bei Benutzerinfo
    this.set_chat_pic; //Avatar PIC im Chat An / Aus
    this.set_wuza; //Würfel anzahl bis Pause
    this.set_wupau; //Pause minuten
    this.set_dj_box_li; //DJ Box Link
    this.set_dj_box; //DJ Bos An / Aus
    this.set_sendeplan_li; //Sendeplan Link
    this.set_sendeplan; //Sendeplan An / Aus
    this.set_chatbot; // ChatBot An/Aus
    // ============================================================
    // NEU: Cache für Nachrichten-Optimierung
    // ============================================================
    this.lastMessageId = null; // Letzte bekannte Message-ID

    // (Start) Das Schreibfeld nach Versand wieder freigeben ------------------------------------------------------
    var let_write = function() {
        $X('message').disabled = false;
        $X('message').value = "";
        $X('message').focus();
    };
    // (Stop) Das Schreibfeld nach Versand wieder freigeben -------------------------------------------------------

    // ============================================================
    // (Stop) Deklaration globaler Attribute im Class -------------------------------------------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // Generiert einen eindeutigen Key für ein Privat-Chat-Paar
    this.getPrivateDialogKey = function(userId1, userId2) {
        // Sortiere IDs, damit der Key immer gleich ist (user1+user2)
        var ids = [String(userId1), String(userId2)].sort();
        return ids[0] + '_' + ids[1];
    };
    this.renderPrivateMessageHtml = function(item, isOwn) {
        var user_id = item.user_id || '';
        var time = item.time || '';
        var message = item.message || '';
        var user = item.user || '';
        var attrs = ' data-user-id="' + escapeHtml(String(user_id)) + '"' +
            ' data-time="' + escapeHtml(time) + '"' +
            ' data-message="' + escapeHtml(message) + '"';
        // 🔥 Einheitliches Format: immer linksbündig, immer "Name: Nachricht"
        var displayUser = isOwn ? escapeHtml(self.username) : escapeHtml(user);
        return '<div class="private-message"' + attrs + ' style="text-align:left; margin:4px 0;">' +
            '<span style="background:#444; padding:8px 12px; border-radius:18px; display:inline-block; max-width:80%; word-wrap:break-word;">' +
            '<b style="color:#5cb85c;">' + displayUser + ':</b> ' + message + '</span>' +
            '</div>';
    };
    // Speichert den Inhalt eines Privat-Chat-Dialogs
    this.savePrivateDialogContent = function(key, contentHtml, scrollTop) {
        var data = {
            html: contentHtml,
            scrollTop: scrollTop || 0,
            timestamp: Date.now()
        };
        try {
            localStorage.setItem('priv_dlg_' + key, JSON.stringify(data));
        } catch (e) {
            console.warn('[savePrivateDialogContent] localStorage voll?', e);
        }
    };
    // Lädt gespeicherten Inhalt eines Privat-Chat-Dialogs
    this.loadPrivateDialogContent = function(key) {
        var raw = localStorage.getItem('priv_dlg_' + key);
        if (!raw) return null;
        try {
            var data = JSON.parse(raw);
            if (data && data.html) {
                return data;
            }
        } catch (e) {}
        return null;
    };
    // Löscht ALLE privaten Chat-Verläufe (beim Logout)
    this.clearAllPrivateChatHistory = function() {
        var keysToRemove = [];
        // Suche alle localStorage Einträge mit 'priv_dlg_'
        for (var i = 0; i < localStorage.length; i++) {
            var key = localStorage.key(i);
            if (key && key.indexOf('priv_dlg_') === 0) {
                keysToRemove.push(key);
            }
        }
        // Lösche alle gefundenen Einträge
        for (var j = 0; j < keysToRemove.length; j++) {
            localStorage.removeItem(keysToRemove[j]);
        }
    };
    // (Start) Konstruktor der Class ET_Chat wird onLoad ausgefuehrt -----------------------------------------------
    this.start = function() {
        if (!self.win_private) self.win_private = [];
        // --- TAB_AWAY_DELAY absichern & umrechnen ---
        var MIN_TAB_AWAY_DELAY = 150;
        var MAX_TAB_AWAY_DELAY = 1200;
        self.TAB_AWAY_DELAY = parseInt(self.TAB_AWAY_DELAY, 10) || MIN_TAB_AWAY_DELAY;
        // Clamp zwischen Min und Max
        self.TAB_AWAY_DELAY = Math.min(Math.max(self.TAB_AWAY_DELAY, MIN_TAB_AWAY_DELAY), MAX_TAB_AWAY_DELAY);
        self.TAB_AWAY_DELAY_MS = self.TAB_AWAY_DELAY * 1000;
        // Cookie Sound lesen und Status neu setzen
        let savedSound = getUserOption(self.username, 'sound', null);
        if (savedSound) {
            this.sound_status = savedSound;
        }
        // Passende Sound Icon setzen, sobald DOM geladen ist
        document.addEventListener("DOMContentLoaded", function() {
            if ($X('sound_icon')) {
                switch (self.sound_status) {
                    case "none":
                        $X('sound_icon').src = "img/sound_none.png";
                        break;
                    case "all":
                        $X('sound_icon').src = "img/sound_all.png";
                        break;
                    case "privat":
                        $X('sound_icon').src = "img/sound_privat.png";
                        break;
                }
            }
        });
        // start tabanzeige neue mitteilung
        // UI-Fokus (Titel, Blinken etc.)
        window.addEventListener("focus", () => {
            self.window_focused = true;
            try {
                clearInterval(self.intv_title_blink);
            } catch (e) {}
            document.title = self.title;
        });
        window.addEventListener("blur", () => {
            self.window_focused = false;
        });
        // ===== Status-Logik
        let tabHiddenTimer = null;
        let tabIsAway = false;
        let pageLoaded = true;
        // ===== visibilitychange
        document.addEventListener("visibilitychange", () => {
            if (!pageLoaded) return;
            if (document.hidden) {
                if (!tabHiddenTimer) {
                    tabHiddenTimer = setTimeout(() => {
                        if (!tabIsAway) {
                            tabIsAway = true;
                            fetch("./?TabFocus&ajax=1&mode=away", {
                                method: "POST"
                            }).catch(() => {}); // Fehler still ignorieren
                        }
                    }, self.TAB_AWAY_DELAY_MS);
                }
            } else {
                if (tabHiddenTimer) {
                    clearTimeout(tabHiddenTimer);
                    tabHiddenTimer = null;
                }
                if (tabIsAway) {
                    tabIsAway = false;
                    fetch("./?TabFocus&ajax=1&mode=back", {
                        method: "POST"
                    }).catch(() => {});
                }
            }
        });
        // ende Tabanzeige neue mitteilung
        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // (Anfang) ---------------------------------------------------------------------------------------------------
        // ============================================================
        // GEMEINSAME FUNKTIONEN
        // ============================================================
        // Gemeinsame Funktion für Admin-Dialog (für Admin, co_admin, grafik, chatwache)
        function openAdminDialog() {
            // Prüfen ob bereits ein Admin-Dialog offen ist
            var existingDialog = document.querySelector('.admin-dialog');
            if (existingDialog && existingDialog.isConnected) {
                ChatDialog.closeDialog(existingDialog);
                return;
            }
            ChatDialog.open({
                title: lang_dialog_admin,
                showHeader: true,
                modal: false,
                draggable: true,
                resizable: true,
                className: "admin-dialog",
                html: '<iframe src="./?AdminIndex" style="width:100%; height:100%; border:none;"></iframe>',
                onOpen: function(dialog) {
                    // Breite anpassen
                    dialog.style.width = '1250px';
                    dialog.style.maxWidth = '90vw';
                    // Höhe des Dialogs anpassen
                    setTimeout(function() {
                        // Prüfen ob Dialog noch existiert
                        if (!dialog || !dialog.isConnected) return;
                        var header = dialog.querySelector('.dialog-header');
                        var headerHeight = header ? header.offsetHeight : 50;
                        var targetHeight = Math.min(window.innerHeight * 0.75, 750);
                        // Weitere Prüfungen vor DOM-Zugriffen
                        if (!dialog.isConnected) return;
                        dialog.style.height = targetHeight + 'px';
                        dialog.style.minHeight = '400px';
                        var contentDiv = dialog.querySelector('.dialog-content');
                        if (contentDiv) {
                            contentDiv.style.height = (targetHeight - headerHeight - 4) + 'px';
                            contentDiv.style.minHeight = (targetHeight - headerHeight - 4) + 'px';
                        }
                    }, 50);
                    // ===== Popup-Button in die Title-Leiste einfügen =====
                    var titleBar = dialog.querySelector('.dialog-header');
                    if (titleBar && !titleBar.querySelector('.admin-popup-button')) {
                        var popupBtn = document.createElement('button');
                        popupBtn.className = 'admin-popup-button';
                        popupBtn.innerHTML = '📂';
                        popupBtn.title = lang_dialog_admin_popup;
                        popupBtn.style.cssText = 'background:none; border:none; cursor:pointer; font-size:18px; margin-left:10px; padding:0 5px; opacity:0.7;';
                        popupBtn.onmouseover = function() {
                            this.style.opacity = '1';
                        };
                        popupBtn.onmouseout = function() {
                            this.style.opacity = '0.7';
                        };
                        popupBtn.onclick = function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            window.open('./?AdminIndex', 'AdminPopup', 'width=1200,height=800,resizable=yes,scrollbars=yes,left=100,top=50');
                        };
                        var closeBtn = titleBar.querySelector('.dialog-close');
                        if (closeBtn) {
                            titleBar.insertBefore(popupBtn, closeBtn);
                        } else {
                            titleBar.appendChild(popupBtn);
                        }
                    }
                    // ===== ESC-Taste auch aus dem Iframe abfangen =====
                    var iframe = dialog.querySelector('iframe');
                    if (iframe) {
                        iframe.addEventListener('load', function() {
                            try {
                                var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                                if (iframeDoc) {
                                    iframeDoc.addEventListener('keydown', function(e) {
                                        if (e.key === 'Escape') {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            ChatDialog.closeDialog(dialog);
                                        }
                                    });
                                }
                            } catch (e) {}
                        });
                    }
                    // Resize-Observer für dynamische Anpassung
                    var resizeObserver = new ResizeObserver(function() {
                        var header = dialog.querySelector('.dialog-header');
                        var headerHeight = header ? header.offsetHeight : 50;
                        var dialogHeight = dialog.offsetHeight;
                        var contentDiv = dialog.querySelector('.dialog-content');
                        if (contentDiv) {
                            contentDiv.style.height = (dialogHeight - headerHeight - 4) + 'px';
                        }
                    });
                    resizeObserver.observe(dialog);
                    // 🔥 Observer speichern
                    dialog._resizeObserver = resizeObserver;
                },
                // 🔥 WICHTIG: onClose MUSS hier IN den options sein!
                onClose: function(dialog) {
                    // ResizeObserver aufräumen
                    if (dialog && dialog._resizeObserver) {
                        dialog._resizeObserver.disconnect();
                        delete dialog._resizeObserver;
                    }
                }
            });
        }
        // Gemeinsame Funktion für DJ Box (für Admin, co_admin, mod)
        function openDjBox() {
            // Prüfen ob bereits ein DJ-Dialog offen ist
            var existingDialog = document.querySelector('.djbox-dialog');
            if (existingDialog && existingDialog.isConnected) {
                ChatDialog.closeDialog(existingDialog);
                return;
            }
            // 🔥 Jetzt mit self.set_dj_box_li (flexibel für Admin!)
            var djBoxUrl = self.set_dj_box_li || './?AdminWunschbox'; // Fallback, falls leer
            ChatDialog.open({
                title: lang_dialog_djbox || '🎵 DJ Box',
                showHeader: true,
                modal: false,
                draggable: true,
                resizable: true,
                className: "djbox-dialog",
                html: '<iframe src="' + djBoxUrl + '" style="width:100%; height:100%; border:none;"></iframe>',
                onOpen: function(dialog) {
                    // Breite anpassen
                    dialog.style.width = '1250px';
                    dialog.style.maxWidth = '90vw';
                    // Höhe anpassen
                    setTimeout(function() {
                        if (!dialog || !dialog.isConnected) return;
                        var header = dialog.querySelector('.dialog-header');
                        var headerHeight = header ? header.offsetHeight : 50;
                        var targetHeight = Math.min(window.innerHeight * 0.75, 750);
                        if (!dialog.isConnected) return;
                        dialog.style.height = targetHeight + 'px';
                        dialog.style.minHeight = '400px';
                        var contentDiv = dialog.querySelector('.dialog-content');
                        if (contentDiv) {
                            contentDiv.style.height = (targetHeight - headerHeight - 4) + 'px';
                            contentDiv.style.minHeight = (targetHeight - headerHeight - 4) + 'px';
                        }
                    }, 50);
                    // ===== Popup-Button im Header (wie beim Admin!) =====
                    var titleBar = dialog.querySelector('.dialog-header');
                    if (titleBar && !titleBar.querySelector('.dj-popup-button')) {
                        var popupBtn = document.createElement('button');
                        popupBtn.className = 'dj-popup-button';
                        popupBtn.innerHTML = '📂';
                        popupBtn.title = 'DJ Box in einem separaten Popup-Fenster öffnen';
                        // 🔥 Button-Stil mit Schutz vor Drag
                        popupBtn.style.cssText = `
                    background: none;
                    border: none;
                    cursor: pointer;
                    font-size: 18px;
                    margin-left: 10px;
                    padding: 0 5px;
                    opacity: 0.7;
                    position: relative;
                    z-index: 99999;
                    pointer-events: auto !important;
                `;
                        // 🔥 Drag-Events komplett ignorieren
                        popupBtn.addEventListener('pointerdown', function(e) {
                            e.stopPropagation();
                        });
                        popupBtn.addEventListener('mousedown', function(e) {
                            e.stopPropagation();
                        });
                        // 🔥 Click-Event – mit self.set_dj_box_li (Fallback)
                        popupBtn.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            // 🔥 Für das Popup verwenden wir die gleiche URL
                            var popupUrl = self.set_dj_box_li || './?AdminWunschbox';
                            // 🔥 Falls die URL relativ ist, mache sie absolut
                            if (popupUrl.indexOf('http') !== 0 && popupUrl.indexOf('/') !== 0) {
                                popupUrl = window.location.origin + window.location.pathname + popupUrl.replace(/^\.\//, '');
                            }
                            window.open(popupUrl, 'DJBoxPopup', 'width=1200,height=800,resizable=yes,scrollbars=yes,left=100,top=50');
                        });
                        // Hover-Effekte
                        popupBtn.addEventListener('mouseover', function() {
                            this.style.opacity = '1';
                        });
                        popupBtn.addEventListener('mouseout', function() {
                            this.style.opacity = '0.7';
                        });
                        // 🔥 Button VOR dem Close-Button einfügen
                        var closeBtn = titleBar.querySelector('.dialog-close');
                        if (closeBtn) {
                            titleBar.insertBefore(popupBtn, closeBtn);
                        } else {
                            titleBar.appendChild(popupBtn);
                        }
                    }
                    // ===== ESC-Taste auch aus dem Iframe abfangen =====
                    var iframe = dialog.querySelector('iframe');
                    if (iframe) {
                        iframe.addEventListener('load', function() {
                            try {
                                var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                                if (iframeDoc) {
                                    iframeDoc.addEventListener('keydown', function(e) {
                                        if (e.key === 'Escape') {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            ChatDialog.closeDialog(dialog);
                                        }
                                    });
                                }
                            } catch (e) {}
                        });
                    }
                    // Resize-Observer
                    var resizeObserver = new ResizeObserver(function() {
                        var header = dialog.querySelector('.dialog-header');
                        var headerHeight = header ? header.offsetHeight : 50;
                        var dialogHeight = dialog.offsetHeight;
                        var contentDiv = dialog.querySelector('.dialog-content');
                        if (contentDiv) {
                            contentDiv.style.height = (dialogHeight - headerHeight - 4) + 'px';
                        }
                    });
                    resizeObserver.observe(dialog);
                    dialog._resizeObserver = resizeObserver;
                },
                onClose: function(dialog) {
                    if (dialog && dialog._resizeObserver) {
                        dialog._resizeObserver.disconnect();
                        delete dialog._resizeObserver;
                    }
                }
            });
        }
        // ============================================================
        // START ADMIN BOX (Admin + co_admin)
        // ============================================================
        if (self.userPrivilegienGlobal == "admin" || self.userPrivilegienGlobal == "co_admin") {
            // Buttons einfügen
            if (self.set_dj_box == 1) {
                $X("form_right").innerHTML += "<img id='link_admin' class='img_button' src='img/admin.png' width='32' height='32' border='0' alt='Admin' title='Admin'>   <img id='dj_box' class='img_button' src='img/djbox.png' width='34' height='32' border='0' alt='DJ Box' title='DJ Box'>";
            } else {
                $X("form_right").innerHTML += "<img id='link_admin' class='img_button' src='img/admin.png' width='32' height='32' border='0' alt='Admin' title='Admin'><img id='dj_box'>";
            }
            // Event-Listener
            $X("link_admin").onclick = function() {
                openAdminDialog();
            };
            $X("dj_box").onclick = function() {
                openDjBox();
            };
        }
        // ============================================================
        // BOX FÜR GRAFIK & CHATWACHE (nur Admin, keine DJ Box)
        // ============================================================
        if (self.userPrivilegienGlobal == "grafik" || self.userPrivilegienGlobal == "chatwache") {
            $X("form_right").innerHTML += "   <img id='admin_box' class='img_button' src='img/admin.png' width='34' height='32' border='0' alt='Admin Box' title='Admin Box'>";
            $X("admin_box").onclick = function() {
                openAdminDialog();
            };
        }
        // ============================================================
        // DJ BOX FÜR MOD (nur DJ Box, kein Admin)
        // ============================================================
        if (self.userPrivilegienGlobal == "mod" && self.set_dj_box == 1) {
            $X("form_right").innerHTML += "   <img id='dj_box' class='img_button' src='img/djbox.png' width='34' height='32' border='0' alt='DJ Box' title='DJ Box'>";
            $X("dj_box").onclick = function() {
                openDjBox();
            };
        }
        // Klick auf Team Box
        $X("link_team").onclick = function() {
            ChatDialog.open({
                title: lang_dialog_team,
                showHeader: true,
                className: "extra-wide",
                html: '<iframe src="./?TeamView" style="width:100%; height:60vh; border:none;"></iframe>'
            });
        };
		// Ende Team Box
        // Klick auf Bewerbung Box
        $X("link_bewerbung").onclick = function() {
            ChatDialog.open({
                title: lang_dialog_bewerbung,
                showHeader: true,
                className: "extra-wide",
                html: '<iframe src="bewerbung.php" style="width:100%; height:60vh; border:none;"></iframe>'
            });
        };
        //Ende Bewerbung Box
        // Klick auf Wunschbox
        $X("Wunschbox").onclick = function() {
            // Wunschbox-Dialog mit Iframe öffnen
            ChatDialog.open({
                title: lang_dialog_wunschbox,
                showHeader: true,
                className: "wide wunschbox-dialog",
                html: '<iframe src="' + self.radio_wb_li + '" style="width:100%; height:60vh; border:none;"></iframe>'
            });
        };
        //Ende Wunschbox
        // Klick auf TS 3
        $X("ts3").onclick = function() {
            // TS 3-Dialog mit Iframe öffnen
            ChatDialog.open({
                title: "Teamspeak 3",
                showHeader: true,
                className: "wide wunschbox-dialog",
                html: '<iframe src="./?Teamspeak" style="width:100%; height:60vh; border:none;"></iframe>'
            });
        };
        //Ende TS 3
        // Klick auf Sendeplan
        $X("Sendeplan").onclick = function() {
            // Sendeplan-Dialog mit Iframe öffnen
            ChatDialog.open({
                title: lang_dialog_sendeplan,
                showHeader: true,
                className: "extra-wide",
                html: '<iframe src="' + self.set_sendeplan_li + '" style="width:100%; height:70vh; border:none;"></iframe>'
            });
        };
        //Ende Sendeplan
        // // Klick auf Titel-Liste (extra-wide)
        $X("link_titellist").onclick = function() {
            ChatDialog.open({
                title: lang_dialog_titellist,
                showHeader: true,
                className: "extra-wide",
                html: '<iframe src="radio-box/radio-box-titel.php" style="width:100%; height:70vh; border:none;"></iframe>'
            });
        };
        //Ende Titel-Liste
        // // Klick auf Top-Liste (extra-wide)
        $X("top_list").onclick = function() {
            ChatDialog.open({
                title: lang_dialog_toplist,
                showHeader: true,
                className: "extra-wide",
                html: '<iframe src="?TopList" style="width:100%; height:70vh; border:none;"></iframe>'
            });
        };
        //Ende Top Liste
		// Klick auf Info-Link (Version im Footer)
		$X("link_info").onclick = function(e) {
			if (e) e.preventDefault();
			ChatDialog.open({
				title: (typeof lang_dialog_info !== 'undefined') ? lang_dialog_info : 'Info',
				showHeader: true,
				className: "wide",
				html: '<iframe src="./?Info" style="width:100%; height:60vh; border:none;"></iframe>'
			});
			return false;
		};
		// Ende Info-Link
        // Start Gäste Fenster hinweiss (nur einmal alle 4 Stunden)
        setTimeout(function() {
            if (typeof self !== "undefined" && self.userPrivilegienGlobal === "gast") {
                var now = Date.now();
                var lastShown = localStorage.getItem("gastFensterGezeigt");
                // Prüfen, ob das Fenster noch nie oder vor mehr als 4 Stunden gezeigt wurde
                if (!lastShown || now - parseInt(lastShown) > 4 * 60 * 60 * 1000) {
                    // Gast-Willkommens-Dialog mit Iframe
                    if (typeof self.win_gast !== "object" || !self.win_gast) {
                        self.win_gast = ChatDialog.open({
                            title: lang_dialog_welcome_gast,
                            showHeader: true,
                            className: "wide",
                            html: '<iframe src="./?Text&id=5" style="width:100%; height:60vh; border:none;"></iframe>',
                            onClose: function() {
                                self.win_gast = null;
                            }
                        });
                    } else {
                        // Falls schon offen, nach vorne holen
                        if (self.win_gast && self.win_gast.currentDialog) {
                            self.win_gast.currentDialog.showModal();
                        }
                    }
                    // Zeitstempel speichern
                    localStorage.setItem("gastFensterGezeigt", now.toString());
                }
            }
        }, 1000); // Einmalig nach 1 Sekunde
        // ende Gäste Fenster hinweiss
        // Gallery
        const allowedRoles = ["admin", "mod", "user", "grafik", "chatwache", "co_admin"];
        if (allowedRoles.includes(self.userPrivilegienGlobal)) {
            // Gallery (als Iframe im Dialog – sicher durch serverseitige Prüfung)
            $X("link_gallery").onclick = function() {
                const role = self.userPrivilegienGlobal;
                if (role === "gast") {
                    alert(lang_error_only_registered);
                    return;
                }
                ChatDialog.open({
                    title: lang_dialog_gallery,
                    showHeader: true,
                    className: "extra-wide gallery-dialog",
                    html: '<iframe src="./?Gallery" style="width:100%; height:70vh; border:none;"></iframe>'
                });
            };
        }
        //Ende Gallery
        // Benutzer Profil Edit - Mit richtiger Höhenbegrenzung
        if (self.userPrivilegienGlobal !== "gast") {
            $X("link_profil").onclick = function() {
                // Prüfen ob bereits ein Profil-Dialog offen ist
                var existingDialog = document.querySelector('.profile-dialog');
                if (existingDialog && existingDialog.isConnected) {
                    ChatDialog.closeDialog(existingDialog);
                    return;
                }
                var maxHeight = Math.min(window.innerHeight * 0.8, 800);
                var headerHeight = 60; // Schätzwert für Header
                var contentHeight = maxHeight - headerHeight;
                var dialog = ChatDialog.open({
                    title: lang_dialog_profil,
                    showHeader: true,
                    modal: false,
                    draggable: true,
                    resizable: true,
                    className: "profile-dialog wide",
                    html: '<div style="height: ' + contentHeight + 'px; display: flex; flex-direction: column;"><iframe src="./?EditProfil" style="width:100%; height:100%; border:none; flex:1;"></iframe></div>',
                    onOpen: function(dialog) {
                        // ===== NEU: Breite dynamisch anpassen (mobil/desktop) =====
                        const isMobile = window.matchMedia("(max-width: 768px)").matches;
                        if (isMobile) {
                            dialog.style.width = '95vw';
                            dialog.style.minWidth = '280px';
                        } else {
                            dialog.style.width = '750px';
                            dialog.style.minWidth = '350px';
                        }
                        dialog.style.maxWidth = '95vw';
                        // ===== ENDE NEU =====
                    }
                });
                // Nach dem Öffnen die genaue Höhe korrigieren
                setTimeout(function() {
                    // Prüfen ob Dialog noch existiert
                    if (!dialog || !dialog.isConnected) return;
                    var header = dialog.querySelector('.dialog-header');
                    var headerHeightActual = header ? header.offsetHeight : 50;
                    var dialogHeight = dialog.offsetHeight;
                    var availableHeight = dialogHeight - headerHeightActual - 4;
                    var wrapper = dialog.querySelector('.dialog-content > div');
                    if (wrapper) {
                        wrapper.style.height = availableHeight + 'px';
                    }
                    var iframe = dialog.querySelector('iframe');
                    if (iframe) {
                        iframe.style.height = availableHeight + 'px';
                    }
                }, 100);
            };
        } else {
            $X("link_profil").onclick = function() {
                alert(lang_error_only_registered);
            };
        }
        //Ende Profil Edit
        // Erst Nachrichten laden (schnell)
        AjaxReadRequest();
        setInterval(AjaxReadRequest, this.reload_interval);
        // Userliste mit leichter Verzögerung starten (startet intern ein Intervall)
        setTimeout(() => {
            this.userOnline();
        }, 100);
        // autocomplete="off" ist nicht XHTML valide deshalb ueber JS
        $X("message").setAttribute("autocomplete", "off");
        // Passt die Hoehe des Chatinhalts immer auf die Hoehe des fensters. Also height 100%
        if (this.set_dynamic_height) {
            window_height();
            window.addEventListener("resize", window_height);
        }
        $X('message').focus();
        $X("message_form").onsubmit = function() {
            return self.send();
        } // Wichtig damit beim Submit das Dokument nicht neu geladen wird.
        $X("link_sagen").onclick = function() {
            return self.send();
        } // s.o. Zeile.
        $X("link_prop").onclick = function() {
            // HTML Content bauen (gleicher Code wie vorher)
            var history_link_content = '';
            if (self.show_history_all_user || self.userPrivilegienGlobal == "admin" || self.userPrivilegienGlobal == "mod" || self.userPrivilegienGlobal == "grafik" || self.userPrivilegienGlobal == "chatwache" || self.userPrivilegienGlobal == "co_admin") {
                history_link_content = '<div style="margin-bottom:3px;"><img src="img/time.png" align="left" />   <a href="#" id="history">' + lang_start_prop_link_2 + '</a></div>';
            }
            var pwchange_link_content = '';
            if (self.userPrivilegienGlobal == "mod" || self.userPrivilegienGlobal == "user" || self.userPrivilegienGlobal == "grafik" || self.userPrivilegienGlobal == "chatwache" || self.userPrivilegienGlobal == "co_admin") {
                pwchange_link_content = '<div style="margin-bottom:3px;"><img src="img/textfield_key.png" align="left" />   <a href="#" id="pwchange_mod">' + lang_start_prop_link_6 + '</a>\
<form id="pwchange_form" style="display:inline;"><div id="pwchange_div" style="display:none;"><div style="padding-top: 2px;">' + lang_start_prop_link_7 + '<input type="password" id="pwchange_field" size="16" /> <a href="#" id="pwchange_mod_ok">` + lang_button_ok + `</a><br><small>' + lang_start_prop_link_12 + '</small><br></div></div></form></div>';
                if (self.userPrivilegienGlobal == "user") {
                    pwchange_link_content += '<div style="margin-bottom:3px;"><img src="img/key_delete.png" align="left" />   <a href="#" id="unregister_name">' + lang_start_prop_link_10 + '</a></div>';
                }
            } else if (self.userPrivilegienGlobal == "gast" && self.allow_nick_registration) {
                pwchange_link_content = '<div style="margin-bottom:3px;"><img src="img/textfield_key.png" align="left" />   <a href="#" id="register_name">' + lang_start_reg_link + '</a><br><small>' + lang_start_prop_link_12 + '</small><br></div>';
            }
            var avatar_upload = '';
            if (self.userPrivilegienGlobal != "gast" && self.u_bild == 1) {
                avatar_upload = '<div id="avatar_up" style="margin-bottom:3px;"><img src="img/avatar.png" align="left" />   <a href="#" id="avatar_up">' + lang_start_prop_link_11 + '</a></div>';
            }
            // Status Auswahl generieren (das ist der längste Teil)
            var status_link_content = '<div><img src="img/status_online.png" align="left" />&nbsp;&nbsp;&nbsp;<a href="#" id="stat_mod">' + lang_statuslink + '</a>\
<div style="display:none;" id="stat_change_div"><div style="padding-top: 2px; padding-bottom: 4px; padding-left: 12px;">\n';
            var shownStatuses = {};
            for (var i = 0; i < lang_status_text.length; i++) {
                var imagename = lang_status_imgname[i];
                var text = lang_status_text[i];
                var right = lang_status_rights[i];
                if (shownStatuses[imagename]) continue;
                var userRole = self.userPrivilegienGlobal;
                var darfSehen = false;
                if (right === 'all') {
                    darfSehen = true;
                } else if (right === 'user' && ['user', 'mod', 'admin'].includes(userRole)) {
                    darfSehen = true;
                } else if (right === 'mod' && ['mod', 'admin'].includes(userRole)) {
                    darfSehen = true;
                } else if (right === 'admin' && userRole === 'admin') {
                    darfSehen = true;
                } else if (right === 'grafik' && userRole === 'grafik') {
                    darfSehen = true;
                } else if (right === 'co_admin' && userRole === 'co_admin') {
                    darfSehen = true;
                } else if (right === 'chatwache' && userRole === 'chatwache') {
                    darfSehen = true;
                }
                if (darfSehen) {
                    status_link_content += '<img src="img/' + imagename + '.png"/> <a href="#" id="' + imagename + '">' + text + '</a><br />\n';
                    shownStatuses[imagename] = true;
                }
            }
            status_link_content += '</div></div><div style="margin-bottom:3px;"></div>';
            var sys_mess_checked = (self.set_sys_messages) ? 'checked' : '';
            // Kompletten HTML Content zusammenbauen
            var propHtml = '<div id="prop_list">' +
                '<div style="margin-bottom:3px;"><img src="img/monitor_lightning.png" align="left" />   <a href="#" id="cls">' + lang_start_prop_link_1 + '</a></div>' +
                history_link_content +
                pwchange_link_content +
                avatar_upload +
                status_link_content +
                '<div style="padding-bottom:5px;">' +
                '<form id="set_sys_messages_form" style="display:inline;">' +
                '<input type="checkbox" id="set_sys_messages" value="1" ' + sys_mess_checked + ' /> ' +
                '<a href="#" id="set_sys_messages_a"> ' + lang_start_prop_link_9 + '</a>' +
                '</form>' +
                '</div>' +
                '<div style="margin-bottom:1px;"><img src="img/sound_' + self.sound_status + '.png" align="left" id="sound_icon" />   ' + lang_start_prop_link_3 + '</div>' +
                '<div><img src="img/space.gif" align="left" width="10"/><a href="#" id="sound_on">' + lang_start_prop_link_4 + '</a> | <a href="#" id="sound_privat">' + lang_start_prop_link_8 + '</a> | <a href="#" id="sound_off">' + lang_start_prop_link_5 + '</a></div>' +
                // NEU: Würfel-Sound an/aus
                '<div style="margin-top:10px; margin-bottom:1px;"><img src="img/redwuerfel.png" align="left" width="16" height="16" />   ' + (typeof lang_start_prop_wuerfel_sound !== 'undefined' ? lang_start_prop_wuerfel_sound : 'Würfel-Sound') + '</div>' +
                '<div style="margin-left:16px;">' +
                '<label style="cursor:pointer; margin-right:14px;"><input type="radio" name="wuerfel_sound" value="1" ' + (getUserOption(self.username, 'wuerfel_sound', true) ? 'checked' : '') + '> ' + (typeof lang_start_prop_wuerfel_sound_on !== 'undefined' ? lang_start_prop_wuerfel_sound_on : 'an') + '</label>' +
                '<label style="cursor:pointer;"><input type="radio" name="wuerfel_sound" value="0" ' + (!getUserOption(self.username, 'wuerfel_sound', true) ? 'checked' : '') + '> ' + (typeof lang_start_prop_wuerfel_sound_off !== 'undefined' ? lang_start_prop_wuerfel_sound_off : 'aus') + '</label>' +
                '</div>' +
                '</div>';
            // Dialog öffnen
            ChatDialog.open({
                title: lang_dialog_settings,
                showHeader: true,
                className: "color-dialog",
                html: propHtml,
                onOpen: function(dialog) {
                    // Hier kommen alle Event-Listener aus dem alten Code
                    // (die waren im $X('prop_list').addEventListener)
                    var propList = dialog.querySelector('#prop_list');
                    if (!propList) return;
                    // NEU: Radio-Buttons für Würfel-Sound
                    var wuerfelRadios = dialog.querySelectorAll('input[name="wuerfel_sound"]');
                    wuerfelRadios.forEach(function(radio) {
                        radio.addEventListener('change', function() {
                            var aktiv = (this.value === '1');
                            setUserOption(self.username, 'wuerfel_sound', aktiv);
                            ChatDialog.close();
                            var msg = document.getElementById('message');
                            if (msg) msg.focus();
                        });
                    });
                    // Definiere die inneren Funktionen (submit_pw, submit_status)
                    var submit_pw = function() {
                        var field = document.getElementById("pwchange_field");
                        if (!field || field.value.length < 1) return false;
                        fetch("./?ChangePw", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded"
                                },
                                body: "modpw=" + encodeURIComponent(field.value)
                            })
                            .then(res => res.text())
                            .then(text => {
                                if (text.trim() === "1") {
                                    var pwDiv = document.getElementById('pwchange_div');
                                    if (pwDiv) pwDiv.style.display = 'none';
                                    ChatDialog.close();
                                } else {
                                    alert('Error!\n\n' + text);
                                }
                            })
                        return false;
                    };
                    var submit_status = function(img, text) {
                        fetch("./?ChangeStatus", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded"
                                },
                                body: "img=" + encodeURIComponent(img) + "&text=" + encodeURIComponent(text)
                            })
                            .then(res => res.text())
                            .then(result => {
                                if (result == 1) {
                                    var el = document.getElementById("stat_change_div");
                                    if (el) {
                                        el.style.transition = "all 0.4s ease";
                                        el.style.display = "none";
                                    }
                                    ChatDialog.close();
                                    setTimeout(function() {
                                        if (typeof updateUserOnlineAnzeigeAfterRoomChange === "function") {
                                            updateUserOnlineAnzeigeAfterRoomChange();
                                        }
                                    }, 300);
                                } else {
                                    alert("Error!\n\n" + result);
                                }
                            })
                            .catch(err => console.error("submit_status Fehler:", err));
                        return false;
                    };
                    // Event-Listener für prop_list (mit Schutz gegen Mehrfachregistrierung)
                    if (!propList.hasAttribute('data-listener-bound')) {
                        propList.setAttribute('data-listener-bound', 'true');
                        propList.addEventListener('click', function(event) {
                            if (event.target.id != "" && event.target.id != 'prop_list' && event.target.id != 'sound_icon') {
                                if (event.target.id === "cls") {
                                    $X('chatinhalt').innerHTML = '';
                                    ChatDialog.close();
                                    $X('message').focus();
                                }
                                if (event.target.id === "pwchange_mod_ok") submit_pw();
                                if (event.target.id === "history") {
                                    self.historyWindow(1);
                                    ChatDialog.close();
                                }
                                if (event.target.id === "avatar_up") {
                                    ChatDialog.close();
                                    // Avatarupload wird später separat geöffnet
                                }
                                if (event.target.id === "stat_mod") {
                                    var div = document.getElementById('stat_change_div');
                                    if (div) {
                                        div.style.display = div.style.display === 'none' ? 'block' : 'none';
                                    }
                                }
                                if (event.target.id === "set_sys_messages" || event.target.id === "set_sys_messages_a") {
                                    // Suche die Checkbox IM DIALOG
                                    var checkbox = dialog.querySelector("#set_sys_messages");
                                    if (!checkbox) return;
                                    var sys_mess = checkbox.checked ? 1 : 0;
                                    // self.set_sys_messages SOFORT aktualisieren
                                    self.set_sys_messages = (sys_mess === 1);
                                    // Server benachrichtigen
                                    fetch("./?ChangeStatus", {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/x-www-form-urlencoded"
                                        },
                                        body: "sys_messages=" + sys_mess
                                    }).catch(err => console.error("ChangeStatus Fehler:", err));
                                    // Dialog schließen
                                    ChatDialog.close();
                                    var msg = document.getElementById("message");
                                    if (msg) msg.focus();
                                }
                                if (event.target.id.slice(0, 7) === "status_") {
                                    submit_status(event.target.id, event.target.innerHTML);
                                }
                                if (event.target.id === "pwchange_mod") {
                                    var div = document.getElementById('pwchange_div');
                                    if (div) {
                                        // Prüfen ob das Formular bereits die neue Struktur hat
                                        var existingNewForm = div.querySelector('#pwchange_form_new');
                                        if (!existingNewForm) {
                                            // Neues HTML mit zwei Passwortfeldern und Auge
                                            div.innerHTML = `
                <div style="padding-top: 2px;">
                    <form id="pwchange_form_new" style="display:inline;">
                        <div style="margin-bottom:8px;">
                            <label style="display:inline-block; width:120px;">` + lang_password_new + `</label>
                            <div style="display:inline-block; position:relative;">
                                <input type="password" id="pwchange_field" size="20" style="padding:4px 30px 4px 4px;">
                                <span class="password-toggle" onclick="window.togglePasswordVisibility('pwchange_field')" style="position:absolute; right:5px; top:50%; transform:translateY(-50%); cursor:pointer;">👁️</span>
                            </div>
                        </div>
                        <div style="margin-bottom:8px;">
                            <label style="display:inline-block; width:120px;">` + lang_password_repeat + `</label>
                            <div style="display:inline-block; position:relative;">
                                <input type="password" id="pwchange_field2" size="20" style="padding:4px 30px 4px 4px;">
                                <span class="password-toggle" onclick="window.togglePasswordVisibility('pwchange_field2')" style="position:absolute; right:5px; top:50%; transform:translateY(-50%); cursor:pointer;">👁️</span>
                            </div>
                        </div>
                        <div style="margin-top:10px;">
                            <a href="#" id="pwchange_mod_ok">` + lang_button_ok + `</a>
                            <span style="margin:0 5px">|</span>
                            <a href="#" id="pwchange_cancel">` + lang_button_cancel + `</a>
                        </div>
                        <small>` + lang_start_prop_link_12 + `</small>
                    </form>
                </div>
            `;
                                            // Abbrechen-Button
                                            var cancelBtn = div.querySelector('#pwchange_cancel');
                                            if (cancelBtn) {
                                                cancelBtn.onclick = function(e) {
                                                    e.preventDefault();
                                                    div.style.display = 'none';
                                                    return false;
                                                };
                                            }
                                            // OK-Button mit Prüfung
                                            var okBtn = div.querySelector('#pwchange_mod_ok');
                                            if (okBtn) {
                                                okBtn.onclick = function(e) {
                                                    e.preventDefault();
                                                    var newPw = document.getElementById('pwchange_field').value;
                                                    var newPw2 = document.getElementById('pwchange_field2').value;
                                                    // Prüfen ob Passwörter übereinstimmen
                                                    if (newPw !== newPw2) {
                                                        alert(lang_error_password_mismatch);
                                                        return;
                                                    }
                                                    // Prüfen ob Passwort lang genug ist (min. 8 Zeichen)
                                                    if (newPw.length < 8) {
                                                        alert(lang_error_password_short);
                                                        return;
                                                    }
                                                    // Stärke-Prüfung (optional - 3 von 4 Kriterien)
                                                    var criteriaMet = 0;
                                                    criteriaMet += /[A-Z]/.test(newPw) ? 1 : 0;
                                                    criteriaMet += /[a-z]/.test(newPw) ? 1 : 0;
                                                    criteriaMet += /[0-9]/.test(newPw) ? 1 : 0;
                                                    criteriaMet += /[!@#$%^&*()_\-=\[\]{};\'":\\|,.<>\/?]/.test(newPw) ? 1 : 0;
                                                    if (criteriaMet < 3) {
                                                        alert(lang_error_password_weak);
                                                        return;
                                                    }
                                                    // Senden an Server
                                                    fetch("./?ChangePw", {
                                                            method: "POST",
                                                            headers: {
                                                                "Content-Type": "application/x-www-form-urlencoded"
                                                            },
                                                            body: "modpw=" + encodeURIComponent(newPw)
                                                        })
                                                        .then(res => res.text())
                                                        .then(text => {
                                                            if (text.trim() === "1") {
                                                                div.style.display = 'none';
                                                                ChatDialog.close();
                                                                alert(lang_error_password_changed);
                                                                $X('message').focus();
                                                            } else {
                                                                alert(lang_error_password_failed + text);
                                                            }
                                                        })
                                                        .catch(err => {
                                                            alert(lang_error_network);
                                                        });
                                                    return false;
                                                };
                                            }
                                        }
                                        div.style.display = (div.style.display === 'none') ? 'block' : 'none';
                                    }
                                }
                                if (event.target.id == "register_name") {
                                    // Einstellungs-Dialog schließen
                                    ChatDialog.close();
                                    var temp_user_name = (self.username.length > 20) ? self.username.slice(0, 20) + "..." : self.username;
                                    // Registrierungs-Dialog öffnen
                                    var win_register_user = ChatDialog.open({
                                        title: "🔐 " + (lang_start_reg_title || 'Benutzernamen schützen') + ' "' + temp_user_name + '"',
                                        showHeader: true,
                                        modal: false,
                                        draggable: true,
                                        resizable: false,
                                        className: "register-dialog",
                                        html: '<div id="register_formular" style="min-width:280px;">' +
                                            '<form id="register_form" style="display:inline;">' +
                                            '<div>' + lang_register_before_text + '</div><br>' +
                                            '<div>' + lang_password_enter + '</div>' +
                                            '<hr size="1">' +
                                            '<div style="margin-bottom:8px;">' +
                                            '<label style="display:inline-block; width:100px;">' + lang_password_old + '</label>' +
                                            '<div style="display:inline-block; position:relative; width:calc(100% - 110px);">' +
                                            '<input type="password" id="pw_register_field" size="15" style="width:100%; padding:4px 30px 4px 4px; box-sizing:border-box;">' +
                                            '<span class="password-toggle" onclick="window.togglePasswordVisibility(\'pw_register_field\')" style="position:absolute; right:5px; top:50%; transform:translateY(-50%); cursor:pointer; font-size:14px;">👁️</span>' +
                                            '</div>' +
                                            '</div>' +
                                            '<div style="margin-bottom:8px;">' +
                                            '<label style="display:inline-block; width:100px;">' + lang_password_repeat + '</label>' +
                                            '<div style="display:inline-block; position:relative; width:calc(100% - 110px);">' +
                                            '<input type="password" id="pw_register_field2" size="15" style="width:100%; padding:4px 30px 4px 4px;">' +
                                            '<span class="password-toggle" onclick="window.togglePasswordVisibility(\'pw_register_field2\')" style="position:absolute; right:5px; top:50%; transform:translateY(-50%); cursor:pointer;">👁️</span>' +
                                            '</div>' +
                                            '</div>' +
                                            '<div style="margin-bottom:8px;">' +
                                            '<label style="display:inline-block; width:100px;">' + lang_password_email_optional + '</label>' +
                                            '<input type="email" id="reg_email" size="25" style="width:calc(100% - 110px); padding:4px;">' +
                                            '</div>' +
                                            '<div style="margin-top:15px;">' +
                                            '<a href="#" id="make_register" style="margin-right:15px;">' + lang_button_register + '</a>' +
                                            '<a href="#" id="cancel_register">' + lang_button_cancel + '</a>' +
                                            '</div>' +
                                            '</form>' +
                                            '</div>',
                                        onOpen: function(regDialog) {
                                            setTimeout(function() {
                                                var pwField = regDialog.querySelector('#pw_register_field');
                                                if (pwField) pwField.focus();
                                            }, 100);
                                            // Abbrechen-Button
                                            var cancelBtn = regDialog.querySelector('#cancel_register');
                                            if (cancelBtn) {
                                                cancelBtn.onclick = function(e) {
                                                    e.preventDefault();
                                                    ChatDialog.closeDialog(regDialog);
                                                };
                                            }
                                            // Registrieren-Button
                                            var makeBtn = regDialog.querySelector('#make_register');
                                            if (makeBtn) {
                                                makeBtn.onclick = function(e) {
                                                    e.preventDefault();
                                                    var password = regDialog.querySelector('#pw_register_field').value;
                                                    var password2 = regDialog.querySelector('#pw_register_field2').value;
                                                    var email = regDialog.querySelector('#reg_email')?.value.trim() || '';
                                                    if (password !== password2) {
                                                        alert(lang_error_password_mismatch);
                                                        return;
                                                    }
                                                    if (password.length < 8) {
                                                        alert(lang_error_password_short);
                                                        return;
                                                    }
                                                    if (email !== '' && !email.match(/^[^\s@]+@([^\s@.,]+\.)+[^\s@.,]{2,}$/)) {
                                                        alert(lang_error_invalid_email);
                                                        return;
                                                    }
                                                    var contentDiv = regDialog.querySelector('.dialog-content');
                                                    if (contentDiv) {
                                                        contentDiv.innerHTML = '<div style="text-align:center; padding:30px;"><img src="img/ajax-loader.gif"> ' + lang_button_loading + '</div>';
                                                    }
                                                    fetch("./?ChangePw", {
                                                            method: "POST",
                                                            headers: {
                                                                "Content-Type": "application/x-www-form-urlencoded"
                                                            },
                                                            body: "user_pw=" + encodeURIComponent(password) + "&email=" + encodeURIComponent(email)
                                                        })
                                                        .then(function(res) {
                                                            return res.text();
                                                        })
                                                        .then(function(result) {
                                                            var response = result.trim();
                                                            if (response === "1") {
                                                                // ✅ Ohne E-Mail: Sofort erfolgreich - Automatischer Logout
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML = '<div id="register_formular" style="padding:20px; text-align:center;">' +
                                                                        '✅ ' + (lang_start_reg_after_registering || 'Registrierung erfolgreich!') +
                                                                        '<br><br>' +
                                                                        '<span style="color:#888; font-size:13px;" id="register_countdown">' + (lang_logout_countdown_text_2 || 'Du wirst in 3 Sekunden automatisch ausgeloggt...') + '</span>' +
                                                                        '</div>';
                                                                }
                                                                setTimeout(function() {
                                                                    ChatDialog.closeDialog(regDialog);
                                                                    window.location.href = "./?Logout&random_user_number=" + self.random_user_number + "&r=" + $X("room").value;
                                                                }, 3000);
                                                            } else if (response === "email_sent") {
                                                                // 📧 Mit E-Mail: Bestätigungsmail gesendet
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML = '<div id="register_formular" style="padding:20px; text-align:center;">' +
                                                                        '📧 ' + (lang_register_email_sent_title || 'Bestätigungs-E-Mail gesendet!') +
                                                                        '<br>' +
                                                                        (lang_register_email_instruction || 'Bitte klicke auf den Link in der E-Mail, um deine Registrierung abzuschließen.') +
                                                                        '<br>' +
                                                                        (lang_register_guest_until_confirm || 'Du bleibst solange Gast, bis du deine E-Mail bestätigt hast.') +
                                                                        '<br><br>' +
                                                                        '<a href="./?Logout&random_user_number=' + self.random_user_number + '&r=' + $X("room").value + '" style="color:#5cb85c; font-weight:bold; font-size:16px;">' +
                                                                        '➡️ Zum Login' +
                                                                        '</a>' +
                                                                        '</div>';
                                                                }
                                                            } else if (response === "password_weak") {
                                                                // ❌ Passwort zu schwach
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML = '<div id="register_formular" style="padding:15px; color:#d9534f; text-align:center;">' +
                                                                        '❌ ' + (lang_error_password_weak || 'Passwort zu schwach!') +
                                                                        '<br><br>' +
                                                                        '<a href="#" id="retry_register" style="color:#5cb85c; font-weight:bold; font-size:16px;">🔄 Erneut versuchen</a>' +
                                                                        '</div>';
                                                                    var retryBtn = contentDiv.querySelector('#retry_register');
                                                                    if (retryBtn) {
                                                                        retryBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            // Schließe den aktuellen Dialog und öffne einen neuen
                                                                            ChatDialog.closeDialog(regDialog);
                                                                            // Simuliere einen Klick auf "register_name"
                                                                            var fakeEvent = {
                                                                                target: {
                                                                                    id: "register_name"
                                                                                }
                                                                            };
                                                                            // Hier muss der Original-Event-Handler neu aufgerufen werden
                                                                            // Einfach: Benutzer klickt manuell neu
                                                                        };
                                                                    }
                                                                }
                                                            } else if (response === "email_invalid") {
                                                                // ❌ E-Mail ungültig
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML = '<div id="register_formular" style="padding:15px; color:#d9534f; text-align:center;">' +
                                                                        '❌ ' + (lang_error_invalid_email || 'Ungültige E-Mail-Adresse!') +
                                                                        '<br><br>' +
                                                                        '<a href="#" id="retry_register" style="color:#5cb85c; font-weight:bold; font-size:16px;">🔄 Erneut versuchen</a>' +
                                                                        '</div>';
                                                                    var retryBtn = contentDiv.querySelector('#retry_register');
                                                                    if (retryBtn) {
                                                                        retryBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                }
                                                            } else if (response === "email_taken") {
                                                                // ❌ E-Mail bereits verwendet
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML = '<div id="register_formular" style="padding:15px; color:#d9534f; text-align:center;">' +
                                                                        '❌ ' + (lang_error_email_taken || 'Diese E-Mail wird bereits von einem anderen Benutzer verwendet!') +
                                                                        '<br><br>' +
                                                                        '<a href="#" id="retry_register" style="color:#5cb85c; font-weight:bold; font-size:16px;">🔄 Erneut versuchen</a>' +
                                                                        '</div>';
                                                                    var retryBtn = contentDiv.querySelector('#retry_register');
                                                                    if (retryBtn) {
                                                                        retryBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                }
                                                            } else if (response === "cooldown") {
                                                                // ⏳ Cooldown aktiv
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML = '<div id="register_formular" style="padding:15px; color:#d9534f; text-align:center;">' +
                                                                        '⏳ ' + (lang_register_cooldown || 'Von dieser IP wurde bereits ein Benutzer registriert. Bitte warte 12 Stunden.') +
                                                                        '<br><br>' +
                                                                        '<a href="#" id="close_error" style="color:#5cb85c; font-weight:bold; font-size:16px;">OK</a>' +
                                                                        '</div>';
                                                                    var closeBtn = contentDiv.querySelector('#close_error');
                                                                    if (closeBtn) {
                                                                        closeBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                }
                                                            } else {
                                                                // ❌ ALLGEMEINER FEHLER - zeigt die Server-Antwort an
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML = '<div id="register_formular" style="padding:15px;">' +
                                                                        '<div style="color:#d9534f; text-align:center; font-weight:bold;">❌ ' + (lang_error_register_failed || 'Fehler bei der Registrierung:') + '</div>' +
                                                                        '<div style="color:#ff6b6b; margin-top:5px; font-size:13px; text-align:center;">' + (response || 'Unbekannter Fehler') + '</div>' +
                                                                        '<br>' +
                                                                        '<a href="#" id="close_error" style="display:block; text-align:center; color:#5cb85c; font-size:16px;">' + lang_close + '</a>' +
                                                                        '</div>';
                                                                    var closeBtn = contentDiv.querySelector('#close_error');
                                                                    if (closeBtn) {
                                                                        closeBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                }
                                                            }
                                                        })
                                                        .catch(function(err) {
                                                            console.error("Register Fehler:", err);
                                                            if (contentDiv) {
                                                                contentDiv.innerHTML = '<div style="color:#d9534f; padding:20px; text-align:center;">' +
                                                                    '❌ ' + (lang_error_network || 'Netzwerkfehler! Bitte versuche es später erneut.') +
                                                                    '<br><br>' +
                                                                    '<a href="#" id="close_error" style="color:#5cb85c; font-size:16px;">' + lang_close + '</a>' +
                                                                    '</div>';
                                                                var closeErr = contentDiv.querySelector('#close_error');
                                                                if (closeErr) {
                                                                    closeErr.onclick = function() {
                                                                        ChatDialog.closeDialog(regDialog);
                                                                    };
                                                                }
                                                            }
                                                        });
                                                };
                                            }
                                            // Enter-Taste im Formular
                                            var form = regDialog.querySelector('#register_form');
                                            if (form) {
                                                form.onsubmit = function(e) {
                                                    e.preventDefault();
                                                    var makeBtn = regDialog.querySelector('#make_register');
                                                    if (makeBtn) makeBtn.onclick(e);
                                                    return false;
                                                };
                                            }
                                        }
                                    });
                                }
                                if (event.target.id === "unregister_name") {
                                    // Einstellungs-Dialog schließen
                                    ChatDialog.close();
                                    var temp_user_name = (self.username.length > 20) ? self.username.slice(0, 20) + "..." : self.username;
                                    // Unregister-Dialog öffnen (Passwort entfernen)
                                    var win_unregister_user = ChatDialog.open({
                                        title: (lang_remove_pw_win_title || 'Passwort entfernen') + ' "' + temp_user_name + '"',
                                        showHeader: true,
                                        modal: false,
                                        draggable: true,
                                        resizable: false,
                                        className: "unregister-dialog",
                                        html: '<div id="unregister_formular" style="padding:15px; min-width:300px;">' +
                                            '<form id="unregister_form" style="display:inline;">' +
                                            '<div style="margin-bottom:10px;">' + (lang_remove_pw_win_text1 || 'Möchtest du deinen Benutzernamen wirklich von der Passwort-Sicherung befreien?') + '</div>' +
                                            '<div style="background:#ff6b6b; padding:10px; border-radius:4px; margin-bottom:10px; color:white;">' +
                                            '<b>' + (lang_remove_pw_win_text2 || 'ACHTUNG:') + '</b><br>' +
                                            (lang_remove_pw_win_text3 || 'Der Name ist danach wieder für jeden frei zugänglich!') +
                                            '</div>' +
                                            '<hr size="1">' +
                                            '<div style="margin-bottom:8px;">' +
                                            '<label style="display:inline-block; width:100px;">' + lang_password_old + '</label>' +
                                            '<div style="display:inline-block; position:relative; width:calc(100% - 110px);">' +
                                            '<input type="password" id="pw_unregister_field" size="15" style="width:100%; padding:4px 30px 4px 4px; box-sizing:border-box;">' +
                                            '<span class="password-toggle" onclick="window.togglePasswordVisibility(\'pw_unregister_field\')" style="position:absolute; right:5px; top:50%; transform:translateY(-50%); cursor:pointer; font-size:16px;">👁️</span>' +
                                            '</div>' +
                                            '</div>' +
                                            // 🔥 NEU: Sicherheits-Checkbox
                                            '<div style="margin-bottom:12px; display:flex; align-items:center; gap:8px;">' +
                                            '<input type="checkbox" id="confirm_unregister" style="width:16px; height:16px;">' +
                                            '<label for="confirm_unregister" style="cursor:pointer; font-weight:bold; color:#ff6b6b;">' + (lang_remove_pw_confirm || 'Ja, ich möchte das Passwort dauerhaft entfernen!') + '</label>' +
                                            '</div>' +
                                            '<div style="margin-top:15px;">' +
                                            '<a href="#" id="make_unregister" style="margin-right:15px; ' +
                                            'background:#d9534f; color:white; padding:8px 20px; border-radius:4px; text-decoration:none; display:inline-block;' +
                                            '">' + lang_button_remove + '</a>' +
                                            '<a href="#" id="cancel_unregister" style="color:#5cb85c; text-decoration:none;">' + lang_button_cancel + '</a>' +
                                            '</div>' +
                                            '</form>' +
                                            '</div>',
                                        onOpen: function(regDialog) {
                                            setTimeout(function() {
                                                var pwField = regDialog.querySelector('#pw_unregister_field');
                                                if (pwField) pwField.focus();
                                            }, 100);
                                            // Abbrechen-Button
                                            var cancelBtn = regDialog.querySelector('#cancel_unregister');
                                            if (cancelBtn) {
                                                cancelBtn.onclick = function(e) {
                                                    e.preventDefault();
                                                    ChatDialog.closeDialog(regDialog);
                                                };
                                            }
                                            // Entfernen-Button
                                            var makeBtn = regDialog.querySelector('#make_unregister');
                                            if (makeBtn) {
                                                makeBtn.onclick = function(e) {
                                                    e.preventDefault();
                                                    // 🔥 NEU: Prüfe ob die Sicherheits-Checkbox aktiviert ist
                                                    var confirmCheckbox = regDialog.querySelector('#confirm_unregister');
                                                    if (!confirmCheckbox || !confirmCheckbox.checked) {
                                                        alert(lang_remove_pw_confirm_error || 'Bitte bestätige die Löschung des Passworts!');
                                                        return;
                                                    }
                                                    var password = regDialog.querySelector('#pw_unregister_field').value;
                                                    if (password.length < 1) {
                                                        alert(lang_error_enter_password || 'Bitte gib dein aktuelles Passwort ein.');
                                                        return;
                                                    }
                                                    // Ladeanimation anzeigen
                                                    var contentDiv = regDialog.querySelector('.dialog-content');
                                                    if (contentDiv) {
                                                        contentDiv.innerHTML = '<div style="text-align:center; padding:30px;"><img src="img/ajax-loader.gif"> ' + lang_button_loading + '</div>';
                                                    }
                                                    fetch("./?UnregisterPw", {
                                                            method: "POST",
                                                            headers: {
                                                                "Content-Type": "application/x-www-form-urlencoded"
                                                            },
                                                            body: "user_pw=" + encodeURIComponent(password)
                                                        })
                                                        .then(function(res) {
                                                            return res.text();
                                                        })
                                                        .then(function(result) {
                                                            var response = result.trim();
                                                            if (response === "1") {
                                                                // ✅ ERFOLG: Automatisch ausloggen mit Countdown
                                                                var countdown = 3;
                                                                if (contentDiv) {
                                                                    var countdownText = (lang_logout_countdown_text || 'Du wirst in {seconds} Sekunden automatisch ausgeloggt...').replace('{seconds}', countdown);
                                                                    contentDiv.innerHTML =
                                                                        '<div style="padding:20px; text-align:center;">' +
                                                                        '✅ ' + (lang_unregister_success || 'Passwort wurde erfolgreich entfernt!') +
                                                                        '<br><br>' +
                                                                        '<span style="color:#888; font-size:13px;" id="logout_countdown">' + countdownText + '</span>' +
                                                                        '</div>';
                                                                }
                                                                var countdownInterval = setInterval(function() {
                                                                    countdown--;
                                                                    var countdownSpan = document.getElementById('logout_countdown');
                                                                    if (countdownSpan) {
                                                                        var newText = (lang_logout_countdown_text || 'Du wirst in {seconds} Sekunden automatisch ausgeloggt...').replace('{seconds}', countdown);
                                                                        countdownSpan.textContent = newText;
                                                                    }
                                                                    if (countdown <= 0) {
                                                                        clearInterval(countdownInterval);
                                                                        ChatDialog.closeDialog(regDialog);
                                                                        window.location.href = "./?Logout&random_user_number=" + self.random_user_number + "&r=" + $X("room").value;
                                                                    }
                                                                }, 1000);
                                                            } else if (response === "wrong_password") {
                                                                // ❌ FALSCHES PASSWORT - Dialog neu aufbauen
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML =
                                                                        '<div id="unregister_formular" style="padding:15px;">' +
                                                                        '<div style="color:#d9534f; text-align:center; font-weight:bold; font-size:16px;">❌ ' + (lang_unregister_wrong_password || 'Falsches Passwort! Bitte versuche es erneut.') + '</div>' +
                                                                        '<br>' +
                                                                        '<form id="unregister_form" style="display:inline;">' +
                                                                        '<div style="margin-bottom:8px;">' +
                                                                        '<label style="display:inline-block; width:100px;">' + lang_password_old + '</label>' +
                                                                        '<div style="display:inline-block; position:relative; width:calc(100% - 110px);">' +
                                                                        '<input type="password" id="pw_unregister_field" size="15" style="width:100%; padding:4px 30px 4px 4px; box-sizing:border-box;">' +
                                                                        '<span class="password-toggle" onclick="window.togglePasswordVisibility(\'pw_unregister_field\')" style="position:absolute; right:5px; top:50%; transform:translateY(-50%); cursor:pointer; font-size:16px;">👁️</span>' +
                                                                        '</div>' +
                                                                        '</div>' +
                                                                        '<div style="margin-bottom:12px; display:flex; align-items:center; gap:8px;">' +
                                                                        '<input type="checkbox" id="confirm_unregister" style="width:16px; height:16px;">' +
                                                                        '<label for="confirm_unregister" style="cursor:pointer; font-weight:bold; color:#ff6b6b;">' + (lang_remove_pw_confirm || 'Ja, ich möchte das Passwort dauerhaft entfernen!') + '</label>' +
                                                                        '</div>' +
                                                                        '<div style="margin-top:15px;">' +
                                                                        '<a href="#" id="make_unregister" style="margin-right:15px; background:#d9534f; color:white; padding:8px 20px; border-radius:4px; text-decoration:none; display:inline-block;">' + lang_button_remove + '</a>' +
                                                                        '<a href="#" id="cancel_unregister" style="color:#5cb85c; text-decoration:none;">' + lang_button_cancel + '</a>' +
                                                                        '</div>' +
                                                                        '</form>' +
                                                                        '</div>';
                                                                    // Events neu binden
                                                                    var newMakeBtn = contentDiv.querySelector('#make_unregister');
                                                                    if (newMakeBtn) {
                                                                        newMakeBtn.onclick = makeBtn.onclick;
                                                                    }
                                                                    var newCancelBtn = contentDiv.querySelector('#cancel_unregister');
                                                                    if (newCancelBtn) {
                                                                        newCancelBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                    setTimeout(function() {
                                                                        var pwField = contentDiv.querySelector('#pw_unregister_field');
                                                                        if (pwField) pwField.focus();
                                                                    }, 100);
                                                                }
                                                            } else if (response === "no_password_set") {
                                                                // ⚠️ KEIN PASSWORT GESETZT
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML =
                                                                        '<div style="padding:20px; text-align:center;">' +
                                                                        '⚠️ ' + (lang_unregister_no_password || 'Dieser Account hat kein Passwort gesetzt!') +
                                                                        '<br><br>' +
                                                                        '<a href="#" id="close_error" style="color:#5cb85c; font-size:16px;">' + lang_button_ok + '</a>' +
                                                                        '</div>';
                                                                    var closeBtn = contentDiv.querySelector('#close_error');
                                                                    if (closeBtn) {
                                                                        closeBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                }
                                                            } else if (response === "no_permission") {
                                                                // 🚫 KEINE BERECHTIGUNG
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML =
                                                                        '<div style="padding:20px; text-align:center;">' +
                                                                        '🚫 ' + (lang_unregister_no_permission || 'Du hast keine Berechtigung, das Passwort zu entfernen!') +
                                                                        '<br><br>' +
                                                                        '<a href="#" id="close_error" style="color:#5cb85c; font-size:16px;">' + lang_button_ok + '</a>' +
                                                                        '</div>';
                                                                    var closeBtn = contentDiv.querySelector('#close_error');
                                                                    if (closeBtn) {
                                                                        closeBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                }
                                                            } else if (response === "no_session") {
                                                                // 🔒 KEINE SESSION
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML =
                                                                        '<div style="padding:20px; text-align:center; color:#d9534f;">' +
                                                                        '🔒 ' + (lang_unregister_no_session || 'Keine gültige Sitzung! Bitte logge dich neu ein.') +
                                                                        '<br><br>' +
                                                                        '<a href="#" id="close_error" style="color:#5cb85c; font-size:16px;">' + lang_button_ok + '</a>' +
                                                                        '</div>';
                                                                    var closeBtn = contentDiv.querySelector('#close_error');
                                                                    if (closeBtn) {
                                                                        closeBtn.onclick = function(ev) {
                                                                            ev.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                            window.location.href = "./?Logout&random_user_number=" + self.random_user_number + "&r=" + $X("room").value;
                                                                        };
                                                                    }
                                                                }
                                                            } else {
                                                                // ❌ ALLGEMEINER FEHLER - zeigt die Server-Antwort an
                                                                if (contentDiv) {
                                                                    contentDiv.innerHTML =
                                                                        '<div id="unregister_formular" style="padding:15px;">' +
                                                                        '<div style="color:#d9534f; text-align:center; font-weight:bold;">❌ ' + (lang_unregister_generic_error || 'Fehler beim Entfernen des Passworts:') + '</div>' +
                                                                        '<div style="color:#ff6b6b; margin-top:5px; font-size:13px; text-align:center;">' + (result || 'Unbekannter Fehler') + '</div>' +
                                                                        '<br>' +
                                                                        '<a href="#" id="close_error" style="display:block; text-align:center; color:#5cb85c; font-size:16px;">' + lang_close + '</a>' +
                                                                        '</div>';
                                                                    var closeBtn = contentDiv.querySelector('#close_error');
                                                                    if (closeBtn) {
                                                                        closeBtn.onclick = function(e) {
                                                                            e.preventDefault();
                                                                            ChatDialog.closeDialog(regDialog);
                                                                        };
                                                                    }
                                                                }
                                                            }
                                                        })
                                                        .catch(function(err) {
                                                            console.error("Unregister Fehler:", err);
                                                            if (contentDiv) {
                                                                contentDiv.innerHTML =
                                                                    '<div style="padding:20px; text-align:center; color:#d9534f;">' +
                                                                    '❌ ' + (lang_unregister_network_error || 'Netzwerkfehler! Bitte versuche es später erneut.') +
                                                                    '<br><br>' +
                                                                    '<a href="#" id="close_error" style="color:#5cb85c; font-size:16px;">' + lang_close + '</a>' +
                                                                    '</div>';
                                                                var closeBtn = contentDiv.querySelector('#close_error');
                                                                if (closeBtn) {
                                                                    closeBtn.onclick = function(e) {
                                                                        e.preventDefault();
                                                                        ChatDialog.closeDialog(regDialog);
                                                                    };
                                                                }
                                                            }
                                                        });
                                                };
                                            }
                                            // Enter-Taste im Formular
                                            var form = regDialog.querySelector('#unregister_form');
                                            if (form) {
                                                form.onsubmit = function(e) {
                                                    e.preventDefault();
                                                    var makeBtn = regDialog.querySelector('#make_unregister');
                                                    if (makeBtn) makeBtn.onclick(e);
                                                    return false;
                                                };
                                            }
                                        }
                                    });
                                }
                                // Avatar Upload Fenster (UMGEBAUT mit ChatDialog)
                                if (event.target.id === "avatar_up") {
                                    ChatDialog.close();
                                    const isMobile = window.matchMedia("(max-width: 1024px)").matches;
                                    // Avatar-Dialog mit ChatDialog öffnen
                                    const avatarDialog = ChatDialog.open({
                                        title: lang_dialog_avatar,
                                        showHeader: true,
                                        modal: false, // Nicht modal, damit Chat weiterläuft
                                        draggable: true,
                                        resizable: false,
                                        className: "avatar-dialog",
                                        html: `
            <div id="avatar_tool">
				<label for="post_file">` + lang_avatar_select_file + `</label>
				<input type="file" id="post_file" accept="image/*" style="margin: 10px 0;">
				<div id="label">
					<canvas id="get_image" width="200" height="200"></canvas>
				</div>
				<button id="save_button" class="avatar-button save">` + lang_avatar_button_save + `</button>
				<button id="Avatar_Loeschen" class="avatar-button delete">` + lang_avatar_button_delete + `</button>
				<div id="Avatar_Ergebnis"></div>
				<div class="avatar-hint">` + lang_avatar_hint + `</div>
			</div>`,
                                        onOpen: function(dialog) {
                                            let originalExtension = "png";
                                            // postFileCanvas.js laden
                                            const script = document.createElement("script");
                                            script.src = "js/postFileCanvas.js";
                                            script.onload = function() {
                                                if (typeof postFile !== "undefined") {
                                                    postFile.init();
                                                    const inputFile = dialog.querySelector("#post_file");
                                                    if (inputFile) {
                                                        inputFile.addEventListener("change", function() {
                                                            const file = inputFile.files[0];
                                                            if (!file) return;
                                                            const ext = file.name.split(".").pop().toLowerCase();
                                                            if (["jpg", "jpeg", "png", "gif"].includes(ext)) {
                                                                originalExtension = ext;
                                                            } else {
                                                                originalExtension = "png";
                                                            }
                                                        });
                                                    }
                                                    const saveBtn = dialog.querySelector("#save_button");
                                                    if (saveBtn) {
                                                        saveBtn.onclick = function() {
                                                            const mimeMap = {
                                                                jpg: "image/jpeg",
                                                                jpeg: "image/jpeg",
                                                                png: "image/png",
                                                                gif: "image/png"
                                                            };
                                                            const mime = mimeMap[originalExtension] || "image/png";
                                                            const ext = (originalExtension === "gif") ? "png" : originalExtension;
                                                            postFile.save(function(blob) {
                                                                const ergebnis = dialog.querySelector("#Avatar_Ergebnis");
                                                                if (!blob || blob.size === 0) {
                                                                    if (ergebnis) {
                                                                        ergebnis.style.color = "red";
                                                                        ergebnis.innerHTML = lang_avatar_no_image;
                                                                    }
                                                                    return;
                                                                }
                                                                const cleanUsername = self.username.replace(/[^a-zA-Z0-9_\-]/g, "_").substring(0, 4);
                                                                const formData = new FormData();
                                                                formData.append("task", "insert");
                                                                formData.append("userid", self.user_id);
                                                                formData.append("username", cleanUsername);
                                                                formData.append("file", blob, "avatar." + ext);
                                                                const client = new XMLHttpRequest();
                                                                client.open("POST", "./?Avatar");
                                                                client.onload = function() {
                                                                    if (ergebnis) {
                                                                        if (client.status == 200) {
                                                                            ergebnis.style.color = "green";
                                                                            ergebnis.innerHTML = lang_avatar_success;
                                                                            // Dialog nach erfolgreichem Upload automatisch schließen?
                                                                            setTimeout(() => ChatDialog.close(), 5000);
                                                                        } else {
                                                                            ergebnis.style.color = "red";
                                                                            ergebnis.innerHTML = lang_error_upload_failed + client.status + ")";
                                                                        }
                                                                    }
                                                                };
                                                                client.onerror = function() {
                                                                    if (ergebnis) {
                                                                        ergebnis.style.color = "red";
                                                                        ergebnis.innerHTML = lang_error_connection_failed;
                                                                    }
                                                                };
                                                                client.send(formData);
                                                            }, mime, ext);
                                                        };
                                                    }
                                                    const deleteBtn = dialog.querySelector("#Avatar_Loeschen");
                                                    if (deleteBtn) {
                                                        deleteBtn.onclick = function() {
                                                            if (!confirm(lang_avatar_delete_confirm)) return;
                                                            const formData = new FormData();
                                                            formData.append("task", "delete");
                                                            formData.append("userid", self.user_id);
                                                            const client = new XMLHttpRequest();
                                                            client.open("POST", "./?Avatar");
                                                            client.onload = function() {
                                                                const ergebnis = dialog.querySelector("#Avatar_Ergebnis");
                                                                if (ergebnis) {
                                                                    if (client.status == 200) {
                                                                        ergebnis.style.color = "green";
                                                                        ergebnis.innerHTML = lang_avatar_delete_success;
                                                                    } else {
                                                                        ergebnis.style.color = "red";
                                                                        ergebnis.innerHTML = lang_avatar_delete_failed + client.status + ")";
                                                                    }
                                                                }
                                                            };
                                                            client.onerror = function() {
                                                                const ergebnis = dialog.querySelector("#Avatar_Ergebnis");
                                                                if (ergebnis) {
                                                                    ergebnis.style.color = "red";
                                                                    ergebnis.innerHTML = lang_error_connection_failed;
                                                                }
                                                            };
                                                            client.send(formData);
                                                        };
                                                    }
                                                }
                                            };
                                            document.body.appendChild(script);
                                        }
                                    });
                                }
                                // Sound Einstellungen
                                if (event.target.id === "sound_off") {
                                    self.sound_status = 'none';
                                    var soundIcon = dialog.querySelector('#sound_icon');
                                    if (soundIcon) soundIcon.src = "img/sound_none.png";
                                    setUserOption(self.username, 'sound', 'none');
                                    ChatDialog.close();
                                    $X('message').focus();
                                }
                                if (event.target.id === "sound_on") {
                                    self.sound_status = 'all';
                                    var soundIcon = dialog.querySelector('#sound_icon');
                                    if (soundIcon) soundIcon.src = "img/sound_all.png";
                                    setUserOption(self.username, 'sound', 'all');
                                    ChatDialog.close();
                                    $X('message').focus();
                                }
                                if (event.target.id === "sound_privat") {
                                    self.sound_status = 'privat';
                                    var soundIcon = dialog.querySelector('#sound_icon');
                                    if (soundIcon) soundIcon.src = "img/sound_privat.png";
                                    setUserOption(self.username, 'sound', 'privat');
                                    ChatDialog.close();
                                    $X('message').focus();
                                }
                            }
                        });
                    }
                }
            });
        };
        // Logout
        $X("link_logout").onclick = function() {
            window.isLoggingOut = true;
            // ============================================================
            // AUFRÄUMEN: Alle chatHistory_* und priv_dlg_* Einträge löschen
            // ============================================================
            try {
                // Alle chatHistory_* aus localStorage löschen
                for (let i = localStorage.length - 1; i >= 0; i--) {
                    const key = localStorage.key(i);
                    if (key && key.startsWith("chatHistory_")) {
                        localStorage.removeItem(key);
                    }
                }
                // Alle priv_dlg_* aus localStorage löschen
                for (let i = localStorage.length - 1; i >= 0; i--) {
                    const key = localStorage.key(i);
                    if (key && key.startsWith("priv_dlg_")) {
                        localStorage.removeItem(key);
                    }
                }
                // Guest-Client-ID entfernen
                sessionStorage.removeItem("guest_client_id");
            } catch (e) {
                console.warn("Aufräumen beim Logout fehlgeschlagen:", e);
            }
            // Private Chat-Verläufe löschen (bestehende Funktion)
            self.clearAllPrivateChatHistory();
            // Weiterleiten zum Logout
            location.href = "./?Logout&random_user_number=" + self.random_user_number + "&r=" + $X("room").value;
        }
        // MausKoord fuer Fenster und Tooltips
        document.addEventListener('mousemove', function(event) {
            self.mouse_left = event.clientX;
            self.mouse_top = event.clientY;
        });
        // überwachung aller Elemente der OnlineList, Chatinhalts,
        // also beim Private, Roomchange oder Usersperren wirds dadurch ausgeloest
        $X('onlineausgabe').addEventListener('click', function(event) {
            changeUserEvent(event.target.id, event);
        });
        $X('chatinhalt').addEventListener('click', function(event) {
            var targetId = event.target.id;
            // Nur ausführen, wenn es KEIN Smiley ist (Smileys werden vom globalen Listener behandelt)
            if (!targetId || (targetId.indexOf('smilchat_') !== 0 && targetId.indexOf('smilchat_0') !== 0)) {
                changeUserEvent(targetId, event);
            }
        });
        $X('form').addEventListener('click', function(event) {});
        $X('kopf').addEventListener('click', function(event) {});
        $X('splitpane').addEventListener('click', function(event) {});
        // Globaler Listener für ALLE Smiley-Klicks (Hauptchat + private Dialoge)
        document.body.addEventListener('click', function(event) {
            var target = event.target;
            if (target && target.classList && target.classList.contains('img_smiley')) {
                var id = target.id;
                if (id && (id.indexOf('smilchat_') === 0 || id.indexOf('smilchat_0') === 0)) {
                    var smileyCode = id.substring(id.indexOf(':'));
                    // Prüfe, ob der Smiley in einem privaten Dialog ist
                    var privateDialog = target.closest('.private-chat-dialog');
                    if (privateDialog) {
                        // Privater Dialog: In das private Input-Feld einfügen
                        var privateInput = privateDialog.querySelector('.private-message-input');
                        if (privateInput) {
                            privateInput.value += " " + smileyCode + " ";
                            privateInput.focus();
                        }
                    } else {
                        // Hauptchat: Ins Hauptchat-Feld einfügen
                        var mainInput = $X('message');
                        if (mainInput) {
                            mainInput.value += " " + smileyCode + " ";
                            mainInput.focus();
                        }
                    }
                    // Verhindere, dass andere Listener auch noch feuern
                    event.stopPropagation();
                }
            }
        });
        // ueberwachung zum ausschalten der Privatanzeige
        $X('privat_anzeige').addEventListener('click', function(event) {
            if (event.target.id == "close_privat") {
                $X("privat").value = "0";
                $X("privat_anzeige").innerHTML = lang_start_1;
                $X("message").focus();
            }
        });
        //Click auf Smiley-Icon
        $X("link_smileys").onclick = function() {
            open_close_smileys_win('message');
            const inputField = $X('message');
            if (inputField) inputField.focus();
        };
        // Bild BBcode - Cursor zwischen die Tags
        $X("link_picture").onclick = function() {
            const messageField = $X("message");
            const start = messageField.selectionStart;
            const end = messageField.selectionEnd;
            const text = messageField.value;
            const before = text.substring(0, start);
            const after = text.substring(end);
            const imgTag = "[img][/img]";
            // Cursor kommt nach "[img]" (5 Zeichen)
            const cursorPos = start + 5;
            messageField.value = before + imgTag + after;
            messageField.focus();
            messageField.setSelectionRange(cursorPos, cursorPos);
        }
        // Video BBcode - Cursor zwischen die Tags
        $X("link_video").onclick = function() {
            const messageField = $X("message");
            const start = messageField.selectionStart;
            const end = messageField.selectionEnd;
            const text = messageField.value;
            const before = text.substring(0, start);
            const after = text.substring(end);
            const videoTag = "[video][/video]";
            // Cursor kommt nach "[video]" (7 Zeichen)
            const cursorPos = start + 7;
            messageField.value = before + videoTag + after;
            messageField.focus();
            messageField.setSelectionRange(cursorPos, cursorPos);
        }
        //Lade Fensterinhalt zum Darstellen des Farbenfensters
        // Username sicher holen
        var user = encodeURIComponent(self.username || "guest");
        // Lade Fensterinhalt zum Darstellen des Farbenfensters
        fetch("./?Colorizer")
            .then(res => res.text())
            .then(result => {
                self.win_color_content = result;
            })
            .catch(err => console.error("Colorizer Fehler:", err));
        // --- Werte laden ---
        var options = loadUserOptions(user) || {};
        var color = options.color || null;
        var bold = options.bold || null;
        var italic = options.italic || null;
        // Farbe setzen
        if (color) {
            self.textcolor = color;
            $X('message').style.color = "#" + color;
            $X('color').value = "#" + color;
        } else {
            $X('message').style.color = "#" + self.textcolor;
        }
        // Fett
        if (bold) {
            $X('bold').value = bold;
            $X('message').style.fontWeight = bold;
        }
        // Kursiv
        if (italic) {
            $X('italic').value = italic;
            $X('message').style.fontStyle = italic;
        }
        // Click auf Color-Icon
        $X("link_color").onclick = function() {
            ChatDialog.open({
                title: lang_dialog_color,
                showHeader: true,
                className: "color-dialog",
                html: self.win_color_content,
                onOpen: function(dialog) {
                    var user = encodeURIComponent(self.username || "guest");
                    var savedOptions = loadUserOptions(user) || {};
                    var savedColor = savedOptions.color || null;
                    var savedBold = savedOptions.bold || null;
                    var savedItalic = savedOptions.italic || null;
                    // --- Kursiv Checkbox ---
                    var kursivCheckbox = dialog.querySelector('#kursiv');
                    if (kursivCheckbox) {
                        if (savedItalic === 'italic') {
                            kursivCheckbox.checked = true;
                        }
                        kursivCheckbox.onclick = function() {
                            if (kursivCheckbox.checked) {
                                setUserOption(user, 'italic', 'italic');
                                $X("italic").value = "italic";
                                $X('message').style.fontStyle = "italic";
                            } else {
                                setUserOption(user, 'italic', 'normal');
                                $X("italic").value = "normal";
                                $X('message').style.fontStyle = "normal";
                            }
                        };
                    }
                    // --- Fett Checkbox ---
                    var fettCheckbox = dialog.querySelector('#fett');
                    if (fettCheckbox) {
                        if (savedBold === 'bold') {
                            fettCheckbox.checked = true;
                        }
                        fettCheckbox.onclick = function() {
                            if (fettCheckbox.checked) {
                                setUserOption(user, 'bold', 'bold');
                                $X("bold").value = "bold";
                                $X('message').style.fontWeight = "bold";
                            } else {
                                setUserOption(user, 'bold', 'normal');
                                $X("bold").value = "normal";
                                $X('message').style.fontWeight = "normal";
                            }
                        };
                    }
                    // --- Farb-Slider ---
                    var sliderRed = dialog.querySelector('#slider_red');
                    var sliderGreen = dialog.querySelector('#slider_green');
                    var sliderBlue = dialog.querySelector('#slider_blue');
                    var farbenvorschau = dialog.querySelector('#farbenvorschau');
                    // Aktuelle Farbe aus self.textcolor (ohne #)
                    var startColor = self.textcolor || savedColor;
                    // r, g, b aus startColor extrahieren
                    var r = parseInt(startColor.slice(0, 2), 16);
                    var g = parseInt(startColor.slice(2, 4), 16);
                    var b = parseInt(startColor.slice(4, 6), 16);
                    // Slider auf aktuelle Farbe setzen
                    if (sliderRed) sliderRed.value = r;
                    if (sliderGreen) sliderGreen.value = g;
                    if (sliderBlue) sliderBlue.value = b;
                    // Nur ANZEIGE aktualisieren (KEIN Cookie!)
                    function updateDisplay() {
                        var hex = dec2hex(parseInt(sliderRed.value)) +
                            dec2hex(parseInt(sliderGreen.value)) +
                            dec2hex(parseInt(sliderBlue.value));
                        $X('message').style.color = '#' + hex;
                        $X('color').value = "#" + hex;
                        if (farbenvorschau) {
                            farbenvorschau.style.backgroundColor = '#' + hex;
                        }
                        self.textcolor = hex; // self.textcolor aktualisieren
                        // KEIN Cookie hier!
                    }
                    // Cookie speichern (nur bei Änderungen)
                    function saveColor() {
                        var hex = dec2hex(parseInt(sliderRed.value)) +
                            dec2hex(parseInt(sliderGreen.value)) +
                            dec2hex(parseInt(sliderBlue.value));
                        setUserOption(user, 'color', hex);
                    }
                    // Event-Listener für Änderungen
                    var onChange = function() {
                        updateDisplay();
                        saveColor(); // Cookie nur bei Änderung!
                    };
                    if (sliderRed) sliderRed.addEventListener('input', onChange);
                    if (sliderGreen) sliderGreen.addEventListener('input', onChange);
                    if (sliderBlue) sliderBlue.addEventListener('input', onChange);
                    // Initiale Anzeige (kein Cookie)
                    updateDisplay();
                    // --- Farbfelder ---
                    var farbenTab = dialog.querySelector('#farben_tab');
                    if (farbenTab) {
                        farbenTab.addEventListener('click', function(event) {
                            var target = event.target;
                            if (target.id && target.id.length === 6 && /^[0-9a-f]{6}$/i.test(target.id)) {
                                var rNew = parseInt(target.id.slice(0, 2), 16);
                                var gNew = parseInt(target.id.slice(2, 4), 16);
                                var bNew = parseInt(target.id.slice(4, 6), 16);
                                if (sliderRed) sliderRed.value = rNew;
                                if (sliderGreen) sliderGreen.value = gNew;
                                if (sliderBlue) sliderBlue.value = bNew;
                                updateDisplay();
                                saveColor(); // Cookie nur bei Klick auf Farbfeld
                            }
                        });
                    }
                }
            });
        };
        // Klick auf Würfel
        document.getElementById("wuerfel").onclick = function() {
            const MAX_CLICKS = self.set_wuza;
            const TIME_WINDOW_MINUTES = self.set_wupau;
            const TIME_WINDOW_MS = TIME_WINDOW_MINUTES * 60 * 1000;
            const now = Date.now();
            // Lade Klickzeiten aus localStorage
            let clickTimestamps = JSON.parse(localStorage.getItem("clickTimestamps")) || [];
            // Filtere alte Klicks raus
            clickTimestamps = clickTimestamps.filter(ts => now - ts < TIME_WINDOW_MS);
            if (clickTimestamps.length >= MAX_CLICKS) {
                alert(lang_wuerfel_too_many.replace('{count}', MAX_CLICKS).replace('{minutes}', TIME_WINDOW_MINUTES));
                return;
            }
            // NEU: Würfel-Sound abspielen (nur für den klickenden User, nur wenn aktiviert)
            var wuerfelSoundAktiv = getUserOption(self.username, 'wuerfel_sound', true);
            if (wuerfelSoundAktiv && self.audioBuffer && self.audioBuffer[2] && self.soundManager) {
                try {
                    if (self.soundManager.state === 'suspended') {
                        self.soundManager.resume();
                    }
                    var src = self.soundManager.createBufferSource();
                    src.buffer = self.audioBuffer[2];
                    src.connect(self.soundManager.destination);
                    src.start(0);
                } catch (e) {
                    console.warn('Würfel-Sound konnte nicht abgespielt werden:', e);
                }
            }
            // neuen Klick speichern
            clickTimestamps.push(now);
            localStorage.setItem("clickTimestamps", JSON.stringify(clickTimestamps));
            // POST Daten bauen
            const body = "username=" + encodeURIComponent(self.username) + "&room=1";
            fetch("./?Wuerfel", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: body
                })
                .catch(err => console.error("Wuerfel Fehler:", err));
        };
        // Ende Würfel
        // Klick auf Filesend
        if (self.userPrivilegienGlobal == "admin" || self.userPrivilegienGlobal == "mod" || self.userPrivilegienGlobal == "user" || self.userPrivilegienGlobal == "grafik" || self.userPrivilegienGlobal == "chatwache" || self.userPrivilegienGlobal == "co_admin") {
            $X("link_filesend").onclick = function() {
                // Speichere den Upload-Dialog in einer eigenen Variable
                var uploadDialog = null;
                uploadDialog = ChatDialog.open({
                    title: lang_dialog_upload,
                    showHeader: true,
                    className: "upload-dialog",
                    html: '<center><div id="Filesendmain">' +
                        '<div id="Ergebnis"></div>' +
                        '<progress id="progress" style="margin-top:10px; width:100%;"></progress>' +
                        '<span id="prozent"></span>' +
                        '<form enctype="multipart/form-data" action="javascript:;" method="post">' +
                        '<input type="file" name="file" id="fileA" /><br/>' +
                        lang_upload_max_size + '<br/>' +
                        '<input type="Checkbox" name="rulescheck" id="rulescheck" value=""> ' + lang_upload_rules_accept + ' <a href="#" id="Uploadregeln">' + lang_upload_rules_title + '.</a><br/>' +
                        '<input type="text" id="bildText" class="input" placeholder="' + lang_upload_placeholder + '" style="width:80%;"><br/><br/>' +
                        '<input name="submit" id="Laden" type="submit" value="' + lang_button_upload + '" class="button" />' +
                        '</form>' +
                        '<div id="fizfooter">' + lang_upload_footer + '</div>' +
                        '</div></center>',
                    onOpen: function(dialog) {
                        // Progress-Bar initial ausblenden
                        var progress = dialog.querySelector('#progress');
                        var prozent = dialog.querySelector('#prozent');
                        var ergebnis = dialog.querySelector('#Ergebnis');
                        if (progress) progress.style.display = 'none';
                        if (prozent) prozent.style.display = 'none';
                        if (ergebnis) ergebnis.innerHTML = lang_upload_select_file;
                        // --- Uploadregeln Link (öffnet separaten Dialog, ohne den Upload zu schließen) ---
                        // In chat.js - ersetze die Uploadregeln-Funktion (ca. Zeile 1790)
                        var regelnLink = dialog.querySelector('#Uploadregeln');
                        if (regelnLink) {
                            regelnLink.onclick = function(e) {
                                e.preventDefault();
                                // Öffne Regeln in einem separaten Dialog
                                var rulesDialog = document.createElement('dialog');
                                rulesDialog.className = 'modern-dialog narrow';
                                // *** HIER IST DER FIX: Die Anführungszeichen korrigieren! ***
                                rulesDialog.innerHTML = `
            <div class="dialog-header">
                <span class="dialog-title">${lang_upload_rules_title}</span>
                <button class="dialog-close">&times;</button>
            </div>
            <div class="dialog-content">
                <div id="infotext" style="padding:10px;">
                    ${lang_upload_rules_text}
                    <br/><br/>
                    <button id="close_rules" class="button" style="margin-top:10px; padding:5px 15px;">${lang_button_ok}</button>
                </div>
            </div>
        `;
                                document.body.appendChild(rulesDialog);
                                // Schließen-Button
                                var closeBtn = rulesDialog.querySelector('.dialog-close');
                                if (closeBtn) {
                                    closeBtn.onclick = function() {
                                        rulesDialog.remove();
                                    };
                                }
                                // OK Button
                                var okBtn = rulesDialog.querySelector('#close_rules');
                                if (okBtn) {
                                    okBtn.onclick = function() {
                                        rulesDialog.remove();
                                    };
                                }
                                // Klick außerhalb schließen
                                rulesDialog.addEventListener('click', function(e) {
                                    if (e.target === rulesDialog) {
                                        rulesDialog.remove();
                                    }
                                });
                                rulesDialog.showModal();
                            };
                        }
                        // --- Dateiauswahl ---
                        var fileInput = dialog.querySelector('#fileA');
                        if (fileInput) {
                            fileInput.onchange = function() {
                                var file = fileInput.files[0];
                                if (!file) return;
                                // Prüfung für GIFs
                                if (file.type === "image/gif" && file.size > 1500000) {
                                    if (progress) progress.style.display = 'none';
                                    if (prozent) prozent.style.display = 'none';
                                    if (ergebnis) {
                                        ergebnis.style.display = 'block';
                                        ergebnis.style.color = "red";
                                        ergebnis.innerHTML = lang_upload_gif_too_large;
                                    }
                                    fileInput.value = "";
                                    return;
                                }
                                // Prüfung für alle anderen Bildtypen
                                if (file.size > 10000000) {
                                    if (progress) progress.style.display = 'none';
                                    if (prozent) prozent.style.display = 'none';
                                    if (ergebnis) {
                                        ergebnis.style.display = 'block';
                                        ergebnis.style.color = "red";
                                        ergebnis.innerHTML = lang_upload_file_too_large;
                                    }
                                    fileInput.value = "";
                                    return;
                                }
                                if (file.type == "image/jpeg" || file.type == "image/png" || file.type == "image/gif") {
                                    if (progress) {
                                        progress.value = 0;
                                        progress.style.display = 'block';
                                    }
                                    if (prozent) {
                                        prozent.innerHTML = "0%";
                                        prozent.style.display = 'inline';
                                    }
                                    if (ergebnis) {
                                        ergebnis.style.display = 'none';
                                    }
                                } else {
                                    if (progress) progress.style.display = 'none';
                                    if (prozent) prozent.style.display = 'none';
                                    if (ergebnis) {
                                        ergebnis.style.display = 'block';
                                        ergebnis.style.color = "red";
                                        ergebnis.innerHTML = lang_upload_invalid_type;
                                    }
                                    fileInput.value = "";
                                }
                            };
                        }
                        // --- Upload Button ---
                        var uploadBtn = dialog.querySelector('#Laden');
                        if (uploadBtn) {
                            uploadBtn.onclick = function() {
                                var rulesCheck = dialog.querySelector('#rulescheck');
                                if (!rulesCheck || !rulesCheck.checked) {
                                    alert(lang_upload_rules_agree);
                                    return false;
                                }
                                var file = fileInput ? fileInput.files[0] : null;
                                var text = dialog.querySelector('#bildText');
                                var bildText = text ? text.value.trim() : '';
                                if (!file) {
                                    alert(lang_upload_select_file_first);
                                    return;
                                }
                                var formData = new FormData();
                                formData.append("raum", $X("room").value);
                                formData.append("privat", $X("privat").value);
                                formData.append("textbold", $X("bold").value);
                                formData.append("textitalic", $X("italic").value);
                                formData.append("textcolor", $X("color").value);
                                formData.append("bildtext", bildText);
                                formData.append("file", file);
                                var client = new XMLHttpRequest();
                                var prog = dialog.querySelector('#progress');
                                var prozentSpan = dialog.querySelector('#prozent');
                                var ergebnisDiv = dialog.querySelector('#Ergebnis');
                                client.onerror = function(e) {
                                    alert(lang_error_unknown);
                                };
                                client.onload = function(e) {
                                    if (client.status == 200) {
                                        if (prog) prog.style.display = 'none';
                                        if (prozentSpan) prozentSpan.style.display = 'none';
                                        if (ergebnisDiv) {
                                            ergebnisDiv.style.display = 'block';
                                            ergebnisDiv.style.color = "green";
                                            ergebnisDiv.innerHTML = lang_upload_success;
                                        }
                                        if (fileInput) fileInput.value = "";
                                        if (text) text.value = "";
                                        setTimeout(function() {
                                            if (uploadDialog) {
                                                ChatDialog.close(); // Schließt den Upload-Dialog
                                            }
                                        }, 1500);
                                    } else {
                                        if (prog) prog.style.display = 'none';
                                        if (prozentSpan) prozentSpan.style.display = 'none';
                                        if (ergebnisDiv) {
                                            ergebnisDiv.style.display = 'block';
                                            ergebnisDiv.style.color = "red";
                                            ergebnisDiv.innerHTML = lang_upload_failed + client.status + ")";
                                        }
                                        if (fileInput) fileInput.value = "";
                                    }
                                    if (prozentSpan) prozentSpan.innerHTML = "100%";
                                    if (prog) prog.value = prog.max;
                                };
                                client.upload.onprogress = function(e) {
                                    var p = Math.round(100 / e.total * e.loaded);
                                    if (prog) prog.value = p;
                                    if (prozentSpan) prozentSpan.innerHTML = p + "% hochgeladen";
                                };
                                client.open("POST", "./?Filesend");
                                client.send(formData);
                            };
                        }
                    }
                });
            };
        }
        // Init Sound --------
        try {
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
            this.soundManager = new AudioContext();
            //creating a new request
            var a_request1 = new XMLHttpRequest();
            a_request1.open("GET", './sound/sound_privat.mp3', true);
            a_request1.responseType = 'arraybuffer';
            a_request1.onload = function() {
                //take the audio from http request and decode it in an audio buffer
                self.soundManager.decodeAudioData(a_request1.response, function(buffer) {
                    self.audioBuffer[0] = buffer; // sound_privat
                });
            };
            a_request1.send();
            var a_request2 = new XMLHttpRequest();
            a_request2.open("GET", './sound/sound_all.mp3', true);
            a_request2.responseType = 'arraybuffer';
            a_request2.onload = function() {
                //take the audio from http a_request2 and decode it in an audio buffer
                self.soundManager.decodeAudioData(a_request2.response, function(buffer) {
                    self.audioBuffer[1] = buffer; // sound_all
                });
            };
            a_request2.send();
            // NEU: rolling_dice.mp3 für den Würfel-Sound laden
            var a_request3 = new XMLHttpRequest();
            a_request3.open("GET", './sound/rolling_dice.mp3', true);
            a_request3.responseType = 'arraybuffer';
            a_request3.onload = function() {
                self.soundManager.decodeAudioData(a_request3.response, function(buffer) {
                    self.audioBuffer[2] = buffer; // rolling_dice
                });
            };
            a_request3.send();
        } catch (e) {}
        window.etChatInstance = self;
        window.chat = self;
    };
    // (Stop) Konstruktor der Class ET_Chat wird onLoad ausgefuehrt ------------------------------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Smileys fenster - MODERN mit ChatDialog
    var open_close_smileys_win = function(input_field_name) {
        // Prüfen ob bereits ein Smiley-Dialog offen ist
        var existingDialog = document.querySelector('.smileys-dialog');
        if (existingDialog && existingDialog.isConnected) {
            ChatDialog.closeDialog(existingDialog);
            return;
        }
        const isMobile = window.matchMedia("(max-width: 1024px)").matches;
        // ===== Position: 40% von oben, 60% von links, Z-Index 10002 =====
        var position = {
            top: '45%',
            left: '55%',
            zIndex: '10002'
        };
        if (isMobile) {
            ChatDialog.open({
                title: lang_dialog_smileys,
                showHeader: true,
                modal: false,
                draggable: false,
                resizable: false,
                className: "mobile-fullscreen smileys-dialog",
                html: '<div id="smileys_list" class="smileys-loading">' + lang_smileys_loading + '</div>',
                onOpen: function(dialog) {
                    // 🔥 Mobil: Volle Breite
                    dialog.style.width = '95vw';
                    dialog.style.maxWidth = '95vw';
                    loadSmileysContent(dialog, input_field_name);
                }
            });
        } else {
            var dialogRef = ChatDialog.open({
                title: lang_dialog_smileys,
                showHeader: true,
                modal: false,
                draggable: true,
                resizable: true,
                className: "extra-wide smileys-dialog",
                position: position,
                html: '<div id="smileys_list" class="smileys-loading">' + lang_smileys_loading + '</div>',
                onOpen: function(dialog) {
                    // 🔥 Breite explizit setzen
                    dialog.style.width = '900px';
                    dialog.style.maxWidth = '90vw';
                    dialog.style.minWidth = '450px';
                    loadSmileysContent(dialog, input_field_name);
                    addSmileyPopupButton(dialog, input_field_name);
                }
            });
        }
    };
    // Funktion für den Popup-Button (gelber Ordner)
    function addSmileyPopupButton(dialog, input_field_name) {
        setTimeout(function() {
            // Prüfen ob Dialog noch existiert (WICHTIG: Vor jedem DOM-Zugriff!)
            if (!dialog || !dialog.isConnected) return;
            var titleBar = dialog.querySelector('.dialog-header');
            if (!titleBar) return;
            // Prüfen ob Button bereits existiert (verhindert Duplikate)
            if (titleBar.querySelector('.smiley-popup-button')) return;
            var btn = document.createElement('button');
            btn.className = 'smiley-popup-button';
            btn.innerHTML = '📂';
            btn.title = 'Smileys in einem separaten Popup-Fenster öffnen';
            btn.style.cssText = 'background:none; border:none; cursor:pointer; font-size:18px; margin-left:10px; padding:0 5px; opacity:0.7;';
            btn.onmouseover = function() {
                this.style.opacity = '1';
            };
            btn.onmouseout = function() {
                this.style.opacity = '0.7';
            };
            btn.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                // Prüfen: Ist das ein privater Chat-Dialog?
                var isPrivateDialog = dialog.classList.contains('private-chat-dialog');
                var popupInputName = input_field_name;
                if (isPrivateDialog && input_field_name.indexOf('private_') === 0) {
                    // Für privaten Dialog: Das Input-Element in der globalen Map speichern
                    var dialogKey = input_field_name.replace('private_', '');
                    if (!window._privateInputMap) {
                        window._privateInputMap = {};
                    }
                    // Finde das Input-Feld in diesem Dialog
                    var privateInput = dialog.querySelector('.private-message-input');
                    if (privateInput) {
                        window._privateInputMap[dialogKey] = privateInput;
                        // WICHTIG: Auch die globale Variable setzen (Fallback)
                        window._tempPrivateInputElement = privateInput;
                        window._tempPrivateInputId = dialogKey;
                    }
                }
                window.open('./?Smileys&popup=1&input=' + encodeURIComponent(popupInputName), 'SmileysPopup', 'width=900,height=600,resizable=yes,scrollbars=yes,left=200,top=100');
                ChatDialog.close();
            };
            var closeBtn = titleBar.querySelector('.dialog-close');
            if (closeBtn) {
                titleBar.insertBefore(btn, closeBtn);
            } else {
                titleBar.appendChild(btn);
            }
        }, 300);
    }
    // Zentrale Funktion zum Laden des Smiley-Inhalts
    function loadSmileysContent(dialog, input_field_name) {
        fetch("./?Smileys")
            .then(res => res.text())
            .then(result => {
                var smileysContainer = dialog.querySelector('#smileys_list');
                if (smileysContainer) {
                    smileysContainer.innerHTML = result;
                    smileysContainer.classList.remove('smileys-loading');
                    // Tabs initialisieren
                    initSmileyTabs(dialog);
                    // 🔥 HIER FEHLTE DER AUFRUF!
                    initSmileyListEvents(dialog, input_field_name);
                    lazyLoadSmileysInDialog(dialog);
                    setTimeout(() => {
                        verifySmileyImagesInDialog(dialog);
                    }, 2000);
                }
            })
            .catch(err => console.error("Smileys Fehler:", err));
    }
    // Nur für Smiley-Klicks aus der Smiley-Liste (Event-Delegation - NUR EIN Listener!)
    function initSmileyListEvents(dialog, input_field_name) {
        // Container für die Smileys finden
        var smileysContainer = dialog.querySelector('#smileys_list');
        if (!smileysContainer) return;
        // Prüfen, ob der Event-Listener bereits registriert wurde
        if (smileysContainer.hasAttribute('data-smiley-listener-bound')) {
            return; // Bereits registriert, nichts tun
        }
        // Markieren, dass der Listener jetzt registriert wird
        smileysContainer.setAttribute('data-smiley-listener-bound', 'true');
        // Bestimme den Dialog-Typ (privat oder Hauptchat)
        var isForPrivateChat = (input_field_name && input_field_name.indexOf('private_') === 0);
        // Event-Delegation: EIN Listener für ALLE Smileys
        smileysContainer.addEventListener('click', function(e) {
            // Prüfen, ob das geklickte Element ein Smiley ist (oder ein Kind davon)
            var img = e.target.closest('.img_smiley');
            if (!img) return;
            e.stopPropagation();
            e.preventDefault();
            var targetInput = null;
            var smileyCode = img.id;
            // Wenn kein Smiley-Code in der ID, versuchen wir es mit data-attribute
            if (!smileyCode && img.dataset.smileyCode) {
                smileyCode = img.dataset.smileyCode;
            }
            // Ziel-Input bestimmen
            if (isForPrivateChat && window._tempPrivateInputElement && window._tempPrivateInputElement.parentNode) {
                // Privater Chat: Verwende das gespeicherte Element
                targetInput = window._tempPrivateInputElement;
            } else {
                // Hauptchat: Direkt das message-Feld holen
                targetInput = document.getElementById('message');
            }
            if (targetInput) {
                var currentValue = targetInput.value || '';
                targetInput.value = currentValue + " " + smileyCode + " ";
                targetInput.focus();
            }
            // Mobil: Dialog nach Auswahl schließen
            const isMobile = window.matchMedia("(max-width: 1024px)").matches;
            if (isMobile) {
                ChatDialog.close();
            }
        });
    }
    // Nur für die Kategorie-Tabs (ohne Smiley-Klick-Handler)
    function initSmileyTabs(dialog) {
        var katButtons = dialog.querySelectorAll('#smileys_list .kat');
        katButtons.forEach(function(el) {
            el.addEventListener('click', function(e) {
                e.preventDefault();
                var targetId = this.getAttribute('data-target');
                if (!targetId) return;
                var containers = dialog.querySelectorAll('#smileys_list .smiley-container');
                containers.forEach(function(c) {
                    c.style.display = 'none';
                });
                var kats = dialog.querySelectorAll('#smileys_list .kat');
                kats.forEach(function(a) {
                    a.classList.remove('active');
                });
                var target = dialog.querySelector('#' + targetId);
                if (target) target.style.display = 'block';
                this.classList.add('active');
            });
        });
    }
    // Lazy Loading für Smiley-Bilder
    function lazyLoadSmileysInDialog(dialog, batchSize = 20, interval = 100) {
        var imgs = Array.from(dialog.querySelectorAll('#smileys_list img[data-src]'));
        var index = 0;
        var loader = setInterval(function() {
            for (var i = 0; i < batchSize && index < imgs.length; i++, index++) {
                var img = imgs[index];
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                }
            }
            if (index >= imgs.length) clearInterval(loader);
        }, interval);
    }
    // Defekte Bilder prüfen
    function verifySmileyImagesInDialog(dialog) {
        var images = dialog.querySelectorAll('#smileys_list img.img_smiley');
        images.forEach(function(img) {
            img.onerror = function() {
                console.warn('Smiley konnte nicht geladen werden:', img.src);
                img.src = img.src + '?reload=' + Date.now();
            };
        });
    }
    // (STOP) Smileys fenster
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Zum Ausdehnen auf height 100% ----------------------------------------------------------------------
    var window_height = function() {
        // 1. Die Elemente holen
        const kopf = document.getElementById("kopf");
        const form = document.getElementById("form");
        
        // 2. Die aktuelle, echte Höhe auslesen (egal wie groß der Banner oder die Buttons gerade sind)
        const kopfHeight = kopf ? kopf.offsetHeight : 0;
        const formHeight = form ? form.offsetHeight : 0;
        
        // 3. Ein kleiner Puffer für Ränder/Abstände (z.B. 30px)
        const padding = 75; 
        
        // 4. Berechnung: Bildschirmhöhe - Kopf - Formular - Puffer
        const h = (window.innerHeight - kopfHeight - formHeight - padding) + "px";
        
        // 5. Die Höhe auf Chat und Userliste anwenden
        const chat = document.getElementById("chatinhalt");
        const online = document.getElementById("onlinelist");
        const split = document.getElementById("splitpane");
        
        if (chat && chat.style.height !== h) {
            chat.style.height = h;
            if (online) online.style.height = h;
            if (split) split.style.height = h;
        }
    };
    // (Stop) Zum Ausdehnen auf height 100% -----------------------------------------------------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Draging von Splitpane ------------------------------------------------------------------------------
    // gelöscht für Mobile Design
    // (Stop) Draging von Splitpane -------------------------------------------------------------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Hierhin wird das Erg. der AJAx Abfrage nach neuen Messages im Chat uebertragen und dargestellt -----
    var receiveResultJSON = function(ajaxResultJSON) {
        if (!self.win_private) self.win_private = [];
        // Die Uebertragung via AJAX ist beendet, weitere Anfragen duerfen gestartet werden
        self.active_get_message_req = false;
        // uebertragenes als Text klassifizieren
        var jsonInhalt = ajaxResultJSON.responseText;
        // Wenn UserIP in der Blacklist, wird der User rausgeworfen.
        if (jsonInhalt == 'blacklist') {
            location.href = "./?AfterBlacklistInsertion";
        }
        // Wenn UserID in der Kicklist, wird der User rausgeworfen.
        if (jsonInhalt == 'kick') {
            location.href = "./?AfterKicklistInsertion";
        }
        // Wenn Spammer erkannt, wird der User rausgeworfen.
        if (jsonInhalt == 'spam') {
            location.href = "./?AfterSpamlistInsertion";
        }
        // Wenn neue Datensaetze in der DB vorhanden sind, ist ein Inhalt vorhanden
        if (jsonInhalt != '') {
            // Erzeugt JSON-Literal-Object aus dem Text
            // Besser mit Try-Catch:
            try {
                var jsonObj = JSON.parse(jsonInhalt);
            } catch (e) {
                return; // Abbrechen bei Fehler
            }
            // 🔥 NEU: Fehler-Antworten (z. B. logging_out) abfangen,
            // damit kein JS-Fehler wegen jsonObj.data.length entsteht.
            if (jsonObj.error) {
                // "logging_out" = Logout läuft → still ignorieren
                // "Session user_id nicht gesetzt" = Session weg → auch ignorieren
                return;
            }
            // ===== NEU: DOM-Element cachen =====
            var chatContainer = $X('chatinhalt');
            // SoundFlag damit der Sound nur gespielt wird wenn dies eine fremde Message ist.
            var play_sound = false;
            // Welcher Sound soll abgespielt werden (0 = privat, 1 = alle)
            var sound_file = 0;
            //var win_id1 = new Array();
            var count_priv_win = 0;
            // Alle Elemende des uebertragenen MessageArrays durchlaufen und ausgeben
            for (var i = 0; i < jsonObj.data.length; i++) {
                // 🔥 NEU: Direkt auf das Objekt zugreifen
                var item = jsonObj.data[i];
                var id = item.id;
                var sex = item.sex;
                var priv = item.priv;
                var user_id = item.user_id;
                var user = item.user;
                var message = item.message;
                var css = item.css;
                var time = item.time;
                var avatar = item.avatar;
                var privat = item.privat;
                // Jede neue Message wird in ein neu erzeugtes DIV verpackt.
                if (id && id !== '') {
                    var newDIV = document.createElement('div');
                    newDIV.id = "a" + id;
                    chatContainer.appendChild(newDIV);
                }
                // Das oben angelegte DIV mit Inhalt auf dem JSON-Object befuellen
                if (self.set_ch_an_gender == 1) {
                    if (sex == "m") var gender_icon = "<img src=\"img/user_" + sex + ".png\" align=\"absbottom\" />";
                    if (sex == "f") var gender_icon = "<img src=\"img/user_" + sex + ".png\" align=\"absbottom\" />";
                    if (sex == "n") var gender_icon = "<img src=\"img/user_" + sex + ".png\" align=\"absbottom\" />";
                    if (sex == "d") var gender_icon = "<img src=\"img/user_" + sex + ".png\" align=\"absbottom\" />";
                    if (user_id == 1) var gender_icon = "";
                } else {
                    if (sex == "m") var gender_icon = "";
                    if (sex == "f") var gender_icon = "";
                    if (sex == "n") var gender_icon = "";
                    if (sex == "d") var gender_icon = "";
                    if (user_id == 1) var gender_icon = "";
                }
                if (self.set_ch_an_privi == 1) {
                    if (priv == "admin") var priv_icon = "<span class=\"kreis-buchstabe-c\"  title=\"" + priv + "\" aria-label=\"" + priv + "\" style=\"background-color: " + self.co_admin + ";\">A</span>";
                    else if (priv == "mod") priv_icon = "<span class=\"kreis-buchstabe-c\"  title=\"" + priv + "\" aria-label=\"" + priv + "\" style=\"background-color: " + self.co_mod + ";\">M</span>";
                    else if (priv == "gast") var priv_icon = "<span class=\"kreis-buchstabe-c\"  title=\"" + priv + "\" aria-label=\"" + priv + "\" style=\"background-color: " + self.co_gast + ";\">G</span>";
                    else if (priv == "user") var priv_icon = "<span class=\"kreis-buchstabe-c\"  title=\"" + priv + "\" aria-label=\"" + priv + "\" style=\"background-color: " + self.co_user + ";\">H</span>";
                    else if (priv == "grafik") var priv_icon = "<span class=\"kreis-buchstabe-c\"  title=\"" + priv + "\" aria-label=\"" + priv + "\" style=\"background-color: " + self.co_admin + ";\">GR</span>";
                    else if (priv == "chatwache") var priv_icon = "<span class=\"kreis-buchstabe-c\"  title=\"" + priv + "\" aria-label=\"" + priv + "\" style=\"background-color: " + self.co_admin + ";\">C</span>";
                    else if (priv == "co_admin") var priv_icon = "<span class=\"kreis-buchstabe-c\"  title=\"" + priv + "\" aria-label=\"" + priv + "\" style=\"background-color: " + self.co_admin + ";\">CA</span>";
                    else var priv_icon = "";
                } else {
                    var priv_icon = "";
                }
                if (self.u_bild == 1 && self.set_chat_pic == 1) {
                    var avatar_bild = '<img class=\"avatar\" id=\"infoblock_' + user_id + '\" src=\"avatar/' + avatar + '\" width=\"auto\" height=\"64px\" style=\"cursor:pointer;\" title=\"Benutzer Profil\">';
                } else {
                    var avatar_bild = '';
                }
                var user_color2 = "";
                if (priv == "admin") var user_color2 = "color: " + self.co_admin + ";";
                if (priv == "mod") var user_color2 = "color: " + self.co_mod + ";";
                if (priv == "user") var user_color2 = "color: " + self.co_user + ";";
                if (priv == "gast") var user_color2 = "color: " + self.co_gast + ";";
                if (priv == "grafik") var user_color2 = "color: " + self.co_admin + ";";
                if (priv == "chatwache") var user_color2 = "color: " + self.co_admin + ";";
                if (priv == "co_admin") var user_color2 = "color: " + self.co_admin + ";";
                if (privat == '0') {
                    if (user_id == self.user_id) var userstyle_clickable = "style=\"" + user_color2 + "\"";
                    else var userstyle_clickable = "id=\"inflblock_" + user_id + "\" style=\"cursor:pointer; " + user_color2 + "\"";
                    $X("a" + id).innerHTML = "<div class=\"mess_back\">" + avatar_bild + "<i>" + (self.set_an_time ? time + " - " : "") + "</i> " + gender_icon + priv_icon + " <b " + userstyle_clickable + ">" + user + "</b>: <span style=\"" + css + "\">" + message + "</span></div>";
                } else {
                    if (id && id !== '') {
                        if (user_id == self.user_id) $X("a" + id).innerHTML = "<div class=\"privat_ausg_von\">" + avatar_bild + "<i>" + (self.set_an_time ? time + " - " : "") + "</i> " + gender_icon + priv_icon + " <b style=\"" + user_color2 + "\">" + user + "</b> <i>(" + lang_receiveResultJSON_1 + " " + self.privat_an + ")</i>: <span style=\"" + css + "\">" + message + "</span></div>";
                        else $X("a" + id).innerHTML = "<div class=\"privat_ausg_an\">" + avatar_bild + "<i>" + (self.set_an_time ? time + " - " : "") + "</i> " + gender_icon + priv_icon + " <b id=\"inflblock_" + user_id + "\" style=\"cursor:pointer; " + user_color2 + "\">" + user + "</b> <i>(" + lang_receiveResultJSON_2 + ")</i>: <span style=\"" + css + "\">" + message + "</span></div>";
                    } else {
                        // privat win - NEU mit ChatDialog
                        var dialogKey = self.getPrivateDialogKey(user_id, privat);
                        var isOpen = (self.win_private[dialogKey] && self.win_private[dialogKey].isOpen);
                        // ===== Wenn ein Popup für diesen Partner offen ist, NICHT in den Dialog schreiben =====
                        // (Das Popup holt sich die Nachrichten selbst über ?PrivateMessages)
                        var popupPartnerId = (user_id == self.user_id) ? privat : user_id;
                        if (self._privatePopups && self._privatePopups[popupPartnerId] && !self._privatePopups[popupPartnerId].closed) {
                            // Popup ist offen → Nachricht wird vom Popup selbst geladen
                            // Nur Sound abspielen (falls gewünscht) und weiter
                            if (user_id != self.user_id) {
                                if (self.sound_status == "all") {
                                    play_sound = true;
                                    sound_file = (privat != '0') ? 0 : 1;
                                }
                                if (self.sound_status == "privat" && privat != '0') {
                                    play_sound = true;
                                    sound_file = 0;
                                }
                            }
                            // Nachricht ausblenden (nicht im Hauptfenster anzeigen)
                            if (id && id !== '') {
                                const el = document.getElementById('a' + id);
                                if (el) el.style.display = 'none';
                            }
                            continue; // Nächste Nachricht
                        }
                        if (!isOpen) {
                            // Fenster ist nicht offen - Gegner-Daten sammeln
                            var privat_win_opponent = (user_id == self.user_id) ? self.privat_an : user;
                            var privat_win_opponent_id = (user_id == self.user_id) ? privat : user_id;
                            // Gespeicherten Verlauf laden
                            var savedContent = self.loadPrivateDialogContent(dialogKey);
                            // AKTUELLE Nachricht für die Anzeige vorbereiten (wichtig für erste Nachricht!)
                            var currentMessageHtml = '';
                            var isOwnMessage = (user_id == self.user_id);
                            // 🔥 NEU: data-* setzen (für Duplikat-Check im Popup)
                            var msgAttrs = ' data-user-id="' + escapeHtml(String(user_id)) + '"' +
                                ' data-time="' + escapeHtml(String(time)) + '"' +
                                ' data-message="' + (function() {
                                    try {
                                        return btoa(unescape(encodeURIComponent(String(message))));
                                    } catch (e) {
                                        return escapeHtml(String(message));
                                    }
                                })() + '"';

                            if (isOwnMessage) {
                                currentMessageHtml = '<div class="private-message own"' + msgAttrs + ' style="text-align:right; margin:4px 0;">' +
                                    '<span style="background:#5cb85c; padding:8px 12px; border-radius:18px; display:inline-block; max-width:80%; word-wrap:break-word;">' + message + '</span>' +
                                    '</div>';
                            } else {
                                currentMessageHtml = '<div class="private-message other"' + msgAttrs + ' style="text-align:left; margin:4px 0;">' +
                                    '<span style="background:#444; padding:8px 12px; border-radius:18px; display:inline-block; max-width:80%; word-wrap:break-word;">' +
                                    '<b style="color:#5cb85c;">' + user.unescapeHTML() + ':</b> ' + message + '</span>' +
                                    '</div>';
                            }
                            // Bestehenden Verlauf + neue Nachricht kombinieren
                            var existingHtml = savedContent ? savedContent.html : '';
                            var combinedHtml = existingHtml + currentMessageHtml;
                            // Dialog öffnen (nur wenn nicht schon offen)
                            var isMobile = window.matchMedia("(max-width: 1024px)").matches;
                            var dialogWidth = isMobile ? '95vw' : '450px';
                            var dialogHeight = isMobile ? '70vh' : '500px';
                            var newDialog = ChatDialog.open({
                                title: lang_private_chat_title + privat_win_opponent,
                                showHeader: true,
                                modal: false,
                                draggable: true,
                                resizable: true,
                                className: 'private-chat-dialog',
                                html: '<div class="private-chat-container" style="display:flex; flex-direction:column; height:100%;">' +
                                    '<div class="private-messages-area" style="flex:1; overflow-y:auto; padding:10px; background:#1a1a1a;">' +
                                    '<div class="private-messages-container" style="display:flex; flex-direction:column; gap:8px;">' +
                                    combinedHtml +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="private-input-area" style="padding:10px; border-top:1px solid #333; background:#2a2a2a;">' +
                                    '<div style="display:flex; gap:8px; align-items:center;">' +
                                    '<input type="text" class="private-message-input" placeholder="' + lang_private_chat_placeholder + '" ' +
                                    'style="flex:1; padding:8px 12px; border-radius:20px; border:1px solid #444; background:#1e1e1e; color:#fff; outline:none;">' +
                                    '<button class="private-send-btn" style="background:#5cb85c; border:none; border-radius:20px; padding:8px 16px; color:white; cursor:pointer;">📨</button>' +
                                    '<button class="private-smiley-btn" style="background:#f0ad4e; border:none; border-radius:20px; padding:8px 12px; color:white; cursor:pointer;">😊</button>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>',
                                onOpen: function(dlg) {
                                    self.win_private[dialogKey] = {
                                        dialog: dlg,
                                        isOpen: true,
                                        otherUserId: privat_win_opponent_id,
                                        otherUserName: privat_win_opponent,
                                        dialogKey: dialogKey
                                    };
                                    // ===== 📂 Popup-Button in die Titelleiste einfügen =====
                                    (function(dlgRef, oid, oname, dkey) {
                                        setTimeout(function() {
                                            if (!dlgRef || !dlgRef.isConnected) return;
                                            var titleBar = dlgRef.querySelector('.dialog-header');
                                            if (!titleBar || titleBar.querySelector('.private-popup-button')) return;
                                            var popupBtn = document.createElement('button');
                                            popupBtn.className = 'private-popup-button';
                                            popupBtn.innerHTML = '📂';
                                            popupBtn.title = 'Privatchat in einem separaten Fenster öffnen';
                                            popupBtn.style.cssText = 'background:none; border:none; cursor:pointer; font-size:18px; margin-left:10px; padding:0 5px; opacity:0.7;';
                                            popupBtn.onmouseover = function() {
                                                this.style.opacity = '1';
                                            };
                                            popupBtn.onmouseout = function() {
                                                this.style.opacity = '0.7';
                                            };
                                            popupBtn.onclick = function(e) {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                try {
                                                    var mc = dlgRef.querySelector('.private-messages-container');
                                                    var ma = dlgRef.querySelector('.private-messages-area');
                                                    if (mc) {
                                                        self.savePrivateDialogContent(dkey, mc.innerHTML, ma ? ma.scrollTop : 0);
                                                    }
                                                    self.openPrivateChatPopup(oid, oname, dkey);
                                                    ChatDialog.closeDialog(dlgRef);
                                                } catch (err) {
                                                    console.error('FEHLER:', err);
                                                    console.error('Stack:', err.stack);
                                                }
                                            };
                                            var closeBtn = titleBar.querySelector('.dialog-close');
                                            if (closeBtn) titleBar.insertBefore(popupBtn, closeBtn);
                                            else titleBar.appendChild(popupBtn);
                                        }, 150);
                                    })(dlg, privat_win_opponent_id, privat_win_opponent, dialogKey);
                                    var messagesContainer = dlg.querySelector('.private-messages-container');
                                    var inputField = dlg.querySelector('.private-message-input');
                                    var sendBtn = dlg.querySelector('.private-send-btn');
                                    var smileyBtn = dlg.querySelector('.private-smiley-btn');
                                    var messagesArea = dlg.querySelector('.private-messages-area');
                                    if (savedContent && savedContent.scrollTop > 0 && messagesArea) {
                                        setTimeout(function() {
                                            if (messagesArea && messagesArea.isConnected) {
                                                messagesArea.scrollTop = savedContent.scrollTop;
                                            }
                                        }, 50);
                                    } else if (messagesArea) {
                                        setTimeout(function() {
                                            if (messagesArea && messagesArea.isConnected) {
                                                messagesArea.scrollTop = messagesArea.scrollHeight;
                                            }
                                        }, 100);
                                    }
                                    var sendMessage = function() {
                                        var msg = inputField.value.trim();
                                        if (msg === '') return;
                                        self.send2privatwinDialog(dialogKey, privat_win_opponent_id, msg, inputField);
                                    };
                                    if (sendBtn) sendBtn.onclick = sendMessage;
                                    if (inputField) {
                                        inputField.onkeypress = function(e) {
                                            if (e.key === 'Enter') {
                                                e.preventDefault();
                                                sendMessage();
                                            }
                                        };
                                        inputField.focus();
                                    }
                                    if (smileyBtn) {
                                        smileyBtn.onclick = function() {
                                            window._tempPrivateInputId = dialogKey;
                                            window._tempPrivateInputElement = inputField;
                                            open_close_smileys_win('private_' + dialogKey);
                                        };
                                    }
                                    var adjustHeight = function() {
                                        var header = dlg.querySelector('.dialog-header');
                                        var headerHeight = header ? header.offsetHeight : 50;
                                        var contentDiv = dlg.querySelector('.dialog-content');
                                        if (contentDiv) {
                                            var availableHeight = dlg.offsetHeight - headerHeight - 4;
                                            contentDiv.style.height = availableHeight + 'px';
                                            var container = dlg.querySelector('.private-chat-container');
                                            if (container) container.style.height = availableHeight + 'px';
                                        }
                                    };
                                    setTimeout(function() {
                                        if (dlg && dlg.isConnected) {
                                            adjustHeight();
                                        }
                                    }, 50);
                                    var resizeObserver = new ResizeObserver(function() {
                                        adjustHeight();
                                    });
                                    resizeObserver.observe(dlg);
                                    dlg._resizeObserver = resizeObserver;
                                },
                                onClose: function() {
                                    if (self.win_private && self.win_private[dialogKey]) {
                                        var dlg = self.win_private[dialogKey].dialog;
                                        if (dlg) {
                                            var messagesContainer = dlg.querySelector('.private-messages-container');
                                            var messagesArea = dlg.querySelector('.private-messages-area');
                                            if (messagesContainer) {
                                                self.savePrivateDialogContent(dialogKey, messagesContainer.innerHTML, messagesArea ? messagesArea.scrollTop : 0);
                                            }
                                            if (dlg._resizeObserver) {
                                                dlg._resizeObserver.disconnect();
                                                delete dlg._resizeObserver;
                                            }
                                        }
                                        self.win_private[dialogKey].isOpen = false;
                                        self.win_private[dialogKey].dialog = null;
                                    }
                                    var mainInput = $X('message');
                                    if (mainInput) mainInput.focus();
                                }
                            });
                        } else {
                            // Fenster ist bereits offen - nur die Nachricht hinzufügen
                            var existingDialog = self.win_private[dialogKey].dialog;
                            if (existingDialog) {
                                var messagesContainer = existingDialog.querySelector('.private-messages-container');
                                if (messagesContainer) {
                                    var msgDiv = document.createElement('div');
                                    msgDiv.className = 'private-message other';
                                    // 🔥 NEU: data-* setzen (für Duplikat-Check im Popup)
                                    msgDiv.setAttribute('data-user-id', String(user_id));
                                    msgDiv.setAttribute('data-time', String(time));
                                    try {
                                        msgDiv.setAttribute('data-message', btoa(unescape(encodeURIComponent(String(message)))));
                                    } catch (e) {
                                        msgDiv.setAttribute('data-message', escapeHtml(String(message)));
                                    }
                                    msgDiv.style.cssText = 'text-align:left; margin:4px 0;';
                                    msgDiv.innerHTML = '<span style="background:#444; padding:8px 12px; border-radius:18px; display:inline-block; max-width:80%; word-wrap:break-word;">' +
                                        '<b style="color:#5cb85c;">' + user.unescapeHTML() + ':</b> ' + message + '</span>';
                                    messagesContainer.appendChild(msgDiv);
                                    var messagesArea = existingDialog.querySelector('.private-messages-area');
                                    if (messagesArea) messagesArea.scrollTop = messagesArea.scrollHeight;
                                    self.savePrivateDialogContent(dialogKey, messagesContainer.innerHTML, messagesArea ? messagesArea.scrollTop : 0);
                                }
                            }
                        }
                    }
                    // Zuerst das neue DIV verstecken (nur bei echten Nachrichten, nicht bei Privatfenster)
                    if (id && id !== '') {
                        const el = document.getElementById('a' + id);
                        if (el) el.style.display = 'none';
                    }
                } // ← Ende else-Zweig (privat != '0')
                // ===== Sound-Logik: für ALLE Nachrichten (privat + normal) =====
                if (user_id != self.user_id) {
                    if (self.sound_status == "all") {
                        play_sound = true;
                        sound_file = (privat != '0') ? 0 : 1;
                    } else if (self.sound_status == "privat" && privat != '0') {
                        play_sound = true;
                        sound_file = 0;
                    }
                    if (!self.window_focused && play_sound) {
                        try {
                            window.clearInterval(self.intv_title_blink);
                        } catch (e) {}
                        self.intv_title_blink = window.setInterval(function() {
                            document.title = (document.title == lang_titleAlert) ? self.title : lang_titleAlert;
                        }, 1000);
                    }
                }
            } // ← Ende for-Schleife
            // sound ---------------------------
            //alert(self.sound_status+ ' '+ play_sound);
            if (play_sound) {
                var audio_source = self.soundManager.createBufferSource();
                audio_source.buffer = self.audioBuffer[sound_file];
                audio_source.connect(self.soundManager.destination);
                audio_source.start(0);
            }
            // ===== OPTIMIERT: Alle Nachrichten in EINER Schleife verarbeiten =====
            var dataLength = jsonObj.data.length;
            for (var i = 0; i < dataLength; i++) {
                var item = jsonObj.data[i];
                var itemId = item.id;
                // --- 1. Animation (Grow-Effekt) ---
                if (itemId && itemId !== '') {
                    var elem = $X('a' + itemId);
                    if (elem) {
                        elem.style.display = 'block';
                        elem.classList.add('chat-message-grow');
                        (function(el) {
                            el.addEventListener('animationend', function onGrowEnd() {
                                el.classList.remove('chat-message-grow');
                                if (bla == 1) {
                                    chatContainer.scrollTop = chatContainer.scrollHeight;
                                }
                                el.removeEventListener('animationend', onGrowEnd);
                            }, {
                                once: true
                            });
                        })(elem);
                    }
                }
                // --- 2. Alte Nachrichten ausblenden ---
                var div_id = Number(itemId) - self.messages_im_chat;
                if (div_id > 0) {
                    var oldElem = $X('a' + div_id);
                    if (oldElem) {
                        oldElem.classList.add('chat-message-switchoff');
                        (function(el, divId) {
                            el.addEventListener('animationend', function onSwitchEnd() {
                                el.classList.remove('chat-message-switchoff');
                                el.style.display = 'none';
                                // Aufräumen alter DIVs (sicherer ohne eval)
                                var removeId = divId - dataLength;
                                var removeEl = $X('a' + removeId);
                                if (removeEl && removeEl.style.display !== "none") {
                                    removeEl.style.display = "none";
                                }
                                var removeId2 = divId - dataLength - 1;
                                var removeEl2 = $X('a' + removeId2);
                                if (removeEl2 && removeEl2.style.display !== "none") {
                                    removeEl2.style.display = "none";
                                }
                                var removeId3 = divId - dataLength - 2;
                                var removeEl3 = $X('a' + removeId3);
                                if (removeEl3 && removeEl3.style.display !== "none") {
                                    removeEl3.style.display = "none";
                                }
                                el.removeEventListener('animationend', onSwitchEnd);
                            }, {
                                once: true
                            });
                        })(oldElem, div_id);
                    }
                }
            }
        }
    };
    // (Stop) Hierhin wird das Erg. der AJAX Abfrage nach neuen Messages im Chat uebertragen und dargestellt -------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Anfrage an den Reloader wird im Interval this.reload_interval aufgerufen ---------------------------
    var AjaxReadRequest = function() {
        var AktuellesDatum = new Date();
        var time_now = Date.parse(AktuellesDatum);
        // Initial setzen
        if (self.time_last_send == 0) self.time_last_send = time_now;
        // Nur für normale User
        if (
            self.userPrivilegienGlobal != "admin" &&
            self.userPrivilegienGlobal != "mod" &&
            self.userPrivilegienGlobal != "grafik" &&
            self.userPrivilegienGlobal != "chatwache" &&
            self.userPrivilegienGlobal != "co_admin"
        ) {
            // Inactivity Warnung
            if (
                !self.inactivity_message_flag &&
                time_now - self.time_last_send > self.interval_for_inactivity - 30000
            ) {
                self.sendSysMessages(
                    $X("room").value,
                    lang_AjaxReadRequest_1,
                    self.user_id
                );
                self.inactivity_message_flag = true;
            }
            // Timeout Logout
            if (time_now - self.time_last_send > self.interval_for_inactivity) {
                location.href =
                    "./?Logout&random_user_number=" +
                    self.random_user_number +
                    "&reason=timeout&r=" +
                    $X("room").value;
            }
        }
        // Request Throttle
        if ((time_now - self.time_last_req) > (self.reload_interval / 2)) {
            self.time_last_req = time_now;
            if (!self.active_get_message_req) {
                // ===== NEU: Zuerst prüfen (leichter Check) =====
                if (self.lastMessageId) {
                    // Nur wenn wir schon eine ID haben, prüfen wir
                    fetch("./?LastMessageId&room=" + encodeURIComponent($X("room").value))
                        .then(res => res.text())
                        .then(currentId => {
                            if (self.lastMessageId === currentId) {
                                // Keine neuen Nachrichten → Reloader mit "keine neuen" aufrufen
                                self.doReloadMessages(true);
                            } else {
                                // Neue Nachrichten vorhanden
                                self.lastMessageId = currentId;
                                self.doReloadMessages(false);
                            }
                        })
                        .catch(() => {
                            // Bei Fehler trotzdem laden
                            self.doReloadMessages(false);
                        });
                } else {
                    // Erster Aufruf - ID noch nicht bekannt
                    fetch("./?LastMessageId&room=" + encodeURIComponent($X("room").value))
                        .then(res => res.text())
                        .then(currentId => {
                            self.lastMessageId = currentId;
                            self.doReloadMessages(false);
                        })
                        .catch(() => {
                            self.doReloadMessages(false);
                        });
                }
                // ===== ENDE NEU =====
            }
        }
    };
    // Ausgelagerte Funktion - wir rufen ReloaderMessages IMMER auf!
    this.doReloadMessages = function(noNewMessages) {
        self.active_get_message_req = true;
        const body = "room=" + encodeURIComponent($X("room").value) +
            "&privat=" + encodeURIComponent($X("privat").value) +
            "&no_new_messages=" + (noNewMessages ? "1" : "0");
        fetch("./?ReloaderMessages", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: body
            })
            .then(res => res.text())
            .then(result => {
                // Nur wenn neue Nachrichten da sind, verarbeiten
                if (result !== '{"data":[]}') {
                    receiveResultJSON({
                        responseText: result
                    });
                }
                self.active_get_message_req = false;
            })
            .catch(err => {
                self.active_get_message_req = false;
            });
    };
    // (Stop) Anfrage an den Reloader wird im Interval this.reload_interval aufgerufen ----------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Anfrage an den Reloader mit Datenuebergabe vom User, also beim Sender der Massage in den Chat -------
    this.send = function() {
        var AktuellesDatum = new Date();
        this.time_last_req = this.time_last_send = Date.parse(AktuellesDatum);
        // Damit in Falle einer zu langen Inaktivitaet der User informiert wird.
        // Ohme einen Flag bekommt er staendige Mlendungen siehe Zeile 373
        this.inactivity_message_flag = false;
        //check, ob der User online ist
        if ($X("privat").value > 0 && !self.userOnlineNow($X("privat").value)) {
            ChatDialog.open({
                title: lang_warning_user_away_2_1 || lang_warning,
                showHeader: true,
                modal: true,
                draggable: false,
                resizable: false,
                className: "warning-dialog",
                html: '<div style="text-align:center; padding:15px;"><img src="img/messagebox_warning.png" width="32" height="32" style="margin-bottom:10px;"><p style="margin:0;">' + lang_warning_user_away_2_2 + '</p><button id="warning_ok" style="margin-top:15px; padding:6px 20px; background:#5cb85c; border:none; border-radius:4px; color:white; cursor:pointer;">' + lang_button_ok + '</button></div>',
                onOpen: function(dialog) {
                    dialog.querySelector('#warning_ok').onclick = function() {
                        ChatDialog.close();
                    };
                    setTimeout(function() {
                        ChatDialog.close();
                    }, 10000);
                }
            });
        }
        var myAjaxObj = fetch("./?ReloaderMessages", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: new URLSearchParams(new FormData($X("message_form"))).toString()
            })
            .then(res => res.text())
            .then(erg => {
                // Schreibfeld wieder freigeben (wie vorher verzögert)
                if ($X('message').disabled) {
                    setTimeout(let_write, 300);
                }
                // alte Prototype-Kompatibilität beibehalten
                receiveResultJSON({
                    responseText: erg
                });
            })
            .catch(err => console.error("ReloaderMessages Fehler:", err));
        // Nach Versand Feld deaktivieren
        $X('message').value = lang_send_1;
        $X('message').blur();
        $X('message').disabled = true;
        return false;
    };
    // (Stop) Anfrage an den Reloader mit Datenuebergabe vom User, also beim Sender der Massage in den Chat --------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Anfrage an den Reloader mit Datenuebergabe vom User, nur für PrivatWin -------
    // Neue Funktion: Nachricht aus Dialog senden
    this.send2privatwinDialog = function(dialogKey, toUserId, message, inputField) {
        var self = this;
        if (!inputField) return;
        inputField.disabled = true;
        // Prüfen ob Empfänger online ist
        if (!self.userOnlineNow(toUserId)) {
            // Fehlermeldung im Dialog anzeigen
            var dialog = self.win_private[dialogKey] ? self.win_private[dialogKey].dialog : null;
            if (dialog) {
                var messagesContainer = dialog.querySelector('.private-messages-container');
                if (messagesContainer) {
                    var errorDiv = document.createElement('div');
                    errorDiv.className = 'private-message system';
                    errorDiv.style.cssText = 'text-align:center; margin:4px 0;';
                    errorDiv.innerHTML = '<span style="background:#d9534f; color:white; padding:4px 8px; border-radius:12px; font-size:12px;">' + lang_private_opponent_offline + '</span>';
                    messagesContainer.appendChild(errorDiv);
                    var area = dialog.querySelector('.private-messages-area');
                    if (area) area.scrollTop = area.scrollHeight;
                    self.savePrivateDialogContent(dialogKey, messagesContainer.innerHTML, area ? area.scrollTop : 0);
                }
            }
            inputField.disabled = false;
            inputField.value = '';
            inputField.focus();
            return false;
        }
        // Nachricht vorbereiten
        var msgText = "/window: " + message;
        var encodedMessage = decodeURIComponent((msgText + '').replace(/\&/g, '%26').replace(/\+/g, '%2B').replace(/\%/g, '%25'));
        // Senden
        fetch("./?ReloaderMessages", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: "room=" + encodeURIComponent($X('room').value) +
                    "&message=" + encodeURIComponent(encodedMessage) +
                    "&privat=" + encodeURIComponent(toUserId) +
                    "&bold=" + encodeURIComponent($X('bold').value) +
                    "&italic=" + encodeURIComponent($X('italic').value) +
                    "&color=" + encodeURIComponent($X('color').value)
            })
            .then(function(res) {
                return res.text();
            })
            .then(function(erg) {
                // Empfangene Nachrichten verarbeiten (das fügt auch die Antwort des anderen hinzu)
                receiveResultJSON({
                    responseText: erg
                });
                // Eingabefeld zurücksetzen
                inputField.disabled = false;
                inputField.value = '';
                inputField.focus();
                // Aktualisiere Dialog-Inhalt (falls sich was geändert hat)
                var dialog = self.win_private[dialogKey] ? self.win_private[dialogKey].dialog : null;
                if (dialog) {
                    var messagesContainer = dialog.querySelector('.private-messages-container');
                    var messagesArea = dialog.querySelector('.private-messages-area');
                    if (messagesContainer) {
                        self.savePrivateDialogContent(dialogKey, messagesContainer.innerHTML, messagesArea ? messagesArea.scrollTop : 0);
                    }
                }
            })
            .catch(function(err) {
                inputField.disabled = false;
                if (inputField) inputField.focus();
            });
        return false;
    };
    // (Stop) Anfrage an den Reloader mit Datenuebergabe vom User, nur für PrivatWin -------
    // NEUE Funktion: Öffnet einen Privat-Chat-Dialog (ersetzt die alte Window-Logik)
    this.openPrivateChatDialog = function(otherUserId, otherUserName) {
        var self = this;
        if (!self.win_private) self.win_private = [];
        var dialogKey = self.getPrivateDialogKey(self.user_id, otherUserId);
        if (self.win_private[dialogKey] && self.win_private[dialogKey].isOpen) {
            var existingDlg = self.win_private[dialogKey].dialog;
            if (existingDlg) {
                // showModal() würde auf einem bereits offenen <dialog> eine Exception werfen
                if (!existingDlg.open) {
                    existingDlg.showModal();
                }
                existingDlg.style.zIndex = '10000';
                setTimeout(function() {
                    var input = existingDlg.querySelector('.private-message-input');
                    if (input) input.focus();
                }, 100);
            }
            return;
        }
        var savedContent = self.loadPrivateDialogContent(dialogKey);
        var isMobile = window.matchMedia("(max-width: 1024px)").matches;
        var dialog = ChatDialog.open({
            title: lang_private_chat_title + otherUserName,
            showHeader: true,
            modal: false,
            draggable: true,
            resizable: true,
            className: 'private-chat-dialog',
            html: '<div class="private-chat-container" style="display:flex; flex-direction:column; height:100%;">' +
                '<div class="private-messages-area" style="flex:1; overflow-y:auto; padding:10px; background:#1a1a1a;">' +
                '<div class="private-messages-container" style="display:flex; flex-direction:column; gap:8px;">' +
                (savedContent ? savedContent.html : '') +
                '</div>' +
                '</div>' +
                '<div class="private-input-area" style="padding:10px; border-top:1px solid #333; background:#2a2a2a;">' +
                '<div style="display:flex; gap:8px; align-items:center;">' +
                '<input type="text" class="private-message-input" placeholder="' + lang_private_chat_placeholder + '" ' +
                'style="flex:1; padding:8px 12px; border-radius:20px; border:1px solid #444; background:#1e1e1e; color:#fff; outline:none;">' +
                '<button class="private-send-btn" style="background:#5cb85c; border:none; border-radius:20px; padding:8px 16px; color:white; cursor:pointer;">📨</button>' +
                '<button class="private-smiley-btn" style="background:#f0ad4e; border:none; border-radius:20px; padding:8px 12px; color:white; cursor:pointer;">😊</button>' +
                '</div>' +
                '</div>' +
                '</div>',
            onOpen: function(dlg) {
                self.win_private[dialogKey] = {
                    dialog: dlg,
                    isOpen: true,
                    otherUserId: otherUserId,
                    otherUserName: otherUserName,
                    dialogKey: dialogKey
                };
                // ===== 📂 Popup-Button in die Titelleiste einfügen =====
                setTimeout(function() {
                    if (!dlg || !dlg.isConnected) return;
                    var titleBar = dlg.querySelector('.dialog-header');
                    if (!titleBar || titleBar.querySelector('.private-popup-button')) return;
                    var popupBtn = document.createElement('button');
                    popupBtn.className = 'private-popup-button';
                    popupBtn.innerHTML = '📂';
                    popupBtn.title = 'Privatchat in einem separaten Fenster öffnen';
                    popupBtn.style.cssText = 'background:none; border:none; cursor:pointer; font-size:18px; margin-left:10px; padding:0 5px; opacity:0.7;';
                    popupBtn.onmouseover = function() {
                        this.style.opacity = '1';
                    };
                    popupBtn.onmouseout = function() {
                        this.style.opacity = '0.7';
                    };
                    popupBtn.onclick = function(e) {
                        e.preventDefault();
                        e.stopPropagation();

                        try {
                            var mc = dlg.querySelector('.private-messages-container');
                            var ma = dlg.querySelector('.private-messages-area');

                            // Verlauf in localStorage speichern (wird vom Popup automatisch gesehen)
                            if (mc) {
                                self.savePrivateDialogContent(dialogKey, mc.innerHTML, ma ? ma.scrollTop : 0);
                            }

                            // Popup öffnen
                            self.openPrivateChatPopup(otherUserId, otherUserName, dialogKey);

                            // Dialog schließen
                            ChatDialog.closeDialog(dlg);
                        } catch (err) {
                            console.error('FEHLER:', err);
                        }
                    };
                    var closeBtn = titleBar.querySelector('.dialog-close');
                    if (closeBtn) titleBar.insertBefore(popupBtn, closeBtn);
                    else titleBar.appendChild(popupBtn);
                }, 150);
                var messagesContainer = dlg.querySelector('.private-messages-container');
                var inputField = dlg.querySelector('.private-message-input');
                var sendBtn = dlg.querySelector('.private-send-btn');
                var smileyBtn = dlg.querySelector('.private-smiley-btn');
                var messagesArea = dlg.querySelector('.private-messages-area');
                if (savedContent && savedContent.scrollTop > 0 && messagesArea) {
                    setTimeout(function() {
                        // Prüfen ob messagesArea noch existiert
                        if (messagesArea && messagesArea.isConnected) {
                            messagesArea.scrollTop = savedContent.scrollTop;
                        }
                    }, 50);
                }
                var sendMessage = function() {
                    var msg = inputField.value.trim();
                    if (msg === '') return;
                    self.send2privatwinDialog(dialogKey, otherUserId, msg, inputField);
                };
                if (sendBtn) sendBtn.onclick = sendMessage;
                if (inputField) {
                    inputField.onkeypress = function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            sendMessage();
                        }
                    };
                    inputField.focus();
                }
                if (smileyBtn) {
                    smileyBtn.onclick = function() {
                        window._tempPrivateInputId = dialogKey;
                        window._tempPrivateInputElement = inputField;
                        open_close_smileys_win('private_' + dialogKey);
                    };
                }
                var adjustHeight = function() {
                    var header = dlg.querySelector('.dialog-header');
                    var headerHeight = header ? header.offsetHeight : 50;
                    var contentDiv = dlg.querySelector('.dialog-content');
                    if (contentDiv) {
                        var availableHeight = dlg.offsetHeight - headerHeight - 4;
                        contentDiv.style.height = availableHeight + 'px';
                        var container = dlg.querySelector('.private-chat-container');
                        if (container) container.style.height = availableHeight + 'px';
                    }
                };
                setTimeout(function() {
                    // Prüfen ob dlg (der Dialog) noch existiert
                    if (dlg && dlg.isConnected) {
                        adjustHeight();
                    }
                }, 50);
                // 🔥 Resize-Observer mit Speicherung
                var resizeObserver = new ResizeObserver(function() {
                    adjustHeight();
                });
                resizeObserver.observe(dlg);
                dlg._resizeObserver = resizeObserver;
            },
            onClose: function() {
                if (self.win_private && self.win_private[dialogKey]) {
                    var dlg = self.win_private[dialogKey].dialog;
                    if (dlg) {
                        var messagesContainer = dlg.querySelector('.private-messages-container');
                        var messagesArea = dlg.querySelector('.private-messages-area');
                        if (messagesContainer) {
                            self.savePrivateDialogContent(dialogKey, messagesContainer.innerHTML, messagesArea ? messagesArea.scrollTop : 0);
                        }
                        // 🔥 ResizeObserver aufräumen
                        if (dlg._resizeObserver) {
                            dlg._resizeObserver.disconnect();
                            delete dlg._resizeObserver;
                        }
                    }
                    self.win_private[dialogKey].isOpen = false;
                    self.win_private[dialogKey].dialog = null;
                }
                var mainInput = $X('message');
                if (mainInput) mainInput.focus();
            }
        });
    };
    // Öffnet den Privatchat als separates Popup-Fenster (PrivateWindow)
    this.openPrivateChatPopup = function(otherUserId, otherUserName, dialogKey) {
        var self = this;
        if (!self._privatePopups) self._privatePopups = {};
        // Prüfen ob schon ein Popup für diesen Partner offen ist
        var existing = self._privatePopups[otherUserId];
        if (existing && !existing.closed) {
            existing.focus();
            return;
        }
        // Popup-URL bauen
        var popupUrl = './?PrivateWindow' +
            '&partnerId=' + encodeURIComponent(otherUserId) +
            '&partnerName=' + encodeURIComponent(otherUserName);
        // Fenster öffnen
        var popup = window.open(
            popupUrl,
            'PrivatPopup_' + otherUserId,
            'width=480,height=640,resizable=yes,scrollbars=yes,left=200,top=100'
        );
        if (!popup) {
            alert('Popup wurde blockiert. Bitte Popup-Blocker für diese Seite erlauben.');
            return;
        }
        // Referenz merken
        self._privatePopups[otherUserId] = popup;
        // Beim Schließen aufräumen
        var closeCheck = setInterval(function() {
            if (popup.closed) {
                clearInterval(closeCheck);
                delete self._privatePopups[otherUserId];
            }
        }, 1000);
    };
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Ist dieser User in der aktuellen OnlineList? -------------------------------------------------------
    this.userOnlineNow = function(user_id) {
        for (var i = 0; i < self.jsonObjUserGlobal.userOnline.length; i++)
            if (self.jsonObjUserGlobal.userOnline[i].user_id == user_id && self.jsonObjUserGlobal.userOnline[i].user_simg != "status_invisible") return true;
        return false;
    }
    // (Start) Ist dieser User in der aktuellen OnlineList? -------------------------------------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Anfrage an den Reloader mit Datenuebergabe vom System -----------------------------------------------
    this.sendSysMessages = function(room, inhalt, privat, roomChange) {
        if (!privat) privat = 0;
        if (!roomChange) roomChange = 0;
        fetch("./?ReloaderMessages", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                },
                body: "room=" + encodeURIComponent(room) +
                    "&sysmess=1" +
                    "&privat=" + encodeURIComponent(privat) +
                    "&roomchange=" + encodeURIComponent(roomChange) +
                    "&message=" + encodeURIComponent(inhalt)
            })
            .then(res => res.text())
            .then(text => {
                receiveResultJSON({
                    responseText: text
                });
            })
            .catch(err => console.error("sendSysMessages Fehler:", err));
    };
    // (Stop) Anfrage an den Reloader mit Datenuebergabe vom System ------------------------------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) UseronlineUpdater - uebertragung der Chatrooms und Onlineuser im Interval ---------------------------
    this.userOnline = function() {
        const interval = this.reload_interval * 2;
        let active = false;
        // 🔥 NEU: Prüfen ob wir bereits eine Userliste haben
        let hasUserList = false;
        let forceLoadSent = false;
        const reload = () => {
            if (active) return;
            active = true;
            // Prüfen ob Userliste existiert (nach F5 wäre sie leer)
            if (!forceLoadSent && (!self.jsonObjUserGlobal ||
                    !self.jsonObjUserGlobal.userOnline ||
                    self.jsonObjUserGlobal.userOnline.length === 0)) {
                hasUserList = false;
            }
            let body = "reloadsequenz=" + interval;
            // 🔥 NEU: Wenn keine Userliste vorhanden (nach F5), force_load=1
            if (!hasUserList && !forceLoadSent) {
                body += "&force_load=1";
                forceLoadSent = true;
                hasUserList = true;
            }
            fetch("./?ReloaderUserOnline", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: body
                })
                .then(res => res.text())
                .then(html => {
                    updateUserOnlineAnzeige({
                        responseText: html
                    });
                })
                .catch(err => console.error("UserOnline Fehler:", err))
                .finally(() => {
                    active = false;
                });
        };
        // 🔥 ENTFERNT: reload();   // KEIN sofortiger Aufruf mehr!
        reload();
        setInterval(reload, interval);
        return false;
    };
    // (Stop) UseronlineUpdater - uebertragung der Chatrooms und Onlineuser im Interval ----------------------------
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // (Start) Historywindow - Mit korrekter Raum-Erhaltung bei Seitenwechsel
    this.historyWindow = function(seite, raumId) {
        var self = this;
        // Prüfen ob schon ein History-Fenster existiert
        var existingDialog = document.getElementById('standalone-history-dialog');
        if (existingDialog) {
            existingDialog.remove();
        }
        // Eigenes Floating DIV erstellen
        var dialogDiv = document.createElement('div');
        dialogDiv.id = 'standalone-history-dialog';
        dialogDiv.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 85vw;
        max-width: 1200px;
        min-width: 600px;
        height: 80vh;
        background: #2a2a2a;
        border-radius: 8px;
        z-index: 10000;
        display: flex;
        flex-direction: column;
        box-shadow: 0 5px 25px rgba(0,0,0,0.5);
        font-family: inherit;
    `;
        // Header - mit korrektem X (kein getElementById nötig)
        var header = document.createElement('div');
        header.style.cssText = `
        background: #3a3a3a;
        padding: 12px 16px;
        border-bottom: 1px solid #4a4a4a;
        border-radius: 8px 8px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: move;
        user-select: none;
    `;
        var titleSpan = document.createElement('span');
        titleSpan.style.cssText = 'color: #e0e0e0; font-weight: 500;';
        titleSpan.textContent = "📜 " + (lang_historyWindow_1 || "Chat-Verlauf");
        var closeBtn = document.createElement('button');
        closeBtn.style.cssText = 'background: #313244; border: none; border-radius: 8px; color: #9399b2; font-size: 14px; cursor: pointer; padding: 4px 10px; transition: all 0.2s ease;';
        closeBtn.textContent = '✕';
        closeBtn.onmouseover = function() {
            this.style.color = '#f38ba8';
            this.style.background = '#45475a';
        };
        closeBtn.onmouseout = function() {
            this.style.color = '#9399b2';
            this.style.background = '#313244';
        };
        closeBtn.onclick = function() {
            dialogDiv.remove();
            document.removeEventListener('keydown', escHandler);
        };
        header.appendChild(titleSpan);
        header.appendChild(closeBtn);
        // Content Bereich
        var contentDiv = document.createElement('div');
        contentDiv.id = 'standalone-history-content';
        contentDiv.style.cssText = `
        flex: 1;
        overflow: auto;
        padding: 16px;
        background: #1e1e1e;
        color: #e0e0e0;
    `;
        contentDiv.innerHTML = '<div style="text-align:center; padding:40px;">⏳ Lade Verlauf...</div>';
        dialogDiv.appendChild(header);
        dialogDiv.appendChild(contentDiv);
        document.body.appendChild(dialogDiv);
        // ESC-Taste
        var escHandler = function(e) {
            if (e.key === 'Escape') {
                dialogDiv.remove();
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
        // Drag & Drop
        var isDragging = false;
        var dragOffsetX = 0,
            dragOffsetY = 0;

        function onPointerMove(e) {
            if (!isDragging) return;
            var newLeft = e.clientX - dragOffsetX;
            var newTop = e.clientY - dragOffsetY;
            newLeft = Math.max(
                0,
                Math.min(newLeft, window.innerWidth - dialogDiv.offsetWidth)
            );
            newTop = Math.max(
                0,
                Math.min(newTop, window.innerHeight - dialogDiv.offsetHeight)
            );
            dialogDiv.style.left = newLeft + 'px';
            dialogDiv.style.top = newTop + 'px';
        }

        function stopDragging() {
            if (!isDragging) return;
            isDragging = false;
            dialogDiv.style.cursor = '';
            document.body.style.userSelect = '';
        }
        header.addEventListener('pointerdown', function(e) {
            if (e.target === closeBtn) return;
            isDragging = true;
            var rect = dialogDiv.getBoundingClientRect();
            dragOffsetX = e.clientX - rect.left;
            dragOffsetY = e.clientY - rect.top;
            dialogDiv.style.cursor = 'grabbing';
            dialogDiv.style.left = rect.left + 'px';
            dialogDiv.style.top = rect.top + 'px';
            dialogDiv.style.transform = 'none';
            document.body.style.userSelect = 'none';
            if (header.setPointerCapture) {
                header.setPointerCapture(e.pointerId);
            }
            e.preventDefault();
        });
        header.addEventListener('pointermove', onPointerMove);
        header.addEventListener('pointerup', stopDragging);
        header.addEventListener('pointercancel', stopDragging);
        window.addEventListener('blur', stopDragging);
        // Zentrale Funktion zum Binden der Events (wie im Original)
        function bindEvents(container, currentRoomId) {
            // Seitenauswahl (Dropdown) - GENAU WIE IM ORIGINAL
            var siteSelecter = container.querySelector('#site_selecter');
            if (siteSelecter) {
                siteSelecter.onchange = function() {
                    var selectedPage = this.value;
                    if (selectedPage) {
                        dialogDiv.remove();
                        self.historyWindow(selectedPage, currentRoomId);
                    }
                };
            }
            // Navigations-Links (historysite_xxx)
            var historyNav = container.querySelector('#history_seiten');
            if (historyNav) {
                historyNav.onclick = function(event) {
                    var el = event.target;
                    if (!el || !el.id) return;
                    if (el.id.slice(0, 12) == "historysite_") {
                        event.preventDefault();
                        var pageNum = el.id.slice(12);
                        dialogDiv.remove();
                        self.historyWindow(pageNum, currentRoomId);
                    }
                    if (el.id == "export_excel") {
                        event.preventDefault();
                        var room = container.querySelector('#raum_in_history');
                        if (room) {
                            window.open('./?HistoryExport&format=xls&roomid=' + room.value);
                        }
                    }
                    if (el.id == "export_csv") {
                        event.preventDefault();
                        var room = container.querySelector('#raum_in_history');
                        if (room) {
                            window.open('./?HistoryExport&format=csv&roomid=' + room.value);
                        }
                    }
                    if (el.id == "export_xml") {
                        event.preventDefault();
                        var room = container.querySelector('#raum_in_history');
                        if (room) {
                            window.open('./?HistoryExport&format=xml&roomid=' + room.value);
                        }
                    }
                };
            }
            // Raum-Auswahl
            var raumSelect = container.querySelector('#raum_in_history');
            if (raumSelect) {
                raumSelect.onchange = function(event) {
                    event.preventDefault();
                    var selectedRoom = this.value;
                    if (!selectedRoom) return;
                    fetch("./?History", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded",
                                "X-Requested-With": "XMLHttpRequest"
                            },
                            body: "site=1&roomid=" + encodeURIComponent(selectedRoom)
                        })
                        .then(function(res) {
                            return res.text();
                        })
                        .then(function(html) {
                            contentDiv.innerHTML = html;
                            var newRaumSelect = contentDiv.querySelector('#raum_in_history');
                            if (newRaumSelect) {
                                newRaumSelect.value = selectedRoom;
                            }
                            bindEvents(contentDiv, selectedRoom);
                        })
                        .catch(function(err) {
                            contentDiv.innerHTML = '<div style="color:#d9534f; text-align:center; padding:40px;">❌ Fehler beim Laden des Raums</div>';
                        });
                };
            }
            // Privatnachrichten-Links
            var privateLinks = container.querySelectorAll('a[href*="privat"], a[onclick*="privat"]');
            for (var i = 0; i < privateLinks.length; i++) {
                var link = privateLinks[i];
                link.onclick = function(event) {
                    event.preventDefault();
                    var href = this.getAttribute('href');
                    if (href) {
                        var userId = href.match(/privat[=:_](\d+)/i);
                        if (userId && userId[1]) {
                            if (typeof changeUserEvent === 'function') {
                                changeUserEvent('privat_' + userId[1]);
                            } else if (typeof self.changeUserEvent === 'function') {
                                self.changeUserEvent('privat_' + userId[1]);
                            }
                        }
                    }
                };
            }
        }
        // Inhalt laden
        function loadHistory() {
            var currentRoomId = raumId || '';
            if (!currentRoomId) {
                var raumInput = contentDiv.querySelector('#raum_in_history');
                if (raumInput && raumInput.value) {
                    currentRoomId = raumInput.value;
                }
            }
            fetch("./?History", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: "site=" + encodeURIComponent(seite) + "&roomid=" + encodeURIComponent(currentRoomId)
                })
                .then(function(res) {
                    return res.text();
                })
                .then(function(html) {
                    contentDiv.innerHTML = html;
                    var raumSelect = contentDiv.querySelector('#raum_in_history');
                    if (raumSelect && currentRoomId) {
                        raumSelect.value = currentRoomId;
                    }
                    bindEvents(contentDiv, currentRoomId);
                })
                .catch(function(err) {
                    contentDiv.innerHTML = '<div style="color:#d9534f; text-align:center; padding:40px;">❌ Fehler beim Laden des Verlaufs</div>';
                });
        }
        loadHistory();
    };
    // (Stop) Historywindow
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //#####################################################################################
    // UserOnline Anzeige
    var updateUserOnlineAnzeige = function(ajaxResultJSON) {
        var aktuelle_room_id;
        // Hier wird der Array des Updaters ausgewertet
        var jsonObj;
        try {
            var text = ajaxResultJSON.responseText;
            if (!text || text.trim() === "") {
                return;
            }
            jsonObj = self.jsonObjUserGlobal = JSON.parse(text);
        } catch (e) {
            return;
        }
        if (jsonObj == 0) {
            //setTimeout( updateUserOnlineAnzeigeAfterRoomChange ,1000);
        } else {
            var anzahl_der_user_im_chat = 0;
            // aktuelle Rechte aus der DB Erhalten und als Globaler Wert festlegen
            for (var i = 0; i < jsonObj.userOnline.length; i++) {
                if (jsonObj.userOnline[i].user_id == self.user_id) self.userPrivilegienGlobal = jsonObj.userOnline[i].user_priv;
                if (jsonObj.userOnline[i].user_simg != 'status_invisible') anzahl_der_user_im_chat++;
            }
            // Useranzeige
            var inner_html = "<b>" + lang_updateUserOnlineAnzeige_1 + "</b><br />";
            inner_html += lang_updateUserOnlineAnzeige_2 + " " + anzahl_der_user_im_chat + "<br/>";
            var last_room_id = null;
            for (var i = 0; i < jsonObj.userOnline.length; i++) {
                if (aktuelle_room_id != jsonObj.userOnline[i].room_id) {
                    aktuelle_room_id = jsonObj.userOnline[i].room_id;
                    var anz_im_room = 0;
                    for (var ii = 0; ii < jsonObj.userOnline.length; ii++) {
                        if (aktuelle_room_id == jsonObj.userOnline[ii].room_id && jsonObj.userOnline[ii].user_simg != 'status_invisible') anz_im_room++;
                    }
                    var show_anz_pro_room = (anz_im_room > 0) ? " (" + anz_im_room + ")" : "";
                    var allowed = jsonObj.userOnline[i].room_allowed;
                    if (allowed == 1) inner_html += "<div class=\"rooms\" id=\"room_" + aktuelle_room_id + "\">" + jsonObj.userOnline[i].room + show_anz_pro_room + "</div>";
                    else {
                        if (allowed == 2) inner_html += "<div class=\"rooms_not_allowed\" id=\"pwroom_" + aktuelle_room_id + "\">" + jsonObj.userOnline[i].room + show_anz_pro_room + "<img id=\"pwroomimg_" + aktuelle_room_id + "\" src=\"img/keylayer.png\" width=\"11\" height=\"11\" style=\"margin-left:5px;\" /></div>";
                        else inner_html += "<div class=\"rooms_not_allowed\" id=\"notallowedroom_" + aktuelle_room_id + "\">" + jsonObj.userOnline[i].room + show_anz_pro_room + "<img id=\"notallowedroomimg_" + aktuelle_room_id + "\" src=\"img/locklayer.png\" width=\"11\" height=\"10\" style=\"margin-left:5px;\" /></div>";
                    }
                    // C: ➜ ChatBot einfügen
                    if (self.set_chatbot == 1) {
                        inner_html += `
<div id="bot_user" style="cursor:pointer;">
    <div style="float:left;">
	
	<img class="avatar_u_list" src="avatar/bot_avatar.png" width="16" height="16" alt="Chat Bot" title="Chat Bot">
	
        <img src="img/user_comment_m.png" width="16" height="16" title="Fun" alt="Fun"/>
        <b>ChatBot</b>
    </div>
    <div style="float:right; margin-right: 2px;">
        <img src="img/status_invisible.png" style="text-decoration:none;border:0px;" alt="ChatBot!" title="ChatBot!"/>
    </div>
    <div style="clear:both"></div>
</div>`;
                    }
                }
                // Wenn admin
                var admin_user = (self.userPrivilegienGlobal == "admin" || self.userPrivilegienGlobal == "mod" || self.userPrivilegienGlobal == "grafik" || self.userPrivilegienGlobal == "chatwache" || self.userPrivilegienGlobal == "co_admin") ? " <img src=\"img/wand.png\" id=\"adminu_" + jsonObj.userOnline[i].user_id + "\" /> " : "";
                if ((self.userPrivilegienGlobal == "admin" && self.user_id == jsonObj.userOnline[i].user_id) || (self.userPrivilegienGlobal == "mod" && self.user_id == jsonObj.userOnline[i].user_id) || (self.userPrivilegienGlobal == "grafik" && self.user_id == jsonObj.userOnline[i].user_id) || (self.userPrivilegienGlobal == "chatwache" && self.user_id == jsonObj.userOnline[i].user_id) || (self.userPrivilegienGlobal == "co_admin" && self.user_id == jsonObj.userOnline[i].user_id)) admin_user = " <img src=\"img/space.gif\" weight=\"10\" height=\"16\" /> ";
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                var usr_priv = "";
                if (self.set_ol_an_privi == 1) {
                    if (jsonObj.userOnline[i].user_priv == "admin") usr_priv = " <span class=\"kreis-buchstabe\"  title=\"Admin\" aria-label=\"Admin\" style=\"background-color: " + self.co_admin + ";\">A</span>";
                    if (jsonObj.userOnline[i].user_priv == "mod") usr_priv = " <span class=\"kreis-buchstabe\"  title=\"Mod\" aria-label=\"Mod\" style=\"background-color: " + self.co_mod + ";\">M</span>";
                    if (jsonObj.userOnline[i].user_priv == "gast") usr_priv = " <span class=\"kreis-buchstabe\"  title=\"Gast\" aria-label=\"Gast\" style=\"background-color: " + self.co_gast + ";\">G</span>";
                    if (jsonObj.userOnline[i].user_priv == "user") usr_priv = " <span class=\"kreis-buchstabe\"  title=\"Hörer\" aria-label=\"HÃ¶rer\" style=\"background-color: " + self.co_user + ";\">H</span>";
                    if (jsonObj.userOnline[i].user_priv == "grafik") usr_priv = " <span class=\"kreis-buchstabe\"  title=\"Grafiker\" aria-label=\"Grafiker\" style=\"background-color: " + self.co_admin + ";\">GR</span>";
                    if (jsonObj.userOnline[i].user_priv == "chatwache") usr_priv = " <span class=\"kreis-buchstabe\"  title=\"Chatwache\" aria-label=\"Chatwache\" style=\"background-color: " + self.co_admin + ";\">C</span>";
                    if (jsonObj.userOnline[i].user_priv == "co_admin") usr_priv = " <span class=\"kreis-buchstabe\"  title=\"Co-Admin\" aria-label=\"CoAdmin\" style=\"background-color: " + self.co_admin + ";\">CA</span>";
                }
                // -----------------
                // Einstellen der Benutzerfarben in der Onlineliste
                var user_color = "";
                if (jsonObj.userOnline[i].user_priv == "admin") user_color = "color: " + self.co_admin + ";"; //#F00
                if (jsonObj.userOnline[i].user_priv == "mod") user_color = "color: " + self.co_mod + ";"; // #0000ff
                if (jsonObj.userOnline[i].user_priv == "user") user_color = "color: " + self.co_user + ";"; //#00ff00
                if (jsonObj.userOnline[i].user_priv == "gast") user_color = "color: " + self.co_gast + ";"; // #ffffff
                if (jsonObj.userOnline[i].user_priv == "grafik") user_color = "color: " + self.co_admin + ";"; //#F00
                if (jsonObj.userOnline[i].user_priv == "chatwache") user_color = "color: " + self.co_admin + ";"; //#F00
                if (jsonObj.userOnline[i].user_priv == "co_admin") user_color = "color: " + self.co_admin + ";"; //#F00
                //status ----
                if (jsonObj.userOnline[i].user_simg && jsonObj.userOnline[i].user_simg !== '') var user_status_anz = " <img src=\"img/" + jsonObj.userOnline[i].user_simg + ".png\" alt=\"" + jsonObj.userOnline[i].user_stext + "\" title=\"" + jsonObj.userOnline[i].user_stext + "\">";
                else var user_status_anz = "";
                //hide User
				//hide User – aber den eigenen Eintrag immer anzeigen
				var isSelf = (String(self.user_id) === String(jsonObj.userOnline[i].user_id));
				if (!isSelf && jsonObj.userOnline[i].user_simg && jsonObj.userOnline[i].user_simg == 'status_invisible') 
					var user_style = "display:none;";
				else 
					var user_style = "";
                // strike user
                if (jsonObj.userOnline[i].user.slice(0, 8) == '<strike>') {
                    jsonObj.userOnline[i].user = jsonObj.userOnline[i].user.slice(8, jsonObj.userOnline[i].user.length);
                    var user_style2 = "text-decoration: line-through;";
                } else var user_style2 = "";
                if (self.user_id == jsonObj.userOnline[i].user_id) {
                    if (self.u_bild == 1) {
                        var etchat_avatar = "<img class=\"avatar_u_list\" src=\"avatar/" + jsonObj.userOnline[i].etchat_avatar + "\" width=\"16\" height=\"16\" alt=\"Avatar1\" title=\"Avatar1\">";
                    } else {
                        var etchat_avatar = "";
                    }
                    if (jsonObj.userOnline[i].user_sex == "m") var gender_icon = "user_comment_m_self.png";
                    if (jsonObj.userOnline[i].user_sex == "f") var gender_icon = "user_comment_w_self.png";
                    if (jsonObj.userOnline[i].user_sex == "n") var gender_icon = "user_comment_n_self.png";
                    if (jsonObj.userOnline[i].user_sex == "d") var gender_icon = "user_comment_d_self.png";
                    inner_html += "<div id=\"user_div_" + jsonObj.userOnline[i].user_id + "\" style=\"" + user_style + "\">\
<div style=\"float:left;\">\
" + etchat_avatar + "\
<img src=\"img/" + gender_icon + "\" width=\"16\" height=\"16\" /> \
<span id=\"user_" + jsonObj.userOnline[i].user_id + "\" style=\"cursor:pointer;" + user_color + "\" alt=\"Mein Profil\" title=\"Mein Profil\"><b>" + admin_user + jsonObj.userOnline[i].user + "</b></span>\
</div>\
<div style=\"float:right; margin-right: 2px;\">" + usr_priv + user_status_anz + "</div>\
<div style=\"clear:both\"></div>\
</div>";
                } else {
                    if (self.u_bild == 1) {
                        var etchat_avatar = "<img class=\"avatar_u_list\" src=\"avatar/" + jsonObj.userOnline[i].etchat_avatar + "\" width=\"16\" height=\"16\" alt=\"Avatar2\" title=\"Avatar2\">";
                    } else {
                        var etchat_avatar = "";
                    }
                    if (jsonObj.userOnline[i].user_sex == "m") var gender_icon = "user_comment_m.png";
                    if (jsonObj.userOnline[i].user_sex == "f") var gender_icon = "user_comment_w.png";
                    if (jsonObj.userOnline[i].user_sex == "n") var gender_icon = "user_comment_n.png";
                    if (jsonObj.userOnline[i].user_sex == "d") var gender_icon = "user_comment_d.png";
                    inner_html += "<div id=\"user_div_" + jsonObj.userOnline[i].user_id + "\" style=\"" + user_style + "\">\
<div style=\"float:left;\">\
" + etchat_avatar + "\
<img src=\"img/" + gender_icon + "\" id=\"user_" + jsonObj.userOnline[i].user_id + "\" style=\"cursor:pointer\" title=\"" + lang_updateUserOnlineAnzeige_3 + "\" alt=\"" + lang_updateUserOnlineAnzeige_3 + "\" />\
<span id=\"infoblock_" + jsonObj.userOnline[i].user_id + "\" style=\"" + user_style2 + "cursor:pointer;" + user_color + "\"alt=\"Benutzer Profil\" title=\"Benutzer Profil\">" + admin_user + jsonObj.userOnline[i].user + "</span>\
</div>\
<div style=\"float:right; margin-right: 2px;\">" + usr_priv + user_status_anz + "</div>\
<div style=\"clear:both\"></div>\
</div>";
                }
                if (self.user_id == jsonObj.userOnline[i].user_id) var aktuell_room = "room_" + aktuelle_room_id;
            }
            try {
                for (var i = 0; i < jsonObj.all_empty_rooms.length; i++)
                    if (jsonObj.all_empty_rooms[i].room_allowed == 1) inner_html += "<div class=\"rooms\" id=\"room_" + jsonObj.all_empty_rooms[i].room_id + "\">" + jsonObj.all_empty_rooms[i].room + "</div>";
                    else {
                        if (jsonObj.all_empty_rooms[i].room_allowed == 2) inner_html += "<div class=\"rooms_not_allowed\" id=\"pwroom_" + jsonObj.all_empty_rooms[i].room_id + "\">" + jsonObj.all_empty_rooms[i].room + "<img id=\"pwroomimg_" + jsonObj.all_empty_rooms[i].room_id + "\" src=\"img/keylayer.png\" width=\"11\" height=\"11\" style=\"margin-left:5px;\" /></div>";
                        else inner_html += "<div class=\"rooms_not_allowed\" id=\"notallowedroom_" + jsonObj.all_empty_rooms[i].room_id + "\">" + jsonObj.all_empty_rooms[i].room + "<img id=\"notallowedroomimg_" + jsonObj.all_empty_rooms[i].room_id + "\" src=\"img/locklayer.png\" width=\"11\" height=\"10\" style=\"margin-left:5px;\" /></div>";
                    }
            } catch (e) {
                /*nix*/
            }
            $X("onlineausgabe").innerHTML = inner_html;
            if (!window.botClickHandlerAdded) {
                document.addEventListener("click", function(e) {
                    if (e.target.closest("#bot_user")) {
                        let msg = $X("message").value;
                        if (msg.length > 0 && !msg.endsWith(" ")) msg += " ";
                        $X("message").value = msg + "ChatBot ";
                        $X("message").focus();
                    }
                });
                window.botClickHandlerAdded = true;
            }
            try {
                document.getElementById("user_" + self.user_id).onclick = function() {
                    $X("link_profil").onclick();
                };
            } catch (e) {
                // Eigener Profil-Link nicht gefunden - ignorieren
            }
            // 🔥 FIX: Prüfen ob aktuell_room existiert BEVOR wir darauf zugreifen
            if (typeof aktuell_room !== 'undefined' && aktuell_room && $X(aktuell_room)) {
                $X(aktuell_room).style.fontWeight = "bold";
            }
        }
    }
    //##############################################################################################################
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // NEU: Kleines Auswahlmenü für Benutzernamen im Chat-Fenster
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    var showUserMiniMenu = function(user_id, user_name, event) {
        // Altes Menü schließen falls vorhanden
        var oldMenu = document.getElementById('user-mini-menu');
        if (oldMenu) oldMenu.remove();
        // Menü-Container erstellen
        var menu = document.createElement('div');
        menu.id = 'user-mini-menu';
        menu.style.cssText = 'position:fixed; background:#2a2a2a; border:1px solid #555; border-radius:4px; padding:5px 0; z-index:9999; min-width:220px; box-shadow:2px 2px 10px rgba(0,0,0,0.5);';
        menu.style.left = event.clientX + 'px';
        menu.style.top = event.clientY + 'px';
        // Menü-Einträge definieren
        var items = [{
            text: '💬 Benutzer ansprechen',
            action: function() {
                var inputField = document.getElementById('message');
                if (inputField) {
                    inputField.value += '@ ' + user_name.unescapeHTML() + ' ';
                    inputField.focus();
                }
            }
        }];
        // Nur hinzufügen wenn Privatnachrichten erlaubt sind
        if (self.allowed_privates_in_chat_win) {
            items.push({
                text: '📩 Privatnachricht im Chatfenster',
                action: function() {
                    changeUserEvent('privat_' + user_id);
                }
            });
        }
        if (self.allowed_privates_in_separate_win) {
            items.push({
                text: '🪟 Privatchat im separaten Fenster',
                action: function() {
                    changeUserEvent('privatwin_' + user_id);
                }
            });
        }
        // Menü-Einträge ins DOM einfügen
        items.forEach(function(item) {
            var menuItem = document.createElement('div');
            menuItem.textContent = item.text;
            menuItem.style.cssText = 'padding:6px 12px; cursor:pointer; color:#fff; font-size:13px; white-space:nowrap;';
            menuItem.onmouseover = function() {
                this.style.backgroundColor = '#444';
            };
            menuItem.onmouseout = function() {
                this.style.backgroundColor = 'transparent';
            };
            menuItem.onclick = function() {
                item.action();
                menu.remove();
            };
            menu.appendChild(menuItem);
        });
        document.body.appendChild(menu);
        // Klick außerhalb schließt das Menü
        setTimeout(function() {
            document.addEventListener('click', function closeMenu(e) {
                if (!menu.contains(e.target)) {
                    // Sicher entfernen - nur wenn noch im DOM vorhanden
                    if (menu && menu.parentNode) {
                        menu.parentNode.removeChild(menu);
                    }
                    document.removeEventListener('click', closeMenu);
                }
            });
        }, 10);
        event.stopPropagation();
        event.preventDefault();
    };
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // ENDE NEUE FUNKTION
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++				
    //####Privat im Chat user ansprechen#######################################		
    var changeUserEvent = function(ereignis) {
        // Stelle sicher, dass win_private existiert
        if (!self.win_private) {
            self.win_private = [];
        }
        if (ereignis.slice(0, 7) == "privat_") {
            $X("privat").value = ereignis.slice(7, ereignis.length);
            // Hier ird anhand der User_ID der entsprechende Username aus dem JSON Resultarray herausgefischt
            for (var i = 0; i < self.jsonObjUserGlobal.userOnline.length; i++)
                if (self.jsonObjUserGlobal.userOnline[i].user_id == $X("privat").value) self.privat_an = self.jsonObjUserGlobal.userOnline[i].user;
            // Privat window
            var user_name_p = (self.privat_an.length > 20) ? self.privat_an.slice(0, 20) + "..." : self.privat_an;
            $X("privat_anzeige").innerHTML = lang_changeUserEvent_privat_1 + " <b>" + user_name_p + "</b><span id=\"close_privat\">" + lang_changeUserEvent_privat_2 + "</span>";
            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // new Effect.Highlight durch CSS-Animation ersetzen
            var msgField = $X("message");
            if (msgField) {
                msgField.classList.add('highlight-pulse');
                setTimeout(function() {
                    msgField.classList.remove('highlight-pulse');
                }, 600);
            }
            $X("message").focus();
            //alert(self.jsonObjUserGlobal.userOnline[0].room);
        }
        //#####Start Privat im separaten Fenster User ansprechen - NEU mit ChatDialog
        if (ereignis.slice(0, 10) == "privatwin_") {
            var privat2id = ereignis.slice(10, ereignis.length);
            // Hier wird anhand der User_ID der entsprechende Username aus dem JSON Resultarray herausgefischt
            var privat2name = null;
            for (var i = 0; i < self.jsonObjUserGlobal.userOnline.length; i++) {
                if (self.jsonObjUserGlobal.userOnline[i].user_id == privat2id) {
                    privat2name = self.jsonObjUserGlobal.userOnline[i].user;
                    break;
                }
            }
            if (privat2name) {
                // Neue Funktion zum Öffnen des Dialogs aufrufen
                self.openPrivateChatDialog(privat2id, privat2name);
            }
        }
        //#####ENDE Privat im separaten Fenster User ansprechen
        //##############################################################################################################
        if (ereignis.slice(0, 5) == "room_") {
            // 🔥 NEU: Prüfen ob bereits ein Raumwechsel läuft
            if (roomChangeInProgress) {
                return false; // Zweiten Aufruf ignorieren
            }
            roomChangeInProgress = true; // Flag setzen
            if ($X("room").value == ereignis.slice(5, ereignis.length)) {
                roomChangeInProgress = false;
                return false;
            }
            $X('chatinhalt').innerHTML = '';
            $X("room").value = ereignis.slice(5, ereignis.length);
            // ... restlicher Code ...
            self.sendSysMessages($X("room").value, lang_changeUserEvent_room_1, 0, true);
            setTimeout(updateUserOnlineAnzeigeAfterRoomChange, 700);
            // 🔥 NEU: Flag nach 1 Sekunde zurücksetzen
            setTimeout(function() {
                roomChangeInProgress = false;
            }, 1000);
        }
        //##############################################################################################################
        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // NEU: Klick auf Namen IM CHAT → kleines Menü
        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if (ereignis.slice(0, 10) == "inflblock_") {
            var id = ereignis.slice(10);
            var userData = self.jsonObjUserGlobal.userOnline.find(function(u) {
                return u.user_id == id;
            });
            if (userData) {
                showUserMiniMenu(id, userData.user, event || window.event);
            }
            return;
        }
        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Start User Profil - NEU mit ChatDialog
        if (ereignis.slice(0, 10) == "infoblock_") {
            const id = ereignis.slice(10);
            const userData = self.jsonObjUserGlobal.userOnline.find(u => u.user_id == id);
            if (!userData) return false;
            const {
                user: user_name,
                user_priv,
                user_sex = 'nicht angegeben',
                reg_timestamp: user_reg_timestamp = null,
                etchat_avatar,
                user_id: profile_user_id
            } = userData;
            if (user_name == undefined) return false;
            // Eindeutige Fetch-Token & Include-ID
            const includeId = "include-bereich-" + id;
            const uploadContainerId = "profil-upload-bereich-" + id;
            const currentFetchToken = Date.now();
            self.lastProfileFetchToken = currentFetchToken;
            // Prüfen ob dieses Fenster bereits offen ist (DOM-basiert - funktioniert immer)
            const existingContent = document.getElementById('include-bereich-' + id);
            if (existingContent) {
                const existingDialog = existingContent.closest('.modern-dialog');
                if (existingDialog && existingDialog.isConnected) {
                    ChatDialog.closeDialog(existingDialog);
                    // Aufräumen
                    if (self.win_block && self.win_block[id]) {
                        self.win_block[id].isOpen = false;
                        self.win_block[id].dialog = null;
                    }
                    return;
                }
            }
            const disabled_block = (user_priv == 'admin' || user_priv == 'mod' || user_priv == 'grafik' || user_priv == 'chatwache' || user_priv == 'co_admin') ? 'disabled' : '';
            const priv_colors = {
                'admin': self.co_admin,
                'mod': self.co_mod,
                'user': self.co_user,
                'gast': self.co_gast,
                'grafik': self.co_admin,
                'chatwache': self.co_admin,
                'co_admin': self.co_admin
            };
            const priv_translation = {
                'admin': 'Administrator',
                'mod': 'Moderator',
                'user': 'Registrierter Benutzer',
                'gast': 'Gast',
                'grafik': 'Grafiker',
                'chatwache': 'Chatwache',
                'co_admin': 'Co-Admin'
            };
            const translated_priv = priv_translation[user_priv] || user_priv;
            const priv_color = priv_colors[user_priv] || '#CCCCCC';
            const sex_translation = {
                'm': 'männlich',
                'f': 'weiblich',
                'n': 'unbekannt',
                'd': 'divers'
            };
            const translated_sex = sex_translation[user_sex] || user_sex;
            const regDateHtml = (user_priv !== 'gast' && user_reg_timestamp !== null) ? `<div style="padding-bottom:5px;"><strong>Dabei seit:</strong> ${formatDate(user_reg_timestamp * 1000)}</div>` : '';

            function formatDate(timestamp) {
                const date = new Date(timestamp);
                return date.toLocaleDateString('de-DE');
            }
            const chat_privat_menue = self.allowed_privates_in_chat_win ? `<div style="padding-bottom:2px;text-align:center;">📩 <a href="#" id="info_privatm_${id}">${lang_changeUserEvent_infoblock_3}</a></div>` : '';
            const separate_win_privat_menue = self.allowed_privates_in_separate_win ? `<div style="padding-bottom:2px;text-align:center;">🪟 <a href="#" id="info_privatf_${id}">${lang_changeUserEvent_infoblock_4}</a></div>` : '';
            const block_option4privat = (!self.allowed_privates_in_separate_win && !self.allowed_privates_in_chat_win) ? '' : `<input type="Checkbox" id="blokiere_user_priv_${id}" ${disabled_block}> ${lang_changeUserEvent_infoblock_7}`;
            // HTML Content zusammenbauen
            const htmlContent = `
        <div style="min-width:300px;">
            <center><div id="${includeId}" style="min-height:100px;">Lade Profil...</div></center>
            <div class="profile-container" style="margin-top:5px;">
                <div style="padding-bottom:2px;text-align:center;">
                    💬 <a href="#" id="info_set_name_${id}">${lang_changeUserEvent_infoblock_2}</a>
                </div>
                ${chat_privat_menue}
                ${separate_win_privat_menue}
                <br>
                <div style="padding-bottom:2px;text-align:center;">
                    🚫 <a href="#" id="info_blockform_${id}">${lang_changeUserEvent_infoblock_5}</a>
                </div>
                <div id="block_form_div_${id}" style="display:none;margin-top:2px;text-align:center;">
                    <form name="user_block_${id}" style="display:inline;">
                        <input type="Checkbox" id="blokiere_user_all_${id}" ${disabled_block}> ${lang_changeUserEvent_infoblock_6}
                        ${block_option4privat}
                    </form>
                </div>
            </div>
            <div id="${uploadContainerId}" style="margin-top:10px;text-align:center;"></div>
        </div>
    `;
            // Dialog öffnen
            var profileDialog = ChatDialog.open({
                title: lang_changeUserEvent_infoblock_1 + ' ' + (user_name.length > 20 ? user_name.slice(0, 20) + "..." : user_name),
                showHeader: true,
                modal: false,
                draggable: true,
                resizable: true,
                className: "profile-dialog",
                html: htmlContent,
                onOpen: function(dialog) {
                    if (!self.win_block) self.win_block = [];
                    self.win_block[id] = {
                        dialog: dialog,
                        isOpen: true,
                        userId: profile_user_id
                    };
                    if (!self.win_block_ids) self.win_block_ids = [];
                    if (!self.win_block_ids.includes(id)) self.win_block_ids.push(id);
                    const isMobile = window.matchMedia("(max-width: 768px)").matches;
                    if (isMobile) {
                        dialog.style.width = '95vw';
                        dialog.style.minWidth = '280px';
                    } else {
                        dialog.style.width = '650px';
                        dialog.style.minWidth = '350px';
                    }
                    dialog.style.maxWidth = '95vw';
                    // 🔥 Resize-Observer mit Speicherung
                    var resizeObserver = new ResizeObserver(function() {
                        var header = dialog.querySelector('.dialog-header');
                        var headerHeight = header ? header.offsetHeight : 50;
                        var dialogHeight = dialog.offsetHeight;
                        var contentDiv = dialog.querySelector('.dialog-content');
                        if (contentDiv && dialogHeight > 0) {
                            var newHeight = Math.max(200, dialogHeight - headerHeight - 4);
                            contentDiv.style.height = newHeight + 'px';
                        }
                    });
                    resizeObserver.observe(dialog);
                    dialog._resizeObserver = resizeObserver;
                    // Bind Events
                    $X("info_set_name_" + id).onclick = function() {
                        $X('block_form_div_' + id).style.display = 'none';
                        changeUserEvent('user_' + id);
                        ChatDialog.closeDialog(dialog);
                    };
                    if (self.allowed_privates_in_chat_win) {
                        $X("info_privatm_" + id).onclick = function() {
                            $X('block_form_div_' + id).style.display = 'none';
                            changeUserEvent('privat_' + id);
                            ChatDialog.closeDialog(dialog);
                        };
                    }
                    if (self.allowed_privates_in_separate_win) {
                        $X("info_privatf_" + id).onclick = function() {
                            $X('block_form_div_' + id).style.display = 'none';
                            changeUserEvent('privatwin_' + id);
                            ChatDialog.closeDialog(dialog);
                        };
                    }
                    $X("info_blockform_" + id).onclick = function() {
                        var el = $X('block_form_div_' + id);
                        if (el) {
                            el.style.display = (el.style.display === 'none') ? 'block' : 'none';
                        }
                    };
                    $X("blokiere_user_all_" + id).onclick = function() {
                        try {
                            $X("blokiere_user_priv_" + id).checked = false;
                        } catch (e) {}
                        fetch("./?BlockUser", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded"
                                },
                                body: "block_all=" + encodeURIComponent(id)
                            })
                            .then(() => {
                                $X('block_form_div_' + id).style.display = 'none';
                                ChatDialog.closeDialog(dialog);
                                updateUserOnlineAnzeigeAfterRoomChange();
                            })
                            .catch(err => console.error("BlockUser Fehler:", err));
                    };
                    if (self.allowed_privates_in_separate_win || self.allowed_privates_in_chat_win) {
                        $X("blokiere_user_priv_" + id).onclick = function() {
                            $X("blokiere_user_all_" + id).checked = false;
                            fetch("./?BlockUser", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/x-www-form-urlencoded"
                                    },
                                    body: "block_priv=" + encodeURIComponent(id)
                                })
                                .then(() => {
                                    $X('block_form_div_' + id).style.display = 'none';
                                    ChatDialog.closeDialog(dialog);
                                    updateUserOnlineAnzeigeAfterRoomChange();
                                })
                                .catch(err => console.error("BlockUser (priv) Fehler:", err));
                        };
                    }
                },
                onClose: function() {
                    // 🔥 ResizeObserver aufräumen
                    if (profileDialog && profileDialog._resizeObserver) {
                        profileDialog._resizeObserver.disconnect();
                        delete profileDialog._resizeObserver;
                    }
                    if (self.win_block && self.win_block[id]) {
                        self.win_block[id].isOpen = false;
                        self.win_block[id].dialog = null;
                    }
                    var index = self.win_block_ids.indexOf(id);
                    if (index !== -1) self.win_block_ids.splice(index, 1);
                }
            });
            // Fetch Profil
            fetch(`./?Profil&user_id=${profile_user_id}&nocache=${currentFetchToken}`)
                .then(response => {
                    if (!response.ok) throw new Error('Fehler beim Laden der Profil-Daten');
                    return response.text();
                })
                .then(html => {
                    if (self.lastProfileFetchToken === currentFetchToken) {
                        const target = document.getElementById(includeId);
                        if (target) target.innerHTML = html;
                    }
                })
                .catch(error => console.error("Include-Fehler:", error));
            // Fetch BildUpload-Bereich
            fetch(`./?ProfilBildUpload&user_id=${profile_user_id}&nocache=${currentFetchToken}`)
                .then(response => {
                    if (!response.ok) throw new Error('Fehler beim Laden des Bilduploads');
                    return response.text();
                })
                .then(uploadHtml => {
                    const uploadContainer = document.getElementById(uploadContainerId);
                    if (uploadContainer) uploadContainer.innerHTML = uploadHtml;
                })
                .catch(error => console.error("Upload-Fetch-Fehler:", error));
        }
        // Start Wenn der User zu adminnistrieren ist kleiner Zaubertab in Userliste.
        if (ereignis.slice(0, 7) == "adminu_") {
            // Hier wird anhand der User_ID der entsprechende Username aus dem JSON Resultarray herausgefischt
            for (var i = 0; i < self.jsonObjUserGlobal.userOnline.length; i++)
                if (self.jsonObjUserGlobal.userOnline[i].user_id == ereignis.slice(7, ereignis.length)) {
                    var user_ip = self.jsonObjUserGlobal.userOnline[i].user_ip;
                    var iparr = user_ip.split(" ");
                    var user_ip_o_provider = iparr[0];
                    var user_name = self.jsonObjUserGlobal.userOnline[i].user;
                    var user_priv = self.jsonObjUserGlobal.userOnline[i].user_priv;
                }
            var id = ereignis.slice(7, ereignis.length);
            // HTML für den Dialog vorbereiten
            var dialogHtml = '';
            if (user_priv != 'admin' && user_priv != 'mod' && user_priv != 'grafik' && user_priv != 'chatwache' && user_priv != 'co_admin') {
                dialogHtml = '<div style="text-align:center;">' +
                    '<b>' + user_name + '</b><br>' +
                    '<i>' + user_ip + '</i><br><br>' +
                    '<a href="https://whatismyipaddress.com/ip/' + user_ip_o_provider + '" target="_blank" style="color:#5cb85c;"><i>' + lang_changeUserEvent_adminu_5 + '</i></a><br><br>' +
                    lang_changeUserEvent_adminu_1 + '<br>' +
                    '<select id="blacklist_time" style="margin:10px 0; padding:5px;">' +
                    '<option value="0">' + lang_changeUserEvent_adminu_opt_1 + '</option>' +
                    '<option value="600">' + lang_changeUserEvent_adminu_opt_2 + '</option>' +
                    '<option value="1800">' + lang_changeUserEvent_adminu_opt_3 + '</option>' +
                    '<option value="3600">' + lang_changeUserEvent_adminu_opt_4 + '</option>' +
                    '<option value="10800">' + lang_changeUserEvent_adminu_opt_5 + '</option>' +
                    '<option value="86400">' + lang_changeUserEvent_adminu_opt_6 + '</option>' +
                    '<option value="604800">' + lang_changeUserEvent_adminu_opt_7 + '</option>' +
                    '<option value="94348800">' + lang_changeUserEvent_adminu_opt_8 + '</option>' +
                    '</select><br>' +
                    '<button id="sperre_user_' + id + '" style="padding:6px 20px; background:#d9534f; color:white; border:none; border-radius:4px; cursor:pointer;">' + lang_changeUserEvent_adminu_2 + '</button>' +
                    '</div>';
            } else {
                dialogHtml = '<div style="text-align:center;">' +
                    '<b>' + user_name + '</b> ' + lang_changeUserEvent_adminu_3 + ' ' + user_priv + ' ' + lang_changeUserEvent_adminu_4 +
                    '</div>';
            }
            // Dialog öffnen
            ChatDialog.open({
                title: lang_dialog_user_manage,
                showHeader: true,
                html: dialogHtml,
                onOpen: function(dialog) {
                    // Nur wenn es ein sperrbarer User ist
                    if (user_priv != 'admin' && user_priv != 'mod' && user_priv != 'grafik' && user_priv != 'chatwache' && user_priv != 'co_admin') {
                        var sperreBtn = dialog.querySelector('#sperre_user_' + id);
                        if (sperreBtn) {
                            sperreBtn.onclick = function() {
                                var timeSelect = dialog.querySelector('#blacklist_time');
                                var time = timeSelect ? timeSelect.value : 0;
                                fetch("./?Insert2Blacklist", {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/x-www-form-urlencoded"
                                        },
                                        body: new URLSearchParams({
                                            user_id: id,
                                            time: time
                                        })
                                    })
                                    .then(() => {
                                        ChatDialog.close();
                                    })
                                    .catch(err => console.error("Insert2Blacklist Fehler:", err));
                            };
                        }
                    }
                }
            });
        }
        // ENDE Wenn der User zu adminnistrieren ist.
        //##############################################################################################################
        if (ereignis.slice(0, 5) == "user_" || ereignis.slice(0, 5) == "usch_") {
            for (var i = 0; i < self.jsonObjUserGlobal.userOnline.length; i++)
                if (self.jsonObjUserGlobal.userOnline[i].user_id == ereignis.slice(5, ereignis.length)) var user_name = self.jsonObjUserGlobal.userOnline[i].user;
            $X("message").value += '@ ' + user_name.unescapeHTML();
            $X("message").focus();
        }
        //START Hier wird für gesicherte Räume die Benutzer nicht betreten dürfen eine Warnung ausgesprochen
        if (ereignis.slice(0, 15) == "notallowedroom_" || ereignis.slice(0, 18) == "notallowedroomimg_") {
            ChatDialog.open({
                showHeader: true, // Kein Header, wie beim alten Fenster
                title: lang_dialog_room_not_allowed,
                className: "simple-dialog",
                html: '<div>' + lang_changeUserEvent_notallowedroom_1 + '<br><br><button id="close_room_warning">' + lang_button_ok + '</button></div>',
                onOpen: function(dialog) {
                    var closeBtn = dialog.querySelector('#close_room_warning');
                    if (closeBtn) {
                        closeBtn.onclick = function() {
                            ChatDialog.close();
                        };
                    }
                }
            });
        }
        // ENDE Hier wird für gesicherte Räume die Benutzer nicht betreten dürfen eine Warnung ausgesprochen
        // START Hier wird das Passwortfenster für gesicherte Räume erstellt
        if (ereignis.slice(0, 7) == "pwroom_" || ereignis.slice(0, 10) == "pwroomimg_") {
            var room_id_now = (ereignis.slice(0, 7) == "pwroom_") ? ereignis.slice(7, ereignis.length) : ereignis.slice(10, ereignis.length);
            // Hier ird anhand der Room_ID der entsprechende Roomname aus dem JSON Resultarray herausgefischt
            for (var i = 0; i < self.jsonObjUserGlobal.userOnline.length; i++)
                if (self.jsonObjUserGlobal.userOnline[i].room_id == room_id_now) var roomName = self.jsonObjUserGlobal.userOnline[i].room;
            // try weil wenn es keine freien Raeume gibt, entsteht error
            try {
                for (var i = 0; i < self.jsonObjUserGlobal.all_empty_rooms.length; i++)
                    if (self.jsonObjUserGlobal.all_empty_rooms[i].room_id == room_id_now) var roomName = self.jsonObjUserGlobal.all_empty_rooms[i].room;
            } catch (e) {
                /* nix */
            }
            // Passwortfenster für gesicherte Räume
            ChatDialog.open({
                title: roomName,
                showHeader: true,
                className: "password-dialog",
                html: '<form id="layerpw_form" style="display:flex; flex-direction:column; gap:10px;">' +
                    '<div>' + lang_changeUserEvent_pwroom_1 + '</div>' +
                    '<div id="pwroom_error" style="color:red; font-size:12px;"></div>' +
                    '<input type="password" name="layerpw" id="layerpw" placeholder="' + lang_room_password_enter_placeholder + '">' +
                    '<button id="send_room_pw" type="submit">' + lang_button_ok + '</button>' +
                    '</form>',
                onOpen: function(dialog) {
                    // Fokus auf Passwortfeld
                    var pwField = dialog.querySelector('#layerpw');
                    if (pwField) pwField.focus();
                    // Form Submit Handler
                    var form = dialog.querySelector('#layerpw_form');
                    if (form) {
                        form.onsubmit = function(e) {
                            e.preventDefault();
                            var password = dialog.querySelector('#layerpw').value;
                            check_room_pw_with_dialog(dialog, password, room_id_now, roomName);
                            return false;
                        };
                    }
                    // OK Button Handler
                    var sendBtn = dialog.querySelector('#send_room_pw');
                    if (sendBtn) {
                        sendBtn.onclick = function() {
                            var password = dialog.querySelector('#layerpw').value;
                            check_room_pw_with_dialog(dialog, password, room_id_now, roomName);
                        };
                    }
                }
            });
        }
    }
    var check_room_pw_with_dialog = function(dialog, password, room_id_now, roomName) {
        // 🔥 NEU: Prüfen ob bereits ein Raumwechsel läuft
        if (roomChangeInProgress) {
            return;
        }
        roomChangeInProgress = true;
        fetch("./?CheckRoomPw", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: new URLSearchParams({
                    layerpw: password,
                    roomid: room_id_now
                })
            })
            .then(res => res.text())
            .then(text => {
                if (text == 1) {
                    ChatDialog.close();
                    $X('chatinhalt').innerHTML = '';
                    $X("room").value = room_id_now;
                    self.sendSysMessages($X("room").value, lang_changeUserEvent_room_1, 0, true);
                    setTimeout(updateUserOnlineAnzeigeAfterRoomChange, 400);
                    // 🔥 NEU: Flag nach 1 Sekunde zurücksetzen
                    setTimeout(function() {
                        roomChangeInProgress = false;
                    }, 1000);
                } else {
                    // Passwort falsch - Flag zurücksetzen
                    roomChangeInProgress = false;
                    var errorDiv = dialog.querySelector('#pwroom_error');
                    if (errorDiv) {
                        errorDiv.innerHTML = "<b>" + lang_changeUserEvent_pwroom_2 + "</b>";
                    }
                    var pwField = dialog.querySelector('#layerpw');
                    if (pwField) {
                        pwField.value = '';
                        pwField.focus();
                    }
                }
            })
            .catch(err => {
                roomChangeInProgress = false;
                console.error("CheckRoomPw Fehler:", err);
            });
    }
    var updateUserOnlineAnzeigeAfterRoomChange = function() {
        fetch("./?ReloaderUserOnline", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: "reloadsequenz=" + encodeURIComponent(self.reload_interval)
            })
            .then(res => res.text())
            .then(html => {
                updateUserOnlineAnzeige({
                    responseText: html
                });
            })
            .catch(err => console.error("UserOnline AfterRoom Fehler:", err));
    };
    // ENDE Hier wird das Passwortfenster für gesicherte Räume erstellt
    //###############################################################################################################
    // Little helpers
    var dec2hex = function(n) {
        n = parseInt(n);
        var c = 'ABCDEF';
        var b = n / 16;
        var r = n % 16;
        b = b - (r / 16);
        b = ((b >= 0) && (b <= 9)) ? b : c.charAt(b - 10);
        return ((r >= 0) && (r <= 9)) ? b + '' + r : b + '' + c.charAt(r - 10);
    }
    var hex2dec = function(n) {
        return parseInt(n, 16);
    }
}
//############## END ##################################################################
// Start open Close Cat Smilie
function openCat(evt, catName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(catName).style.display = "block";
    evt.currentTarget.className += " active";
}
// Ende open Close Cat Smilie
// Start Rechtsklick auf Bilder verbieten
document.addEventListener("contextmenu", function(e) {
    if (e.target.nodeName === "IMG") {
        e.preventDefault();
    }
}, false);
// Ende Rechtsklick auf Bilder verbieten
// Start toggle-bar-player
document.addEventListener('DOMContentLoaded', function() {
    const headerToggleBar = document.querySelector('.header-toggle-bar');
    const iframeWrapper = document.querySelector('.iframe-wrapper');
    if (headerToggleBar && iframeWrapper) {
        headerToggleBar.addEventListener('click', function() {
            const hidden = iframeWrapper.classList.toggle('collapsed');
            localStorage.setItem('djIframeHidden', hidden);
            // Verwende die JS-Variablen für die Texte
            headerToggleBar.textContent = hidden ? lang_player_back_js : lang_player_hide_js;
        });
        // Zustand beim Laden wiederherstellen
        if (localStorage.getItem('djIframeHidden') === 'true') {
            iframeWrapper.classList.add('collapsed');
            headerToggleBar.textContent = lang_player_back_js;
        }
    }
});
// Ende toggle-bar-player
// Start Send Comand begrüßen Bye
function sendCommand(cmd) {
    var chatInput = document.getElementById("message");
    var sendButton = document.getElementById("link_sagen");
    if (chatInput && sendButton) {
        chatInput.value = cmd;
        sendButton.click(); // ← GENAU das schickt es ab!
    } else {
        alert("Fehler: Chat-Eingabe oder Senden-Button nicht gefunden.");
    }
}
// Ende Send Comand begrüßen Bye
// Start Scroll an/aus
var bla = '1'; // Anfangszustand: Scrollen AKTIV
function toggleScroll() {
    var input = document.getElementById('scroll_toggle');
    var button = document.getElementById('scroll_toggle_btn');
    if (input.value === '1') {
        // Scrollen deaktivieren
        input.value = '0';
        bla = '0';
        // Verwende die Sprachvariablen aus MessagesForJs
        button.textContent = lang_scroll_an || 'Scroll an\u00A0\u202F';
    } else {
        // Scrollen aktivieren
        input.value = '1';
        bla = '1';
        // Verwende die Sprachvariablen aus MessagesForJs
        button.textContent = lang_scroll_aus || 'Scroll aus';
    }
}
// Ende Scroll an/aus
// Start Cookiehinweiss
function setCookie(key, value, sameSite) {
    var expires = new Date();
    expires.setTime(expires.getTime() + 31536000000); // 1 Jahr
    var cookieString = key + '=' + value + ';expires=' + expires.toUTCString();
    if (sameSite) {
        cookieString += ';SameSite=' + sameSite;
    }
    document.cookie = cookieString;
}

function getCookie(key) {
    var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
    return keyValue ? keyValue[2] : null;
}

function deleteCookie(key) {
    document.cookie = key + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}
// Ende Cookiehinweiss
// Start Fullbild
function toggleFullScreen(elem) {
    if ((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) || (document.mozFullScreen !== undefined && !document.mozFullScreen) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen)) {
        if (elem.requestFullScreen) {
            elem.requestFullScreen();
        } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullScreen) {
            elem.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
        } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen();
        }
    } else {
        if (document.cancelFullScreen) {
            document.cancelFullScreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}
// Ende Fullbild
// Start Online-Userliste (ein-/ausklappbar, mit localStorage-Zustand)
document.addEventListener('DOMContentLoaded', function() {
    const onlineuser = document.getElementById('onlineuser');
    const onlinelist = document.getElementById('onlinelist');
    if (!onlineuser || !onlinelist) return;
    // Gespeicherten Zustand wiederherstellen
    if (localStorage.getItem('userlistCollapsed') === 'true') {
        onlinelist.classList.add('collapsed');
        onlineuser.classList.add('collapsed');
    }
    // Ein-/Ausklappen und Zustand speichern
    onlineuser.addEventListener('click', function() {
        onlinelist.classList.toggle('collapsed');
        onlineuser.classList.toggle('collapsed');
        const isCollapsed = onlinelist.classList.contains('collapsed');
        localStorage.setItem('userlistCollapsed', isCollapsed);
    });
});
document.addEventListener('DOMContentLoaded', function() {
    var openModal = document.getElementById('open-modal');
    var modal = document.getElementById('modal-userliste');
    var closeModal = document.querySelector('.close-modal');
    var onlinelist = document.getElementById('onlinelist');
    if (openModal && modal && closeModal && onlinelist) {
        openModal.addEventListener('click', function() {
            modal.classList.toggle('visible');
            if (onlinelist.classList.contains('collapsed')) {
                onlinelist.classList.remove('collapsed');
                localStorage.setItem('userlistCollapsed', 'false');
            }
        });
        closeModal.addEventListener('click', function() {
            modal.classList.remove('visible');
        });
    }
});
// Ende Online-Userliste (ein-/ausklappbar, mit localStorage-Zustand)
// Start Tab/Reload Detection + Chat-History
(function() {
    /* ================================
     * ZUSTANDS-FLAGS
     * ================================ */
    // isLoggingOut liegt auf window, damit auch der Logout-Handler außerhalb
    // dieser IIFE es setzen kann (vorher: implizite globale Variable + lokale let).
    let isReloading = false;
    let beaconSent = false;
    const self = window.chat || {};
    /* ================================
     * 1) RELOAD ERKENNEN
     * ================================ */
    // Navigation API
    try {
        const nav = performance.getEntriesByType("navigation")[0];
        if (nav && nav.type === "reload") {
            isReloading = true;
        }
    } catch (e) {}
    // Tastatur Reload
    document.addEventListener("keydown", (e) => {
        if (e.key === "F5" || (e.ctrlKey && e.key.toLowerCase() === "r")) {
            isReloading = true;
            setTimeout(() => isReloading = false, 3000);
        }
    });
    // Mobile Pull-to-Refresh
    const isMobile = /Android|iPhone|iPad|iPod|Windows Phone|webOS|BlackBerry/i.test(navigator.userAgent);
    if (isMobile) {
        let startY = 0;
        window.addEventListener("touchstart", e => {
            startY = e.touches[0].clientY;
        }, {
            passive: true
        });
        window.addEventListener("touchmove", e => {
            if (e.touches[0].clientY - startY > 120) {
                isReloading = true;
                setTimeout(() => isReloading = false, 3000);
            }
        }, {
            passive: true
        });
    }
    // Reload beendet → Flag freigeben
    window.addEventListener("pageshow", (e) => {
        if (!e.persisted) {
            isReloading = false;
        }
    });
    /* ================================
     * 2) GUEST-ID (pro Tab stabil)
     * ================================ */
    self._guestId = sessionStorage.getItem("guest_client_id");
    if (!self._guestId) {
        self._guestId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2);
        sessionStorage.setItem("guest_client_id", self._guestId);
    }
    /* ================================
     * 3) SESSION-ID
     * ================================ */
    self.getSessionId = function() {
        const m = document.querySelector('meta[name="session-id"]');
        return m ? m.content : "default-session";
    };
    /* ================================
     * 4) HISTORY-KEY
     * ================================ */
    self.getHistoryKey = function() {
        if (self.user_id && self.user_id > 0) {
            return `chatHistory_user_${self.user_id}_${self.getSessionId()}`;
        }
        return `chatHistory_guest_${self._guestId}_${self.getSessionId()}`;
    };
    /* ================================
     * 5) SAVE CHAT HISTORY
     * ================================ */
    self.saveChatHistory = function() {
        const box = $X('chatinhalt');
        if (!box || box.innerHTML.trim() === "") return;
        const data = {
            html: box.innerHTML,
            scrollTop: box.scrollTop,
            scrollHeight: box.scrollHeight,
            timestamp: Date.now(),
            maxMessages: self.messages_im_chat || 0,
            username: self.username || `guest_${self._guestId}`,
            sessionId: self.getSessionId()
        };
        localStorage.setItem(self.getHistoryKey(), JSON.stringify(data));
    };
    /* ================================
     * 6) LOAD CHAT HISTORY
     * ================================ */
    self.loadChatHistory = function() {
        const box = $X('chatinhalt');
        const raw = localStorage.getItem(self.getHistoryKey());
        if (!box || !raw) return;
        try {
            const data = JSON.parse(raw);
            const nowUser = self.user_id ? self.username : `guest_${self._guestId}`;
            const valid = data.username === nowUser && data.sessionId === self.getSessionId() && data.maxMessages === (self.messages_im_chat || 0) && (Date.now() - data.timestamp) < 5 * 60 * 1000;
            if (!valid) return;
            box.innerHTML = data.html;
            setTimeout(() => {
                box.scrollTop = data.scrollHeight === box.scrollHeight ? data.scrollTop : box.scrollHeight;
            }, 50);
        } catch (e) {
            localStorage.removeItem(self.getHistoryKey());
        }
    };
    /* ================================
     * 7) AUTO-SAVE
     * ================================ */
    self.setupChatHistoryAutoSave = function() {
        setInterval(() => {
            if (!window.isLoggingOut) self.saveChatHistory();
        }, 10000);
        window.addEventListener("beforeunload", () => {
            if (!window.isLoggingOut) self.saveChatHistory();
        });
    };
    // ================================
    // ET-Chat OnlinePing (Broadcast-Style – FINAL)
    // ================================
    window.ET_OnlinePing = (function() {
        let intervalHandle = null;

        function start() {
            if (intervalHandle) return;
            if (!window.BROADCAST_CONFIG || !BROADCAST_CONFIG.user_id) {
                return;
            }
            sendPing();
            intervalHandle = setInterval(sendPing, 10000);
        }

        function sendPing() {
            const userId = BROADCAST_CONFIG.user_id;
            const url = `./?OnlinePing&user_id=${userId}&t=${Date.now()}`;
            fetch(url, {
                keepalive: true
            }).catch(() => {});
        }
        return {
            start
        };
    })();
    /* ================================
     * 10) START: WARTEN BIS CHAT READY
     * ================================ */
    (function waitForChatReady() {
        const box = $X('chatinhalt');
        const userReady = (self.user_id && self.username) || (!self.user_id && self._guestId);
        if (!box || !userReady) {
            setTimeout(waitForChatReady, 200);
            return;
        }
        // History laden
        self.loadChatHistory();
        self.setupChatHistoryAutoSave();
        // *** AJAX erst NACH History starten ***
        if (typeof window._chatStarted === 'undefined') {
            window._chatStarted = true;
            // WICHTIG: Die globale AjaxReadRequest-Funktion aufrufen
            // Aber mit einer kleinen Verzögerung, damit die History Zeit hat
            setTimeout(function() {
                if (typeof AjaxReadRequest === 'function') {
                    AjaxReadRequest();
                }
            }, 500);
        }
    })();
})();
// Ende Tab/Reload Detection + Chat-History
// Start Broadcast System
window.ET_Broadcast = (function() {
    var intervalHandle = null;
    var started = false;

    function start() {
        if (started) return; // 🔒 Mehrfach-Start verhindern
        started = true;
        if (!window.BROADCAST_CONFIG) return;
        createBroadcastModal();
        checkBroadcastNow();
        intervalHandle = setInterval(checkBroadcastNow, BROADCAST_CONFIG.interval);
    }

    function checkBroadcastNow() {
        fetch('?Broadcast&function=checkBroadcast' + '&user_id=' + BROADCAST_CONFIG.user_id + '&t=' + Date.now()).then(function(response) {
            if (!response.ok) throw new Error(response.status);
            return response.json();
        }).then(function(data) {
            if (data.hasBroadcast && data.message) {
                showBroadcast(data.message, !!data.no_reload);
            }
        }).catch(function() {});
    }

    function showBroadcast(message, noReload) {
        document.getElementById('broadcast-content').innerHTML = message.replace(/\n/g, '<br>');
        document.getElementById('broadcast-modal').style.display = 'block';
        document.getElementById('broadcast-overlay').style.display = 'block';
        document.getElementById('confirm-broadcast').onclick = function() {
            document.getElementById('broadcast-modal').style.display = 'none';
            document.getElementById('broadcast-overlay').style.display = 'none';
            if (!noReload) {
                window.location.reload();
            }
        };
    }

    function createBroadcastModal() {
        if (document.getElementById('broadcast-modal')) return;
        var html = `
        <div id="broadcast-modal" style="display:none;position:fixed;top:50%;left:50%;
            transform:translate(-50%,-50%);background:#000;padding:20px;border-radius:8px;
            z-index:9999;min-width:300px;text-align:center;border:3px solid #d9534f;">
            <h3 style="color:#d9534f;margin-top:0;">System Nachricht</h3>
            <p id="broadcast-content" style="color:white;"></p>
            <button id="confirm-broadcast"
                style="padding:8px 20px;background:#5cb85c;color:#fff;border:none;border-radius:4px;">
                OK
            </button>
        </div>
        <div id="broadcast-overlay" style="display:none;position:fixed;top:0;left:0;
            width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:9998;"></div>
        `;
        document.body.insertAdjacentHTML('beforeend', html);
        document.getElementById('broadcast-overlay').onclick = function() {
            document.getElementById('broadcast-modal').style.display = 'none';
            this.style.display = 'none';
        };
    }
    // 🔹 Optional: sauber stoppen (Raumwechsel / Logout)
    function stop() {
        if (intervalHandle) {
            clearInterval(intervalHandle);
            intervalHandle = null;
        }
        started = false;
    }
    return {
        start: start,
        stop: stop
    };
})();
// Ende Broadcast System