<?php
// Automatisch generiert aus radio.json
// NICHT manuell bearbeiten — Quelle ist die JSON-Datei!
// Generiert am: 2026-11-20 12:17:47
return array (
  'dj_onair' => 'DJ OnAir:',
  'listeners' => 'Zuhörer:',
  'bitrate' => 'Bitrate:',
  'title' => 'Titel:',
  'auto_dj' => 'Auto DJ',
  'play' => 'Drücke Play...',
  'paused' => 'Pausiert',
  'kb_s' => 'kb/s',
  'on_air' => 'On Air',
  'error_loading' => 'Titel wird geladen...',
  'stream_unavailable' => 'Stream nicht verfügbar',
  'radio_history' => 'Titel-Liste',
  'date_select' => 'Datum wählen:',
  'no_titles' => 'Keine Titel für diesen Tag.',
  'with_dj' => '(mit DJ {dj})',
  'recent_titles' => '🎵 Zuletzt gespielte Titel ({date})',
  'history_title' => 'Titel-Liste',
  'neuer_titel' => '🎵 Neuer Titel:',
);
