<?php
// Automatisch generiert aus radio.json
// NICHT manuell bearbeiten — Quelle ist die JSON-Datei!
// Generiert am: 2026-11-20 12:59:40
return array (
  'dj_onair' => 'DJ OnAir:',
  'listeners' => 'Listeners:',
  'bitrate' => 'Bitrate:',
  'title' => 'Title:',
  'auto_dj' => 'Auto DJ',
  'play' => 'Press Play...',
  'paused' => 'Paused',
  'kb_s' => 'kb/s',
  'on_air' => 'On Air',
  'error_loading' => 'Loading title...',
  'stream_unavailable' => 'Stream not available',
  'radio_history' => 'Title List',
  'date_select' => 'Select date:',
  'no_titles' => 'No titles for this day.',
  'with_dj' => '(with DJ {dj})',
  'recent_titles' => '🎵 Recently played titles ({date})',
  'history_title' => 'Title List',
  'neuer_titel' => '🎵 New Title:',
);
