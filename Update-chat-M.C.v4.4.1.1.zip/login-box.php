<!--
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/
	 Loginformular mit moderner Sprach-API -->
	 
<?php
// Moderner Sprachzugriff über die IndexBox-Klasse
$lang = $this->lang;

if (!$lang || !($lang instanceof LangJson)) {
    $lang = new LangJson();
}

// ===== GENDER AUS PROFIL-KEYS =====
$genderMale = $lang->get('profil_gender_male', 'männlich');
$genderFemale = $lang->get('profil_gender_female', 'weiblich');
$genderDiverse = $lang->get('profil_gender_diverse', 'divers');
$genderNone = $lang->get('profil_gender_unknown', 'keine Angabe');
?>

<style>
    a {
        font-size: 12px !important;
        text-decoration: underline !important;
    }
    .popup-link {
        font-size: 12px !important;
    }
    #lay_remember {
        margin: 10px 0;
        font-size: 13px;
    }
    #lay_remember label {
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        justify-content: center;
    }
    #lay_remember input[type="checkbox"] {
        cursor: pointer;
        width: 16px;
        height: 16px;
    }
</style>

<form id="login" action="">
    <input type="hidden" name="<?php echo $_SESSION[$this->_prefix.'set_check']; ?>" value="<?php echo $this->aktuell_date_u; ?>" />
    <br />
    
    <!-- ===== HIDDEN FIELDS FÜR JS-TEXTE (aus Json) ===== -->
    <input type="hidden" id="forgot_pw_text" value="<?php echo $lang->get('forgot_password', 'Passwort vergessen?'); ?>">
    <input type="hidden" id="privacy_error_text" value="<?php echo $lang->get('privacy_error', 'Bitte akzeptiere die Datenschutzbestimmungen'); ?>">
    <input type="hidden" id="username_min_length_text" value="<?php echo $lang->get('username_min_length', 'Bitte mindestens 4 Zeichen für den Benutzernamen'); ?>">
    <input type="hidden" id="gender_required_text" value="<?php echo $lang->get('gender_required', 'Bitte wähle ein Geschlecht aus'); ?>">
    <input type="hidden" id="password_wrong_text" value="<?php echo $lang->get('password_wrong', '❌ Passwort falsch - bitte versuchen Sie es erneut'); ?>">
    <input type="hidden" id="cookie_required_text" value="<?php echo $lang->get('cookie_required', 'Bitte akzeptieren Sie zuerst die Cookie-Richtlinien.'); ?>">
    <input type="hidden" id="banned_name_text" value="<?php echo $lang->get('banned_name', '!!!   Unerlaubter Name   !!!'); ?>">
    <input type="hidden" id="banned_text" value="<?php echo $lang->get('banned', 'Du wurdest gebannt!'); ?>">
    <input type="hidden" id="login_failed_text" value="<?php echo $lang->get('login_failed', 'Login fehlgeschlagen: '); ?>">
    <input type="hidden" id="login_failed_default_text" value="<?php echo $lang->get('login_failed_default', 'Login fehlgeschlagen! Bitte versuche es erneut.'); ?>">
    <input type="hidden" id="error_text" value="<?php echo $lang->get('error', 'Fehler: '); ?>">
    
    <!-- ===== BENUTZERNAME ===== -->
    <input type="text" name="username" id="username" value="" minlength="4" maxlength="25" 
           placeholder="<?php echo $lang->get('login_name', 'Dein Chatname'); ?>" required /> 
    <br />
    <br />
    
    <!-- ===== PASSWORT ===== -->
    <div id="lay_pw" style="display: none; position: relative;">
        <input type="password" name="pw" value="" id="pw" 
               placeholder="<?php echo $lang->get('login_password', 'Passwort:'); ?>" />
        <span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; bottom: 6px;" id="togglePassword">👁️</span>
        <span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; display: none; bottom: 6px;" id="togglePasswordOff">🙈</span>
        <br>
    </div>
    
    <!-- ===== UNSICHTBAR ===== -->
    <div id="lay_invisible" style="display: none;">
        <input type="checkbox" name="status_invisible" value="1" />
        <?php echo $lang->get('login_invisible', 'unsichtbar'); ?>
    </div>
    
    <!-- ===== GESCHLECHT ===== -->
    <div id="lay_gender">
        <input type="radio" name="gender" value="m" id="sex_m" class="gender-input">
        <label for="sex_m" class="gender-label"><?php echo $genderMale; ?></label>
        <input type="radio" name="gender" value="f" id="sex_f" class="gender-input">
        <label for="sex_f" class="gender-label"><?php echo $genderFemale; ?></label>
        <input type="radio" name="gender" value="d" id="sex_d" class="gender-input">
        <label for="sex_d" class="gender-label"><?php echo $genderDiverse; ?></label>
        <br><br>
        <input type="radio" name="gender" value="n" id="sex_n" class="gender-input" checked>
        <label for="sex_n" class="gender-label"><?php echo $genderNone; ?></label>
        <br />
    </div>
    
    <br />
    
    <!-- ===== DATENSCHUTZ (Pflicht) ===== -->
    <input type="checkbox" id="privacy_policy" name="privacy_policy" value="true" required />
    <label for="privacy_policy" style="cursor: pointer;">
        <?php echo $lang->get('datenschutz_ok', 'OK'); ?>
    </label>
    <a href="#" id="open_datenschutz_popup">
        <?php echo $lang->get('datenschutz_cookie', '(Cookie und Datenschutz akzeptieren)'); ?>
    </a>
    
    <br>
    sowie die <a href="#" id="open_chatregeln_popup">
        <?php echo $lang->get('chat_rules', 'Chatregeln'); ?>
    </a> akzeptieren.
    
    <br />
    
    <!-- ===== NEU: ANGEMELDET BLEIBEN ===== -->
    <div id="lay_remember">
        <label style="cursor: pointer;">
            <input type="checkbox" id="remember_me" name="remember_me" value="1"> 
            <?php echo $lang->get('remember_me', 'Ich möchte angemeldet bleiben'); ?>
        </label>
    </div>
    
    <!-- ===== SUBMIT BUTTON ===== -->
    <input type="submit" id="submit_button" name="go" value="<?php echo $lang->get('login_submit', 'Chat Login'); ?>" />
</form>

<p>
    <a href="#" id="open_register_popup"><?php echo $lang->get('register_button', 'Registrieren für den Chat'); ?></a>
</p>
