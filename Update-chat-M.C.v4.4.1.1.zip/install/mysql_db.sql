INSERT INTO `etchat_wunschbox_config` (`config_key`, `config_value`)
SELECT `config_key`, `config_value`
FROM `etchat_sendeplan_config`
WHERE `config_key` IN ('wunschbox_vorab_enabled','wunschbox_vorab_mods','wunschbox_vorab_max_days')
ON DUPLICATE KEY UPDATE `config_value` = VALUES(`config_value`);

DELETE FROM `etchat_sendeplan_config`
WHERE `config_key` IN ('wunschbox_vorab_enabled','wunschbox_vorab_mods','wunschbox_vorab_max_days');

ALTER TABLE `etchat_texte` MODIFY `content` MEDIUMTEXT;
ALTER TABLE `etchat_start_boxes` MODIFY `content` MEDIUMTEXT;