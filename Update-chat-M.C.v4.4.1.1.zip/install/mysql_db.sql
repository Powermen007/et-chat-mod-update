-- 1) Config von sendeplan_config nach wunschbox_config kopieren
INSERT INTO `etchat_wunschbox_config` (`config_key`, `config_value`)
SELECT `config_key`, `config_value`
FROM `etchat_sendeplan_config`
WHERE `config_key` IN ('wunschbox_vorab_enabled','wunschbox_vorab_mods','wunschbox_vorab_max_days')
ON DUPLICATE KEY UPDATE `config_value` = NEW.`config_value`;

-- 2) Alte Eintr�ge entfernen
DELETE FROM `etchat_sendeplan_config`
WHERE `config_key` IN ('wunschbox_vorab_enabled','wunschbox_vorab_mods','wunschbox_vorab_max_days');

-- 3) TEXT ? MEDIUMTEXT
ALTER TABLE `etchat_texte` MODIFY `content` MEDIUMTEXT;
ALTER TABLE `etchat_start_boxes` MODIFY `content` MEDIUMTEXT;

-- 4) Neue Tabelle
CREATE TABLE IF NOT EXISTS `etchat_giphy_codes` (
    `etchat_giphy_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `etchat_giphy_code` VARCHAR(32) NOT NULL,
    `etchat_giphy_url` VARCHAR(512) NOT NULL,
    `etchat_giphy_created` INT UNSIGNED NOT NULL,
    PRIMARY KEY (`etchat_giphy_id`),
    UNIQUE KEY `etchat_giphy_code` (`etchat_giphy_code`),
    KEY `etchat_giphy_created` (`etchat_giphy_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;