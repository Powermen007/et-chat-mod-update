// ============================
// PLAYER.JS – VOLLSTÄNDIG LESBARE VERSION
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/
// ============================

const audio = document.getElementById('audio');
const playPauseBtn = document.getElementById('playPauseBtn');
const timeDisplay = document.getElementById('timeDisplay');
const muteBtn = document.getElementById('muteBtn');
const volumeSlider = document.getElementById('volumeSlider');
const volumeControl = document.getElementById('volumeControl');
const player = document.getElementById('player');
const streamTitle = document.getElementById('streamTitle');
const volumeContainer = document.getElementById('volumeContainer');

let titleInterval;
let volumeHideTimeout;

// ============================================================
// 1. GERÄTEBASIERTE LAUTSTÄRKE
// ============================================================
function isMobileDevice() {
    return /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
}

if (audio) {
    audio.volume = isMobileDevice() ? 0.9 : 0.3;
    audio.dataset.lastVolume = audio.volume;
}

if (volumeControl && audio) {
    volumeControl.value = audio.volume;
}

// ============================================================
// 2. PLAY / PAUSE
// ============================================================
if (playPauseBtn && audio) {
    playPauseBtn.addEventListener('click', function() {
        if (audio.paused) {
			audio.removeAttribute('src');
			audio.load();
            // Stream starten
            audio.src = audio.dataset.stream;
			audio.load();
            
            audio.play()
                .then(function() {
                    // Pause-Symbol (⏸)
                    playPauseBtn.innerHTML = '&#10074;&#10074;';
                    
                    // Titel laden + Intervall starten (alle 30 Sek.)
                    loadStreamTitle();
                    
                    if (titleInterval) {
                        clearInterval(titleInterval);
                    }
                    titleInterval = setInterval(loadStreamTitle, 30000);
                })
                .catch(function(err) {
                    console.error("Fehler beim Abspielen:", err);
                });
        } else {
            // Pause
            audio.pause();
            audio.removeAttribute('src');
            audio.load();
            
            // Play-Symbol (▶)
            playPauseBtn.innerHTML = '&#9654;';
            
            // Titel-Intervall stoppen
            if (titleInterval) {
                clearInterval(titleInterval);
                titleInterval = null;
            }
            
            // Anzeige zurücksetzen
            if (streamTitle) {
                // Sprache aus globalem lang-Objekt oder Fallback
                streamTitle.textContent = (typeof lang !== 'undefined' && lang.play) ? lang.play : 'Drücke Play...';
            }
            if (timeDisplay) {
                timeDisplay.textContent = '00:00';
            }
        }
    });
}

// ============================================================
// 3. STREAM-TITEL LADEN (mit Cache-Priorität)
// ============================================================
function loadStreamTitle() {
    if (!audio || !audio.dataset.stream) {
        return;
    }
    
    var streamUrl = encodeURIComponent(audio.dataset.stream);
    
    fetch('gettitle.php?url=' + streamUrl)
        .then(function(response) {
            return response.text();
        })
        .then(function(data) {
            // Titel aus der Antwort extrahieren (erster Teil vor "|")
            var title = data.split('|')[0].trim();
            if (streamTitle && title) {
                streamTitle.textContent = title;
            }
        })
        .catch(function() {
            // Bei Fehler: nichts tun oder Platzhalter
            if (streamTitle && streamTitle.textContent === '') {
                streamTitle.textContent = (typeof lang !== 'undefined' && lang.play) ? lang.play : 'Drücke Play...';
            }
        });
}

// ============================================================
// 4. MUTE / UNMUTE
// ============================================================
if (muteBtn && audio && volumeControl) {
    muteBtn.addEventListener('click', function() {
        if (audio.volume > 0) {
            // Stummschalten
            audio.dataset.lastVolume = audio.volume;
            audio.volume = 0;
            volumeControl.value = 0;
            muteBtn.innerHTML = '&#128263;'; // Lautsprecher mit X
        } else {
            // Ton wieder an
            var lastVolume = parseFloat(audio.dataset.lastVolume) || 0.1;
            audio.volume = lastVolume;
            volumeControl.value = lastVolume;
            muteBtn.innerHTML = '&#128266;'; // Normaler Lautsprecher
        }
    });
}

// ============================================================
// 5. VOLUME-SLIDER ANZEIGEN (Hover)
// ============================================================
if (volumeContainer && volumeSlider) {
    volumeContainer.addEventListener('mouseenter', function() {
        var rect = player ? player.getBoundingClientRect() : null;
        var spaceAbove = rect ? rect.top : 0;
        
        // Position bestimmen (above/below)
        if (spaceAbove >= 100) {
            volumeSlider.classList.remove('below');
            volumeSlider.classList.add('above');
        } else {
            volumeSlider.classList.remove('above');
            volumeSlider.classList.add('below');
        }
        
        clearTimeout(volumeHideTimeout);
        volumeSlider.style.display = 'block';
    });
    
    volumeContainer.addEventListener('mouseleave', function() {
        volumeHideTimeout = setTimeout(function() {
            volumeSlider.style.display = 'none';
        }, 1000);
    });
}

// ============================================================
// 6. LAUTSTÄRKE REGELN
// ============================================================
if (volumeControl && audio) {
    volumeControl.addEventListener('input', function() {
        var vol = parseFloat(volumeControl.value);
        audio.volume = vol;
        muteBtn.innerHTML = (vol === 0) ? '&#128263;' : '&#128266;';
    });
}

// ============================================================
// 7. ZEIT-ANZEIGE (Timeupdate)
// ============================================================
if (audio && timeDisplay) {
    audio.addEventListener('timeupdate', function() {
        var minutes = Math.floor(audio.currentTime / 60);
        var seconds = Math.floor(audio.currentTime % 60);
        
        if (seconds < 10) {
            seconds = '0' + seconds;
        }
        
        timeDisplay.textContent = minutes + ':' + seconds;
    });
}

// ============================================================
// 8. OPTIONAL: VISIBILITY API (Tab sichtbar?)
// ============================================================
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // Tab ist versteckt → Titel-Updates stoppen (spart Ressourcen)
        if (titleInterval) {
            clearInterval(titleInterval);
            titleInterval = null;
        }
    } else {
        // Tab ist wieder sichtbar → Titel-Updates starten (wenn Player läuft)
        if (!audio.paused && !titleInterval) {
            loadStreamTitle();
            titleInterval = setInterval(loadStreamTitle, 30000);
        }
    }
});