<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

/**
 * Login - Einstiegsbereich der Startseite.
 *
 * Diese Klasse ist der Dirigent für den kompletten Einstiegs-Flow:
 *  - Login-Formular (Standard)
 *  - Registrierung (?register / ?token)              -> Registrieren
 *  - Passwort vergessen / zurücksetzen (?passwort=…) -> PasswortVergessen
 *  - E-Mail ändern (?email_aendern)                  -> EmailAendern
 *
 * index.tpl.html ruft nur noch (new Login())->render(); auf.
 */
class Login extends DbConectionMaker
{
    private ?LangJson $lang = null;
	public int $aktuell_date_u;

    public function __construct()
    {
        parent::__construct();

        // Zugriffsschutz (öffentlich zugänglich, daher true)
        require_once __DIR__ . '/ZugriffsGuard.class.php';
        new ZugriffsGuard(true);

        // Anti-Bot: set_check-Hash für CheckUserName
        $this->aktuell_date_u = time();
        $_SESSION[$this->_prefix . 'set_check'] = hash('sha256', (string)$this->aktuell_date_u);

        // Sprache laden
        try {
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }
    }

    /**
     * Dispatcher: entscheidet, welches Fragment gerendert wird.
     */
    public function render(): void
    {
        // 1) E-Mail ändern
        if (isset($_GET['email_aendern'])) {
            (new EmailAendern())->run();
            return;
        }

        // 2) Passwort vergessen / zurücksetzen
        if (
            isset($_GET['passwort']) &&
            in_array($_GET['passwort'], ['vergessen', 'zuruecksetzen'], true)
        ) {
            (new PasswortVergessen())->run();
            return;
        }

        // 3) Registrierung / Token-Aktivierung
        if (isset($_GET['register']) || isset($_GET['token'])) {
            (new Registrieren())->run();
            return;
        }

        // 4) Standard: Login-Formular
        $this->renderLoginForm();
    }

    /**
     * Gibt einen lokalisierten Text zurück (Fallback: $default).
     */
    private function t(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * HTML-Escaping-Helfer.
     */
    private function h(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    }

    /**
     * Rendert das Login-Formular (ehemals login.php).
     */
    private function renderLoginForm(): void
    {
        $lang = $this->lang;

        // Fallback, falls LangJson nicht verfügbar
        if (!$lang || !($lang instanceof LangJson)) {
            $lang = new LangJson();
        }

        // ===== GENDER AUS PROFIL-KEYS =====
        $genderMale    = $lang->get('profil_gender_male', 'männlich');
        $genderFemale  = $lang->get('profil_gender_female', 'weiblich');
        $genderDiverse = $lang->get('profil_gender_diverse', 'divers');
        $genderNone    = $lang->get('profil_gender_unknown', 'keine Angabe');
        ?>

        <!-- ===== HIDDEN FIELDS FÜR JS-TEXTE (aus Json) ===== -->
        <input type="hidden" id="forgot_pw_text" value="<?php echo $this->h($lang->get('forgot_password', 'Passwort vergessen?')); ?>">
        <input type="hidden" id="privacy_error_text" value="<?php echo $this->h($lang->get('privacy_error', 'Bitte akzeptieren Sie die Datenschutzbestimmungen und Chatregeln!')); ?>">
        <input type="hidden" id="username_min_length_text" value="<?php echo $this->h($lang->get('username_min_length', 'Sorry ... mindestens 3 Buchstaben beim Namen eingegeben')); ?>">
        <input type="hidden" id="gender_required_text" value="<?php echo $this->h($lang->get('gender_required', '???   Dein Geschlecht   ???')); ?>">
        <input type="hidden" id="password_wrong_text" value="<?php echo $this->h($lang->get('password_wrong', '❌ Passwort falsch - bitte versuchen Sie es erneut')); ?>">
        <input type="hidden" id="connection_error_text" value="<?php echo $this->h($lang->get('connection_error', 'Verbindungsfehler. Bitte versuche es erneut.')); ?>">

        <form id="login" action="">
                        <?php
            $setCheckName  = $_SESSION[$this->_prefix . 'set_check'] ?? '';
            $setCheckValue = $this->aktuell_date_u;
            ?>
            <input type="hidden" name="<?php echo $this->h($setCheckName); ?>" value="<?php echo (int)$setCheckValue; ?>" />
            <br />

            <!-- ===== BENUTZERNAME ===== -->
            <input type="text" name="username" id="username" value="" minlength="4" maxlength="25"
                   placeholder="<?php echo $this->h($lang->get('login_name', 'Dein Chatname')); ?>" required />
            <br />
            <br />

            <!-- ===== PASSWORT ===== -->
            <div id="lay_pw" style="display: none; position: relative;">
                <input type="password" name="pw" value="" id="pw"
                       placeholder="<?php echo $this->h($lang->get('login_password', 'Passwort:')); ?>" />
                <span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; bottom: 6px;" id="togglePassword">👁️</span>
                <span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; display: none; bottom: 6px;" id="togglePasswordOff">🙈</span>
                <br>
            </div>

            <!-- ===== UNSICHTBAR ===== -->
            <div id="lay_invisible" style="display: none;">
                <input type="checkbox" name="status_invisible" value="1" />
                <?php echo $lang->get('login_invisible', 'unsichtbar'); ?>
            </div>

            <!-- ===== GESCHLECHT ===== -->
            <div id="lay_gender">
                <input type="radio" name="gender" value="m" id="sex_m" class="gender-input">
                <label for="sex_m" class="gender-label"><?php echo $genderMale; ?></label>
                <input type="radio" name="gender" value="f" id="sex_f" class="gender-input">
                <label for="sex_f" class="gender-label"><?php echo $genderFemale; ?></label>
                <input type="radio" name="gender" value="d" id="sex_d" class="gender-input">
                <label for="sex_d" class="gender-label"><?php echo $genderDiverse; ?></label>
                <br><br>
                <input type="radio" name="gender" value="n" id="sex_n" class="gender-input" checked>
                <label for="sex_n" class="gender-label"><?php echo $genderNone; ?></label>
                <br />
            </div>

            <br />

            <!-- ===== NUR EINE CHECKBOX FÜR ALLES ===== -->
            <input type="checkbox" id="privacy_policy" name="privacy_policy" value="true" required />
            <label for="privacy_policy" style="cursor: pointer;">
                <?php echo $lang->get('datenschutz_ok', 'OK'); ?>
                <?php echo $lang->get('datenschutz_cookie', '(Cookie und Datenschutz akzeptieren)'); ?>
                <br><?php echo $lang->get('sowie_die', '(sowie die)'); ?>
                <a class="popup_link"
                   data-popup-title="<?php echo $this->h($lang->get('chat_rules', 'Chatregeln')); ?>"
                   data-popup-src="?Text&amp;id=4"
                   data-pane-id="menu-pane-chatregeln"
                   href="#"> <?php echo $lang->get('chat_rules', 'Chatregeln'); ?></a>
                <?php echo $lang->get('akzeptieren', '(akzeptieren.)'); ?>
            </label>

            <br />

            <!-- ===== ANGEMELDET BLEIBEN (OPTIONAL) ===== -->
            <div id="lay_remember" style="margin-bottom: 5px; margin-top: 5px;">
                <label style="cursor: pointer;">
                    <input type="checkbox" id="remember_me" name="remember_me" value="1">
                    <?php echo $lang->get('remember_me', 'Ich möchte angemeldet bleiben'); ?>
                </label>
            </div>

            <!-- ===== SUBMIT BUTTON ===== -->
            <input type="submit" id="submit_button" name="go" value="<?php echo $this->h($lang->get('login_submit', 'Chat Login')); ?>" />
            <br />

            <!-- ===== REGISTRIEREN BUTTON ===== -->
            <?php if (($_SESSION['etchat_' . $this->_prefix . 'reg_an_aus'] ?? '0') == '1') { ?>
                <button type="button" id="submit_button_reg" style="margin: 15px 0;" onclick="window.location.href='?register=1';"><?php echo $this->h($lang->get('register_button', 'Registrieren')); ?></button>
            <?php } else { echo '<br/>'; } ?>
        </form>
        <?php
    }
}