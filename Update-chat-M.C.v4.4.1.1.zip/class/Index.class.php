<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Index extends DbConectionMaker
{
    public $lang = null;
    public int $aktuell_date_u;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'secure'   => $isHttps,
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            session_start();
        }

        if (!headers_sent()) {
            header('Content-Type: text/html; charset=utf-8');
        }

        // ===== NUR EIN COOKIE: db1_session_active =====
        // 1 = akzeptiert, 0 = abgelehnt, nicht vorhanden = keine Entscheidung
        $this->handleCookies();

        $this->configTabData2Session();
        $this->runCleanupIfDue();

        $this->aktuell_date_u = time();
        $_SESSION[$this->_prefix . 'set_check'] = hash('sha256', (string) $this->aktuell_date_u);

        $this->loadLanguage();
        $this->initTemplate();
    }

    /**
     * NUR EIN COOKIE: db1_session_active
     */
    private function handleCookies(): void
    {
        $cookieName = $this->_prefix . 'session_active';
        $cookieValue = $_COOKIE[$cookieName] ?? null;
        
        if ($cookieValue === '1') {
            $_SESSION[$this->_prefix . 'consent'] = 'accepted';
        } elseif ($cookieValue === '0') {
            $_SESSION[$this->_prefix . 'consent'] = 'declined';
        } else {
            $_SESSION[$this->_prefix . 'consent'] = null;
        }
    }

    private function initTemplate(): void
    {
        $style = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'default');
        $templatePath = __DIR__ . "/../styles/{$style}/index.tpl.html";

        if (is_file($templatePath)) {
            include_once $templatePath;
        } else {
            // Fallback: Standard-Template, falls Style-Verzeichnis fehlt
            $fallback = __DIR__ . "/../styles/default/index.tpl.html";
            if (is_file($fallback)) {
                include_once $fallback;
            } else {
                echo "Template nicht gefunden: " . htmlspecialchars($templatePath);
            }
        }
    }

    private function runCleanupTasks(): void
    {
        $deleteDays = (int) ($_SESSION['etchat_' . $this->_prefix . 'loeschen_nach'] ?? 30);

        $messageExpireTime = time() - ($deleteDays * 86400);
        $guestExpireTime    = time() - ($deleteDays * 86400 * 2);
        $currentTime        = time();

        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_messages WHERE etchat_timestamp < :ts",
            [':ts' => $messageExpireTime]
        );

        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_blacklist WHERE etchat_blacklist_time < :t",
            [':t' => $currentTime]
        );

        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_kick_user WHERE etchat_kicked_user_time < :t",
            [':t' => $currentTime]
        );

        $this->dbObj->sqlSet("
            DELETE FROM {$this->_prefix}etchat_user
            WHERE etchat_userprivilegien = 'gast'
            AND etchat_reset_token IS NOT NULL
            AND etchat_reset_token_expiry < DATE_SUB(NOW(), INTERVAL 35 MINUTE)
        ");

        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_user
             WHERE etchat_userprivilegien = 'gast'
             AND etchat_logintime < :gt",
            [':gt' => $guestExpireTime]
        );
		
		// 🔥 NEU: Cache-Dateien zentral bereinigen
        $this->cleanupCaches($deleteDays);
    }
	
    /**
     * 🔥 NEU: Zentrale Cache-Bereinigung
     * Löscht FFmpeg-bezogene Cache-Dateien, die älter als $deleteDays sind.
     */
    private function cleanupCaches(int $deleteDays = 30): void
    {
        if ($deleteDays < 1) $deleteDays = 30;
        
        $cacheDir = __DIR__ . '/../cache/';
        if (!is_dir($cacheDir)) return;
        
        $cacheFiles = [
            'ffmpeg_status.json',
            'ffmpeg_errors.log',
        ];
        
        $threshold = time() - ($deleteDays * 86400);
        
        foreach ($cacheFiles as $file) {
            $path = $cacheDir . $file;
            if (is_file($path) && filemtime($path) < $threshold) {
                @unlink($path);
            }
        }
    }

    /**
     * MODERNE Sprach-Lade-Methode (dynamisch)
     */
    private function loadLanguage(): void
    {
        try {
            // Dynamische Spracherkennung über LangJson
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }
    }
    
    public function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }
    
    public function getTextArray(string $key): array
    {
        if ($this->lang !== null) {
            return $this->lang->getArray($key);
        }
        return [];
    }
    
    private function monthlyMaintenance(): void
    {
        if ((int) date('d') !== 31) {
            return;
        }

        try {
            $this->dbObj->sqlSet("SET @a = 0");
            $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_messages SET etchat_id = (@a := @a + 1)");
            $this->dbObj->sqlSet("ALTER TABLE {$this->_prefix}etchat_messages AUTO_INCREMENT = 1");
            $this->dbObj->sqlSet("OPTIMIZE TABLE {$this->_prefix}etchat_messages");
        } catch (Throwable $e) {
            // Fehler still behandeln
        }
    }

    private function runCleanupIfDue(): void
    {
        $interval = 1800;
        $file = __DIR__ . '/../cache/cleanup_last_run.txt';

        $lastRun = is_file($file) ? (int) file_get_contents($file) : 0;

        if (time() - $lastRun >= $interval) {
            $this->runCleanupTasks();
            file_put_contents($file, (string) time(), LOCK_EX);
        }
    }
}
?>