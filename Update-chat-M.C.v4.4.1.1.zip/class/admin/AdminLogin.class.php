<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminLogin extends DbConectionMaker
{
    private object $lang;
    private string $error   = '';
    private string $success = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Content-Type: text/html; charset=utf-8');
        }

        $this->lang = new LangJson('', 'wb_sendeplan_admin.json');

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login_attempt'])) {
            $this->handlePost();
        }

        $this->render();
    }

    /* ============================================================
     *  LOGIN-LOGIK
     * ============================================================ */
    private function handlePost(): void
    {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['pw'] ?? '');

        if ($username === '' || $password === '') {
            $this->error = $this->lang->get(
                'admin_login_err_empty',
                'Bitte Name und Passwort eingeben.'
            );
            return;
        }

        $rows = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_username, etchat_userpw,
                    etchat_userprivilegien, etchat_usersex
             FROM {$this->_prefix}etchat_user
             WHERE etchat_username = :u
             LIMIT 1",
            [':u' => $username]
        );

        if (!$rows) {
            $this->error = $this->lang->get(
                'admin_login_err_user_not_found',
                'Benutzer nicht gefunden.'
            );
            return;
        }

        $row  = $rows[0];
        $priv = (string)($row['etchat_userprivilegien'] ?? '');

        if (!in_array($priv, ['admin', 'mod', 'co_admin', 'grafik', 'chatwache'], true)) {
            $this->error = $this->lang->get(
                'admin_login_err_no_perm',
                'Dieser Zugang ist nur für das Team (Admin, Mod, Co-Admin, Grafik, Chatwache).'
            );
            return;
        }

        // Passwort prüfen: md5 (Altbestand) ODER password_hash (modern, Feld = 255)
        $storedPw = (string)($row['etchat_userpw'] ?? '');
        $isValid  = false;

        if ($storedPw !== '') {
            if (md5($password) === $storedPw) {
                $isValid = true;
            } elseif (password_verify($password, $storedPw)) {
                $isValid = true;
            }
        }

        if (!$isValid) {
            $this->error = $this->lang->get(
                'admin_login_err_wrong_pw',
                'Passwort falsch.'
            );
            return;
        }

        // Session setzen
        $_SESSION['etchat_' . $this->_prefix . 'user_id']   = (int)$row['etchat_user_id'];
        $_SESSION['etchat_' . $this->_prefix . 'username']  = (string)$row['etchat_username'];
        $_SESSION['etchat_' . $this->_prefix . 'user_priv'] = $priv;

        // Style aus DB laden, falls noch nicht in Session
        $styleKey = 'etchat_' . $this->_prefix . 'style';
        if (empty($_SESSION[$styleKey])) {
            try {
                $cfg = $this->dbObj->sqlGet(
                    "SELECT etchat_config_style FROM {$this->_prefix}etchat_config
                     WHERE etchat_config_id = 1 LIMIT 1"
                );
                $_SESSION[$styleKey] = (!empty($cfg[0]['etchat_config_style']))
                    ? (string)$cfg[0]['etchat_config_style']
                    : 'style_chat';
            } catch (Throwable $e) {
                $_SESSION[$styleKey] = 'style_chat';
            }
        }

        // ============================================================
        // 1. ALTEN Cookie per PHP löschen — MIT und OHNE HttpOnly
        // ============================================================
        $this->clearOldChatCookie();

        // ============================================================
        // 2. Daten für JavaScript in Session ablegen
        // ============================================================
        if (!empty($_POST['admin_remember_me'])) {
            // Gender bestimmen: alter Cookie → DB → 'd'
            $gender = $this->getGenderForCookie($row['etchat_usersex'] ?? '');

            // 🔥 NEU: is_invisible — nur für admin
            $isInvisible = ($priv === 'admin');

            $_SESSION['admin_login_cookie_data'] = [
                'action'       => 'set',
                'username'     => $username,
                'password'     => $password,
                'gender'       => $gender,
                'is_invisible' => $isInvisible,
            ];
        } else {
            $_SESSION['admin_login_cookie_data'] = [
                'action'   => 'delete',
            ];
        }

        $roleLabels = [
            'admin'     => 'Administrator',
            'mod'       => 'Moderator',
            'co_admin'  => 'Co-Admin',
            'grafik'    => 'Grafiker',
            'chatwache' => 'Chatwache',
        ];
        $roleLabel = $roleLabels[$priv] ?? $priv;

        $this->success = $this->lang->get(
            'admin_login_success',
            'Login erfolgreich als %s.<br>Du kannst jetzt den Sendeplan öffnen.'
        );
        $this->success = sprintf($this->success, htmlspecialchars($roleLabel, ENT_QUOTES, 'UTF-8'));
    }

    /* ============================================================
     *  COOKIE-HELFER
     * ============================================================ */

    private function getChatCookiePrefix(): string
    {
        $host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
        $host = preg_replace('/:\d+$/', '', $host);
        $host = preg_replace('/^www\./', '', $host);
        $host = str_replace('.', '_', $host);
        $host = preg_replace('/[^a-zA-Z0-9_]/', '', $host);

        return 'chat_' . $host;
    }

    private function getChatCookieName(): string
    {
        return $this->getChatCookiePrefix() . '_login_data';
    }

    /**
     * Löscht alte Chat-Login-Cookies — sowohl HttpOnly als auch non-HttpOnly.
     */
    private function clearOldChatCookie(): void
    {
        if (headers_sent()) {
            return;
        }

        $name = $this->getChatCookieName();

        // 1. Löschen mit HttpOnly-Flag (für alte HttpOnly-Cookies)
        header(
            'Set-Cookie: ' . $name . '='
            . '; expires=Thu, 01 Jan 1970 00:00:00 GMT'
            . '; path=/'
            . '; httponly',
            false
        );

        // 2. Löschen ohne HttpOnly-Flag (für non-HttpOnly-Cookies)
        header(
            'Set-Cookie: ' . $name . '='
            . '; expires=Thu, 01 Jan 1970 00:00:00 GMT'
            . '; path=/',
            false
        );

        // 3. Aus dem aktuellen Request-Cache entfernen
        unset($_COOKIE[$name]);
    }

    /**
     * Liest den Chat-Login-Cookie aus und liefert username + password.
     */
    private function getPrefillFromChatCookie(): array
    {
        $out = ['username' => '', 'password' => ''];

        $cookieName = $this->getChatCookieName();
        if (empty($_COOKIE[$cookieName])) {
            return $out;
        }

        $raw = (string)$_COOKIE[$cookieName];

        $step1 = base64_decode($raw, true);
        if ($step1 === false) {
            return $out;
        }

        $step2 = rawurldecode($step1);

        $data = json_decode($step2, true);
        if (!is_array($data)) {
            return $out;
        }

        $tsMs = (int)($data['timestamp'] ?? 0);
        if ($tsMs <= 0) {
            return $out;
        }
        $ageSeconds = time() - (int)($tsMs / 1000);
        if ($ageSeconds > 30 * 86400 || $ageSeconds < 0) {
            return $out;
        }

        $out['username'] = (string)($data['username'] ?? '');

        $pwB64 = (string)($data['password'] ?? '');
        if ($pwB64 !== '') {
            $pw = base64_decode($pwB64, true);
            if ($pw !== false) {
                $out['password'] = $pw;
            }
        }

        return $out;
    }

    /**
     * Bestimmt das Gender für den Chat-Login-Cookie.
     */
    private function getGenderForCookie(string $dbGender = ''): string
    {
        $gender = '';
        $cookieName = $this->getChatCookieName();

        // 1. Aus bestehendem Cookie
        if (!empty($_COOKIE[$cookieName])) {
            $raw = (string)$_COOKIE[$cookieName];
            $step1 = base64_decode($raw, true);
            if ($step1 !== false) {
                $step2 = rawurldecode($step1);
                $data = json_decode($step2, true);
                if (is_array($data) && !empty($data['gender'])) {
                    $g = (string)$data['gender'];
                    if (in_array($g, ['m', 'f', 'd'], true)) {
                        $gender = $g;
                    }
                }
            }
        }

        // 2. Aus DB
        if ($gender === '') {
            $g = strtolower(trim($dbGender));
            if (in_array($g, ['m', 'f', 'd'], true)) {
                $gender = $g;
            }
        }

        // 3. Fallback
        if ($gender === '') {
            $gender = 'd';
        }

        return $gender;
    }

    /* ============================================================
     *  STYLE-URL
     * ============================================================ */
    private function getStyleUrl(): string
    {
        $styleName = preg_replace(
            '/[^a-zA-Z0-9_\-]/',
            '',
            $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'style_chat'
        );

        $stylePath = 'styles/' . $styleName . '/style.css';
        $styleVer  = file_exists($stylePath) ? filemtime($stylePath) : time();

        return htmlspecialchars($stylePath, ENT_QUOTES, 'UTF-8') . '?v=' . $styleVer;
    }

    /* ============================================================
     *  HTML-AUSGABE
     * ============================================================ */
    private function render(): void
    {
        $styleUrl = $this->getStyleUrl();
        $error    = $this->error;
        $success  = $this->success;
        $lang     = $this->lang;

        // 🔥 NEU: Rolle aus Session für Button-Sichtbarkeit
        $privForButtons = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');

        $prefill = $this->getPrefillFromChatCookie();
        $hasPrefill = ($prefill['username'] !== '');

        // Cookie-Daten für JS (aus Session, dann löschen)
        $cookieData = $_SESSION['admin_login_cookie_data'] ?? null;
        unset($_SESSION['admin_login_cookie_data']);

        $title       = $lang->get('admin_login_title', 'Sendeplan-Wunschbox-Login');
        $subtitle    = $lang->get('admin_login_subtitle', 'Nur für Administratoren und Moderatoren.');
        $lblUser     = $lang->get('admin_login_label_username', 'Benutzername');
        $lblPass     = $lang->get('admin_login_label_password', 'Passwort');
        $phUser      = $lang->get('admin_login_placeholder_username', 'Dein Chatname');
        $phPass      = $lang->get('admin_login_placeholder_password', 'Passwort:');
        $btnLogin    = $lang->get('admin_login_btn_login', 'Anmelden');
        $btnOpenPlan = $lang->get('admin_login_btn_open_plan', 'Sendeplan öffnen');
        $btnOpenWun  = $lang->get('admin_login_btn_open_wun', 'Wunschbox öffnen');
        // 🔥 NEU: Button für AdminIndex (Chatconfig)
        $btnOpenAdmin = $lang->get('admin_login_btn_open_admin', 'Chatconfig öffnen');
        $lblRemember = $lang->get('admin_login_label_remember', 'Angemeldet bleiben');
        ?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<title>🔑 <?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<link rel="stylesheet" href="<?= $styleUrl ?>">
<script>
if (window.top === window.self) {
    window.location.replace('./');
}
</script>
</head>
<body id="body">

<div class="layout">
    <div id="inhalt">

        <h2 style="margin-top: 0;">🔑 <?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h2>
        <p style="font-size: var(--font-size-base); margin-top: 0;">
            <?= htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8') ?>
        </p>

        <?php if ($error !== ''): ?>
            <div class="meldung" style="margin: 10px auto; padding: 10px; background: #ff0404d4; border-radius: 6px; text-align: center;">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if ($success !== ''): ?>

            <div style="margin: 10px auto; padding: 10px; background: rgba(0,128,0,0.3); border-radius: 6px; text-align: center;">
                <?= $success ?>
            </div>

            <div style="margin-top: 15px; text-align: center;">
                <button type="button"
                        id="submit_button_reg"
                        onclick="window.open('./?AdminSendeplan', '_blank', 'noopener');">
                    ✏️ <?= htmlspecialchars($btnOpenPlan, ENT_QUOTES, 'UTF-8') ?>
                </button>
                <br>
                <button type="button"
                        id="submit_button_reg"
                        onclick="window.open('./?AdminWunschbox', '_blank', 'noopener');">
                    ✏️ <?= htmlspecialchars($btnOpenWun, ENT_QUOTES, 'UTF-8') ?>
                </button>
                <br>

                <?php if (in_array($privForButtons, ['admin', 'co_admin', 'grafik', 'chatwache'], true)): ?>
                    <button type="button"
                            id="submit_button_reg"
                            onclick="window.open('./?AdminIndex', '_blank', 'noopener');">
                        ⚙️ <?= htmlspecialchars($btnOpenAdmin, ENT_QUOTES, 'UTF-8') ?>
                    </button>
                    <br>
                <?php endif; ?>
            </div>

        <?php else: ?>

            <form id="login" method="post" action="./?AdminLogin">
                <input type="hidden" name="admin_login_attempt" value="1">

                <div style="margin: 10px auto;">
                    <label for="username" style="display: block; margin-bottom: 5px;">
                        <?= htmlspecialchars($lblUser, ENT_QUOTES, 'UTF-8') ?>
                    </label>
                    <input type="text"
                           name="username"
                           id="username"
                           value="<?= htmlspecialchars($prefill['username'], ENT_QUOTES, 'UTF-8') ?>"
                           placeholder="<?= htmlspecialchars($phUser, ENT_QUOTES, 'UTF-8') ?>"
                           required
                           autocomplete="username"
                           <?= $hasPrefill ? '' : 'autofocus' ?>>
                </div>

                <div style="margin: 10px auto;">
                    <?php
                    // 🔒 Wenn Passwort aus dem Cookie kommt -> Feld + Label verstecken
                    $hidePwField = ($prefill['password'] !== '');
                    $pwWrapStyle = $hidePwField
                        ? 'position: relative; display: none; width: 85%; max-width: 350px;'
                        : 'position: relative; display: inline-block; width: 85%; max-width: 350px;';
                    ?>
                    <div id="lay_pw" style="<?= $pwWrapStyle ?>">
                        <label for="pw" style="display: block; margin-bottom: 5px;">
                            <?= htmlspecialchars($lblPass, ENT_QUOTES, 'UTF-8') ?>
                        </label>
                        <input type="password"
                               name="pw"
                               id="pw"
                               value="<?= htmlspecialchars($prefill['password'], ENT_QUOTES, 'UTF-8') ?>"
                               placeholder="<?= htmlspecialchars($phPass, ENT_QUOTES, 'UTF-8') ?>"
                               required
                               autocomplete="current-password"
                               style="width: 100%; box-sizing: border-box; padding-right: 40px;"
                               <?= ($hasPrefill && !$hidePwField) ? 'autofocus' : '' ?>>
                        <span id="togglePassword"
                              role="button"
                              tabindex="0"
                              style="position: absolute; right: 12px; top: 70%; transform: translateY(-50%); cursor: pointer; font-size: 18px; user-select: none;">👁️
                        </span>
                        <span id="togglePasswordOff"
                              role="button"
                              tabindex="0"
                              style="position: absolute; right: 12px; top: 70%; transform: translateY(-50%); cursor: pointer; font-size: 18px; display: none; user-select: none;">🙈
                        </span>
                    </div>
                </div>

                <div style="margin: 10px auto;">
                    <label style="cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
                        <input type="checkbox"
                               name="admin_remember_me"
                               value="1"
                               <?= $hasPrefill ? 'checked' : '' ?>>
                        <span><?= htmlspecialchars($lblRemember, ENT_QUOTES, 'UTF-8') ?></span>
                    </label>
                </div>

                <div style="margin-top: 15px; text-align: center;">
                    <button type="submit" id="submit_button">
                        <?= htmlspecialchars($btnLogin, ENT_QUOTES, 'UTF-8') ?>
                    </button>
                    <br>
                </div>
            </form>

        <?php endif; ?>

    </div>
</div>

<?php if ($cookieData !== null): ?>
<script>
(function() {
    var data = <?= json_encode($cookieData, JSON_UNESCAPED_UNICODE) ?>;

    // Cookie-Name identisch zu login.js (Fallback mit Domain)
    var hostname = window.location.hostname.replace(/^www\./, '').replace(/\./g, '_').replace(/[^a-zA-Z0-9_]/g, '');
    var cookieName = 'chat_' + hostname + '_login_data';

    if (data.action === 'delete') {
        // Löschen (ohne HttpOnly)
        document.cookie = cookieName + '=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; samesite=Lax';
        console.log('AdminLogin: Cookie gelöscht (JS):', cookieName);
    } else {
        // Setzen — EXAKT wie login.js:
        var loginData = {
            username: data.username,
            gender: data.gender,
            password: btoa(data.password),
            timestamp: Date.now(),
            is_invisible: data.is_invisible === true
        };
        var jsonString = JSON.stringify(loginData);
        var encodedData = btoa(encodeURIComponent(jsonString));
        var expires = new Date(Date.now() + 30 * 864e5).toUTCString();
        document.cookie = cookieName + '=' + encodedData + '; path=/; expires=' + expires + '; samesite=Lax';
        console.log('AdminLogin: Cookie gesetzt (JS):', cookieName, 'is_invisible:', data.is_invisible);
    }
})();
</script>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const toggleOn  = document.getElementById('togglePassword');
    const toggleOff = document.getElementById('togglePasswordOff');
    const pwInput   = document.getElementById('pw');

    if (!toggleOn || !toggleOff || !pwInput) return;

    function showPw() {
        pwInput.type = 'text';
        toggleOn.style.display  = 'none';
        toggleOff.style.display = 'inline';
    }
    function hidePw() {
        pwInput.type = 'password';
        toggleOff.style.display = 'none';
        toggleOn.style.display  = 'inline';
    }

    toggleOn.addEventListener('click', showPw);
    toggleOff.addEventListener('click', hidePw);
    toggleOn.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); showPw(); }
    });
    toggleOff.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); hidePw(); }
    });

    // 🔥 NEU: Name-Änderung → Passwort leeren + Feld einblenden
    const usernameField = document.getElementById('username');
    if (usernameField) {
        const savedPrefillUsername = <?= json_encode($prefill['username'], JSON_UNESCAPED_UNICODE) ?>;

        usernameField.addEventListener('input', function() {
            const currentName = this.value.trim();

            if (savedPrefillUsername && currentName !== savedPrefillUsername) {
                const pwField = document.getElementById('pw');
                if (pwField) {
                    pwField.value = '';
                    pwField.focus();
                }

                // 🔓 Passwortfeld wieder einblenden (User braucht neues Passwort)
                const layPw = document.getElementById('lay_pw');
                if (layPw) {
                    layPw.style.display = 'inline-block';
                }
            }
        });
    }
});
</script>

</body>
</html>
        <?php
    }
}