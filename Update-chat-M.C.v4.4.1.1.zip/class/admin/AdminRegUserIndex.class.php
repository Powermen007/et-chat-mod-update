<?php

declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminRegUserIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private int $total = 0;
    private array $users = [];
    private array $onlineUserIds = [];
    private string $currentSort = 'login_new';
    private string $currentSearch = '';
    private int $currentPage = 1;
	private const PER_PAGE = 10;

    private array $allowedSorts = [
        'name'      => 'etchat_username ASC',
        'reg_new'   => 'etchat_reg_timestamp DESC',
        'reg_old'   => 'etchat_reg_timestamp ASC',
        'login_new' => 'etchat_logintime DESC',
        'login_old' => 'etchat_logintime ASC',
    ];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin Json
        // -------------------------
        $lang = new LangJson();

        // ROLE CHECK
        $allowedRoles = ["admin", "co_admin", "chatwache", "grafik"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Parameter laden
        $this->loadParams();

        // Gesamtanzahl laden
        $this->loadTotal();

        // User laden
        $this->loadUsers();

        // *** WICHTIG: Erst hier die Online-User holen, BEVOR die Verbindung geschlossen wird ***
        $this->loadOnlineUsers();

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    private function loadParams(): void
    {
        $this->currentSort = $_GET['sort'] ?? 'login_new';
        if (!isset($this->allowedSorts[$this->currentSort])) {
            $this->currentSort = 'login_new';
        }

        $this->currentSearch = trim($_GET['search'] ?? '');
        $this->currentPage = max(1, (int)($_GET['site'] ?? 1));
    }

	private function loadTotal(): void
	{
		$params = [];
		$searchSql = '';

		if ($this->currentSearch !== '') {
			$searchSql = "AND (etchat_username LIKE :search1
						OR etchat_email    LIKE :search2
						OR etchat_last_ip  LIKE :search3)";
			$like = '%' . $this->currentSearch . '%';
			$params[':search1'] = $like;
			$params[':search2'] = $like;
			$params[':search3'] = $like;
		}

		$sql = "SELECT COUNT(etchat_user_id) AS cnt 
				FROM {$this->_prefix}etchat_user 
				WHERE etchat_userprivilegien='user' $searchSql";

		$result = $this->dbObj->sqlGet($sql, $params);
		$this->total = (int)($result[0]['cnt'] ?? 0);
	}

	private function loadUsers(): void
	{
		$perPage = self::PER_PAGE;
		$offset  = ($this->currentPage - 1) * $perPage;

		$params = [];
		$searchSql = '';

		if ($this->currentSearch !== '') {
			$searchSql = "AND (etchat_username LIKE :search1
						OR etchat_email    LIKE :search2
						OR etchat_last_ip  LIKE :search3)";
			$like = '%' . $this->currentSearch . '%';
			$params[':search1'] = $like;
			$params[':search2'] = $like;
			$params[':search3'] = $like;
		}

		$orderBy = $this->allowedSorts[$this->currentSort];

		$sql = "SELECT etchat_user_id, etchat_username, etchat_userprivilegien,
						etchat_reg_timestamp, etchat_reg_ip,
						etchat_logintime, etchat_avatar,
						etchat_email, etchat_last_ip
				FROM {$this->_prefix}etchat_user
				WHERE etchat_userprivilegien='user'
				$searchSql
				ORDER BY $orderBy
				LIMIT {$offset}, {$perPage}";

		$result = $this->dbObj->sqlGet($sql, $params);
		$this->users = is_array($result) ? $result : [];
	}

    /**
     * Holt alle online User IDs aus der useronline Tabelle
     */
    private function loadOnlineUsers(): void
    {
        // Timeout für Online-Status (5 Minuten)
        $timeout = time() - 300;
        
        try {
            $result = $this->dbObj->sqlGet("
                SELECT DISTINCT etchat_onlineuser_fid 
                FROM {$this->_prefix}etchat_useronline 
                WHERE etchat_onlinetimestamp > ?
            ", [$timeout]);
            
            $this->onlineUserIds = [];
            foreach ($result as $row) {
                $this->onlineUserIds[] = (int)$row['etchat_onlineuser_fid'];
            }
        } catch (Exception $e) {
            // Falls die Abfrage fehlschlägt, leeres Array
            $this->onlineUserIds = [];
        }
    }

    private function renderTemplate($lang): void
    {
        $print_sort_form = $this->buildSortForm($lang);
        $print_sitemaker = $this->buildPagination($lang);
        $print_user_table = $this->buildUserTable($lang);
        $print_user_extra = $this->buildInactiveForm($lang);
        $total = $this->total;
        $csrfToken = $this->csrfToken;
        
        // Sprachtexte für JavaScript vorbereiten
        $lang_confirm_delete = $lang->get('admin_reguser_confirm_delete', 'Ausgewählte Benutzer wirklich löschen?');
        $lang_no_selected = $lang->get('admin_reguser_alert_no_selected', 'Keine Benutzer ausgewählt');
        $lang_mark_all = $lang->get('admin_reguser_mark_all', 'Alle markieren');
        $lang_unmark_all = $lang->get('admin_reguser_unmark_all', 'Alle abwählen');
        $lang_success_updated = $lang->get('admin_reguser_success_updated', 'Registrierter Benutzer wurde erfolgreich aktualisiert!');
        $lang_page_title = $lang->get('admin_reguser_page_title') . ' (' . (int)$total . ' ' . ($lang->get('admin_reguser_users', 'User')) . ')';
        $lang_footer_note = $lang->get('admin_reguser_footer_note', '');
        $lang_total_users = $lang->get('admin_reguser_total_users', 'Registrierte Benutzer');
        $lang_users = $lang->get('admin_reguser_users', 'User');
        $lang_hint_deleted = $lang->get('admin_reguser_hint_deleted', 'Wenn ein Benutzer gelöscht wird, wird der gelöschte Name wieder für den Gastzugang freigegeben.');
        $lang_delete_inactive_label = $lang->get('admin_reguser_delete_inactive_label', 'Inaktive Benutzer löschen (nicht online seit)');
        $lang_delete_inactive = $lang->get('admin_reguser_delete_inactive', 'Löschen');

        include "styles/admin_tpl/indexRegUser.tpl.html";
    }

    private function buildSortForm($lang): string
    {
        $sortOptions = [
            'name' => $lang->get('admin_reguser_sort_name', 'Name'),
            'reg_new' => $lang->get('admin_reguser_sort_reg_new', 'Registriert neu'),
            'reg_old' => $lang->get('admin_reguser_sort_reg_old', 'Registriert alt'),
            'login_new' => $lang->get('admin_reguser_sort_login_new', 'Login neu'),
            'login_old' => $lang->get('admin_reguser_sort_login_old', 'Login alt')
        ];

        $html = '<form method="get" action="./">
            <input type="hidden" name="AdminRegUserIndex" value="1">
            <label><b>' . ($lang->get('admin_reguser_sort_label', 'Sortieren')) . ':</b>
            <select name="sort" onchange="this.form.submit()">';

        foreach ($sortOptions as $key => $label) {
            $selected = ($this->currentSort === $key) ? 'selected' : '';
            $html .= "<option value=\"{$key}\" {$selected}>" . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . "</option>";
        }

        $searchEscaped = htmlspecialchars($this->currentSearch, ENT_QUOTES, 'UTF-8');

        $html .= '</select>
            <b>' . ($lang->get('admin_reguser_search_label', 'Suche')) . ':</b></label>
            <input type="text" name="search" value="' . $searchEscaped . '">
            <input type="submit" value="🔍 ' . ($lang->get('admin_reguser_search_button', 'Suchen')) . '">
            <button type="button" onclick="window.location.href=\'./?AdminRegUserIndex=1\'">🔄 ' . ($lang->get('admin_reguser_reset_button', 'Reset')) . '</button>
        </form>';

        return $html;
    }

	private function buildPagination($lang): string
	{
		$perPage = self::PER_PAGE;
		$totalPages = max(1, (int)ceil($this->total / $perPage));

		if ($totalPages <= 1) {
			return '';
		}

		$pageText = $lang->get('admin_reguser_page', 'Seite');
		$ofText = $lang->get('admin_reguser_of', 'von');
		$prevText = $lang->get('admin_reguser_prev', 'Vorherige');
		$nextText = $lang->get('admin_reguser_next', 'Nächste');

		$html = '<div class="pagination"><span>';
    
		if ($this->currentPage > 1) {
			$url = $this->buildPaginationUrl($this->currentPage - 1);
			$html .= '<a href="' . $url . '">« ' . $prevText . '</a>&nbsp;';
		}

		$html .= $pageText . '&nbsp;' . $this->currentPage . '&nbsp;' . $ofText . '&nbsp;' . $totalPages;

		if ($this->currentPage < $totalPages) {
			$url = $this->buildPaginationUrl($this->currentPage + 1);
			$html .= '&nbsp;<a href="' . $url . '">' . $nextText . ' »</a>';
		}

		$html .= '</span></div>';
		return $html;
	}

    private function buildPaginationUrl(int $page): string
    {
        $url = "./?AdminRegUserIndex&site={$page}";
        if ($this->currentSort !== 'login_new') {
            $url .= '&sort=' . urlencode($this->currentSort);
        }
        if ($this->currentSearch !== '') {
            $url .= '&search=' . urlencode($this->currentSearch);
        }
        return $url;
    }

    private function buildUserTable($lang): string
    {
        if (empty($this->users)) {
            return '<b>' . ($lang->get('admin_reguser_no_users', 'Keine Benutzer gefunden.')) . '</b>';
        }

        $html = '<form id="checkers" method="post" action="./?AdminRegUserEdit">
            <input type="hidden" name="csrf_token" value="' . htmlspecialchars($this->csrfToken, ENT_QUOTES, 'UTF-8') . '">
            <input type="hidden" id="userids" name="userids">

            <table border="1" cellpadding="5" cellspacing="0" class="user-table">
            <thead>
            <tr>
                <th></th>
                <th>' . ($lang->get('admin_reguser_th_username', 'Username')) . '</th>
                <th>' . ($lang->get('admin_reguser_th_reg_date', 'Reg. Datum')) . '</th>
                <th>' . ($lang->get('admin_reguser_th_reg_ip', 'IP während Reg.')) . '</th>
                <th>' . ($lang->get('admin_reguser_th_last_login', 'Letzter Login')) . '</th>
                <th>' . ($lang->get('admin_reguser_th_last_ip', 'Letzte IP')) . '</th>
                <th>' . ($lang->get('admin_reguser_th_email', 'E-Mail')) . '</th>
                <th>' . ($lang->get('admin_reguser_th_avatar', 'Avatar')) . '</th>
            </tr></thead><tbody>';

        foreach ($this->users as $user) {
            $id = (int)$user['etchat_user_id'];
            $name = htmlspecialchars($user['etchat_username'] ?? '', ENT_QUOTES, 'UTF-8', false);

            $reg = $this->formatTimestamp($user['etchat_reg_timestamp'] ?? null);
            $loginTs = (int)($user['etchat_logintime'] ?? 0);
            $loginDate = $loginTs ? date("d.m.Y H:i", $loginTs) : '-';

            $email = htmlspecialchars((string)($user['etchat_email'] ?? ''), ENT_QUOTES, 'UTF-8');
            $avatar = htmlspecialchars((string)($user['etchat_avatar'] ?? ''), ENT_QUOTES, 'UTF-8');
            $regIp = htmlspecialchars((string)($user['etchat_reg_ip'] ?? ''), ENT_QUOTES, 'UTF-8');
            $lastIp = htmlspecialchars((string)($user['etchat_last_ip'] ?? ''), ENT_QUOTES, 'UTF-8');

            // Status ermitteln (GENAU wie in AdminUserIndex)
            $isOnline = in_array($id, $this->onlineUserIds, true);
            $statusIndicator = $isOnline 
                ? '<span style="color: #00cc00;">●</span> <span style="color: #00cc00;">Online</span>'
                : '<span style="color: #cc0000;">●</span> <span>' . $loginDate . '</span>';
            
            $statusTooltip = $isOnline 
                ? 'Aktiv im Chat' 
                : 'Letzter Login: ' . $loginDate;

            $avatarDeleteLink = '<a href="./?AdminRegUserEdit&delavatar&csrf_token=' . urlencode($this->csrfToken) . '&id=' . $id . '"
                onclick="return confirm(\'' . ($lang->get('admin_reguser_confirm_delete_avatar', 'Avatar wirklich löschen?')) . '\')">' . ($lang->get('admin_reguser_delete_avatar', 'Löschen')) . '</a>';

            $html .= '<tr>
                <td><input type="checkbox" class="chk_user" value="' . $id . '"></td>
                <td><b><a href="./?AdminEditUserUser&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '">✏️ ' . $name . '</a></b></td>
                <td>' . $reg . '</td>
                <td>' . $regIp . '</td>
                <td title="' . $statusTooltip . '" style="white-space: nowrap;">' . $statusIndicator . '</td>
                <td>' . $lastIp . '</td>
                <td>' . $email . '</td>
                <td>' . $avatarDeleteLink . ' <img class="avatar_list_admin" src="avatar/' . $avatar . '" width="16" alt="avatar"></td>
            </tr>';
        }

        $html .= '</tbody>
            </table>
            </form>
            <br>
            <input type="button" value="' . ($lang->get('admin_reguser_mark_all', 'Alle markieren')) . '" id="mark_all_btn">
            &nbsp;
            <input type="button" value="' . ($lang->get('admin_reguser_delete_selected', 'Ausgewählte löschen')) . '" id="delete_selected_btn">';

        return $html;
    }

    private function formatTimestamp($timestamp): string
    {
        if (is_numeric($timestamp)) {
            return date("d.m.Y H:i:s", (int)$timestamp);
        }
        return (string)$timestamp;
    }

    private function buildInactiveForm($lang): string
    {
        $months = [
            3 => $lang->get('admin_reguser_inactive_3', '3 Monate'),
            6 => $lang->get('admin_reguser_inactive_6', '6 Monate'),
            12 => $lang->get('admin_reguser_inactive_12', '12 Monate'),
            18 => $lang->get('admin_reguser_inactive_18', '18 Monate'),
            24 => $lang->get('admin_reguser_inactive_24', '24 Monate')
        ];

        $html = '<form method="get" action="./">
            <input type="hidden" name="AdminRegUserEdit" value="1">
            <input type="hidden" name="deleteinactive" value="1">
            <input type="hidden" name="csrf_token" value="' . htmlspecialchars($this->csrfToken, ENT_QUOTES, 'UTF-8') . '">
            <select name="inactive_months">';

        foreach ($months as $value => $label) {
            $selected = ($value === 12) ? 'selected' : '';
            $html .= '<option value="' . $value . '" ' . $selected . '>' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</option>';
        }

        $html .= '</select>
            <input type="submit" value="' . ($lang->get('admin_reguser_delete_inactive', 'Löschen')) . '">
        </form>';

        return $html;
    }
}