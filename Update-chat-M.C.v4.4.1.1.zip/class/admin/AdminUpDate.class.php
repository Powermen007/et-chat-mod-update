<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminUpDate extends DbConectionMaker
{
    private string $moduleName = 'AdminUpDate';
    protected $db;
    protected $prefix;
    protected $dbname;

    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // NEU: Sprache laden - Admin Json
        // -------------------------
        $lang = new LangJson();

        $desei = $this->dbObj->sqlGet(
            "SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'"
        );

        $configFile = dirname(dirname(__DIR__)) . "/config.php";
        if (!file_exists($configFile)) {
            die($lang->get('admin_update_error_config', "FEHLER: config.php nicht gefunden!"));
        }
        include $configFile;

        $this->prefix = $prefix;
        $this->dbname = $database;

        try {
            $this->db = new PDO(
                "mysql:host={$sqlhost};dbname={$database};charset=utf8mb4",
                $sqluser,
                $sqlpass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
        } catch (PDOException $e) {
            die($lang->get('admin_update_error_db', "FEHLER: Datenbankverbindung: ") . $e->getMessage());
        }

        // Session starten (verbessert)
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        if ($_SESSION["etchat_" . $this->prefix . "user_priv"] !== "admin") {
            die($lang->get('admin_update_error_access', "Zugriff verweigert!"));
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $csrfToken = $_SESSION[$csrfKey];

        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $token = $_POST['csrf_token'] ?? '';
            if (!hash_equals($_SESSION['etchat_' . $this->prefix . 'csrf_token'], $token)) {
                die($lang->get('admin_update_error_csrf', 'CSRF Token ungültig!'));
            }

            $action = $_POST["action"] ?? "";

            switch ($action) {
                case "restore":
                    if (isset($_POST["file"])) {
                        // FIX: $lang an Position 3, $file an Position 4
                        $this->renderLoading(
                            $lang->get('admin_update_loading_message', "Update wird installiert... Bitte einen Moment Geduld."),
                            $lang->get('admin_update_loading_title', "Update Installation"),
                            $lang,
                            $_POST["file"]
                        );
                    }
                    break;

                case "delete":
                    if (isset($_POST["file"])) {
                        $this->deleteBackupFile($_POST["file"], $lang);
                    }
                    break;

                case "upload":
                    $this->handleUpload($lang);
                    break;
            }
            exit();
        }

        if (isset($_GET["action"])) {
            switch ($_GET["action"]) {
                case "restoreRun":
                    if (isset($_GET["file"])) {
                        $this->restoreBackup($_GET["file"], $lang);
                    }
                    break;
                case "downloadUpdate":
                    if (isset($_GET["version"])) {
                        $this->downloadUpdate($_GET["version"], $lang);
                    } else {
                        echo $lang->get('admin_update_error_no_version', "<span style='color:red;'>Keine Versionsnummer angegeben.</span>");
                    }
                    break;
            }
            exit();
        }

        $updateFiles = $this->getUpdateFiles();
        $this->renderTemplate($updateFiles, $lang);
    }

    // ========== METHODEN MIT SPRACHE ==========

    private function getAvailableUpdates($localVersion, $lang)
    {
        $updateIndexUrl = "https://powermen007.github.io/et-chat-mod-update/updates.json";
        $response = $this->fetchRemoteVersion($updateIndexUrl);

        if (!$response) {
            echo $lang->get('admin_update_error_load_list', "<span style='color:red;'>Fehler beim Laden der Update-Liste.</span><br>");
            return [];
        }

        $files = json_decode($response, true);
        if (!is_array($files)) {
            echo $lang->get('admin_update_error_invalid_list', "<span style='color:red;'>Update-Liste ist ungültig.</span><br>");
            return [];
        }

        $updates = [];

        foreach ($files as $file) {
            if (preg_match("/v(\d+\.\d+(?:\.\d+)?(?:\.\d+)?)/i", $file, $match)) {
                $version = $match[1];
                if (version_compare($version, $localVersion, ">")) {
                    $updates[] = [
                        "version" => $version,
                        "file" => $file,
                    ];
                }
            }
        }

        usort($updates, fn($a, $b) => version_compare($a["version"], $b["version"]));
        return $updates;
    }

    private function deleteBackupFile($filename, $lang)
    {
        $updateFolder = dirname(dirname(__DIR__)) . "/update";
        $filePath = $updateFolder . "/" . basename($filename);

        if (file_exists($filePath)) {
            unlink($filePath);
            header("Location: ?AdminUpDate");
            exit();
        } else {
            // FIX: $lang, []
            $this->renderResult($lang->get('admin_update_error_not_found', "Datei nicht gefunden"), $lang, []);
        }
    }

    private function restoreBackup($filename, $lang)
    {
        $updateFolder = dirname(dirname(__DIR__)) . "/update";
        $filePath = $updateFolder . "/" . basename($filename);

        if (!file_exists($filePath)) {
            // FIX: $lang, []
            $this->renderResult($lang->get('admin_update_error_file_not_found', "Chat Update-Datei nicht gefunden"), $lang, []);
            return;
        }

        $extension = pathinfo($filePath, PATHINFO_EXTENSION);

        if ($extension === "zip") {
            $result = $this->restoreFiles($filePath, $lang);
            $message = $lang->get('admin_update_success_completed', "Chat Update Fertiggestellt");
            if ($result['db']) {
                $message .= $lang->get('admin_update_success_db', " (inkl. Datenbankänderungen)");
            }
            // FIX: $message, $lang, $files
            $this->renderResult($message, $lang, $result['files']);
        } else {
            // FIX: $lang, []
            $this->renderResult($lang->get('admin_update_error_invalid_type', "Ungültiger Dateityp, nur ZIP-Dateien werden akzeptiert"), $lang, []);
        }
    }

    private function restoreFiles($zipFile, $lang)
    {
        $changedFiles = [];
        $dbChanged = false;

        $zip = new ZipArchive();
        if ($zip->open($zipFile) !== true) {
            // FIX: $lang, []
            $this->renderResult($lang->get('admin_update_error_zip_open', "Fehler beim Öffnen der ZIP-Datei: $zipFile"), $lang, []);
            return ['files' => [], 'db' => false];
        }

        $basePath = dirname(dirname(__DIR__));
        $sqlFilePath = null;

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            $targetPath = $basePath . "/" . $filename;

            if (substr($filename, -1) !== "/") {
                $changedFiles[] = $filename;
            }

            if (substr($filename, -1) === "/") {
                if (!is_dir($targetPath)) {
                    mkdir($targetPath, 0777, true);
                }
                continue;
            }

            if (strtolower($filename) === "install/mysql_db.sql") {
                $sqlFilePath = $targetPath;
                $dbChanged = true;
            }

            $dir = dirname($targetPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }

            $fileContent = $zip->getFromIndex($i);
            if ($fileContent !== false) {
                file_put_contents($targetPath, $fileContent);
            }
        }

        $zip->close();

        if ($sqlFilePath && file_exists($sqlFilePath)) {
            $this->importAdditionalSQL($sqlFilePath, $lang);
        }

        return [
            'files' => $changedFiles,
            'db' => $dbChanged
        ];
    }

    private function handleUpload($lang)
    {
        if (!isset($_FILES["update_file"])) {
            // FIX: $lang, []
            $this->renderResult($lang->get('admin_update_error_no_file', "Keine Datei hochgeladen"), $lang, []);
            return;
        }

        $uploadedFile = $_FILES["update_file"];
        $updateFolder = dirname(dirname(__DIR__)) . "/update";

        $extension = pathinfo($uploadedFile["name"], PATHINFO_EXTENSION);
        if (strtolower($extension) !== "zip") {
            // FIX: $lang, []
            $this->renderResult($lang->get('admin_update_error_invalid_ext', "Nur .zip Dateien erlaubt"), $lang, []);
            return;
        }

        $targetPath = $updateFolder . "/" . basename($uploadedFile["name"]);

        if (move_uploaded_file($uploadedFile["tmp_name"], $targetPath)) {
            header("Location: ?AdminUpDate");
            exit();
        } else {
            // FIX: $lang, []
            $this->renderResult($lang->get('admin_update_error_upload', "Fehler beim Hochladen"), $lang, []);
        }
    }

    private function checkForNewVersion($lang)
    {
        $localRaw = @file_get_contents(dirname(dirname(__DIR__)) . "/version.txt");
        $localVersion = $this->extractVersion($localRaw);

        if (!$localVersion || $localVersion === "0.0.0.0") {
            echo $lang->get('admin_update_error_local_version', "<span style='color: red;'>Lokale Version nicht erkennbar.</span><br>");
            return;
        }

        echo "<h3>" . ($lang->get('admin_update_status_title', "Update Status")) . "</h3>";
        echo "<strong>" . ($lang->get('admin_update_status_local', "Lokale Version")) . ":</strong> $localVersion<br>";

        if (isset($_GET["msg"]) && $_GET["msg"] === "download_ok") {
            $v = htmlspecialchars($_GET["downloaded_version"] ?? "");
            echo "<div style='color: green;'><strong>" . ($lang->get('admin_update_download_success', "Update-Version")) . " $v " . ($lang->get('admin_update_download_success_suffix', "erfolgreich heruntergeladen.")) . "</strong></div><br>";
        }

        $updates = $this->getAvailableUpdates($localVersion, $lang);

        if (empty($updates)) {
            echo $lang->get('admin_update_status_current', "<span style='color: green;'>Deine Version ist aktuell.</span>");
        } else {
            echo "<strong>" . ($lang->get('admin_update_available', "Verfügbare Updates")) . ":</strong><br>";
            foreach ($updates as $update) {
                $ver = $update["version"];
                echo "Version: <strong>$ver</strong> ";
                echo "<a href='?AdminUpDate&action=downloadUpdate&version=$ver'>" . ($lang->get('admin_update_download_link', "Herunterladen")) . "</a><br>";
            }
        }
    }

    private function extractVersion($text)
    {
        if (preg_match("/\b(\d+(?:\.\d+)+)\b/", (string)$text, $match)) {
            return $match[1];
        }
        return "0.0.0";
    }

    private function fetchRemoteVersion($url)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);
        curl_close($ch);

        return $response !== false ? $response : "";
    }

    private function downloadUpdate($version, $lang)
    {
        $remoteUrlBase = "https://powermen007.github.io/et-chat-mod-update/";
        $downloadDir = dirname(dirname(__DIR__)) . "/update";
        $filename = "Update-chat-M.C.v$version.zip";
        $downloadUrl = $remoteUrlBase . $filename;
        $destination = $downloadDir . "/" . $filename;

        if (!is_dir($downloadDir)) {
            mkdir($downloadDir, 0755, true);
        }

        $ch = curl_init($downloadUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $data = curl_exec($ch);

        if (curl_errno($ch)) {
            echo $lang->get('admin_update_error_download', "<span style='color: red;'>Fehler beim Herunterladen der Datei: ") . curl_error($ch) . "</span>";
            curl_close($ch);
            return;
        }

        curl_close($ch);

        if (file_put_contents($destination, $data)) {
            header("Location: ?AdminUpDate&msg=download_ok&downloaded_version=$version");
            exit();
        } else {
            echo $lang->get('admin_update_error_save', "<span style='color: red;'>Fehler beim Speichern der Datei.</span>");
            exit();
        }
    }

    private function renderTemplate(array $updateFiles, $lang): void
    {
        $tplPath = __DIR__ . '/../../styles/admin_tpl/indexUpdate.tpl.html';

        if (!file_exists($tplPath)) {
            die('Template nicht gefunden: ' . $tplPath);
        }

        $csrfToken = $_SESSION['etchat_' . $this->prefix . 'csrf_token'];
        include $tplPath;
    }

    private function getUpdateFiles(): array
    {
        $updateFolder = dirname(dirname(__DIR__)) . "/update";
        $result = [];

        if (is_dir($updateFolder)) {
            foreach (scandir($updateFolder, SCANDIR_SORT_DESCENDING) as $file) {
                if ($file === '.' || $file === '..') continue;

                $filePath = $updateFolder . '/' . $file;

                $result[] = [
                    'name' => $file,
                    'size' => filesize($filePath),
                    'date' => date('d.m.Y H:i', filemtime($filePath)),
                    'type' => pathinfo($filePath, PATHINFO_EXTENSION)
                ];
            }
        }

        return $result;
    }

    private function renderLoading(string $message, string $title, $lang, string $file = ''): void
    {
        $tplPath = __DIR__ . '/../../styles/admin_tpl/admin_loading_screen.tpl.html';

        if (!file_exists($tplPath)) {
            die('Template nicht gefunden: ' . $tplPath);
        }

        $prefix = $this->prefix;
        $csrfToken = $_SESSION['etchat_' . $this->prefix . 'csrf_token'];
        $action = 'restoreRun';
        $moduleName = $this->moduleName;
        $backLink = './?' . $moduleName;

        include $tplPath;
        exit();
    }

    private function renderResult(string $message, $lang, array $files = []): void
    {
        $tplPath = __DIR__ . '/../../styles/admin_tpl/createUpdate.tpl.html';

        if (!file_exists($tplPath)) {
            die('Template nicht gefunden: ' . $tplPath);
        }

        include $tplPath;
        exit();
    }

    // ============================================================
    // SQL-Import mit automatischer Spalten-Ergänzung
    // ============================================================
    private function importAdditionalSQL($sqlFile, $lang)
    {
        $sql = file_get_contents($sqlFile);
        if ($sql === false) {
            // FIX: $lang, []
            $this->renderResult(
                $lang->get('admin_update_error_sql_read', "Fehler beim Lesen von install/mysql_db.sql"),
                $lang,
                []
            );
            return;
        }

        $prefix = $this->prefix;

        // ###prefix### ersetzen
        $sql = str_replace('###prefix###', $prefix, $sql);

        // `etchat_...` nur nach FROM / INTO / UPDATE / TABLE / JOIN prefixen
        $sql = preg_replace_callback(
            '/\b(FROM|INTO|UPDATE|TABLE|JOIN)(\s+IF\s+NOT\s+EXISTS)?(\s+)`(etchat_[a-z0-9_]+)`/i',
            fn($m) => $m[1] . ($m[2] ?? '') . $m[3] . "`" . $prefix . $m[4] . "`",
            $sql
        );

        // Kommentare entfernen
        $sql = preg_replace('/^\s*--.*$/m', '', $sql);
        $sql = preg_replace('#/\*.*?\*/#s', '', $sql);

        $this->db->exec("SET FOREIGN_KEY_CHECKS = 0");

        $statements = array_filter(
            array_map('trim', explode(';', $sql)),
            fn($st) => $st !== ''
        );

        foreach ($statements as $statement) {
            try {
                // ---------- CREATE TABLE ----------
                if (preg_match('/^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`([^`]+)`\s*\((.*)\)\s*ENGINE/is', $statement, $m)) {
                    $table = $m[1];
                    $body  = $m[2];

                    $columns = $this->parseColumnsFromCreate($body);

                    $createStmt = preg_replace(
                        '/^CREATE\s+TABLE(?!\s+IF)/i',
                        'CREATE TABLE IF NOT EXISTS',
                        $statement
                    );
                    $this->db->exec($createStmt);

                    $added = $this->syncColumns($table, $columns);
                    if ($added) {
                        error_log("Update: Tabelle `$table` – Spalten ergänzt: " . implode(', ', $added));
                    }
                    continue;
                }

                // ---------- ALTER TABLE (robust) ----------
                if (preg_match('/^ALTER\s+TABLE\s+`([^`]+)`\s+(.*)$/is', $statement, $m)) {
                    $this->handleAlterTable($m[1], trim($m[2]));
                    continue;
                }

                // ---------- INSERT ----------
                if (preg_match('/^INSERT\s+(?:IGNORE\s+)?INTO/i', $statement)) {
                    if (!preg_match('/ON\s+DUPLICATE\s+KEY/i', $statement)) {
                        $statement = preg_replace(
                            '/^INSERT\s+(?:IGNORE\s+)?INTO/i',
                            'INSERT IGNORE INTO',
                            $statement
                        );
                    }
                }

                $this->db->exec($statement);

            } catch (PDOException $e) {
                error_log("SQL-Fehler: " . $e->getMessage() . " | Statement: " . substr($statement, 0, 200));
            }
        }

        $this->db->exec("SET FOREIGN_KEY_CHECKS = 1");
    }

    /**
     * Führt ein ALTER TABLE idempotent aus.
     * Zerlegt die Klauseln auf Top-Level-Kommas und führt nur aus, was noch fehlt.
     */
    private function handleAlterTable(string $table, string $body): void
    {
        // Existiert die Tabelle überhaupt?
        try {
            $this->db->query("SELECT 1 FROM `$table` LIMIT 1");
        } catch (PDOException $e) {
            error_log("ALTER TABLE `$table`: Tabelle existiert nicht – übersprungen.");
            return;
        }

        $existingCols = $this->getExistingColumns($table);
        $existingIdx  = $this->getExistingIndexes($table);

        $clauses = $this->splitTopLevelCommas($body);
        $needed  = [];

        foreach ($clauses as $clause) {
            $clause = trim($clause);
            if ($clause === '') continue;

            // ADD `col` <definition>   (nicht ADD INDEX/KEY/UNIQUE/PRIMARY/CONSTRAINT)
            if (preg_match('/^ADD\s+`([^`]+)`\s+(.+)$/is', $clause, $mm)) {
                if (!isset($existingCols[$mm[1]])) {
                    $needed[] = $clause;
                }
                continue;
            }

            // ADD INDEX/KEY/UNIQUE/FULLTEXT/SPATIAL `name` (...)
            if (preg_match('/^ADD\s+(?:UNIQUE\s+|FULLTEXT\s+|SPATIAL\s+)?(?:INDEX|KEY)\s+`?([^`\s(]+)`?/i', $clause, $mm)) {
                if (!isset($existingIdx[$mm[1]])) {
                    $needed[] = $clause;
                }
                continue;
            }

            // ADD PRIMARY KEY (...)
            if (preg_match('/^ADD\s+PRIMARY\s+KEY/i', $clause)) {
                if (!isset($existingIdx['PRIMARY'])) {
                    $needed[] = $clause;
                }
                continue;
            }

            // DROP `col`
            if (preg_match('/^DROP\s+`([^`]+)`/is', $clause, $mm)) {
                if (isset($existingCols[$mm[1]])) {
                    $needed[] = $clause;
                }
                continue;
            }

            // DROP INDEX/KEY `name`
            if (preg_match('/^DROP\s+(?:INDEX|KEY)\s+`?([^`\s]+)`?/i', $clause, $mm)) {
                if (isset($existingIdx[$mm[1]])) {
                    $needed[] = $clause;
                }
                continue;
            }

            // MODIFY `col` <definition>
            if (preg_match('/^MODIFY\s+`([^`]+)`/is', $clause, $mm)) {
                if (isset($existingCols[$mm[1]])) {
                    $needed[] = $clause;
                }
                continue;
            }

            // CHANGE `alt` `neu` <definition>
            if (preg_match('/^CHANGE\s+`([^`]+)`\s+`([^`]+)`/is', $clause, $mm)) {
                if (isset($existingCols[$mm[1]]) && !isset($existingCols[$mm[2]])) {
                    $needed[] = $clause;
                }
                continue;
            }

            // Alles andere (ADD CONSTRAINT, ENGINE, DEFAULT CHARSET, …) durchreichen
            $needed[] = $clause;
        }

        if (!empty($needed)) {
            $this->db->exec("ALTER TABLE `$table` " . implode(", ", $needed));
            error_log("ALTER TABLE `$table` ausgeführt: " . count($needed) . " Klausel(n)");
        }
    }

    private function getExistingColumns(string $table): array
    {
        $stmt = $this->db->query("SHOW COLUMNS FROM `$table`");
        $out  = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $out[$r['Field']] = $r;
        }
        return $out;
    }

    private function getExistingIndexes(string $table): array
    {
        $stmt = $this->db->query("SHOW INDEX FROM `$table`");
        $out  = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $out[$r['Key_name']] = true;
        }
        return $out;
    }

    /**
     * Zerlegt einen String auf Top-Level-Kommas (Klammern werden ignoriert).
     */
    private function splitTopLevelCommas(string $body): array
    {
        $parts = [];
        $buf   = '';
        $depth = 0;
        $len   = strlen($body);

        for ($i = 0; $i < $len; $i++) {
            $c = $body[$i];

            if ($c === '(') {
                $depth++;
            } elseif ($c === ')') {
                $depth--;
            }

            if ($c === ',' && $depth === 0) {
                $parts[] = trim($buf);
                $buf = '';
                continue;
            }
            $buf .= $c;
        }
        if (trim($buf) !== '') {
            $parts[] = trim($buf);
        }

        return $parts;
    }

    /**
     * Parst die Spalten aus dem Body eines CREATE TABLE-Statements.
     * Gibt ein Array [spaltenname => definition] zurück.
     * Indizes, Keys, Constraints werden ignoriert.
     */
    private function parseColumnsFromCreate(string $body): array
    {
        $columns = [];
        $lines = preg_split('/\r\n|\r|\n/', $body);

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line === ',') {
                continue;
            }
            $line = rtrim($line, ',');

            // Spaltendefinition: `name` definition…
            if (preg_match('/^`([^`]+)`\s+(.+)$/', $line, $m)) {
                $name = $m[1];

                // Keys/Indizes/Constraints aussortieren
                if (preg_match('/^(PRIMARY|UNIQUE|KEY|INDEX|CONSTRAINT|FULLTEXT|SPATIAL)$/i', $name)) {
                    continue;
                }

                $def = trim($m[2]);

                // Zeilen, die nur ein Index sind, haben keine Typdefinition – grobe Prüfung
                if (preg_match('/^(PRIMARY|UNIQUE|KEY|INDEX|CONSTRAINT|FULLTEXT|SPATIAL)\b/i', $def)) {
                    continue;
                }

                $columns[$name] = $def;
            }
        }

        return $columns;
    }

    /**
     * Vergleicht die Spalten aus der CREATE-Definition mit den vorhandenen Spalten
     * in der DB und ergänzt fehlende per ALTER TABLE ADD.
     *
     * @return array Liste der ergänzten Spaltennamen
     */
    private function syncColumns(string $table, array $columnsFromCreate): array
    {
        if (empty($columnsFromCreate)) {
            return [];
        }

        // Vorhandene Spalten holen
        try {
            $stmt = $this->db->prepare("SHOW COLUMNS FROM `$table`");
            $stmt->execute();
            $existing = [];
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $existing[$row['Field']] = true;
            }
        } catch (PDOException $e) {
            error_log("syncColumns: SHOW COLUMNS fehlgeschlagen für `$table`: " . $e->getMessage());
            return [];
        }

        $added = [];

        foreach ($columnsFromCreate as $colName => $colDef) {
            if (isset($existing[$colName])) {
                continue; // Spalte ist da
            }

            try {
                $sql = "ALTER TABLE `$table` ADD `$colName` $colDef";
                $this->db->exec($sql);
                $added[] = $colName;
            } catch (PDOException $e) {
                error_log("syncColumns: ADD `$colName` in `$table` fehlgeschlagen: " . $e->getMessage());
            }
        }

        return $added;
    }
}