<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Online extends DbConectionMaker
{
    private ?object $lang = null;

    /** @var array Erlaubte Domains aus cache/allowed_domains.txt */
    private array $allowedDomains = [];

    /** @var string Host des Referers (normalisiert, ohne www.) */
    private string $refererHost = '';

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function replacePlaceholders(string $text, array $placeholders): string
    {
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', (string)$value, $text);
        }
        return $text;
    }

    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // ===== MODERNE SPRACHE LADEN =====
        $this->lang = new LangJson();

        // ===== ZUGRIFFSPRÜFUNG (wie OnlineListe.class.php, KEIN Admin-Bypass) =====
        $this->loadAllowedDomains();
        $this->checkReferer();

        if (!$this->isDomainAllowed()) {
            // Zugriff verweigert - KEIN HTML, KEIN header(), nur stiller Abbruch
            // damit das umgebende Layout (index.tpl.html) nicht bricht.
            return;
        }

        // ===== AB HIER: BESTEHENDE LOGIK (unverändert) =====

        // Config abrufen
        $una = $this->dbObj->sqlGet(
            "SELECT etchat_config_name_user 
             FROM {$this->_prefix}etchat_config 
             WHERE etchat_config_id = :id",
            [':id' => 1]
        );

        // Online-Fenster berechnen
        $reloadSec = (int)($_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] ?? 5000) / 1000;
        $onlineWindow = max(30, (int)($reloadSec * 6));
        $minUnix = time() - $onlineWindow;
        $minDate = date('Y-m-d H:i:s', $minUnix);

        // Anzahl online User
        $erg = $this->dbObj->sqlGet(
            "SELECT COUNT(etchat_onlineid) as user_count
             FROM {$this->_prefix}etchat_useronline 
             WHERE (
                 etchat_onlinetimestamp > :minUnix
                 OR etchat_last_ping > :minDate
             )
             AND (etchat_user_online_user_status_img IS NULL 
                  OR etchat_user_online_user_status_img <> 'status_invisible')",
            [':minUnix' => $minUnix, ':minDate' => $minDate]
        );

        $userCount = $erg[0]['user_count'] ?? 0;

        // ===== MODERNISIERT: Online-Anzahl AUS Json =====
        $onlineText = $this->getText('online_users_count', '{count} User sind online.');
        $userText = $this->getText('online_user', 'User');
        $onlineText = $this->replacePlaceholders($onlineText, ['count' => $userCount]);

        // Fallback falls Platzhalter nicht ersetzt wurde
        if (strpos($onlineText, '{count}') !== false) {
            $onlineText = $userCount . ' ' . $userText . ' sind online.';
        }

        echo $onlineText . "<br />";

        // Limit aus Session
        $limit_users = (int) ($_SESSION['etchat_'.$this->_prefix.'name_user_anz'] ?? 10);

        // Letzte Login User abrufen
        $erg_user = $this->dbObj->sqlGet(
            "SELECT u.etchat_user_online_user_name, u.etchat_user_online_user_priv
             FROM {$this->_prefix}etchat_useronline u
             JOIN {$this->_prefix}etchat_user usr
               ON usr.etchat_username = u.etchat_user_online_user_name
             WHERE (
                 u.etchat_onlinetimestamp > :minUnix
                 OR u.etchat_last_ping > :minDate
             )
             AND (u.etchat_user_online_user_status_img IS NULL 
                  OR u.etchat_user_online_user_status_img <> 'status_invisible')
             ORDER BY usr.etchat_logintime DESC
             LIMIT $limit_users",
            [':minUnix' => $minUnix, ':minDate' => $minDate]
        );

        // User anzeigen, falls Config aktiviert
        if (($una[0]['etchat_config_name_user'] ?? 0) == 1 && is_array($erg_user) && count($erg_user) > 0) {
            $lastLoginsText = $this->getText('online_last_logins', 'Letzte Login (Top {limit}):');
            $lastLoginsText = $this->replacePlaceholders($lastLoginsText, ['limit' => $limit_users]);

            if (strpos($lastLoginsText, '{limit}') !== false) {
                $lastLoginsText = 'Letzte Login (Top ' . $limit_users . '):';
            }

            echo $lastLoginsText . "<br />";

            $anzahl = count($erg_user);
            foreach ($erg_user as $index => $us) {
                echo htmlspecialchars($us['etchat_user_online_user_name'] ?? '');
                if ($index < $anzahl - 1) {
                    echo ",&nbsp;";
                }
            }
            echo "<br />";
        }

        $this->dbObj->close();
    }

    /* =========================================================
     *  ZUGRIFFSPRÜFUNG (wie OnlineListe.class.php)
     * ========================================================= */

    private function loadAllowedDomains(): void
    {
        $file = null;
        $candidates = [
            __DIR__ . '/../cache/allowed_domains.txt',
            'cache/allowed_domains.txt',
            'allowed_domains.txt',
        ];

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                $file = $candidate;
                break;
            }
        }

        if ($file === null) {
            return;
        }

        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            return;
        }

        foreach ($lines as $line) {
            $line = trim($line);

            // Leerzeilen und Kommentarzeilen (# ...) überspringen
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $clean = preg_replace('/[^a-zA-Z0-9\.\-]/', '', $line);
            if ($clean !== '') {
                $this->allowedDomains[] = $this->normalizeHost($clean);
            }
        }
    }

    private function checkReferer(): void
    {
        // Echter Referer - nicht HTTP_HOST!
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        if (empty($referer)) {
            $this->refererHost = '';
            return;
        }
        $host = strtolower((string)parse_url($referer, PHP_URL_HOST));
        $this->refererHost = $this->normalizeHost($host);
    }

    private function isDomainAllowed(): bool
    {
        // 1) Kein Referer: nur erlaubt, wenn der Browser NICHT "cross-site" meldet
        //    (direkter Aufruf / Lesezeichen / neues Tab = "none" bzw. "same-origin").
        if (empty($this->refererHost)) {
            return ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') !== 'cross-site';
        }

        // 2) Referer-Host (bereits normalisiert)
        $refHost = $this->refererHost;

        // 3) Eigene Domain (HTTP_HOST, ohne Port) immer erlaubt
        $ownHost = preg_replace('/:\d+$/', '', $this->normalizeHost($_SERVER['HTTP_HOST'] ?? ''));
        if (!empty($ownHost) && $refHost === $ownHost) {
            return true;
        }

        // 4) Parent-Domain des Chats (chat.domaine-1.de -> domaine-1.de) immer erlaubt
        $parent = $this->getParentHost();
        if ($parent !== '' && $refHost === $parent) {
            return true;
        }

        // 5) In der Liste? (Subdomain-Regel: endet auf ".$allowed")
        foreach ($this->allowedDomains as $allowed) {
            if ($refHost === $allowed) {
                return true;
            }
            if (strlen($refHost) > strlen($allowed)
                && substr($refHost, -(strlen($allowed) + 1)) === '.' . $allowed) {
                return true;
            }
        }

        return false;
    }

    /**
     * Parent-Domain des eigenen Hosts: chat.domaine-1.de -> domaine-1.de
     * Leer bei IP, localhost, Hauptdomain oder Endungen wie co.uk.
     */
    private function getParentHost(): string
    {
        $own = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
        $own = preg_replace('/:\d+$/', '', $own);
        $own = preg_replace('/^www\./', '', $own);

        if ($own === '' || filter_var($own, FILTER_VALIDATE_IP) || substr_count($own, '.') < 2) {
            return '';
        }

        $parent = substr($own, strpos($own, '.') + 1);

        // Keine öffentlichen Endungen wie co.uk, com.au, org.br ...
        if (preg_match('/^(co|com|org|net|gov|edu|ac|or|ne|go|mil|nom|sch|ltd|plc)\.[a-z]{2}$/', $parent)) {
            return '';
        }

        return $parent;
    }

    /**
     * Entfernt "www." am Anfang und schreibt klein.
     * Damit gilt: www.pcip.de == pcip.de == chris.pcip.de (im Subdomain-Match).
     */
    private function normalizeHost(string $host): string
    {
        $host = strtolower($host);
        if (strpos($host, 'www.') === 0) {
            $host = substr($host, 4);
        }
        return $host;
    }
}

// Initialisieren
// new Online();