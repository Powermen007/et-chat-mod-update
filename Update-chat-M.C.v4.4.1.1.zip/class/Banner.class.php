<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

/*
 * iframe-Modus: wird über die URL gesteuert, z. B.  ./?Banner&iframe=true
 * Ohne den Parameter (oder mit iframe=false) läuft alles wie im Chat bisher.
 */
$bannerEmbed = (($_GET['iframe'] ?? '') === 'true');

/*
 * Hintergrundfarbe im iframe: &color=ff0000 (3 oder 6 Hex-Zeichen, ohne #).
 * Ungültig oder nicht angegeben = transparent.
 */
$bannerColor = 'transparent';
$colorParam  = ltrim((string)($_GET['color'] ?? ''), '#');
if (preg_match('/^(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $colorParam)) {
    $bannerColor = '#' . $colorParam;
}

class Banner extends DbConectionMaker
{
    /**
     * Popup-Muster – MUSS identisch sein mit AdminCreateNewMenu, Menu, MenuIndex.
     * Capture-Groups:
     *   [1] = Ziel-URL
     *   [2] = "width=...,height=..."
     */
    private const POPUP_REGEX =
        '~^window\.open\(\x27(https?://[a-zA-Z0-9\-._\x7E:/?#\[\]@!$&\x27()*+,;=%]+)\x27,\x27\x27,\x27\s*((?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4})(?:\s*,\s*(?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4}))*)\s*\x27\); return false;$~';

    /** true = Ausgabe als eigenständige Seite für einen iframe */
    private bool $embed;

    /** Hintergrundfarbe der iframe-Seite (nur Embed-Modus) */
    private string $bgColor;

    public function __construct(bool $embed = false, string $bgColor = 'transparent')
    {
        parent::__construct();
        $this->embed   = $embed;
        $this->bgColor = $bgColor;
    }

    public function render(): void
    {
        $rows = $this->dbObj->sqlGet("
            SELECT id, menu, link_text, image_active, image, url, target, gewicht
            FROM {$this->_prefix}etchat_menu
            WHERE menu = 3
            ORDER BY gewicht
        ");

        if (!is_array($rows) || empty($rows)) {
            return;
        }

        // Output Buffering für Performance
        ob_start();

        // -------------------------
        // Embed-Modus: Inline-Styles, kein externes CSS nötig.
        // Im Chat bleiben alle diese Werte leer, dort greift style.css wie bisher.
        // -------------------------
        $imgPath   = 'img/menu/';
        $boxStyle  = '';
        $imgStyle  = '';
        $textStyle = '';
        $linkStyle = '';

        if ($this->embed) {
            $boxStyle  = ' style="width:95%;height:80px;display:inline-block;overflow:hidden;border-radius:25px;margin:0 auto"';
            $imgStyle  = ' style="display:block;max-width:100%;height:80px;width:auto;margin:0 auto;object-fit:contain;border-radius:10px"';
            $textStyle = ' style="display:block;font:bold 32px/80px Arial,sans-serif;color:inherit"';
            $linkStyle = ' style="text-decoration:none;color:inherit"';

            echo '<!DOCTYPE html><html lang="de"><head><meta charset="utf-8">'
               . '<meta name="viewport" content="width=device-width, initial-scale=1">'
               . '<base target="_blank"></head>'
               . '<body style="margin:0;padding:0;background:' . $this->bgColor . ';text-align:center;overflow:hidden">';
        }

        echo '<div class="w3-content w3-display-container"' . $boxStyle . '>';

        foreach ($rows as $row) {

            $rawUrl      = (string)($row['url'] ?? '');
            $linkText    = htmlspecialchars((string)($row['link_text'] ?? ''), ENT_QUOTES, 'UTF-8');
            $imageActive = (int)($row['image_active'] ?? 0);
            $image       = htmlspecialchars((string)($row['image'] ?? ''), ENT_QUOTES, 'UTF-8');
            $rawTarget   = (string)($row['target'] ?? '_self');

            // -------------------------
            // Popup?
            // -------------------------
            $isPopup = ($rawUrl !== '') && preg_match(self::POPUP_REGEX, $rawUrl, $m);

            if ($isPopup) {
                $safeUrl  = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
                $features = htmlspecialchars($m[2], ENT_QUOTES, 'UTF-8');

                $hrefAttr    = ' href="' . $safeUrl . '"';
                $targetAttr  = '';
                $onclickAttr = ' onclick="window.open(\'' . $safeUrl . '\',\'\',\'' . $features . '\');return false;"';
            } else {
                $safeUrl     = htmlspecialchars($rawUrl !== '' ? $rawUrl : '#', ENT_QUOTES, 'UTF-8');

                $allowedTargets = ['', '_blank', '_self', '_parent', '_top'];
                $target         = in_array($rawTarget, $allowedTargets, true) ? $rawTarget : '_self';

                $hrefAttr    = ' href="' . $safeUrl . '"';
                $targetAttr  = ' target="' . htmlspecialchars($target, ENT_QUOTES, 'UTF-8') . '"';
                $onclickAttr = '';
            }

            // -------------------------
            // Ausgabe
            // -------------------------
            if ($imageActive === 1 && $image !== '') {

                echo '<a class="img_banner"' . $hrefAttr . $targetAttr . $onclickAttr . $linkStyle . '>';
                echo '<img class="mySlides"' . $imgStyle . ' src="' . $imgPath . $image . '" alt="' . $linkText . '" />';
                echo '</a>';

            } else {

                echo '<a' . $hrefAttr . $targetAttr . $onclickAttr . $linkStyle . '>';
                echo '<span class="mySlides banner-text"' . $textStyle . '>' . $linkText . '</span>';
                echo '</a>';
            }
        }

        echo '</div>';

        // JS
        echo <<<SCRIPT
<script>
let slideIndex = 0;
function carousel() {
    const slides = document.getElementsByClassName("mySlides");
    for (let i = 0; i < slides.length; i++) slides[i].style.display = "none";
    slideIndex++;
    if (slideIndex > slides.length) slideIndex = 1;
    if (slides.length > 0) slides[slideIndex-1].style.display = "block";
    setTimeout(carousel, 30000);
}
carousel();
</script>
SCRIPT;

        if ($this->embed) {
            echo '</body></html>';
        }

        // Flush buffer einmalig
        ob_end_flush();
    }
}

// Aufruf: im Chat wie bisher, mit ?iframe=true im Embed-Modus
if ($bannerEmbed) {
    // Optional: Einbetten nur auf bestimmten Domains erlauben
    // header("Content-Security-Policy: frame-ancestors 'self' https://FREMDE-DOMAIN.de");
    $banner = new Banner(true, $bannerColor);
} else {
    $banner = new Banner();
}
$banner->render();