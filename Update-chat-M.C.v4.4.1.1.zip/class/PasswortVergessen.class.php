<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';
require_once __DIR__ . '/../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * PasswortVergessen - deckt beide Modi ab:
 *   ?passwort=vergessen     -> Formular "Passwort vergessen" + Mail senden
 *   ?passwort=zuruecksetzen -> Token-Formular + neues Passwort setzen
 */
class PasswortVergessen extends DbConectionMaker
{
    private ?LangJson $lang = null;

    public function __construct()
    {
        parent::__construct();

        require_once __DIR__ . '/ZugriffsGuard.class.php';
        new ZugriffsGuard();

        try {
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }
    }

    public function run(): void
    {
        $this->handle();
        $this->render();
    }

    // ============================================================
    // HANDLE
    // ============================================================
    private function handle(): void
    {
        $mode = $_GET['passwort'] ?? 'vergessen';

        if ($mode === 'vergessen') {
            $this->handleForgot();
        } elseif ($mode === 'zuruecksetzen') {
            $this->handleReset();
        }
    }

    private function handleForgot(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $prefix   = $this->_prefix;
        $domain   = $this->getDomain();
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');

        if ($username === '') {
            $this->pvFail(
                $this->t('register_username_empty', 'Der Benutzername darf nicht leer sein.'),
                $_POST, $domain, '?passwort=vergessen'
            );
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->pvFail(
                $this->t('register_email_invalid', 'Ungültige E-Mail-Adresse.'),
                $_POST, $domain, '?passwort=vergessen'
            );
        }

        $rows = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_email
             FROM {$prefix}etchat_user
             WHERE etchat_username = ?
               AND etchat_email = ?
               AND etchat_userprivilegien != 'gast'",
            [$username, $email]
        );

        if (!$rows) {
            $this->pvFail(
                $this->t('register_user_not_found', 'Benutzername oder E-Mail-Adresse nicht gefunden.'),
                $_POST, $domain, '?passwort=vergessen'
            );
        }

        $user     = $rows[0];
        $email_db = $user['etchat_email'];
        $userId   = (int)$user['etchat_user_id'];
        $token    = bin2hex(random_bytes(32));
        $expiry   = date('Y-m-d H:i:s', strtotime('+15 minutes'));

        $this->dbObj->sqlSet(
            "UPDATE {$prefix}etchat_user
             SET etchat_reset_token = ?, etchat_reset_token_expiry = ?
             WHERE etchat_user_id = ?",
            [$token, $expiry, $userId]
        );

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $this->_mail_host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->_mail_sendemail;
            $mail->Password   = $this->_mail_pass;
            $mail->SMTPSecure = $this->_mail_smtpsecure;
            $mail->Port       = $this->_mail_port;
            $mail->CharSet    = 'UTF-8';
            $mail->Encoding   = 'base64';
            $mail->setFrom($this->_mail_sendemail, $this->t('register_password_reset_subject', 'Passwort vergessen'));
            $mail->addAddress($email_db, $username);
            $mail->isHTML(true);
            $mail->Subject = $this->t('register_password_reset_subject', 'Passwort zurücksetzen');

            $resetLink = $domain . '?passwort=zuruecksetzen&token=' . urlencode($token) . '&user=' . urlencode($username);
            $mail->Body = '<p>' . $this->t('register_hello', 'Hallo') . ' ' . $this->h($username) . ',</p>'
                        . '<p>' . $this->t('register_reset_link_text', 'Hier ist dein Link zum Ändern deines Passworts:') . '</p>'
                        . '<a href="' . $this->h($resetLink) . '">' . $this->h($resetLink) . '</a><br>'
                        . $this->t('register_reset_link_valid', 'Dieser Link ist 15 Minuten gültig.');

            $mail->send();

            $_SESSION['reg_success'] = $this->t('register_email_sent_php', 'E-Mail wurde versendet. Bitte überprüfe dein Postfach.');
            header('Location: ' . $domain);
            exit();

        } catch (Exception $e) {
            $this->pvFail(
                $this->t('register_email_error', 'E-Mail konnte nicht gesendet werden:') . ' ' . $mail->ErrorInfo,
                $_POST, $domain, '?passwort=vergessen'
            );
        }
    }

    private function handleReset(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $prefix      = $this->_prefix;
        $domain      = $this->getDomain();
        $token       = $_POST['token'] ?? '';
        $newPassword = $_POST['password'] ?? '';

        if (!$this->isPasswordStrongEnough($newPassword)) {
            $this->pvFail(
                $this->t('register_password_weak', 'Fehler: Passwort muss mind. 8 Zeichen lang sein und 3 der Kriterien enthalten.'),
                $_POST, $domain,
                '?passwort=zuruecksetzen&token=' . urlencode($token) . '&user=' . urlencode($_GET['user'] ?? '')
            );
        }

        $rows = $this->dbObj->sqlGet(
            "SELECT etchat_user_id
             FROM {$prefix}etchat_user
             WHERE etchat_reset_token = ?
               AND etchat_reset_token_expiry > NOW()",
            [$token]
        );

        if ($rows) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $this->dbObj->sqlSet(
                "UPDATE {$prefix}etchat_user
                 SET etchat_userpw = ?,
                     etchat_reset_token = NULL,
                     etchat_reset_token_expiry = NULL
                 WHERE etchat_user_id = ?",
                [$hashedPassword, (int)$rows[0]['etchat_user_id']]
            );

            $_SESSION['reg_success'] = $this->t('register_password_reset_success', 'Passwort zurückgesetzt.');
            header('Location: ' . $domain);
            exit();
        }

        $_SESSION['reg_success'] = $this->t('register_token_invalid', 'Ungültiger Token oder Token abgelaufen.');
        header('Location: ' . $domain);
        exit();
    }

    // ============================================================
    // RENDER
    // ============================================================
    private function render(): void
    {
        $mode = $_GET['passwort'] ?? 'vergessen';
        $regError = $this->pvPullError();
        $regOld   = $this->pvPullOld();

        echo $this->styleCss();

        if ($mode === 'zuruecksetzen') {
            $this->renderReset($regError, $regOld);
        } else {
            $this->renderForgot($regError, $regOld);
        }
    }

    private function renderForgot(string $regError, array $regOld): void
    {
        ?>
        <h2><?php echo $this->h($this->t('register_forgot_password_title', 'Passwort vergessen')); ?></h2>
        <?php if ($regError !== ''): ?>
            <div class="reg-error"><?php echo $this->h($regError); ?></div>
        <?php endif; ?>
        <form class="reg-form" method="POST">
            <input name="username" id="username"
                   value="<?php echo $this->h($regOld['username'] ?? ''); ?>"
                   placeholder="<?php echo $this->h($this->t('login_name', 'Dein Chatname')); ?>" required /><br>
            <input name="email" id="email"
                   value="<?php echo $this->h($regOld['email'] ?? ''); ?>"
                   placeholder="<?php echo $this->h($this->t('register_email_placeholder', 'E-Mail-Adresse')); ?>"
                   type="email" required /><br>
            <button type="submit" class="submit_button"><?php echo $this->h($this->t('register_change_password', 'Passwort ändern')); ?></button>
            <button type="button" class="submit_button-secondary" onclick="window.location.href='?email_aendern=1'"><?php echo $this->h($this->t('email_change', 'E-Mail ändern')); ?></button>
            <button type="button" class="submit_button-secondary" onclick="window.location.href='<?php echo $this->h($this->getDomain()); ?>'"><?php echo $this->h($this->t('register_back_to_login', 'Zurück zum Login')); ?></button>
        </form>
        <?php
    }

    private function renderReset(string $regError, array $regOld): void
    {
        $tokenFromOld = $regOld['token'] ?? ($_GET['token'] ?? '');
        ?>
        <h2><?php echo $this->h($this->t('register_reset_password_title', 'Passwort zurücksetzen')); ?></h2>
        <?php if ($regError !== ''): ?>
            <div class="reg-error"><?php echo $this->h($regError); ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['user'])): ?>
            <p style="text-align: center; color: red; font-weight: bold;"><?php echo $this->h($this->t('register_user_label', 'Benutzer:')); ?> <?php echo $this->h((string)$_GET['user']); ?></p>
        <?php endif; ?>
        <form class="reg-form" method="POST">
            <input type="hidden" name="token" value="<?php echo $this->h($tokenFromOld); ?>" />
            <p style="text-align: center;margin-top: 0px;"><?php echo $this->h($this->t('register_password_requirements', 'Das Passwort muss mindestens 8 Zeichen lang sein und 3 der folgenden Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.')); ?></p>
            <input name="password" id="password" placeholder="<?php echo $this->h($this->t('register_new_password', 'Neues Passwort')); ?>" required type="password" />
            <small id="pw_strength" style="color: red;"></small><br>
            <input id="confirm_password" name="confirm_password" placeholder="<?php echo $this->h($this->t('register_confirm_password', 'Passwort wiederholen')); ?>" type="password" required />
            <small id="pwcheck" style="display:none;"><?php echo $this->h($this->t('register_password_mismatch', 'Die Passwörter stimmen nicht überein.')); ?></small>
            <p style="text-align: center;margin-top: 0px;margin-bottom: 0px;"><input type="checkbox" onclick="machText(this.checked,this.form)"><?php echo $this->h($this->t('register_show_password', 'Passwort anzeigen')); ?></p>
            <button type="submit" class="submit_button"><?php echo $this->h($this->t('register_save_password', 'Neues Passwort speichern')); ?></button>
            <button type="button" class="submit_button-secondary" onclick="window.location.href='<?php echo $this->h($this->getDomain()); ?>'"><?php echo $this->h($this->t('register_back_to_login', 'Zurück zum Login')); ?></button>
        </form>
        <?php
    }

    // ============================================================
    // PRIVATE HELFER
    // ============================================================
    private function t(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function h(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    }

    private function getDomain(): string
    {
        $protocol  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host      = $_SERVER['SERVER_NAME'] ?? 'localhost';
        $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\');
        return $protocol . '://' . $host . ($scriptDir !== '' && $scriptDir !== '/' ? $scriptDir : '') . '/';
    }

    private function pvFail(string $error, array $old, string $domain, string $target): void
    {
        $_SESSION['pv_error'] = $error;
        $_SESSION['pv_old']   = $old;
        header('Location: ' . $domain . $target);
        exit();
    }

    private function pvPullError(): string
    {
        $e = $_SESSION['pv_error'] ?? '';
        unset($_SESSION['pv_error']);
        return (string)$e;
    }

    private function pvPullOld(): array
    {
        $o = $_SESSION['pv_old'] ?? [];
        unset($_SESSION['pv_old']);
        return is_array($o) ? $o : [];
    }

    private function isPasswordStrongEnough(string $password): bool
    {
        $criteriaMet  = (int)preg_match('/[A-Z]/', $password);
        $criteriaMet += (int)preg_match('/[a-z]/', $password);
        $criteriaMet += (int)preg_match('/[0-9]/', $password);
        $criteriaMet += (int)preg_match('/[\W_]/', $password);
        return strlen($password) >= 8 && $criteriaMet >= 3;
    }

    private function styleCss(): string
    {
        return '
<style>
input, label, button, small { margin-bottom: 15px; }
small { font-size: 11px; color: red; }
.reg-error {
    color: red; background: #ffeeee; padding: 10px; border-radius: 5px;
    margin: 10px auto; text-align: center; font-weight: bold; max-width: 600px;
}
.reg-success {
    color: green; background: #eeffee; padding: 10px; border-radius: 5px;
    margin: 10px auto; text-align: center; font-weight: bold; max-width: 600px;
}
</style>';
    }
}