<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class OnlineListe extends DbConectionMaker
{
    private ?object $lang = null;

    /** @var array Erlaubte Domains aus cache/onlineliste.txt */
    private array $allowedDomains = [];

    /** @var string Host des Referers (normalisiert, ohne www.) */
    private string $refererHost = '';

    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // ===== SESSION SICHERSTELLEN (wie IndexBox: http UND https) =====
        if (session_status() !== PHP_SESSION_ACTIVE) {
            $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'secure'   => $isHttps,
                'httponly' => true,
                'samesite' => $isHttps ? 'None' : 'Lax',
            ]);
            session_start();
        }

        // ===== MODERNE SPRACHE LADEN =====
        $this->lang = new LangJson();

        // ===== ZUGRIFFSPRÜFUNG (wie IndexBox, KEIN Admin-Bypass) =====
        $this->loadAllowedDomains();
        $this->checkReferer();

        if (!$this->isDomainAllowed()) {
            $this->renderAccessDenied();
            return;
        }

        // Browser selbst das Einbetten auf fremden Domains verbieten lassen
        $this->sendFrameHeaders();

        // ===== KOMPLETTE SEITE AUSGEBEN =====
        $this->renderPage();

        $this->dbObj->close();
    }

    /* =========================================================
     *  TEXT-HELFER
     * ========================================================= */

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function replacePlaceholders(string $text, array $placeholders): string
    {
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', (string)$value, $text);
        }
        return $text;
    }

    /* =========================================================
     *  ZUGRIFFSPRÜFUNG
     * ========================================================= */

    private function loadAllowedDomains(): void
    {
        $file = null;
        $candidates = [
            __DIR__ . '/../cache/onlineliste.txt',
            'cache/onlineliste.txt',
            'onlineliste.txt',
        ];

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                $file = $candidate;
                break;
            }
        }

        if ($file === null) {
            return;
        }

        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            return;
        }

        foreach ($lines as $line) {
            $line = trim($line);

            // Leerzeilen und Kommentarzeilen (# ...) überspringen
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $clean = preg_replace('/[^a-zA-Z0-9\.\-]/', '', $line);
            if ($clean !== '') {
                $this->allowedDomains[] = $this->normalizeHost($clean);
            }
        }
    }

    private function checkReferer(): void
    {
        // Echter Referer - nicht HTTP_HOST!
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        if (empty($referer)) {
            $this->refererHost = '';
            return;
        }
        $host = strtolower((string)parse_url($referer, PHP_URL_HOST));
        $this->refererHost = $this->normalizeHost($host);
    }

    /**
     * Entfernt "www." am Anfang und schreibt klein.
     * Damit gilt: www.pcip.de == pcip.de == chris.pcip.de (im Subdomain-Match).
     */
    private function normalizeHost(string $host): string
    {
        $host = strtolower($host);
        if (strpos($host, 'www.') === 0) {
            $host = substr($host, 4);
        }
        return $host;
    }

/**
 * Parent-Domain des eigenen Hosts: chat.domaine-1.de -> domaine-1.de
 * Leer bei IP, localhost, Hauptdomain oder Endungen wie co.uk.
 */
private function getParentHost(): string
{
    $own = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $own = preg_replace('/:\d+$/', '', $own);
    $own = preg_replace('/^www\./', '', $own);

    if ($own === '' || filter_var($own, FILTER_VALIDATE_IP) || substr_count($own, '.') < 2) {
        return '';
    }

    $parent = substr($own, strpos($own, '.') + 1);

    // Keine öffentlichen Endungen wie co.uk, com.au, org.br ...
    if (preg_match('/^(co|com|org|net|gov|edu|ac|or|ne|go|mil|nom|sch|ltd|plc)\.[a-z]{2}$/', $parent)) {
        return '';
    }

    return $parent;
}

private function isDomainAllowed(): bool
{
    if (empty($this->refererHost)) {
        return ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') !== 'cross-site';
    }

    $refHost = $this->refererHost;

    // Eigene Domain (ohne Port) immer erlaubt
    $ownHost = preg_replace('/:\d+$/', '', $this->normalizeHost($_SERVER['HTTP_HOST'] ?? ''));
    if (!empty($ownHost) && $refHost === $ownHost) {
        return true;
    }

    // Parent-Domain des Chats immer erlaubt
    $parent = $this->getParentHost();
    if ($parent !== '' && $refHost === $parent) {
        return true;
    }

    foreach ($this->allowedDomains as $allowed) {
        if ($refHost === $allowed) {
            return true;
        }
        if (strlen($refHost) > strlen($allowed)
            && substr($refHost, -(strlen($allowed) + 1)) === '.' . $allowed) {
            return true;
        }
    }

    return false;
}

private function sendFrameHeaders(): void
{
    if (headers_sent()) {
        return;
    }

    $ancestors = ["'self'"];

    $parent = $this->getParentHost();
    if ($parent !== '') {
        foreach (['https', 'http'] as $scheme) {
            $ancestors[] = "{$scheme}://{$parent}";
            $ancestors[] = "{$scheme}://www.{$parent}";
        }
    }

    foreach ($this->allowedDomains as $domain) {
        $ancestors[] = "https://{$domain}";
        $ancestors[] = "https://*.{$domain}";
        $ancestors[] = "http://{$domain}";
        $ancestors[] = "http://*.{$domain}";
    }

    header('Content-Security-Policy: frame-ancestors ' . implode(' ', $ancestors));
}

    /* =========================================================
     *  KOMPLETTE SEITE AUSGEBEN
     * ========================================================= */

    private function renderPage(): void
    {
        // ===== STYLE AUS DB LADEN (wie Info.class.php) =====
        $config = $this->dbObj->sqlGet("
            SELECT etchat_config_style
            FROM {$this->_prefix}etchat_config
            LIMIT 1
        ") ?: [];

        $style = $config[0]['etchat_config_style'] ?? 'default';

        $title = $this->getText('online_page_title', 'Online-Liste');

        // ===== AUTO-REFRESH-INTERVALL (30 Sekunden) =====
        $refreshSec = 30;

        ?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<title><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></title>
<link href="styles/<?php echo htmlspecialchars($style, ENT_QUOTES, 'UTF-8'); ?>/style.css" rel="stylesheet" type="text/css"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<style>
    html, body {
        margin: 0;
        padding: 0;
        overflow: hidden;
    }
    #online_wrapper {
        padding: 6px;
    }
    .online_user_card {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 3px 8px;
        border: 1px solid var(--color-border);
        border-radius: 25px;
        background-color: var(--color-button-zeilen);
        margin: 2px;
        transition: background-color 0.2s ease;
    }
    .online_user_card:hover {
        background-color: var(--color-button-hover);
    }
    .online_user_card .online_user_name {
        white-space: nowrap;
    }
    .online_empty {
        text-align: center;
        font-style: italic;
        opacity: 0.75;
        padding: 8px;
    }
</style>
</head>
<body id="body">
<div id="online_wrapper">
<?php
        $this->renderOnlineList();
?>
</div>
<script>
(function () {
    // ---- Höhe an Parent melden ----
    function sendHeight() {
        if (window.parent && window.parent.postMessage) {
            var el = document.getElementById('online_wrapper');
            if (el) {
                var h = el.getBoundingClientRect().height + 12;
                window.parent.postMessage({ 'etchat_online_height': h }, '*');
            }
        }
    }
    window.addEventListener('DOMContentLoaded', sendHeight);
    window.addEventListener('load', sendHeight);
    setTimeout(sendHeight, 300);

    // ---- Auto-Refresh der Online-Liste (alle 30 Sekunden) ----
    var REFRESH_SEC = <?php echo (int)$refreshSec; ?>;

    function refreshList() {
        // Wenn Tab im Hintergrund -> NICHT abrufen, aber Timer weiterlaufen lassen.
        // Sobald der Tab wieder sichtbar wird, holt der visibilitychange-Handler
        // unten sofort die aktuelle Liste nach.
        if (document.hidden) {
            setTimeout(refreshList, REFRESH_SEC * 1000);
            return;
        }

        var url = window.location.pathname + '?OnlineListe&_t=' + Date.now();

        fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.text(); })
            .then(function (html) {
                var parser = new DOMParser();
                var doc = parser.parseFromString(html, 'text/html');
                var newContent = doc.getElementById('online_wrapper');
                var oldContent = document.getElementById('online_wrapper');
                if (newContent && oldContent) {
                    oldContent.innerHTML = newContent.innerHTML;
                    sendHeight();
                }
                setTimeout(refreshList, REFRESH_SEC * 1000);
            })
            .catch(function () {
                setTimeout(refreshList, REFRESH_SEC * 1000);
            });
    }

    // Erster Refresh nach 30 Sekunden
    setTimeout(refreshList, REFRESH_SEC * 1000);

    // ---- Wenn der Tab wieder in den Vordergrund kommt: sofort aktualisieren ----
    // Das gleicht die Zeit aus, die im Hintergrund "verpasst" wurde.
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) {
            // direkt einmal refreshen, ohne den regulären Timer abzuwarten
            var url = window.location.pathname + '?OnlineListe&_t=' + Date.now();
            fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.text(); })
                .then(function (html) {
                    var parser = new DOMParser();
                    var doc = parser.parseFromString(html, 'text/html');
                    var newContent = doc.getElementById('online_wrapper');
                    var oldContent = document.getElementById('online_wrapper');
                    if (newContent && oldContent) {
                        oldContent.innerHTML = newContent.innerHTML;
                        sendHeight();
                    }
                })
                .catch(function () { /* stiller Fehler */ });
        }
    });
})();
</script>
</body>
</html>
<?php
    }

    /* =========================================================
     *  ONLINE-LISTE AUSGEBEN (nutzt System-Style)
     * ========================================================= */

    private function renderOnlineList(): void
    {
        // Online-Fenster berechnen
        $reloadSec = (int)($_SESSION['etchat_' . $this->_prefix . 'config_reloadsequenz'] ?? 5000) / 1000;
        $onlineWindow = max(30, (int)($reloadSec * 6));
        $minUnix = time() - $onlineWindow;
        $minDate = date('Y-m-d H:i:s', $minUnix);

        $limitUsers = (int)($_SESSION['etchat_' . $this->_prefix . 'name_user_anz'] ?? 10);

        // ---- Anzahl online User ----
        $countRow = $this->dbObj->sqlGet(
            "SELECT COUNT(etchat_onlineid) as user_count
             FROM {$this->_prefix}etchat_useronline
             WHERE (
                 etchat_onlinetimestamp > :minUnix
                 OR etchat_last_ping > :minDate
             )
             AND (etchat_user_online_user_status_img IS NULL
                  OR etchat_user_online_user_status_img <> 'status_invisible')",
            [':minUnix' => $minUnix, ':minDate' => $minDate]
        );

        $userCount = (int)($countRow[0]['user_count'] ?? 0);

        // ---- Überschrift "X User sind online" ----
        $onlineText = $this->getText('online_users_count', '{count} User sind online.');
        $onlineText = $this->replacePlaceholders($onlineText, ['count' => $userCount]);
        if (strpos($onlineText, '{count}') !== false) {
            $onlineText = $userCount . ' User sind online.';
        }

        echo '<div class="user-online-title" style="width:95%;margin:0 auto 8px auto;padding:4px 8px;">'
           . htmlspecialchars($onlineText, ENT_QUOTES, 'UTF-8')
           . '</div>' . "\n";

        // ---- Konfiguration: Namen anzeigen? ----
        $config2 = $this->dbObj->sqlGet(
            "SELECT etchat_config_name_user
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = :id",
            [':id' => 1]
        );
        $showNames = ((int)($config2[0]['etchat_config_name_user'] ?? 0) === 1);

        if (!$showNames) {
            return;
        }

        // ---- Letzte Login User abrufen ----
        $users = $this->dbObj->sqlGet(
            "SELECT u.etchat_user_online_user_name,
                    usr.etchat_logintime
             FROM {$this->_prefix}etchat_useronline u
             JOIN {$this->_prefix}etchat_user usr
               ON usr.etchat_username = u.etchat_user_online_user_name
             WHERE (
                 u.etchat_onlinetimestamp > :minUnix
                 OR u.etchat_last_ping > :minDate
             )
             AND (u.etchat_user_online_user_status_img IS NULL
                  OR u.etchat_user_online_user_status_img <> 'status_invisible')
             ORDER BY usr.etchat_logintime DESC
             LIMIT $limitUsers",
            [':minUnix' => $minUnix, ':minDate' => $minDate]
        );

        // ---- Unterzeile "Letzte Login (Top X):" ----
        $lastLoginsText = $this->getText('online_last_logins', 'Letzte Login (Top {limit}):');
        $lastLoginsText = $this->replacePlaceholders($lastLoginsText, ['limit' => $limitUsers]);
        if (strpos($lastLoginsText, '{limit}') !== false) {
            $lastLoginsText = 'Letzte Login (Top ' . $limitUsers . '):';
        }

        echo '<div class="compact-users-container">' . "\n";

        echo '<div style="margin-bottom:6px;font-weight:bold;">'
           . htmlspecialchars($lastLoginsText, ENT_QUOTES, 'UTF-8')
           . '</div>' . "\n";

        // Leere Liste
        if (!is_array($users) || count($users) === 0) {
            $emptyText = $this->getText('online_no_users', 'Zurzeit ist niemand online.');
            echo '<div class="online_empty">'
               . htmlspecialchars($emptyText, ENT_QUOTES, 'UTF-8')
               . '</div>' . "\n";
            echo '</div>' . "\n";
            return;
        }

        echo '<div class="compact-user-row">' . "\n";

        foreach ($users as $us) {
            $name = $us['etchat_user_online_user_name'] ?? '';
            if ($name === '') {
                continue;
            }

            $nameSafe = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');

            echo '<span class="online_user_card">'
               . '<span class="online_user_name">' . $nameSafe . '</span>'
               . '</span>' . "\n";
        }

        echo '</div>' . "\n"; // .compact-user-row
        echo '</div>' . "\n"; // .compact-users-container
    }

    /* =========================================================
     *  ZUGRIFF VERWEIGERT
     * ========================================================= */

    private function renderAccessDenied(): void
    {
        header('Content-Type: text/html; charset=utf-8');

        $host      = htmlspecialchars($this->refererHost, ENT_QUOTES, 'UTF-8');
        $title     = $this->getText('online_access_denied_title', 'Zugriff verweigert für');
        $subtitle  = $this->getText('online_access_denied_subtitle', '(Online Liste)');
        $text      = $this->getText('online_access_denied_text', 'Die Domain');
        $notAuth   = $this->getText('online_access_denied_not_authorized', 'ist nicht autorisiert');

        die("<!DOCTYPE html>
<html lang=\"de\">
<head>
<meta charset=\"utf-8\">
<title>" . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "</title>
</head>
<body style='background:#000; color:#f00; margin:0; padding:15px; font-family:Arial; overflow:hidden; box-sizing:border-box;'>
<div id='err_box' style='max-width:550px; margin:0 auto; padding:15px; border:0px solid rgba(255,0,0,0.4); background:rgba(255,0,0,0.05); text-align:center;'>
<h3 style='margin:0;'>" . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "</h3>
<p style='margin:20px 0;'><b>" . htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8') . "</b><br><br>" . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . "<br><br><b>\"$host\"</b><br><br>" . htmlspecialchars($notAuth, ENT_QUOTES, 'UTF-8') . "</p>
</div>
<script>
function sendErrorHeight() {
    if (window.parent && window.parent.postMessage) {
        var box = document.getElementById('err_box');
        if (box) {
            var h = box.getBoundingClientRect().height + 30;
            window.parent.postMessage({ 'etchat_online_height': h }, '*');
        }
    }
}
window.addEventListener('DOMContentLoaded', sendErrorHeight);
window.addEventListener('load', sendErrorHeight);
</script>
</body>
</html>");
    }
}