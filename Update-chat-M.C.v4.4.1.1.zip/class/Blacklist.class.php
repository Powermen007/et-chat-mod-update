<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Blacklist extends EtChatConfig
{
    private const TEAM_ROLES = [
        "admin",
        "mod",
        "chatwache",
        "co_admin",
        "grafik",
    ];
    private $dbObj;
    public $user_param_all;
    public $user_bann_time = 0;

    public function __construct($dbObj)
    {
        parent::__construct();

        $this->dbObj = $dbObj;

        $ip = $_SERVER["REMOTE_ADDR"] ?? "0.0.0.0";

        // ============================================================
        // 🔥 PERFORMANCE: Reverse-DNS-Lookup cachen
        // gethostbyaddr() kann bei fehlendem PTR-Record Sekunden dauern.
        // Deshalb: nur 1× pro Session (24 h) auflösen, dann aus Session.
        // ============================================================
        $cacheKey = "etchat_" . $this->_prefix . "host_" . md5($ip);

        if (isset($_SESSION[$cacheKey])) {
            $cached = $_SESSION[$cacheKey];
            // Cache ist 24 h gültig
            if (($cached["ts"] ?? 0) + 86400 > time()) {
                $host = $cached["host"];
            } else {
                unset($_SESSION[$cacheKey]);
                $host = null;
            }
        } else {
            $host = null;
        }

        if ($host === null) {
            $host = gethostbyaddr($ip) ?: $ip;
            $_SESSION[$cacheKey] = [
                "host" => $host,
                "ts" => time(),
            ];
        }

        $this->user_param_all = $ip . "@" . $host;
    }

    public function userInBlacklist(string $checkUserName = ""): bool
    {
        $now = time();

        // Team ist von allen Sperren befreit (IP-Bann, Cookie, Username)
        $teamRole = "";
        if ($checkUserName !== "") {
            // Beim Login: Rolle über den eingegebenen Namen holen
            $r = $this->dbObj->sqlGet(
                "SELECT etchat_userprivilegien FROM {$this->_prefix}etchat_user
         WHERE etchat_username IN (:raw, :enc) LIMIT 1",
                [
                    ":raw" => $checkUserName,
                    ":enc" => htmlspecialchars(
                        $checkUserName,
                        ENT_QUOTES,
                        "UTF-8"
                    ),
                ]
            );
            $teamRole = $r[0]["etchat_userprivilegien"] ?? "";
        } else {
            // Eingeloggt: Rolle aus der Session (kein Extra-DB-Zugriff)
            $teamRole =
                $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? "";
        }

        if (in_array($teamRole, self::TEAM_ROLES, true)) {
            return false;
        }

        $cookie_ip = $_COOKIE["cookie_etchat_blacklist_ip"] ?? "";
        $cookie_time = (int) ($_COOKIE["cookie_etchat_blacklist_until"] ?? 0);

        $blacklist_c = false;

        if ($cookie_ip !== "" && $cookie_time > $now) {
            $blacklist_c = $this->dbObj->sqlGet(
                "SELECT etchat_blacklist_time
                 FROM {$this->_prefix}etchat_blacklist
                 WHERE etchat_blacklist_ip = :ip
                 AND etchat_blacklist_time = :time
                 AND etchat_blacklist_time > :now",
                [
                    ":ip" => $cookie_ip,
                    ":time" => $cookie_time,
                    ":now" => $now,
                ]
            );
        }

        $user_ip = $_SERVER["REMOTE_ADDR"] ?? "";

        // 🔥 PERFORMANCE: gecachten Host verwenden statt neuem DNS-Lookup
        $hostCacheKey = "etchat_" . $this->_prefix . "host_" . md5($user_ip);
        if (isset($_SESSION[$hostCacheKey]["host"])) {
            $user_host = $_SESSION[$hostCacheKey]["host"];
        } else {
            $user_host = gethostbyaddr($user_ip) ?: "";
            $_SESSION[$hostCacheKey] = ["host" => $user_host, "ts" => time()];
        }

        $user_combined = $user_ip . "@" . $user_host;

        $blacklist = $this->dbObj->sqlGet(
            "SELECT etchat_blacklist_time
             FROM {$this->_prefix}etchat_blacklist
             WHERE (:ip LIKE CONCAT(etchat_blacklist_ip, '%')
                OR :combined LIKE CONCAT(etchat_blacklist_ip, '%'))
             AND etchat_blacklist_time > :now",
            [
                ":ip" => $user_ip,
                ":combined" => $user_combined,
                ":now" => $now,
            ]
        );

        // 🔄 ASSOZIATIVE INDIZES
        if ($blacklist && isset($blacklist[0]["etchat_blacklist_time"])) {
            $this->user_bann_time =
                (int) $blacklist[0]["etchat_blacklist_time"];
            return true;
        }

        if ($blacklist_c && isset($blacklist_c[0]["etchat_blacklist_time"])) {
            $this->user_bann_time =
                (int) $blacklist_c[0]["etchat_blacklist_time"];
            return true;
        }

        // Username → User-ID auflösen (übergebener Name hat beim Login Vorrang)
        $userName =
            $checkUserName !== ""
                ? $checkUserName
                : $_SESSION["etchat_" . $this->_prefix . "username"] ?? "";

        $uid = 0;
        if ($userName !== "") {
            // Beide Varianten prüfen: in der User-Tabelle steht der Name ggf. HTML-kodiert (z.B. &amp;)
            $u = $this->dbObj->sqlGet(
                "SELECT etchat_user_id FROM {$this->_prefix}etchat_user
         WHERE etchat_username IN (:raw, :enc) LIMIT 1",
                [
                    ":raw" => $userName,
                    ":enc" => htmlspecialchars($userName, ENT_QUOTES, "UTF-8"),
                ]
            );
            $uid = (int) ($u[0]["etchat_user_id"] ?? 0);
        } else {
            $uid =
                (int) ($_SESSION["etchat_" . $this->_prefix . "user_id"] ?? 0);
        }

        if ($uid > 0) {
            $hit = $this->dbObj->sqlGet(
                "SELECT etchat_blacklist_time
         FROM {$this->_prefix}etchat_blacklist
         WHERE etchat_blacklist_userid = :uid
           AND etchat_blacklist_time > :now
         ORDER BY etchat_blacklist_time DESC
         LIMIT 1",
                [":uid" => $uid, ":now" => $now]
            );

            if ($hit && isset($hit[0]["etchat_blacklist_time"])) {
                $this->user_bann_time = max(
                    $this->user_bann_time,
                    (int) $hit[0]["etchat_blacklist_time"]
                );
                return true;
            }
        }

        return false;
    }

    public function allowedToAndSetCookie(): bool
    {
        $user_id =
            (int) ($_SESSION["etchat_" . $this->_prefix . "user_id"] ?? 0);

        if ($user_id <= 0) {
            return false;
        }

        // 🔄 ASSOZIATIVER INDEX
        $role_result = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :user_id",
            [":user_id" => $user_id]
        );

        $role = $role_result[0]["etchat_userprivilegien"] ?? null;

        $excludedRoles = ["admin", "mod", "chatwache", "co_admin", "grafik"];

        if (!in_array($role, $excludedRoles, true)) {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_useronline
                 WHERE etchat_onlineuser_fid = :user_id",
                [":user_id" => $user_id]
            );

            setcookie("cookie_etchat_blacklist_until", $this->user_bann_time, [
                "expires" => $this->user_bann_time,
                "path" => "/",
                "samesite" => "Lax",
                "httponly" => true,
            ]);

            setcookie("cookie_etchat_blacklist_ip", $this->user_param_all, [
                "expires" => $this->user_bann_time,
                "path" => "/",
                "samesite" => "Lax",
                "httponly" => true,
            ]);

            return true;
        }

        return false;
    }

    public function insertUser(int $userID, int $time): bool
    {
        // 🔄 ASSOZIATIVER INDEX
        $role_result = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :user_id",
            [":user_id" => $userID]
        );

        $role = $role_result[0]["etchat_userprivilegien"] ?? null;

        $excludedRoles = self::TEAM_ROLES;

        if (in_array($role, $excludedRoles, true)) {
            return false;
        }

        // ============================================================
        // 🔥 IP ermitteln: onlineip → last_ip → reg_ip
        // ============================================================
        $ipVal = $this->getUserIp($userID);

        // Username für den Username-Bann holen
        $userRow = $this->dbObj->sqlGet(
            "SELECT etchat_username
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :user_id",
            [":user_id" => $userID]
        );

        $userName = $userRow[0]["etchat_username"] ?? "";

        $time_to_hold = time() + $time;

        // Ein Eintrag: IP + User-ID. Ist keine IP bekannt, kommt der Name
        // in die IP-Spalte (reiner Username-Bann über die User-ID).
        $banKey = $ipVal !== "" ? $ipVal : $userName;
        if ($banKey === "") {
            return false;
        }

        $this->dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_blacklist
     (etchat_blacklist_ip, etchat_blacklist_userid, etchat_blacklist_time)
     VALUES (:ip, :user_id, :time_to_hold)",
            [
                ":ip" => $banKey,
                ":user_id" => $userID,
                ":time_to_hold" => $time_to_hold,
            ]
        );

        return true;
    }

    /**
     * 🔥 IP ermitteln mit Fallback-Kette:
     *   1) etchat_onlineip (aktuell online)
     *   2) etchat_last_ip (letzte bekannte IP)
     *   3) etchat_reg_ip  (Registrierungs-IP, Notnagel)
     */
    private function getUserIp(int $userID): string
    {
        // Priorität 1: Aktuelle Online-IP
        $online = $this->dbObj->sqlGet(
            "SELECT etchat_onlineip
             FROM {$this->_prefix}etchat_useronline
             WHERE etchat_onlineuser_fid = :user_id",
            [":user_id" => $userID]
        );

        if ($online && !empty($online[0]["etchat_onlineip"])) {
            $ip = trim($online[0]["etchat_onlineip"]);
            if ($ip !== "") {
                return $ip;
            }
        }

        // Priorität 2 & 3: last_ip, dann reg_ip
        $user = $this->dbObj->sqlGet(
            "SELECT etchat_last_ip, etchat_reg_ip
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :user_id",
            [":user_id" => $userID]
        );

        if ($user && !empty($user[0])) {
            if (!empty($user[0]["etchat_last_ip"])) {
                $ip = trim($user[0]["etchat_last_ip"]);
                if ($ip !== "") {
                    return $ip;
                }
            }
            if (!empty($user[0]["etchat_reg_ip"])) {
                $ip = trim($user[0]["etchat_reg_ip"]);
                if ($ip !== "") {
                    return $ip;
                }
            }
        }

        return "";
    }

    public function killUserSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_unset();
            session_destroy();
        }
    }
}
