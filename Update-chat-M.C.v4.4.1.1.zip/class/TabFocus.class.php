<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class TabFocus extends DbConectionMaker
{
    private ?LangJson $lang = null;

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ============================================================
        // Sprache laden
        // ============================================================
        try {
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }

        if (!isset($_SESSION['etchat_' . $this->_prefix . 'user_id'])) {
            exit;
        }

        $userID = (int)$_SESSION['etchat_' . $this->_prefix . 'user_id'];
        $mode   = $_GET['mode'] ?? '';

		$userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

		if ($userPriv === 'admin' || $userPriv === 'co_admin') {
			return;
		}

        // =========================================================
        // MODE AWAY
        // =========================================================
        if ($mode === 'away') {

            // Multi-Tab-Schutz
            $lastActive = $_SESSION['__TABFOCUS_LAST_ACTIVE__'] ?? 0;
            if ($lastActive > time() - 10) {
                return;
            }

            $res = $this->dbObj->sqlGet(
                "SELECT etchat_user_online_user_status_img,
                        etchat_user_online_user_status_text
                 FROM {$this->_prefix}etchat_useronline
                 WHERE etchat_onlineuser_fid = :id
                 LIMIT 1",
                [':id' => $userID]
            );

            $currentImg  = $res[0]['etchat_user_online_user_status_img'] ?? '';
            $currentText = $res[0]['etchat_user_online_user_status_text'] ?? '';

            // Away darf eigenen Status nicht überschreiben
            if ($currentImg === 'status_tabaway') {
                return;
            }

            // Originalstatus sichern
            $_SESSION['__TABFOCUS__'] = [
                'old_img'  => $currentImg,
                'old_text' => $currentText,
                'ts'       => time()
            ];

            // ============================================================
            // Status auf away setzen - MIT SPRACHE!
            // ============================================================
            $awayText = $this->getText('tabfocus_status_away', 'Abwesend');

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_useronline
                 SET etchat_user_online_user_status_img = 'status_tabaway',
                     etchat_user_online_user_status_text = :away_text
                 WHERE etchat_onlineuser_fid = :id",
                [
                    ':away_text' => $awayText,
                    ':id'        => $userID
                ]
            );
        }

        // =========================================================
        // MODE BACK
        // =========================================================
        if ($mode === 'back' && isset($_SESSION['__TABFOCUS__'])) {

            $_SESSION['__TABFOCUS_LAST_ACTIVE__'] = time();

            $oldImg  = $_SESSION['__TABFOCUS__']['old_img']  ?? '';
            $oldText = $_SESSION['__TABFOCUS__']['old_text'] ?? '';

            // =====================================================
            // ?? GUARD: Nur wiederherstellen, wenn der Away-Zustand
            //    in der DB noch aktiv ist (status_tabaway).
            //
            //    Wurde er zwischenzeitlich von außen geändert
            //    (z. B. durch das OnAir-Script beim DJ-Wechsel),
            //    wird NICHT restored.
            //
            //    Das löst das Problem:
            //      Mod1 sendet ? onair
            //      Mod1 geht away ? tabaway (Session merkt onair)
            //      Mod2 übernimmt ? OnAir-Script leert Mod1 (DB = '')
            //      Mod1 kommt zurück ? DB ? tabaway ? kein Restore
            //      ? Mod1 bleibt leer, Mod2 bleibt onair ?
            //
            //    Duo-Sendungen bleiben unberührt:
            //      Mod1 + Mod2 onair, Mod1 geht away ? tabaway
            //      Mod1 kommt zurück, Sendung läuft noch
            //      ? DB = tabaway ? Restore läuft ? Mod1 = onair ?
            // =====================================================
            $current = $this->dbObj->sqlGet(
                "SELECT etchat_user_online_user_status_img,
                        etchat_user_online_user_status_text
                 FROM {$this->_prefix}etchat_useronline
                 WHERE etchat_onlineuser_fid = :id
                 LIMIT 1",
                [':id' => $userID]
            );

            $dbImg  = null;
            $dbText = null;
            if ($current && isset($current[0])) {
                $dbImg  = $current[0]['etchat_user_online_user_status_img']  ?? null;
                $dbText = $current[0]['etchat_user_online_user_status_text'] ?? null;
            }

            // ?? Marker: Text wurde geleert, Image steht noch auf tabaway
            //    ? OnAir-Reset ist passiert ? Status komplett leeren
            if ($dbImg === 'status_tabaway' && $dbText === '') {
                $this->dbObj->sqlSet(
                    "UPDATE {$this->_prefix}etchat_useronline
                     SET etchat_user_online_user_status_img  = '',
                         etchat_user_online_user_status_text = ''
                     WHERE etchat_onlineuser_fid = :id",
                    [':id' => $userID]
                );
            }
            // Normaler away-Ablauf ? Restore
            elseif ($dbImg === 'status_tabaway') {
                $this->dbObj->sqlSet(
                    "UPDATE {$this->_prefix}etchat_useronline
                     SET etchat_user_online_user_status_img = :img,
                         etchat_user_online_user_status_text = :txt
                     WHERE etchat_onlineuser_fid = :id",
                    [
                        ':img' => $oldImg,
                        ':txt' => $oldText,
                        ':id'  => $userID
                    ]
                );
            }
            // else:
            //   - $dbImg === null  ? User nicht mehr online ? nichts tun
            //   - $dbImg === ''    ? Status wurde von außen geleert
            //                        (OnAir-Reset) ? nichts tun
            //   - $dbImg === 'status_onair' ? schon onair ? nichts tun
            //   - sonst            ? Status wurde manuell geändert ? nichts tun

            // Session-Reste in jedem Fall aufräumen
            unset($_SESSION['__TABFOCUS__']);
        }
    }

    /**
     * Holt einen Sprachtext mit Fallback
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }
}