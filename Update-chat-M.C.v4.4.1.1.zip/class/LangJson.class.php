<?php

declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class LangJson extends EtChatConfig
{
    public $lastError = '';

    private $jsonData = null;

    public function __construct($path = "./lang/", $jsonfile = "")
    {
        parent::__construct();

        // 🔥 Wenn kein Pfad übergeben wurde, Default nutzen
        if (empty($path)) {
            $path = "./lang/";
        }

        $sessionFile = $_SESSION['etchat_' . $this->_prefix . 'lang_json_file'] ?? 'Deutsch';
        $langFolder = $sessionFile ?: 'Deutsch';
        $langCode = $this->getLangCodeFromFolder($langFolder);

        // 🔥 Dateiname ermitteln
        if (!empty($jsonfile)) {
            $jsonFile = $jsonfile;
        } else {
            // Backtrace: Admin-Request erkennen
            $isAdminRequest = false;
            $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5);
            foreach ($backtrace as $call) {
                $class = $call['class'] ?? '';
                if (str_starts_with($class, 'Admin')) {
                    $isAdminRequest = true;
                    break;
                }
            }

            if ($isAdminRequest) {
                $jsonFile = "lang_admin_" . $langCode . "_v2.json";
            } else {
                $jsonFile = "lang_" . $langCode . "_v2.json";
            }
        }

        // Pfade aufbauen
        $basePath = rtrim($path, "/");
        $jsonPath = $basePath . "/" . $langFolder . "/" . $jsonFile;
        $phpDir   = $basePath . "/" . $langFolder . "/php";
        $phpPath  = $phpDir . "/" . preg_replace('/\.json$/', '.php', $jsonFile);

        // Fallback: JSON im Hauptverzeichnis (alte Logik)
        if (!file_exists($jsonPath)) {
            $fallbackJson = $basePath . "/" . basename($jsonFile);
            if (file_exists($fallbackJson)) {
                $jsonPath = $fallbackJson;
                $phpPath  = $basePath . "/php/" . preg_replace('/\.json$/', '.php', basename($jsonFile));
                $phpDir   = $basePath . "/php";
            }
        }

        // ============================================================
        // 🔥 1) Prüfen, ob die PHP-Datei aktuell ist (Auto-Konvertierung)
        // ============================================================
        $this->ensurePhpIsUpToDate($jsonPath, $phpPath, $phpDir);

        // ============================================================
        // 🔥 2) PHP-Datei laden (schnell), sonst JSON (Fallback)
        // ============================================================
        $data = null;

        if (file_exists($phpPath)) {
            $data = require $phpPath;
            if (!is_array($data)) {
                $this->lastError = "PHP language file did not return array: " . $phpPath;
                $data = null;
            }
        }

        // Fallback: JSON direkt laden
        if ($data === null) {
            if (!file_exists($jsonPath)) {
                $this->lastError = "Language file not found: " . $jsonPath;
                $this->jsonData = new stdClass();
                return;
            }

            $content = file_get_contents($jsonPath);
            if ($content === false) {
                $this->lastError = "Failed to read JSON: " . $jsonPath;
                $this->jsonData = new stdClass();
                return;
            }

            $data = json_decode($content, true);
            if ($data === null) {
                $this->lastError = "Failed to parse JSON: " . json_last_error_msg() . " - File: " . $jsonPath;
                $this->jsonData = new stdClass();
                return;
            }
        }

        // ============================================================
        // 3) In moderne Objekt-Struktur parsen
        // ============================================================
        $this->jsonData = $this->parseModernJson($data);
    }

    /**
     * 🔥 Stellt sicher, dass die PHP-Datei existiert und aktuell ist.
     * Wenn die JSON neuer ist (oder die PHP fehlt), wird neu konvertiert.
     * Der php/-Ordner wird automatisch angelegt, falls er fehlt.
     */
    private function ensurePhpIsUpToDate(string $jsonPath, string $phpPath, string $phpDir): void
    {
        // JSON muss existieren
        if (!file_exists($jsonPath)) {
            return;
        }

        // Prüfen: PHP fehlt ODER JSON ist neuer
        $needsConvert = false;
        if (!file_exists($phpPath)) {
            $needsConvert = true;
        } else {
            $jsonTime = @filemtime($jsonPath);
            $phpTime  = @filemtime($phpPath);
            if ($jsonTime !== false && $phpTime !== false && $jsonTime > $phpTime) {
                $needsConvert = true;
            }
        }

        if (!$needsConvert) {
            return;
        }

        // JSON lesen
        $content = @file_get_contents($jsonPath);
        if ($content === false) {
            return;
        }

        $data = json_decode($content, true);
        if ($data === null) {
            // JSON kaputt → nicht konvertieren, Fallback auf JSON beim Laden
            return;
        }

        // php/-Ordner anlegen (falls nicht vorhanden)
        if (!is_dir($phpDir)) {
            if (!@mkdir($phpDir, 0755, true) && !is_dir($phpDir)) {
                // Konnte Ordner nicht erstellen → Fallback auf JSON
                return;
            }
        }

        // PHP-Datei schreiben
        $phpContent  = "<?php\n";
        $phpContent .= "// Automatisch generiert aus " . basename($jsonPath) . "\n";
        $phpContent .= "// NICHT manuell bearbeiten — Quelle ist die JSON-Datei!\n";
        $phpContent .= "// Generiert am: " . date('Y-m-d H:i:s') . "\n";
        $phpContent .= "return " . var_export($data, true) . ";\n";

        @file_put_contents($phpPath, $phpContent, LOCK_EX);
    }

    /**
     * Wandelt Ordnernamen in Sprachcode um (Deutsch -> de, Englisch -> en)
     */
    private function getLangCodeFromFolder(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
            'Französisch' => 'fr',
            'Spanisch' => 'es',
            'Italienisch' => 'it',
            'Niederländisch' => 'nl',
            'Russisch' => 'ru',
            'Türkisch' => 'tr',
            'Arabisch' => 'ar',
            'Chinesisch' => 'zh',
            '日本语' => 'ja',
            'Norwegisch' => 'no',
            'Finnisch' => 'fi',
            'Schwedisch' => 'sv',
        ];

        return $map[$folder] ?? 'de';
    }

    /**
     * Parst die JSON in eine moderne Objekt-Struktur
     */
private function parseModernJson(array $data): stdClass
{
    $result = new stdClass();
    
    // Strukturierte JSON (strings/structs)
    if (isset($data['strings']) || isset($data['structs'])) {
        if (isset($data['strings'])) {
            foreach ($data['strings'] as $key => $value) {
                $result->$key = $value;
            }
        }
        if (isset($data['structs'])) {
            foreach ($data['structs'] as $key => $struct) {
                $obj = new stdClass();
                $obj->value = $struct['value'] ?? '';
                $obj->attributes = $struct['attributes'] ?? [];
                $result->$key = $obj;
            }
        }
    } else {
        // 🔥 Flache JSON (radio.json etc.)
        foreach ($data as $key => $value) {
            $result->$key = $value;
        }
    }
    
    return $result;
}

    /**
     * Hauptmethode für den Sprachzugriff
     */
    public function get(string $key, $default = '')
    {
        if ($this->jsonData !== null && isset($this->jsonData->$key)) {
            $value = $this->jsonData->$key;
            // Bei Structs den value zurückgeben
            if (is_object($value) && isset($value->value)) {
                return $value->value;
            }
            return $value;
        }
        return $default;
    }

    /**
     * Holt ein Array (für Array-Typen in der JSON)
     */
    public function getArray(string $key): array
    {
        $value = $this->get($key);
        return is_array($value) ? $value : [];
    }

    /**
     * Holt ein Struct-Objekt (für Status-Definitionen)
     */
    public function getStruct(string $key)
    {
        if ($this->jsonData !== null && isset($this->jsonData->$key)) {
            $value = $this->jsonData->$key;
            if (is_object($value) && isset($value->value)) {
                return $value;
            }
        }
        return null;
    }

    /**
     * Holt alle Structs (für ChangeStatus::checkRightsOfStatus)
     */
    public function getAllStructs(): array
    {
        if ($this->jsonData === null) {
            return [];
        }

        $structs = [];
        foreach (get_object_vars($this->jsonData) as $key => $value) {
            if (is_object($value) && isset($value->value)) {
                $structs[$key] = $value;
            }
        }
        return $structs;
    }
	
/**
 * Gibt alle Daten als assoziatives Array zurück.
 * Funktioniert für flache JSONs (radio.json) UND für strukturierte.
 */
public function toArray(): array
{
    if ($this->jsonData === null) {
        return [];
    }

    $result = [];
    foreach (get_object_vars($this->jsonData) as $key => $value) {
        if (is_object($value) && isset($value->value)) {
            $result[$key] = $value->value;
        } else {
            $result[$key] = $value;
        }
    }
    return $result;
}

    /**
     * Gibt den letzten Fehler zurück
     */
    public function getLastError(): string
    {
        return $this->lastError;
    }
}