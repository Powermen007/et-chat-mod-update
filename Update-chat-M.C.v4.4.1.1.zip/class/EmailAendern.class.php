<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';
require_once __DIR__ . '/../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * EmailAendern - E-Mail-Adresse ändern mit Bestätigung via HMAC-Token.
 *   ?email_aendern=1                                   -> Formular
 *   ?email_aendern=1&bestaetigen=1&token=…             -> Bestätigung
 */
class EmailAendern extends DbConectionMaker
{
    private ?LangJson $lang = null;

    public function __construct()
    {
        parent::__construct();

        require_once __DIR__ . '/ZugriffsGuard.class.php';
        new ZugriffsGuard();

        try {
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }
    }

    public function run(): void
    {
        $this->handle();
        $this->render();
    }

    // ============================================================
    // HANDLE
    // ============================================================
    private function handle(): void
    {
        // Bestätigungslink
        if (isset($_GET['bestaetigen'], $_GET['token'])) {
            $this->handleConfirm((string)$_GET['token']);
            return;
        }

        // POST-Formular
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handleChange();
        }
    }

    private function handleConfirm(string $token): void
    {
        $prefix = $this->_prefix;
        $domain = $this->getDomain();

        $data = $this->verifyEmailChangeToken($token);

        if ($data === null) {
            $_SESSION['reg_success'] = $this->t('email_change_token_invalid', 'Ungültiger oder abgelaufener Link. Bitte fordere einen neuen an.');
            header('Location: ' . $domain);
            exit();
        }

        $userId   = (int)$data['uid'];
        $newEmail = (string)$data['eml'];

        // User existiert?
        $rows = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_userprivilegien
             FROM {$prefix}etchat_user
             WHERE etchat_user_id = ?",
            [$userId]
        );

        if (!$rows || $rows[0]['etchat_userprivilegien'] === 'gast') {
            $_SESSION['reg_success'] = $this->t('email_change_user_invalid', 'Benutzer nicht gefunden oder nicht aktiviert.');
            header('Location: ' . $domain);
            exit();
        }

        // 2er-Regel erneut prüfen
        $countRows = $this->dbObj->sqlGet(
            "SELECT COUNT(*) AS cnt FROM {$prefix}etchat_user
             WHERE etchat_email = ?
               AND (
                     etchat_userprivilegien != 'gast'
                  OR (etchat_reset_token IS NOT NULL AND etchat_reset_token_expiry > NOW())
               )
               AND etchat_user_id != ?",
            [$newEmail, $userId]
        );
        $emailCount = (int)($countRows[0]['cnt'] ?? 0);

        if ($emailCount >= 2) {
            $_SESSION['reg_success'] = $this->t('register_email_taken', 'Diese E-Mail-Adresse ist bereits registriert.');
            header('Location: ' . $domain);
            exit();
        }

        $this->dbObj->sqlSet(
            "UPDATE {$prefix}etchat_user SET etchat_email = ? WHERE etchat_user_id = ?",
            [$newEmail, $userId]
        );

        $_SESSION['reg_success'] = $this->t('email_change_success', 'E-Mail-Adresse erfolgreich geändert.');
        header('Location: ' . $domain);
        exit();
    }

    private function handleChange(): void
    {
        $prefix   = $this->_prefix;
        $domain   = $this->getDomain();
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $newEmail = trim($_POST['email'] ?? '');

        if ($username === '' || $password === '') {
            $this->eaFail(
                $this->t('register_username_empty', 'Benutzername und Passwort dürfen nicht leer sein.'),
                $_POST, $domain
            );
        }

        $rows = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_userpw, etchat_email, etchat_userprivilegien
             FROM {$prefix}etchat_user
             WHERE etchat_username = ?",
            [$username]
        );

        $user = $rows ? $rows[0] : null;

        if (!$user
            || $user['etchat_userprivilegien'] === 'gast'
            || !password_verify($password, $user['etchat_userpw'])) {
            $this->eaFail(
                $this->t('email_change_user_not_found', 'Benutzername oder Passwort nicht gefunden.'),
                $_POST, $domain
            );
        }

        $userId   = (int)$user['etchat_user_id'];
        $oldEmail = (string)$user['etchat_email'];

        if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $this->eaFail($this->t('register_email_invalid', 'Ungültige E-Mail-Adresse.'), $_POST, $domain);
        }
        if (strcasecmp($newEmail, $oldEmail) === 0) {
            $this->eaFail($this->t('email_change_same', 'Die neue E-Mail-Adresse ist identisch mit der alten.'), $_POST, $domain);
        }

        $countRows = $this->dbObj->sqlGet(
            "SELECT COUNT(*) AS cnt FROM {$prefix}etchat_user
             WHERE etchat_email = ?
               AND (
                     etchat_userprivilegien != 'gast'
                  OR (etchat_reset_token IS NOT NULL AND etchat_reset_token_expiry > NOW())
               )
               AND etchat_user_id != ?",
            [$newEmail, $userId]
        );
        $emailCount = (int)($countRows[0]['cnt'] ?? 0);

        if ($emailCount >= 2) {
            $this->eaFail($this->t('register_email_taken', 'Diese E-Mail-Adresse ist bereits registriert.'), $_POST, $domain);
        }

        $token = $this->createEmailChangeToken($userId, $newEmail);

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $this->_mail_host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->_mail_sendemail;
            $mail->Password   = $this->_mail_pass;
            $mail->SMTPSecure = $this->_mail_smtpsecure;
            $mail->Port       = $this->_mail_port;
            $mail->CharSet    = 'UTF-8';
            $mail->Encoding   = 'base64';
            $mail->setFrom($this->_mail_sendemail, $this->t('email_change_subject', 'E-Mail-Adresse bestätigen'));
            $mail->addAddress($newEmail, $username);
            $mail->isHTML(true);
            $mail->Subject = $this->t('email_change_subject', 'E-Mail-Adresse bestätigen');

            $confirmLink = $domain . '?email_aendern=1&bestaetigen=1&token=' . urlencode($token);
            $mailBody = '<p>' . $this->t('register_hello', 'Hallo') . ' ' . $this->h($username) . ',</p>'
                      . '<p>' . $this->t('email_change_body', 'Bitte bestätige deine neue E-Mail-Adresse:') . '</p>'
                      . '<a href="' . $this->h($confirmLink) . '">' . $this->h($confirmLink) . '</a><br>'
                      . $this->t('register_reset_link_valid', 'Dieser Link ist 15 Minuten gültig.');

            $mail->Body = $mailBody;
            $mail->send();

            $_SESSION['reg_success'] = $this->t('email_change_sent', 'Bestätigungs-Mail an die neue Adresse gesendet. Bitte prüfe dein Postfach.');
            header('Location: ' . $domain);
            exit();

        } catch (Exception $e) {
            $this->eaFail(
                $this->t('register_email_error', 'E-Mail konnte nicht gesendet werden. Bitte versuche es später erneut.'),
                $_POST, $domain
            );
        }
    }

    // ============================================================
    // RENDER
    // ============================================================
    private function render(): void
    {
        // Bestätigung und Redirect beenden den Request vorher – hier nur Formular.
        $eaError = $this->eaPullError();
        $eaOld   = $this->eaPullOld();

        echo $this->styleCss();
        ?>
        <h2><?php echo $this->h($this->t('email_change_title', 'E-Mail-Adresse ändern')); ?></h2>
        <?php if ($eaError !== ''): ?>
            <div class="reg-error"><?php echo $this->h($eaError); ?></div>
        <?php endif; ?>
        <form class="reg-form" method="POST" action="?email_aendern=1" id="ea_form">
            <input name="username" id="username"
                   value="<?php echo $this->h($eaOld['username'] ?? ''); ?>"
                   placeholder="<?php echo $this->h($this->t('login_name', 'Dein Chatname')); ?>" required /><br><br>

            <div id="ea_lay_pw" style="position: relative; display: inline-block; width: 85%; max-width: 350px;">
                <input name="password" id="ea_password"
                       placeholder="<?php echo $this->h($this->t('login_password', 'Passwort:')); ?>"
                       type="password" required
                       style="width: 100%; padding-right: 40px; box-sizing: border-box;" />
                <span id="ea_togglePassword"
                      style="position: absolute; right: 12px; top: 30%; transform: translateY(-50%); cursor: pointer; font-size: 18px;"
                      title="<?php echo $this->h($this->t('register_show_password', 'Passwort anzeigen')); ?>">👁️</span>
                <span id="ea_togglePasswordOff"
                      style="position: absolute; right: 12px; top: 30%; transform: translateY(-50%); cursor: pointer; font-size: 18px; display: none;"
                      title="<?php echo $this->h($this->t('register_show_password', 'Passwort anzeigen')); ?>">🙈</span>
            </div><br>

            <input name="email" id="email"
                   value="<?php echo $this->h($eaOld['email'] ?? ''); ?>"
                   placeholder="<?php echo $this->h($this->t('register_email_placeholder', 'Neue E-Mail-Adresse')); ?>"
                   type="email" required /><br>
            <button type="submit" class="submit_button"><?php echo $this->h($this->t('email_change_submit', 'E-Mail ändern')); ?></button>
            <button type="button" class="submit_button-secondary" onclick="window.location.href='<?php echo $this->h($this->getDomain()); ?>'"><?php echo $this->h($this->t('register_back_to_login', 'Zurück zum Login')); ?></button>
        </form>
        <?php
    }

    // ============================================================
    // PRIVATE HELFER
    // ============================================================
    private function t(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function h(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    }

    private function getDomain(): string
    {
        $protocol  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host      = $_SERVER['SERVER_NAME'] ?? 'localhost';
        $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\');
        return $protocol . '://' . $host . ($scriptDir !== '' && $scriptDir !== '/' ? $scriptDir : '') . '/';
    }

    private function eaFail(string $error, array $old, string $domain, string $target = '?email_aendern=1'): void
    {
        $_SESSION['ea_error'] = $error;
        $_SESSION['ea_old']   = $old;
        header('Location: ' . $domain . $target);
        exit();
    }

    private function eaPullError(): string
    {
        $e = $_SESSION['ea_error'] ?? '';
        unset($_SESSION['ea_error']);
        return (string)$e;
    }

    private function eaPullOld(): array
    {
        $o = $_SESSION['ea_old'] ?? [];
        unset($_SESSION['ea_old']);
        return is_array($o) ? $o : [];
    }

    // ===== HMAC-Token (Maschinen-gebunden) =====
    private function getMachineId(): string
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $parts   = [];
        $parts[] = gethostname() ?: '';
        $parts[] = php_uname('n') ?: '';
        if (is_readable('/etc/machine-id')) {
            $parts[] = trim((string)file_get_contents('/etc/machine-id'));
        }
        if (is_readable('/var/lib/dbus/machine-id')) {
            $parts[] = trim((string)file_get_contents('/var/lib/dbus/machine-id'));
        }
        $parts[] = $_SERVER['SERVER_ADDR'] ?? '';

        $cached = hash('sha256', implode('|', $parts));
        return $cached;
    }

    private function createEmailChangeToken(int $userId, string $newEmail): string
    {
        $payload = json_encode([
            'uid' => $userId,
            'eml' => $newEmail,
            'exp' => time() + 3600,
        ]);
        $secret = $this->getMachineId();
        $sig    = hash_hmac('sha256', $payload, $secret);

        $token   = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
        $sigEnc  = rtrim(strtr(base64_encode($sig), '+/', '-_'), '=');

        return $token . '.' . $sigEnc;
    }

    private function verifyEmailChangeToken(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 2) {
            return null;
        }
        [$payloadEnc, $sigEnc] = $parts;

        $payload = base64_decode(strtr($payloadEnc, '-_', '+/'));
        $sig     = base64_decode(strtr($sigEnc, '-_', '+/'));
        if ($payload === false || $sig === false) {
            return null;
        }

        $secret      = $this->getMachineId();
        $expectedSig = hash_hmac('sha256', $payload, $secret);
        if (!hash_equals($expectedSig, $sig)) {
            return null;
        }

        $data = json_decode($payload, true);
        if (!is_array($data)) {
            return null;
        }
        if (empty($data['exp']) || $data['exp'] < time()) {
            return null;
        }
        if (empty($data['uid']) || empty($data['eml'])) {
            return null;
        }

        return $data;
    }

    private function styleCss(): string
    {
        return '
<style>
input, label, button, small { margin-bottom: 15px; }
small { font-size: 11px; color: red; }
.reg-error {
    color: red; background: #ffeeee; padding: 10px; border-radius: 5px;
    margin: 10px auto; text-align: center; font-weight: bold; max-width: 600px;
}
.reg-success {
    color: green; background: #eeffee; padding: 10px; border-radius: 5px;
    margin: 10px auto; text-align: center; font-weight: bold; max-width: 600px;
}
</style>';
    }
}