<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';
require_once __DIR__ . '/../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Registrieren extends DbConectionMaker
{
    private ?LangJson $lang = null;

    public function __construct()
    {
        parent::__construct();

        require_once __DIR__ . '/ZugriffsGuard.class.php';
        new ZugriffsGuard();

        try {
            $this->lang = new LangJson();
        } catch (Throwable $e) {
            $this->lang = null;
        }
    }

    public function run(): void
    {
        $this->handle();
        $this->render();
    }

    // ============================================================
    // HANDLE
    // ============================================================
    private function handle(): void
    {
        $prefix      = $this->_prefix;
        $regEnabled  = (int)($_SESSION['etchat_' . $prefix . 'reg_an_aus'] ?? 0) === 1;
        $mode        = $_GET['passwort'] ?? 'registrieren';
        $isPublicReg = ($mode === 'registrieren' && !isset($_GET['token']));

        // Registrierung global aus?
        if ($isPublicReg && !$regEnabled) {
            $msg = $this->t('register_disabled', 'Die Registrierung ist derzeit deaktiviert.');
            echo "<script>alert(" . json_encode($msg) . "); window.location.href='" . $this->h($this->getDomain()) . "';</script>";
            exit();
        }

        // Aktivierung via Token
        if (isset($_GET['token'])) {
            $this->handleActivation((string)$_GET['token']);
            return;
        }

        // POST-Verarbeitung
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
            $this->handleRegistration();
        }
    }

    private function handleActivation(string $token): void
    {
        $prefix = $this->_prefix;
        $domain = $this->getDomain();

        $user = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_reset_token_expiry
             FROM {$prefix}etchat_user
             WHERE etchat_reset_token = ?
               AND etchat_userprivilegien = 'gast'
               AND etchat_reset_token_expiry > NOW()",
            [$token]
        );

        if (!$user) {
            $expired = $this->dbObj->sqlGet(
                "SELECT etchat_user_id
                 FROM {$prefix}etchat_user
                 WHERE etchat_reset_token = ?
                   AND etchat_userprivilegien = 'gast'
                   AND etchat_reset_token_expiry <= NOW()",
                [$token]
            );

            if ($expired) {
                $this->dbObj->sqlSet(
                    "DELETE FROM {$prefix}etchat_user
                     WHERE etchat_reset_token = ?
                       AND etchat_userprivilegien = 'gast'",
                    [$token]
                );
                $_SESSION['reg_success'] = $this->t('register_token_expired', 'Ihr Aktivierungs-Link ist abgelaufen (gültig für 30 Minuten). Bitte registrieren Sie sich erneut.');
                header('Location: ' . $domain . '?register');
                exit();
            }

            $_SESSION['reg_success'] = $this->t('register_token_invalid', 'Aktivierungs-Token ungültig.');
            header('Location: ' . $domain);
            exit();
        }

        $this->dbObj->sqlSet(
            "UPDATE {$prefix}etchat_user
             SET etchat_userprivilegien = 'user',
                 etchat_reset_token = NULL,
                 etchat_reset_token_expiry = NULL
             WHERE etchat_user_id = ?",
            [(int)$user[0]['etchat_user_id']]
        );

        $_SESSION['reg_success'] = $this->t('register_account_activated', 'Account aktiviert! Du kannst dich jetzt einloggen.');
        header('Location: ' . $domain);
        exit();
    }

    private function handleRegistration(): void
    {
        $prefix = $this->_prefix;
        $domain = $this->getDomain();

        $username = trim($_POST['username'] ?? '');

        if ($username === '') {
            $this->regFail($this->t('register_username_empty', 'Der Benutzername darf nicht leer sein.'), $_POST, $domain);
        }
        if (strlen($username) < 4 || strlen($username) > 25) {
            $this->regFail($this->t('register_username_length', 'Der Benutzername muss zwischen 4 und 25 Zeichen lang sein.'), $_POST, $domain);
        }
        if (!$this->validateUsernameFormat($username)) {
            $this->regFail($this->t('register_username_invalid_chars', 'Der Benutzername enthält nicht erlaubte Zeichen oder zu viele Sonderzeichen (max. 3)!'), $_POST, $domain);
        }
        if ($this->hasDangerousPatterns($username)) {
            $this->regFail($this->t('register_username_dangerous', 'Der Benutzername enthält ungültige Zeichenkombinationen!'), $_POST, $domain);
        }
        $bannedWords = $this->loadBannedWordsFromJson();
        if (!$this->isUsernameAllowed($username, $bannedWords)) {
            $this->regFail($this->t('register_username_banned', 'Dieser Benutzername ist nicht erlaubt! Bitte wähle einen anderen Namen.'), $_POST, $domain);
        }
        if (preg_match('/^[\s&@\._\-+=#~€$%§]+$/u', $username)) {
            $this->regFail($this->t('register_username_no_letters', 'Der Benutzername muss mindestens einen Buchstaben oder eine Zahl enthalten.'), $_POST, $domain);
        }

        $password         = trim($_POST['password'] ?? '');
        $confirm_password = trim($_POST['confirm_password'] ?? '');
        $email            = trim($_POST['email'] ?? '');
        $reg_ip           = $_SERVER['REMOTE_ADDR'] ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->regFail($this->t('register_email_invalid', 'Ungültige E-Mail-Adresse.'), $_POST, $domain);
        }
        if ($password !== $confirm_password) {
            $this->regFail($this->t('register_password_mismatch', 'Die Passwörter stimmen nicht überein.'), $_POST, $domain);
        }
        if (!$this->isPasswordStrongEnough($password)) {
            $this->regFail($this->t('register_password_weak', 'Passwort zu schwach. Mindestens 8 Zeichen, 3 von: Groß, Klein, Zahl, Sonderzeichen.'), $_POST, $domain);
        }

        // Username-Check
        $existingUser = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_userprivilegien, etchat_reset_token_expiry
             FROM {$prefix}etchat_user
             WHERE etchat_username = ?",
            [$username]
        );
        $existingUser = $existingUser ? $existingUser[0] : null;

        if ($existingUser) {
            if ($existingUser['etchat_userprivilegien'] !== 'gast') {
                $this->regFail($this->t('register_username_taken', 'Dieser Benutzername ist bereits vergeben.'), $_POST, $domain);
            }
            if (!empty($existingUser['etchat_reset_token_expiry'])
                && strtotime($existingUser['etchat_reset_token_expiry']) > time()) {
                $this->regFail($this->t('register_activation_pending', 'Für diesen Benutzernamen läuft bereits eine Registrierung. Bitte bestätige deine E-Mail.'), $_POST, $domain);
            }
        }

        // E-Mail-Check (max. 2 aktive Einträge pro E-Mail)
        $excludeUserId = $existingUser ? (int)$existingUser['etchat_user_id'] : 0;
        $emailCountRows = $this->dbObj->sqlGet(
            "SELECT COUNT(*) AS cnt FROM {$prefix}etchat_user
             WHERE etchat_email = ?
               AND (
                     etchat_userprivilegien != 'gast'
                  OR (etchat_reset_token IS NOT NULL AND etchat_reset_token_expiry > NOW())
               )
               AND etchat_user_id != ?",
            [$email, $excludeUserId]
        );
        $emailCount = (int)($emailCountRows[0]['cnt'] ?? 0);

        if ($emailCount >= 2) {
            $this->regFail($this->t('register_email_taken', 'Diese E-Mail-Adresse ist bereits registriert.'), $_POST, $domain);
        }

        // INSERT oder UPDATE
        $hashedPassword  = password_hash($password, PASSWORD_DEFAULT);
        $userprivilegien = 'gast';
        $reg_timestamp   = date('Y-m-d H:i:s');
        $token           = bin2hex(random_bytes(16));
        $token_expiry    = date('Y-m-d H:i:s', strtotime('+30 minutes'));

        if ($existingUser) {
            $this->dbObj->sqlSet(
                "UPDATE {$prefix}etchat_user
                 SET etchat_userpw = ?, etchat_userprivilegien = ?, etchat_email = ?,
                     etchat_reg_timestamp = ?, etchat_reg_ip = ?,
                     etchat_reset_token = ?, etchat_reset_token_expiry = ?
                 WHERE etchat_user_id = ?",
                [$hashedPassword, $userprivilegien, $email, $reg_timestamp, $reg_ip, $token, $token_expiry, (int)$existingUser['etchat_user_id']]
            );
        } else {
            // IP-Cooldown
            $ipCountRows = $this->dbObj->sqlGet(
                "SELECT COUNT(*) AS cnt FROM {$prefix}etchat_user
                 WHERE etchat_reg_ip = ?
                   AND etchat_reg_timestamp > (NOW() - INTERVAL 12 HOUR)
                   AND (
                         etchat_userprivilegien != 'gast'
                      OR (etchat_reset_token IS NOT NULL AND etchat_reset_token_expiry > NOW())
                   )",
                [$reg_ip]
            );
            $ipCount = (int)($ipCountRows[0]['cnt'] ?? 0);

            if ($ipCount >= 2) {
                $this->regFail($this->t('register_ip_limit', 'Von dieser IP wurden bereits 2 Registrierungen in den letzten 12 Stunden durchgeführt. Bitte versuche es später erneut.'), $_POST, $domain);
            }

            $this->dbObj->sqlSet(
                "INSERT INTO {$prefix}etchat_user
                 (etchat_username, etchat_userpw, etchat_userprivilegien, etchat_email,
                  etchat_reg_timestamp, etchat_reg_ip,
                  etchat_reset_token, etchat_reset_token_expiry)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                [$username, $hashedPassword, $userprivilegien, $email, $reg_timestamp, $reg_ip, $token, $token_expiry]
            );
        }
		
        // Aktivierungs-Mail
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $this->_mail_host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->_mail_sendemail;
            $mail->Password   = $this->_mail_pass;
            $mail->SMTPSecure = $this->_mail_smtpsecure;
            $mail->Port       = $this->_mail_port;
            $mail->CharSet    = 'UTF-8';
            $mail->Encoding   = 'base64';
            $mail->setFrom($this->_mail_sendemail, $this->t('register_email_confirm_subject', 'Registrierung bestätigen'));
            $mail->addAddress($email, $username);
            $mail->isHTML(true);
            $mail->Subject = $this->t('register_email_confirm_subject', 'Registrierung bestätigen');

            $confirmLink = $domain . '?token=' . urlencode($token);
            $mailBody    = $this->t('register_email_body', '
<p>Hallo {username},</p>
<p>Bitte bestätige deine Registrierung:</p>
<a href="{confirmLink}">{confirmLink}</a><br>
Link 30 Minuten gültig.<br><br>
Viel Spaß!<br><br>
Sollten sie sich nicht bei uns Registriert haben, können sie diese E-Mail ignorieren.<br><br>
Nach der Aktivierung sind sie kein Gast mehr und können sich mit Ihren<br>
Benutzernname :<b> {username}</b><br>
und Ihren<br>
Passwort:<b> {password}</b><br>
Einloggen auf<br>
{domain}<br><br>
Viel Spaß');

            $mailBody = str_replace(
                ['{username}', '{confirmLink}', '{password}', '{domain}'],
                [$username, $confirmLink, $password, $domain],
                $mailBody
            );

            $mail->Body = $mailBody;
            $mail->send();

            $_SESSION['reg_success'] = $this->t('register_success', 'Registrierung erfolgreich. Bitte bestätige deine E-Mail.');
            header('Location: ' . $domain);
            exit();

        } catch (Exception $e) {
            // Cleanup bei Mail-Fehler
            if ($existingUser) {
                $this->dbObj->sqlSet(
                    "UPDATE {$prefix}etchat_user
                     SET etchat_reset_token = NULL, etchat_reset_token_expiry = NULL
                     WHERE etchat_user_id = ?",
                    [(int)$existingUser['etchat_user_id']]
                );
            } else {
                $this->dbObj->sqlSet(
                    "DELETE FROM {$prefix}etchat_user WHERE etchat_reset_token = ?",
                    [$token]
                );
            }

            $this->regFail($this->t('register_email_error', 'E-Mail konnte nicht gesendet werden. Bitte versuche es später erneut.'), $_POST, $domain);
        }
    }

    // ============================================================
    // RENDER
    // ============================================================
    private function render(): void
    {
        $regError = $this->regPullError();
        $regOld   = $this->regPullOld();

        $pwWeakMsg   = $this->t('register_password_weak_msg', 'Passwort ist zu schwach');
        $pwStrongMsg = $this->t('register_password_strong_msg', 'Passwort stark');

        echo '<input type="hidden" id="reg_pw_weak_msg" value="' . $this->h($pwWeakMsg) . '">';
        echo '<input type="hidden" id="reg_pw_strong_msg" value="' . $this->h($pwStrongMsg) . '">';

        echo $this->styleCss();
        ?>
        <h2><?php echo $this->h($this->t('register_title', 'Benutzer registrieren')); ?></h2>
        <?php if ($regError !== ''): ?>
            <div class="reg-error"><?php echo $this->h($regError); ?></div>
        <?php endif; ?>
        <form class="reg-form" method="POST">
            <input name="username" id="username"
                   value="<?php echo $this->h($regOld['username'] ?? ''); ?>"
                   placeholder="<?php echo $this->h($this->t('register_username_placeholder', 'Dein Chatname min.4 Zeichen max.25')); ?>"
                   required minlength="4" maxlength="25"/>
            <p style="text-align: center;margin-top: 0px;"><?php echo $this->h($this->t('register_password_requirements', 'Das Passwort muss mindestens 8 Zeichen lang sein und 3 der folgenden Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.')); ?></p>
            <input id="password" name="password" placeholder="<?php echo $this->h($this->t('register_password_placeholder', 'Dein Passwort')); ?>" type="password" required />
            <small id="pw_strength" style="color: red;"></small><br>
            <input id="confirm_password" name="confirm_password" placeholder="<?php echo $this->h($this->t('register_confirm_password', 'Passwort wiederholen')); ?>" type="password" required />
            <small id="pwcheck" style="display:none;"><?php echo $this->h($this->t('register_password_mismatch', 'Die Passwörter stimmen nicht überein.')); ?></small>
            <p style="text-align: center;margin-top: 0px;margin-bottom: 0px;"><input type="checkbox" onclick="machText(this.checked,this.form)"><?php echo $this->h($this->t('register_show_password', 'Passwort anzeigen')); ?></p>
            <input name="email" id="email"
                   value="<?php echo $this->h($regOld['email'] ?? ''); ?>"
                   placeholder="<?php echo $this->h($this->t('register_email_placeholder', 'E-Mail-Adresse')); ?>"
                   type="email" required /><br>
            <small id="emailcheck" style="display:none; color:red; text-align:center;"><?php echo $this->h($this->t('register_email_invalid_hint', 'Bitte gib eine gültige E-Mail-Adresse ein.')); ?></small><br>
            <button type="submit" class="submit_button"><?php echo $this->h($this->t('register_submit', 'Registrieren')); ?></button>
            <button type="button" class="submit_button-secondary" onclick="window.location.href='?passwort=vergessen'"><?php echo $this->h($this->t('register_forgot_password', 'Passwort vergessen?')); ?></button>
            <button type="button" class="submit_button-secondary" onclick="window.location.href='<?php echo $this->h($this->getDomain()); ?>'"><?php echo $this->h($this->t('register_back_to_login', 'Zurück zum Login')); ?></button>
        </form>
        <?php
    }

    // ============================================================
    // PRIVATE HELFER
    // ============================================================
    private function t(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function h(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    }

    private function getDomain(): string
    {
        $protocol  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host      = $_SERVER['SERVER_NAME'] ?? 'localhost';
        $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\');
        return $protocol . '://' . $host . ($scriptDir !== '' && $scriptDir !== '/' ? $scriptDir : '') . '/';
    }

    private function regFail(string $error, array $old, string $domain, string $target = '?register'): void
    {
        $_SESSION['reg_error'] = $error;
        $_SESSION['reg_old']   = $old;
        header('Location: ' . $domain . $target);
        exit();
    }

    private function regPullError(): string
    {
        $e = $_SESSION['reg_error'] ?? '';
        unset($_SESSION['reg_error']);
        return (string)$e;
    }

    private function regPullOld(): array
    {
        $o = $_SESSION['reg_old'] ?? [];
        unset($_SESSION['reg_old']);
        return is_array($o) ? $o : [];
    }

    private function isPasswordStrongEnough(string $password): bool
    {
        $criteriaMet  = (int)preg_match('/[A-Z]/', $password);
        $criteriaMet += (int)preg_match('/[a-z]/', $password);
        $criteriaMet += (int)preg_match('/[0-9]/', $password);
        $criteriaMet += (int)preg_match('/[\W_]/', $password);
        return strlen($password) >= 8 && $criteriaMet >= 3;
    }

    private function loadBannedWordsFromJson(): array
    {
        $jsonFile = __DIR__ . '/../cache/verbotene_user_namen.json';
        if (!is_file($jsonFile)) {
            return [];
        }
        $content = file_get_contents($jsonFile);
        $words   = json_decode((string)$content, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($words)) {
            return [];
        }
        return $words;
    }

    private function isUsernameAllowed(string $username, array $bannedWords): bool
    {
        foreach ($bannedWords as $banned) {
            if (stripos($username, (string)$banned) !== false) {
                return false;
            }
            if (strcasecmp($username, (string)$banned) === 0) {
                return false;
            }
        }
        return true;
    }

    private function validateUsernameFormat(string $username): bool
    {
        if (!preg_match('/^[\p{L}\p{N}\s&@\._\-+=#~€$%§]+$/u', $username)) {
            return false;
        }
        if (preg_match_all('/[&@\._\-+=#~€$%§]/u', $username) > 3) {
            return false;
        }
        return true;
    }

    private function hasDangerousPatterns(string $username): bool
    {
        $dangerous = [
            '../', '..\\', './', '.\\', '<!--', '-->', '<script', '</script',
            '<?php', '?>', '<%', '%>', 'javascript:', 'vbscript:', 'onclick=', 'onload=',
            'union select', 'or 1=1', 'drop table', 'delete from', '--', '/*', '*/', ';--',
        ];
        $lowerUser = strtolower($username);
        foreach ($dangerous as $pattern) {
            if (strpos($lowerUser, strtolower($pattern)) !== false) {
                return true;
            }
        }
        return false;
    }

    private function styleCss(): string
    {
        return '
<style>
input, label, button, small { margin-bottom: 15px; }
small { font-size: 11px; color: red; }
.reg-error {
    color: red; background: #ffeeee; padding: 10px; border-radius: 5px;
    margin: 10px auto; text-align: center; font-weight: bold; max-width: 600px;
}
.reg-success {
    color: green; background: #eeffee; padding: 10px; border-radius: 5px;
    margin: 10px auto; text-align: center; font-weight: bold; max-width: 600px;
}
</style>';
    }
}