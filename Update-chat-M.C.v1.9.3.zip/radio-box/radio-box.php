<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

$GLOBALS["path"] = "./../";

spl_autoload_register(function($class_name) {
		require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class ExternUserViewLinkRadio extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		unset($GLOBALS["path"]);

		$desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");
		$radio=$this->dbObj->sqlGet("SELECT etchat_radio_id , etchat_radio_horst, etchat_radio_port, etchat_radio_typ, etchat_radio_stream, etchat_radio_name, etchat_radio_color, etchat_radio_bit, etchat_radio_box, etchat_radio_player FROM {$this->_prefix}etchat_radio_box WHERE etchat_radio_id = '1'");
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="de" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link href="player.css" rel="stylesheet" type="text/css">
<?php
 			if (is_array($desei)){
     			   foreach($desei as $data){
        				echo"<link href=\"../styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        		}
        	}
        	if (is_array($radio)){
        			foreach($radio as $data_radio){
        	 			$horst1 = $data_radio[1];
        	 			$port1 = $data_radio[2];
        	 			$pass1 = $data_radio[3];
        	 			$stream1 = $data_radio[4];
        	 			$rname1 = $data_radio[5];
        	 			$rcolor1 = $data_radio[6];
        	 			$rbit1 = $data_radio[7];
        	 			$radio_box = $data_radio[8];
        	 			$radio_player = $data_radio[9];
 							}
 	      				}

?>

<title><?php echo $rname1; ?></title>
</head>
<body id="body">

<script>
setInterval(function() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "radio-box.php?metrics=true", true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("dj-on").innerHTML = xhr.responseText;
        }
    }
    xhr.send();
}, 30000);
</script>

<div id="dj-on">

<?php

if ($radio_box == '1') {

$type = $data_radio[3] ?? 'shoutcast'; // shoutcast oder icecast
$ip = $horst1;
$port = $port1;

$xml_data = false;
$json_data = false;
$listeners = 0;
$max = 0;
$title1 = '';
$name = '';

$protocols = ['https', 'http'];

switch ($type) {
	case 'lautfm':
    $station = $horst1; // z.B. 'radiobob' aus Datenbank
    $url = "https://api.laut.fm/station/{$station}/current_song";
    $context = stream_context_create(['http' => ['timeout' => 3]]);
    $json_data = @file_get_contents($url, false, $context);

    if ($json_data !== false) {
        $data = json_decode($json_data, true);
        if ($data && isset($data['title'])) {
            $title1 = $data['title'] ?? '';
            $name = $data['artist']['name'] ?? '';
            $title = "$name - $title1";
        } else {
            echo "Fehler beim Parsen der laut.fm-Daten.";
        }
    } else {
        echo "laut.fm-Station nicht erreichbar.";
    }

	$url = "https://api.laut.fm/station/$horst1/listeners";
		$listeners = @file_get_contents($url);

		if ($listeners === false) {
		    // Fehlerbehandlung
		    error_log("Konnte $url nicht laden");
		    $listeners = '{"total":0}'; // z.�B. Standardwert setzen
				}
		    $max = 100;		   // laut.fm gibt diese Info nicht �ffentlich
    			break;

    case 'icecast':
        foreach ($protocols as $proto) {
            $url = "$proto://$ip:$port/status-json.xsl";
            $context = stream_context_create(['http' => ['timeout' => 3]]);
            $json_data = @file_get_contents($url, false, $context);

            if ($json_data !== false) {
                $data = json_decode($json_data, true);
                if ($data && isset($data['icestats']['source'])) {
                    $source = $data['icestats']['source'];

                    // Wenn mehrere Mountpoints existieren
                    if (isset($source[0])) {
                        $source = $source[0]; // nur den ersten Mount nehmen
                    }

                    $title = $source['title'] ?? '';
                    $listeners = $source['listeners'] ?? 0;
                    $max = $source['listener_peak'] ?? 0;
                    $name = $source['server_name'] ?? 'Icecast Stream';
                    break;
                }
            }
        }

        if ($json_data === false) {
            echo "Icecast-Server nicht erreichbar �ber HTTP oder HTTPS.";
        }
        break;

    case 'shoutcast':
    default:
        $path = '/stats?sid=1&mode=xml';
        foreach ($protocols as $proto) {
            $url = "$proto://$ip:$port$path";
            $context = stream_context_create(['http' => ['timeout' => 3]]);
            $xml_data = @file_get_contents($url, false, $context);

            if ($xml_data !== false) {
                $xml = simplexml_load_string($xml_data);
                if ($xml && $xml->STREAMSTATUS == 1) {
                    $listeners = (int)$xml->CURRENTLISTENERS;
                    $title = (string)$xml->SONGTITLE;
                    $name = (string)$xml->SERVERTITLE;
                    $max = (string)$xml->MAXLISTENERS;
                    break;
                }
            }
        }

        if ($xml_data === false) {
            echo "Shoutcast-Server nicht erreichbar �ber HTTP oder HTTPS.";
        }
}

?>
<table class="player" style="width:100%; border-collapse:collapse;">
<tbody>
<tr style="height: 2px;">
<td style="width: 70px">DJ OnAir:</td>
<td style="width: 2px"></td>
<td colspan="2">

<?php
$title = $title ?? '';
$parts = explode("|", $title);
$djName = trim($parts[1] ?? '');

// Pr�fen, ob User ein mod oder admin ist
$isPrivileged = false;
if (!empty($djName)) {
    $check = $this->dbObj->sqlGet("
        SELECT etchat_user_id
        FROM {$this->_prefix}etchat_user
        WHERE etchat_username = '" . addslashes($djName) . "'
          AND etchat_userprivilegien IN ('mod','admin')
        LIMIT 1
    ");
    $isPrivileged = ($check && isset($check[0][0]));
}

// Ausgabe Name im Feld "DJ OnAir:"
echo $isPrivileged ? $djName : "Auto DJ";

// ===============================
// Chat-Status setzen oder zur�cksetzen
// ===============================

// Absicherung: falls $title nicht definiert ist
$djName = trim($parts[1] ?? '');
$song   = trim($parts[0] ?? '');

if (!empty($djName)) {
    $statusImg  = "status_onair";
    $statusText = "On Air";

    // User suchen, aber nur wenn privilegien "mod" oder "admin"
    $user = $this->dbObj->sqlGet("
        SELECT etchat_user_id
        FROM {$this->_prefix}etchat_user
        WHERE etchat_username = '" . addslashes($djName) . "'
          AND etchat_userprivilegien IN ('mod','admin')
        LIMIT 1
    ");

    if ($user && isset($user[0][0])) {
        $userId = (int)$user[0][0];

        $this->dbObj->sqlSet("
            UPDATE {$this->_prefix}etchat_useronline SET
                etchat_user_online_user_status_img  = '$statusImg',
                etchat_user_online_user_status_text = '$statusText'
            WHERE etchat_onlineuser_fid = $userId
        ");
    }
} else {
    // Kein DJ oder Stream aus ? Status zur�cksetzen
    $this->dbObj->sqlSet("
        UPDATE {$this->_prefix}etchat_useronline SET
            etchat_user_online_user_status_img  = '',
            etchat_user_online_user_status_text = ''
        WHERE etchat_user_online_user_status_img = 'status_onair'
    ");
}
// ===============================

  $this->dbObj->close();
?>

</td>

</tr>
<tr style="height: 2px;">
<td style="width: 70px">Zuh&ouml;rer:</td>
<td style="width: 2px"></td>
<td style="width: 30%">
<?php echo $listeners; ?> / <?php echo $max; ?>
</td>

<td rowspan="2">
<?php
$parts = explode("|", $title);
if (!$isPrivileged) {
    // Standardbild f�r Auto DJ
    echo '<img src="../avatar/autodj.jpg" width="75" height="75" alt="autodj">';
} else {
    // Avatar f�r DJ suchen
    $name = $djName;
    $result = "mod_ohne_pic.png"; // Standardbild falls nichts gefunden
    $avatarDir = "../avatar/";
    $extensions = ['jpg','jpeg','gif','png'];

    $escapedName = str_replace(['*','?'], ['\*','\?'], $name);

    foreach ($extensions as $ext) {
        $files = glob($avatarDir . $escapedName . "-*." . $ext);
        if (!empty($files)) {
            $result = basename($files[0]);
            break;
        }
    }

    echo '<img src="../avatar/' . $result . '" width="75" height="75" alt="' . htmlspecialchars($name) . '">';
}

?>
</td>


</tr>
<tr style="height: 2px;">
<td style="width: 70px">Bitrate:</td>
<td style="width: 2px"></td>
<td style="width: 30%"><?php echo $rbit1; ?> kb/s</td>

</tr>
<tr style="height: 2px;">
<td style="width: 70px">Titel:</td>
<td style="width: 2px"></td>
<td colspan="2">
<marquee scrollamount="10" scrolldelay="300">
<?php
$song1 = trim($parts[0]);
echo $song1;
?>
</marquee></td>

</tr>
</tbody>
</table>
</div></div>


<?php
}
if ($radio_player == '1') {
?>

<div class="player_play" id="player">
  <button id="playPauseBtn">&#9654;</button>
  <div class="title">
    <div class="scroll-text" id="streamTitle">Dr&uuml;cke Play...</div>
  </div>
  <div class="time" id="timeDisplay">00:00</div>
  <div class="volume-container" id="volumeContainer">
    <button class="volume" id="muteBtn">&#128266;</button>
    <div class="volume-slider above" id="volumeSlider">
      <input type="range" id="volumeControl" min="0" max="1" step="0.01" value="0.1">
    </div>
  </div>
</div>

<audio id="audio" preload="none" data-stream="<?php echo htmlspecialchars($stream1); ?>"></audio>

<script src="player.js"></script>

<?php
 }
  }}
new ExternUserViewLinkRadio();
?>
</body>
</html>