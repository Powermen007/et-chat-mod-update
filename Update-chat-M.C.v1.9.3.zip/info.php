<?php

$GLOBALS["path"] = "./";

spl_autoload_register(function($class_name) {
		require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class ExternViewInfo extends DbConectionMaker
{
	public function __construct (){

		parent::__construct();

		unset($GLOBALS["path"]);

		$desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

?>

<!DOCTYPE html>
<html lang="de">

<head>

<!--

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

-->

<title>Info</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<?php
 			if (is_array($desei)){
     			   foreach($desei as $data){
        				echo"<link href=\"styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        		}
        	}
  $this->dbObj->close();
?>
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=300">

</head>

<body id="body" style="margin-left: 20px;margin-right: 20px;">

<br>
<strong>
ET-Chat_T-FISH-MOD basiert auf dem ET-Chat V3.0.7 Realease 3 und unterliegt daher auch der License vom ET-Chat!<br><br>

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)<br><br>
</strong>

Der ursprünglich von SEDesign entwickelte ET-Chat, der im Jahr 2019 aufgegeben wurde, wurde von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte) weiterentwickelt und modernisiert.<br><br>

Ein wesentlicher Bestandteil der Überarbeitung war die Anpassung an PHP 8, da der ursprüngliche Code ab PHP 7.4 nicht mehr funktionierte.<br>
Darüber hinaus wurde der Chat um zahlreiche zusätzliche Module und Funktionen erweitert, die nicht im ursprünglichen Standardpaket enthalten waren.<br><br>

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn), Harlekin (Bernd Witte) und Powermen (Christian K.).<br><br>

Mitwirkende:<br>
<ul>

<li><strong>Powermen (Christian K.):</strong> Modulentwicklung - Programmierung - Betreuung</li>
<li><strong>Chrno (Herman):</strong> Modulentwicklung - Programmierung</li>
<li><strong>Micha (Michael Krissel):</strong> Mod-Entwicklung</li>
<li><strong>FizzyLemmon:</strong> Modulentwicklung - Programmierung</li>
<li><strong>Svensken:</strong> Programmierung</li>
<li><strong>Sascha:</strong> Codebereinigung</li>

</ul>
<br><br>
Copyright hinweis verwendeter fremd Code<br><br>

<a href="https://github.com/PHPMailer/PHPMailer?tab=readme-ov-file" target="_blank">Copyright &#169; 2025 PHPMailer, Alle Rechte vorbehalten.</a><br>
<a href="https://codemirror.net/" target="_blank">Copyright &#169; 2025 CodeMirror, Alle Rechte vorbehalten.</a><br>
<a href="https://www.tiny.cloud/get-tiny/" target="_blank">Copyright &#169; 2024 TinyMCE. Alle Rechte vorbehalten.</a><br><br>

<a href="mailto:et-chat-mod@abwesend.de">Anfragen per. E-Mail</a>
<a hidden onclick="window.open('https://www.radio4life.de', '_blank')" style="cursor: pointer" />ET-Chat_T-FISH-MOD Download</a>

<br>

</body>

</html>

<?php

	}
}

// initialise
new ExternViewInfo();

?>