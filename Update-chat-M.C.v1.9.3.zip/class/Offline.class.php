<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Offline extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        // Cache verhindern
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');

        // Session- oder Fallback-Werte
        $username   = $_SESSION['etchat_' . $this->_prefix . 'username'] ?? ($_POST['fallback_username'] ?? '');
        $userId     = $_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0;
        $userPriv   = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'user';
        $userStatus = $_SESSION['etchat_' . $this->_prefix . 'userstatus'] ?? 'status_online';
        $showAvatar = $_SESSION['etchat_' . $this->_prefix . 'chat_pic'] ?? '1';

        // Abbruch bei ung�ltigen Daten
        if ($userId <= 0 || empty($username)) {
            exit;
        }

        // Nur Nachricht senden, wenn sichtbar
        if ($userStatus !== "status_invisible") {
            $color = $this->getUserColor($userPriv);
            $usernameStyled = "<span style=\"$color\"><b>" . htmlentities($username, ENT_QUOTES, "UTF-8") . "</b></span>";
            $message = ($showAvatar === '1' ? $this->getUserAvatarHTML($username) : '') .
                       $usernameStyled . " hat den Tab/Browser geschlossen.";

            new SysMessage($this->dbObj, $message, 0, 0);
        }

        // Benutzer aus Online-Liste entfernen
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = " . (int)$userId);

        // Session beenden
        @session_unset();
        @session_destroy();

        exit;
    }

    private function getUserAvatarHTML(string $username): string
    {
        $escapedUsername = htmlentities($username, ENT_QUOTES, "UTF-8");
        $avatarData = $this->dbObj->sqlGet("SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_username = '$escapedUsername'");
        $avatarFilename = $avatarData[0][0] ?? 'default.png';
        $avatarPath = "avatar/$avatarFilename";

        return '<img src="' . $avatarPath . '" alt="Avatar" class=\"avatar_w\" title=\"\">';
    }

    private function getUserColor($priv): string
    {
        $colorKey = match ($priv) {
            'admin' => 'admin_color',
            'mod'   => 'mod_color',
            'user'  => 'user_color',
            'gast'  => 'gast_color',
            'grafik' => 'admin_color',
            'chatwache' => 'admin_color',
            'co_admin' => 'admin_color',
            default => null,
        };

        return $colorKey ? ("color: " . ($_SESSION['etchat_' . $this->_prefix . $colorKey] ?? '#FFFFFF')) : 'color: #FFFFFF';
    }
}