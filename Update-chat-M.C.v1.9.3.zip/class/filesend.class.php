<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class filesend extends DbConectionMaker
{

   public function __construct (){

      // call parent Constructor from class DbConectionMaker
      parent::__construct();

      session_start();

      header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
      // Sets charset and content-type for index.php
      header('content-type: text/html; charset=utf-8');

         $filedir = 'userpic/'; // Uploadverzeichnis  + Muss CHMOD 777 sein!
            $accepted = array('png', 'jpg', 'jpeg', 'gif');

         $roomId = $_POST['raum'];
         $_POST['textcolor'] = substr($_POST['textcolor'], 0, 7);
         $_POST['textbold'] = substr($_POST['textbold'], 0, 6);
         $_POST['textitalic'] = substr($_POST['textitalic'], 0, 6);
         $fontstyle = "color:" . htmlentities($_POST['textcolor'], ENT_QUOTES, "UTF-8") . ";font-weight:" . htmlentities($_POST['textbold'], ENT_QUOTES, "UTF-8") . ";font-style:" . htmlentities($_POST['textitalic'], ENT_QUOTES, "UTF-8") . ";";


       if (isset($_FILES['file']))
{
                preg_match('/.([a-zA-Z]+?)$/', $_FILES['file']['name'], $matches);
if(in_array(strtolower($matches[1]), $accepted)) {

    // Neuer Dateiname mit Timestamp, verhindert �berschreiben
    $newname = substr(md5_file($_FILES['file']['tmp_name']), 0, 8) 
               . '_' . time() . '.' . $matches[1];

    // Datei auf Server speichern
    move_uploaded_file($_FILES['file']['tmp_name'], $filedir . $newname);

    // MIME-Typ pr�fen
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $filedir . $newname);
    finfo_close($finfo);

    // GIF blockieren wenn zu gro�
    if ($mime === 'image/gif' && filesize($filedir . $newname) > 1500000) {
        unlink($filedir . $newname);
        die('GIF zu gro�. Max. 1,5�MB erlaubt.');
    }

    // JPEG + PNG ggf. resize & compress
    if (in_array($mime, ['image/jpeg', 'image/png'])) {
        $this->resizeImageIfTooLarge($filedir . $newname);         
        $this->compressImageToTargetSize($filedir . $newname);     
    }

    // TXT-Datei mit denselben Namen + .txt
    $username = isset($_SESSION['etchat_' . $this->_prefix . 'username'])
        ? $_SESSION['etchat_' . $this->_prefix . 'username']
        : 'Unbekannt';
    $datum = date('d.m.Y H:i');
    file_put_contents($filedir . $newname . '.txt', $username . '|' . $datum . '|' . $_SERVER['REMOTE_ADDR']);

    // URL f�r Chatnachricht
    $imgurl = ''.preg_replace('/\/([^/]+?)$/', '/', $_SERVER['PHP_SELF']).$filedir. $newname;

    $messageText = '';
    if (!empty($_POST['bildtext'])) {
        $messageText = htmlspecialchars($_POST['bildtext'], ENT_QUOTES, 'UTF-8') . ' ';
    }
    $messageText .= '[img]' . $imgurl . '[/img]';

    $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat, etchat_user_ip)
    VALUES ( '" . $_SESSION['etchat_' . $this->_prefix . 'user_id'] . "', '" . $messageText . "', '" . $fontstyle . "', " . date('U') . ", '" . $roomId . "', '" . (int)$_POST['privat'] . "', '" . $_SERVER['REMOTE_ADDR'] . "')");

    $this->dbObj->close();

 /*
 * Start um alle Dateien zu L�chen die �lter als 4 Tage sind
 */
$files = glob($filedir . '*');
$now = time();
$maxAge = 7 * 24 * 3600; // 7 Tage

foreach ($files as $file) {
    if (is_file($file) && ($now - filemtime($file) > $maxAge)) {
        // �berpr�fe, ob die Dateiendung .php ist
        if (pathinfo($file, PATHINFO_EXTENSION) !== 'php') {
            unlink($file);
        }
    }
}
 /*
 * Ende um alle Dateien zu L�chen die �lter als 1 Stunden sind
 */
      }
   }
}

private function resizeImageIfTooLarge($sourcePath, $maxWidth = 1600, $maxHeight = 900) {
    list($width, $height, $type) = getimagesize($sourcePath);

    // Pr�fen ob resize �berhaupt n�tig ist
    if ($width <= $maxWidth && $height <= $maxHeight) return;

    // Berechne neues Seitenverh�ltnis basierend auf �berschreitung
    $widthRatio  = $width / $maxWidth;
    $heightRatio = $height / $maxHeight;

    // Gr��ere Einschr�nkung entscheidet
    if ($widthRatio > $heightRatio) {
        $newWidth = $maxWidth;
        $newHeight = intval($height / $widthRatio);
    } else {
        $newHeight = $maxHeight;
        $newWidth = intval($width / $heightRatio);
    }

    switch ($type) {
        case IMAGETYPE_JPEG:
            $src = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $src = imagecreatefrompng($sourcePath);
            break;
        default:
            return; // kein Resize f�r andere Typen
    }

    $dst = imagecreatetruecolor($newWidth, $newHeight);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

    if ($type === IMAGETYPE_JPEG) {
        imagejpeg($dst, $sourcePath, 90);
    } elseif ($type === IMAGETYPE_PNG) {
        imagepng($dst, $sourcePath, 6);
    }

    imagedestroy($src);
    imagedestroy($dst);
}


private function compressImageToTargetSize($sourcePath, $maxSizeBytes = 1500000) {
    $info = getimagesize($sourcePath);
    $mime = $info['mime'];

    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($sourcePath);
            $quality = 90;

            do {
                ob_start();
                imagejpeg($image, null, $quality);
                $imageData = ob_get_clean();
                $fileSize = strlen($imageData);
                $quality -= 5;
            } while ($fileSize > $maxSizeBytes && $quality >= 40); // max Kompression

            file_put_contents($sourcePath, $imageData);
            imagedestroy($image);
            break;

        case 'image/png':
            $image = imagecreatefrompng($sourcePath);
            ob_start();
            imagepng($image, null, 6); // Kompressionslevel 0�9
            $imageData = ob_get_clean();
            file_put_contents($sourcePath, $imageData);
            imagedestroy($image);
            break;

        default:
            // GIF oder anderes ? nicht bearbeiten
            break;
    }
}

}

?>
