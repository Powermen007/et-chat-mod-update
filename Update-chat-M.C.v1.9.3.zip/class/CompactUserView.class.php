<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class CompactUserView extends DbConectionMaker
{
	public function __construct() {

	parent::__construct();

$color=$this->dbObj->sqlGet( "SELECT etchat_config_admin_color, etchat_config_mod_color, etchat_config_user_color FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");
$users=$this->dbObj->sqlGet( "SELECT etchat_username, etchat_userprivilegien, etchat_reg_timestamp, etchat_usersex, etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_userprivilegien IN ('mod','admin','user') ORDER BY etchat_user_id DESC LIMIT 5");
$this->dbObj->close();

if (is_array($color)) {

foreach ($color as $colo1) {

$adminc = $colo1[0];
$modc = $colo1[1];
$userc = $colo1[2];
}}

echo '<div class="compact-user-row">';
if (is_array($users)) {

foreach ($users as $user) {

$colors = [
'admin' => $adminc,
'mod'   => $modc,
'user'  => $userc
];

$color = $colors[$user[1]] ?? '#CCCCCC';
$roleName = $this->roleNames[$user[1]] ?? $user[1];
$regDate = date('d.m.Y', strtotime($user[2]));
$gender = $user[3] === 'm' ? 'Männlich' : ($user[3] === 'f' ? 'Weiblich' :  ($user[3] === 'n' ? 'keine Angabe' : ($user[3] === 'd' ? 'Divers' :  '')));

echo <<<HTML
<div class="compact-user-card"
title="Benutzername: {$user[0]}
Geschlecht: {$gender}
Privileg: {$roleName}
Dabei seit: {$regDate}"
style="border-color:{$color}">
<img src="avatar/{$user[4]}" alt="{$user[0]}">
</div>
HTML;


}}
}
}


// Erstelle eine Instanz von ExternUserView
new CompactUserView;

?>