<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminInsertSmilies extends DbConectionMaker
{
public function __construct()
{
    parent::__construct();
    session_start();
    header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
    header("content-type: text/html; charset=utf-8");

    $langObj = new LangXml();
    $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

    $allowedRoles = ["admin", "grafik", "co_admin"];

	if (
	    !isset($_SESSION["etchat_" . $this->_prefix . "user_priv"]) ||
	    !in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], $allowedRoles)
	) {
        echo $lang->error[0]->tagData;
        return false;
    }

    $uploaddir = "./smilies/";

    // Kategorie-Namen filtern (nur alphanumerisch, _, -)
    $catName = preg_replace("/[^a-zA-Z0-9_-]/", "_", $_POST["cat"]);
    $catFolder = $uploaddir . $catName . "/";

    // Ordner anlegen, falls nicht vorhanden
    if (!is_dir($catFolder)) {
        mkdir($catFolder, 0777, true);
    }

    // Dateiname pr�fen und ggf. Zeitstempel anh�ngen
    $originalName = $_FILES["smiliefile"]["name"];
    $targetFile = $catFolder . $originalName;
    $notes = "";

    if (file_exists($targetFile)) {
        $nowname = time() . "_" . $originalName;
        $targetFile = $catFolder . $nowname;
        $notes = $lang->file_exists[0]->tagData . " " . $nowname . "<br>";
    } else {
        $nowname = $originalName;
    }

    // Pr�fen, ob das Zeichen schon existiert
    $res = $this->dbObj->sqlGet(
        "SELECT etchat_smileys_id
         FROM {$this->_prefix}etchat_smileys
         WHERE etchat_smileys_sign = '" . $_POST["sign"] . "'"
    );

    if (is_array($res)) {
        $print_result = $lang->sign_exists[0]->tagData . "<br>";
        $print_result .= "<a href='./?AdminSmiliesIndex'>" . $lang->back[0]->tagData . "</a>";
    } else {
        $is_image = getimagesize($_FILES["smiliefile"]["tmp_name"]);
        if (is_array($is_image)) {
            move_uploaded_file($_FILES["smiliefile"]["tmp_name"], $targetFile);

            // DB-Eintrag erstellen
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_smileys
                (etchat_smileys_kat, etchat_smileys_sign, etchat_smileys_img, etchat_smileys_gewicht)
                VALUES
                ('" . $_POST["cat"] . "', '" . $_POST["sign"] . "', '" . $targetFile . "', '" . $_POST["gw"] . "')"
            );

            $print_result = $lang->isupload[0]->tagData . "<br>" . $notes;
            $print_result .= "<br><a href='./?AdminCreateNewSmilies'>" . $lang->smilie[0]->tagData . "</a>";
            $print_result .= "<br /><a href='./?AdminSmiliesIndex'>" . $lang->back[0]->tagData . "</a>";
        } else {
            @unlink($_FILES["smiliefile"]["tmp_name"]);
            $print_result = $lang->noupload[0]->tagData;
            $print_result .= "<br /><br /><a href='./?AdminSmiliesIndex'>" . $lang->back[0]->tagData . "</a>";
        }
    }

    include_once "styles/admin_tpl/insertSmiliesMessage.tpl.html";
}

}

?>
