<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUserIndex extends DbConectionMaker
{

    public function __construct (){

        parent::__construct();

        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang=$langObj->getLang()->admin[0]->admin_user[0];

        if (in_array($_SESSION['etchat_' . $this->_prefix . 'user_priv'], ["admin", "chatwache", "co_admin"])) {

            if (!isset($_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"])) {
                $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] = rand(1, 999999999);
            }

            $roles = ["admin", "mod", "grafik", "chatwache", "co_admin"];
            $rolesList = "'" . implode("','", $roles) . "'";

            // Sortierung bestimmen
            $sort = $_GET['sort'] ?? 'username'; // Standard: username
            switch ($sort) {
                case 'reg':
                    $orderBy = "etchat_reg_timestamp DESC";
                    break;
                case 'login':
                     $orderBy = "(etchat_logintime = 0), etchat_logintime DESC";
                    break;
                case 'username':
                default:
                    $orderBy = "etchat_username ASC";
                    break;
            }

            $sql = "SELECT
                        etchat_user_id,
                        etchat_username,
                        etchat_userpw,
                        etchat_userprivilegien,
                        etchat_reg_timestamp,
                        etchat_reg_ip,
                        etchat_logintime,
                        etchat_avatar,
                        etchat_email,
                        etchat_last_ip
                    FROM {$this->_prefix}etchat_user
                    WHERE etchat_userprivilegien IN ($rolesList)
                    ORDER BY $orderBy";

            $feld = $this->dbObj->sqlGet($sql);
            $this->dbObj->close();

            // Auswahlmen� oberhalb der Tabelle
            $print_user_list = '<form method="get" action="">
			    <input type="hidden" name="AdminUserIndex" value="">
			    <label for="sort">Sortieren nach: </label>
			    <select name="sort" id="sort" onchange="this.form.submit()">
			        <option value="username" '.(($sort=="username") ? "selected" : "").'>Username</option>
			        <option value="reg" '.(($sort=="reg") ? "selected" : "").'>Registrierungsdatum</option>
			        <option value="login" '.(($sort=="login") ? "selected" : "").'>Letzter Login</option>
			    </select>
			</form><br>';

            if (is_array($feld)){
                $print_user_list.="<table><tr>
                    <td><b>".$lang->name[0]->tagData."</b></td>
                    <td><b>".$lang->status[0]->tagData."</b></td><td>&nbsp;</td>
                    <td><b>".$lang->reg_date[0]->tagData."</b></td><td>&nbsp;</td>
                    <td><b>".$lang->reg_ip[0]->tagData."</b></td><td>&nbsp;</td>
                    <td><b>".$lang->login[0]->tagData."</b></td><td>&nbsp;</td>
                    <td><b>letzte IP</b></td><td>&nbsp;</td>
                    <td><b>E-Mail</b></td><td>&nbsp;</td><td>&nbsp;</td></tr>";

                foreach($feld as $datasets) {
                    $print_user_list.="<tr>
                        <td><a href=\"./?AdminEditUser&id=".$datasets[0]."\">".$datasets[1]."</a></td>
                        <td>(<i>".$datasets[3]."</i>)</td><td>&nbsp;</td>
                        <td>".$datasets[4]."</td><td>&nbsp;</td>
                        <td>".$datasets[5]."</td><td>&nbsp;</td>
                        <td>".date("d.m.Y-H:i",$datasets[6])."</td><td>&nbsp;</td>
                        <td>".$datasets[9]."</td><td>&nbsp;</td>
                        <td><a href=\"mailto:".$datasets[8]."\">".$datasets[8]."</a></td><td>&nbsp;</td>
                        <td><a href=\"./?AdminDeleteAvatar&delavatar&cs4rue=".$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit']."&id=".$datasets[0]."\" onclick=\"return confirm('Bist du sicher, dass du diesen Avatar wirklich l&ouml;schen m&ouml;chtest?')\">L&ouml;sche Avatar</a>&nbsp; &nbsp; <img src=\"avatar/$datasets[7]\" width=\"16\" height=\"16\"></td>
                    </tr>";
                }

                $print_user_list.="</table>";
            } else {
                $print_user_list=$lang->noadmins[0]->tagData;
            }

            $this->initTemplate($lang, $print_user_list);

        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }

    private function initTemplate($lang, $print_user_list){
        include_once("styles/admin_tpl/indexUser.tpl.html");
    }
}

