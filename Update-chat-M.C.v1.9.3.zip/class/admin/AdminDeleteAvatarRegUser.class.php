<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminDeleteAvatarRegUser extends DbConectionMaker
{


	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');


		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_reg_user[0];

		if (in_array($_SESSION['etchat_' . $this->_prefix . 'user_priv'], ["admin", "chatwache", "co_admin"])) {

				if($_GET['cs4rue']!=$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] || !isset($_GET['cs4rue']) || !isset($_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'])){
					echo "Dear Admin this User tried to fake you. ;-)";
					$this->dbObj->close();
					return false;
				}

				if (isset($_GET['delavatar']) && isset($_GET['id'])) {
					$filedir = 'avatar'; // Uploadverzeichnis + Muss CHMOD 777 sein!
					$avatarfile = $this->dbObj->sqlGet("SELECT etchat_avatar FROM {$this->_prefix}etchat_user where etchat_user_id = ".(int)$_GET['id']);
					if ($avatarfile[0][0] != "noavatar.jpg" AND $avatarfile[0][0] != "mod_ohne_pic.png" AND $avatarfile[0][0] != "autodj.jpg") {
					$delfile = $filedir."/".$avatarfile[0][0];
					unlink($delfile);
					}
						$this->dbObj->sqlSet("update {$this->_prefix}etchat_user set etchat_avatar='noavatar.jpg' WHERE etchat_user_id = ".(int)$_GET['id']);
						}
			$this->dbObj->close();
			header("Location: ./?AdminRegUserIndex");



		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
