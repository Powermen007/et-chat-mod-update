<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminSpracheBearbeiten extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        // Style + Sprache aus DB holen (robust gegen numerische / assoziative Keys)
        $desei = $this->dbObj->sqlGet("
            SELECT etchat_config_id, etchat_config_style, etchat_config_lang
            FROM {$this->_prefix}etchat_config
            WHERE etchat_config_id = '1'
        ");

        if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] !== "admin") {
            die("Zugriff verweigert.");
        }

        $this->zeigeSpracheEditor($desei);
    }

    private function zeigeSpracheEditor($desei)
    {
        // Standard: fallback Sprachdatei
        $langFile = 'lang_de.xml';
        $styles = [];

        if (is_array($desei)) {
            foreach ($desei as $data) {
                // Sprache (pr�fe assoziativ und numerisch)
                $langCandidate = $data['etchat_config_lang'] ?? $data[2] ?? '';
                if (!empty($langCandidate) && file_exists(__DIR__ . '/../../lang/' . $langCandidate)) {
                    $langFile = $langCandidate;
                }

                // Style (pr�fe assoziativ und numerisch)
                $styleCandidate = $data['etchat_config_style'] ?? $data[1] ?? '';
                if (!empty($styleCandidate)) {
                    $styles[] = $styleCandidate;
                }
            }
        }

        // Einmalig unique machen
        $styles = array_values(array_unique($styles));

        $path = __DIR__ . '/../../lang/' . $langFile;
        if (!file_exists($path)) {
            die("XML nicht gefunden: $path");
        }

        $xml = simplexml_load_file($path);
        if (!$xml) {
            die("Fehler beim Laden der XML.");
        }

        // --- Backup-L�sch-Handling (POST vom Button) ---
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_backups'])) {
            $backupDir = __DIR__ . '/../../lang/old/';
            // nur Backups f�r die aktuell gew�hlte Sprachdatei l�schen (sicherer)
            $pattern = $backupDir . basename($langFile) . '.bak.*';
            if (is_dir($backupDir)) {
                $files = glob($pattern);
                // sortiere nach Zeit (neueste zuerst)
                usort($files, function($a, $b) {
                    return filemtime($b) - filemtime($a);
                });
                // l�sche alles au�er die 3 neuesten
                $toDelete = array_slice($files, 3);
                foreach ($toDelete as $f) {
                    @unlink($f);
                }
                echo "<p style='color:green;'>Alte Sicherungen wurden gel&ouml;scht (nur die letzten 3 behalten).</p>";
            } else {
                echo "<p style='color:orange;'>Backup-Ordner nicht gefunden: " . htmlspecialchars($backupDir) . "</p>";
            }
        }

        // --- HTML Ausgabe ---
        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="utf-8">
            <title>Sprache bearbeiten</title>
            <?php
            // Stylesheets einbinden
            foreach ($styles as $s) {
                echo '<link href="styles/' . htmlspecialchars($s) . '/style.css" rel="stylesheet" type="text/css">';
            }
            // DB schlie�en
            $this->dbObj->close();

            // Anzahl Backups z�hlen
			$backupDir = __DIR__ . '/../../lang/old/';
			$backupCount = 0;
			if (is_dir($backupDir)) {
			    $pattern = $backupDir . basename($langFile) . '.bak.*';
			    $files = glob($pattern);
			    if ($files !== false) {
			        $backupCount = count($files);
			    }
			}
           ?>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="robots" content="noindex, nofollow">
        </head>
        <body id="adminbereich_body">
            <a href="./?AdminIndex" style="cursor:pointer;">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml;</a>
            <hr>

            <h2>Sprache bearbeiten (<?php echo htmlspecialchars($langFile, ENT_QUOTES, 'UTF-8'); ?>)</h2>
            <p>Es wird automatisch eine Sicherung im Ordner <strong>old</strong> angelegt.
            <br>(Es sind <?php echo $backupCount; ?> Sicherungen vorhanden)</p>

            <form method="post" style="display:inline;" class="top-actions">
                <input type="hidden" name="delete_backups" value="1">
                <input type="submit" value="Sicherungen l&ouml;schen (nur 3 neueste behalten)">
            </form>

            <br><br>

            <?php
            // Bereichsauswahl (GET)
            echo '<form method="get">';
            echo '<input type="hidden" name="AdminSpracheBearbeiten" value="">';
            echo '<label for="bereich">Bereich ausw&auml;hlen:</label> ';

// Nur Top-Level-Bereiche (oberste Tags im XML) anzeigen
$bereiche = [];
foreach ($xml as $key => $child) {
    $bereiche[$key] = $child;
}
$bereich = $_GET['bereich'] ?? (count($bereiche) ? array_key_first($bereiche) : '');



            echo '<select name="bereich" onchange="this.form.submit()">';
            foreach ($bereiche as $pfad => $_knoten) {
                $selected = ($bereich === $pfad) ? 'selected' : '';
                echo '<option value="' . htmlspecialchars($pfad, ENT_QUOTES, 'UTF-8') . '" ' . $selected . '>' . htmlspecialchars($pfad, ENT_QUOTES, 'UTF-8') . '</option>';
            }
            echo '</select>';
            echo '</form><hr>';

            // Bearbeitungsformular (POST -> AdminSpracheSpeichern)
            echo '<form method="post" action="./?AdminSpracheSpeichern">';
            echo '<input type="hidden" name="bereich" value="' . htmlspecialchars($bereich, ENT_QUOTES, 'UTF-8') . '">';
            echo '<input type="hidden" name="lang_file" value="' . htmlspecialchars($langFile, ENT_QUOTES, 'UTF-8') . '">';

            // Zielknoten anhand des Pfads finden
            $teile = array_values(array_filter(explode('/', (string)$bereich), 'strlen'));
            $ziel = $xml;
            foreach ($teile as $teil) {
                if (isset($ziel->{$teil})) {
                    // Falls mehrere gleiche Tags existieren, nehmen wir das erste
                    $ziel = $ziel->{$teil};
                } else {
                    die("Ung�ltiger Bereichspfad: " . htmlspecialchars($bereich, ENT_QUOTES, 'UTF-8'));
                }
            }

            // Knoten anzeigen
            $this->zeigeKnoten($ziel);

            echo '<input type="submit" value="&Auml;nderungen speichern">';
            echo '</form>';
            ?>
        </body>
        </html>
        <?php
    }

private function zeigeKnoten($node, $prefix = '')
{
    // Anzahl Vorkommen pro Tagname auf dieser Ebene ermitteln
    $counts = [];
    foreach ($node as $k => $v) {
        $counts[$k] = ($counts[$k] ?? 0) + 1;
    }

    // Laufende Indizes pro Tagname (0-basierend)
    $indexCounter = [];

    foreach ($node as $key => $value) {
        $idx = $indexCounter[$key] ?? 0;
        $indexCounter[$key] = $idx + 1;

        $hasMultiple = ($counts[$key] ?? 0) > 1;
        // Pfad-Teil: nur mit _Index wenn mehrfach vorhanden
        $pathKey = $key . ($hasMultiple ? '_' . $idx : '');
        $pfad = $prefix . $pathKey;

        $children = $value->children();
        if (count($children) > 0) {
            // Lesbarer Legenden-Text (ohne die Index-Suffix bei Anzeige)
            $legend = htmlspecialchars($key, ENT_QUOTES, 'UTF-8') . ($hasMultiple ? ' [' . ($idx + 1) . ']' : '');
            echo "<fieldset><legend>{$legend}</legend>";
            // beim Rekursions-Pfad bleibt der Index-Teil erhalten, damit die Namen eindeutig sind
            $this->zeigeKnoten($value, $pfad . '/');
            echo "</fieldset>";
        } else {
            // Attribute im Label anzeigen (z.B. imagename, rights)
            $attrString = '';
            foreach ($value->attributes() as $aName => $aVal) {
                $attrString .= ' [' . htmlspecialchars($aName, ENT_QUOTES, 'UTF-8') . '=' .
                               htmlspecialchars((string)$aVal, ENT_QUOTES, 'UTF-8') . ']';
            }

            $feldname = $pfad; // eindeutig und deterministisch, z.B. "start_prop_link_0" oder "avatar_text"
            $inhalt = htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');

            echo "<label>" . htmlspecialchars($key, ENT_QUOTES, 'UTF-8') . $attrString . "</label><br>";
            echo "<input type=\"text\" name=\"eintraege[" . htmlspecialchars($feldname, ENT_QUOTES, 'UTF-8') . "]\" value=\"" .
                 $inhalt . "\" style=\"width:100%;\"><br><br>";
        }
    }
}





    private function ermittleAlleBereiche($node, $prefix = '')
    {
        $result = [];
        $hasChildren = false;

        foreach ($node as $key => $child) {
            $pfad = ($prefix === '') ? $key : "$prefix/$key";
            if (count($child->children()) > 0) {
                // rekursiv zusammenf�hren
                $result += $this->ermittleAlleBereiche($child, $pfad);
                $hasChildren = true;
            }
        }

        if (!$hasChildren && $prefix !== '') {
            // leaf: prefix ist der vollst�ndige Pfad
            $result[$prefix] = $node;
        }

        return $result;
    }
}