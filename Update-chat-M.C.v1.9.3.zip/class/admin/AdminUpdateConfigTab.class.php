<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateConfigTab extends DbConectionMaker
{
    public function __construct (){

        parent::__construct();

        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang=$langObj->getLang()->admin[0]->admin_prop[0];

        if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "co_admin"])) {

            $updates = [];

            // Hilfsfunktion f�r sichere Werte
            $escape = fn($v) => $this->dbObj->escape(trim($v));

            // === TEXTFELDER ===
            if (isset($_POST['radio_name']))       $updates[] = "etchat_config_radio_name = '".$escape($_POST['radio_name'])."'";
            if (isset($_POST['style']))            $updates[] = "etchat_config_style = '".$escape($_POST['style'])."'";
            if (isset($_POST['lang']))             $updates[] = "etchat_config_lang = '".$escape($_POST['lang'])."'";
            if (isset($_POST['radio_box_li']))     $updates[] = "etchat_config_radio_box_li = '".$escape($_POST['radio_box_li'])."'";
            if (isset($_POST['radio_wb_li']))      $updates[] = "etchat_config_wb_li = '".$escape($_POST['radio_wb_li'])."'";
            if (isset($_POST['list_user_online'])) $updates[] = "etchat_config_user_online = '".$escape($_POST['list_user_online'])."'";
            if (isset($_POST['vb']))               $updates[] = "etchat_config_vollbild = '".$escape($_POST['vb'])."'";
            if (isset($_POST['c_admin']))          $updates[] = "etchat_config_admin_color = '".$escape($_POST['c_admin'])."'";
            if (isset($_POST['c_mod']))            $updates[] = "etchat_config_mod_color = '".$escape($_POST['c_mod'])."'";
            if (isset($_POST['c_user']))           $updates[] = "etchat_config_user_color = '".$escape($_POST['c_user'])."'";
            if (isset($_POST['c_gast']))           $updates[] = "etchat_config_gast_color = '".$escape($_POST['c_gast'])."'";
            if (isset($_POST['zeit']))             $updates[] = "etchat_config_time = '".$escape($_POST['zeit'])."'";
            if (isset($_POST['gender']))           $updates[] = "etchat_config_chat_gender = '".$escape($_POST['gender'])."'";
            if (isset($_POST['privi']))            $updates[] = "etchat_config_chat_privi = '".$escape($_POST['privi'])."'";
            if (isset($_POST['privi-ol']))         $updates[] = "etchat_config_ol_privi = '".$escape($_POST['privi-ol'])."'";
            if (isset($_POST['pic_ben_info']))     $updates[] = "etchat_config_be_in_pic = '".$escape($_POST['pic_ben_info'])."'";
            if (isset($_POST['pic_chat']))         $updates[] = "etchat_config_chat_pic = '".$escape($_POST['pic_chat'])."'";
            if (isset($_POST['sc']))               $updates[] = "etchat_config_scroll = '".$escape($_POST['sc'])."'";
            if (isset($_POST['radio_dj_box_li']))  $updates[] = "etchat_config_dj_box_li = '".$escape($_POST['radio_dj_box_li'])."'";
            if (isset($_POST['radio_sendeplan_li'])) $updates[] = "etchat_config_radio_se_li = '".$escape($_POST['radio_sendeplan_li'])."'";

            // === ZAHLENFELDER (werden gecastet) ===
            if (isset($_POST['wartung']))       $updates[] = "etchat_config_wartung = ".(int)$_POST['wartung'];
            if (isset($_POST['gast_zugang']))   $updates[] = "etchat_config_gast = ".(int)$_POST['gast_zugang'];
            if (isset($_POST['reg_an_aus']))    $updates[] = "etchat_config_reg_an_aus = ".(int)$_POST['reg_an_aus'];
            if (isset($_POST['reload']))        $updates[] = "etchat_config_reloadsequenz = ".(int)$_POST['reload'];
            if (isset($_POST['anz_mess']))      $updates[] = "etchat_config_messages_im_chat = ".(int)$_POST['anz_mess'];
            if (isset($_POST['loeschen_nach'])) $updates[] = "etchat_config_loeschen_nach = ".(int)$_POST['loeschen_nach'];
            if (isset($_POST['wu']))            $updates[] = "etchat_config_wu = ".(int)$_POST['wu'];
            if (isset($_POST['wuan']))          $updates[] = "etchat_config_wuan = ".(int)$_POST['wuan'];
            if (isset($_POST['wuza']))          $updates[] = "etchat_config_wuza = ".(int)$_POST['wuza'];
            if (isset($_POST['wupau']))         $updates[] = "etchat_config_wupau = ".(int)$_POST['wupau'];
            if (isset($_POST['yo']))            $updates[] = "etchat_config_yo = ".(int)$_POST['yo'];
            if (isset($_POST['bi']))            $updates[] = "etchat_config_bi = ".(int)$_POST['bi'];
            if (isset($_POST['biup']))          $updates[] = "etchat_config_biup = ".(int)$_POST['biup'];
            if (isset($_POST['av']))            $updates[] = "etchat_config_av = ".(int)$_POST['av'];
            if (isset($_POST['pro']))           $updates[] = "etchat_config_pro = ".(int)$_POST['pro'];
            if (isset($_POST['online_li']))     $updates[] = "etchat_config_onlie_li = ".(int)$_POST['online_li'];
            if (isset($_POST['radio_box']))     $updates[] = "etchat_config_radio_box = ".(int)$_POST['radio_box'];
            if (isset($_POST['radio_box_hi']))  $updates[] = "etchat_config_radio_box_hi = ".(int)$_POST['radio_box_hi'];
            if (isset($_POST['radio_wb']))      $updates[] = "etchat_config_wb = ".(int)$_POST['radio_wb'];
            if (isset($_POST['name_user_online'])) $updates[] = "etchat_config_name_user = ".(int)$_POST['name_user_online'];
            if (isset($_POST['name_user_anz'])) $updates[] = "etchat_config_name_user_anz = ".(int)$_POST['name_user_anz'];
            if (isset($_POST['chat_anzsmily'])) $updates[] = "etchat_config_chat_anzsmily = ".(int)$_POST['chat_anzsmily'];
            if (isset($_POST['radio_dj_box']))  $updates[] = "etchat_config_dj_box = ".(int)$_POST['radio_dj_box'];
            if (isset($_POST['radio_sendeplan'])) $updates[] = "etchat_config_radio_se = ".(int)$_POST['radio_sendeplan'];
            if (isset($_POST['reg_user_an']))   $updates[] = "etchat_config_reg_user_an = ".(int)$_POST['reg_user_an'];

            // === UPDATE nur wenn es Felder gibt ===
            if (!empty($updates)) {
                $sql = "UPDATE {$this->_prefix}etchat_config SET ".implode(", ", $updates)." WHERE etchat_config_id = 1";
                $this->dbObj->sqlSet($sql);
            }

            $this->dbObj->close();
            header("Location: ./?AdminPropertyIndex");

        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }
}

