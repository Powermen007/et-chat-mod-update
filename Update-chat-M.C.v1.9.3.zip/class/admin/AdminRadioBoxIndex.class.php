<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminRadioBoxIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$langData = $langObj->getLang();

		if (isset($langData->admin[0]->admin_menus[0])) {
			$lang = $langData->admin[0]->admin_menus[0];
		} else {
			$lang = (object)[ 'error' => [ (object)[ 'tagData' => 'Fehler: Sprachdatei unvollständig.' ] ] ];
		}

if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "co_admin"])) {

    $_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] = rand(1,999999999);

    // Hole ALLE Radios, nicht nur ID=1
    $feld = $this->dbObj->sqlGet("SELECT etchat_radio_id, etchat_radio_horst, etchat_radio_port, etchat_radio_typ, etchat_radio_stream, etchat_radio_name, etchat_radio_color, etchat_radio_bit, etchat_radio_box, etchat_radio_player 
                                   FROM {$this->_prefix}etchat_radio_box 
                                   ORDER BY etchat_radio_id ASC");
    $this->dbObj->close();

    if (is_array($feld) && count($feld) > 0) {
        $print_text_list  = "<table border='1' cellpadding='5' cellspacing='0'>";
        $print_text_list .= "<tr>
            <th>ID</th>
            <th>Radiobox</th>
            <th>Horst</th>
            <th>Admin Port</th>
            <th>Radio Typ</th>
            <th>Bit Rate</th>
            <th>Radioplayer</th>
            <th>Stream Adresse</th>
            <th>Name</th>
            <th>Aktion</th>
        </tr>";

        foreach($feld as $datasets) {
            $print_text_list.= "<tr>
                <td><b>".$datasets[0]."</b></td>
                <td>".$datasets[8]."</td>
                <td>".$datasets[1]."</td>
                <td>".$datasets[2]."</td>
                <td>".$datasets[3]."</td>
                <td>".$datasets[7]."</td>
                <td>".$datasets[9]."</td>
                <td>".$datasets[4]."</td>
                <td>".$datasets[5]."</td>";

            // Aktion je nach Rolle
            if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] === "admin") {
                $print_text_list.= "<td><b><a href=\"./?AdminEditRadioBox&id=".$datasets[0]."\">Editieren</a></b></td>";
            } else {
                $print_text_list.= "<td><i>Keine Rechte</i></td>";
            }

            $print_text_list.= "</tr>";
        }

        $print_text_list.= "</table>";
    } else {
        $print_text_list = "<p>Keine Radioboxen gefunden.</p>";
    }

    $this->initTemplate($lang, $print_text_list);

} else {
    echo $lang->error[0]->tagData;
    return false;
}

	}

	private function initTemplate($lang, $print_text_list){
		// Include Template
		include_once("styles/admin_tpl/indexRadioBox.tpl.html");
	}
}
