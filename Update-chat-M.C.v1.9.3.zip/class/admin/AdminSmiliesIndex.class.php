<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminSmiliesIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();
        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

// --- Ajax-Handler: Speichern der neuen Sortierung ---
if (isset($_GET["SaveSmileyOrder"])) {

    // Rechtepr�fung: nur Admin
$allowedRoles = ["admin", "grafik", "co_admin"];

if (
    !isset($_SESSION["etchat_" . $this->_prefix . "user_priv"]) ||
    !in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], $allowedRoles)
) {
    echo "Keine Rechte oder Session abgelaufen.";
    exit;
}


    $pro_seite = 30;

    $json = file_get_contents("php://input");
    $data = json_decode($json, true);

    if (!is_array($data) || empty($data)) {
        echo "Fehlerhafte Daten";
        exit;
    }

    // Pr�fen: Kategorie muss gesetzt sein
    $kat  = isset($data['kat']) ? (string)$data['kat'] : '';
    $site = isset($data['site']) ? max(1, (int)$data['site']) : 1;
    $ids  = isset($data['ids']) && is_array($data['ids']) ? $data['ids'] : [];

    if ($kat === '') {
        echo "Speichern nur m�glich, wenn eine Kategorie ausgew�hlt ist.";
        exit;
    }

    if (empty($ids)) {
        echo "Keine Smileys zum Speichern gefunden.";
        exit;
    }

    // Startgewicht je Seite
    $offset  = ($site - 1) * $pro_seite;
    $gewicht = ($offset * 5) + 5;

    foreach ($ids as $id) {
        $id = (int)$id;
        $sql = "
            UPDATE {$this->_prefix}etchat_smileys
            SET etchat_smileys_gewicht = $gewicht
            WHERE etchat_smileys_id = $id
            AND etchat_smileys_kat = '" . addslashes($kat) . "'
        ";
        $this->dbObj->sqlSet($sql);
        $gewicht += 5;
    }

    echo "Gespeichert";
    exit;
}
// --- Ende Ajax-Handler ---



			 if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "co_admin"])) {

            // Kategorie w�hlen
            $kategorie = isset($_GET['kat']) ? $_GET['kat'] : '';
            $where = '';
            if (!empty($kategorie)) {
                $where = "WHERE etchat_smileys_kat = '" . addslashes($kategorie) . "'";
            }

            // Alle Kategorien
            $alle_kategorien = $this->dbObj->sqlGet("SELECT DISTINCT etchat_smileys_kat FROM {$this->_prefix}etchat_smileys ORDER BY etchat_smileys_kat ASC");

            // Dropdown
            $print_smil_list4 = "<form method='get' action=''>\n";
            $print_smil_list4 .= "<input type='hidden' name='AdminSmiliesIndex' value='1'>\n";
            $print_smil_list4 .= "<select name='kat' onchange='this.form.submit()'>\n";
            $print_smil_list4 .= "<option value=''>Alle Kategorien</option>\n";
            if (is_array($alle_kategorien)) {
                foreach ($alle_kategorien as $kat_row) {
                    $selected = ($kategorie == $kat_row[0]) ? " selected" : "";
                    $print_smil_list4 .= "<option value='" . htmlspecialchars($kat_row[0]) . "'$selected>" . htmlspecialchars($kat_row[0]) . "</option>\n";
                }
            }
            $print_smil_list4 .= "</select>\n";
            $print_smil_list4 .= "</form>\n";

            $print_smil_list3 = '';
            $print_smil_list2 = '';
            $print_smil_list  = '';

            // Anzahl
            $countQuery = "SELECT count(etchat_smileys_id) FROM {$this->_prefix}etchat_smileys $where";
            $counted = $this->dbObj->sqlGet($countQuery);
            $counted2 = " ".$counted[0][0]." Smileys gefunden<br>";

            if (empty($_GET['site'])) $_GET['site']=1;
            $pro_seite = 30;
            $site=intval($_GET['site'])-1;
            $von = $site*$pro_seite;
            if ($this->_usedDatabase == "mysql") $limit = "LIMIT $von, $pro_seite";

            // Smileys abrufen
            $feld = $this->dbObj->sqlGet("
                SELECT * FROM {$this->_prefix}etchat_smileys
                $where
                ORDER BY etchat_smileys_kat, etchat_smileys_gewicht, etchat_smileys_sign ASC
                $limit
            ");
            $this->dbObj->close();

            // Pagination
            $sitemakerObj = new Sitemaker($pro_seite, $counted[0][0]);
            $sitemakerObj->href=true;
            $katQuery = ($kategorie !== '') ? '&kat=' . urlencode($kategorie) : '';
            $sitemakerObj->make($_GET['site'], "./?AdminSmiliesIndex&site=#site#" . $katQuery, $lang->site[0]->tagData, $lang->site_of[0]->tagData);
            $print_sitemaker = $sitemakerObj->get();

            $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] = rand(1, 999999999);

            $print_smil_list3 .= "$counted2";
            $print_smil_list2 .= "$print_sitemaker";

            // Tabellenzeilen
            if (is_array($feld)) {
                $i = 0;
                foreach ($feld as $datasets) {
                    $i++;
                    $bgcolor = ($i % 2 == 0) ? "class=\"ungerade\"" : "class=\"gerade\"";

                    $print_smil_list .= "<tr $bgcolor draggable='true' data-id='" . $datasets[0] . "' data-kat='" . htmlspecialchars($datasets[1]) . "'>\r\n
                    	\t\t\t\t\t<td align='center'><img class='img_verschieben'  src='./img/verschieben.png' border='0'></td>\r\n
						\t\t\t\t\t<td align='center'><img class='img_smiley'  src='./" . $datasets[3] . "' border='0'></td>\r\n
						\t\t\t\t\t<td >" . $datasets[2] . "</td>\r\n
						\t\t            <td >" . $datasets[1] . "</td>\r\n
						\t\t\t\t\t<td >\r\n
						\t\t\t\t\t<a href=\"./?AdminRenameSmilies&id=" . $datasets[0] . "\">" . $lang->rename[0]->tagData . "</a>\r\n
						\t\t\t\t\t</td>\r\n
						\t\t\t\t\t<td >\r\n
						\t\t\t\t\t<a href=\"./?AdminDeleteSmilies&id=" . $datasets[0] . "&pic=" . $datasets[3] . "&cs4rue=" . $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] . "\" onclick=\"return confirm('Bist du sicher, dass du dieses Smiley wirklich löschen möchtest?')\">" . $lang->delete[0]->tagData . "</a>\r\n
						\t\t\t\t\t</td>\r\n
						\t\t\t\t\t<td >" . $datasets[4] . "</td>
					</tr>";
                }
            }

            // Speichern-Button
            if (!empty($kategorie)) {
    // Kategorie gew�hlt ? Button aktiv
    $print_smil_list2 .= "<button id='saveSmileyBtn' type='button' onclick='saveOrder()' style='margin-left: 50px;'>Neue Reihenfolge speichern</button>";
} else {
    // Alle Kategorien ? Button deaktiviert
    $print_smil_list2 .= "<button id='saveSmileyBtn' type='button' disabled style='margin-left: 50px;' title='Speichern nur bei ausgew�hlter Kategorie m�glich'>Neue Reihenfolge speichern</button>";
}


            $this->initTemplate($lang, $print_smil_list2, $print_smil_list, $print_smil_list3, $print_smil_list4);
        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }

    private function initTemplate($lang, $print_smil_list2, $print_smil_list, $print_smil_list3, $print_smil_list4)
    {
        include_once "styles/admin_tpl/indexSmilies.tpl.html";
    }
}

