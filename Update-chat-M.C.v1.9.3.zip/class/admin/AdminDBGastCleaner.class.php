<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminDBGastCleaner extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Content-Type: text/html; charset=utf-8');

        $allowedRoles = ["admin", "chatwache", "co_admin"];

        if (!in_array($_SESSION['etchat_' . $this->_prefix . 'user_priv'], $allowedRoles)) {
            echo "Keine Berechtigung.";
            exit;
        }

        if (!isset($_SESSION['etchat_' . $this->_prefix . 'CheckSum4RegUserEdit'])) {
            $_SESSION['etchat_' . $this->_prefix . 'CheckSum4RegUserEdit'] = rand(100000, 999999);
        }
        $checksum = $_SESSION['etchat_' . $this->_prefix . 'CheckSum4RegUserEdit'];

        if (isset($_GET['action'])) {
            if ($_GET['cs4rue'] != $checksum) {
                echo "Manipulationsversuch erkannt.";
                exit;
            }

            if ($_GET['action'] === 'delete' && isset($_GET['id'])) {
                $id = (int)$_GET['id'];
                $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_user WHERE etchat_user_id=$id AND etchat_userprivilegien='gast'");
            }

            if ($_GET['action'] === 'delete_all') {
                $threshold = time() - 600; // 10 Minuten
                $this->dbObj->sqlSet("
                    DELETE u FROM {$this->_prefix}etchat_user u
                    LEFT JOIN {$this->_prefix}etchat_useronline uo
                    ON uo.etchat_onlineuser_fid = u.etchat_user_id
                    WHERE u.etchat_userprivilegien='gast'
                      AND (uo.etchat_onlinetimestamp IS NULL OR uo.etchat_onlinetimestamp < $threshold)
                ");
            }

            header("Location: ./?AdminDBGastCleaner");
            exit;
        }

        $guests = $this->dbObj->sqlGet("SELECT u.etchat_user_id,
                                               u.etchat_username,
                                               u.etchat_logintime,
                                               u.etchat_last_ip,
                                               uo.etchat_onlinetimestamp
                                        FROM {$this->_prefix}etchat_user u
                                        LEFT JOIN {$this->_prefix}etchat_useronline uo
                                        ON uo.etchat_onlineuser_fid = u.etchat_user_id
                                        WHERE u.etchat_userprivilegien = 'gast'
                                        ORDER BY u.etchat_username ASC");

        $this->dbObj->close();

        echo '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>G�steverwaltung</title><link href="styles/';
            echo $_SESSION['etchat_'.$this->_prefix.'style'];
        echo '/style.css" rel="stylesheet" type="text/css"/>
            <style>
                .online { color: green; }
                .offline { color: red; }
            </style>
        </head>
        <body id="adminbereich_body">';

        // Rollen ermitteln
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        // Links f�r jede Rolle definieren
        $roleLinks = [
            "admin"     => "./?AdminIndex",
            "grafik"    => "./?AdminIndexGrafik",
            "co_admin"  => "./?AdminIndexCoAdmin",
            "chatwache" => "./?AdminIndexChatwache"
        ];

        // Link setzen, Standard-Link falls Rolle unbekannt
        $backlinkUrl = $roleLinks[$role] ?? "./";

        // Ausgabe Backlink (WICHTIG: doppelte Anf�hrungszeichen f�r Variablenersetzung!)
        echo "<a href=\"$backlinkUrl\"><<< zur&uuml;ck zum Adminmen&uuml;</a><hr size=\"1\">";

        echo "G&auml;steverwaltung:<br><br>";

        if (is_array($guests) && count($guests) > 0) {
            echo '<table>
                    <tr>
                        <th>Benutzername</th>
                        <th style="width: 60px">Status</th>
                        <th style="width: 75px">Aktion</th>
                        <th style="width: 150px">Login Zeit</th>
                        <th style="width: 100px">Last. IP</th>
                    </tr>';
            foreach ($guests as $guest) {
                $onlineStatus = 'Offline';
                $statusClass = 'offline';

                $threshold = time() - 600;
                if (isset($guest[5]) && $guest[5] >= $threshold) {
                    $onlineStatus = 'Online';
                    $statusClass = 'online';
                }

                echo '<tr>
                        <td>' . htmlspecialchars($guest[1]) . '</td>
                        <td class="' . $statusClass . '">' . $onlineStatus . '</td>
                        <td><a href="?AdminDBGastCleaner&action=delete&id=' . $guest[0] . '&cs4rue=' . $checksum . '" onclick="return confirm(\'Diesen Gast wirklich löschen?\')">L&ouml;schen</a></td>
                        <td>' . (is_numeric($guest[2]) ? date("d. F Y H:i", (int)$guest[2]) : '') . '</td>
                        <td>' . htmlspecialchars($guest[3]) . '</td>
                    </tr>';
            }
            echo '</table><br>
                  <a onclick="if(confirm(\'Wirklich ALLE offline G&auml;ste löschen?\')) { self.location.href=\'?AdminDBGastCleaner&action=delete_all&cs4rue=' . $checksum . '\'; }" class="button">ALLE offline G&auml;ste l&ouml;schen</a><br><br>
                  <hr size="1">
                  Diese administrative &Auml;nderung ist sofort sichtbar.';
        } else {
            echo '<p>Keine G&auml;ste gefunden.</p>';
        }

        echo '</body></html>';
    }
}