<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminSmiliesCatIndex extends DbConectionMaker {

    public function __construct() {
        parent::__construct();
        session_start();

        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "co_admin"])) {

            $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] = rand(1, 999999999);

            $cats = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_smileys_cat ORDER BY gewicht ASC ");
            $this->dbObj->close();

            $print_cat_list = "";
            if (is_array($cats)) {
                $i = 0;
                foreach ($cats as $datasets) {
                    $i++;
                    $bgcolor = ($i % 2 == 0) ? "class='ungerade'" : "class='gerade'";
                    $print_cat_list .= "
                        <tr $bgcolor data-id='{$datasets[0]}'>
                        	<td align='center'><img class='img_verschieben'  src='./img/verschieben.png' border='0'  draggable='false'></td>
                            <td>{$i}.</td>
                            <td align='center'></td>
                            <td>{$datasets[1]}</td>
                            <td><a href='./?AdminRenameSmiliesCat&id={$datasets[0]}'>" . $lang->rename[0]->tagData . "</a></td>
                            <td><a href='./?AdminDeleteSmiliesCat&id={$datasets[0]}&cat={$datasets[1]}&cs4rue={$_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"]}' onclick=\"return confirm('Bist du sicher, dass du diese Smiley-Kategorie inkl. aller Smileys wirklich löschen möchtest?')\">" . $lang->delete[0]->tagData . "</a></td>
                            <td><a href='./?AdminOnOffSmiliesCat&id={$datasets[0]}&on_on_off={$datasets[2]}&cs4rue={$_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"]}'>{$datasets[2]}</a></td>
                            <td>{$datasets[3]}</td>
                        </tr>";
                }
            }

            $this->initTemplate($lang, $print_cat_list);

        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }

    private function initTemplate($lang, $print_cat_list) {
        include_once "styles/admin_tpl/indexSmiliesCat.tpl.html";
    }
}

