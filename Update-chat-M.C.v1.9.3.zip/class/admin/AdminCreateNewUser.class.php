<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminCreateNewUser extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_user[0];


		if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "chatwache", "co_admin"])) {

			$feld=$this->dbObj->sqlGet("SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien FROM {$this->_prefix}etchat_user WHERE etchat_userprivilegien='admin' OR etchat_userprivilegien='mod'");
			$this->dbObj->close();

			if (is_array($feld)){
				$print_user_list="<table>";
				foreach($feld as $datasets)
					$print_user_list.="<tr><td>".$datasets[1]."</td><td>(<i>".$datasets[3]."</i>)</td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"./?AdminUserEdit&id=".$datasets[0]."\">".$lang->edit[0]->tagData."</a></td></tr>";
				$print_user_list.="</table>";
			} else $print_user_list=$lang->noadmins[0]->tagData;
			$this->initTemplate($lang, $print_user_list);

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}

	}

	private function initTemplate($lang, $print_user_list){
		include_once("styles/admin_tpl/createNewUser.tpl.html");
	}
}
