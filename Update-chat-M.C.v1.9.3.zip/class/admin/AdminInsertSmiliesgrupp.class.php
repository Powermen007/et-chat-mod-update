<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminInsertSmiliesgrupp extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        $allowedRoles = ["admin", "grafik", "co_admin"];

		if (
		    !isset($_SESSION["etchat_" . $this->_prefix . "user_priv"]) ||
		    !in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], $allowedRoles)
		) {
            echo $lang->error[0]->tagData;
            return false;
        }

        $uploaddir = "./smilies/";
        $notes = "";

        // Kategorie bereinigen und Ordner erstellen
        $catNameo =  $_POST["cat"];
        $catName = preg_replace("/[^a-zA-Z0-9_-]/", "_", $_POST["cat"]);
        $catFolder = $uploaddir . $catName . "/";
        if (!is_dir($catFolder)) {
            mkdir($catFolder, 0777, true);
        }

        $gw_start = (int)($_POST["gw"] ?? 0);
        $gw_step = 5;
        $gw_current = $gw_start;

        foreach ($_FILES['smiliefiles']['tmp_name'] as $key => $tmp_name) {
            if (!is_uploaded_file($tmp_name)) continue;

            $originalName = $_FILES['smiliefiles']['name'][$key];
            $basename = pathinfo($originalName, PATHINFO_FILENAME);

            // Zeichen und Name bereinigen
            $basename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $basename);
            $basename = substr($basename, 0, 19);
            $sign = ':' . $basename;

            // K�rzel pr�fen
            $counter = 1;
            while (true) {
                $res = $this->dbObj->sqlGet("SELECT etchat_smileys_id FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_sign = '" . $sign . "'");
                if (!is_array($res)) break;

                $maxBaseLen = 19 - strlen($counter);
                $shortBase = substr($basename, 0, $maxBaseLen);
                $sign = ':' . $shortBase . $counter;
                $counter++;
            }

            $is_image = getimagesize($tmp_name);
            if (!is_array($is_image)) {
                $notes .= "Datei {$originalName} ist kein Bild, �bersprungen.<br>";
                continue;
            }

            // Datei existiert bereits -> Zeitstempel anh�ngen
            $targetFile = $catFolder . $originalName;
            if (file_exists($targetFile)) {
                $nowname = time() . "_" . $originalName;
                $targetFile = $catFolder . $nowname;
                $notes .= "Datei existiert schon, umbenannt zu {$nowname}<br>";
            } else {
                $nowname = $originalName;
            }

            move_uploaded_file($tmp_name, $targetFile);

            // DB-Eintrag
            $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_smileys
                (etchat_smileys_kat, etchat_smileys_sign, etchat_smileys_img, etchat_smileys_gewicht)
                VALUES ('{$catNameo}', '{$sign}', '{$targetFile}', '{$gw_current}')");

            $notes .= "Smilie {$sign} hochgeladen (Gewicht {$gw_current}).<br>";

            $gw_current += $gw_step;
        }

        $print_result  = "<b>Upload abgeschlossen</b><br>" . $notes;
        $print_result .= "<br><a href='./?AdminCreateNewSmiliesgrupp'>Weitere hochladen</a><br>";
        $print_result .= "<br><a href='./?AdminSmiliesIndex'>Zur&uuml;ck zur &Uuml;bersicht</a>";

        include_once "styles/admin_tpl/insertSmiliesMessage.tpl.html";
    }
}
?>