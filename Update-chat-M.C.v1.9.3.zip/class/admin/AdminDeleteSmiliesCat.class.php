<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminDeleteSmiliesCat extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();
        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        $allowedRoles = ["admin", "grafik", "co_admin"];

		if (
		    !isset($_SESSION["etchat_" . $this->_prefix . "user_priv"]) ||
		    !in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], $allowedRoles)
		) {
            echo $lang->error[0]->tagData;
            return false;
        }

        if ($_GET["cs4rue"] != $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] || !isset($_GET["cs4rue"]) || !isset($_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"])) {
            echo "Dear Admin this User tried to fake you. ;-)";
            return false;
        }

        $cats = filter_var($_GET["cat"], FILTER_SANITIZE_STRING);

        // Alle Smilies der Kategorie auslesen
        $feld = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_kat = '$cats'");

        // Alle Dateien l�schen
        foreach ($feld as $datasets) {
            if (file_exists($datasets['etchat_smileys_img'])) {
                unlink($datasets['etchat_smileys_img']);
            }
        }

        // DB-Eintr�ge l�schen
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_kat = '$cats'");
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_smileys_cat WHERE id = " . (int)$_GET["id"]);

        // Kategorie-Ordner l�schen, wenn vorhanden
        $catFolder = "./smilies/" . preg_replace("/[^a-zA-Z0-9_-]/", "_", $cats) . "/";
        if (is_dir($catFolder)) {
            // Ordnerinhalt pr�fen
            $files = glob($catFolder . '*'); // Alle Dateien im Ordner
            foreach ($files as $file) {
                if (is_file($file)) unlink($file);
            }
            rmdir($catFolder); // Ordner l�schen
        }

        $this->dbObj->close();
        header("Location: ./?AdminSmiliesCatIndex");
    }
}

?>
