<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminInsertUser extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();

        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
        header("Content-Type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_user[0];

        // Rolle ermitteln
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        // Ziel-Links nach Rolle
        $roleRedirects = [
            "admin"     => "./?AdminIndex",
            "co_admin"  => "./?AdminIndexCoAdmin",
            "chatwache" => "./?AdminIndexChatwache"
        ];

        $redirectUrl = $roleRedirects[$role] ?? "./";

        // Pr�fen, ob Rolle g�ltig ist
        if (!in_array($role, ["admin", "co_admin", "chatwache"])) {
            $this->showError($lang->error[0]->tagData, $redirectUrl);
            return false;
        }

        // Pr�fen, ob Username gesetzt ist
        if (empty($_POST["user"])) {
            $this->showError("Bitte Username angeben.", "./?AdminCreateNewUser");
            return false;
        }

        // Eingaben s�ubern
        $user = $_POST["user"] = htmlentities($_POST["user"], ENT_QUOTES, "UTF-8");
        $priv = $_POST["priv"] = htmlentities($_POST["priv"], ENT_QUOTES, "UTF-8");
        $mail = $_POST["mail"] = htmlentities($_POST["mail"], ENT_QUOTES, "UTF-8");

        if (!empty($_POST["pw"])) {
            $_POST["pw"] = "'" . md5($_POST["pw"]) . "'";
        } else {
            $_POST["pw"] = "NULL";
        }

        $reg_timestamp = date("Y-m-d H:i:s");

        // Pr�fen, ob Benutzer bereits existiert
        $sql = "SELECT etchat_user_id
                FROM {$this->_prefix}etchat_user
                WHERE etchat_username = '" . $user . "'
                  AND etchat_userprivilegien IN ('admin','mod','user','grafik','chatwache','co_admin')";

        $res = $this->dbObj->sqlGet($sql);

        if (is_array($res)) {
            // Benutzer existiert schon ? Fehlermeldung anzeigen
            $this->showError("Benutzer mit diesem Namen existiert bereits.", "./?AdminCreateNewUser");
            return false;
        }

        // Benutzer darf neu angelegt werden
        $sqlInsert = "INSERT INTO {$this->_prefix}etchat_user
            (etchat_username, etchat_userpw, etchat_userprivilegien, etchat_reg_timestamp, etchat_email)
            VALUES ('" . $user . "', " . $_POST["pw"] . ", '" . $priv . "', '" . $reg_timestamp . "', '" . $mail . "')";
        $this->dbObj->sqlSet($sqlInsert);
        $this->dbObj->close();

        // ? Alles ok ? Weiterleitung zur passenden Admin-Seite
        header("Location: $redirectUrl");
        exit;
    }

    /**
     * Hilfsfunktion, um eine Fehlermeldung mit CSS anzuzeigen
     */
    private function showError(string $message, string $backLink)
    {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Adminbereich</title>
            <link href="styles/<?php echo $_SESSION['etchat_'.$this->_prefix.'style']; ?>/style.css" rel="stylesheet" type="text/css"/>
        </head>
        <body id="adminbereich_body">
            
                    <?php
			        // Rollen ermitteln
						$role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

					// Links f�r jede Rolle definieren
						$roleLinks = [
						    "admin"     => "./?AdminIndex",
						    "grafik"    => "./?AdminIndexGrafik",
						    "co_admin"  => "./?AdminIndexCoAdmin"
						];

					// Link setzen, Standard-Link falls Rolle unbekannt
					$backlinkUrl = $roleLinks[$role] ?? "./";

			// Ausgabe
			echo "<a href=\"$backlinkUrl\">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml;</a><hr size=\"1\">";

		        ?>

            <div class="error">
                <?php echo $message; ?><br><br>
                <a href="<?php echo $backLink; ?>">Zur&uuml;ck</a>
            </div>
        </body>
        </html>
        <?php
    }
}

