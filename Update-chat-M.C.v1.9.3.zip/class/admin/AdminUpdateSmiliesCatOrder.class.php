<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateSmiliesCatOrder extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
        header("Content-Type: text/plain; charset=utf-8");

        $allowedRoles = ["admin", "grafik", "co_admin"];

		if (
		    !isset($_SESSION["etchat_" . $this->_prefix . "user_priv"]) ||
		    !in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], $allowedRoles)
		) {
            echo "Keine Berechtigung!";
            return;
        }

        // Rohdaten einlesen
        $raw = file_get_contents("php://input");
        $data = json_decode($raw, true);

        if (!$data || !is_array($data)) {
            echo "Fehler: Keine oder ung�ltige JSON-Daten empfangen.";
            return;
        }

        // Reihenfolge speichern
        foreach ($data as $row) {
            $id = intval($row["id"]);
            $gewicht = intval($row["gewicht"]);

            $this->dbObj->sqlGet(
                "UPDATE {$this->_prefix}etchat_smileys_cat
                 SET gewicht='" . $gewicht . "'
                 WHERE id='" . $id . "'"
            );
        }

        echo "Reihenfolge gespeichert!";
    }
}