<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminSpracheSpeichern extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        // Style + Sprache aus DB holen
        $desei = $this->dbObj->sqlGet("
            SELECT etchat_config_id, etchat_config_style, etchat_config_lang
            FROM {$this->_prefix}etchat_config
            WHERE etchat_config_id = '1'
        ");

        if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] !== "admin") {
            die("Zugriff verweigert.");
        }

        $this->speichereAenderungen($desei);
    }

private function speichereAenderungen($desei)
{
    // Standardm��ig Deutsch
    $langFile = 'lang_de.xml';

    if (is_array($desei)) {
        foreach ($desei as $data) {
            $langValue = $data['etchat_config_lang'] ?? $data[2] ?? '';
            if (!empty($langValue) && file_exists(__DIR__ . '/../../lang/' . $langValue)) {
                $langFile = $langValue;
            }
        }
    }

    $xml_file = __DIR__ . '/../../lang/' . $langFile;
    if (!file_exists($xml_file)) {
        die("XML-Datei nicht gefunden: " . htmlspecialchars($xml_file));
    }

    $bereich = $_POST['bereich'] ?? '';
    $eintraege = $_POST['eintraege'] ?? [];

    if (!$bereich || !is_array($eintraege)) {
        die("Ung�ltige Eingaben.");
    }

    // Backup anlegen (zeitgestempelt)
    $backupDir = __DIR__ . '/../../lang/old/'; // Backup-Ordner
    if (!is_dir($backupDir)) {
        @mkdir($backupDir, 0777, true);
    }
    $backupFile = basename($xml_file) . '.bak.' . date('Ymd_His');
    $backup = $backupDir . $backupFile;
    @copy($xml_file, $backup);

    // --- DOM-basiertes Speichern (robust) ---
    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    if (@$dom->load($xml_file) === false) {
        if (file_exists($backup)) @copy($backup, $xml_file);
        die("Fehler beim Laden der XML-Datei (DOM).");
    }
    $xpath = new DOMXPath($dom);

    // Zielknoten (Bereich) ermitteln relativ zur Wurzel
    $teileBereich = array_values(array_filter(explode('/', $bereich), 'strlen'));
    if (count($teileBereich) === 0) {
        die("Ung�ltiger Bereich: " . htmlspecialchars($bereich));
    }
    $rootName = $dom->documentElement->nodeName;
    $targetQuery = '/' . $rootName . '/' . implode('/', $teileBereich);
    $targetNodes = $xpath->query($targetQuery);
    if ($targetNodes->length === 0) {
        // zus�tzliche Fehlersuche: falls Pfad nicht exakt �bereinstimmt, abbrechen statt XML zu zerst�ren
        if (file_exists($backup)) @copy($backup, $xml_file);
        die("Ung�ltiger Bereichspfad (DOM): " . htmlspecialchars($targetQuery));
    }
    $targetNode = $targetNodes->item(0);

    // Eintr�ge durchgehen und per DOM anpassen / anlegen
    foreach ($eintraege as $pfadRelativ => $wert) {
        $wert = (string)$wert;
        $pfadRelativ = trim($pfadRelativ, "/ \t\n\r\0\x0B");
        if ($pfadRelativ === '') continue;


    // Falls der erste Teil identisch mit dem Bereichs-Namen ist -> entfernen
    $bereichName = end($teileBereich);
    if (strpos($pfadRelativ, $bereichName . '/') === 0) {
        $pfadRelativ = substr($pfadRelativ, strlen($bereichName) + 1);
    }



        // Pfad-Segmente (z.B. "start_prop_link_0" oder "title" oder "group/entry_1")
        $parts = array_values(array_filter(explode('/', $pfadRelativ), 'strlen'));
        $currentParent = $targetNode;

        foreach ($parts as $segment) {
            // Erkenne numerischen Index-Suffix (z.B. name_2)
            if (preg_match('/^(.*)_(\d+)$/', $segment, $m)) {
                $tag = $m[1];
                $index = (int)$m[2];
            } else {
                $tag = $segment;
                $index = 0;
            }

            // Finde vorhandene Child-Elemente mit dem Tag-Namen
            $existing = [];
            for ($i = 0; $i < $currentParent->childNodes->length; $i++) {
                $cn = $currentParent->childNodes->item($i);
                if ($cn->nodeType === XML_ELEMENT_NODE && $cn->nodeName === $tag) {
                    $existing[] = $cn;
                }
            }

            if (isset($existing[$index])) {
                // Das gew�nschte Vorkommen existiert bereits
                $currentParent = $existing[$index];
            } else {
                // Erzeuge so viele neue Elemente, bis das gew�nschte Index existiert
                while (count($existing) <= $index) {
                    $new = $dom->createElement($tag);
                    $currentParent->appendChild($new);
                    $existing[] = $new;
                }
                $currentParent = $existing[$index];
            }
        }

        // Textinhalt setzen (alte Textknoten entfernen, Attribute bleiben erhalten)
        while ($currentParent->firstChild) {
            $currentParent->removeChild($currentParent->firstChild);
        }
        $textNode = $dom->createTextNode($wert);
        $currentParent->appendChild($textNode);
    }

    // Atomar speichern: tmp + rename
    $tmpFile = $xml_file . '.tmp';
    if (@$dom->save($tmpFile) === false) {
        if (file_exists($backup)) @copy($backup, $xml_file);
        die("Fehler beim Speichern der tempor�ren XML-Datei.");
    }
    if (!@rename($tmpFile, $xml_file)) {
        if (!@copy($tmpFile, $xml_file)) {
            if (file_exists($backup)) @copy($backup, $xml_file);
            @unlink($tmpFile);
            die("Fehler beim finalen Schreiben der XML-Datei.");
        } else {
            @unlink($tmpFile);
        }
    }

    // Style f�r CSS laden (wie vorher)
    $styleValue = '';
    if (is_array($desei)) {
        foreach ($desei as $data) {
            $styleValue = $data['etchat_config_style'] ?? $data[1] ?? '';
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <title>Sprache bearbeiten</title>
        <?php
        if (!empty($styleValue)) {
            echo '<link href="styles/' . htmlspecialchars($styleValue) . '/style.css" rel="stylesheet" type="text/css">';
        }
        $this->dbObj->close();
        ?>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="robots" content="noindex, nofollow">
    </head>
    <body id="adminbereich_body">
        <a href="./?AdminIndex" style="cursor:pointer;">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml;</a>
        <hr>
            <h2>Sprach&auml;nderung gespeichert</h2>
            <?php
            echo "&Auml;nderungen im Bereich <strong>" . htmlspecialchars($bereich) . "</strong> wurden gespeichert.<br><br>";
            echo "<a href=\"./?AdminSpracheBearbeiten&bereich=" . urlencode($bereich) . "\">Zur&uuml;ck</a>";
            ?>
    </body>
    </html>
    <?php
}

}