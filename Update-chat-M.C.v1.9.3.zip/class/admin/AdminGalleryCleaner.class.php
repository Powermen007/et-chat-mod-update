<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Erg�nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminGalleryCleaner extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();

        $desei = $this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang();

        $allowedRoles = ["admin", "grafik", 'co_admin'];

        if (
            !isset($_SESSION["etchat_" . $this->_prefix . "user_priv"]) ||
            !in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], $allowedRoles)
        ) {
            echo $lang->error[0]->tagData;
            return;
        }

        $this->runCleaner($desei);
    }

    private function runCleaner($desei)
    {
        $uploadDir = realpath(__DIR__ . '/../../userpic/') . '/';
        $jetzt = time();
        $etwasGeloescht = false;

        echo '<!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Bilduploadcleaner</title>
            <link href="styles/';

        if (is_array($desei) && !empty($desei)) {
            foreach ($desei as $data) {
                echo $data[1];
            }
        } else {
            echo "desei ist leer oder kein Array.";
        }

        $this->dbObj->close();

        echo '/style.css" rel="stylesheet" type="text/css">
        </head>
       <body id="adminbereich_body">';

        // Rollen ermitteln
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        // Link je nach Rolle setzen
        if ($role == "admin") {
            $backlinkUrl = "./?AdminIndex";
        } elseif ($role == "grafik") {
            $backlinkUrl = "./?AdminIndexGrafik";
        } else {
            $backlinkUrl = "./";
        }

        // Ausgabe
        echo "<a href=\"$backlinkUrl\"><<< zur&uuml;ck zum Adminmen&uuml;</a><hr size=\"1\">";

        if (is_dir($uploadDir)) {
            if ($handle = opendir($uploadDir)) {
                while (false !== ($datei = readdir($handle))) {
                    $dateipfad = $uploadDir . $datei;

                    if (in_array($datei, ['.', '..', 'index.html', '.htaccess'])) {
                        continue;
                    }

                    // nur Bilder beachten
                    if (is_file($dateipfad) && preg_match('/\.(jpg|jpeg|png|gif)$/i', $datei)) {

                        // zugeh�rige TXT
                        $txtFile = $uploadDir . $datei . ".txt";

                        if (is_file($txtFile)) {
                            $content = trim(file_get_contents($txtFile));
                            $parts = explode("|", $content);

                            if (count($parts) >= 2) {
                                $datum = trim($parts[1]);
                                $zeit = DateTime::createFromFormat("d.m.Y H:i", $datum);

                                if ($zeit !== false) {
                                    $timestamp = $zeit->getTimestamp();
                                    $diff = $jetzt - $timestamp;

                                   if ($diff > 432000) {
                                        // Bild l�schen
                                        if (unlink($dateipfad)) {
                                            echo "Bild <b>$datei</b> wurde gel&ouml;scht.<br>";
                                            $etwasGeloescht = true;
                                        } else {
                                            echo "Fehler beim L&ouml;schen von <b>$datei</b><br>";
                                        }

                                        // TXT l�schen
                                        if (unlink($txtFile)) {
                                            echo "Zuordnung <b>" . basename($txtFile) . "</b> wurde gel&ouml;scht.<br>";
                                        } else {
                                            echo "Fehler beim L&ouml;schen von <b>" . basename($txtFile) . "</b><br>";
                                        }
                                    }
                                } else {
                                    echo "Fehler: Konnte Datum aus $txtFile nicht parsen.<br>";
                                }
                            }
                        }
                    }
                }
                closedir($handle);
            }

            if (!$etwasGeloescht) {
                echo "Keine Dateien &auml;lter als 5 Tage vorhanden.<br>";
            }
        } else {
            echo "Upload-Verzeichnis <b>$uploadDir</b> nicht gefunden.";
        }

        echo '<br><br><br>
        <a onclick="window.location.href=\'./?AdminGallery\'" style="cursor: pointer"><<< zur&uuml;ck zur Galerie</a>
        <hr size="1">
        </body>
        </html>';
    }
}
?>