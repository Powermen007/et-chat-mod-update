<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateSmiliesOrder extends DbConectionMaker
{
    public function __construct() {
        parent::__construct();
        session_start();

        // Rechtepr�fung
        if (
            !isset($_SESSION['etchat_'.$this->_prefix.'user_priv']) ||
            !in_array($_SESSION['etchat_'.$this->_prefix.'user_priv'], ["admin", "grafik", "co_admin"])
        ) {
            http_response_code(403);
            echo "Keine Rechte oder die Session ist abgelaufen.";
            exit;
        }

        // JSON-Daten holen
        $json = file_get_contents("php://input");
        $data = json_decode($json, true);

        if (!is_array($data)) {
            http_response_code(400);
            echo "Ung�ltige Daten";
            exit;
        }

        // Jetzt f�r jede Zeile UPDATE mit deiner DB-Struktur
        foreach ($data as $row) {
            if (!isset($row["id"], $row["weight"])) {
                continue;
            }

            $id     = (int)$row["id"];
            $weight = (int)$row["weight"];

            // SQL an dein System anpassen
            $sql = "
                UPDATE {$this->_prefix}smileys
                SET etchat_smileys_gewicht = ".$weight."
                WHERE etchat_smileys_id = ".$id."
            ";

            $this->dbObj->sqlSet($sql);
        }

        echo "OK";
    }
}