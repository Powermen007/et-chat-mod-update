<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminRegUserIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();

        header(
            "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0"
        );
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_reg_user[0];

        if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "chatwache", "co_admin"])) {
        
            $counted = $this->dbObj->sqlGet(
                "SELECT count(etchat_user_id) FROM {$this->_prefix}etchat_user WHERE etchat_userprivilegien='user'"
            );

            if (empty($_GET["site"])) {
                $_GET["site"] = 1;
            }

            $pro_seite = 20;
            $site = intval($_GET["site"]) - 1;
            $von = $site * $pro_seite;

            if ($this->_usedDatabase == "mysql") {
                $limit = "LIMIT $von, $pro_seite";
            }
            if ($this->_usedDatabase == "pgsql") {
                $limit = "LIMIT $pro_seite OFFSET $von";
            }

            $feld = $this->dbObj->sqlGet("SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien, etchat_reg_timestamp, etchat_reg_ip, etchat_logintime, etchat_avatar, etchat_email, etchat_last_ip FROM {$this->_prefix}etchat_user WHERE etchat_userprivilegien='user' order by etchat_logintime DESC " .$limit);
            $this->dbObj->close();

            $sitemakerObj = new Sitemaker($pro_seite, $counted[0][0]);
            $sitemakerObj->href = true;
            $sitemakerObj->make(
                $_GET["site"],
                "./?AdminRegUserIndex&site=#site#",
                $lang->site[0]->tagData,
                $lang->site_of[0]->tagData
            );
            $print_sitemaker = $sitemakerObj->get();

            $_SESSION[
                "etchat_" . $this->_prefix . "CheckSum4RegUserEdit"
            ] = rand(1, 999999999);

            if (is_array($feld)) {
                $print_user_list =
                    $print_sitemaker .
                    "&nbsp;&nbsp;<form id=\"checkers\" action=\"./?AdminRegUserEdit\" method=\"post\">
				<input type=\"hidden\" id=\"userids\" name=\"userids\" />
				<table><tr><td>&nbsp;</td><td><b>" .
                    $lang->name[0]->tagData .
                    "</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><b>" .
                    $lang->reg_date[0]->tagData .
                    "</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><b>" .
                    $lang->reg_ip[0]->tagData .
                    "</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><b>letzter Login</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><b>letzte IP</b></td><td>&nbsp;&nbsp;&nbsp;</td><td></td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td></tr>";
                foreach ($feld as $datasets) {
                    $print_user_list .=
                        "<tr><td><input type=\"checkbox\" name=\"userid\" value=\"" .
                        $datasets[0] .
                        "\"></td><td><b><a href=\"./?AdminEditUserUser&id=" .
                        $datasets[0] .
                        "\">" .
                        $datasets[1] .
                        "</a></b></td><td>&nbsp;&nbsp;&nbsp;</td><td> " .
                        $datasets[4] .
                        "</td><td>&nbsp;&nbsp;&nbsp;</td><td> " .
                        $datasets[5] .
                        "</td><td>&nbsp;&nbsp;&nbsp;</td><td>" .
                        date("d.m.Y-H:i", $datasets[6]) .
                        "</td><td>&nbsp;&nbsp;&nbsp;</td><td> ".$datasets[9]."  </td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"mailto:".$datasets[8]."\">".$datasets[8]."</a></td><td>&nbsp;&nbsp;&nbsp;</td><td>
						  <a href=\"./?AdminDeleteAvatarRegUser&delavatar&cs4rue=" .
                        $_SESSION[
                            "etchat_" . $this->_prefix . "CheckSum4RegUserEdit"
                        ] .
                        "&id=" .
                        $datasets[0]."\" onclick=\"return confirm('Bist du sicher, dass du diesen Avatar wirklich l&ouml;schen m&ouml;chtest?')\">
                        L&ouml;sche Avatar</a>&nbsp; &nbsp; <img src=\"avatar/$datasets[7]\" width=\"16\" height=\"16\"></td></tr>";
                }
                $print_user_list .=
                    "</table>
				<input type=\"button\" value=\"" .
                    $lang->set_all[0]->tagData .
                    "\" id=\"marking_all_button\" onclick=\"marking_all();\">&nbsp;<input type=\"button\" value=\"" .
                    $lang->del[0]->tagData .
                    "\" onclick=\"del_all();\"></form>" .
                    $lang->text[0]->tagData;

                $checksum = $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"];

				$print_user_list .= "
					  <form id=\"deleteinactive_form\" method=\"get\" action=\"./\">
					    <input type=\"hidden\" name=\"AdminRegUserEdit\" value=\"1\">
  						<input type=\"hidden\" name=\"deleteinactive\" value=\"1\">
					  <label for=\"inactive_months\">Inaktive Benutzer l&ouml;schen (nicht online seit):</label>
					  <select name=\"inactive_months\" id=\"inactive_months\">
				      <option value=\"3\">3 Monate</option>
				      <option value=\"6\">6 Monate</option>
				      <option value=\"9\">9 Monate</option>
				      <option value=\"12\">12 Monate</option>
				      <option value=\"18\">18 Monate</option>
				      <option value=\"24\">24 Monate</option>
					  </select>
					  <input type=\"hidden\" name=\"cs4rue\" value=\"$checksum\">
					  <input type=\"submit\" value=\"L&ouml;schen\">
					  </form>";
            } else {
                if ($this->_allow_nick_registration) {
                    $print_user_list =
                        "<br /><br /><b>" .
                        $lang->nouser[0]->tagData .
                        "</b><br />" .
                        $lang->nouser2[0]->tagData .
                        "<br /><br />";
                } else {
                    $print_user_list =
                        "<br /><br />" .
                        $lang->nouser[0]->tagData .
                        "<br /><br />";
                }
            }
            $this->initTemplate($lang, $print_user_list);
        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }
    private function initTemplate($lang, $print_user_list)
    {
        include_once "styles/admin_tpl/indexRegUser.tpl.html";
    }
}

