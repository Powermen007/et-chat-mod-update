<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminInsertSmiliesCat extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();
        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
        header("content-type: text/html; charset=utf-8");
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];
        if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "co_admin"])) {
            $res = $this->dbObj->sqlGet("select id FROM " . $this->_prefix . "etchat_smileys_cat where name = '".$_POST["name"]."'");
            if (is_array($res)) {
                $print_result = $lang->name_exists[0]->tagData . "<br>";
                $print_result .= "<a href='./?AdminCreateNewSmiliesCat'>" . $lang->back[0]->tagData . "</a>";
            } else {
                $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_smileys_cat(`id`, `name`, `aktiv`, `gewicht`) VALUES (NULL, '".$_POST["name"]."', '".$_POST["on_off"]."', '".$_POST["gw"]."')");
                $print_result = $lang->isupload1[0]->tagData . "<br>";
                $print_result .= "<br><a href='./?AdminCreateNewSmiliesCat'>" . $lang->cat[3]->tagData . "</a>";
                $print_result .= "<br /><a href='./?AdminSmiliesCatIndex'>" . $lang->cat[0]->tagData . "</a>";
            }
            include_once "styles/admin_tpl/insertSmiliesCatMessage.tpl.html";
        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }
}

?>
