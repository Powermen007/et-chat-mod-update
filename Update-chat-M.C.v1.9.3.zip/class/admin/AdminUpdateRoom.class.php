<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateRoom extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_rooms[0];


		if (!empty($_POST['id']) && in_array($_SESSION['etchat_'.$this->_prefix.'user_priv'], ["admin", "co_admin"])
			) {

			if ($_POST['room_priv']==3)
				$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_rooms SET etchat_roomname = '".$_POST['room']."', etchat_room_goup = ".$_POST['room_priv'].", etchat_room_pw = '".$_POST['roompw']."', etchat_room_message = '".$_POST['roommessage']."' WHERE etchat_id_room = ".(int)$_POST['id']);
			else
				$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_rooms SET etchat_roomname = '".$_POST['room']."', etchat_room_goup = ".$_POST['room_priv'].",  etchat_room_pw = NULL, etchat_room_message = '".$_POST['roommessage']."' WHERE etchat_id_room = ".(int)$_POST['id']);

			$this->dbObj->close();
			header("Location: ./?AdminRoomsIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
