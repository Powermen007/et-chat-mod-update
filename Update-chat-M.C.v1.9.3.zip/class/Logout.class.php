<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Logout extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        // Cache verhindern
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');

        // Session-Werte holen
        $username   = $_SESSION['etchat_' . $this->_prefix . 'username'] ?? '';
        $userId     = $_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0;
        $userPriv   = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'user';
        $userStatus = $_SESSION['etchat_' . $this->_prefix . 'userstatus'] ?? 'status_online';

        $langObj = new LangXml();
        $lang    = $langObj->getLang()->logout_php[0];
        $userColor = $this->getUserColor($userPriv);

	if ($_SESSION['etchat_'.$this->_prefix.'chat_pic'] == '1'){
        // Nachricht nur senden, wenn Benutzer sichtbar ist
        if (!empty($username) && $userStatus !== "status_invisible") {
            $avatarHTML = $this->getUserAvatarHTML($username);
            $usernameStyled = "<span style=\"$userColor\"><b>" . htmlentities($username, ENT_QUOTES, "UTF-8") . "</b></span>";
            $message = $avatarHTML . $usernameStyled . " " . $lang->exit[0]->tagData;
            new SysMessage($this->dbObj, $message, 0, 0);
        }
        }else{
         if (!empty($username) && $userStatus !== "status_invisible") {
            $avatarHTML = $this->getUserAvatarHTML($username);
            $usernameStyled = "<span style=\"$userColor\"><b>" . htmlentities($username, ENT_QUOTES, "UTF-8") . "</b></span>";
            $message = $usernameStyled . " " . $lang->exit[0]->tagData;
            new SysMessage($this->dbObj, $message, 0, 0);
        }
        }

        // Benutzer aus Online-Liste entfernen
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = " . (int)$userId);

        // Session beenden
        @session_unset();
        @session_destroy();

        // Weiterleitung
        $redirectURL = $_SESSION['etchat_' . $this->_prefix . 'logout_url'] ?? './';
        header("Location: " . $redirectURL);
        exit;
    }

    /**
     * Gibt den HTML-Code für einen runden Avatar neben dem Namen zurück
     */
    private function getUserAvatarHTML(string $username): string
    {

    		$avatar = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_user WHERE etchat_username = '".$_SESSION['etchat_'.$this->_prefix.'username']."'");
		$avatar1 = $avatar [0][7];
        $avatarPath = "avatar/$avatar1";

        return '
            <img src="' . $avatarPath . '"
                 alt="Avatar"
                  class=\"avatar_w\" alt=\"\" title=\"\">';
    }

    /**
     * Sucht nach einem vorhandenen Avatarbild
     */


    /**
     * Gibt die passende Schriftfarbe für den Benutzertyp zurück
     */
	private function getUserColor($priv) {
		switch($priv) {
			case 'admin': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
			case 'mod':	return "color: ".$_SESSION['etchat_'.$this->_prefix.'mod_color']."";
			case 'user': return "color: ".$_SESSION['etchat_'.$this->_prefix.'user_color']."";
			case 'gast': return "color: ".$_SESSION['etchat_'.$this->_prefix.'gast_color']."";
			case 'grafik': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
			case 'chatwache': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
			case 'co_admin': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
			default: return "color: #FFFFFF";
		}
	}
}
?>