<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Blacklist extends EtChatConfig
{
    private $dbObj;
    public $user_param_all;
    public $user_bann_time;

    public function __construct($dbObj){
        parent::__construct();
        $this->dbObj = $dbObj;
        $this->user_param_all = $_SERVER['REMOTE_ADDR']."@".@gethostbyaddr($_SERVER['REMOTE_ADDR']);
    }

    public function userInBlacklist(){
        $blacklist_c = '';
        if (isset($_COOKIE['cookie_etchat_blacklist_ip']) && isset($_COOKIE['cookie_etchat_blacklist_until'])) {
            $blacklist_c = $this->dbObj->sqlGet(
                "SELECT etchat_blacklist_time FROM {$this->_prefix}etchat_blacklist
                 WHERE etchat_blacklist_ip = '".addslashes($_COOKIE['cookie_etchat_blacklist_ip'])."'
                 AND etchat_blacklist_time = ".(int)$_COOKIE['cookie_etchat_blacklist_until']."
                 AND etchat_blacklist_time > ".date('U')
            );
        }

        // IP und Hostname
        $user_ip = $_SERVER['REMOTE_ADDR'];
        $user_host = @gethostbyaddr($user_ip);
        $user_combined = $user_ip . '@' . $user_host;

        // Pr�fe IP oder IP+Hostname gegen DB
        $blacklist = $this->dbObj->sqlGet(
            "SELECT etchat_blacklist_time FROM {$this->_prefix}etchat_blacklist
             WHERE ('".addslashes($user_ip)."' LIKE CONCAT(etchat_blacklist_ip, '%')
                 OR '".addslashes($user_combined)."' LIKE CONCAT(etchat_blacklist_ip, '%'))
             AND etchat_blacklist_time > ".date('U')
        );

        // Falls gebannt, Zeit merken
        if (is_array($blacklist) && count($blacklist) > 0) $this->user_bann_time = $blacklist[0][0];
        if (is_array($blacklist_c) && count($blacklist_c) > 0) $this->user_bann_time = $blacklist_c[0][0];

        return (is_array($blacklist) && count($blacklist) > 0) || (is_array($blacklist_c) && count($blacklist_c) > 0);
    }

    public function allowedToAndSetCookie() {
        $rechte_zum_sperren = $this->dbObj->sqlGet("SELECT etchat_userprivilegien
            FROM {$this->_prefix}etchat_user
            WHERE etchat_user_id = " . (int)$_SESSION['etchat_' . $this->_prefix . 'user_id']);

        $role = $rechte_zum_sperren[0][0] ?? null;
        $excludedRoles = ["admin", "mod", "chatwache", "co_admin"];

        if (!in_array($role, $excludedRoles, true)) {
            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline
                WHERE etchat_onlineuser_fid = " . (int)$_SESSION['etchat_' . $this->_prefix . 'user_id']);

            setcookie("cookie_etchat_blacklist_until", $this->user_bann_time, [
                "expires"  => $this->user_bann_time,
                "path"     => "/",
                "samesite" => "lax"
            ]);
            setcookie("cookie_etchat_blacklist_ip", $this->user_param_all, [
                "expires"  => $this->user_bann_time,
                "path"     => "/",
                "samesite" => "lax"
            ]);

            return true;
        }

        return false;
    }

    public function insertUser($userID, $time) {
        $rechte_zum_sperren = $this->dbObj->sqlGet("SELECT etchat_userprivilegien
            FROM {$this->_prefix}etchat_user
            WHERE etchat_user_id = " . (int)$userID);

        $role = $rechte_zum_sperren[0][0] ?? null;
        $excludedRoles = ["admin", "mod", "chatwache", "co_admin"];

        if (!in_array($role, $excludedRoles, true)) {
            $ip = $this->dbObj->sqlGet("SELECT etchat_onlineip
                FROM {$this->_prefix}etchat_useronline
                WHERE etchat_onlineuser_fid = " . (int)$userID);

            $time_to_hold = time() + $time;

            $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_blacklist
                (etchat_blacklist_ip, etchat_blacklist_userid, etchat_blacklist_time)
                VALUES ('" . $ip[0][0] . "', " . (int)$userID . ", " . $time_to_hold . ")");

            return true;
        }

        return false;
    }

    public function killUserSession(){
        @session_unset();
        @session_destroy();
    }
}

