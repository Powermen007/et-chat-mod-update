<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Insert2Blacklist extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->add2blacklist[0];

		if (in_array($_SESSION['etchat_' . $this->_prefix . 'user_priv'], ["admin", "mod", "grafik", "chatwache", "co_admin"])) {

			$ip=$this->dbObj->sqlGet("SELECT etchat_onlineip FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = ".(int)$_POST['user_id']);

			if (is_array($ip)){
				if ($_POST['time']>0) {
					$blObj = new Blacklist($this->dbObj);
					$blObj->insertUser((int)$_POST['user_id'],(int)$_POST['time']);
				}else{
					$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_kick_user (etchat_kicked_user_id, etchat_kicked_user_time) VALUES (".(int)$_POST['user_id'].", ".(date("U")+30).")");
				}
			}else{
				echo $lang->user_away[0]->tagData;
			}

			$this->dbObj->close();

		}else{
			echo $lang->session_lost[0]->tagData;
		}
	}
}
