<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class RoomAllowed extends EtChatConfig
{
    public $room_status = 0;

    public function __construct($room_priv, $room_id)
    {
        parent::__construct();

        // Session-Wert absichern
        $user_priv = $_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? '';

        // Admin-�hnliche Rollen
        $admin_roles = ['admin', 'chatwache', 'grafik', 'co_admin'];

        // Standardm��ig kein Zugriff
        $room_allowed = 0;

        switch ($room_priv) {
            case 0: // frei f�r alle
                $room_allowed = 1;
                break;
            case 1: // nur mod und admin
                if (in_array($user_priv, array_merge(['mod'], $admin_roles))) $room_allowed = 1;
                break;
            case 2: // nur admin
                if (in_array($user_priv, $admin_roles)) $room_allowed = 1;
                break;
            case 4: // admin, mod, user
                if (in_array($user_priv, array_merge(['mod','user'], $admin_roles))) $room_allowed = 1;
                break;
            case 3: // Passwortgesch�tzter Raum
                if (in_array($user_priv, $admin_roles)) {
                    $room_allowed = 1; // Admin-�hnliche Rollen haben immer Zugriff
                } else {
                    $room_allowed = 2; // andere brauchen Passwort
                    // Passwort bereits eingegeben?
                    if (isset($_SESSION['etchat_'.$this->_prefix.'roompw_array']) &&
                        is_array($_SESSION['etchat_'.$this->_prefix.'roompw_array']) &&
                        in_array($room_id, $_SESSION['etchat_'.$this->_prefix.'roompw_array'])
                    ) {
                        $room_allowed = 1;
                    }
                }
                break;
        }

        $this->room_status = $room_allowed;
    }
}

