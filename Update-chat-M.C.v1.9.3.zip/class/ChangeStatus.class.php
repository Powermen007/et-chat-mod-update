<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class ChangeStatus extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

        // Speichert Systemmeldungen in die Session
        if (isset($_POST['sys_messages'])) {
            $_SESSION['etchat_' . $this->_prefix . 'sys_messages'] = $_POST['sys_messages'];
            return false;
        }

        // Pr�fung ob User-ID in der Session existiert
        if (!isset($_SESSION['etchat_' . $this->_prefix . 'user_id'])) {
            echo "Invalid session.";
            return false;
        }

        // Input bereinigen
        $_POST['img'] = isset($_POST['img']) ? preg_replace("/[^a-zA-Z0-9_\-. ]/", "", $_POST['img']) : '';
        $_POST['text'] = isset($_POST['text']) ? preg_replace('/[\x00-\x1F]/', '', $_POST['text']) : '';

        // Rechte pr�fen f�r gew�nschten Status
        if (!$this->checkRightsOfStatus($_POST['img'])) {
            $_POST['img'] = "";
            $_POST['text'] = "";
            echo "Not allowed operation.";
            return false;
        }

        // "status_online" = neutraler Zustand ? leeren
        if ($_POST['img'] === "status_online") {
            $_POST['img'] = "";
            $_POST['text'] = "";
        }

        // Pr�fen ob die Bilddatei existiert
        if (!empty($_POST['img']) && !file_exists("./img/" . $_POST['img'] . ".png")) {
            $_POST['img'] = "";
            $_POST['text'] = "";
        }

        // Datenbank-Update (sofern Status g�ltig)
        $img = addslashes($_POST['img']);
        $text = addslashes($_POST['text']);

        $userId = (int)$_SESSION['etchat_' . $this->_prefix . 'user_id'];

        $this->dbObj->sqlSet("
            UPDATE {$this->_prefix}etchat_useronline SET
                etchat_user_online_user_status_img = '$img',
                etchat_user_online_user_status_text = '$text'
            WHERE etchat_onlineuser_fid = $userId
        ");

        $this->dbObj->close();

        echo "1";
    }

    /**
     * Pr�ft ob der aktuelle User den gew�nschten Status setzen darf.
     * Unterst�tzt mehrere <status> mit gleichem imagename aber unterschiedlichem "rights"-Wert.
     */
    private function checkRightsOfStatus($statusImagename)
    {
        // G�ltigkeit des Status-Namens pr�fen
        if (substr($statusImagename, 0, 7) !== 'status_') {
            return false;
        }

        // Sprachdatei laden
        $langObj = new LangXml();
        $lang = $langObj->getLang();

        $requiredRights = [];

        // Alle <status>-Eintr�ge mit dem gew�nschten Bildnamen pr�fen
        foreach ($lang->chat_js[0]->status as $status_value) {
            if ($status_value->tagAttrs['imagename'] == $statusImagename) {
                $right = $status_value->tagAttrs['rights'];

                // "all" bedeutet: jeder darf diesen Status verwenden
                if ($right === 'all') {
                    return true;
                }

                $requiredRights[] = $right;
            }
        }

        // Keine Rechte gefunden ? Status darf jeder verwenden
        if (empty($requiredRights)) {
            return true;
        }

        // Aktuelles Benutzerrecht aus der Session holen
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'];

        // Darf der User einen der erlaubten Werte?
        return in_array($userPriv, $requiredRights);
    }
}

