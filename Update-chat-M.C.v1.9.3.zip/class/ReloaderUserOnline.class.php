<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class ReloaderUserOnline extends DbConectionMaker
{
    public function __construct() {
        parent::__construct();
        session_start();


        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['task'] ?? '') === 'logout') {
    if (isset($_SESSION['etchat_'.$this->_prefix.'user_id'])) {
        $userID   = (int)$_SESSION['etchat_'.$this->_prefix.'user_id'];
        $username = $_SESSION['etchat_'.$this->_prefix.'username'] ?? '';
        $userPriv = $_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? 'user';

        // Nachricht: Tab geschlossen
        if (!empty($username)) {
            $langObj = new LangXml();
            $lang = $langObj->getLang()->logout_php[0];
            $userColor = $this->getUserColor($userPriv);

            $avatarHTML = ''; // optional: Avatar kannst du hier auch laden
            $usernameStyled = "<span style=\"$userColor\"><b>" . htmlentities($username, ENT_QUOTES, "UTF-8") . "</b></span>";
            $message = $avatarHTML . $usernameStyled . " " . $lang->exit_tab[0]->tagData;

            new SysMessage($this->dbObj, $message, 0, 0);
        }

        // Sofort aus Online-Tabelle l�schen
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = $userID");
    }

    exit;
}




        if (isset($_SESSION['etchat_'.$this->_prefix.'user_id'])) {

            $userID = (int)$_SESSION['etchat_'.$this->_prefix.'user_id'];
            $result = $this->dbObj->sqlGet("SELECT etchat_user_online_user_status_img, etchat_user_online_user_status_text
                FROM {$this->_prefix}etchat_useronline
                WHERE etchat_onlineuser_fid = $userID LIMIT 1");

            if (!empty($result) && $result[0][0] === 'status_off') {
                $oldImg  = $_SESSION['etchat_'.$this->_prefix.'old_status_img']  ?? '';
                $oldText = $_SESSION['etchat_'.$this->_prefix.'old_status_text'] ?? '';

                $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_useronline
                    SET etchat_user_online_user_status_img = '".addslashes($oldImg)."',
                        etchat_user_online_user_status_text = '".addslashes($oldText)."'
                    WHERE etchat_onlineuser_fid = $userID
                    AND etchat_user_online_user_status_img = 'status_off'");

                unset($_SESSION['etchat_'.$this->_prefix.'old_status_img']);
                unset($_SESSION['etchat_'.$this->_prefix.'old_status_text']);
            }
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: application/json; charset=utf-8');

        if (!empty($_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'])) {
            $grenzzeit1 = (date('U') - (((int)$_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] / 1000) * 8));
            $grenzzeit2 = (date('U') - (((int)$_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] / 1000) * 16));

            $userID = (int)$_SESSION['etchat_'.$this->_prefix.'user_id'];
            $statusRes = $this->dbObj->sqlGet("SELECT etchat_user_online_user_status_img, etchat_user_online_user_status_text
                FROM {$this->_prefix}etchat_useronline
                WHERE etchat_onlineuser_fid = $userID AND etchat_user_online_user_status_img != 'status_off' LIMIT 1");

            if (!empty($statusRes)) {
                $_SESSION['etchat_'.$this->_prefix.'old_status_img'] = $statusRes[0][0];
                $_SESSION['etchat_'.$this->_prefix.'old_status_text'] = $statusRes[0][1];
            }

            $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_useronline
                SET etchat_user_online_user_status_img = 'status_off',
                    etchat_user_online_user_status_text = 'Verbindung verloren'
                WHERE etchat_onlinetimestamp < $grenzzeit1");

			$this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline
				WHERE etchat_onlinetimestamp < $grenzzeit2");
        }

        $feld = $this->dbObj->sqlGet("SELECT
            etchat_user_online_user_name,
            etchat_user_online_room_name,
            etchat_fid_room,
            etchat_onlineuser_fid,
            etchat_onlineip,
            etchat_user_online_user_priv,
            etchat_user_online_room_goup,
            etchat_user_online_user_sex,
            etchat_user_online_user_status_img,
            etchat_user_online_user_status_text,
            etchat_avatar
            FROM {$this->_prefix}etchat_useronline
            ORDER BY etchat_fid_room, etchat_user_online_user_name");

        $roomarray = $this->dbObj->sqlGet("SELECT etchat_id_room, etchat_roomname, etchat_room_goup
            FROM {$this->_prefix}etchat_rooms
            WHERE etchat_id_room NOT IN (SELECT DISTINCT etchat_fid_room FROM {$this->_prefix}etchat_useronline)");

        if (!is_array($feld)) {
            $this->makeJsonOutput([], $roomarray);
        } else {
            if (!$this->anyChangesSinceLastPolling($feld, $roomarray)) {
                $this->dbObj->close();
            } else {
                $this->makeJsonOutput($feld, $roomarray);
            }
        }
    }

	private function anyChangesSinceLastPolling($feld, $roomarray) {
		$rel = '';

		if (is_array($feld)) {
			foreach ($feld as $row) {
				if (is_array($row)) {
					$rel .= implode('', $row);
				}
			}
		} else {
			$feld = [];
		}

		if (!is_array($roomarray)) {
			$roomarray = [];
		}

		foreach ($roomarray as $row) {
			if (is_array($row)) {
				$rel .= implode('', $row);
			}
		}

		if (isset($_SESSION['etchat_'.$this->_prefix.'block_all']) && is_array($_SESSION['etchat_'.$this->_prefix.'block_all'])) {
			$rel .= implode("-", $_SESSION['etchat_'.$this->_prefix.'block_all']);
		}

		if (isset($_SESSION['etchat_'.$this->_prefix.'block_priv']) && is_array($_SESSION['etchat_'.$this->_prefix.'block_priv'])) {
			$rel .= implode("-", $_SESSION['etchat_'.$this->_prefix.'block_priv']);
		}

		if (isset($_SESSION['etchat_'.$this->_prefix.'roompw_array']) && is_array($_SESSION['etchat_'.$this->_prefix.'roompw_array'])) {
			$rel .= implode("-", $_SESSION['etchat_'.$this->_prefix.'roompw_array']);
		}

		if (isset($_SESSION['etchat_'.$this->_prefix.'reload_user_anz']) && $_SESSION['etchat_'.$this->_prefix.'reload_user_anz'] === $rel) {
			return false;
		} else {
			$_SESSION['etchat_'.$this->_prefix.'reload_user_anz'] = $rel;
			return true;
		}
	}

    private function makeJsonOutput($feld, $roomarray) {
        echo "{ \"userOnline\" : [\n";

        for ($a = 0; $a < count($feld); $a++) {
            $user_id = (int)$feld[$a][3];
            $timestamp = 0;

            $regResult = $this->dbObj->sqlGet("SELECT etchat_reg_timestamp
                FROM {$this->_prefix}etchat_user
                WHERE etchat_user_id = '$user_id' LIMIT 1");

            if (!empty($regResult) && isset($regResult[0][0])) {
                $timestamp = strtotime($regResult[0][0]);
            }

            if (isset($_SESSION['etchat_'.$this->_prefix.'block_all']) && in_array($user_id, $_SESSION['etchat_'.$this->_prefix.'block_all'])) {
                $feld[$a][0] = "<strike>".$feld[$a][0];
            }
            if (isset($_SESSION['etchat_'.$this->_prefix.'block_priv']) && in_array($user_id, $_SESSION['etchat_'.$this->_prefix.'block_priv'])) {
                $feld[$a][0] = "<strike>".$feld[$a][0];
            }

            $room_allowed = new RoomAllowed($feld[$a][6], $feld[$a][2]);
            $room_status = $room_allowed->room_status;

            if (isset($_SESSION['etchat_'.$this->_prefix.'user_id']) && $_SESSION['etchat_'.$this->_prefix.'user_id'] == $feld[$a][3]) {
                $_SESSION['etchat_'.$this->_prefix.'userstatus'] = $feld[$a][8];
            }

            if ($a > 0) echo ",\n";

            echo "{";
            echo "\"user\": \"".addslashes($feld[$a][0])."\",";
            echo "\"user_id\": \"".$feld[$a][3]."\",";
            echo "\"user_priv\": \"".$feld[$a][5]."\",";
            echo "\"user_sex\": \"".$feld[$a][7]."\",";
            echo "\"user_simg\": \"".$feld[$a][8]."\",";
            echo "\"user_stext\": \"".$feld[$a][9]."\",";
            echo "\"room_id\": \"".$feld[$a][2]."\",";
            echo "\"room_allowed\": \"".$room_status."\",";
            echo "\"room\": \"".addslashes($feld[$a][1])."\",";
            echo "\"reg_timestamp\": \"".$timestamp."\",";
            echo "\"etchat_avatar\": \"".$feld[$a][10]."\"";


            if (isset($_SESSION['etchat_'.$this->_prefix.'user_priv']) && ($_SESSION['etchat_'.$this->_prefix.'user_priv'] == "admin" || $_SESSION['etchat_'.$this->_prefix.'user_priv'] == "mod" || $_SESSION['etchat_'.$this->_prefix.'user_priv'] == "grafik" || $_SESSION['etchat_'.$this->_prefix.'user_priv'] == "chatwache" || $_SESSION['etchat_'.$this->_prefix.'user_priv'] == "co_admin")) {
                echo ",\"user_ip\": \"".addslashes(str_replace("@", " - ", $feld[$a][4]))."\"";
            }
            echo "}";
        }

        echo "\n]";

        if (is_array($roomarray)) {
            echo ",\n\n \"all_empty_rooms\" : [\n";
            for ($a = 0; $a < count($roomarray); $a++) {
                $room_allowed2 = new RoomAllowed($roomarray[$a][2], $roomarray[$a][0]);

                if ($a > 0) echo ",\n";
                echo "{\"room_id\": \"".addslashes($roomarray[$a][0])."\",";
                echo "\"room_allowed\": \"".$room_allowed2->room_status."\",";
                echo "\"room\": \"".addslashes($roomarray[$a][1])."\"}";
            }
            echo "\n]";
        }

        echo "\n}";
    }

    private function getUserColor($priv) {
    switch($priv) {
        case 'admin': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
        case 'mod':   return "color: ".$_SESSION['etchat_'.$this->_prefix.'mod_color']."";
        case 'user':  return "color: ".$_SESSION['etchat_'.$this->_prefix.'user_color']."";
        case 'gast':  return "color: ".$_SESSION['etchat_'.$this->_prefix.'gast_color']."";
        case 'grafik': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
        case 'chatwache': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
        case 'co_admin': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
        default:      return "color: #FFFFFF";
    }
}



}