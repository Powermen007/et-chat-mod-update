<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

spl_autoload_register(function($class_name) {
	if (substr($class_name, 0, 5) == "Admin")
		require_once('class/admin/' . $class_name . '.class.php');
	elseif (substr($class_name, 0, 7) == "Install")
		require_once('class/install/' . $class_name . '.class.php');
	elseif (file_exists('class/' . $class_name . '.class.php'))
		require_once('class/' . $class_name . '.class.php');
	else
		return false;
});

$special_keys = ['register', 'token'];
$special_combination = isset($_GET['passwort']) && in_array($_GET['passwort'], ['vergessen', 'zuruecksetzen']);

$firstKey = array_keys($_GET)[0] ?? '';
if (in_array($firstKey, $special_keys) || $special_combination) {
	$init_class = "Index";
} else {
	$init_class = (!empty($firstKey)) ? $firstKey : "Index";
}

if (preg_match('/^[A-Za-z0-9_\-]+$/i', $init_class))
	new $init_class;
else
	echo "Not allowed sign in the class name!";

?>
