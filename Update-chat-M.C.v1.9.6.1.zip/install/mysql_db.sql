
ALTER TABLE `etchat_user` MODIFY `etchat_userpw` VARCHAR(255) CHARACTER SET `utf8mb4` COLLATE `utf8mb4_unicode_ci` NULL;