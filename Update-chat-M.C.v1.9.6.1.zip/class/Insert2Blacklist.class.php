<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Insert2Blacklist extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        $langObj = new LangXml();
        $lang    = $langObj->getLang()->admin[0]->add2blacklist[0] ?? null;

        $privilege = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        $allowedRoles = ["admin", "mod", "grafik", "chatwache", "co_admin"];

        if (!in_array($privilege, $allowedRoles, true)) {
            echo $lang->session_lost[0]->tagData ?? 'Session lost';
            $this->dbObj->close();
            return;
        }

        $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT) ?: 0;
        $time   = filter_input(INPUT_POST, 'time', FILTER_VALIDATE_INT) ?: 0;

        if ($userId <= 0) {
            echo "Invalid user id";
            $this->dbObj->close();
            return;
        }

        $userId = (int)$userId;
        $time   = (int)$time;

        // Online-IP per Prepared holen
        $ip = $this->dbObj->sqlGet(
            "SELECT etchat_onlineip 
             FROM {$this->_prefix}etchat_useronline 
             WHERE etchat_onlineuser_fid = :uid
             LIMIT 1",
            [':uid' => $userId]
        );

        if (empty($ip) || !is_array($ip)) {
            echo $lang->user_away[0]->tagData ?? 'User not online';
            $this->dbObj->close();
            return;
        }

        if ($time > 0) {

            // Blacklist über Klasse (falls vorhanden)
            $blObj = new Blacklist($this->dbObj);
            $blObj->insertUser($userId, $time);

        } else {

            // Kick-Eintrag mit Prepared
            $expireTime = time() + 30;

            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_kick_user 
                (etchat_kicked_user_id, etchat_kicked_user_time) 
                VALUES (:uid, :etime)",
                [
                    ':uid'   => $userId,
                    ':etime' => $expireTime
                ]
            );
        }

        $this->dbObj->close();
    }
}