<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class SysMessage extends EtChatConfig
{
    protected $dbObj;
    public $lastInsertedId;

    public function __construct($dbObj, $message, $room_fid, $privat)
    {
        parent::__construct();

        // Nachricht und CSS vorbereiten
        $css = 'color:#' . ($_SESSION['etchat_'.$this->_prefix.'syscolor'] ?? '000000') .
               ';font-weight:normal;font-style:normal;';

        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        // INSERT mit Prepared Statement
        $dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_messages
            (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat, etchat_user_ip)
            VALUES (:uid, :msg, :css, :ts, :room, :priv, :ip)",
            [
                ":uid"  => 1,
                ":msg"  => $message,
                ":css"  => $css,
                ":ts"   => date('U'),
                ":room" => (int)$room_fid,
                ":priv" => (int)$privat,
                ":ip"   => $ip
            ]
        );

        if (!empty($dbObj->lastId)) {
            $this->lastInsertedId = $dbObj->lastId;
        } else {
            $lastID = $dbObj->sqlGet("SELECT max(etchat_id) FROM {$this->_prefix}etchat_messages");
            $this->lastInsertedId = $lastID[0][0] ?? 0;
        }
    }
}