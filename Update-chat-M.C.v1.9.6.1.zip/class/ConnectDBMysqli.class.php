<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ConnectDBMysqli extends EtChatConfig
{
    protected ?mysqli $_connid = null;

    public $lastId = 0;

    public function __construct()
    {
        parent::__construct();

        $this->_connid = new mysqli(
            $this->_sqlhost,
            $this->_sqluser,
            $this->_sqlpass,
            $this->_database
        );

        if ($this->_connid->connect_errno) {
            echo "Datenbankverbindung fehlgeschlagen.";
            exit;
        }

        $this->_connid->set_charset("utf8mb4");
    }


    public function escape($value)
    {
        return $this->_connid->real_escape_string($value);
    }


    public function sqlGet(string $sql, array $params = [])
    {
        if ($sql === '') {
            return false;
        }

        try {

            if (!empty($params)) {

                $stmt = $this->_connid->prepare($sql);
                if (!$stmt) {
                    return false;
                }

                $types = str_repeat('s', count($params));
                $stmt->bind_param($types, ...$params);

                $stmt->execute();

                $result = $stmt->get_result();

                $data = [];

                if ($result) {
                    while ($row = $result->fetch_array(MYSQLI_BOTH)) {
                        $data[] = $row;
                    }
                }

                $stmt->close();

            } else {

                $result = $this->_connid->query($sql);

                if (!$result) {
                    return false;
                }

                $data = [];

                while ($row = $result->fetch_array(MYSQLI_BOTH)) {
                    $data[] = $row;
                }
            }

            if (empty($data)) {
                return false;
            }

            return $data;

        } catch (Throwable $e) {
            return false;
        }
    }


    public function sqlSet(string $sql, $params = [])
    {
        try {

            if (!is_array($params)) {
                $params = [];
            }

            if (!empty($params)) {

                $stmt = $this->_connid->prepare($sql);
                if (!$stmt) {
                    return false;
                }

                $types = str_repeat('s', count($params));
                $stmt->bind_param($types, ...$params);

                $stmt->execute();

                $this->lastId = $this->_connid->insert_id;

                $stmt->close();

                return true;
            }

            $result = $this->_connid->query($sql);

            $this->lastId = $this->_connid->insert_id;

            return $this->_connid->affected_rows;

        } catch (Throwable $e) {
            return false;
        }
    }


    public function close()
    {
        if ($this->_connid instanceof mysqli) {
            $this->_connid->close();
        }

        $this->_connid = null;
    }
}