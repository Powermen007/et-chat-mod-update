<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

require_once __DIR__ . '/ConnectDB.class.php';
require_once __DIR__ . '/DbConectionMaker.class.php';

require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Bewerbung extends DbConectionMaker
{
    protected string $styleName = 'default';

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        parent::__construct();

        $config = $this->dbObj->sqlGet(
            "SELECT etchat_config_style
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = ?
             LIMIT 1",
            [1]
        );

        $this->styleName = $config[0][0] ?? 'default';
    }

    public function getStyleName(): string
    {
        return $this->styleName;
    }

    public function getDb(): ConnectDB
    {
        return $this->dbObj;
    }

    public function senden(array $daten): string
    {

        // Spam Honeypots
        if (!empty($daten['https_ceck']) || !empty($daten['www'])) {
            return "Spam erkannt!";
        }

        // Captcha
        if (
            !isset($_SESSION['captcha_text']) ||
            strtolower((string)$daten['web_php_de']) !== strtolower((string)$_SESSION['captcha_text'])
        ) {
            return "Falsches Captcha! Bitte erneut versuchen.";
        }

        /* ---------------- DB Speicherung ---------------- */

        $saveData = $daten;

        unset(
            $saveData['https_ceck'],
            $saveData['www'],
            $saveData['web_php_de'],
            $saveData['action']
        );

        $jsonData = json_encode($saveData, JSON_UNESCAPED_UNICODE);

        $this->dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_bewerbungen
            (bewerber_daten, status)
            VALUES (?, ?)",
            [$jsonData, 'neu']
        );

        global $host, $sendemail, $mailpass, $smtpsecure, $port;

        try {

            /* ---------- Mail an Admin ---------- */

            $mailAdmin = $this->createMailer();

            $mailAdmin->setFrom($sendemail, 'Chat Bewerbungsformular');
            $mailAdmin->addAddress($sendemail);

            $betreff = $daten['Betreff'] ?? 'Unbekannte Bewerbung';
            $mailAdmin->Subject = "Neue Bewerbung: {$betreff}";

            $fixedOrder = ['Betreff','Anrede','Name','Modiename'];

            $message = "<h2>Neue Bewerbung eingegangen</h2><table>";

            foreach ($fixedOrder as $field) {
                if (!empty($daten[$field])) {
                    $message .= "<tr><td><strong>{$field}:</strong></td><td>"
                        . htmlspecialchars($daten[$field], ENT_QUOTES, 'UTF-8')
                        . "</td></tr>";
                }
            }

            $skip = array_merge($fixedOrder, ['https_ceck','www','web_php_de','action']);

            foreach ($daten as $key => $val) {

                if (in_array($key, $skip, true)) {
                    continue;
                }

                if (is_array($val)) {
                    $val = implode(", ", $val);
                }

                $message .= "<tr><td><strong>{$key}:</strong></td><td>"
                    . htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8')
                    . "</td></tr>";
            }

            $message .= "</table>";

            $mailAdmin->isHTML(true);
            $mailAdmin->Body = $message;
            $mailAdmin->AltBody = strip_tags($message);
            $mailAdmin->send();

            /* ---------- Bestätigung Bewerber ---------- */

            if (!empty($daten['E_Mail'])) {

                $mailBewerber = $this->createMailer();

                $mailBewerber->setFrom($sendemail, 'Chat Bewerbungsformular');
                $mailBewerber->addAddress($daten['E_Mail'], $daten['Name'] ?? 'Bewerber');

                $mailBewerber->Subject = "Ihre Bewerbung: {$betreff}";

                $text =
                    "Hallo " . ($daten['Name'] ?? '') . ",\n\n" .
                    "vielen Dank für Ihre Bewerbung als {$betreff}.\n" .
                    "Wir haben Ihre Bewerbung erhalten und melden uns zeitnah.\n\n" .
                    "Viele Grüße\nDas Team";

                $mailBewerber->isHTML(true);
                $mailBewerber->Body = nl2br($text);
                $mailBewerber->AltBody = $text;

                $mailBewerber->send();
            }

            return "Bewerbung erfolgreich gesendet!";

        } catch (Exception $e) {

            return "Fehler beim Versenden: " . $e->getMessage();
        }
    }

    private function createMailer(): PHPMailer
    {
        global $host, $sendemail, $mailpass, $smtpsecure, $port;

        $mail = new PHPMailer(true);

        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';

        $mail->isSMTP();
        $mail->Host = $host;
        $mail->SMTPAuth = true;
        $mail->Username = $sendemail;
        $mail->Password = $mailpass;
        $mail->SMTPSecure = $smtpsecure;
        $mail->Port = $port;

        return $mail;
    }
}