<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class MenuIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        $feld = $this->dbObj->sqlGet(
            "SELECT id, menu, link_text, image_active, image, url, target, gewicht
             FROM {$this->_prefix}etchat_menu
             WHERE menu = 2
             ORDER BY gewicht"
        );

        $this->dbObj->close();

        if (is_array($feld)) {

            foreach ($feld as $datasets) {

                // Attribute 1:1 aus DB übernehmen (Admin Inhalt)
                $attr = trim($datasets[2] ?? '');

                $url    = $datasets[5] ?? '#';
                $target = $datasets[6] ?? '_blank';
                $text   = $datasets[2] ?? '';
                $img    = $datasets[4] ?? '';

                if ($datasets[3] == 1) {
                    echo "<a class=\"start_text\" {$attr} href=\"#\" target=\"{$target}\">"
                       . "<img height=\"55\" alt=\"{$text}\" title=\"{$text}\" src=\"img/menu/{$img}\" />"
                       . "</a>&nbsp;&nbsp;&nbsp;";
                } else {
                    echo "<a class=\"start_text\" {$attr} href=\"{$url}\" target=\"{$target}\">{$text}</a>&nbsp;&nbsp;&nbsp;";
                }
            }
        }
    }
}
new MenuIndex();