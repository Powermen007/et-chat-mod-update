<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AfterKicklistInsertion extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);

        if ($userId > 0) {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_useronline 
                 WHERE etchat_onlineuser_fid = ?",
                [$userId]
            );
        }

        $this->dbObj->close();

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->kick[0] ?? null;

        $this->initTemplate($lang);

        session_unset();
        session_destroy();
    }

    private function initTemplate($lang): void
    {
        $style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'default';

        $template = "styles/" . $style . "/kicked.tpl.html";

        if (file_exists($template)) {
            include_once($template);
        }
    }
}
