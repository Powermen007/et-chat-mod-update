<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminHalloAnreden extends DbConectionMaker
{
    private $txtFile;
    private $desei; // Style aus DB
	private $meldung = '';

    public function __construct()
    {
        parent::__construct();
        session_start();

        // Style laden
        $this->desei = $this->dbObj->sqlGet("
            SELECT etchat_config_id, etchat_config_style 
            FROM {$this->_prefix}etchat_config 
            WHERE etchat_config_id = '1'
        ");

        // Admin-Prüfung
        $allowedRoles = ["admin", "co_admin"];
        if (!in_array($_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? '', $allowedRoles)) {
            header("Location: ./");
            exit;
        }

        // Auswahl bestimmen: hallo oder bye
        $typ = $_GET['typ'] ?? 'hallo';
        if (!in_array($typ, ['hallo', 'bye'])) $typ = 'hallo';

        // passende TXT-Datei
        $this->txtFile = __DIR__ . '/../../cache/' . ($typ === 'hallo' ? 'anreden.txt' : 'verabschieden.txt');

        // Formular absenden
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['anreden'])) {
            $this->speichereAnreden($_POST['anreden']);
        }

        $this->zeigeEditor($typ);
    }

    private function ladeAnreden()
    {
        if (!file_exists($this->txtFile)) return [];
        $lines = file($this->txtFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return array_map('trim', $lines);
    }

private function speichereAnreden($inhalt)
{
    $lines = array_map('trim', explode("\n", $inhalt));
    file_put_contents($this->txtFile, implode(PHP_EOL, $lines));

    // Meldung für die Anzeige im Editor speichern
    $this->meldung = '
    <div id="successMsg" style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        padding: 10px 15px;
        border-radius: 5px;
        margin: 10px 0;
        max-width: 600px;
    ">
        <span>✅ Datei wurde erfolgreich gespeichert!</span>
        <span style="cursor:pointer; font-weight:bold;" onclick="this.parentElement.style.display=\'none\'">&times;</span>
    </div>
    <script>
        setTimeout(function() {
            var msg = document.getElementById("successMsg");
            if(msg) msg.style.display = "none";
        }, 30000); // 30 Sekunden
    </script>
    ';
}

    private function zeigeEditor($typ)
    {
        $anreden = $this->ladeAnreden();
        $inhalt = htmlspecialchars(implode("\n", $anreden), ENT_QUOTES, 'UTF-8');

        $titel = ($typ === 'hallo') ? "Hallo-Anreden" : "Verabschiedungen";
        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Admin: <?php echo $titel; ?> bearbeiten</title>
            <?php
            if (is_array($this->desei)) {
                foreach ($this->desei as $data) {
                    echo '<link href="styles/' . htmlspecialchars($data[1]) . '/style.css" rel="stylesheet" type="text/css">';
                }
            }
            $this->dbObj->close();
            ?>
        </head>
        <body id="adminbereich_body">

<?php
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $roleLinks = ["admin"=>"./?AdminIndex","co_admin"=>"./?AdminIndexCoAdmin"];
        $backlinkUrl = $roleLinks[$role] ?? "./";
        echo "<a href=\"{$backlinkUrl}\">&lt;&lt;&lt; zurück zum Adminmenü</a><hr size=\"1\">";
?>

            <h2><?php echo $titel; ?> bearbeiten</h2>
<?php 
if ($this->meldung) {
    echo $this->meldung;
}
?>


            <form method="get" style="margin-bottom: 1em;" action="./">
                <input type="hidden" name="AdminHalloAnreden" value="">
                <label for="typ"><strong>Datei auswählen:</strong></label>
                <select name="typ" id="typ" onchange="this.form.submit()">
                    <option value="hallo" <?php echo $typ==='hallo'?'selected':''; ?>>Hallo-Anreden</option>
                    <option value="bye" <?php echo $typ==='bye'?'selected':''; ?>>Verabschiedungen</option>
                </select>
                <noscript><input type="submit" value="Anzeigen"></noscript>
            </form>

            <p>Jede Zeile entspricht einem Eintrag, z.B. „Hallo“ oder „Tschüss“.</p>
            <form method="post">
                <textarea name="anreden" style="width:50%;height:300px;padding:5px;margin:0 auto;"><?php echo $inhalt; ?></textarea><br>
                <input type="submit" value="Speichern">
            </form>
            
            <br>Mit .hallo und .bye sind sie ausführbar (Mann begrüßt bzw. verabschiedet alle Online User), weitere Befele sind .version und .time<br>Nur für Admin, Co-Admin, Chatwache und Grafiger gibt es noch .chatregeln und .reg
            
        </body>
        </html>
        <?php
    }
}
