<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class UnregisterPw extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        $sessionPrefix = 'etchat_' . $this->_prefix;

        $userId = (int)($_SESSION[$sessionPrefix.'user_id'] ?? 0);

        if ($userId <= 0) {
            echo "No Session";
            $this->dbObj->close();
            return;
        }

        $passwordInput = (string)($_POST['user_pw'] ?? '');

        // Benutzerdaten laden
        $user = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien, etchat_userpw, etchat_avatar
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :id
             LIMIT 1",
            [":id" => $userId]
        );

        $priv   = $user[0][0] ?? '';
        $dbHash = (string)($user[0][1] ?? '');

        if (!in_array($priv, ["admin", "mod", "user"], true)) {
            echo "No, no... ;-)";
            $this->dbObj->close();
            return;
        }

        $passwordOk = false;

        if ($dbHash !== '') {

            // moderner Hash
            if (password_verify($passwordInput, $dbHash)) {
                $passwordOk = true;
            }

            // alter MD5 Hash (Fallback)
            elseif (strlen($dbHash) === 32 && md5($passwordInput) === $dbHash) {
                $passwordOk = true;
            }
        }

        if ($passwordOk) {

            // Avatar laden

            $avatar = $user[0][2] ?? '';

            $filedir = __DIR__ . '/../avatar';

			if ($avatar && !in_array($avatar, ["noavatar.jpg","mod_ohne_pic.png","autodj.jpg"], true)) {

				$avatar = basename($avatar);

				$delfile = $filedir . DIRECTORY_SEPARATOR . $avatar;

				if (file_exists($delfile)) {
					@unlink($delfile);
				}
			}

            // Account zurücksetzen
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_user
                 SET
                    etchat_userpw = NULL,
                    etchat_userprivilegien = 'gast',
                    etchat_avatar = 'noavatar.jpg',
                    etchat_email = NULL,
                    etchat_reset_token = NULL,
                    etchat_reset_token_expiry = NULL,
                    etchat_geb_tag = NULL,
                    etchat_geb_monat = NULL,
                    etchat_geb_jahr = NULL,
                    etchat_ort = NULL,
                    etchat_beschreibung = NULL
                 WHERE etchat_user_id = :id",
                [":id" => $userId]
            );

            echo "1";

        } else {

            $langObj = new LangXml();
			$lang = $langObj->getLang()->unregisterpw_php[0] ?? null;

			if ($lang) {

				$warn1 = $lang->warning[0]->tagData ?? '';
				$warn2 = $lang->warning[1]->tagData ?? '';

				echo "<b>{$warn1}</b><br>{$warn2}";

			} else {

				echo "Password incorrect";
			}
        }

        $this->dbObj->close();
    }
}