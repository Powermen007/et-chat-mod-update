<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Erg�nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Erg�nzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Boxunten extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
    }

    public function render(): void
    {
        $sql = "SELECT id, ort, header_text, content
                FROM {$this->_prefix}etchat_start_boxes
                WHERE id = ? 
                LIMIT 1";

        $result = $this->dbObj->sqlGet($sql, [4]);

        if ($result && isset($result[0])) {

            $header = $result[0]['header_text'] ?? $result[0][2] ?? '';
            $content = $result[0]['content'] ?? $result[0][3] ?? '';

            echo '<h2 style="margin-top:0.05px;margin-bottom:0.05px;text-align:center;">';
            echo htmlspecialchars_decode($header, ENT_QUOTES);
            echo '</h2>';

            echo htmlspecialchars_decode($content, ENT_QUOTES);
        }

        $this->dbObj->close();
    }
}

/* Aufruf */
$box = new Boxunten();
$box->render();