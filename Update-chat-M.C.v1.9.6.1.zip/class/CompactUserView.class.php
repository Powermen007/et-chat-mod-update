<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class CompactUserView extends DbConectionMaker
{
    protected array $roleNames = [
        'admin'     => 'Administrator',
        'co_admin'  => 'Co-Administrator',
        'mod'       => 'Moderator',
        'chatwache' => 'Chatwache',
        'grafik'    => 'Grafiker',
        'user'      => 'Benutzer'
    ];

    public function __construct()
    {
        parent::__construct();

        // Standardfarben
        $adminc = '#FF0000';
        $modc   = '#00AAFF';
        $userc  = '#CCCCCC';

        // Farben aus DB laden
        $color = $this->dbObj->sqlGet(
            "SELECT etchat_config_admin_color, etchat_config_mod_color, etchat_config_user_color
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = ?",
            [1]
        );

        if (is_array($color) && isset($color[0])) {
            $adminc = $color[0][0] ?? $adminc;
            $modc   = $color[0][1] ?? $modc;
            $userc  = $color[0][2] ?? $userc;
        }

        // Benutzer laden (nur 'user' Privileg, letzte 5)
        $users = $this->dbObj->sqlGet(
            "SELECT etchat_username, etchat_userprivilegien, etchat_reg_timestamp,
                    etchat_usersex, etchat_avatar
             FROM {$this->_prefix}etchat_user
             WHERE etchat_userprivilegien = ?
             ORDER BY etchat_user_id DESC
             LIMIT 5",
            ['user']
        );

        $this->dbObj->close();

        echo '<div class="compact-user-row">';

        if (is_array($users)) {
            foreach ($users as $user) {

                if (!is_array($user)) continue;

                $username = $user[0] ?? '';
                $role     = $user[1] ?? 'user';
                $regRaw   = $user[2] ?? '';
                $genderId = $user[3] ?? '';
                $avatar   = basename($user[4] ?? '');

                $colors = [
                    'admin'     => $adminc,
                    'mod'       => $modc,
                    'user'      => $userc,
                    'chatwache' => $adminc,
                    'grafik'    => $adminc,
                    'co_admin'  => $adminc
                ];

                $borderColor = $colors[$role] ?? '#CCCCCC';
                $roleName    = $this->roleNames[$role] ?? ucfirst($role);

                $regDate = '–';
                if (!empty($regRaw) && strtotime($regRaw)) {
                    $regDate = date('d.m.Y', strtotime($regRaw));
                }

                $gender = match($genderId) {
                    'm' => 'Männlich',
                    'f' => 'Weiblich',
                    'n' => 'keine Angabe',
                    'd' => 'Divers',
                    default => ''
                };

                $title = sprintf(
                    "Benutzername: %s\nGeschlecht: %s\nPrivileg: %s\nDabei seit: %s",
                    htmlspecialchars($username, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
                    $gender,
                    $roleName,
                    $regDate
                );

                echo <<<HTML
<div class="compact-user-card"
     title="{$title}"
     style="border-color:{$borderColor}">
    <img src="avatar/{$avatar}" alt="{$username}">
</div>
HTML;
            }
        }

        echo '</div>';
    }
}

// Instanz erzeugen
new CompactUserView();