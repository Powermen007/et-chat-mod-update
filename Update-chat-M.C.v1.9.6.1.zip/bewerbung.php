<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

session_start();

// 1. Config laden
require_once __DIR__ . "/config.php";

// 2. Klassen laden
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/Bewerbung.class.php";

// 3. Bewerbung-Objekt
$bewerbung = new Bewerbung();
$style = $bewerbung->getStyleName();
$meldung = '';

// Formularverarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') == 1) {
    $meldung = $bewerbung->senden($_POST);
}

// Felder aus DB laden (PDO Prepared)
$fields = $bewerbung->getDb()->sqlGet(
    "SELECT *
     FROM {$prefix}etchat_bewerbung_fields
     WHERE etchat_visible=1
     ORDER BY etchat_sort_order ASC"
);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Bewerbung</title>
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style.css" rel="stylesheet">
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style-mobil-index.css" rel="stylesheet">
</head>
<body id="body">

<center><h2>Bewerbung</h2></center>

<?php if ($meldung): ?>
    <div class="meldung" style="background: <?= strpos($meldung, 'Fehler') !== false ? '#ff4c4c' : '#4caf50' ?>;">
        <?= htmlspecialchars($meldung) ?>
    </div>
<?php endif; ?>

<form method="POST" action="" class="bewerbung-form">
    <input type="hidden" name="action" value="1">
    <input type="hidden" name="https_ceck" value="">
    <input type="hidden" name="www" value="">

    Bitte f&uuml;llen Sie die mit <span class="pflichthinweis">*</span> gekennzeichneten Felder aus (Pflichtfelder).

<?php
foreach ($fields as $f) {
    $rawName = $f['etchat_field_name'];
    $name = preg_replace('/[^a-zA-Z0-9_]/', '_', $rawName);
    $label = htmlspecialchars($rawName);
    $required = $f['etchat_required'] ? 'required' : '';
    $pflichthinweis = $f['etchat_required'] ? ' <span class="pflichthinweis">*</span>' : '';
    $type = $f['etchat_field_type'] ?? 'text';
    $value = $_POST[$name] ?? '';

    switch ($type) {
        case 'text':
        case 'email':
        case 'date':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<input type='{$type}' name='{$name}' id='{$name}' {$required} value='" . htmlspecialchars($value) . "'>";
            break;

        case 'textarea':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<textarea name='{$name}' id='{$name}' {$required}>" . htmlspecialchars($value) . "</textarea>";
            break;

        case 'select':
            $options = json_decode($f['etchat_options'], true) ?: [];
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<select name='{$name}' id='{$name}' {$required}>";
            echo "<option value=''>Bitte ausw&auml;hlen:</option>";
            foreach ($options as $opt) {
                $sel = ($value == $opt) ? 'selected' : '';
                echo "<option value='" . htmlspecialchars($opt) . "' {$sel}>" . htmlspecialchars($opt) . "</option>";
            }
            echo "</select>";
            break;

        case 'checkbox':
            $options = json_decode($f['etchat_options'], true) ?: [];
            echo "<label>{$label}:{$pflichthinweis}</label>";
            echo '<div class="musikrichtungen">';
            foreach ($options as $opt) {
                $chk = in_array($opt, (array)$value, true) ? 'checked' : '';
                echo '<div class="musikrichtung-option">';
                echo "<label><input type='checkbox' name='{$name}[]' value='" . htmlspecialchars($opt) . "' {$chk}> " . htmlspecialchars($opt) . "</label>";
                echo '</div>';
            }
            echo '</div>';
            break;
    }
}
?>

    <label for="web_php_de">Bitte geben Sie die Zeichen ein:<span class="pflichthinweis">*</span></label>
    <div class="captcha-group">
        <img src="captcha.php" alt="Captcha" onclick="this.src='captcha.php?'+Math.random();" title="Klicken zum Neuladen">
        <input type="text" name="web_php_de" id="web_php_de" maxlength="5" required>
    </div>

    <button type="submit">Anfrage senden</button>
</form>

</body>
</html>