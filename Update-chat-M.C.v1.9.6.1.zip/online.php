<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

$GLOBALS["path"] = "./";

spl_autoload_register(function($class_name) {
    require_once($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class Online extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // Config abrufen
        $una = $this->dbObj->sqlGet(
            "SELECT etchat_config_name_user 
             FROM {$this->_prefix}etchat_config 
             WHERE etchat_config_id = :id",
            [':id' => 1]
        );

        $timestamp = time() - 30;

        // Anzahl online User
        $erg = $this->dbObj->sqlGet(
            "SELECT COUNT(etchat_onlineid) 
             FROM {$this->_prefix}etchat_useronline 
             WHERE etchat_onlinetimestamp > :ts
             AND (etchat_user_online_user_status_img IS NULL 
                  OR etchat_user_online_user_status_img <> 'status_invisible')",
            [':ts' => $timestamp]
        );

        echo ($erg[0][0] ?? 0) . " User sind online.<br />";

        // Limit aus Session
        $limit_users = (int) ($_SESSION['etchat_'.$this->_prefix.'name_user_anz'] ?? 10);

        // Letzte Login User abrufen
        $erg_user = $this->dbObj->sqlGet(
            "SELECT u.etchat_user_online_user_name, u.etchat_user_online_user_priv
             FROM {$this->_prefix}etchat_useronline u
             JOIN {$this->_prefix}etchat_user usr
               ON usr.etchat_username = u.etchat_user_online_user_name
             WHERE u.etchat_onlinetimestamp > :ts
             AND (u.etchat_user_online_user_status_img IS NULL 
                  OR u.etchat_user_online_user_status_img <> 'status_invisible')
             ORDER BY usr.etchat_logintime DESC
             LIMIT $limit_users",
            [':ts' => $timestamp]
        );

        // Top User anzeigen, falls Config aktiviert
        if (($una[0][0] ?? 0) == 1 && is_array($erg_user) && count($erg_user) > 0) {
            echo "Letzte Login (Top $limit_users):<br />";

            $anzahl = count($erg_user);
            foreach ($erg_user as $index => $us) {
                echo htmlspecialchars($us[0]);
                if ($index < $anzahl - 1) {
                    echo ",&nbsp;";
                }
            }
            echo "<br />";
        }

        $this->dbObj->close();
    }
}

// Initialisieren
new Online();
?>