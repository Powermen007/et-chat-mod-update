<?php
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL
ET-Chat_T-FISH-MOD Weiterentwicklung durch Tommy und Harlekin
*/

$GLOBALS["path"] = "./";

spl_autoload_register(function($class_name) {
    require_once($GLOBALS["path"] . 'class/' . $class_name . '.class.php');
});

require_once __DIR__ . "/class/Smileys.class.php";

class SmileyPopup extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // DB Style laden
        $styleData = $this->dbObj->sqlGet("SELECT etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = 1");
        $style = $styleData[0]['etchat_config_style'] ?? 'etchat_black';
        $this->dbObj->close();
        ?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Smileys</title>

    <!-- CSS laden -->
    <link rel="stylesheet" href="styles/<?php echo htmlspecialchars($style); ?>/style.css">
    <link rel="stylesheet" href="styles/<?php echo htmlspecialchars($style); ?>/style-mobil.css" type="text/css">

	<script type="text/javascript" src="js/popupsmiley.js"></script>

</head>
<body id="body" class="smiley-popup">

<?php
// Smileys ausgeben
echo "<div id='smileys_list'>";
new Smileys();
echo "</div>";
?>

</body>
</html>

<?php
    }
}

new SmileyPopup();
?>
