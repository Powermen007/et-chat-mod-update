INSERT INTO `etchat_user` (`etchat_user_id`, `etchat_username`, `etchat_userpw`, `etchat_userprivilegien`, `etchat_usersex`, `etchat_reg_timestamp`, `etchat_reg_ip`, `etchat_avatar`, `etchat_logintime`, `etchat_email`, `etchat_reset_token`, `etchat_reset_token_expiry`, `etchat_geb_tag`, `etchat_geb_monat`, `etchat_geb_jahr`, `etchat_ort`, `etchat_beschreibung`, `etchat_last_ip`, `etchat_onlinetime`) VALUES ('-1', 'ChatBot', '00000000', 'ChatBot', 'n', '1980-01-01 00:00:00.000000', NULL, 'bot_avatar.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0'); 

ALTER TABLE `etchat_config` ADD `etchat_bot` TINYINT(2) NOT NULL DEFAULT '1' AFTER `etchat_top_user`; 

ALTER TABLE `etchat_useronline` ADD `etchat_last_ping` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `etchat_onlineuser_zeit`; 

ALTER TABLE `etchat_config` ADD `etchat_tab_away_delay` INT(4) NOT NULL DEFAULT '150' AFTER `etchat_bot`; 