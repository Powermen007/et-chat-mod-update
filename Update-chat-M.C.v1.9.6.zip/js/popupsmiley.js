// Rechtsklick auf Bilder verbieten
document.addEventListener("contextmenu", function(e) {
    if (e.target.nodeName === "IMG") {
        e.preventDefault();
    }
}, false);

/* ===============================
   1️⃣ Lazy-Load & Kategorien
=============================== */
document.addEventListener('DOMContentLoaded', function () {

    // Smileys nachladen
    document.querySelectorAll('#smileys_list img[data-src]').forEach(img => {
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
    });

    // Fehlerhafte Bilder neu laden
    document.querySelectorAll('#smileys_list img.img_smiley').forEach(img => {
        img.onerror = () => {
            console.warn('Smiley konnte nicht geladen werden:', img.src);
            img.src = img.src + '?reload=' + Date.now();
        };
    });

    // Kategorien umschalten
    document.querySelectorAll('#smileys_list .tablinks').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();

            const targetId = this.textContent.trim();

            document.querySelectorAll('#smileys_list .tabcontent')
                .forEach(c => c.style.display = 'none');

            document.querySelectorAll('#smileys_list .tablinks')
                .forEach(a => a.classList.remove('active'));

            const target = document.getElementById(targetId);
            if (target) target.style.display = 'block';

            this.classList.add('active');
        });
    });
});

/* ===============================
   Smiley-Klick → ins Hauptfeld & Cursor korrekt
=============================== */
document.addEventListener('click', function (e) {

    if (!e.target.classList.contains('img_smiley')) return;

    const code = e.target.id;

    if (!window.opener || window.opener.closed) return;

    const inputFieldName = new URLSearchParams(location.search).get('input') || 'message';
    const field = window.opener.document.getElementById(inputFieldName);
    if (!field) return;

    // Fokus zuerst setzen
    field.focus();

    // Text einfügen & Cursor setzen
    const insert = ' ' + code + ' ';
    const start = field.selectionStart ?? field.value.length;
    const end   = field.selectionEnd ?? field.value.length;

    field.value =
        field.value.substring(0, start) +
        insert +
        field.value.substring(end);

    // Cursor direkt hinter das Smiley setzen
    const newPos = start + insert.length;

    // Fokus nochmal setzen nach Wertänderung
    field.setSelectionRange(newPos, newPos);
    field.focus();
});