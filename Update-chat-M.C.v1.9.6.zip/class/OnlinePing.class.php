﻿<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und ErgÃ¤nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class OnlinePing extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
		session_start();

        $userId = (int)($_POST['user_id'] ?? $_GET['user_id'] ?? 0);
        if ($userId <= 0) exit;

        $prefix = $this->_prefix ?? 'db1_';

        // 1️⃣ EIGENEN PING ZUERST AKTUALISIEREN
        $this->dbObj->sqlSet("
            UPDATE {$prefix}etchat_useronline
            SET etchat_last_ping = NOW()
            WHERE etchat_onlineuser_fid = {$userId}
        ");

        // 2️⃣ DANACH OFFLINE-USER PRÜFEN (AUSSER MIR)
        $this->checkOfflineUsers($userId);

        exit;
    }

    private function checkOfflineUsers(int $currentUserId)
    {
$timeout = 60; // Sekunden
$prefix  = $this->_prefix;

// alle verwaisten Online-User holen
$offlineUsers = $this->dbObj->sqlGet("
    SELECT
    uo.etchat_onlineuser_fid AS user_id,
    uo.etchat_avatar   AS online_avatar,
    u.etchat_username,
    u.etchat_userprivilegien,
    u.etchat_avatar    AS user_avatar
    FROM {$prefix}etchat_useronline uo
    JOIN {$prefix}etchat_user u
        ON u.etchat_user_id = uo.etchat_onlineuser_fid
    WHERE
        TIMESTAMPDIFF(SECOND, uo.etchat_last_ping, NOW()) > {$timeout}
");


foreach ($offlineUsers as $u) {

    $name      = htmlentities($u['etchat_username'], ENT_QUOTES, 'UTF-8');
    $sysColor  = $this->getSystemColor();
    $nameColor = $this->getPrivColor($u['etchat_userprivilegien']);

    $avatarFile = $u['online_avatar'] ?: $u['user_avatar'] ?: 'noavatar.jpg';

    $avatar =
        '<img src="avatar/' .
        htmlentities($avatarFile, ENT_QUOTES, 'UTF-8') .
        '" class="avatar_w">';

    $msg =
        $avatar .
        '<span style="'.$sysColor.'">' .
            '<span style="'.$nameColor.'"><b>'.$name.'</b></span>' .
            ' hat den Tab/Browser geschlossen.' .
        '</span>';

    new SysMessage($this->dbObj, $msg, 0, 0);

    $this->dbObj->sqlSet("
        DELETE FROM {$prefix}etchat_useronline
        WHERE etchat_onlineuser_fid = ".(int)$u['user_id']
    );
}
	}

private function getSystemColor(): string
{
    $prefix = $this->_prefix ?? 'db1_';

    // 🔹 1. Style aus DB holen
    $styleData = $this->dbObj->sqlGet("
        SELECT etchat_config_style
        FROM {$prefix}etchat_config
        LIMIT 1
    ");

    $style = $styleData[0]['etchat_config_style'] ?? 'default';

    // 🔹 2. Pfade zu den CSS-Dateien
    $stylePath = "styles/{$style}/";
    $variablesFile = $stylePath . "variables.css";
    $styleFile     = $stylePath . "style.css";

    // 🔹 3. Farbe aus variables.css
    if (file_exists($variablesFile)) {
        $content = file_get_contents($variablesFile);
        if (preg_match('/--\s*Systemfarbe\s*:\s*#?([0-9a-f]{3,6})\s*;/i', $content, $m)) {
            return 'color:#' . strtolower($m[1]);
        }
    }

    // 🔹 4. Fallback style.css
    if (file_exists($styleFile)) {
        foreach (file($styleFile) as $line) {
            if (preg_match('/^Systemfarbe\s*:\s*#?([0-9a-f]{3,6})/i', trim($line), $m)) {
                return 'color:#' . strtolower($m[1]);
            }
        }
    }

    // 🔹 5. Ultimativer Fallback
    return 'color:#fff';
}

private function getPrivColor(string $priv): string
{
    $prefix = $this->_prefix ?? 'db1_';

    $cfg = $this->dbObj->sqlGet("
        SELECT
            etchat_config_admin_color,
            etchat_config_mod_color,
            etchat_config_user_color,
            etchat_config_gast_color
        FROM {$prefix}etchat_config
        LIMIT 1
    ");

    if (!$cfg) {
        return 'color:#fff';
    }

    $row = $cfg[0];

    $map = [
        'admin' => $row['etchat_config_admin_color'] ?? null,
        'mod'   => $row['etchat_config_mod_color']   ?? null,
        'user'  => $row['etchat_config_user_color']  ?? null,
        'gast'  => $row['etchat_config_gast_color']  ?? null,
    ];

    $color = $map[$priv] ?? null;

    return $color
        ? 'color:#' . ltrim(strtolower($color), '#')
        : 'color:#fff';
}

}
?>