<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski
ET-Chat_T-FISH-MOD Weiterentwicklung durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
*/

class TabFocus extends DbConectionMaker
{
    public function __construct() {
        parent::__construct();
        session_start();

        if (!isset($_SESSION['etchat_'.$this->_prefix.'user_id'])) {
            exit;
        }

        $userID = (int)$_SESSION['etchat_'.$this->_prefix.'user_id'];
        $mode   = $_GET['mode'] ?? '';

        // =========================================================
        // MODE AWAY
        // =========================================================
        if ($mode === 'away') {

            // Multi-Tab-Schutz:
            // War vor kurzem ein anderer Tab aktiv ? abbrechen
            $lastActive = $_SESSION['__TABFOCUS_LAST_ACTIVE__'] ?? 0;
            if ($lastActive > time() - 10) {
                return;
            }

            $res = $this->dbObj->sqlGet("
                SELECT etchat_user_online_user_status_img,
                       etchat_user_online_user_status_text
                FROM {$this->_prefix}etchat_useronline
                WHERE etchat_onlineuser_fid = $userID
                LIMIT 1
            ");

            $currentImg  = $res[0][0] ?? '';
            $currentText = $res[0][1] ?? '';

            // Away darf sich selbst NICHT �berschreiben
            if ($currentImg === 'status_tabaway') {
                return;
            }

            // Originalstatus sichern
            $_SESSION['__TABFOCUS__'] = [
                'old_img'  => $currentImg,
                'old_text' => $currentText,
                'ts'       => time()
            ];

            // Jetzt auf away setzen
            $this->dbObj->sqlSet("
                UPDATE {$this->_prefix}etchat_useronline
                SET etchat_user_online_user_status_img = 'status_tabaway',
                    etchat_user_online_user_status_text = 'Abwesend'
                WHERE etchat_onlineuser_fid = $userID
            ");
        }

        // =========================================================
        // MODE BACK
        // =========================================================
        if ($mode === 'back' && isset($_SESSION['__TABFOCUS__'])) {

            // Diesen Tab als letzten aktiven merken
            $_SESSION['__TABFOCUS_LAST_ACTIVE__'] = time();

            $oldImg  = $_SESSION['__TABFOCUS__']['old_img']  ?? '';
            $oldText = $_SESSION['__TABFOCUS__']['old_text'] ?? '';

            $this->dbObj->sqlSet("
                UPDATE {$this->_prefix}etchat_useronline
                SET etchat_user_online_user_status_img = '".addslashes($oldImg)."',
                    etchat_user_online_user_status_text = '".addslashes($oldText)."'
                WHERE etchat_onlineuser_fid = $userID
            ");

            unset($_SESSION['__TABFOCUS__']);
        }
    }
}
