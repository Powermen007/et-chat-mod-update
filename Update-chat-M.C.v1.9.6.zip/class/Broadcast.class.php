<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class Broadcast extends DbConectionMaker
{
    private $broadcast_file = 'broadcast_current.txt';
    
    public function __construct() {
        parent::__construct();
        
        if (session_status() == PHP_SESSION_NONE) {
            @session_start();
        }
        
        header('Content-Type: application/json');
        
        $function = $_GET['function'] ?? '';
        
        if ($function == 'sendBroadcast') {
            $this->sendBroadcast();
        } elseif ($function == 'checkBroadcast') {
            $this->checkBroadcast();
        } elseif ($function == 'clearBroadcast') {
            $this->clearBroadcast();
        } elseif ($function == 'getBroadcastStatus') {
            $this->getBroadcastStatus();
        } else {
            echo json_encode(['error' => 'Unbekannte Funktion']);
        }
        
        if (isset($this->dbObj)) {
            $this->dbObj->close();
        }
        exit;
    }
    
    private function getRealOnlineUsers() {
        $current_time = time();
        $timeout = 300;
        $time_limit = $current_time - $timeout;
        
        $sqlRegistered = "SELECT 
            u.etchat_user_id,
            u.etchat_username, 
            u.etchat_userprivilegien
        FROM {$this->_prefix}etchat_useronline o
        JOIN {$this->_prefix}etchat_user u ON o.etchat_user_online_user_name = u.etchat_username
        WHERE o.etchat_onlinetimestamp > $time_limit
        AND (o.etchat_user_online_user_status_img IS NULL 
             OR o.etchat_user_online_user_status_img NOT IN ('status_invisible', 'status_off'))
        AND u.etchat_userprivilegien != 'admin'";

        $sqlGuests = "SELECT 
            etchat_onlineuser_fid,
            LOWER(TRIM(etchat_user_online_user_name)) as etchat_username,
            'gast' as etchat_userprivilegien
        FROM {$this->_prefix}etchat_useronline
        WHERE etchat_onlinetimestamp > $time_limit
        AND (etchat_user_online_user_name LIKE 'Gast%' OR etchat_user_online_user_priv = 'gast')
        AND (etchat_user_online_user_status_img IS NULL 
             OR etchat_user_online_user_status_img NOT IN ('status_invisible', 'status_off'))
        AND LOWER(TRIM(etchat_user_online_user_name)) NOT IN (
            SELECT LOWER(etchat_username) FROM {$this->_prefix}etchat_user
        )
        GROUP BY LOWER(TRIM(etchat_user_online_user_name))";

        $sql = "($sqlRegistered) UNION ALL ($sqlGuests)";
        
        $result = $this->dbObj->sqlGet($sql);
        
        $online_users = [];
        if ($result && is_array($result)) {
            foreach ($result as $row) {
                if (isset($row[0])) {
                    $online_users[] = (int)$row[0];
                }
            }
        }
        
        return $online_users;
    }
    
    private function isUserOnline($user_id) {
        $current_time = time();
        $timeout = 300;
        $time_limit = $current_time - $timeout;
        
        $sql = "SELECT COUNT(*) as count 
                FROM {$this->_prefix}etchat_useronline 
                WHERE etchat_onlineuser_fid = $user_id 
                AND etchat_onlinetimestamp > $time_limit
                AND (etchat_user_online_user_status_img IS NULL 
                     OR etchat_user_online_user_status_img NOT IN ('status_invisible', 'status_off'))";
        
        $result = $this->dbObj->sqlGet($sql);
        if ($result && is_array($result) && isset($result[0][0])) {
            return $result[0][0] > 0;
        }
        
        return false;
    }
    
    private function sendBroadcast() {
        if ($_SESSION['etchat_'.$this->_prefix.'user_priv'] == 'admin') {
            $message = $_POST['message'] ?? '';
            $admin_id = $_POST['admin_id'] ?? '';
            $no_reload = $_POST['no_reload'] ?? 0;
            $message_type = $_POST['message_type'] ?? 'standard';
            
            $no_reload = intval($no_reload);
            
            if (!empty($message)) {
                $timestamp = time();
                
                $target_users = $this->getRealOnlineUsers();
                $original_online_count = count($target_users);
                
                $data = [
                    'timestamp' => $timestamp,
                    'admin_id' => $admin_id,
                    'message' => $message,
                    'no_reload' => $no_reload,
                    'message_type' => $message_type,
                    'target_users' => $target_users,
                    'original_online_count' => $original_online_count,
                    'seen_by' => []
                ];
                
                file_put_contents($this->broadcast_file, json_encode($data));
                
                $_SESSION['last_broadcast_seen'] = $timestamp;
                
                echo json_encode([
                    'success' => true, 
                    'target_count' => count($target_users),
                    'original_online_count' => $original_online_count,
                    'message_type' => $message_type,
                    'target_users' => $target_users
                ]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Leere Nachricht']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Keine Admin-Rechte']);
        }
    }
    
    private function checkBroadcast() {
        $current_user_priv = $_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? 'user';
        $current_user_id = $_SESSION['etchat_'.$this->_prefix.'user_id'] ?? 0;
        
        if ($current_user_priv == 'admin') {
            echo json_encode(['hasBroadcast' => false, 'debug' => 'user_is_admin']);
            return;
        }
        
        if (file_exists($this->broadcast_file)) {
            $data = file_get_contents($this->broadcast_file);
            $broadcast = json_decode($data, true);
            
            if ($broadcast && isset($broadcast['message'])) {
                $is_online = $this->isUserOnline($current_user_id);
                $seen_by = $broadcast['seen_by'] ?? [];
                
                if (in_array($current_user_id, $seen_by)) {
                    echo json_encode(['hasBroadcast' => false, 'debug' => 'already_seen']);
                    return;
                }
                
                switch($broadcast['message_type']) {
                    case 'standard':
                        if (!$is_online) {
                            echo json_encode(['hasBroadcast' => false, 'debug' => 'user_not_online']);
                            return;
                        }
                        
                        if (!in_array($current_user_id, $broadcast['target_users'])) {
                            echo json_encode(['hasBroadcast' => false, 'debug' => 'user_not_in_target']);
                            return;
                        }
                        break;
                        
                    case 'general':
                        break;
                        
                    case 'welcome':
                        if (in_array($current_user_id, $broadcast['target_users'])) {
                            echo json_encode(['hasBroadcast' => false, 'debug' => 'user_was_already_online']);
                            return;
                        }
                        
                        if (!$is_online) {
                            echo json_encode(['hasBroadcast' => false, 'debug' => 'user_not_online_for_welcome']);
                            return;
                        }
                        break;
                }
                
                $seen_by[] = $current_user_id;
                $broadcast['seen_by'] = $seen_by;
                file_put_contents($this->broadcast_file, json_encode($broadcast));
                
                echo json_encode([
                    'hasBroadcast' => true, 
                    'message' => $broadcast['message'],
                    'no_reload' => $broadcast['no_reload'],
                    'debug' => 'new_broadcast_for_user_' . $broadcast['message_type']
                ]);
                
            } else {
                unlink($this->broadcast_file);
                echo json_encode(['hasBroadcast' => false]);
            }
        } else {
            echo json_encode(['hasBroadcast' => false, 'debug' => 'no_broadcast']);
        }
    }
    
    private function getBroadcastStatus() {
        if (file_exists($this->broadcast_file)) {
            $data = file_get_contents($this->broadcast_file);
            $broadcast = json_decode($data, true);
            
            if ($broadcast && isset($broadcast['message'])) {
                $current_online_count = count($this->getRealOnlineUsers());
                $timestamp = $broadcast['timestamp'];
                $time_ago = $this->getTimeAgo($timestamp);
                
                switch($broadcast['message_type']) {
                    case 'standard':
                        $target_count = count($broadcast['target_users'] ?? []);
                        $original_online_count = $broadcast['original_online_count'] ?? $target_count;
                        break;
                        
                    case 'general':
                        $target_count = $current_online_count;
                        $original_online_count = $broadcast['original_online_count'] ?? $current_online_count;
                        break;
                        
                    case 'welcome':
                        $target_count = 0;
                        $original_online_count = 0;
                        break;
                }
                
                echo json_encode([
                    'hasBroadcast' => true, 
                    'message' => $broadcast['message'],
                    'timestamp' => $broadcast['timestamp'],
                    'time_ago' => $time_ago,
                    'admin_id' => $broadcast['admin_id'],
                    'no_reload' => $broadcast['no_reload'],
                    'message_type' => $broadcast['message_type'],
                    'target_count' => $target_count,
                    'original_online_count' => $original_online_count,
                    'current_online_count' => $current_online_count,
                    'seen_count' => count($broadcast['seen_by'] ?? [])
                ]);
            } else {
                unlink($this->broadcast_file);
                echo json_encode(['hasBroadcast' => false]);
            }
        } else {
            echo json_encode(['hasBroadcast' => false]);
        }
    }
    
    private function getTimeAgo($timestamp) {
        $current_time = time();
        $time_difference = $current_time - $timestamp;
        
        if ($time_difference < 60) {
            return 'Gerade eben';
        } elseif ($time_difference < 3600) {
            $minutes = floor($time_difference / 60);
            return "Vor {$minutes} Minute" . ($minutes > 1 ? 'n' : '');
        } elseif ($time_difference < 86400) {
            $hours = floor($time_difference / 3600);
            return "Vor {$hours} Stunde" . ($hours > 1 ? 'n' : '');
        } else {
            $days = floor($time_difference / 86400);
            return "Vor {$days} Tag" . ($days > 1 ? 'en' : '');
        }
    }
    
    private function clearBroadcast() {
        if ($_SESSION['etchat_'.$this->_prefix.'user_priv'] == 'admin') {
            if (file_exists($this->broadcast_file)) {
                unlink($this->broadcast_file);
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Kein aktiver Broadcast']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Keine Admin-Rechte']);
        }
    }
}