<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class AdminBroadcast extends DbConectionMaker
{

    public function __construct (){ 
        
        parent::__construct(); 

        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');
        
        $this->configTabData2Session();
        $this->dbObj->close();
            
        $langObj = new LangXml();
        $lang=$langObj->getLang()->admin[0]->admin_prop[0];
        
$userPriv = $_SESSION['etchat_'.$this->_prefix.'user_priv'];

$allowed = ['admin', 'co_admin'];

if (in_array($userPriv, $allowed, true)) {

    $backlink = ($userPriv === 'co_admin')
        ? './?AdminIndexCoAdmin'
        : './?AdminIndex';

    include_once("styles/admin_tpl/indexBroadcast.tpl.html");

} else {
    echo $lang->error[0]->tagData;
    return false;
}
    }
}