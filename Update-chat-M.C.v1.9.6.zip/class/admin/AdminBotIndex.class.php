<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

class AdminBotIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_rooms[0];

        if (!in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "co_admin"])) {
            echo $lang->error[0]->tagData;
            return false;
        }

        // Sicherheitscheck
        $_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] = rand(1, 999999999);

        // HTML/JSON Seite rendern
        $this->renderBotAdmin();
    }

    private function renderBotAdmin()
    {
        $jsonFile = __DIR__ . "/../bot_answers.json"; // korrigierter Pfad

        // -------------------------------------------------------------
        // JSON laden
        // -------------------------------------------------------------
        $botAnswers = [];
        if (file_exists($jsonFile)) {
            $botAnswers = json_decode(file_get_contents($jsonFile), true);
        }
        if (!is_array($botAnswers)) {
            $botAnswers = [];
        }

// -------------------------------------------------------------
// Bot Status aus SESSION
// -------------------------------------------------------------
$botEnabled = (int)($_SESSION['etchat_'.$this->_prefix.'etchat_bot'] ?? 0);

        // -------------------------------------------------------------
        // Antwort löschen
        // -------------------------------------------------------------
        if (isset($_GET["delete"])) {
            $deleteIndex = (int)$_GET["delete"];
            unset($botAnswers[$deleteIndex]);
            $botAnswers = array_values($botAnswers); // neu indexieren
            file_put_contents($jsonFile, json_encode($botAnswers, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            header("Location: ?AdminBotIndex");

            exit;
        }

        // -------------------------------------------------------------
        // Neue Antwort speichern
        // -------------------------------------------------------------
        if (isset($_POST["new_answer"])) {
            $new = trim($_POST["new_answer"]);
            if ($new !== "") {
                $botAnswers[] = $new;
                file_put_contents($jsonFile, json_encode($botAnswers, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
            header("Location: ?AdminBotIndex");

            exit;
        }

// -------------------------------------------------------------
// Bot an / aus schalten (wie die anderen Felder)
// -------------------------------------------------------------
if (isset($_POST['toggle_bot'])) {

    $newStatus = isset($_POST['etchat_bot']) ? 1 : 0;
    $newStatus = (int)$newStatus;

    // SQL bauen
    $sql = "UPDATE {$this->_prefix}etchat_config 
            SET etchat_bot = {$newStatus} 
            WHERE etchat_config_id = 1";

    // Wrapper nutzen – ET-Chat Standard
    $this->dbObj->sqlSet($sql);

    // Session sofort aktualisieren
    $_SESSION['etchat_'.$this->_prefix.'etchat_bot'] = $newStatus;

    header("Location: ?AdminBotIndex");
    exit;
}





        // -------------------------------------------------------------
        // HTML Ausgabe
        // -------------------------------------------------------------
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>ChatBot Antworten verwalten</title>
			<link href="styles/<?php echo $_SESSION['etchat_'.$this->_prefix.'style']; ?>/style.css" rel="stylesheet">
            <style>
                table { width: 99%; border-collapse: collapse; }
                td, th { padding: 8px; border-bottom: 1px solid #ccc; }
                textarea { width: 90%; height: 40px; }
                button {padding: 8px 12px; color: var(--color-text-webfarbe); background-color: var(--color-button-zeilen);}
            </style>
        </head>
        <body id="adminbereich_body">
		<?php
		        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $roleLinks = [
            "admin"     => "./?AdminIndex",
            "chatwache" => "./?AdminIndexChatwache",
            "co_admin"  => "./?AdminIndexCoAdmin"
        ];
        $backlinkUrl = $roleLinks[$role] ?? "./";
        echo "<a href=\"$backlinkUrl\">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml; </a><hr size=\"1\">";
		?>

        <h2><center>ChatBot</center></h2>

<h3>ChatBot Status</h3>

<form method="post">
    <label style="cursor:pointer;">
        <input type="checkbox" name="etchat_bot" value="1"
            <?php if ($botEnabled === 1) echo 'checked'; ?>>
        ChatBot aktivieren
    </label>
    <br><br>
    <button type="submit" name="toggle_bot">
        Status speichern
    </button>
</form>

<p>
    Aktueller Status:
    <strong style="color:<?php echo $botEnabled ? 'green' : 'red'; ?>">
        <?php echo $botEnabled ? 'AKTIV' : 'DEAKTIVIERT'; ?>
    </strong>
</p>

<hr size="1">

        <h3>Neue Antwort hinzufügen</h3>
        <form method="post">
            <textarea name="new_answer" placeholder="Neue Bot-Antwort hier eingeben..."></textarea>
            <br>
            <button type="submit">Hinzufügen</button>
        </form>
		
		<hr size="1">

        <h3>Vorhandene Antworten (<?php echo count($botAnswers); ?> Stück)</h3>
        <table>
            <tr><th>#</th><th>Antwort</th><th>Aktion</th></tr>
            <?php foreach ($botAnswers as $index => $answer): ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($answer); ?></td>
                    <td>
                          <a href="?AdminBotIndex&delete=<?php echo $index; ?>" onclick="return confirm('Diese Antwort löschen?')">✖ löschen</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

        </body>
        </html>
        <?php
    }
}

