<?php
/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

include '../config.php';
session_start();

$allowed = ['admin', 'grafik', 'co_admin'];

if (!in_array($_SESSION['etchat_'.$prefix.'user_priv'], $allowed, true)) {
    header("Location: ../");
    exit;
}

$style = $_SESSION['etchat_'.$prefix.'style'] ?? 'style_chat';
$css = "../styles/$style/style.css";

/* -----------------------------------
   ICON KONFIGURATION
----------------------------------- */
$icons = [
    ["id"=>"grussbox","title"=>"Grussbox Icon","filename"=>"Grussbox.png","path"=>"../img/Grussbox.png","default"=>"../img_default/Grussbox.png"],
    ["id"=>"userliste","title"=>"Userliste Icon","filename"=>"Userliste.png","path"=>"../img/Userliste.png","default"=>"../img_default/Userliste.png"],
    ["id"=>"checked","title"=>"Senden Icon","filename"=>"Checked.png","path"=>"../img/Checked.png","default"=>"../img_default/Checked.png"],
    ["id"=>"smiley_cool","title"=>"Smiley Icon","filename"=>"Smiley_Cool.png","path"=>"../img/Smiley_Cool.png","default"=>"../img_default/Smiley_Cool.png"],
    ["id"=>"picture","title"=>"Picture Icon","filename"=>"picture.png","path"=>"../img/picture.png","default"=>"../img_default/picture.png"],
    ["id"=>"video","title"=>"Video Icon","filename"=>"video.png","path"=>"../img/video.png","default"=>"../img_default/video.png"],
    ["id"=>"colors","title"=>"Colors Icon","filename"=>"Colors.png","path"=>"../img/Colors.png","default"=>"../img_default/Colors.png"],
    ["id"=>"display","title"=>"Einstellungen Icon","filename"=>"Display.png","path"=>"../img/Display.png","default"=>"../img_default/Display.png"],
    ["id"=>"wuerfel_gif","title"=>"Würfel GIF Icon","filename"=>"wuerfel.gif","path"=>"../img/wuerfel.gif","default"=>"../img_default/wuerfel.gif"],
    ["id"=>"redwuerfel","title"=>"Roter Würfel im Chat","filename"=>"redwuerfel.png","path"=>"../img/redwuerfel.png","default"=>"../img_default/redwuerfel.png"],
    ["id"=>"vollbild","title"=>"Vollbild Icon","filename"=>"Vollbild.png","path"=>"../img/Vollbild.png","default"=>"../img_default/Vollbild.png"],
    ["id"=>"bild","title"=>"Bild Hochladen Icon","filename"=>"Bild.png","path"=>"../img/Bild.png","default"=>"../img_default/Bild.png"],
    ["id"=>"gallery","title"=>"Gallery Icon","filename"=>"Gallery.png","path"=>"../img/Gallery.png","default"=>"../img_default/Gallery.png"],
    ["id"=>"kurz_befehl","title"=>"Befehle Icon","filename"=>"gear.png","path"=>"../img/gear.png","default"=>"../img_default/gear.png"],
    ["id"=>"delete_big","title"=>"Logout Icon","filename"=>"Delete_big.png","path"=>"../img/Delete_big.png","default"=>"../img_default/Delete_big.png"],
    ["id"=>"team","title"=>"Team Icon","filename"=>"team.png","path"=>"../img/team.png","default"=>"../img_default/team.png"],
    ["id"=>"bewerbung","title"=>"Bewerbung Icon","filename"=>"bewerbung.png","path"=>"../img/bewerbung.png","default"=>"../img_default/bewerbung.png"],
    ["id"=>"sendeplan","title"=>"Sendeplan Icon","filename"=>"sendeplan.gif","path"=>"../img/sendeplan.gif","default"=>"../img_default/sendeplan.gif"],
    ["id"=>"playlist","title"=>"Playlist Icon","filename"=>"playlist.png","path"=>"../img/playlist.png","default"=>"../img_default/playlist.png"],
    ["id"=>"admin","title"=>"Admin Icon","filename"=>"admin.png","path"=>"../img/admin.png","default"=>"../img_default/admin.png"],
    ["id"=>"djbox","title"=>"DJ Box Icon","filename"=>"djbox.png","path"=>"../img/djbox.png","default"=>"../img_default/djbox.png"],
    ["id"=>"top_list","title"=>"Top List Icon","filename"=>"top_list.png","path"=>"../img/top_list.png","default"=>"../img_default/top_list.png"],
    ["id"=>"status_online","title"=>"Status Online","filename"=>"status_online.png","path"=>"../img/status_online.png","default"=>"../img_default/status_online.png"],
    ["id"=>"status_away","title"=>"Status Away","filename"=>"status_away.png","path"=>"../img/status_away.png","default"=>"../img_default/status_away.png"],
    ["id"=>"status_busy","title"=>"Status Busy","filename"=>"status_busy.png","path"=>"../img/status_busy.png","default"=>"../img_default/status_busy.png"],
    ["id"=>"status_chatwache","title"=>"Status Chatwache","filename"=>"status_chatwache.png","path"=>"../img/status_chatwache.png","default"=>"../img_default/status_chatwache.png"],
    ["id"=>"status_chef","title"=>"Status Chef","filename"=>"status_chef.png","path"=>"../img/status_chef.png","default"=>"../img_default/status_chef.png"],
    ["id"=>"status_grafik","title"=>"Status Grafik","filename"=>"status_grafik.png","path"=>"../img/status_grafik.png","default"=>"../img_default/status_grafik.png"],
    ["id"=>"status_invisible","title"=>"Status Invisible","filename"=>"status_invisible.png","path"=>"../img/status_invisible.png","default"=>"../img_default/status_invisible.png"],
    ["id"=>"status_moderator","title"=>"Status Moderator","filename"=>"status_moderator.png","path"=>"../img/status_moderator.png","default"=>"../img_default/status_moderator.png"],
    ["id"=>"status_onair","title"=>"Status OnAir","filename"=>"status_onair.png","path"=>"../img/status_onair.png","default"=>"../img_default/status_onair.png"],
    ["id"=>"status_teamleiter","title"=>"Status Teamleiter","filename"=>"status_teamleiter.png","path"=>"../img/status_teamleiter.png","default"=>"../img_default/status_teamleiter.png"],
    ["id"=>"status_techniker","title"=>"Status Techniker","filename"=>"status_techniker.png","path"=>"../img/status_techniker.png","default"=>"../img_default/status_techniker.png"],
    ["id"=>"status_telephone","title"=>"Status Telephone","filename"=>"status_telephone.png","path"=>"../img/status_telephone.png","default"=>"../img_default/status_telephone.png"],
    ["id"=>"status_user","title"=>"Status User","filename"=>"status_user.png","path"=>"../img/status_user.png","default"=>"../img_default/status_user.png"],
    ["id"=>"homepage","title"=>"Homepage Icon","filename"=>"homepage.png","path"=>"../img/menu/homepage.png","default"=>"../img_default/homepage.png"],
    ["id"=>"ts","title"=>"TS Icon","filename"=>"teamspeak.png","path"=>"../img/menu/teamspeak.png","default"=>"../img_default/teamspeak.png"]
];

/* -----------------------------------
   HILFSFUNKTION
----------------------------------- */
function formatBytes($bytes, $precision = 2) {
    $units = ['B','KB','MB','GB'];
    $pow = $bytes > 0 ? floor(log($bytes, 1024)) : 0;
    return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
}

/* -----------------------------------
   IMAGE RESIZE FUNKTIONEN
----------------------------------- */

function resizeStaticImage($sourceFile, $defaultFile, $outputFile, $saveAsExt)
{
    // Zielgröße vom Default-File übernehmen
    $defaultSize = @getimagesize($defaultFile);
    if ($defaultSize === false) return false;
    list($targetWidth, $targetHeight) = $defaultSize;

    $info = @getimagesize($sourceFile);
    if ($info === false) return false;
    $type = $info[2];

    switch ($type) {
        case IMAGETYPE_JPEG: $src = imagecreatefromjpeg($sourceFile); break;
        case IMAGETYPE_PNG:  $src = imagecreatefrompng($sourceFile); break;
        case IMAGETYPE_GIF:  $src = imagecreatefromgif($sourceFile); break;
        default: return false;
    }

    $srcWidth  = imagesx($src);
    $srcHeight = imagesy($src);

    $dst = imagecreatetruecolor($targetWidth, $targetHeight);

    // Transparenz beibehalten
    if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefill($dst, 0, 0, $transparent);
    }

    imagecopyresampled($dst, $src, 0, 0, 0, 0, $targetWidth, $targetHeight, $srcWidth, $srcHeight);

    // Speichern im Format des Default-Files
    switch ($saveAsExt) {
        case 'jpg':
        case 'jpeg':
            imagejpeg($dst, $outputFile, 90);
            break;

        case 'png':
            imagepng($dst, $outputFile);
            break;

        case 'gif':
            imagegif($dst, $outputFile);
            break;

        default:
            imagepng($dst, $outputFile);
            break;
    }

    imagedestroy($src);
    imagedestroy($dst);

    return true;
}

function resizeImageAuto($uploadedFile, $defaultFile, $outputFile)
{
    $defaultInfo = @getimagesize($defaultFile);
    if (!$defaultInfo) return false;
    list($targetWidth, $targetHeight) = $defaultInfo;

    $uploadInfo = @getimagesize($uploadedFile);
    if (!$uploadInfo) return false;
    $mime = $uploadInfo['mime'];

    // ----------------------------------------
    // GIFs immer mit Imagick behandeln
    // ----------------------------------------
    if ($mime === 'image/gif' && class_exists('Imagick')) {

        $gif = new Imagick();
        $gif->readImage($uploadedFile);

        // Animation nicht zerstören
        $gif = $gif->coalesceImages();
        foreach ($gif as $frame) {
            $frame->thumbnailImage($targetWidth, $targetHeight);
            $frame->setImagePage(0, 0, 0, 0);
        }
        $gif = $gif->deconstructImages();
        $gif->setImageFormat('gif');

        $gif->writeImages($outputFile, true);
        $gif->clear();
        $gif->destroy();

        return true;
    }

    // ----------------------------------------
    // Statische Bilder (PNG/JPG/GIF ohne Imagick) mit GD
    // ----------------------------------------
    $ext = strtolower(pathinfo($defaultFile, PATHINFO_EXTENSION));
    return resizeStaticImage($uploadedFile, $defaultFile, $outputFile, $ext);
}



/* -----------------------------------
   ICON HANDLING
----------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];

    foreach ($icons as $icon) {
        if ($icon['id'] === $id) {

            // Zurücksetzen auf Default
            if (isset($_POST['reset'])) {
                if (file_exists($icon['default'])) copy($icon['default'], $icon['path']);
            }

            // Neues Bild hochladen
if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $tmp = $_FILES['file']['tmp_name'];
    $uploadedExt = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

    // Default-Datei des Icons
    $defaultExt = strtolower(pathinfo($icon['default'], PATHINFO_EXTENSION));

    // Prüfen, ob die Endung passt
    if ($uploadedExt !== $defaultExt) {
        exit("Ungültiges Dateiformat! Nur .$defaultExt erlaubt.");
    }

    // Verschieben und resize wie bisher
    if (!move_uploaded_file($tmp, $icon['path'])) exit("Fehler beim Hochladen!");
    resizeImageAuto($icon['path'], $icon['default'], $icon['path']);
}

        }
    }

    header("Location: img_manager.php");
    exit;
}

/* -----------------------------------
   RESET ALL
----------------------------------- */
if (isset($_POST['reset_all'])) {
    foreach ($icons as $icon) {
        if (file_exists($icon['default'])) copy($icon['default'], $icon['path']);
    }
    header("Location: img_manager.php");
    exit;
}

/* -----------------------------------
   MENÜ ICON LÖSCHEN / UPLOAD
----------------------------------- */
if (isset($_POST['delete_menu'])) {
    $file = basename($_POST['delete_menu']);
    $path = "../img/menu/".$file;
    if (file_exists($path)) unlink($path);
    header("Location: img_manager.php");
    exit;
}

if (isset($_FILES['upload_menu'])) {
    $tmp  = $_FILES['upload_menu']['tmp_name'];
    $name = basename($_FILES['upload_menu']['name']);
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $dest = "../img/menu/".$name;

    if (in_array($ext, ['png','jpg','jpeg','gif']) && is_uploaded_file($tmp)) {
        move_uploaded_file($tmp, $dest);

        // Default-Datei für menu (falls vorhanden)
        $defaultFile = "../img_default/menu/default.png";
        if (file_exists($defaultFile)) {
            resizeImageAuto($dest, $defaultFile, $dest);
        }
    }
    header("Location: img_manager.php");
    exit;
}

/* -----------------------------------
   IMAGE LÖSCHEN / UPLOAD
----------------------------------- */
if (isset($_POST['delete_image'])) {
    $file = basename($_POST['delete_image']);
    $path = "../img/images/".$file;
    if (file_exists($path)) unlink($path);
    header("Location: img_manager.php");
    exit;
}

if (isset($_FILES['upload_image'])) {
    $tmp  = $_FILES['upload_image']['tmp_name'];
    $name = basename($_FILES['upload_image']['name']);
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $dest = "../img/images/".$name;

    if (in_array($ext, ['png','jpg','jpeg','gif']) && is_uploaded_file($tmp)) {
        move_uploaded_file($tmp, $dest);

        // Default-Datei für images (falls vorhanden)
        $defaultFile = "../img_default/images/default.png";
        if (file_exists($defaultFile)) {
            resizeImageAuto($dest, $defaultFile, $dest);
        }
    }
    header("Location: img_manager.php");
    exit;
}

/* -----------------------------------
   HINTERGRUND LÖSCHEN
----------------------------------- */
if (isset($_POST['delete_bg'])) {
    $file = basename($_POST['delete_bg']);
    $path = "../styles/" . $style . "/hintergrund/" . $file;

    if (file_exists($path)) unlink($path);

    header("Location: img_manager.php");
    exit;
}

/* -----------------------------------
   HINTERGRUND UPLOAD
----------------------------------- */
if (isset($_FILES['upload_bg'])) {

    $dir = "../styles/" . $style . "/hintergrund/";

    if (is_dir($dir)) {

        $tmp  = $_FILES['upload_bg']['tmp_name'];
        $name = basename($_FILES['upload_bg']['name']);
        $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $dest = $dir . $name;

        if (in_array($ext, ['png','jpg','jpeg','gif']) && is_uploaded_file($tmp)) {
            move_uploaded_file($tmp, $dest);
        }
    }

    header("Location: img_manager.php");
    exit;
}


?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Icon Verwaltung</title>
<link href="<?= htmlspecialchars($css) ?>" rel="stylesheet">
<style>
.grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(260px,1fr)); gap:20px; }
.box { border:2px solid #333; padding:5px; border-radius:12px; background:#111; text-align:center; }
.btn { padding:8px 14px; border:none; cursor:pointer; border-radius:8px; }
.upload { background:#007bff; color:white; }
.reset { background:#ffc107; }
.bigreset { background:#c0392b; color:white; width:100%; }
img.preview { max-width:80px; height:auto; margin-bottom:10px; }
hr.sep { border:0; border-top:2px solid #444; margin:28px 0; }
h3 { margin-top:5px; margin-bottom: 5px;}
p { margin:5px; }
</style>

<script>
function checkFileType(input, defaultFilePath, msgId) {
    const msg = document.getElementById(msgId);
    msg.textContent = ''; // Alte Meldung löschen

    if (!input.files || !input.files[0]) return;

    const file = input.files[0];
    const uploadedExt = file.name.split('.').pop().toLowerCase();
    const defaultExt = defaultFilePath.split('.').pop().toLowerCase();

    if (uploadedExt !== defaultExt) {
        msg.textContent = `Ungültiges Dateiformat! Nur .${defaultExt} erlaubt.`;
        input.value = ''; // Datei zurücksetzen
    }
}
</script>


</head>
<body id="adminbereich_body">

<?php
switch ($_SESSION['etchat_'.$prefix.'user_priv']) {
    case 'grafik':
        $ziel = '../?AdminIndexGrafik';
        break;

    case 'co_admin':
        $ziel = '../?AdminIndexCoAdmin';
        break;

    case 'admin':
    default:
        $ziel = '../?AdminIndex';
}
?>

<div>
    <a href="<?= $ziel ?>">&laquo;&laquo;&laquo; Zurück zum Adminbereich</a>
</div>

<hr size="1">

<center><b>Icon Verwaltung</b></center><br><br>
<form method="post"><button class="bigreset" name="reset_all"><h3>Alle Icons zurücksetzen</h3></button></form>

<!-- SYSTEM ICONS -->
<hr>
<h2>System Icons</h2>
<div class="grid">
<?php foreach ($icons as $icon): ?>
    <?php if (strpos($icon['id'], 'status_') === 0) continue; ?>
    <?php
        $status = file_exists($icon['path']) ? "Vorhanden" : "Fehlt";
        $size = file_exists($icon['path']) ? formatBytes(filesize($icon['path'])) : "-";
        $changed = file_exists($icon['path']) ? date("d.m.Y H:i", filemtime($icon['path'])) : "-";
    ?>
    <div class="box">
        <h3><?= htmlspecialchars($icon['title']) ?></h3>
        <img class="preview" src="<?= $icon['path'] ?>?v=<?= time() ?>" alt="Icon">
        <p>Status: <b><?= $status ?></b></p>
        <p>Größe: <?= $size ?></p>
        <p>Geändert: <?= $changed ?></p>
        <p>Standard: <?= file_exists($icon['default']) ? "Vorhanden" : "Fehlt" ?></p>

        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $icon['id'] ?>">
<input type="file" name="file" accept="image/*"
       onchange="checkFileType(this, '<?= $icon['default'] ?>', 'msg_<?= $icon['id'] ?>')"><br>
<span id="msg_<?= $icon['id'] ?>" style="color:red; font-weight:bold;"></span><br>
<button class="btn upload" name="upload">Hochladen</button>

            <button class="btn reset" name="reset">Zurücksetzen</button>
        </form>
    </div>
<?php endforeach; ?>
</div>

<!-- STATUS ICONS -->
<hr>
<h2>Status Icons</h2>
<div class="grid">
<?php foreach ($icons as $icon): ?>
    <?php if (strpos($icon['id'], 'status_') !== 0) continue; ?>
    <?php
        $status = file_exists($icon['path']) ? "Vorhanden" : "Fehlt";
        $size = file_exists($icon['path']) ? formatBytes(filesize($icon['path'])) : "-";
        $changed = file_exists($icon['path']) ? date("d.m.Y H:i", filemtime($icon['path'])) : "-";
    ?>
    <div class="box">
        <h3><?= htmlspecialchars($icon['title']) ?></h3>
        <img class="preview" src="<?= $icon['path'] ?>?v=<?= time() ?>" alt="Icon">
        <p>Status: <b><?= $status ?></b></p>
        <p>Größe: <?= $size ?></p>
        <p>Geändert: <?= $changed ?></p>
        <p>Standard: <?= file_exists($icon['default']) ? "Vorhanden" : "Fehlt" ?></p>

        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $icon['id'] ?>">
 <input type="file" name="file" accept="image/*"
       onchange="checkFileType(this, '<?= $icon['default'] ?>', 'msg_<?= $icon['id'] ?>')"><br>
<span id="msg_<?= $icon['id'] ?>" style="color:red; font-weight:bold;"></span><br>

            <button class="btn upload" name="upload">Hochladen</button>
            <button class="btn reset" name="reset">Zurücksetzen</button>
        </form>
    </div>
<?php endforeach; ?>
</div>

<!-- MENÜ ICONS -->
<hr>
<h2>Menü Icons</h2>
<p>Ordner: <code>/img/menu/</code></p>
<div class="grid">
<?php
$menuDir = "../img/menu/";
if (is_dir($menuDir)) {
    $menuFiles = array_diff(scandir($menuDir), ['.','..']);
    foreach ($menuFiles as $file) {
        if (!preg_match('/\.(png|jpe?g|gif)$/i', $file)) continue;
        $full = $menuDir.$file;
?>
    <div class="box">
        <h3><?= htmlspecialchars($file) ?></h3>
        <img class="preview" src="<?= $full ?>?v=<?= time() ?>" alt="">
        <p>Größe: <?= formatBytes(filesize($full)) ?></p>
        <p>Geändert: <?= date("d.m.Y H:i", filemtime($full)) ?></p>

        <form method="post">
            <input type="hidden" name="delete_menu" value="<?= htmlspecialchars($file) ?>">
            <button class="btn reset" onclick="return confirm('Wirklich löschen?')">Löschen</button>
        </form>
    </div>
<?php
    }
}
?>
</div>

<form method="post" enctype="multipart/form-data" style="margin-top:12px;">
    <input type="file" name="upload_menu" accept="image/*" required>
    <button class="btn upload">Hochladen</button>
</form>

<!-- IMAGES -->
<hr>
<h2>Images</h2>
<p>Ordner: <code>/img/images/</code></p>
<div class="grid">
<?php
$imgDir = "../img/images/";
if (is_dir($imgDir)) {
    $imgFiles = array_diff(scandir($imgDir), ['.','..']);
    foreach ($imgFiles as $file) {
        if (!preg_match('/\.(png|jpe?g|gif)$/i', $file)) continue;
        $full = $imgDir.$file;
?>
    <div class="box">
        <h3><?= htmlspecialchars($file) ?></h3>
        <img class="preview" src="<?= $full ?>?v=<?= time() ?>" alt="">
        <p>Größe: <?= formatBytes(filesize($full)) ?></p>
        <p>Geändert: <?= date("d.m.Y H:i", filemtime($full)) ?></p>

        <form method="post">
            <input type="hidden" name="delete_image" value="<?= htmlspecialchars($file) ?>">
            <button class="btn reset" onclick="return confirm('Wirklich löschen?')">Löschen</button>
        </form>
    </div>
<?php
    }
}
?>
</div>

<form method="post" enctype="multipart/form-data" style="margin-top:12px;">
    <input type="file" name="upload_image" accept="image/*" required>
    <button class="btn upload">Hochladen</button>
</form>

<!-- HINTERGRUND -->
<hr>
<h2>Hintergründe</h2>
<?php
// Dynamischer Style-Pfad
$styleFolder = "../styles/" . $style . "/hintergrund/";

if (is_dir($styleFolder)) {
    echo "<p>Ordner: <code>$styleFolder</code></p>";
    echo '<div class="grid">';

    $bgFiles = array_diff(scandir($styleFolder), ['.','..']);

    foreach ($bgFiles as $file) {
        if (!preg_match('/\.(png|jpe?g|gif)$/i', $file)) continue;

        $full = $styleFolder . $file;
?>
    <div class="box">
        <h3><?= htmlspecialchars($file) ?></h3>
        <img class="preview" src="<?= $full ?>?v=<?= time() ?>" alt="">
        <p>Größe: <?= formatBytes(filesize($full)) ?></p>
        <p>Geändert: <?= date("d.m.Y H:i", filemtime($full)) ?></p>

        <form method="post">
            <input type="hidden" name="delete_bg" value="<?= htmlspecialchars($file) ?>">
            <button class="btn reset" onclick="return confirm('Wirklich löschen?')">Löschen</button>
        </form>
    </div>
<?php
    }

    echo "</div>";
} else {
    echo "<p>Der Hintergrund-Ordner existiert nicht: <code>$styleFolder</code></p>";
}

if (is_dir($styleFolder) && is_writable($styleFolder)) {
?>
    <form method="post" enctype="multipart/form-data" style="margin-top:12px;">
        <input type="file" name="upload_bg" accept="image/*" required>
        <button class="btn upload">Hochladen</button>
    </form>
<?php
} else {
    echo '<div style="margin-top:12px;color:#c00;font-weight:bold;">
            Der Hintergrund-Ordner existiert bei diesem Style nicht oder ist nicht beschreibbar.
          </div>';
}
?>

</body>
</html>
