CREATE TABLE IF NOT EXISTS etchat_test123 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    txt VARCHAR(255)
);

INSERT INTO etchat_test123 (txt) VALUES ('Test erfolgreich');

