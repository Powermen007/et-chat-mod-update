<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, JSON Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

$style = htmlspecialchars(
    $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'default',
    ENT_QUOTES,
    'UTF-8'
);

$csrf_token = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

if (!function_exists('e')) {
    function e(string $value): string {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }
}

// ============================================================
// HILFSFUNKTION: Wandelt Ordnernamen in Sprachcode um
// ============================================================
if (!function_exists('getLangCodeFromFolder')) {
    function getLangCodeFromFolder(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
            'Französisch' => 'fr',
            'Spanisch' => 'es',
            'Italienisch' => 'it',
            'Niederländisch' => 'nl',
            'Russisch' => 'ru',
            'Türkisch' => 'tr',
            'Arabisch' => 'ar',
            'Chinesisch' => 'zh',
            'Japanisch' => 'ja',
        ];
        return $map[$folder] ?? 'de';
    }
}

// ============================================================
// SPRACHE AUS JSON LADEN
// ============================================================
$langFolder = $_SESSION['etchat_' . $this->_prefix . 'lang_json_file'] ?? 'Deutsch';

// Sprachcode aus Ordnername ableiten (Deutsch -> de, Englisch -> en)
$langCode = getLangCodeFromFolder($langFolder);

$basePath = dirname(__DIR__, 2);
$langPath = $basePath . '/lang/' . $langFolder . '/lang_admin_' . $langCode . '_v2.json';

$backToMenu = '&lt;&lt;&lt; zurück zum Adminmenü';
$backText = '&lt;&lt;&lt; zurück';

if (file_exists($langPath)) {
    $jsonContent = file_get_contents($langPath);
    if ($jsonContent !== false) {
        $data = json_decode($jsonContent, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($data)) {
            $strings = $data['strings'] ?? [];
            
            if (isset($strings['admin_master_back_to_menu'])) {
                $backToMenu = $strings['admin_master_back_to_menu'];
            }
            if (isset($strings['admin_master_back'])) {
                $backText = $strings['admin_master_back'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title><?= e($pageTitle ?? 'Admin Bereich') ?></title>

    <link rel="stylesheet" href="styles/admin_tpl/admin.css">

    <?php if (!empty($extraHead)): ?>
        <?= $extraHead ?>
    <?php endif; ?>
</head>

<body id="adminbereich_body">

<?php if (empty($hideNav)): ?>
<nav>
    <a href="./?AdminIndex"><?= $backToMenu ?></a>
</nav>
<hr>
<?php endif; ?>

<main>

    <?php if (!empty($pageTitle)): ?>
        <h2><?= e($pageTitle) ?></h2>
    <?php endif; ?>

    <!-- ===== CONTENT SLOT ===== -->
    <?= $content ?? '' ?>

</main>

<hr>

<?php if (!empty($backLink)): ?>
    <a href="<?= e($backLink) ?>"><?= $backText ?></a><br>
<?php endif; ?>

<?php if (!empty($footerNote)): ?>
    <small><?= $footerNote ?></small>
<?php endif; ?>
 
<?php if (!empty($backLink) || !empty($footerNote)): ?>
 <hr>
<?php endif; ?>

<?php if (!empty($extraScripts)) echo $extraScripts; ?>
</body>
</html>