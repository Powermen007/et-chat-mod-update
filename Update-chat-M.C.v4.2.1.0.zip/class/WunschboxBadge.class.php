<?php
declare(strict_types=1);

/**
 * WunschboxBadge – API für den roten Punkt an der DJ-Box
 * 
 * Aufruf: ./?WunschboxBadge&last_checked=<timestamp>
 * 
 * Antwort: JSON {
 *   count: int,
 *   latest: string|null,
 *   interval: int (Millisekunden für nächsten Check),
 *   error?: string
 * }
 */

class WunschboxBadge extends DbConectionMaker
{
    private Wunschbox $wunschbox;
    private object $lang;
    private string $userRole = '';
    private int $userId = 0;
    private array $config = [];
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        
        $this->lang = new LangJson();
        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
        $this->userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        
        // Config laden
        $this->loadConfig();
        
        // Nur Moderatoren/Admins dürfen den Badge sehen
        $allowedRoles = ['admin', 'mod', 'co_admin'];
        if (!in_array($this->userRole, $allowedRoles, true)) {
            echo json_encode([
                'count'    => 0,
                'latest'   => null,
                'interval' => $this->getIntervalMs(),
                'error'    => 'no_permission'
            ]);
            exit;
        }
        
        // Wunschbox-Instanz erstellen
        $this->wunschbox = new Wunschbox();
        
        $this->handleRequest();
    }
    
    /**
     * Config aus DB laden
     */
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_wunschbox_config"
        );
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
    private function getConfig(string $key, string $default = ''): string
    {
        return $this->config[$key] ?? $default;
    }
    
    /**
     * 🔥 NEU: Intervall aus Config in Millisekunden (mit Grenzen)
     */
    private function getIntervalMs(): int
    {
        $seconds = (int)$this->getConfig('admin_refresh_seconds', '30');
        // Grenzen: min. 5 Sek., max. 300 Sek.
        $seconds = max(5, min(300, $seconds));
        return $seconds * 1000;
    }
    
    /**
     * Hauptlogik: Zählt offene Wünsche je nach Mod-Rechten
     */
private function handleRequest(): void
{
    $lastChecked = isset($_GET['last_checked']) ? (int)$_GET['last_checked'] : 0;
    
    // 🔥 NEU: IMMER nur die AKTUELLE Sendung zählen
    // (egal ob Admin, Co-Admin oder Mod – der Badge zeigt nur aktuelle Wünsche)
    $sendungsId = $this->getCurrentSendungId();
    
    if ($sendungsId === null) {
        // Keine aktuelle Sendung → Badge auf 0
        echo json_encode([
            'count'    => 0,
            'latest'   => null,
            'interval' => $this->getIntervalMs()
        ]);
        return;
    }
    
    $result = $this->wunschbox->hasNewOpenWishes($lastChecked, $sendungsId);
    
    echo json_encode([
        'count'    => $result['count'],
        'latest'   => $result['latest'],
        'interval' => $this->getIntervalMs()
    ]);
}
    
    /**
     * Aktuelle Sendung des Moderators (heute, jetzt)
     */
    private function getModeratorSendungId(): ?int
    {
        $now = new DateTime();
        $currentDate = $now->format('Y-m-d');
        $currentTime = $now->format('H:i:s');
        
        // Erst: Aktuelle Sendung (auch tagübergreifend)
        $result = $this->dbObj->sqlGet(
            "SELECT id 
             FROM {$this->_prefix}etchat_sendeplan 
             WHERE moderator_id = :user_id 
             AND datum = :date 
             AND zeit_von <= :time 
             AND zeit_bis >= :time
             LIMIT 1",
            [
                ':user_id' => $this->userId,
                ':date'    => $currentDate,
                ':time'    => $currentTime
            ]
        );
        
        if (!empty($result)) {
            return (int)$result[0]['id'];
        }
        
        // Fallback: Nächste Sendung des Mods
        $result = $this->dbObj->sqlGet(
            "SELECT id 
             FROM {$this->_prefix}etchat_sendeplan 
             WHERE moderator_id = :user_id 
             AND datum >= :date 
             ORDER BY datum ASC, zeit_von ASC
             LIMIT 1",
            [
                ':user_id' => $this->userId,
                ':date'    => $currentDate
            ]
        );
        
        return !empty($result) ? (int)$result[0]['id'] : null;
    }
	
/**
 * 🔥 NEU: Aktuell laufende Sendung (unabhängig vom Moderator)
 * Berücksichtigt tagübergreifende Sendungen (z.B. 22:00-02:00)
 */
private function getCurrentSendungId(): ?int
{
    $now = new DateTime();
    $currentDate = $now->format('Y-m-d');
    $currentTime = $now->format('H:i:s');
    
    // Gestern prüfen (für tagübergreifende Sendungen)
    $yesterday = new DateTime();
    $yesterday->modify('-1 day');
    $yesterdayDate = $yesterday->format('Y-m-d');
    
    // Alle Sendungen von heute UND gestern holen
    $entries = $this->dbObj->sqlGet(
        "SELECT id, datum, zeit_von, zeit_bis 
         FROM {$this->_prefix}etchat_sendeplan 
         WHERE datum IN (:yesterday, :today)
         ORDER BY datum DESC, zeit_von DESC",
        [
            ':yesterday' => $yesterdayDate,
            ':today'     => $currentDate
        ]
    );
    
    if (empty($entries)) {
        return null;
    }
    
    $activeEntries = [];
    
    foreach ($entries as $entry) {
        $zeitVon = $entry['zeit_von'];
        $zeitBis = $entry['zeit_bis'];
        $datum   = $entry['datum'];
        
        $isOvernight = $zeitBis < $zeitVon;
        $isActive = false;
        
        if ($isOvernight) {
            // Tagübergreifend
            if ($datum === $yesterdayDate) {
                // Gestern gestartet → prüfen ob jetzt noch läuft
                if ($currentTime >= $zeitVon || $currentTime <= $zeitBis) {
                    $isActive = true;
                }
            } else {
                // Heute gestartet
                if ($currentTime >= $zeitVon) {
                    $isActive = true;
                }
            }
        } else {
            // Normale Sendung
            if ($datum === $currentDate && $zeitVon <= $currentTime && $zeitBis >= $currentTime) {
                $isActive = true;
            }
        }
        
        if ($isActive) {
            $activeEntries[] = $entry;
        }
    }
    
    if (empty($activeEntries)) {
        return null;
    }
    
    // Neueste aktive Sendung nehmen
    usort($activeEntries, function($a, $b) {
        $dateCmp = strcmp($b['datum'], $a['datum']);
        if ($dateCmp !== 0) return $dateCmp;
        return strcmp($b['zeit_von'], $a['zeit_von']);
    });
    
    return (int)$activeEntries[0]['id'];
}
    
    /**
     * Alle Sendungs-IDs des Moderators (für "alle eigenen Sendungen")
     */
    private function getModeratorAllSendungIds(): array
    {
        $result = $this->dbObj->sqlGet(
            "SELECT DISTINCT id 
             FROM {$this->_prefix}etchat_sendeplan 
             WHERE moderator_id = :user_id 
             ORDER BY datum DESC, zeit_von DESC",
            [':user_id' => $this->userId]
        );
        
        $ids = [];
        foreach ($result as $row) {
            $ids[] = (int)$row['id'];
        }
        return $ids;
    }
}