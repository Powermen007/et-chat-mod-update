<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Insert2Blacklist extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangJson();

        $privilege = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        $allowedRoles = ["admin", "mod", "grafik", "chatwache", "co_admin"];

        if (!in_array($privilege, $allowedRoles, true)) {
            echo $this->getText('admin_session_lost', 'Keine Berechtigung oder Session ist abgelaufen.');
            $this->dbObj->close();
            return;
        }

        $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT) ?: 0;
        $time   = filter_input(INPUT_POST, 'time', FILTER_VALIDATE_INT) ?: 0;

        if ($userId <= 0) {
            echo $this->getText('admin_invalid_user_id', 'Ungültige User-ID.');
            $this->dbObj->close();
            return;
        }

        $userId = (int)$userId;
        $time   = (int)$time;

        // Prüfen ob der Benutzer online ist
        $onlineCheck = $this->dbObj->sqlGet(
            "SELECT etchat_onlineuser_fid 
             FROM {$this->_prefix}etchat_useronline 
             WHERE etchat_onlineuser_fid = :uid
             LIMIT 1",
            [':uid' => $userId]
        );

        if (empty($onlineCheck) || !is_array($onlineCheck)) {
            echo $this->getText('admin_user_away', 'User ist bereits abgemeldet.');
            $this->dbObj->close();
            return;
        }

        if ($time > 0) {
            // Blacklist über Klasse
            $blObj = new Blacklist($this->dbObj);
            $blObj->insertUser($userId, $time);
        } else {
            // Kick-Eintrag mit Prepared Statement
            $expireTime = time() + 30;

            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_kick_user 
                (etchat_kicked_user_id, etchat_kicked_user_time) 
                VALUES (:uid, :etime)",
                [
                    ':uid'   => $userId,
                    ':etime' => $expireTime
                ]
            );
        }

        $this->dbObj->close();
    }
}