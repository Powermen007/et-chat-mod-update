<?php

declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class LangJson extends EtChatConfig
{
    public $lastError = '';
    
    private $jsonData = null;

public function __construct($path = "./lang/", $jsonfile = "")
{
    parent::__construct();

    // 🔥 Wenn kein Pfad übergeben wurde, Default nutzen
    if (empty($path)) {
        $path = "./lang/";
    }

    $sessionFile = $_SESSION['etchat_' . $this->_prefix . 'lang_json_file'] ?? 'Deutsch';
    $langFolder = $sessionFile ?: 'Deutsch';
    $langCode = $this->getLangCodeFromFolder($langFolder);

    // 🔥 NEU: Wenn Dateiname explizit übergeben → diesen nutzen
    if (!empty($jsonfile)) {
        $fullpath = rtrim($path, "/") . "/" . $langFolder . "/" . $jsonfile;
    } else {
        // alte Logik
        $isAdminRequest = false;
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5);
        foreach ($backtrace as $call) {
            $class = $call['class'] ?? '';
            if (str_starts_with($class, 'Admin')) {
                $isAdminRequest = true;
                break;
            }
        }

        if ($isAdminRequest) {
            $jsonfile = "lang_admin_" . $langCode . "_v2.json";
        } else {
            $jsonfile = "lang_" . $langCode . "_v2.json";
        }

        $fullpath = rtrim($path, "/") . "/" . $langFolder . "/" . $jsonfile;
    }

		// ============================================================
		// Lade die JSON
		// ============================================================
		if (!file_exists($fullpath)) {
			// Fallback: Versuche im Hauptverzeichnis
			$fallbackPath = rtrim($path, "/") . "/" . basename($fullpath);
			if (file_exists($fallbackPath)) {
				$fullpath = $fallbackPath;
			} else {
				$this->lastError = "Language file not found: " . $fullpath;
				$this->jsonData = new stdClass();
				return;
			}
		}

		$content = file_get_contents($fullpath);
        
        if ($content === false) {
            $this->lastError = "Failed to read JSON: " . $fullpath;
            $this->jsonData = new stdClass();
            return;
        }

        $data = json_decode($content, true);
        
        if ($data === null) {
            $this->lastError = "Failed to parse JSON: " . json_last_error_msg() . " - File: " . $fullpath;
            $this->jsonData = new stdClass();
            return;
        }

        // ============================================================
        // Parse die JSON (nur moderne Struktur)
        // ============================================================
        $this->jsonData = $this->parseModernJson($data);
    }

    /**
     * Wandelt Ordnernamen in Sprachcode um (Deutsch -> de, Englisch -> en)
     */
    private function getLangCodeFromFolder(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
            'Französisch' => 'fr',
            'Spanisch' => 'es',
            'Italienisch' => 'it',
            'Niederländisch' => 'nl',
            'Russisch' => 'ru',
            'Türkisch' => 'tr',
            'Arabisch' => 'ar',
            'Chinesisch' => 'zh',
            '日本语' => 'ja',
        ];
        
        return $map[$folder] ?? 'de';
    }

    /**
     * Parst die JSON in eine moderne Objekt-Struktur
     */
    private function parseModernJson(array $data): stdClass
    {
        $result = new stdClass();
        
        // Strings
        if (isset($data['strings'])) {
            foreach ($data['strings'] as $key => $value) {
                $result->$key = $value;
            }
        }
        
        // Structs (für Status-Definitionen etc.)
        if (isset($data['structs'])) {
            foreach ($data['structs'] as $key => $struct) {
                $obj = new stdClass();
                $obj->value = $struct['value'] ?? '';
                $obj->attributes = $struct['attributes'] ?? [];
                $result->$key = $obj;
            }
        }
        
        return $result;
    }

    /**
     * Hauptmethode für den Sprachzugriff
     */
    public function get(string $key, $default = '')
    {
        if ($this->jsonData !== null && isset($this->jsonData->$key)) {
            $value = $this->jsonData->$key;
            // Bei Structs den value zurückgeben
            if (is_object($value) && isset($value->value)) {
                return $value->value;
            }
            return $value;
        }
        return $default;
    }

    /**
     * Holt ein Array (für Array-Typen in der JSON)
     */
    public function getArray(string $key): array
    {
        $value = $this->get($key);
        return is_array($value) ? $value : [];
    }

    /**
     * Holt ein Struct-Objekt (für Status-Definitionen)
     */
    public function getStruct(string $key)
    {
        if ($this->jsonData !== null && isset($this->jsonData->$key)) {
            $value = $this->jsonData->$key;
            if (is_object($value) && isset($value->value)) {
                return $value;
            }
        }
        return null;
    }

    /**
     * Holt alle Structs (für ChangeStatus::checkRightsOfStatus)
     */
    public function getAllStructs(): array
    {
        if ($this->jsonData === null) {
            return [];
        }
        
        $structs = [];
        foreach (get_object_vars($this->jsonData) as $key => $value) {
            if (is_object($value) && isset($value->value)) {
                $structs[$key] = $value;
            }
        }
        return $structs;
    }

    /**
     * Gibt den letzten Fehler zurück
     */
    public function getLastError(): string
    {
        return $this->lastError;
    }
}