<?php
/*
Sendeplan – Verwaltung der Sendungen im ET-Chat
*/

class Sendeplan extends DbConectionMaker
{
    private $user_id;
    private $user_priv;
    private $lang;
    private array $config = [];
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $this->user_id = (int)($_SESSION['etchat_'.$this->_prefix.'user_id'] ?? 0);
        $this->user_priv = $_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? 'gast';
        $lang = new LangJson('', 'wb_sendeplan.json');
        $this->loadConfig();
    }
    
    /**
     * 🔥 NEU: Lädt die Sendeplan-Konfiguration
     */
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_sendeplan_config"
        );
        
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
    /**
     * 🔥 NEU: Prüft ob ein Moderator eine Sendung anlegen darf
     */
    public function canCreateEntry(): bool
    {
        // Admin und Co-Admin dürfen immer
        if (in_array($this->user_priv, ['admin', 'co_admin'])) {
            return true;
        }
        
        // Mod: Prüfe Konfiguration
        if ($this->user_priv === 'mod') {
            $setting = $this->config['mod_can_create'] ?? 'own';
            return $setting !== 'none';
        }
        
        return false;
    }
    
    /**
     * 🔥 NEU: Prüft ob ein Moderator eine bestimmte Sendung bearbeiten darf
     */
public function canEditEntry(int $entryId, int $moderatorId): bool
{
    // Admin und Co-Admin dürfen immer
    if (in_array($this->user_priv, ['admin', 'co_admin'])) {
        return true;
    }
    
    // Mod: Prüfe Konfiguration
    if ($this->user_priv === 'mod') {
        $setting = $this->config['mod_can_edit'] ?? 'own';
        
        if ($setting === 'none') return false;
        if ($setting === 'all') return true;
        if ($setting === 'own') {
            $entry = $this->getEntry($entryId);
            if (!$entry) return false;
            
            // 🔥 NEU: Wenn KEIN Moderator zugewiesen ist, darf man sie bearbeiten!
            if (empty($entry['moderator_id'])) {
                return true;
            }
            
            // 🔥 NEU: Prüfe, ob ich der ZUGEWIESENE Moderator bin
            return ($entry['moderator_id'] ?? 0) == $this->user_id;
        }
    }
    
    return false;
}
    
    /**
     * 🔥 NEU: Prüft ob ein Moderator eine Sendung löschen darf
     */
public function canDeleteEntry(int $entryId, int $moderatorId): bool
{
    // Admin und Co-Admin dürfen immer
    if (in_array($this->user_priv, ['admin', 'co_admin'])) {
        return true;
    }
    
    // Mod: Prüfe Konfiguration
    if ($this->user_priv === 'mod') {
        $setting = $this->config['mod_can_delete'] ?? 'own';
        
        if ($setting === 'none') return false;
        if ($setting === 'all') return true;
        if ($setting === 'own') {
            $entry = $this->getEntry($entryId);
            // 🔥 NEU: Prüfe, ob ich der ZUGEWIESENE Moderator bin, nicht der Ersteller!
            return $entry && ($entry['moderator_id'] ?? 0) == $this->user_id;
        }
    }
    
    return false;
}
  
/**
 * 🔥 NEU: Automatische Bereinigung ohne Cron-Job (max. 2x am Tag)
 */
public function maybeAutoCleanup(): void
{
    // 1. Ist Auto-Delete überhaupt aktiv?
    $autoDelete = ($this->config['auto_delete_enabled'] ?? '1') == '1';
    if (!$autoDelete) {
        return;
    }
    
    // 2. Cache-Datei Pfad erstellen
    $cacheFile = __DIR__ . '/../cache/sendeplan_cleanup.txt';
    
    // 3. Wenn Datei existiert, prüfen ob sie jünger als 12 Stunden ist
    if (file_exists($cacheFile)) {
        $lastRun = filemtime($cacheFile);
        // Wenn weniger als 12 Stunden (43200 Sekunden) vergangen sind -> zurück
        if ((time() - $lastRun) < 43200) {
            return;
        }
    }
    
    // 4. Bereinigung ausführen
    $deletedCount = $this->cleanupExpiredEntries();
    
    // 5. Cache-Datei schreiben
    if (!is_dir(__DIR__ . '/../cache')) {
        mkdir(__DIR__ . '/../cache', 0755, true);
    }
    file_put_contents($cacheFile, date('Y-m-d H:i:s') . " - Gelöscht: $deletedCount Einträge");
}

    /**
     * 🔥 NEU: Löscht automatisch abgelaufene Sendungen (wird via Cron aufgerufen)
     */
public function cleanupExpiredEntries(): int
{
    $autoDelete = ($this->config['auto_delete_enabled'] ?? '1') == '1';
    if (!$autoDelete) {
        return 0;
    }
    
    $days = (int)($this->config['delete_after_days'] ?? 30);
    $deleteDate = date('Y-m-d', strtotime("-$days days"));
    
    // Alte Sendungen holen
    $sql = "SELECT id FROM {$this->_prefix}etchat_sendeplan 
            WHERE datum < :date";
    $entries = $this->dbObj->sqlGet($sql, [':date' => $deleteDate]);
    
    if (empty($entries) || !is_array($entries)) {
        return 0;
    }
    
    $count = 0;
    foreach ($entries as $entry) {
        $this->deleteEntry((int)$entry['id']);
        $count++;
    }
    
    return (int)$count;
}
    
    private function getText(string $key, string $default = ''): string
    {
        return $this->lang ? $this->lang->get($key, $default) : $default;
    }
    
    public function isAuthorized(): bool
    {
        return in_array($this->user_priv, ['admin', 'mod', 'co_admin']);
    }
	
	/**
	* 🔥 NEU: Prüft, ob für eine Sendung gerade Wünsche abgegeben werden dürfen
	* 
	* @param array $entry  Sendungs-Datensatz (aus getEntries/getEntry)
	* @return array        ['allowed' => bool, 'mode' => 'live'|'vorab'|'closed', 'reason' => string]
	*/
	public function canSendWish(array $entry): array
	{
		// 1. Ist die Wunschbox für diese Sendung überhaupt aktiv?
		$wbMode = (int)($entry['wunschbox_aktiv'] ?? 0);
    
		if ($wbMode === 0) {
			return [
				'allowed' => false,
				'mode'    => 'closed',
				'reason'  => 'wb_off',
			];
		}
    
		// 2. Aktuelle Zeit
		$now = time();
		$today = date('Y-m-d');
		$currentTime = date('H:i:s');
    
		// 3. Sendungs-Zeitstempel berechnen
		$entryDate = $entry['datum'] ?? '';
		$zeitVon   = $entry['zeit_von'] ?? '00:00:00';
		$zeitBis   = $entry['zeit_bis'] ?? '00:00:00';
    
		if (strlen($zeitVon) === 5) $zeitVon .= ':00';
		if (strlen($zeitBis) === 5) $zeitBis .= ':00';
    
		$isOvernight = $zeitBis < $zeitVon;
    
		$startTs = strtotime($entryDate . ' ' . $zeitVon);
    
		if ($isOvernight) {
			$endTs = strtotime($entryDate . ' ' . $zeitBis . ' +1 day');
		} else {
			$endTs = strtotime($entryDate . ' ' . $zeitBis);
		}
    
		// 4. Läuft die Sendung gerade? → Immer erlaubt (wenn Modus 1 oder 2)
		if ($now >= $startTs && $now <= $endTs) {
			return [
				'allowed' => true,
				'mode'    => 'live',
				'reason'  => 'wb_live',
			];
		}
    
		// 5. Ist die Sendung vorbei? → Nicht erlaubt
		if ($now > $endTs) {
			return [
				'allowed' => false,
				'mode'    => 'closed',
				'reason'  => 'wb_past',
			];
		}
    
		// 6. Sendung liegt in der Zukunft
		// → Nur erlaubt, wenn Modus 2 UND Vorab-Feature aktiv
		if ($wbMode === 2) {
			$vorabEnabled = ($this->config['wunschbox_vorab_enabled'] ?? '0') == '1';
        
			if (!$vorabEnabled) {
				return [
					'allowed' => false,
					'mode'    => 'closed',
					'reason'  => 'vorab_disabled',
				];
			}
        
			$maxDays = (int)($this->config['wunschbox_vorab_max_days'] ?? 30);
			if ($maxDays < 1) $maxDays = 30;
        
			$maxTs = $startTs - ($maxDays * 86400);
        
			if ($now >= $maxTs) {
				// Innerhalb des Vorab-Fensters
				return [
					'allowed' => true,
					'mode'    => 'vorab',
					'reason'  => 'wb_vorab',
				];
			} else {
				// Zu früh
				return [
					'allowed' => false,
					'mode'    => 'closed',
					'reason'  => 'vorab_too_early',
					'maxDays' => $maxDays,
				];
			}
		}
    
		// 7. Sendung in der Zukunft + Modus 1 → Nicht erlaubt
		return [
			'allowed' => false,
			'mode'    => 'closed',
			'reason'  => 'wb_future',
		];
	}
	
	/**
	* 🔥 NEU: Config-Wert auslesen (öffentlich)
	*/
	public function getConfig(string $key, $default = null)
	{
		return $this->config[$key] ?? $default;
	}
    
	/**
	* Holt alle Moderatoren (admin, mod, co_admin) + Auto-DJ
	* Sortierung: Auto-DJ zuerst, dann admin, co_admin, mod
	*/
	public function getModerators(): array
	{
		$sql = "SELECT etchat_user_id, etchat_username, etchat_avatar, etchat_userprivilegien
				FROM {$this->_prefix}etchat_user
				WHERE etchat_userprivilegien IN ('admin', 'mod', 'co_admin', 'autodj')
				ORDER BY 
					CASE etchat_userprivilegien 
						WHEN 'autodj'   THEN 1
						WHEN 'admin'    THEN 2
						WHEN 'co_admin' THEN 3
						WHEN 'mod'      THEN 4
						ELSE 5
					END ASC,
					etchat_username ASC";
    
		return $this->dbObj->sqlGet($sql, []) ?: [];
	}
	
	 /**
     * 🔥 NEU: Holt alle Vorlagen für das Sendeplan-Formular
     */
    public function getVorlagen(): array
    {
        $result = $this->dbObj->sqlGet(
            "SELECT * FROM {$this->_prefix}etchat_sendeplan_vorlagen 
             ORDER BY sortierung ASC, name ASC"
        ) ?: [];
        
        return $result;
    }
    
    public function getEntries(string $startDate, string $endDate): array
    {
        $sql = "SELECT s.*, u.etchat_username as moderator_name, u.etchat_avatar as moderator_avatar
                FROM {$this->_prefix}etchat_sendeplan s
                LEFT JOIN {$this->_prefix}etchat_user u ON s.moderator_id = u.etchat_user_id
                WHERE s.datum BETWEEN :start AND :end
                ORDER BY s.datum ASC, s.zeit_von ASC";
        
        return $this->dbObj->sqlGet($sql, [
            ':start' => $startDate,
            ':end' => $endDate
        ]) ?: [];
    }
    
    public function getEntry(int $id): ?array
    {
        $result = $this->dbObj->sqlGet(
            "SELECT s.*, u.etchat_username as moderator_name, u.etchat_avatar as moderator_avatar
             FROM {$this->_prefix}etchat_sendeplan s
             LEFT JOIN {$this->_prefix}etchat_user u ON s.moderator_id = u.etchat_user_id
             WHERE s.id = :id",
            [':id' => $id]
        );
        return $result[0] ?? null;
    }
    
    public function getWeekRange(string $startDate): array
    {
        $start = new DateTime($startDate);
        $end = clone $start;
        $end->modify('+6 days');
        
        $days = [];
        $current = clone $start;
        for ($i = 0; $i < 7; $i++) {
            $days[] = $current->format('Y-m-d');
            $current->modify('+1 day');
        }
        
        return [
            'start' => $start->format('Y-m-d'),
            'end' => $end->format('Y-m-d'),
            'days' => $days,
            'weekNumber' => (int)$start->format('W'),
            'startFormatted' => $start->format('d.m.Y'),
            'endFormatted' => $end->format('d.m.Y')
        ];
    }
	
    /**
     * 🔥 NEU: Flexibler Tageszeitraum ab einem Startdatum
     * 
     * @param string $startDate  Startdatum (Y-m-d)
     * @param int    $days       Anzahl der Tage (Standard: 8)
     * @return array             Mit start, end, days (Array), count
     */
    public function getDaysRange(string $startDate, int $days = 8): array
    {
        // Sicherheitscheck: mindestens 1, maximal 31 Tage
        $days = max(1, min(31, $days));
        
        $start = new DateTime($startDate);
        $end = clone $start;
        $end->modify('+' . ($days - 1) . ' days');
        
        $daysArray = [];
        $current = clone $start;
        for ($i = 0; $i < $days; $i++) {
            $daysArray[] = $current->format('Y-m-d');
            $current->modify('+1 day');
        }
        
        return [
            'start' => $start->format('Y-m-d'),
            'end' => $end->format('Y-m-d'),
            'days' => $daysArray,
            'count' => $days,
            'startFormatted' => $start->format('d.m.Y'),
            'endFormatted' => $end->format('d.m.Y'),
        ];
    }
    
    /**
     * 🔥 NEU: Tageszeitraum ab HEUTE
     * Kurzform für getDaysRange(date('Y-m-d'), $days)
     * 
     * @param int $days Anzahl der Tage (Standard: 8)
     * @return array
     */
    public function getNextDays(int $days = 8): array
    {
        return $this->getDaysRange(date('Y-m-d'), $days);
    }
	
    /**
     * 🔥 NEU: Holt die aktuell laufende Sendung + die nächsten X Sendungen
     *          (unabhängig davon, ob sie heute oder an Folgetagen stattfinden)
     * 
     * @param int $limit Anzahl der kommenden Sendungen (ohne laufende)
     * @return array Mit 'live' (oder null) und 'upcoming' (Array)
     */
    public function getUpcomingEntries(int $limit = 3): array
    {
        $limit = max(1, min(20, $limit));
        $today = date('Y-m-d');
        $now   = date('H:i:s');
        
        // Zeitraum großzügig: heute + 30 Tage (damit wirklich die nächsten kommen)
        $end = date('Y-m-d', strtotime('+30 days'));
        
        // Alle Sendungen im Zeitraum holen (bereits sortiert: datum ASC, zeit_von ASC)
        $all = $this->getEntries($today, $end);
        
        $live = null;
        $upcoming = [];
        
        // ============================================
        // Schritt 1: Laufende Sendung ermitteln
        // ============================================
        // 1a) Heutige Sendungen prüfen
        foreach ($all as $entry) {
            if ($entry['datum'] !== $today) continue;
            
            $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
            
            if (!$isOvernight) {
                // Normale Sendung: von <= jetzt <= bis
                if ($now >= $entry['zeit_von'] && $now <= $entry['zeit_bis']) {
                    $live = $entry;
                    break;
                }
            } else {
                // Tagübergreifend: von <= jetzt (bis ist morgen früh)
                if ($now >= $entry['zeit_von']) {
                    $live = $entry;
                    break;
                }
            }
        }
        
        // 1b) Falls heute noch nichts läuft: gestrige tagübergreifende Sendungen prüfen
        if (!$live) {
            $yesterday = date('Y-m-d', strtotime('-1 day'));
            $yesterdayEntries = $this->getEntries($yesterday, $yesterday);
            foreach ($yesterdayEntries as $entry) {
                $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
                // Läuft noch bis heute früh
                if ($isOvernight && $now <= $entry['zeit_bis']) {
                    $live = $entry;
                    break;
                }
            }
        }
        
        // ============================================
        // Schritt 2: Kommende Sendungen sammeln
        // ============================================
        $liveId = $live['id'] ?? null;
        
        foreach ($all as $entry) {
            // Laufende Sendung überspringen
            if ($liveId !== null && $entry['id'] == $liveId) continue;
            
            // Vergangene Sendungen überspringen
            if ($entry['datum'] < $today) {
                // Gestrige tagübergreifende, die noch läuft → haben wir schon als live markiert
                continue;
            }
            
            if ($entry['datum'] === $today) {
                $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
                
                if (!$isOvernight) {
                    // Normale Sendung von heute: schon vorbei?
                    if ($entry['zeit_bis'] <= $now) {
                        continue; // vorbei
                    }
                    // Läuft gerade? (haben wir schon als live erfasst)
                    if ($entry['zeit_von'] <= $now && $entry['zeit_bis'] > $now) {
                        continue;
                    }
                    // Kommt heute noch → aufnehmen
                } else {
                    // Tagübergreifend von heute: 
                    // Wenn sie noch nicht begonnen hat → aufnehmen
                    if ($entry['zeit_von'] > $now) {
                        // kommt heute noch
                    } else {
                        // hat schon begonnen → als live markiert oder vorbei
                        continue;
                    }
                }
            }
            
            // Zukünftige Tage → alle aufnehmen
            $upcoming[] = $entry;
            
            if (count($upcoming) >= $limit) break;
        }
        
        return [
            'live'     => $live,
            'upcoming' => $upcoming,
        ];
    }
    
	
    /**
     * 🔥 NEU: Berechnet die Stunden-Grid-Matrix für die Übersichtsansicht
     * 
     * @param array $week      Aus getWeekRange()
     * @param array $entries   Aus getEntries($week['start'], $week['end'])
     * @param bool  $fullDay   true = immer 00-23, false = nur Bereich mit Sendungen
     * @return array           Mit 'hours', 'grid', 'hasData'
     */
    public function getHourlyGrid(array $week, array $entries, bool $fullDay = true): array
    {
        $days = $week['days']; // 7 Tage Mo-So
        
        // ============================================
        // 0. Sendungen vom Vortag mitladen (für tagübergreifende)
        // ============================================
        $prevDay = date('Y-m-d', strtotime($week['start'] . ' -1 day'));
        $prevEntries = $this->getEntries($prevDay, $prevDay);
        
        // Nur die tagübergreifenden vom Vortag, die in unsere Woche reinreichen
        foreach ($prevEntries as $pe) {
            $isOvernight = $pe['zeit_bis'] < $pe['zeit_von'];
            if ($isOvernight) {
                $entries[] = $pe;
            }
        }
        
        // ============================================
        // 1. Stunden-Bereich bestimmen
        // ============================================
        $minHour = 0;
        $maxHour = 23;
        
        if (!$fullDay) {
            $minHour = 24;
            $maxHour = 0;
            $foundAny = false;
            
            foreach ($entries as $entry) {
                // Nur Sendungen, die in dieser Woche relevant sind
                if ($entry['datum'] < $week['start'] || $entry['datum'] > $week['end']) {
                    // Vortagessendung: nur die Stunden, die in unsere Woche reinreichen
                    if ($entry['datum'] < $week['start']) {
                        $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
                        if (!$isOvernight) continue;
                        
                        // Diese Sendung läuft noch in den ersten Tag der Woche rein
                        // → sie belegt auf jeden Fall die Stunde 0 (00:00-01:00)
                        // Nur dann $minHour = 0 setzen, wenn das auch stimmt
                        $endH = (int)substr($entry['zeit_bis'], 0, 2);
                        $endM = (int)substr($entry['zeit_bis'], 3, 2);
                        
                        // Bei genau 00:00 → läuft nicht in den nächsten Tag
                        if ($endH === 0 && $endM === 0) {
                            continue;
                        }
                        
                        if (0 < $minHour) $minHour = 0;
                        if ($endH > $maxHour) $maxHour = $endH;
                        $foundAny = true;
                    }
                    continue;
                }
                
                $fromH = (int)substr($entry['zeit_von'], 0, 2);
                $toH   = (int)substr($entry['zeit_bis'], 0, 2);
                $toM   = (int)substr($entry['zeit_bis'], 3, 2);
                $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
                
                // Sonderfall: Endet um genau 00:00 → wird als "bis 24:00" betrachtet
                // (also deckt bis Ende Stunde 23 ab)
                if ($entry['zeit_bis'] === '00:00:00' || $entry['zeit_bis'] === '00:00') {
                    $endHourForBlock = 23;
                } else {
                    // Normalfall: Endminute > 0 → diese Stunde ist belegt
                    // Endminute = 0 → vorherige Stunde ist die letzte volle
                    $endHourForBlock = ($toM > 0) ? $toH : $toH - 1;
                }
                
                if ($fromH < $minHour) $minHour = $fromH;
                
				if ($isOvernight) {
					// geht über Mitternacht → deckt bis 23 ab + beim nächsten Tag 0..bis
					if (23 > $maxHour) $maxHour = 23;
    
					// 🔥 NEU: Morgenstunden des Folgetages brauchen wir auch
					if (0 < $minHour) $minHour = 0;
    
					// 🔥 NEU: Die Endstunde des Folgetages
					if ($endHourForBlock > $maxHour) $maxHour = $endHourForBlock;
				} else {
					if ($endHourForBlock > $maxHour) $maxHour = $endHourForBlock;
				}
                $foundAny = true;
            }
            
            if (!$foundAny) {
                $minHour = 0;
                $maxHour = 23;
            }
            
            $minHour = max(0, min(23, $minHour));
            $maxHour = max($minHour, min(23, $maxHour));
        }
        
        // Stunden-Array bauen
        $hours = [];
        for ($h = $minHour; $h <= $maxHour; $h++) {
            $hours[] = [
                'from'  => $h,
                'to'    => $h + 1,
                'label' => sprintf('%02d-%02d', $h, $h + 1),
            ];
        }
        
        // ============================================
        // 2. Grid-Matrix aufbauen
        // ============================================
        $grid = [];
        foreach ($hours as $hourInfo) {
            $grid[$hourInfo['from']] = [];
        }
        
        $hasData = false;
        
        foreach ($days as $day) {
            $prevDayStr = date('Y-m-d', strtotime($day . ' -1 day'));
            
            foreach ($hours as $hourInfo) {
                $h = $hourInfo['from'];
                $slotStartSec = $h * 3600;
                $slotEndSec   = ($h + 1) * 3600; // exklusiv (24:00 = 86400)
                
                $grid[$h][$day] = [];
                
                foreach ($entries as $entry) {
                    $isOvernight   = $entry['zeit_bis'] < $entry['zeit_von'];
                    $isFromThisDay = ($entry['datum'] === $day);
                    $isFromPrevDay = ($entry['datum'] === $prevDayStr);
                    
                    if (!$isFromThisDay && !$isFromPrevDay) continue;
                    
                    // ============================================
                    // Zeitfenster dieser Sendung für den aktuellen Tag bestimmen
                    // ============================================
                    if ($isFromThisDay) {
                        $startSec = $this->timeToSec($entry['zeit_von']);
                        
                        if ($isOvernight) {
                            // geht bis 24:00 des aktuellen Tages
                            $endSec = 24 * 3600;
                        } else {
                            $endSec = $this->timeToSec($entry['zeit_bis']);
                        }
                    } else {
                        // Sendung startete am Vortag, ist tagübergreifend
                        if (!$isOvernight) continue;
                        // Auf dem aktuellen Tag: von 00:00 bis zeit_bis
                        $startSec = 0;
                        $endSec   = $this->timeToSec($entry['zeit_bis']);
                    }
                    
                    // Prüfen ob die Sendung diesen Slot berührt
                    // Slot berührt = start < slotEnd && end > slotStart
                    // (end ist exklusiv)
                    if ($startSec < $slotEndSec && $endSec > $slotStartSec) {
                        $hasData = true;
                        
                        // Typ bestimmen: mod (Slot vollständig innerhalb der Sendung)
                        // oder zeitteiler (Sendung beginnt/endet in diesem Slot)
                        $isFullSlot = ($startSec <= $slotStartSec && $endSec >= $slotEndSec);
                        
                        if ($isFullSlot) {
                            // Sendung deckt den Slot komplett ab → Mod
                            $grid[$h][$day][] = [
                                'type'  => 'mod',
                                'entry' => $entry,
                            ];
                        } else {
                            // Sendung beginnt oder endet in diesem Slot
                            $startsInSlot = ($startSec >= $slotStartSec && $startSec < $slotEndSec);
                            $endsInSlot   = ($endSec > $slotStartSec && $endSec < $slotEndSec);
                            
                            if ($startsInSlot && $endsInSlot) {
                                // Sendung liegt komplett innerhalb dieses Slots (z.B. 20:15–20:45)
                                // → Mod
                                $grid[$h][$day][] = [
                                    'type'  => 'mod',
                                    'entry' => $entry,
                                ];
                            } elseif ($startsInSlot) {
                                // Sendung beginnt hier, geht in nächsten Slot → Mod
                                $grid[$h][$day][] = [
                                    'type'  => 'mod',
                                    'entry' => $entry,
                                ];
                            } elseif ($endsInSlot) {
                                // Sendung endet hier, begann im vorherigen Slot → Zeitteiler
                                $grid[$h][$day][] = [
                                    'type'  => 'zeitteiler',
                                    'entry' => $entry,
                                ];
                            }
                        }
                    }
                }
            }
        }
        
        return [
            'hours'   => $hours,
            'grid'    => $grid,
            'hasData' => $hasData,
        ];
    }
    
    /**
     * 🔥 Helper: Zeit "HH:MM:SS" in Sekunden umwandeln
     */
    private function timeToSec(string $time): int
    {
        $parts = explode(':', $time);
        $h = (int)($parts[0] ?? 0);
        $m = (int)($parts[1] ?? 0);
        $s = (int)($parts[2] ?? 0);
        return $h * 3600 + $m * 60 + $s;
    }
	
public function saveEntry(array $data): array
{
    // 1. Berechtigung prüfen
    if (!$this->isAuthorized()) {
        return ['success' => false, 'error' => $this->getText('sendeplan_no_permission', 'Keine Berechtigung')];
    }
    
    // 2. Pflichtfelder prüfen
    if (empty($data['datum']) || empty($data['zeit_von']) || 
        empty($data['zeit_bis']) || empty($data['sendungsname'])) {
        return ['success' => false, 'error' => $this->getText('sendeplan_fields_missing', 'Bitte alle Pflichtfelder ausfüllen')];
    }
    
    // 🔥 NEU: Prüfen, ob das Datum in der Vergangenheit liegt (NUR bei Neuanlage!)
    $id = $data['id'] ?? 0;
    $today = date('Y-m-d');
    $currentTime = date('H:i');
    
    // 3. Prüfen, ob das Datum in der Vergangenheit liegt (NUR bei Neuanlage, ID == 0)
    if ($id == 0 && $data['datum'] < $today) {
        return ['success' => false, 'error' => $this->getText('sendeplan_past_date_error', 'Das Datum darf nicht in der Vergangenheit liegen')];
    }
    
    // 🔥 NEU: Prüfen, ob die Startzeit zu weit in der Vergangenheit liegt (max. 1 Stunde)
    if ($id == 0 && $data['datum'] === $today && $data['zeit_von'] < date('H:i', strtotime('-30 minutes'))) {
        return ['success' => false, 'error' => $this->getText('sendeplan_past_time_error', 'Die Startzeit darf maximal eine halbe Stunde in der Vergangenheit liegen')];
    }
    
    // 3. Zeit prüfen (Tagübergreifend erlaubt!)
    if ($data['zeit_von'] == $data['zeit_bis']) {
        return ['success' => false, 'error' => $this->getText('sendeplan_time_error', 'Startzeit und Endzeit dürfen nicht gleich sein')];
    }
	
    // 🔥 NEU: Prüfen, ob das Datum zu weit in der Zukunft liegt (NUR bei Neuanlage!)
    // ABER: Serien-Einträge (serie_gruppe gesetzt) überspringen diese Prüfung,
    // weil Serien eine eigene Regel haben (92 Tage / 60 Termine).
    $isSerieEntry = !empty($data['serie_gruppe']);
    
    if ($id == 0 && !$isSerieEntry) {
        $maxDays = (int)($this->config['max_days_ahead'] ?? 90);
        if ($maxDays > 0) {
            $maxDate = date('Y-m-d', strtotime("+$maxDays days"));
            if ($data['datum'] > $maxDate) {
                return ['success' => false, 'error' => $this->getText('sendeplan_future_date_error', 'Das Datum darf maximal ' . $maxDays . ' Tage in der Zukunft liegen')];
            }
        }
    }
    
    // 4. Überschneidungsprüfung
    $id = $data['id'] ?? 0;
    $check = $this->checkOverlap($data['datum'], $data['zeit_von'], $data['zeit_bis'], (int)$id);
    if (!$check['success']) {
        return ['success' => false, 'error' => $check['message']];
    }
    
    // 5. Daten vorbereiten
    $wunschbox_aktiv = isset($data['wunschbox_aktiv']) ? (int)$data['wunschbox_aktiv'] : 1;
    $moderator_id = isset($data['moderator_id']) && $data['moderator_id'] !== '' && $data['moderator_id'] !== null 
        ? (int)$data['moderator_id'] 
        : null;
    // 🔥 NEU: Bild
    $bild = isset($data['bild']) && $data['bild'] !== '' ? $data['bild'] : null;
    
    // 6. Speichern
    if ($id > 0) {
        $sql = "UPDATE {$this->_prefix}etchat_sendeplan SET
                    datum = :datum,
                    zeit_von = :zeit_von,
                    zeit_bis = :zeit_bis,
                    sendungsname = :sendungsname,
                    beschreibung = :beschreibung,
                    wunschbox_aktiv = :wunschbox_aktiv,
                    moderator_id = :moderator_id,
                    erstellt_von = :erstellt_von,
                    bild = :bild,
                    serie_gruppe = :serie_gruppe,
                    serie_nummer = :serie_nummer
                WHERE id = :id";
        
        $params = [
            ':datum' => $data['datum'],
            ':zeit_von' => $data['zeit_von'],
            ':zeit_bis' => $data['zeit_bis'],
            ':sendungsname' => $data['sendungsname'],
            ':beschreibung' => $data['beschreibung'] ?? '',
            ':wunschbox_aktiv' => $wunschbox_aktiv,
            ':moderator_id' => $moderator_id,
            ':erstellt_von' => $data['erstellt_von'] ?? $this->user_id,
            ':bild' => $bild,
            ':serie_gruppe' => $data['serie_gruppe'] ?? null,
            ':serie_nummer' => $data['serie_nummer'] ?? null,
            ':id' => (int)$id
        ];
        
        $success = $this->dbObj->sqlSet($sql, $params);
        return ['success' => $success, 'id' => (int)$id];
        
    } else {
        $sql = "INSERT INTO {$this->_prefix}etchat_sendeplan
                    (datum, zeit_von, zeit_bis, sendungsname, beschreibung, 
                     wunschbox_aktiv, moderator_id, erstellt_von, bild,
                     serie_gruppe, serie_nummer)
                VALUES
                    (:datum, :zeit_von, :zeit_bis, :sendungsname, :beschreibung,
                     :wunschbox_aktiv, :moderator_id, :erstellt_von, :bild,
                     :serie_gruppe, :serie_nummer)";
        
        $params = [
            ':datum' => $data['datum'],
            ':zeit_von' => $data['zeit_von'],
            ':zeit_bis' => $data['zeit_bis'],
            ':sendungsname' => $data['sendungsname'],
            ':beschreibung' => $data['beschreibung'] ?? '',
            ':wunschbox_aktiv' => $wunschbox_aktiv,
            ':moderator_id' => $moderator_id,
            ':erstellt_von' => $this->user_id,
            ':bild' => $bild,
            ':serie_gruppe' => $data['serie_gruppe'] ?? null,
            ':serie_nummer' => $data['serie_nummer'] ?? null
        ];
        
        $newId = $this->dbObj->sqlSet($sql, $params);
        return ['success' => ($newId > 0), 'id' => $newId];
    }
}

/**
 * 🔥 NEU: Prüft ob eine Sendung sich mit anderen überschneidet
 */
public function checkOverlap(string $datum, string $zeit_von, string $zeit_bis, int $ignoreId = 0): array
{
    // 1. Prüfen ob Startzeit == Endzeit (nicht erlaubt)
    if ($zeit_von == $zeit_bis) {
        return ['success' => false, 'message' => $this->getText('sendeplan_time_error', 'Startzeit und Endzeit dürfen nicht gleich sein')];
    }
    
    // 2. Tagübergreifend? (Endzeit < Startzeit, z.B. 22:00 - 02:00)
    $isOvernight = $zeit_bis < $zeit_von;
    
    // 3. SQL-Abfrage für den Zeitraum
    $sql = "SELECT id, sendungsname, zeit_von, zeit_bis 
            FROM {$this->_prefix}etchat_sendeplan 
            WHERE datum = :datum 
              AND id != :ignore_id
              AND (
                  -- Fall A: Normale Sendung (nicht tagübergreifend)
                  (zeit_bis > zeit_von AND (
                      (zeit_von < :zeit_bis AND zeit_bis > :zeit_von)
                  ))
                  OR
                  -- Fall B: Tagübergreifende Sendung (bestehende Sendung läuft über Mitternacht)
                  (zeit_bis < zeit_von AND (
                      (zeit_von < :zeit_bis) OR (zeit_bis > :zeit_von)
                  ))
              )
            ORDER BY zeit_von ASC";
    
    $params = [
        ':datum' => $datum,
        ':zeit_von' => $zeit_von,
        ':zeit_bis' => $zeit_bis,
        ':ignore_id' => $ignoreId
    ];
    
    $overlaps = $this->dbObj->sqlGet($sql, $params);
    
    if (empty($overlaps)) {
        return ['success' => true];
    }
    
    // 4. Fehlermeldung mit allen Überschneidungen
    $messages = [];
    foreach ($overlaps as $overlap) {
        $messages[] = htmlspecialchars($overlap['sendungsname']) . ' (' . substr($overlap['zeit_von'], 0, 5) . '-' . substr($overlap['zeit_bis'], 0, 5) . ' Uhr)';
    }
    
    $message = $this->getText('sendeplan_overlap_error', 'Überschneidung mit: {list}');
    $message = str_replace('{list}', implode(', ', $messages), $message);
    
    return ['success' => false, 'message' => $message];
}
    
    public function deleteEntry(int $id): array
    {
        if (!$this->isAuthorized()) {
            return ['success' => false, 'error' => $this->getText('sendeplan_no_permission', 'Keine Berechtigung')];
        }
        
        $entry = $this->getEntry($id);
        if (!$entry) {
            return ['success' => false, 'error' => $this->getText('sendeplan_not_found', 'Eintrag nicht gefunden')];
        }
        
        $success = $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_sendeplan WHERE id = :id",
            [':id' => $id]
        );
        
        // Auch alle Wünsche zu dieser Sendung löschen
        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_wunschbox WHERE sendungs_id = :id",
            [':id' => $id]
        );
        
        return ['success' => $success];
    }
    
    public function formatTime(string $time): string
    {
        return substr($time, 0, 5);
    }
    
    public function getWeekday(string $date): string
    {
        $weekdays = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
        $d = new DateTime($date);
        $index = (int)$d->format('N') - 1;
        return $weekdays[$index];
    }
    
    public function isToday(string $date): bool
    {
        return $date === date('Y-m-d');
    }
	
    // ============================================================
    // SERIEN-FEATURE
    // ============================================================

    /**
     * Berechnet alle Termine für eine Wiederholung
     *
     * @param string $startDatum  Y-m-d
     * @param array  $regel
     * @return string[]  Liste von Y-m-d
     */
    public function calculateSerieTermine(string $startDatum, array $regel): array
    {
        $maxTermine = max(2, (int)($this->config['serien_max_termine'] ?? 60));
        $maxTage    = max(7, (int)($this->config['serien_max_tage'] ?? 92));

        $start = new DateTime($startDatum);
        $typ = $regel['wiederholung'] ?? 'taeglich';

        // ============================================================
        // 🔥 NEU: Bei monatlichen Serien anderes Limit
        //
        // Für monatliche Serien gilt:
        //   effektiveMaxTermine = SERIEN_MONATE_MAX / monats_intervall
        //
        // SERIEN_MONATE_MAX = 36 → ergibt ca. 3 Jahre Gesamt-Zeitraum
        // (z. B. 36 × 1 Monat = 3 Jahre, 3 × 12 Monate = 3 Jahre)
        //
        // TODO: Später als Config-Wert "serien_monate_max" einbaubar.
        // ============================================================
        if ($typ === 'monatlich') {
            // 🔥 NEU: Config-Wert für die maximale Dauer monatlicher Serien
            // (Standard: 36 Monate = 3 Jahre)
            $serienMonateMax = (int)($this->config['serien_monate_max'] ?? 36);
            
            // Sicherheitscheck: nur erlaubte Werte (2–6 Jahre)
            if ($serienMonateMax < 24) $serienMonateMax = 24;
            if ($serienMonateMax > 72) $serienMonateMax = 72;
            
            $monatsIntervall = max(1, (int)($regel['monat_intervall'] ?? 1));
            $effektiveMaxTermine = max(2, (int)($serienMonateMax / $monatsIntervall));
            
            // Tages-Limit: entspricht der konfigurierten Monate-Dauer + Puffer (30 Tage)
            $maxEndTage = ($serienMonateMax * 30) + 30;
            $maxEnd = (clone $start)->modify("+{$maxEndTage} days");
        } else {
            $effektiveMaxTermine = $maxTermine;
            $maxEnd = (clone $start)->modify("+{$maxTage} days");
        }

        // Ende bestimmen
        $endeDatum = null;
        $endeTyp = $regel['ende_typ'] ?? 'anzahl';

        if ($endeTyp === 'datum' && !empty($regel['ende_datum'])) {
            $endeDatum = new DateTime($regel['ende_datum']);
            if ($endeDatum > $maxEnd) {
                $endeDatum = $maxEnd;
            }
        } else {
            $endeDatum = $maxEnd;
        }

        // Ende-Anzahl — mit dem effektiven Limit begrenzen
        $endeAnzahl = ($endeTyp === 'anzahl')
            ? max(1, (int)($regel['ende_anzahl'] ?? 10))
            : $effektiveMaxTermine;

        $endeAnzahl = min($endeAnzahl, $effektiveMaxTermine);

        $termine = [];

        switch ($typ) {

            // ============================================
            // TÄGLICH / WÖCHENTLICH (Mo–So Checkboxen)
            // Mit Wochen-Intervall (jede Woche / alle X Wochen)
            // ============================================
            case 'taeglich':
            case 'woechentlich':
                $wochentage = $regel['wochentage'] ?? [];
                if (!is_array($wochentage)) $wochentage = [];
                $wochentage = array_map('intval', $wochentage);
                
                // 🔥 NEU: Wochen-Intervall (1 = jede Woche, 2 = alle 2 Wochen, ...)
                $wochenIntervall = max(1, (int)($regel['wochen_intervall'] ?? 1));

                $current = clone $start;
                while (count($termine) < $endeAnzahl) {
                    if ($current > $endeDatum) break;

                    // 🔥 NEU: Nur in Wochen aufnehmen, die zum Intervall passen
                    $weekDiff = $this->getWeekDiff($start, $current);
                    $isInRightWeek = ($weekDiff % $wochenIntervall) === 0;
                    
                    if ($isInRightWeek) {
                        $wd = (int)$current->format('N'); // 1=Mo ... 7=So
                        if (empty($wochentage) || in_array($wd, $wochentage, true)) {
                            $termine[] = $current->format('Y-m-d');
                        }
                    }
                    $current->modify('+1 day');
                }
                break;

            // ============================================
            // ALLE X TAGE
            // ============================================
            case 'intervall':
                $intervall = max(1, (int)($regel['intervall'] ?? 1));

                $current = clone $start;
                while (count($termine) < $endeAnzahl) {
                    if ($current > $endeDatum) break;

                    $termine[] = $current->format('Y-m-d');
                    $current->modify("+{$intervall} days");
                }
                break;

            // ============================================
            // MONATLICH
            // Mit Monats-Intervall (jeden Monat / alle X Monate)
            // ============================================
            case 'monatlich':
                $modus = $regel['monat_modus'] ?? 'tag';
                
                // 🔥 NEU: Monats-Intervall (1 = jeden Monat, 2 = alle 2 Monate, ...)
                $monatsIntervall = max(1, (int)($regel['monat_intervall'] ?? 1));

                if ($modus === 'tag') {
                    // Jeden X. Tag des Monats
                    $tag = max(1, min(31, (int)($regel['monat_tag'] ?? 1)));

                    $current = clone $start;
                    $monatsZaehler = 0;   // 🔥 NEU
                    while (count($termine) < $endeAnzahl) {
                        if ($current > $endeDatum) break;

                        // 🔥 NEU: Nur jeden X. Monat
                        if (($monatsZaehler % $monatsIntervall) === 0) {
                            $jahr  = (int)$current->format('Y');
                            $monat = (int)$current->format('n');
                            $tageImMonat = (int)$current->format('t');
                            $zielTag = min($tag, $tageImMonat);

                            $kandidat = new DateTime(sprintf('%04d-%02d-%02d', $jahr, $monat, $zielTag));
                            if ($kandidat >= $start && $kandidat <= $endeDatum) {
                                $termine[] = $kandidat->format('Y-m-d');
                            }
                        }

                        // Nächster Monat
                        $current->modify('first day of next month');
                        $monatsZaehler++;   // 🔥 NEU
                    }
                } else {
                    // Jeden X. [Wochentag] des Monats
                    $position  = max(1, min(5, (int)($regel['monat_position'] ?? 1)));
                    $wochentag = max(1, min(7, (int)($regel['monat_wochentag'] ?? 1)));

                    $current = clone $start;
                    $current->modify('first day of this month');
                    $monatsZaehler = 0;   // 🔥 NEU

                    while (count($termine) < $endeAnzahl) {
                        if ($current > $endeDatum) break;

                        // 🔥 NEU: Nur jeden X. Monat
                        if (($monatsZaehler % $monatsIntervall) === 0) {
                            $kandidat = $this->getNthWeekdayOfMonth(
                                (int)$current->format('Y'),
                                (int)$current->format('n'),
                                $wochentag,
                                $position
                            );

                            if ($kandidat && $kandidat >= $start && $kandidat <= $endeDatum) {
                                $termine[] = $kandidat->format('Y-m-d');
                            }
                        }

                        $current->modify('first day of next month');
                        $monatsZaehler++;   // 🔥 NEU
                    }
                }
                break;
        }

        return $termine;
    }

    /**
     * Findet den n-ten Wochentag im Monat
     * z.B. 1. Montag im September 2026
     */
    private function getNthWeekdayOfMonth(int $jahr, int $monat, int $wochentag, int $position): ?DateTime
    {
        $erster = new DateTime(sprintf('%04d-%02d-01', $jahr, $monat));
        $wdErster = (int)$erster->format('N');

        // Wie viele Tage bis zum ersten Vorkommen des Wochentags?
        $diff = ($wochentag - $wdErster + 7) % 7;
        $tag = 1 + $diff + ($position - 1) * 7;

        $tageImMonat = (int)$erster->format('t');
        if ($tag > $tageImMonat) {
            return null;
        }

        return new DateTime(sprintf('%04d-%02d-%02d', $jahr, $monat, $tag));
    }
	
    /**
     * 🔥 NEU: Berechnet die Differenz in Wochen zwischen zwei Daten
     *          (normalisiert auf Montag, robust bei Jahreswechsel)
     */
    private function getWeekDiff(DateTime $start, DateTime $current): int
    {
        // Auf Wochenanfang (Montag) normalisieren
        $startMon = clone $start;
        $startMon->modify('monday this week');
        $startMon->setTime(0, 0, 0);
        
        $currMon = clone $current;
        $currMon->modify('monday this week');
        $currMon->setTime(0, 0, 0);
        
        $diffSeconds = $currMon->getTimestamp() - $startMon->getTimestamp();
        return (int)floor($diffSeconds / (7 * 86400));
    }
	
    /**
     * 🔥 NEU: Ersetzt den Zahl-Joker in einem Text
     * 
     * Unterstützte Formate:
     *   {zahl}      → startet bei 1
     *   {4 zahl}    → startet bei 4 (Leerzeichen zwischen Zahl und "zahl")
     * 
     * Beispiele bei $nummer = 1:
     *   "Staffel {zahl}"   → "Staffel 1"
     *   "Staffel {4 zahl}" → "Staffel 4"
     * 
     * Beispiele bei $nummer = 3:
     *   "Staffel {zahl}"   → "Staffel 3"
     *   "Staffel {4 zahl}" → "Staffel 6"
     */
    public function ersetzeZahlJoker(string $text, int $nummer): string
    {
        if ($text === '') {
            return $text;
        }
        
        return preg_replace_callback(
            '/\{(\d+\s+)?zahl\}/i',
            function($m) use ($nummer) {
                // Wenn ein Startwert angegeben wurde, nutze diesen
                $start = 1;
                if (!empty($m[1])) {
                    $start = (int)trim($m[1]);
                }
                // Ergebnis: Startwert + (aktuelle Nummer - 1)
                return (string)($start + $nummer - 1);
            },
            $text
        );
    }
	
	/**
 * 🔥 NEU: Füllt die Lücken eines Tages mit virtuellen Auto-DJ-Einträgen
 * 
 * Wird nur angewendet, wenn auto_dj_enabled = 1.
 * Berücksichtigt tagübergreifende Sendungen.
 * 
 * @param string $day       Y-m-d
 * @param array  $entries   Sendungen des Tages (aus getEntries)
 * @return array            Sortierte Liste mit echten + Auto-DJ-Einträgen
 */
public function fillWithAutoDj(string $day, array $entries): array
{
    // 1. Ist Auto-DJ aktiv?
    $enabled = ($this->config['auto_dj_enabled'] ?? '0') == '1';
    if (!$enabled) {
        return $entries;
    }
    
    // 2. Zeitfenster aus Config holen
    $timeFrom = $this->config['auto_dj_time_from'] ?? '08:00';
    $timeTo   = $this->config['auto_dj_time_to']   ?? '22:00';
    
    // 3. Zeitfenster normalisieren (HH:MM → HH:MM:SS)
    if (strlen($timeFrom) === 5) $timeFrom .= ':00';
    if (strlen($timeTo)   === 5) $timeTo   .= ':00';
    
    // 🔥 NEU: Sonderfälle für 24 Stunden
    $isAllDay = false;
    
    // Fall 1: 00:00 bis 00:00
    if ($timeFrom === '00:00:00' && $timeTo === '00:00:00') {
        $isAllDay = true;
    }
    
    // Fall 2: 00:00 bis 24:00
    if ($timeFrom === '00:00:00' && ($timeTo === '24:00:00' || $timeTo === '24:00')) {
        $isAllDay = true;
    }
    
    if ($isAllDay) {
        $timeFrom = '00:00:00';
        $timeTo   = '24:00:00';
    }
    
    // 4. Sicherheitscheck: from < to (sonst ungültig)
    // (Bei 24-Stunden-Sonderfall: timeTo ist '24:00:00', das ist > timeFrom)
    if ($timeFrom >= $timeTo) {
        return $entries; // ungültig → nichts tun
    }
    
    // 5. Alle Sendungen sammeln, die diesen Tag betreffen
    //    (inkl. tagübergreifende vom Vortag + eigene tagübergreifende)
    $dayStart = $day . ' 00:00:00';
    $dayEnd   = $day . ' 24:00:00';
    
    $prevDay = date('Y-m-d', strtotime($day . ' -1 day'));
    $prevEntries = $this->getEntries($prevDay, $prevDay);
    
    // Alle "Blöcke" dieses Tages aufbauen (Start + Ende als Timestamp)
    $blocks = [];
    
    // 5a) Eigene Sendungen des Tages
    foreach ($entries as $entry) {
        // Ist es eine tagübergreifende Sendung? (zeit_bis < zeit_von)
        $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
        
        $startTs = strtotime($entry['datum'] . ' ' . $entry['zeit_von']);
        
        if ($isOvernight) {
            // Endet am nächsten Tag
            $endTs = strtotime($entry['datum'] . ' ' . $entry['zeit_bis'] . ' +1 day');
        } else {
            $endTs = strtotime($entry['datum'] . ' ' . $entry['zeit_bis']);
        }
        
        // Prüfen ob der Block in unseren Tag reicht
        $blockStartTs = max($startTs, strtotime($dayStart));
        $blockEndTs   = min($endTs,   strtotime($dayEnd));
        
        if ($blockStartTs < $blockEndTs) {
            $blocks[] = [
                'start' => $blockStartTs,
                'end'   => $blockEndTs,
                'entry' => $entry,
            ];
        }
    }
    
    // 5b) Tagübergreifende Sendungen vom Vortag
    foreach ($prevEntries as $entry) {
        $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
        if (!$isOvernight) continue; // normale Sendung vom Vortag ignorieren
        
        // Sonderfall: endet um 00:00 → nicht tagübergreifend
        if ($entry['zeit_bis'] === '00:00:00' || $entry['zeit_bis'] === '00:00') {
            continue;
        }
        
        $startTs = strtotime($entry['datum'] . ' ' . $entry['zeit_von']);
        $endTs   = strtotime($entry['datum'] . ' ' . $entry['zeit_bis'] . ' +1 day');
        
        // Der Block liegt am aktuellen Tag: von 00:00 bis endTs
        $blockStartTs = max($startTs, strtotime($dayStart));
        $blockEndTs   = min($endTs,   strtotime($dayEnd));
        
        if ($blockStartTs < $blockEndTs) {
            $blocks[] = [
                'start' => $blockStartTs,
                'end'   => $blockEndTs,
                'entry' => $entry,
            ];
        }
    }
    
    // 6. Blöcke nach Startzeit sortieren
    usort($blocks, function($a, $b) {
        return $a['start'] - $b['start'];
    });
    
    // 7. Zeitfenster in Timestamps umrechnen (relativ zum Tag)
	$windowStartTs = strtotime($day . ' ' . $timeFrom);

	// 🔥 NEU: 24:00:00 → nächster Tag 00:00:00
	if ($timeTo === '24:00:00') {
		$windowEndTs = strtotime($day . ' +1 day 00:00:00');
	} else {
		$windowEndTs = strtotime($day . ' ' . $timeTo);
	}
    
    // 8. Lücken berechnen
    $autoDjEntries = [];
    $cursorTs = strtotime($dayStart); // Start: 00:00:00
    
    foreach ($blocks as $block) {
        // Lücke vor diesem Block?
        if ($cursorTs < $block['start']) {
            // Auto-DJ nur einfügen, wenn die Lücke im Zeitfenster liegt
            $gapStartTs = max($cursorTs, $windowStartTs);
            $gapEndTs   = min($block['start'], $windowEndTs);
            
            if ($gapStartTs < $gapEndTs) {
                $autoDjEntries[] = $this->makeAutoDjEntry($day, $gapStartTs, $gapEndTs);
            }
        }
        
        // Cursor auf das Ende des Blocks setzen
        $cursorTs = max($cursorTs, $block['end']);
    }
    
    // 9. Lücke nach dem letzten Block?
    $endOfDayTs = strtotime($dayEnd);
    if ($cursorTs < $endOfDayTs) {
        $gapStartTs = max($cursorTs, $windowStartTs);
        $gapEndTs   = min($endOfDayTs, $windowEndTs);
        
        if ($gapStartTs < $gapEndTs) {
            $autoDjEntries[] = $this->makeAutoDjEntry($day, $gapStartTs, $gapEndTs);
        }
    }
    
    // 10. Alles zusammenführen und nach Startzeit sortieren
    $allEntries = array_merge($entries, $autoDjEntries);
    
    usort($allEntries, function($a, $b) {
        // Sortieren nach Datum, dann zeit_von
        $dateCmp = strcmp($a['datum'] ?? '', $b['datum'] ?? '');
        if ($dateCmp !== 0) return $dateCmp;
        return strcmp($a['zeit_von'] ?? '', $b['zeit_von'] ?? '');
    });
    
    return $allEntries;
}

/**
 * 🔥 NEU: Erzeugt einen virtuellen Auto-DJ-Eintrag
 */
private function makeAutoDjEntry(string $day, int $startTs, int $endTs): array
{
    return [
        'id'              => null,
        'datum'           => $day,
        'zeit_von'        => date('H:i:s', $startTs),
        'zeit_bis'        => date('H:i:s', $endTs),
        'sendungsname'    => $this->getText('sendeplan_autodj', 'Auto DJ'),
        'beschreibung'    => $this->getText('sendeplan_autodj_default_desc', '🎵 Automatisches Programm'),
        'bild'            => 'Auto_DJ.jpg', // null oder 'Auto_DJ.jpg' wenn du ein Standard-Bild willst
        'moderator_id'    => null,
        'moderator_name'  => null,
        'moderator_avatar'=> null,
        'wunschbox_aktiv' => 0,
        'erstellt_von'    => null,
        'serie_gruppe'    => null,
        'serie_nummer'    => null,
        'is_autodj'       => true,
    ];
}
	
}