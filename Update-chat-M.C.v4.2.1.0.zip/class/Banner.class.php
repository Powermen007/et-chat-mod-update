<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Banner extends DbConectionMaker
{
    /**
     * Popup-Muster – MUSS identisch sein mit AdminCreateNewMenu, Menu, MenuIndex.
     * Capture-Groups:
     *   [1] = Ziel-URL
     *   [2] = "width=...,height=..."
     */
    private const POPUP_REGEX =
        '~^window\.open\(\x27(https?://[a-zA-Z0-9\-._\x7E:/?#\[\]@!$&\x27()*+,;=%]+)\x27,\x27\x27,\x27\s*((?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4})(?:\s*,\s*(?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4}))*)\s*\x27\); return false;$~';

    public function __construct()
    {
        parent::__construct();
    }

    public function render(): void
    {
        $rows = $this->dbObj->sqlGet("
            SELECT id, menu, link_text, image_active, image, url, target, gewicht
            FROM {$this->_prefix}etchat_menu
            WHERE menu = 3
            ORDER BY gewicht
        ");

        if (!is_array($rows) || empty($rows)) {
            return;
        }

        // Output Buffering für Performance
        ob_start();

        echo '<div class="w3-content w3-display-container">';

        foreach ($rows as $row) {

            $rawUrl      = (string)($row['url'] ?? '');
            $linkText    = htmlspecialchars((string)($row['link_text'] ?? ''), ENT_QUOTES, 'UTF-8');
            $imageActive = (int)($row['image_active'] ?? 0);
            $image       = htmlspecialchars((string)($row['image'] ?? ''), ENT_QUOTES, 'UTF-8');
            $rawTarget   = (string)($row['target'] ?? '_self');

            // -------------------------
            // Popup?
            // -------------------------
            $isPopup = ($rawUrl !== '') && preg_match(self::POPUP_REGEX, $rawUrl, $m);

            if ($isPopup) {
                $safeUrl  = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
                $features = htmlspecialchars($m[2], ENT_QUOTES, 'UTF-8');

                $hrefAttr    = ' href="' . $safeUrl . '"';
                $targetAttr  = '';
                $onclickAttr = ' onclick="window.open(\'' . $safeUrl . '\',\'\',\'' . $features . '\');return false;"';
            } else {
                $safeUrl     = htmlspecialchars($rawUrl !== '' ? $rawUrl : '#', ENT_QUOTES, 'UTF-8');

                $allowedTargets = ['', '_blank', '_self', '_parent', '_top'];
                $target         = in_array($rawTarget, $allowedTargets, true) ? $rawTarget : '_self';

                $hrefAttr    = ' href="' . $safeUrl . '"';
                $targetAttr  = ' target="' . htmlspecialchars($target, ENT_QUOTES, 'UTF-8') . '"';
                $onclickAttr = '';
            }

            // -------------------------
            // Ausgabe
            // -------------------------
            if ($imageActive === 1 && $image !== '') {

                echo '<a class="img_banner"' . $hrefAttr . $targetAttr . $onclickAttr . '>';
                echo '<img class="mySlides" src="img/menu/' . $image . '" alt="' . $linkText . '" />';
                echo '</a>';

            } else {

                echo '<a' . $hrefAttr . $targetAttr . $onclickAttr . '>';
                echo '<span class="mySlides banner-text">' . $linkText . '</span>';
                echo '</a>';
            }
        }

        echo '</div>';

        // CSS
        echo <<<STYLE
<style>
.mySlides {
    display: none;
    max-width: 100%;
    border-radius: 10px;
}
.img_banner img {
    border-radius: 10px;
}
.banner-text {
    display: block;
    font-size: 32px;
    font-weight: bold;
    padding: 20px;
}
</style>
STYLE;

        // JS
        echo <<<SCRIPT
<script>
let slideIndex = 0;
function carousel() {
    const slides = document.getElementsByClassName("mySlides");
    for (let i = 0; i < slides.length; i++) slides[i].style.display = "none";
    slideIndex++;
    if (slideIndex > slides.length) slideIndex = 1;
    if (slides.length > 0) slides[slideIndex-1].style.display = "block";
    setTimeout(carousel, 30000);
}
carousel();
</script>
SCRIPT;

        // Flush buffer einmalig
        ob_end_flush();
    }
}

// Aufruf wie bisher
$banner = new Banner();
$banner->render();