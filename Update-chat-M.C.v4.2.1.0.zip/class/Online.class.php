<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Online extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function replacePlaceholders(string $text, array $placeholders): string
    {
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', $value, $text);
        }
        return $text;
    }

    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangJson();

        // Config abrufen
        $una = $this->dbObj->sqlGet(
            "SELECT etchat_config_name_user 
             FROM {$this->_prefix}etchat_config 
             WHERE etchat_config_id = :id",
            [':id' => 1]
        );

        // Gleiche Logik wie CheckUserName:
        // Karteileiche nur, wenn BEIDE Zeitstempel alt sind.
        // Schwelle: 30 s (Kompromiss zwischen schnellem Login und Netzwerk-Toleranz)
        $reloadSec = (int)($_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] ?? 5000) / 1000;
        $onlineWindow = max(30, (int)($reloadSec * 6));
        $minUnix = time() - $onlineWindow;
        $minDate = date('Y-m-d H:i:s', $minUnix);

        // Anzahl online User
        // User zählt als online, wenn MINDESTENS EINER der Zeitstempel frisch ist
        $erg = $this->dbObj->sqlGet(
            "SELECT COUNT(etchat_onlineid) as user_count
             FROM {$this->_prefix}etchat_useronline 
             WHERE (
                 etchat_onlinetimestamp > :minUnix
                 OR etchat_last_ping > :minDate
             )
             AND (etchat_user_online_user_status_img IS NULL 
                  OR etchat_user_online_user_status_img <> 'status_invisible')",
            [':minUnix' => $minUnix, ':minDate' => $minDate]
        );

        $userCount = $erg[0]['user_count'] ?? 0;
        
        // ===== MODERNISIERT: Online-Anzahl AUS Json =====
        $onlineText = $this->getText('online_users_count', '{count} User sind online.');
        $userText = $this->getText('online_user', 'User');
        $onlineText = $this->replacePlaceholders($onlineText, ['count' => $userCount]);
        
        // Fallback falls Platzhalter nicht ersetzt wurde (z.B. bei alter Json)
        if (strpos($onlineText, '{count}') !== false) {
            $onlineText = $userCount . ' ' . $userText . ' sind online.';
        }
        
        echo $onlineText . "<br />";

        // Limit aus Session
        $limit_users = (int) ($_SESSION['etchat_'.$this->_prefix.'name_user_anz'] ?? 10);

        // Letzte Login User abrufen
        // Gleiche Logik: mindestens einer der Zeitstempel muss frisch sein
        $erg_user = $this->dbObj->sqlGet(
            "SELECT u.etchat_user_online_user_name, u.etchat_user_online_user_priv
             FROM {$this->_prefix}etchat_useronline u
             JOIN {$this->_prefix}etchat_user usr
               ON usr.etchat_username = u.etchat_user_online_user_name
             WHERE (
                 u.etchat_onlinetimestamp > :minUnix
                 OR u.etchat_last_ping > :minDate
             )
             AND (u.etchat_user_online_user_status_img IS NULL 
                  OR u.etchat_user_online_user_status_img <> 'status_invisible')
             ORDER BY usr.etchat_logintime DESC
             LIMIT $limit_users",
            [':minUnix' => $minUnix, ':minDate' => $minDate]
        );

        // User anzeigen Zahl, falls Config aktiviert
        if (($una[0]['etchat_config_name_user'] ?? 0) == 1 && is_array($erg_user) && count($erg_user) > 0) {
            // ===== MODERNISIERT: Letzte Logins AUS Json =====
            $lastLoginsText = $this->getText('online_last_logins', 'Letzte Login (Top {limit}):');
            $lastLoginsText = $this->replacePlaceholders($lastLoginsText, ['limit' => $limit_users]);
            
            if (strpos($lastLoginsText, '{limit}') !== false) {
                $lastLoginsText = 'Letzte Login (Top ' . $limit_users . '):';
            }
            
            echo $lastLoginsText . "<br />";

            $anzahl = count($erg_user);
            foreach ($erg_user as $index => $us) {
                echo htmlspecialchars($us['etchat_user_online_user_name'] ?? '');
                if ($index < $anzahl - 1) {
                    echo ",&nbsp;";
                }
            }
            echo "<br />";
        }

        $this->dbObj->close();
    }
}

// Initialisieren
// new Online();