<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class MenuIndex extends DbConectionMaker
{
    /**
     * Popup-Muster – MUSS identisch sein mit AdminCreateNewMenu.class.php und Menu.class.php
     * Capture-Groups:
     *   [1] = Ziel-URL
     *   [2] = "width=...,height=..."
     */
    private const POPUP_REGEX =
        '~^window\.open\(\x27(https?://[a-zA-Z0-9\-._\x7E:/?#\[\]@!$&\x27()*+,;=%]+)\x27,\x27\x27,\x27\s*((?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4})(?:\s*,\s*(?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4}))*)\s*\x27\); return false;$~';

    public function __construct()
    {
        parent::__construct();

        $feld = $this->dbObj->sqlGet(
            "SELECT id, menu, link_text, image_active, image, url, target, gewicht
             FROM {$this->_prefix}etchat_menu
             WHERE menu = 2
             ORDER BY gewicht"
        );

        if (!empty($feld)) {
            foreach ($feld as $datasets) {

                $rawUrl = (string)($datasets['url'] ?? '');
                $target = (string)($datasets['target'] ?? '_blank');
                $text   = (string)($datasets['link_text'] ?? '');
                $img    = (string)($datasets['image'] ?? '');

                $textEsc = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
                $imgEsc  = htmlspecialchars($img,  ENT_QUOTES, 'UTF-8');
                $idAttr  = $textEsc !== '' ? ' id="' . $textEsc . '"' : '';

                // -------------------------
                // Popup?
                // -------------------------
                $isPopup = ($rawUrl !== '') && preg_match(self::POPUP_REGEX, $rawUrl, $m);

                if ($isPopup) {
                    $safeUrl  = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
                    $features = htmlspecialchars($m[2], ENT_QUOTES, 'UTF-8');

                    $hrefAttr    = ' href="' . $safeUrl . '"';
                    // kein target bei Popup – onclick übernimmt
                    $targetAttr  = '';
                    $onclickAttr = ' onclick="window.open(\'' . $safeUrl . '\',\'\',\'' . $features . '\');return false;"';
                } else {
                    $safeUrl     = htmlspecialchars($rawUrl, ENT_QUOTES, 'UTF-8');
                    $safeTarget  = htmlspecialchars($target, ENT_QUOTES, 'UTF-8');

                    $hrefAttr    = ' href="' . $safeUrl . '"';
                    $targetAttr  = ' target="' . $safeTarget . '"';
                    $onclickAttr = '';
                }

                // -------------------------
                // Ausgabe
                // -------------------------
                if (($datasets['image_active'] ?? 0) == 1 && $imgEsc !== '') {
                    echo '<a class="start_text"' . $idAttr . $hrefAttr . $targetAttr . $onclickAttr . '>'
                       . '<img height="55" alt="' . $textEsc . '" title="' . $textEsc . '" src="img/menu/' . $imgEsc . '" />'
                       . '</a>&nbsp;&nbsp;&nbsp;';
                } else {
                    echo '<a class="start_text"' . $idAttr . $hrefAttr . $targetAttr . $onclickAttr . '>'
                       . $textEsc
                       . '</a>&nbsp;&nbsp;&nbsp;';
                }
            }
        }

        $this->dbObj->close();
    }
}

new MenuIndex();