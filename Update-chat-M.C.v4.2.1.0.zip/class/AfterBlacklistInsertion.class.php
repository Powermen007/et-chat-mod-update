<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class AfterBlacklistInsertion extends DbConectionMaker
{
    private ?object $lang = null;

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        $this->configTabData2Session();

        $this->dbObj->close();

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangJson();

        $this->initTemplate();
    }

    /**
     * Hilfsmethode für Sprachzugriff
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function initTemplate(): void
    {
        $templatePath = "styles/etchat_chat/blacklisted.tpl.html";

        if (file_exists($templatePath)) {
            include_once($templatePath);
        } else {
            error_log("Template not found: " . $templatePath);
        }
    }
}