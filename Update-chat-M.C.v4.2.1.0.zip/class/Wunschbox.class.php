<?php
/*
Wunschbox – Verwaltung der Wünsche im ET-Chat
gespielt-Werte: 0=Offen, 1=Gespielt, 2=Vorgemerkt, 3=Gespielter Vorab
*/

class Wunschbox extends DbConectionMaker
{
    private $user_id;
    private $user_priv;
    private $lang;
    private array $config = [];
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $this->user_id = (int)($_SESSION['etchat_'.$this->_prefix.'user_id'] ?? 0);
        $this->user_priv = $_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? 'gast';
		$this->lang = new LangJson('', 'wb_sendeplan.json');
        
        $this->loadConfig();
    }
    
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_wunschbox_config"
        );
    
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    
        // Sendeplan-Config (für Vorab-Wünsche)
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_sendeplan_config"
        );
    
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
    private function getConfig(string $key, string $default = ''): string
    {
        return $this->config[$key] ?? $default;
    }
    
    private function getText(string $key, string $default = ''): string
    {
        return $this->lang ? $this->lang->get($key, $default) : $default;
    }
    
    public function isAuthorized(): bool
    {
        return in_array($this->user_priv, ['admin', 'mod', 'co_admin']);
    }
    
    public function getWishes(int $sendungsId = null, string $filter = 'all', int $limit = 0, int $offset = 0): array
	{
		$params = [];
		$sql = "SELECT w.*, 
					u.etchat_username as username,
					m.etchat_username as moderator_name,
					s.etchat_username as sendung_moderator_name,
					sp.datum as sendung_datum,
					sp.zeit_von as sendung_zeit_von,
					sp.zeit_bis as sendung_zeit_bis
				FROM {$this->_prefix}etchat_wunschbox w
				LEFT JOIN {$this->_prefix}etchat_user u 
					ON w.erstellt_von = u.etchat_user_id
				LEFT JOIN {$this->_prefix}etchat_user m
					ON w.gespielt_von = m.etchat_user_id
				LEFT JOIN {$this->_prefix}etchat_sendeplan sp
					ON w.sendungs_id = sp.id
				LEFT JOIN {$this->_prefix}etchat_user s
					ON sp.moderator_id = s.etchat_user_id";
        
        $conditions = [];
        
        if ($sendungsId !== null && $sendungsId > 0) {
            $conditions[] = "w.sendungs_id = :sendungs_id";
            $params[':sendungs_id'] = $sendungsId;
        }
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            // Offene: gespielt = 0
            $conditions[] = "w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            // Gespielte: 1 oder 3 (gespielter Vorab)
            $conditions[] = "w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            // Vorgemerkt: 2
            $conditions[] = "w.gespielt = 2";
        }
        
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
        
        // 🔥 NEU: Sortierung abhängig vom Filter
		if ($filter === 'vorab') {
			// Vorgemerkt: Erst nach Sendungstermin, dann nach Wunsch-Zeitstempel (ältester zuerst)
			$sql .= " ORDER BY sp.datum ASC, sp.zeit_von ASC, w.created_at ASC";
		} else {
			// Andere Filter: Neueste Wünsche zuerst
			$sql .= " ORDER BY w.created_at DESC";
		}
        
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
        }
        
        return $this->dbObj->sqlGet($sql, $params) ?: [];
    }
    
    public function getWishesCount(int $sendungsId = null, string $filter = 'all'): int
    {
        $params = [];
        $sql = "SELECT COUNT(*) as total 
                FROM {$this->_prefix}etchat_wunschbox w";
        
        $conditions = [];
        
        if ($sendungsId !== null && $sendungsId > 0) {
            $conditions[] = "w.sendungs_id = :sendungs_id";
            $params[':sendungs_id'] = $sendungsId;
        }
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            $conditions[] = "w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            $conditions[] = "w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            $conditions[] = "w.gespielt = 2";
        }
        
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
        
        $result = $this->dbObj->sqlGet($sql, $params);
        return !empty($result) ? (int)$result[0]['total'] : 0;
    }

    /**
     * Wünsche für mehrere Sendungs-IDs holen
     */
    public function getWishesBySendungsIds(array $sendungsIds, string $filter = 'all', int $limit = 0, int $offset = 0): array
    {
        if (empty($sendungsIds)) {
            return [];
        }
        
        $params = [];
        $placeholders = [];
        foreach ($sendungsIds as $index => $id) {
            $key = ':sendungs_id_' . $index;
            $placeholders[] = $key;
            $params[$key] = $id;
        }
        
        $sql = "SELECT w.*, 
                    u.etchat_username as username,
                    m.etchat_username as moderator_name,
                    s.etchat_username as sendung_moderator_name,
                    sp.datum as sendung_datum,
                    sp.zeit_von as sendung_zeit_von,
                    sp.zeit_bis as sendung_zeit_bis
                FROM {$this->_prefix}etchat_wunschbox w
                LEFT JOIN {$this->_prefix}etchat_user u 
                    ON w.erstellt_von = u.etchat_user_id
                LEFT JOIN {$this->_prefix}etchat_user m
                    ON w.gespielt_von = m.etchat_user_id
                LEFT JOIN {$this->_prefix}etchat_sendeplan sp
                    ON w.sendungs_id = sp.id
                LEFT JOIN {$this->_prefix}etchat_user s
                    ON sp.moderator_id = s.etchat_user_id
                WHERE w.sendungs_id IN (" . implode(',', $placeholders) . ")";
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            $sql .= " AND w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            $sql .= " AND w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            $sql .= " AND w.gespielt = 2";
        }
        
        // 🔥 NEU: Sortierung abhängig vom Filter
		if ($filter === 'vorab') {
			// Vorgemerkt: Erst nach Sendungstermin, dann nach Wunsch-Zeitstempel (ältester zuerst)
			$sql .= " ORDER BY sp.datum ASC, sp.zeit_von ASC, w.created_at ASC";
		} else {
			// Andere Filter: Neueste Wünsche zuerst
			$sql .= " ORDER BY w.created_at DESC";
		}
        
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
        }
        
        return $this->dbObj->sqlGet($sql, $params) ?: [];
    }

    /**
     * Gesamtanzahl für mehrere Sendungs-IDs
     */
    public function getWishesCountBySendungsIds(array $sendungsIds, string $filter = 'all'): int
    {
        if (empty($sendungsIds)) {
            return 0;
        }
        
        $params = [];
        $placeholders = [];
        foreach ($sendungsIds as $index => $id) {
            $key = ':sendungs_id_' . $index;
            $placeholders[] = $key;
            $params[$key] = $id;
        }
        
        $sql = "SELECT COUNT(*) as total 
                FROM {$this->_prefix}etchat_wunschbox w
                WHERE w.sendungs_id IN (" . implode(',', $placeholders) . ")";
        
        // 🔥 Filter nach gespielt-Status
        if ($filter === 'all') {
            $sql .= " AND w.gespielt = 0";
        } elseif ($filter === 'gespielt') {
            $sql .= " AND w.gespielt IN (1, 3)";
        } elseif ($filter === 'vorab') {
            $sql .= " AND w.gespielt = 2";
        }
        
        $result = $this->dbObj->sqlGet($sql, $params);
        return !empty($result) ? (int)$result[0]['total'] : 0;
    }

    /**
     * Prüft ob es neue offene Wünsche gibt (für Badge)
     * Zählt NUR gespielt = 0 (frische Wünsche), NICHT Vorab (2)
     */
    public function hasNewOpenWishes(int $lastChecked = 0, ?int $sendungsId = null, array $sendungsIds = []): array
    {
        $params = [];
        $sql = "SELECT COUNT(*) as count, MAX(created_at) as latest 
                FROM {$this->_prefix}etchat_wunschbox 
                WHERE gespielt = 0";
        
        if ($sendungsId !== null && $sendungsId > 0) {
            $sql .= " AND sendungs_id = :sendungs_id";
            $params[':sendungs_id'] = $sendungsId;
        } elseif (!empty($sendungsIds)) {
            $placeholders = [];
            foreach ($sendungsIds as $index => $id) {
                $key = ':sid_' . $index;
                $placeholders[] = $key;
                $params[$key] = (int)$id;
            }
            $sql .= " AND sendungs_id IN (" . implode(',', $placeholders) . ")";
        }
        
        if ($lastChecked > 0) {
            $sql .= " AND created_at > FROM_UNIXTIME(:last_checked)";
            $params[':last_checked'] = $lastChecked;
        }
        
        $result = $this->dbObj->sqlGet($sql, $params);
        
        if (empty($result)) {
            return ['count' => 0, 'latest' => null];
        }
        
        return [
            'count' => (int)$result[0]['count'],
            'latest' => $result[0]['latest']
        ];
    }
    
    public function saveWish(array $data): array
    {
        if (empty($data['name']) || empty($data['interpret']) || empty($data['titel'])) {
            return ['success' => false, 'error' => $this->getText('wunschbox_fields_missing', 'Bitte Name, Interpret und Titel ausfüllen')];
        }
		
		// Sendungs-Prüfung wenn sendungs_id angegeben
		if (!empty($data['sendungs_id'])) {
			$sendungsId = (int)$data['sendungs_id'];
        
			$entry = $this->dbObj->sqlGet(
				"SELECT id, datum, zeit_von, zeit_bis, wunschbox_aktiv 
				FROM {$this->_prefix}etchat_sendeplan 
				WHERE id = :id",
				[':id' => $sendungsId]
			);
        
			if (empty($entry)) {
				return ['success' => false, 'error' => $this->getText('wunschbox_sendung_not_found', 'Sendung nicht gefunden.')];
			}
        
			$entry = $entry[0];
			$wbMode = (int)$entry['wunschbox_aktiv'];
        
			if ($wbMode === 0) {
				return ['success' => false, 'error' => $this->getText('wunschbox_wb_closed', 'Die Wunschbox ist für diese Sendung geschlossen.')];
			}
        
			// Zeitliche Prüfung
			$now = time();
			$zeitVon = $entry['zeit_von'];
			$zeitBis = $entry['zeit_bis'];
			if (strlen($zeitVon) === 5) $zeitVon .= ':00';
			if (strlen($zeitBis) === 5) $zeitBis .= ':00';
        
			$isOvernight = $zeitBis < $zeitVon;
			$startTs = strtotime($entry['datum'] . ' ' . $zeitVon);
			$endTs = $isOvernight 
				? strtotime($entry['datum'] . ' ' . $zeitBis . ' +1 day')
				: strtotime($entry['datum'] . ' ' . $zeitBis);
        
			$isLive = ($now >= $startTs && $now <= $endTs);
			$isPast = ($now > $endTs);
        
			if ($isPast) {
				return ['success' => false, 'error' => $this->getText('wunschbox_wb_past', 'Die Sendung ist bereits vorbei.')];
			}
        
			if (!$isLive) {
				if ($wbMode !== 2) {
					return ['success' => false, 'error' => $this->getText('wunschbox_wb_not_live', 'Die Wunschbox ist nur während der Sendung geöffnet.')];
				}
            
				$vorabEnabled = ($this->getConfig('wunschbox_vorab_enabled', '0')) == '1';
				if (!$vorabEnabled) {
					return ['success' => false, 'error' => $this->getText('wunschbox_vorab_disabled', 'Vorab-Wünsche sind deaktiviert.')];
				}
            
				$maxDays = (int)$this->getConfig('wunschbox_vorab_max_days', '30');
				if ($maxDays < 1) $maxDays = 30;
            
				$maxTs = $startTs - ($maxDays * 86400);
            
				if ($now < $maxTs) {
					return ['success' => false, 'error' => str_replace(
						'{days}',
						(string)$maxDays,
						$this->getText('wunschbox_vorab_too_early', 'Wünsche für diese Sendung sind erst {days} Tage vorher möglich.')
					)];
				}
			}
		}
        
        $user_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $user_ip = trim($ips[0]);
        }
        
        if ($this->isRateLimited($user_ip)) {
            $limitSeconds = (int)$this->getConfig('rate_limit_seconds', '60');
            return [
                'success' => false, 
                'error' => str_replace(
					'{seconds}',
					(string)$limitSeconds,
					$this->getText('wunschbox_rate_limited', "Du hast bereits einen Wunsch abgesendet. Bitte warte {$limitSeconds} Sekunden.")
				)
            ];
        }
        
        $gruss = $data['gruss'] ?? '';
        if (strlen($gruss) > 500) {
            $gruss = substr($gruss, 0, 500);
        }
        
        // 🔥 NEU: Vorab-Status bestimmen (2 = Vorab, 0 = Offen)
        $gespieltStatus = 0;
        if (!empty($data['sendungs_id'])) {
            $sendungsId = (int)$data['sendungs_id'];
            $entryCheck = $this->dbObj->sqlGet(
                "SELECT datum, zeit_von FROM {$this->_prefix}etchat_sendeplan WHERE id = :id",
                [':id' => $sendungsId]
            );
            if (!empty($entryCheck)) {
                $sendungsStartTs = strtotime($entryCheck[0]['datum'] . ' ' . $entryCheck[0]['zeit_von']);
                if (time() < $sendungsStartTs) {
                    $gespieltStatus = 2; // Vorab-Wunsch
                }
            }
        }
        
        $sql = "INSERT INTO {$this->_prefix}etchat_wunschbox
                    (sendungs_id, name, wohnort, interpret, titel, gruss, erstellt_von, user_ip, gespielt)
                VALUES
                    (:sendungs_id, :name, :wohnort, :interpret, :titel, :gruss, :erstellt_von, :user_ip, :gespielt)";
        
        $params = [
            ':sendungs_id' => !empty($data['sendungs_id']) ? (int)$data['sendungs_id'] : null,
            ':name' => substr($data['name'], 0, 100),
            ':wohnort' => substr($data['wohnort'] ?? '', 0, 100),
            ':interpret' => substr($data['interpret'], 0, 100),
            ':titel' => substr($data['titel'], 0, 100),
            ':gruss' => $gruss,
            ':erstellt_von' => $this->user_id,
            ':user_ip' => $user_ip,
            ':gespielt' => $gespieltStatus
        ];
        
        $newId = $this->dbObj->sqlSet($sql, $params);
        
        if ($newId === false) {
            return ['success' => false, 'error' => $this->getText('wunschbox_db_error', 'Fehler beim Speichern in der Datenbank.')];
        }
        
        return ['success' => ($newId > 0), 'id' => $newId];
    }
    
    public function deleteWish(int $id): array
    {
        if (!$this->isAuthorized()) {
            return ['success' => false, 'error' => $this->getText('wunschbox_no_permission', 'Keine Berechtigung')];
        }
        
        $success = $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_wunschbox WHERE id = :id",
            [':id' => $id]
        );
        
        return ['success' => $success];
    }
    
    public function isIpBanned(string $ip): bool
    {
        $result = $this->dbObj->sqlGet(
            "SELECT id FROM {$this->_prefix}etchat_wunschbox_ip_ban 
             WHERE ip_address = :ip AND ban_until > NOW()",
            [':ip' => $ip]
        );
        return !empty($result);
    }
    
    public function isRateLimited(string $ip): bool
    {
        $limitSeconds = (int)$this->getConfig('rate_limit_seconds', '60');
        
        $result = $this->dbObj->sqlGet(
            "SELECT COUNT(*) as count 
             FROM {$this->_prefix}etchat_wunschbox 
             WHERE user_ip = :ip 
             AND created_at > DATE_SUB(NOW(), INTERVAL :limit SECOND)",
            [
                ':ip' => $ip,
                ':limit' => $limitSeconds
            ]
        );
        
        return !empty($result) && (int)$result[0]['count'] > 0;
    }
	
public function maybeAutoCleanup(): void
{
    $enabled = (int)$this->getConfig('auto_delete_enabled', '0');
    if ($enabled !== 1) {
        return;
    }
    
    $days = (int)$this->getConfig('auto_delete_after_days', '30');
    if ($days < 1) $days = 1;
    
    // 🔥 NEU: Vorlaufzeit für Vorgemerkte
    $vorabMaxDays = (int)$this->getConfig('wunschbox_vorab_max_days', '14');
    if ($vorabMaxDays < 0) $vorabMaxDays = 0;
    
    // Vorgemerkte: 30 + 14 = 44 Tage
    $daysVorab = $days + $vorabMaxDays;
    
    $cacheFile = __DIR__ . '/../cache/wunschbox_cleanup.txt';
    
    if (file_exists($cacheFile)) {
        $lastRun = filemtime($cacheFile);
        if ((time() - $lastRun) < 86400) {
            return;
        }
    }
    
    // 1. Gespielte löschen (nach gespielt_am)
    $countPlayed = $this->dbObj->sqlGet(
        "SELECT COUNT(*) as count 
         FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt IN (1, 3)
         AND gespielt_am < DATE_SUB(NOW(), INTERVAL :days DAY)",
        [':days' => $days]
    );
    $deletedPlayed = !empty($countPlayed) ? (int)$countPlayed[0]['count'] : 0;
    
    $this->dbObj->sqlSet(
        "DELETE FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt IN (1, 3)
         AND gespielt_am < DATE_SUB(NOW(), INTERVAL :days DAY)",
        [':days' => $days]
    );
    
    // 2. Offene ungespielte löschen (nach created_at)
    $countOpen = $this->dbObj->sqlGet(
        "SELECT COUNT(*) as count 
         FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 0
         AND created_at < DATE_SUB(NOW(), INTERVAL :days DAY)",
        [':days' => $days]
    );
    $deletedOpen = !empty($countOpen) ? (int)$countOpen[0]['count'] : 0;
    
    $this->dbObj->sqlSet(
        "DELETE FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 0
         AND created_at < DATE_SUB(NOW(), INTERVAL :days DAY)",
        [':days' => $days]
    );
    
    // 3. Vorgemerkte ungespielte löschen (nach created_at + Vorlaufzeit)
    $countVorab = $this->dbObj->sqlGet(
        "SELECT COUNT(*) as count 
         FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 2
         AND created_at < DATE_SUB(NOW(), INTERVAL :daysVorab DAY)",
        [':days' => $daysVorab]
    );
    $deletedVorab = !empty($countVorab) ? (int)$countVorab[0]['count'] : 0;
    
    $this->dbObj->sqlSet(
        "DELETE FROM {$this->_prefix}etchat_wunschbox 
         WHERE gespielt = 2
         AND created_at < DATE_SUB(NOW(), INTERVAL :daysVorab DAY)",
        [':days' => $daysVorab]
    );
    
    if (!is_dir(__DIR__ . '/../cache')) {
        mkdir(__DIR__ . '/../cache', 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $total = $deletedPlayed + $deletedOpen + $deletedVorab;
    $logEntry = "{$timestamp} - Gelöscht: {$total} gesamt ({$deletedPlayed} gespielt >{$days}T, {$deletedOpen} offen >{$days}T, {$deletedVorab} vorgemerkt >{$daysVorab}T)\n";
    file_put_contents($cacheFile, $logEntry);
}
}