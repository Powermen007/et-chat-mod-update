<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class LastMessageId extends DbConectionMaker
{
    private int $roomId = 1;
    
    public function __construct($roomId = 1)
    {
        parent::__construct();
        $this->roomId = (int)$roomId;
    }
    
    public function getLastMessageId(): string
    {
        $result = $this->dbObj->sqlGet(
            "SELECT MAX(etchat_id) as last_id 
             FROM {$this->_prefix}etchat_messages 
             WHERE etchat_fid_room = ?",
            [$this->roomId]
        );
        
        if (is_array($result) && !empty($result) && isset($result[0]['last_id'])) {
            return (string)$result[0]['last_id'];
        }
        return '0';
    }
    
    public function render(): void
    {
        header('Content-Type: text/plain');
        header('Cache-Control: no-cache, must-revalidate');
        echo $this->getLastMessageId();
    }
}

// NUR AUSFÜHREN WENN DIREKT AUFGERUFEN
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    $roomId = isset($_GET['room']) ? (int)$_GET['room'] : 1;
    $lastMessageId = new LastMessageId($roomId);
    $lastMessageId->render();
}
?>