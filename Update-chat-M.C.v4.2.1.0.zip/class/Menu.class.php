<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class Menu extends DbConectionMaker
{
    /**
     * Popup-Muster – MUSS identisch sein mit AdminCreateNewMenu.class.php
     * Capture-Groups:
     *   [1] = Ziel-URL
     *   [2] = "width=...,height=..."
     */
	 

    private const POPUP_REGEX =
        '~^window\.open\(\x27(https?://[a-zA-Z0-9\-._\x7E:/?#\[\]@!$&\x27()*+,;=%]+)\x27,\x27\x27,\x27\s*((?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4})(?:\s*,\s*(?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4}))*)\s*\x27\); return false;$~';
		

    public function __construct()
    {
        parent::__construct();
        $this->renderMenu();
    }

    private function renderMenu(): void
    {
        $sql = "SELECT id, menu, link_text, image_active, image, url, target, gewicht 
                FROM {$this->_prefix}etchat_menu 
                WHERE menu = 1 
                ORDER BY gewicht";

        $rows = $this->dbObj->sqlGet($sql);
        $this->dbObj->close();

        if (!is_array($rows) || empty($rows)) {
            return;
        }

        foreach ($rows as $row) {

            $linkText    = htmlspecialchars((string)$row['link_text'], ENT_QUOTES, 'UTF-8');
            $imageActive = (int)$row['image_active'];
            $image       = htmlspecialchars((string)$row['image'], ENT_QUOTES, 'UTF-8');
            $rawUrl      = (string)$row['url'];
            $rawTarget   = (string)$row['target'];
			
            // -------------------------
            // Inhalt (Bild oder Text)
            // -------------------------
            if ($imageActive === 1 && $image !== '') {
                $inner = '<img src="img/menu/' . $image . '" height="40" alt="' . $linkText . '" title="' . $linkText . '">';
            } else {
                $inner = '<span class="menu_text">' . $linkText . '</span>';
            }

            // -------------------------
            // Popup?
            // -------------------------
            if ($rawUrl !== '' && preg_match(self::POPUP_REGEX, $rawUrl, $m)) {

                $safeUrl = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
                $wh      = $m[2]; // width=\d{1,4},height=\d{1,4} → sicher

                echo '<a href="' . $safeUrl . '" class="img_home" '
                   . 'onclick="window.open(\'' . $safeUrl . '\',\'\',\'' . $wh . '\');return false;" '
                   . 'rel="noopener noreferrer">'
                   . $inner
                   . '</a>&nbsp;';

                continue;
            }

            // -------------------------
            // Normale URL
            // -------------------------
            $safeUrl = htmlspecialchars($rawUrl, ENT_QUOTES, 'UTF-8');

            $allowedTargets = ['', '_blank', '_self', '_parent', '_top'];
            $target = in_array($rawTarget, $allowedTargets, true) ? $rawTarget : '';

            $targetAttr = $target !== '' ? ' target="' . $target . '"' : '';
            $relAttr    = $target === '_blank' ? ' rel="noopener noreferrer"' : '';

            echo '<a href="' . $safeUrl . '" class="img_home"' . $targetAttr . $relAttr . '>'
               . $inner
               . '</a>&nbsp;';
        }
    }
}

new Menu();