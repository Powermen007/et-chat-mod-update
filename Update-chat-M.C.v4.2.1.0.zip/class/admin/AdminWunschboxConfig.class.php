<?php
declare(strict_types=1);

/**
 * AdminWunschboxConfig – Verwaltung der Wunschbox-Einstellungen
 * Nur für Admin und Co-Admin sichtbar
 */

class AdminWunschboxConfig extends DbConectionMaker
{
    private string $csrfToken = '';
    private object $lang;
    private string $userRole = '';
    private array $config = [];
    private string $message = '';
    private bool $saved = false;
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        
        $this->lang = new LangJson('', 'wb_sendeplan_admin.json');
        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
        
        // 🔥 NUR Admin und Co-Admin
        $allowedRoles = ['admin', 'co_admin'];
        if (!in_array($this->userRole, $allowedRoles, true)) {
            header('Location: ./');
            exit;
        }
        
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
        
        $this->loadConfig();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        } else {
            $this->showConfig();
        }
    }
    
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_wunschbox_config"
        );
        
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
private function handlePost(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($this->csrfToken, $token)) {
        http_response_code(403);
        exit($this->lang->get('admin_kontakt_error_csrf', 'Ungültiger CSRF Token'));
    }
    
    // 🔥 NEU: Alle Config-Keys (inkl. Auto-Delete)
    $configs = [
        'mod_can_delete',
        'mod_can_see_all',
        'rate_limit_seconds',
        'admin_refresh_seconds',
        'auto_delete_enabled',
        'auto_delete_after_days',
		'wunschbox_cleanup_hours'
    ];
    
    foreach ($configs as $key) {
        $value = $_POST[$key] ?? '';
        
        // Bei Checkboxen
        if ($key === 'auto_delete_enabled') {
            $value = isset($_POST[$key]) ? '1' : '0';
        }
        
        // Bei Zahlen
        if ($key === 'rate_limit_seconds' || $key === 'admin_refresh_seconds') {
            $value = (int)$value;
            if ($value < 5) $value = 5;
            if ($value > 3600) $value = 3600;
        }
        
        // 🔥 NEU: Für auto_delete_after_days
        if ($key === 'auto_delete_after_days') {
            $value = (int)$value;
            if ($value < 1) $value = 1;
            if ($value > 365) $value = 365;
        }
		
		// 🔥 NEU: wunschbox_cleanup_hours
		if ($key === 'wunschbox_cleanup_hours') {
			$value = (int)$value;
			if ($value < 1) $value = 1;
			if ($value > 24) $value = 24;
		}
        
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_wunschbox_config 
             SET config_value = :value 
             WHERE config_key = :key",
            [':value' => (string)$value, ':key' => $key]
        );
    }
    
    $this->saved = true;
    $this->message = $this->lang->get('admin_wunschbox_config_saved', 'Einstellungen wurden erfolgreich gespeichert!');
    $this->loadConfig();
    $this->showConfig();
}
    
    private function showConfig(): void
    {
        $config = $this->config;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;
        $userRole = $this->userRole;
        $saved = $this->saved;
        $message = $this->message;
        
        include "styles/admin_tpl/indexWunschboxConfig.tpl.html";
    }
}