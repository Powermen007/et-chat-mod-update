<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminBadWords extends DbConectionMaker
{
    private $message = '';
    private $wordsFile = 'cache/bad_words.json';  // ✅ Jetzt JSON!
    
    public function __construct()
    {
        parent::__construct();

        if (session_id() == '') {
            session_start();
        }
		
        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');

        $lang = new LangJson();

        if ($_SESSION['etchat_' . $this->_prefix . 'user_priv'] != "admin") {
			echo $lang->get('admin_access_denied', 'Zugriff verweigert.');
			return false;
		}
		
        // AJAX Request für GET (Wörter laden)
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                header('Content-Type: application/json');
                $words = $this->loadWords();
                echo json_encode(['words' => $words]);
                exit;
            }
        }
        
        if (isset($_POST['save_word'])) {
            $this->saveWord($_POST);
            exit;
        }
        
        if (isset($_POST['delete_word'])) {
            $this->deleteWord($_POST['delete_word']);
            exit;
        }
        
        if (isset($_POST['add_word'])) {
            $this->addWord($_POST);
            exit;
        }

        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
        $chat_url = $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
        $chat_url = rtrim($chat_url, '/\\') . '/';

        $this->initTemplate($lang, $chat_url);
    }
    
    /**
     * Lädt die Bad Words aus der JSON-Datei
     */
    private function loadWords()
    {
        $words = [];
        if (!file_exists($this->wordsFile)) {
            return $words;
        }
        
        $content = file_get_contents($this->wordsFile);
        $data = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE || !isset($data['words'])) {
            return $words;
        }
        
        return $data['words'];
    }
    
    /**
     * Speichert ein Wort (neu oder bearbeitet)
     */
    private function saveWord($postData)
    {
        $oldWord = $postData['old_word'] ?? '';
        $newWord = trim($postData['word_in'] ?? '');
        $newOut = trim($postData['word_out'] ?? '');
        $excepts = explode("\n", trim($postData['excepts'] ?? ''));
        $excepts = array_map('trim', $excepts);
        $excepts = array_filter($excepts);
        
        if (empty($newWord) || empty($newOut)) {
            echo json_encode(['success' => false, 'error' => 'Wort und Ersetzung sind Pflichtfelder']);
            return;
        }
        
        // JSON laden
        $data = ['words' => []];
        if (file_exists($this->wordsFile)) {
            $content = file_get_contents($this->wordsFile);
            $data = json_decode($content, true);
            if (json_last_error() !== JSON_ERROR_NONE || !isset($data['words'])) {
                $data = ['words' => []];
            }
        }
        
        // Altes Wort entfernen
        if ($oldWord && $oldWord !== $newWord) {
            foreach ($data['words'] as $index => $word) {
                if ($word['in'] === $oldWord) {
                    unset($data['words'][$index]);
                }
            }
            $data['words'] = array_values($data['words']);
        }
        
        // Existiert das neue Wort bereits?
        $found = false;
        foreach ($data['words'] as &$word) {
            if ($word['in'] === $newWord) {
                $word['out'] = $newOut;
                $word['except'] = $excepts;
                $found = true;
                break;
            }
        }
        
        // Neues Wort hinzufügen
        if (!$found) {
            $data['words'][] = [
                'in' => $newWord,
                'out' => $newOut,
                'except' => $excepts
            ];
        }
        
        // JSON speichern
        file_put_contents($this->wordsFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        
        // Session-Cache leeren
        unset($_SESSION['etchat_' . $this->_prefix . '_badwords']);
        
        echo json_encode(['success' => true]);
    }
    
    /**
     * Löscht ein Wort
     */
    private function deleteWord($wordIn)
    {
        if (empty($wordIn)) {
            echo json_encode(['success' => false, 'error' => 'Kein Wort zum Löschen']);
            return;
        }
        
        if (!file_exists($this->wordsFile)) {
            echo json_encode(['success' => false, 'error' => 'JSON-Datei nicht gefunden']);
            return;
        }
        
        // JSON laden
        $content = file_get_contents($this->wordsFile);
        $data = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE || !isset($data['words'])) {
            echo json_encode(['success' => false, 'error' => 'Ungültige JSON-Datei']);
            return;
        }
        
        // Wort suchen und löschen
        $found = false;
        foreach ($data['words'] as $index => $word) {
            if ($word['in'] === $wordIn) {
                unset($data['words'][$index]);
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            echo json_encode(['success' => false, 'error' => 'Wort nicht gefunden']);
            return;
        }
        
        $data['words'] = array_values($data['words']);
        
        // JSON speichern
        file_put_contents($this->wordsFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        
        // Session-Cache leeren
        unset($_SESSION['etchat_' . $this->_prefix . '_badwords']);
        
        echo json_encode(['success' => true]);
    }
    
    private function addWord($postData)
    {
        $this->saveWord($postData);
    }

    private function initTemplate($lang, $chat_url)
    {
        $message = $this->message;
        include_once("styles/admin_tpl/indexBadWords.tpl.html");
    }
}
?>