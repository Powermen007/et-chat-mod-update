<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditMenu extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $menuData = [];

    public function __construct()
    {
        parent::__construct();

        // Session sicher starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // NEU: Sprache laden - Admin Json
        $lang = new LangJson();

        // Rechte prüfen (nur admin)
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($role, ['admin'], true)) {
            echo $lang->get('admin_access_denied', 'Zugriff verweigert');
            return;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // GET + POST kompatibel
        $data = $_GET + $_POST;

        // ID absichern
        $id = (int)($data['id'] ?? 0);
        if ($id <= 0) {
            echo $lang->get('admin_editmenu_error_invalid_id', 'Ungültige ID.');
            return;
        }

        // Menü-Daten laden
        $this->loadMenuData($id);

        if (empty($this->menuData)) {
            echo $lang->get('admin_editmenu_error_not_found', 'Eintrag nicht gefunden.');
            return;
        }

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    /**
     * Lädt die Menü-Daten aus der Datenbank
     */
    private function loadMenuData(int $id): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id, menu, link_text, image_active, image, url, target, gewicht
             FROM {$this->_prefix}etchat_menu
             WHERE id = :id"
        );
        $stmt->execute([':id' => $id]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->menuData = is_array($result) ? $result : [];
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate(object $lang): void
    {
        // Template erwartet $feld[0] mit den Daten (numerisches Array von Arrays)
        $feld = [$this->menuData];
        $csrfToken = $this->csrfToken;
        
        include __DIR__ . "/../../styles/admin_tpl/editMenu.tpl.html";
    }
}