<?php
declare(strict_types=1);

/**
 * AdminSendeplanVorlagen – Verwaltung der Sendungsvorlagen
 * Nur für Admin sichtbar
 */

class AdminSendeplanVorlagen extends DbConectionMaker
{
    private string $csrfToken = '';
    private object $lang;
    private string $userRole = '';
    private array $vorlagen = [];
    private string $message = '';
    private bool $saved = false;
    private bool $deleted = false;
    private string $uploadDir = 'img/sendeplan_vorlagen/';
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        
        $this->lang = new LangJson('', 'wb_sendeplan_admin.json');
        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
        
        // 🔥 NUR Admin (KEIN Co-Admin!)
        if ($this->userRole !== 'admin') {
            header('Location: ./');
            exit;
        }
        
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
        
        // Upload-Ordner erstellen, falls nicht vorhanden
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        } else {
            $this->showList();
        }
    }
    
    private function handlePost(): void
    {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            exit($this->lang->get('admin_updatevorlagen_error_csrf', 'Ungültiger CSRF Token'));
        }
        
        // 🔥 Löschen
        if (!empty($_POST['delete_vorlage'])) {
            $this->deleteVorlage((int)array_key_first($_POST['delete_vorlage']));
            return;
        }
        
        // 🔥 Speichern (neu oder bearbeiten)
        if (isset($_POST['save_vorlage'])) {
            $this->saveVorlage($_POST);
        }
    }
    
    private function saveVorlage(array $post): void
    {
        $id = (int)($post['id'] ?? 0);
        $name = trim((string)($post['name'] ?? ''));
        $sortierung = (int)($post['sortierung'] ?? 0);
        $altesBild = (string)($post['altes_bild'] ?? '');
        
        if (empty($name)) {
            $this->message = $this->lang->get('admin_sendeplan_vorlagen_name_empty', 'Bitte einen Namen eingeben!');
            $this->showList();
            return;
        }
        
        // 🔥 Bild-Upload verarbeiten
        $bildDatei = $altesBild; // Standard: altes Bild behalten
        if (!empty($_FILES['bild']['name'])) {
            $uploadResult = $this->handleUpload($_FILES['bild'], $altesBild);
            if ($uploadResult['success']) {
                $bildDatei = $uploadResult['filename'];
            } else {
                $this->message = $this->lang->get('admin_sendeplan_vorlagen_upload_error', 'Fehler beim Upload: ') . $uploadResult['error'];
                $this->showList();
                return;
            }
        }
        
        if ($id > 0) {
            // UPDATE
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_sendeplan_vorlagen 
                 SET name = :name, bild = :bild, sortierung = :sortierung 
                 WHERE id = :id",
                [
                    ':name' => $name,
                    ':bild' => $bildDatei,
                    ':sortierung' => $sortierung,
                    ':id' => $id
                ]
            );
            $this->message = $this->lang->get('admin_sendeplan_vorlagen_saved_update', 'Vorlage wurde aktualisiert!');
        } else {
            // INSERT
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_sendeplan_vorlagen 
                 (name, bild, sortierung) 
                 VALUES (:name, :bild, :sortierung)",
                [
                    ':name' => $name,
                    ':bild' => $bildDatei,
                    ':sortierung' => $sortierung
                ]
            );
            $this->message = $this->lang->get('admin_sendeplan_vorlagen_saved_create', 'Vorlage wurde erstellt!');
        }
        
        $this->saved = true;
        $this->showList();
    }
    
    private function handleUpload(array $file, string $altesBild = ''): array
    {
        // Prüfe auf Upload-Fehler
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'error' => $this->lang->get('admin_sendeplan_vorlagen_upload_error_code', 'Upload-Fehler (Code: ') . $file['error'] . ')'];
        }
        
        // Prüfe Dateityp
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, $allowedTypes, true)) {
            return ['success' => false, 'error' => $this->lang->get('admin_sendeplan_vorlagen_upload_invalid_type', 'Nur JPG, PNG, GIF und WebP erlaubt!')];
        }
        
        // Prüfe Dateigröße (max 5 MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            return ['success' => false, 'error' => $this->lang->get('admin_sendeplan_vorlagen_upload_too_large', 'Datei zu groß (max 5 MB)!')];
        }
        
        // Generiere sicheren Dateinamen
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $neuerName = 'vorlage_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
        $zielPfad = $this->uploadDir . $neuerName;
        
        // Verschiebe Datei
        if (!move_uploaded_file($file['tmp_name'], $zielPfad)) {
            return ['success' => false, 'error' => $this->lang->get('admin_sendeplan_vorlagen_upload_save_failed', 'Datei konnte nicht gespeichert werden!')];
        }
        
        // 🔥 Altes Bild löschen (falls vorhanden)
        if (!empty($altesBild) && file_exists($this->uploadDir . $altesBild)) {
            unlink($this->uploadDir . $altesBild);
        }
        
        return ['success' => true, 'filename' => $neuerName];
    }
    
    private function deleteVorlage(int $id): void
    {
        // Vorlage laden (um Bild-Dateinamen zu bekommen)
        $result = $this->dbObj->sqlGet(
            "SELECT bild FROM {$this->_prefix}etchat_sendeplan_vorlagen WHERE id = :id",
            [':id' => $id]
        );
        
        if (!empty($result[0]['bild'])) {
            $bildPfad = $this->uploadDir . $result[0]['bild'];
            if (file_exists($bildPfad)) {
                unlink($bildPfad);
            }
        }
        
        // Vorlage löschen
        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_sendeplan_vorlagen WHERE id = :id",
            [':id' => $id]
        );
        
        $this->deleted = true;
        $this->message = $this->lang->get('admin_sendeplan_vorlagen_deleted', 'Vorlage wurde gelöscht!');
        $this->showList();
    }
    
    private function showList(): void
    {
        // Alle Vorlagen laden
        $this->vorlagen = $this->dbObj->sqlGet(
            "SELECT * FROM {$this->_prefix}etchat_sendeplan_vorlagen 
             ORDER BY sortierung ASC, name ASC"
        ) ?: [];
        
        // 🔥 NEU: Reihenfolge-Speichern-Erkennung
        if (isset($_GET['saved']) && $_GET['saved'] === '1') {
            $this->saved = true;
            if (empty($this->message)) {
                $this->message = $this->lang->get('admin_sendeplan_vorlagen_order_saved', 'Reihenfolge wurde gespeichert!');
            }
        }
        
        $vorlagen = $this->vorlagen;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;
        $userRole = $this->userRole;
        $saved = $this->saved;
        $deleted = $this->deleted;
        $message = $this->message;
        $uploadDir = $this->uploadDir; // 🔥 NEU
        
        include "styles/admin_tpl/indexSendeplanVorlagen.tpl.html";
    }
}