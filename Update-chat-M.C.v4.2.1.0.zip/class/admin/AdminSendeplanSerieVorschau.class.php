<?php
declare(strict_types=1);

/**
 * AdminSendeplanSerieVorschau – AJAX-Endpoint für die Serien-Vorschau
 *
 * Liefert JSON zurück. KEIN Template, KEIN admin_master_template.
 * Wird automatisch vom Router gefunden über ?AdminSendeplanSerieVorschau
 */

class AdminSendeplanSerieVorschau extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        // JSON-Header
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        
        // Berechtigung prüfen
		$lang = new LangJson('', 'wb_sendeplan_admin.json');
		$userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
		if (!in_array($userRole, ['admin', 'mod', 'co_admin'], true)) {
			http_response_code(403);
			echo json_encode(['success' => false, 'error' => $lang->get('admin_sendeplan_serie_vorschau_no_permission', 'Keine Berechtigung')]);
			exit;
		}
        
        // Sendeplan-Manager
        $manager = new Sendeplan();
        
        // Eingaben
        $startDatum = $_POST['datum'] ?? $_GET['datum'] ?? date('Y-m-d');
        
        // 🔥 NEU: Optionales Serien-Startdatum überschreibt das normale Datum
        $serienStartDatum = trim((string)($_POST['serien_start_datum'] ?? ''));
        if ($serienStartDatum !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $serienStartDatum)) {
            $startDatum = $serienStartDatum;
        }
        
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDatum)) {
            $startDatum = date('Y-m-d');
        }
        
        // Zeit normalisieren
        $zeit_von = $_POST['zeit_von'] ?? '20:00';
        $zeit_bis = $_POST['zeit_bis'] ?? '22:00';
        if (strlen($zeit_von) === 5) $zeit_von .= ':00';
        if (strlen($zeit_bis) === 5) $zeit_bis .= ':00';
        
        // Wochentage normalisieren
        $wochentage = $_POST['wochentage'] ?? [];
        if (!is_array($wochentage)) {
            $wochentage = [$wochentage];
        }
        $wochentage = array_map('intval', $wochentage);
        
        $regel = [
            'wiederholung'      => $_POST['wiederholung'] ?? 'taeglich',
            'wochentage'        => $wochentage,
            'wochen_intervall'  => (int)($_POST['wochen_intervall'] ?? 1),
            'intervall'         => (int)($_POST['intervall'] ?? 1),
            'monat_modus'       => $_POST['monat_modus'] ?? 'tag',
            'monat_tag'         => (int)($_POST['monat_tag'] ?? 1),
            'monat_intervall'   => (int)($_POST['monat_intervall'] ?? 1),  // 🔥 NEU
            'monat_position'    => (int)($_POST['monat_position'] ?? 1),
            'monat_wochentag'   => (int)($_POST['monat_wochentag'] ?? 1),
            'ende_typ'          => $_POST['ende_typ'] ?? 'anzahl',
            'ende_datum'        => $_POST['ende_datum'] ?? null,
            'ende_anzahl'       => (int)($_POST['ende_anzahl'] ?? 10),
        ];
        
        // Termine berechnen
        $termine = $manager->calculateSerieTermine($startDatum, $regel);
        
        // Vorschau-Liste mit Konfliktstatus
        $vorschau = [];
        foreach ($termine as $i => $datum) {
            $nummer = $i + 1;
            $check = $manager->checkOverlap($datum, $zeit_von, $zeit_bis, 0);
            
            $vorschau[] = [
                'nummer'         => $nummer,
                'datum'          => $datum,
                'datum_fmt'      => date('d.m.Y', strtotime($datum)),
                'wochentag'      => $manager->getWeekday($datum),
                'konflikt'       => !$check['success'],
                'konflikt_text'  => $check['success'] ? '' : ($check['message'] ?? ''),
            ];
        }
        
        echo json_encode([
            'success' => true,
            'total'   => count($termine),
            'termine' => $vorschau,
        ]);
        exit;
    }
}