<?php
declare(strict_types=1);

class AdminSpracheBearbeiten extends DbConectionMaker
{
    private string $csrfToken = '';
    private string $langFolder = 'Deutsch';
    private array $languageFolders = [];
    private array $categories = [];
    private array $allStrings = [];
    private array $jsKeys = []; // Cache für JS-Schlüssel

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $userRole = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        if ($userRole !== "admin") {
            echo "❌ Zugriff verweigert. Nur für Admins!";
            exit;
        }

        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        $this->langFolder = $_SESSION['etchat_' . $this->_prefix . 'lang_json_file'] ?? 'Deutsch';
        $this->languageFolders = $this->getLanguageFolders(__DIR__ . '/../../lang/');

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_lang'])) {
            $this->handleSave();
            exit;
        }

        $this->showEditor();
    }

    private function showEditor(): void
    {
        $langBase = __DIR__ . '/../../lang/';
        $fileType = $_GET['file_type'] ?? 'admin';
        $langFolder = $_GET['lang_folder'] ?? $this->langFolder;
        $selectedCategory = $_GET['category'] ?? '';
        $selectedFile = $_GET['json_file'] ?? '';
        
        if (!in_array($langFolder, $this->languageFolders, true)) {
            $langFolder = $this->langFolder;
        }
        $this->langFolder = $langFolder;
        
        $langCode = $this->getLangCode($langFolder);
        $jsonFiles = $this->findAllJsonFiles($langBase, $langFolder);
        
        if (empty($jsonFiles)) {
            echo "<h2>❌ Keine JSON-Datei gefunden!</h2>";
            echo "<p>Pfad: " . $langBase . $langFolder . "</p>";
            if (is_dir($langBase . $langFolder)) {
                $files = scandir($langBase . $langFolder);
                echo "<ul>";
                foreach ($files as $file) {
                    if ($file != '.' && $file != '..') {
                        echo "<li>" . $file . "</li>";
                    }
                }
                echo "</ul>";
            }
            exit;
        }
        
        if ($selectedFile === '' || !in_array($selectedFile, $jsonFiles)) {
            $selectedFile = $jsonFiles[0];
        }
        
$jsonPath = $langBase . $langFolder . '/' . $selectedFile;
    $this->parseJsonFile($jsonPath); // <- HIER werden jsKeys gefüllt
    $backupCount = $this->countBackups($jsonPath);
    $this->dbObj->close();

    $categoryNames = array_keys($this->categories);
    
    if ($selectedCategory === '' && !empty($categoryNames)) {
        $selectedCategory = $categoryNames[0];
    }
    
    if (!isset($this->categories[$selectedCategory]) && !empty($categoryNames)) {
        $selectedCategory = $categoryNames[0];
    }

    // ============================================================
    // STATISTIK NACH DEM PARSEN BERECHNEN
    // ============================================================
    $totalStrings = count($this->allStrings);
    
    // JS-Strings zählen (berücksichtigt nur die aktuelle Datei)
    $jsCount = 0;
    foreach ($this->allStrings as $key => $value) {
        if ($this->isJavaScriptString($key)) {
            $jsCount++;
        }
    }
    $htmlCount = $totalStrings - $jsCount;
    
    // Statistik für die AKTUELLE KATEGORIE
    $currentCategoryJsCount = 0;
    $currentCategoryTotal = 0;
    if (!empty($selectedCategory) && isset($this->categories[$selectedCategory])) {
        foreach ($this->categories[$selectedCategory] as $subName => $strings) {
            $currentCategoryTotal += count($strings);
            foreach ($strings as $key => $value) {
                if ($this->isJavaScriptString($key)) {
                    $currentCategoryJsCount++;
                }
            }
        }
    }
    $currentCategoryHtmlCount = $currentCategoryTotal - $currentCategoryJsCount;

    // ============================================================
    // AUSGABE
    // ============================================================
	echo '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>🌐 Sprache bearbeiten</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; margin: 0; }
        .container { max-width: 1400px; margin: 0 auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { color: #333; border-bottom: 2px solid #1a73e8; padding-bottom: 10px; margin-top: 0; }
        
        .filter-bar { display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end; background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 10px 0; }
        .filter-bar .field { flex: 1; min-width: 150px; }
        .filter-bar .field label { font-weight: bold; display: block; margin-bottom: 3px; font-size: 13px; }
        .filter-bar .field select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; background: #fff; }
        .filter-bar .actions button { padding: 8px 20px; background: #1a73e8; color: #fff; border: none; border-radius: 4px; cursor: pointer; }
        .filter-bar .actions button:hover { background: #1557b0; }
        
        .stats { display: flex; gap: 20px; flex-wrap: wrap; margin: 10px 0; padding: 10px 15px; background: #f8f9fa; border-radius: 4px; }
        .stats .stat { font-size: 13px; padding: 4px 0; }
        .stats .stat strong { color: #1a73e8; }
        
        .search-box { margin: 10px 0; }
        .search-box input { width: 100%; max-width: 300px; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; }
        .search-box input:focus { outline: none; border-color: #1a73e8; }
        
        .backup-info { background: #e8f0fe; padding: 10px 15px; border-radius: 4px; margin: 10px 0; color: #1a73e8; }
        
        .sub-category { background: #e8f0fe; padding: 15px; margin-top: 15px; border-radius: 4px; }
        .sub-category h4 { margin: 0 0 10px 0; color: #1a73e8; font-size: 15px; }
        
        .string-item { background: #fff; padding: 10px 12px; margin: 5px 0; border: 1px solid #e0e0e0; border-radius: 4px; }
        .string-item label { font-weight: bold; display: block; margin-bottom: 3px; font-size: 13px; }
        .string-item textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-family: monospace; font-size: 13px; resize: vertical; min-height: 40px; }
        .string-item textarea:focus { outline: none; border-color: #1a73e8; }
        
        .string-item .js-warning { color: #d32f2f; display: block; margin-top: 4px; font-size: 12px; background: #ffebee; padding: 4px 8px; border-radius: 3px; border-left: 3px solid #d32f2f; }
        .string-item .html-hint { color: #2e7d32; display: block; margin-top: 4px; font-size: 12px; background: #e8f5e9; padding: 4px 8px; border-radius: 3px; border-left: 3px solid #2e7d32; }
        
        .string-item .key-badge { display: inline-block; padding: 1px 8px; border-radius: 3px; font-size: 10px; font-weight: bold; margin-left: 5px; }
        .key-badge.js { background: #d32f2f; color: #fff; }
        .key-badge.html { background: #2e7d32; color: #fff; }
        
        .js-highlight { background: #ffebee !important; border-left: 3px solid #d32f2f !important; }
        .html-highlight { background: #f1f8e9 !important; border-left: 3px solid #2e7d32 !important; }
        
        .save-btn { background: #1a73e8; color: #fff; padding: 12px 30px; border: none; border-radius: 4px; cursor: pointer; margin-top: 20px; font-size: 16px; }
        .save-btn:hover { background: #1557b0; }
        
        .error { background: #f8d7da; color: #721c24; padding: 10px 15px; border-radius: 4px; margin: 10px 0; border-left: 4px solid #d32f2f; }
        .success { background: #d4edda; color: #155724; padding: 10px 15px; border-radius: 4px; margin: 10px 0; border-left: 4px solid #2e7d32; }
        
        @media (max-width: 768px) {
            .filter-bar .field { flex: 1 1 100%; }
            .container { padding: 10px; }
            .stats { gap: 10px; }
            .stats .stat { font-size: 12px; }
        }
    </style>
    </head>
    <body>
    <div class="container">';

    // Session-Meldungen
    if (isset($_SESSION['lang_save_success'])) {
        echo '<div class="success">✅ ' . htmlspecialchars($_SESSION['lang_save_success']) . '</div>';
        unset($_SESSION['lang_save_success']);
    }
    if (isset($_SESSION['lang_save_error'])) {
        echo '<div class="error">❌ ' . htmlspecialchars($_SESSION['lang_save_error']) . '</div>';
        unset($_SESSION['lang_save_error']);
    }

    echo '<h2>🌐 Sprache bearbeiten</h2>';

    // ============================================================
    // STATISTIK ANZEIGEN - MIT AKTUELLER KATEGORIE
    // ============================================================
    echo '<div class="stats">';
    
    // Gesamtstatistik
    echo '<span class="stat">📊 <strong>' . $totalStrings . '</strong> Einträge gesamt</span>';
    echo '<span class="stat">🟥 <strong>' . $jsCount . '</strong> JavaScript-Texte</span>';
    echo '<span class="stat">🟩 <strong>' . $htmlCount . '</strong> HTML-Texte</span>';
    echo '<span class="stat">📂 <strong>' . count($this->categories) . '</strong> Kategorien</span>';
    
    // Aktuelle Kategorie Statistik (nur wenn eine Kategorie ausgewählt ist)
    if (!empty($selectedCategory) && isset($this->categories[$selectedCategory])) {
        $jsPercent = $currentCategoryTotal > 0 ? round(($currentCategoryJsCount / $currentCategoryTotal) * 100) : 0;
        echo '<span class="stat" style="border-left:2px solid #ddd;padding-left:15px;">';
        echo '📌 <strong>' . htmlspecialchars($selectedCategory) . '</strong>: ';
        echo $currentCategoryTotal . ' Einträge, ';
        echo '🟥 ' . $currentCategoryJsCount . ' JS';
        if ($currentCategoryJsCount > 0) {
            echo ' <span style="color:#d32f2f;">(' . $jsPercent . '%)</span>';
        }
        echo '</span>';
    }
    
    echo '</div>';

        // ============================================================
        // FILTER-FORMULAR
        // ============================================================
        echo '<form method="get" class="filter-bar">';
        echo '<input type="hidden" name="AdminSpracheBearbeiten" value="1">';
        
        echo '<div class="field">
            <label>🌐 Sprache:</label>
            <select name="lang_folder">';
        foreach ($this->languageFolders as $folder) {
            $selected = ($folder === $langFolder) ? 'selected' : '';
            echo '<option value="' . htmlspecialchars($folder) . '" ' . $selected . '>' . htmlspecialchars($folder) . '</option>';
        }
        echo '  </select>
        </div>';
        
        echo '<div class="field">
            <label>📄 Datei:</label>
            <select name="json_file">';
        foreach ($jsonFiles as $file) {
            $selected = ($file === $selectedFile) ? 'selected' : '';
            echo '<option value="' . htmlspecialchars($file) . '" ' . $selected . '>' . htmlspecialchars($file) . '</option>';
        }
        echo '  </select>
        </div>';
        
        if (!empty($categoryNames)) {
            echo '<div class="field">
                <label>📂 Kategorie:</label>
                <select name="category">';
            foreach ($categoryNames as $catName) {
                $selected = ($catName === $selectedCategory) ? 'selected' : '';
                echo '<option value="' . htmlspecialchars($catName) . '" ' . $selected . '>' . htmlspecialchars($catName) . '</option>';
            }
            echo '  </select>
            </div>';
        }
        
        echo '<div class="actions">
            <button type="submit">🔄 Laden</button>
        </div>';
        echo '</form>';

        // Suchfeld
        echo '<div class="search-box">
            <input type="text" id="searchInput" placeholder="🔍 Schlüssel oder Wert suchen..." onkeyup="filterStrings(this.value)">
        </div>';

        echo '<div class="backup-info">💾 Backups: ' . $backupCount . ' Sicherungen vorhanden (die 3 neuesten bleiben erhalten)</div>';

        // ============================================================
        // EDITOR-FORMULAR
        // ============================================================
        echo '<form method="post" id="save-lang-form">';
        echo '<input type="hidden" name="csrf" value="' . htmlspecialchars($this->csrfToken) . '">';
        echo '<input type="hidden" name="lang_folder" value="' . htmlspecialchars($langFolder) . '">';
        echo '<input type="hidden" name="selected_file" value="' . htmlspecialchars($selectedFile) . '">';
        echo '<input type="hidden" name="selected_category" value="' . htmlspecialchars($selectedCategory) . '">';
        
        // Strings anzeigen
        if (!empty($selectedCategory) && isset($this->categories[$selectedCategory])) {
            $subCats = $this->categories[$selectedCategory];
            
            foreach ($subCats as $subName => $strings) {
                // JS-Strings in dieser Unterkategorie zählen
                $jsCountSub = 0;
                foreach ($strings as $key => $value) {
                    if ($this->isJavaScriptString($key)) {
                        $jsCountSub++;
                    }
                }
                
                echo '<div class="sub-category">';
                echo '<h4>' . htmlspecialchars($subName) . ' (' . count($strings) . ' Einträge' . ($jsCountSub > 0 ? ', 🟥 ' . $jsCountSub . ' JS' : '') . ')</h4>';
                
                foreach ($strings as $key => $value) {
                    $isJs = $this->isJavaScriptString($key);
                    $cssClass = $isJs ? 'js-highlight' : 'html-highlight';
                    $badge = $isJs ? '<span class="key-badge js">JS</span>' : '<span class="key-badge html">HTML</span>';
                    $warning = $isJs ? 
                        '<span class="js-warning">⚠️ Achtung: Dieser Text wird in <strong>JavaScript</strong> verwendet! Kein HTML wie &lt;br&gt; erlaubt! Nur reinen Text eingeben.</span>' : 
                        '<span class="html-hint">💡 HTML-Tags wie &lt;br&gt; oder &lt;b&gt; sind erlaubt. Für Zeilenumbruch &lt;br&gt; verwenden.</span>';
                    
                    echo '<div class="string-item ' . $cssClass . '" data-key="' . htmlspecialchars($key) . '">';
                    echo '<label>' . htmlspecialchars($key) . ' ' . $badge . ':</label>';
                    echo '<textarea name="lang_' . htmlspecialchars($key) . '" rows="2" data-key="' . htmlspecialchars($key) . '" data-is-js="' . ($isJs ? '1' : '0') . '">' . htmlspecialchars($value) . '</textarea>';
                    echo $warning;
                    echo '</div>';
                }
                
                echo '</div>';
            }
        } else {
            echo '<p>⚠️ Keine Einträge in dieser Kategorie.</p>';
        }

        echo '<button type="submit" name="save_lang" class="save-btn">💾 Alle Änderungen speichern</button>';
        echo '</form>';

        echo '<p style="margin-top: 20px; font-size: 12px; color: #666;">
            💡 Tipp: <strong>Strg + S</strong> zum Speichern | Nach dem Speichern <strong>Strg + F5</strong> im Chat drücken
        </p>';

        echo '</div>';

        // ============================================================
        // JAVASCRIPT FÜR SUCHE & FILTER
        // ============================================================
        echo '
        <script>
        function filterStrings(searchTerm) {
            searchTerm = searchTerm.toLowerCase();
            var items = document.querySelectorAll(".string-item");
            var visibleCount = 0;
            
            items.forEach(function(item) {
                var key = item.getAttribute("data-key") || "";
                var textarea = item.querySelector("textarea");
                var value = textarea ? textarea.value.toLowerCase() : "";
                
                if (key.toLowerCase().indexOf(searchTerm) !== -1 || value.indexOf(searchTerm) !== -1) {
                    item.style.display = "block";
                    visibleCount++;
                } else {
                    item.style.display = "none";
                }
            });
            
            // Zeige Anzahl an
            var stats = document.querySelector(".stats");
            if (stats) {
                var total = items.length;
                var info = stats.querySelector(".search-info");
                if (!info) {
                    info = document.createElement("span");
                    info.className = "stat search-info";
                    stats.appendChild(info);
                }
                info.innerHTML = "🔍 <strong>" + visibleCount + "</strong> von " + total + " sichtbar";
            }
        }
        
        // STRG+S zum Speichern
        document.addEventListener("keydown", function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === "s") {
                e.preventDefault();
                document.getElementById("save-lang-form").submit();
            }
        });
        
        // Änderungen markieren
        document.querySelectorAll(".string-item textarea").forEach(function(textarea) {
            textarea.addEventListener("change", function() {
                this.style.borderColor = "#ff9800";
                this.style.backgroundColor = "#fff8e1";
            });
        });
        </script>

        </body>
        </html>';
    }

    // ============================================================
    // JS-ERKENNUNG
    // ============================================================
    private function isJavaScriptString(string $key): bool
    {
        // Cache prüfen
        if (isset($this->jsKeys[$key])) {
            return $this->jsKeys[$key];
        }
        
        // 1. Bekannte JS-Schlüssel-Muster
        $jsPatterns = [
            '/^js_/',                    // js_*
            '/_js_/',                    // *_js_*
            '/_javascript_/',            // *_javascript_*
            '/^broadcast_js_/',          // broadcast_js_*
            '/^admin_broadcast_js_/',    // admin_broadcast_js_*
            '/_alert_/',                 // *_alert_*
            '/_confirm_/',               // *_confirm_*
            '/^dialog_js_/',             // dialog_js_*
            '/_loading_/',               // loading Texte
            '/_error_js_/',              // *_error_js_*
            '/_success_js_/',            // *_success_js_*
            '/^button_loading/',         // button_loading
            '/^button_logout/',          // button_logout
            '/^loading_/',               // loading_*
            '/^close_/',                 // close_* (wird in Dialogen verwendet)
            '/^warning_/',               // warning_* (wird in JS-Dialogen verwendet)
            '/^error_network/',          // error_network
            '/^error_connection/',       // error_connection
            '/^connection_lost/',        // connection_lost
            '/^ajax_/',                  // ajax_*
            '/^tabfocus_/',              // tabfocus_*
            '/^logout_countdown/',       // logout_countdown_*
        ];
        
        foreach ($jsPatterns as $pattern) {
            if (preg_match($pattern, $key)) {
                $this->jsKeys[$key] = true;
                return true;
            }
        }
        
        // 2. Dateien die JS enthalten
        $jsFiles = [
            'chat.js',
            'login.js',
            'admin.js',
            'register.js',
            'profile.js',
            'gallery.js',
            'smileys.js',
            'blacklist.js',
            'broadcast.js',
            'radio.js',
            'backup.js',
            'update.js',
            'css.js',
            'styler.js',
            'imgmanager.js',
            'bot.js',
            'kontakt.js',
            'bewerbung.js',
            'hallo.js',
            'menus.js',
            'boxes.js',
            'texts.js',
            'rooms.js',
            'users.js',
            'smilies.js',
            'gallery.js',
            'history.js',
            'upload.js',
            'avatar.js',
            'password.js',
            'redirect.js',
            'toplist.js',
            'team.js',
            'wunschbox.js',
            'sendeplan.js',
            'playlist.js',
            'filesend.js',
        ];
        
        foreach ($jsFiles as $jsFile) {
            if (strpos($key, $jsFile) !== false) {
                $this->jsKeys[$key] = true;
                return true;
            }
        }
        
        // 3. Bestimmte Schlüssel die in JS verwendet werden
        $jsKeys = [
            'register_email_sent_title',
            'register_email_instruction',
            'register_guest_until_confirm',
            'error_password_mismatch',
            'error_password_short',
            'error_password_weak',
            'error_network',
            'error_enter_password',
            'error_invalid_email',
            'error_register_failed',
            'error_unknown',
            'error_upload_failed',
            'error_connection_failed',
            'user_typing',
            'ajax_inactive_warning',
            'title_alert',
            'tabfocus_status_away',
            'connection_lost',
            'unregister_no_session',
            'unregister_password_incorrect',
            'register_password_weak_msg',
            'register_password_strong_msg',
            'register_password_mismatch',
            'private_user_not_online',
            'private_user_not_online_text',
            'private_opponent_offline',
            'avatar_success',
            'avatar_delete_confirm',
            'avatar_delete_success',
            'upload_success',
            'upload_failed',
            'upload_select_file_first',
            'upload_gif_too_large',
            'upload_file_too_large',
            'upload_invalid_type',
            'smileys_loading',
            'smileys_no_smileys',
            'static_max_smilies',
            'static_external_link',
            'static_image_click_title',
            'wuerfel_too_many',
            'wuerfel_message',
            'remove_pw_confirm',
            'remove_pw_confirm_error',
            'unregister_success',
            'unregister_no_password',
            'unregister_no_permission',
            'unregister_no_session',
            'unregister_wrong_password',
            'unregister_network_error',
            'unregister_generic_error',
            'broadcast_js_empty',
            'broadcast_js_sending',
            'broadcast_js_sent',
            'broadcast_js_error',
            'broadcast_js_unknown_error',
            'broadcast_js_network_error',
            'broadcast_js_clear_confirm',
            'broadcast_js_cleared',
            'broadcast_js_no_active',
            'broadcast_js_active',
            'broadcast_js_type',
            'broadcast_js_mode',
            'broadcast_js_sent_to',
            'broadcast_js_seen_by',
            'broadcast_js_online',
            'broadcast_js_user',
            'broadcast_js_unknown',
            'broadcast_js_only_message',
            'broadcast_js_message_reload',
        ];
        
        if (in_array($key, $jsKeys)) {
            $this->jsKeys[$key] = true;
            return true;
        }
        
        $this->jsKeys[$key] = false;
        return false;
    }

    // ============================================================
    // EXISTIERENDE METHODEN (unverändert)
    // ============================================================
    
    private function findAllJsonFiles(string $basePath, string $folder): array
    {
        $searchPath = $basePath . $folder . '/';
        $pattern = $searchPath . 'lang_*.json';
        $files = glob($pattern);
        
        $result = [];
        foreach ($files as $file) {
            $result[] = basename($file);
        }
        sort($result);
        return $result;
    }

    private function parseJsonFile(string $jsonPath): void
    {
        $jsonContent = file_get_contents($jsonPath);
        if ($jsonContent === false) {
            $this->categories = ['Allgemein' => ['Allgemein' => []]];
            return;
        }

        $data = json_decode($jsonContent, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->categories = ['Allgemein' => ['Allgemein' => []]];
            return;
        }

        $strings = $data['strings'] ?? [];
        $this->allStrings = $strings;

        if (empty($strings)) {
            $this->categories = ['Allgemein' => ['Allgemein' => []]];
            return;
        }

        // Einfache Gruppierung
        $grouped = [];
        foreach ($strings as $key => $value) {
            $parts = explode('_', $key);
            $mainKey = $parts[0] ?? 'allgemein';
            
            $mainName = match($mainKey) {
                'admin' => '👑 Admin',
                'user' => '👤 Benutzer',
                'room' => '🚪 Räume',
                'smilies' => '😊 Smileys',
                'gallery' => '🖼️ Galerie',
                'blacklist' => '🚫 Blacklist',
                'broadcast' => '📢 Broadcast',
                'prop' => '⚙️ Einstellungen',
                'menu' => '📋 Menü',
                'box' => '📦 Boxen',
                'text' => '📝 Texte',
                'radio' => '📻 Radio',
                'backup' => '💾 Backup',
                'update' => '🔄 Update',
                'bot' => '🤖 Bot',
                'kontakt' => '📞 Kontakt',
                'bewerbung' => '📋 Bewerbung',
                'register' => '📝 Registrierung',
                'login' => '🔐 Login',
                'password' => '🔑 Passwort',
                'avatar' => '🖼️ Avatar',
                'upload' => '📤 Upload',
                'hallo' => '👋 Begrüßung',
                'wunschbox' => '📦 Wunschbox',
                'sendeplan' => '📅 Sendeplan',
                'playlist' => '🎵 Playlist',
                'toplist' => '🏆 Topliste',
                'team' => '👥 Team',
                'profile' => '👤 Profil',
                'private' => '🔒 Privat',
                'status' => '📊 Status',
                'error' => '❌ Fehler',
                'warning' => '⚠️ Warnung',
                'info' => 'ℹ️ Info',
                'help' => '❓ Hilfe',
                default => '📌 ' . ucfirst($mainKey)
            };
            
            $subKey = $parts[1] ?? 'allgemein';
            $subName = match($subKey) {
                'allgemein' => '📋 Allgemein',
                'page_title' => '📌 Titel',
                'footer_note' => '📄 Fußnote',
                'edit' => '✏️ Bearbeiten',
                'create' => '➕ Erstellen',
                'delete' => '🗑️ Löschen',
                'save' => '💾 Speichern',
                'update' => '🔄 Aktualisieren',
                'add' => '➕ Hinzufügen',
                'remove' => '🗑️ Entfernen',
                'error' => '❌ Fehler',
                'success' => '✅ Erfolg',
                'warning' => '⚠️ Warnung',
                'info' => 'ℹ️ Info',
                'hint' => '💡 Tipp',
                'label' => '🏷️ Beschriftung',
                'placeholder' => '📝 Platzhalter',
                'button' => '🔘 Button',
                'list' => '📋 Liste',
                'table' => '📊 Tabelle',
                'settings' => '⚙️ Einstellungen',
                'manage' => '⚙️ Verwalten',
                'form' => '📝 Formular',
                'title' => '📌 Titel',
                'back' => '⬅️ Zurück',
                'note' => '📝 Hinweis',
                'confirm' => '✅ Bestätigung',
                'option' => '⚙️ Option',
                'default' => '⭐ Standard',
                'current' => '📌 Aktuell',
                'new' => '🆕 Neu',
                'old' => '📌 Alt',
                'all' => '📋 Alle',
                'none' => '🚫 Keine',
                'empty' => '📭 Leer',
                'total' => '📊 Gesamt',
                'count' => '🔢 Anzahl',
                'date' => '📅 Datum',
                'time' => '🕐 Zeit',
                'name' => '📝 Name',
                'email' => '📧 E-Mail',
                'phone' => '📞 Telefon',
                'address' => '📍 Adresse',
                'location' => '📍 Ort',
                'gender' => '⚧️ Geschlecht',
                'birthday' => '🎂 Geburtstag',
                'age' => '🎂 Alter',
                'privilege' => '🔑 Privileg',
                'role' => '👤 Rolle',
                'right' => '🔑 Rechte',
                'permission' => '🔑 Berechtigung',
                'access' => '🚪 Zugriff',
                'denied' => '🚫 Verweigert',
                'allowed' => '✅ Erlaubt',
                default => '📌 ' . ucfirst($subKey)
            };
            
            if ($mainKey === 'admin' && isset($parts[2])) {
                $adminAction = $parts[2];
                $actionName = match($adminAction) {
                    'page_title' => '📌 Titel',
                    'footer_note' => '📄 Fußnote',
                    'edit' => '✏️ Bearbeiten',
                    'create' => '➕ Erstellen',
                    'delete' => '🗑️ Löschen',
                    'save' => '💾 Speichern',
                    'update' => '🔄 Aktualisieren',
                    'add' => '➕ Hinzufügen',
                    'remove' => '🗑️ Entfernen',
                    'error' => '❌ Fehler',
                    'success' => '✅ Erfolg',
                    'warning' => '⚠️ Warnung',
                    'info' => 'ℹ️ Info',
                    'hint' => '💡 Tipp',
                    'label' => '🏷️ Beschriftung',
                    'placeholder' => '📝 Platzhalter',
                    'button' => '🔘 Button',
                    'list' => '📋 Liste',
                    'table' => '📊 Tabelle',
                    'settings' => '⚙️ Einstellungen',
                    'manage' => '⚙️ Verwalten',
                    'form' => '📝 Formular',
                    'title' => '📌 Titel',
                    'back' => '⬅️ Zurück',
                    'note' => '📝 Hinweis',
                    'confirm' => '✅ Bestätigung',
                    'option' => '⚙️ Option',
                    default => '📌 ' . ucfirst($adminAction)
                };
                
                $adminSub = $parts[1];
                $adminName = match($adminSub) {
                    'rooms' => '🚪 Räume',
                    'user' => '👤 Benutzer',
                    'reguser' => '📋 Registrierte User',
                    'blacklist' => '🚫 Blacklist',
                    'bannednames' => '🚫 Verbotene Namen',
                    'bewer' => '📋 Bewerbungen',
                    'gallery' => '🖼️ Galerie',
                    'prop' => '⚙️ Einstellungen',
                    'badwords' => '🚫 Filterwörter',
                    'boxes' => '📦 Boxen',
                    'menus' => '📋 Menü',
                    'texts' => '📝 Texte',
                    'kontakt' => '📞 Kontakt',
                    'bot' => '🤖 ChatBot',
                    'ankuendigung' => '📢 Ankündigung',
                    'imgmanager' => '🖼️ Icon Manager',
                    'styler' => '🎨 Chat Styler',
                    'loginbox' => '🔐 Login Box',
                    'sprachebearbeiten' => '🌐 Sprache bearbeiten',
                    'hallo' => '👋 Begrüßung',
                    'broadcast' => '📢 Broadcast',
                    'radio' => '📻 Radio',
                    'backup' => '💾 Backup',
                    'update' => '🔄 Update',
                    'css' => '🎨 CSS',
                    'smilies' => '😊 Smileys',
                    'smiliescat' => '📂 Smiley Kategorien',
                    default => '📌 ' . ucfirst($adminSub)
                };
                
                if (!isset($grouped[$adminName])) {
                    $grouped[$adminName] = [];
                }
                if (!isset($grouped[$adminName][$actionName])) {
                    $grouped[$adminName][$actionName] = [];
                }
                $grouped[$adminName][$actionName][$key] = $value;
            } else {
                if (!isset($grouped[$mainName])) {
                    $grouped[$mainName] = [];
                }
                if (!isset($grouped[$mainName][$subName])) {
                    $grouped[$mainName][$subName] = [];
                }
                $grouped[$mainName][$subName][$key] = $value;
            }
        }
        
        ksort($grouped);
        foreach ($grouped as $main => $subs) {
            ksort($grouped[$main]);
        }
        $this->categories = $grouped;
        
        if (empty($this->categories)) {
            $this->categories = ['Alle Texte' => ['Alle Einträge' => $strings]];
        }
    }

    private function handleSave(): void
    {
        $token = $_POST['csrf'] ?? '';
        if (!hash_equals($this->csrfToken, $token)) {
            $_SESSION['lang_save_error'] = '🔒 CSRF Fehler';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $langFolder = trim((string)($_POST['lang_folder'] ?? ''));
        $selectedCategory = $_POST['selected_category'] ?? '';
        $selectedFile = $_POST['selected_file'] ?? '';

        if ($langFolder === '' || $selectedFile === '') {
            $_SESSION['lang_save_error'] = '❌ Ungültige Eingaben.';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $jsonPath = __DIR__ . '/../../lang/' . $langFolder . '/' . $selectedFile;

        if (!file_exists($jsonPath)) {
            $_SESSION['lang_save_error'] = '📄 Datei nicht gefunden: ' . htmlspecialchars($selectedFile);
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $updatedStrings = [];
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'lang_') === 0) {
                $realKey = substr($key, 5);
                $updatedStrings[$realKey] = trim($value);
            }
        }

        if (empty($updatedStrings)) {
            $_SESSION['lang_save_error'] = '❌ Keine Änderungen zum Speichern gefunden.';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $jsonContent = file_get_contents($jsonPath);
        if ($jsonContent === false) {
            $_SESSION['lang_save_error'] = '❌ Lesen der Datei fehlgeschlagen.';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $data = json_decode($jsonContent, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $_SESSION['lang_save_error'] = '❌ Parsen der JSON-Datei fehlgeschlagen.';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $changed = 0;
        foreach ($updatedStrings as $key => $value) {
            // ============================================================
            // JS-STRINGS AUTOMATISCH SICHER MACHEN
            // ============================================================
            if ($this->isJavaScriptString($key)) {
                // 1. HTML-Tags entfernen
                $value = strip_tags($value);
                // 2. Zeilenumbrüche entfernen (oder in Leerzeichen umwandeln)
                $value = str_replace(["\r\n", "\n", "\r"], ' ', $value);
                // 3. Mehrfach-Leerzeichen entfernen
                $value = preg_replace('/\s+/', ' ', $value);
                // 4. Für JavaScript escapen
                $value = addslashes($value);
            }
            
            if (isset($data['strings'][$key]) && $data['strings'][$key] !== $value) {
                $data['strings'][$key] = $value;
                $changed++;
            } elseif (!isset($data['strings'][$key])) {
                $data['strings'][$key] = $value;
                $changed++;
            }
        }

        if ($changed === 0) {
            $_SESSION['lang_save_error'] = '❌ Keine Änderungen zum Speichern gefunden.';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $backupDir = dirname($jsonPath) . '/old/';
        if (!is_dir($backupDir) && !mkdir($backupDir, 0755, true) && !is_dir($backupDir)) {
            $_SESSION['lang_save_error'] = '📁 Backup-Ordner konnte nicht erstellt werden.';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $backupFile = basename($jsonPath) . '.bak.' . date('Ymd_His');
        copy($jsonPath, $backupDir . $backupFile);

        $jsonOutput = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (file_put_contents($jsonPath, $jsonOutput) === false) {
            $_SESSION['lang_save_error'] = '❌ Speichern fehlgeschlagen.';
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $_SESSION['lang_save_success'] = "✅ {$changed} Einträge wurden erfolgreich aktualisiert! (JS-Strings wurden automatisch gesichert)";
        
        header("Location: ./?AdminSpracheBearbeiten&lang_folder=" . urlencode($langFolder) . 
               "&json_file=" . urlencode($selectedFile) . 
               "&category=" . urlencode($selectedCategory));
        exit;
    }

    private function getLangCode(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
            'Französisch' => 'fr',
            'Spanisch' => 'es',
            'Italienisch' => 'it',
            'Niederländisch' => 'nl',
            'Russisch' => 'ru',
            'Türkisch' => 'tr',
            'Arabisch' => 'ar',
            'Chinesisch' => 'zh',
            'Japanisch' => 'ja',
        ];
        return $map[$folder] ?? 'de';
    }

    private function getLanguageFolders(string $basePath): array
    {
        $folders = [];
        if (!is_dir($basePath)) return $folders;

        $handle = opendir($basePath);
        while (($item = readdir($handle)) !== false) {
            if ($item === '.' || $item === '..') continue;
            $fullPath = $basePath . '/' . $item;
            if (!is_dir($fullPath)) continue;
            
            $files = glob($fullPath . '/lang_*.json');
            if (!empty($files)) {
                $folders[] = $item;
            }
        }
        closedir($handle);
        sort($folders);
        return $folders;
    }

    private function countBackups(string $jsonPath): int
    {
        $backupDir = dirname($jsonPath) . '/old/';
        $baseName = basename($jsonPath);
        $files = is_dir($backupDir) ? glob($backupDir . $baseName . '.bak.*') : [];
        return $files !== false ? count($files) : 0;
    }
}