<?php
declare(strict_types=1);

/**
 * AdminWunschbox – Verwaltung der Wünsche (Admin/Mod/Co-Admin)
 */

class AdminWunschbox extends DbConectionMaker
{
    private Wunschbox $manager;
    private string $csrfToken = '';
    private object $lang;
    private string $userRole = '';
    private int $userId = 0;
    private array $wishes = [];
    private ?int $sendungsId = null;
    private bool $deleted = false;
    private string $filter = 'all';
    private int $currentPage = 1;
    private int $perPage = 10;
    private int $totalWishes = 0;
    private int $totalPages = 0;
    private array $config = [];
    private $modFilterSendungId = null;
    private bool $modFilterActive = false;
    private string $modFilterMode = 'all';
    private string $modViewMode = 'current';
    private array $availableViews = ['current'];
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        
        $this->lang = new LangJson('', 'wb_sendeplan_admin.json');
        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
        $this->userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        $this->manager = new Wunschbox();
        
        $this->loadConfig();
        
        $allowedRoles = ['admin', 'mod', 'co_admin'];
        if (!in_array($this->userRole, $allowedRoles, true)) {
            header('Location: ./');
            exit;
        }
        
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
        
        // Filter
        $allowedFilters = ['all', 'gespielt', 'vorab'];
        $this->filter = isset($_GET['filter']) && in_array($_GET['filter'], $allowedFilters, true) 
            ? $_GET['filter'] 
            : 'all';
        
        $this->currentPage = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        
        // Verfügbare Modi je Rolle/Config bestimmen
        $this->determineAvailableViews();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        } else {
            $this->showList();
        }
    }
    
    private function determineAvailableViews(): void
    {
        $modSeeAll = $this->getConfig('mod_can_see_all', '1');
        $isAdmin = in_array($this->userRole, ['admin', 'co_admin'], true);
        
        if ($isAdmin) {
            $this->availableViews = ['current', 'all_own', 'all'];
            $defaultView = 'all';
        } elseif ($this->userRole === 'mod') {
            if ($modSeeAll === '1') {
                $this->availableViews = ['current', 'all_own', 'all'];
                $defaultView = 'all';
            } elseif ($modSeeAll === '2') {
                $this->availableViews = ['current', 'all_own'];
                $defaultView = 'all_own';
            } else {
                // 🔥 NEU: mod_can_see_all = 0
                // "Alle eigenen" nur bei Filter "gespielt" oder "vorab"
                // Bei Filter "all" (Offene) → nur aktuelle Sendung
                if ($this->filter === 'all') {
                    $this->availableViews = ['current'];
                    $defaultView = 'current';
                } else {
                    $this->availableViews = ['current', 'all_own'];
                    $defaultView = 'current';
                }
            }
        } else {
            $this->availableViews = ['current'];
            $defaultView = 'current';
        }
        
        // Modus aus GET oder Standard
        if (!isset($_GET['mod_view']) || !in_array($_GET['mod_view'], $this->availableViews, true)) {
            $this->modViewMode = $defaultView;
        } else {
            $this->modViewMode = $_GET['mod_view'];
        }
    }
    
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_wunschbox_config"
        );
        
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
    private function getConfig(string $key, string $default = ''): string
    {
        return $this->config[$key] ?? $default;
    }
    
    private function getModeratorSendungId(): ?int
    {
        $now = new DateTime();
        $currentDate = $now->format('Y-m-d');
        $currentTime = $now->format('H:i:s');
        
        $result = $this->dbObj->sqlGet(
            "SELECT id 
             FROM {$this->_prefix}etchat_sendeplan 
             WHERE moderator_id = :user_id 
             AND datum = :date 
             AND zeit_von <= :time 
             AND zeit_bis >= :time
             LIMIT 1",
            [
                ':user_id' => $this->userId,
                ':date' => $currentDate,
                ':time' => $currentTime
            ]
        );
        
        if (!empty($result)) {
            return (int)$result[0]['id'];
        }
        
        $result = $this->dbObj->sqlGet(
            "SELECT id 
             FROM {$this->_prefix}etchat_sendeplan 
             WHERE moderator_id = :user_id 
             AND datum >= :date 
             ORDER BY datum ASC, zeit_von ASC
             LIMIT 1",
            [
                ':user_id' => $this->userId,
                ':date' => $currentDate
            ]
        );
        
        if (!empty($result)) {
            return (int)$result[0]['id'];
        }
        
        return null;
    }
    
    private function getModeratorAllSendungIds(): array
    {
        $result = $this->dbObj->sqlGet(
            "SELECT DISTINCT id 
             FROM {$this->_prefix}etchat_sendeplan 
             WHERE moderator_id = :user_id 
             ORDER BY datum DESC, zeit_von DESC",
            [':user_id' => $this->userId]
        );
        
        $ids = [];
        foreach ($result as $row) {
            $ids[] = (int)$row['id'];
        }
        
        return $ids;
    }
    
    private function handlePost(): void
    {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            exit($this->lang->get('admin_wunschbox_error_csrf', 'Ungültiger CSRF Token'));
        }
    
        if (isset($_GET['action']) && $_GET['action'] === 'markAsPlayed') {
            $this->markAsPlayed();
            exit;
        }
    
        if (isset($_GET['action']) && $_GET['action'] === 'unmarkAsPlayed') {
            $this->unmarkAsPlayed();
            exit;
        }
    
        if (isset($_GET['action']) && $_GET['action'] === 'unblockIp') {
            $this->unblockIp();
            exit;
        }
    
        if (isset($_GET['action']) && $_GET['action'] === 'blockIp') {
            $this->blockIp();
            exit;
        }
    
        if (!empty($_POST['delete_wunsch'])) {
            foreach ($_POST['delete_wunsch'] as $id => $v) {
                $this->manager->deleteWish((int)$id);
            }
            header("Location: ./?AdminWunschbox&deleted=1&t=" . time() . "&filter=" . $this->filter . "&page=" . $this->currentPage);
            exit;
        }
    }
    
    /**
     * 🔥 Wunsch als gespielt markieren
     * Status 0 → 1 | Status 2 → 3
     */
    private function markAsPlayed(): void
    {
        header('Content-Type: application/json');
        
        $wishId = (int)($_GET['wish_id'] ?? 0);
        
        if ($wishId <= 0) {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_invalid_id', 'Ungültige Wunsch-ID')]);
            return;
        }
        
        // Aktuellen Status prüfen
        $current = $this->dbObj->sqlGet(
            "SELECT gespielt FROM {$this->_prefix}etchat_wunschbox WHERE id = :id",
            [':id' => $wishId]
        );
        
        if (empty($current)) {
            echo json_encode(['success' => false, 'error' => 'Wunsch nicht gefunden']);
            return;
        }
        
        $currentStatus = (int)$current[0]['gespielt'];
        $newStatus = 1; // Standard
        
        if ($currentStatus === 2) {
            // War Vorab → gespielter Vorab
            $newStatus = 3;
        } elseif ($currentStatus === 0) {
            $newStatus = 1;
        } else {
            // Bereits gespielt (1 oder 3) → nichts ändern
            echo json_encode(['success' => true]);
            return;
        }
        
        $success = $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_wunschbox 
             SET gespielt = :status, 
                 gespielt_am = NOW(), 
                 gespielt_von = :user_id 
             WHERE id = :id",
            [
                ':status' => $newStatus,
                ':user_id' => $this->userId,
                ':id' => $wishId
            ]
        );
        
        if ($success) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_mark_failed', 'Fehler beim Markieren')]);
        }
    }
    
    /**
     * 🔥 Gespielt-Status zurücksetzen
     * Status 1 → 0 | Status 3 → 2
     */
    private function unmarkAsPlayed(): void
    {
        header('Content-Type: application/json');
        
        $wishId = (int)($_GET['wish_id'] ?? 0);
        
        if ($wishId <= 0) {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_invalid_id', 'Ungültige Wunsch-ID')]);
            return;
        }
        
        // Aktuellen Status prüfen
        $current = $this->dbObj->sqlGet(
            "SELECT gespielt FROM {$this->_prefix}etchat_wunschbox WHERE id = :id",
            [':id' => $wishId]
        );
        
        if (empty($current)) {
            echo json_encode(['success' => false, 'error' => 'Wunsch nicht gefunden']);
            return;
        }
        
        $currentStatus = (int)$current[0]['gespielt'];
        $newStatus = 0;
        
        if ($currentStatus === 3) {
            // War gespielter Vorab → zurück zu Vorgemerkt
            $newStatus = 2;
        } elseif ($currentStatus === 1) {
            $newStatus = 0;
        } else {
            echo json_encode(['success' => true]);
            return;
        }
        
        $success = $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_wunschbox 
             SET gespielt = :status, 
                 gespielt_am = NULL, 
                 gespielt_von = NULL 
             WHERE id = :id",
            [
                ':status' => $newStatus,
                ':id' => $wishId
            ]
        );
        
        if ($success) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_unmark_failed', 'Fehler beim Zurücksetzen')]);
        }
    }
    
    private function showList(): void
    {
        $this->sendungsId = isset($_GET['sendungs_id']) ? (int)$_GET['sendungs_id'] : null;
        $this->deleted = isset($_GET['deleted']) && isset($_GET['t']);
        
        $filterSendungsId = $this->sendungsId;
        $this->modFilterActive = false;
        $this->modFilterSendungId = null;
        $this->modFilterMode = 'all';
        
        if ($this->modViewMode === 'current') {
            $this->modFilterMode = 'current';
            $ownSendungsId = $this->getModeratorSendungId();
            
            if ($ownSendungsId !== null) {
                $this->modFilterSendungId = $ownSendungsId;
                $filterSendungsId = $ownSendungsId;
            } else {
                $this->wishes = [];
                $this->totalWishes = 0;
                $this->totalPages = 0;
                $this->modFilterActive = true;
                $this->renderTemplate();
                return;
            }
            $this->modFilterActive = true;
            
        } elseif ($this->modViewMode === 'all_own') {
            $this->modFilterMode = 'own_all';
            $ownSendungsIds = $this->getModeratorAllSendungIds();
            
            if (!empty($ownSendungsIds)) {
                $filterSendungsId = null;
                $this->modFilterSendungId = $ownSendungsIds;
            } else {
                $this->wishes = [];
                $this->totalWishes = 0;
                $this->totalPages = 0;
                $this->modFilterActive = true;
                $this->renderTemplate();
                return;
            }
            $this->modFilterActive = true;
            
        } elseif ($this->modViewMode === 'all') {
            $this->modFilterMode = 'all';
            $filterSendungsId = $this->sendungsId;
            $this->modFilterActive = false;
        }
        
        $offset = ($this->currentPage - 1) * $this->perPage;
        
        if ($this->modFilterMode === 'own_all' 
            && !empty($this->modFilterSendungId) && is_array($this->modFilterSendungId)) {
            
            $this->wishes = $this->manager->getWishesBySendungsIds(
                $this->modFilterSendungId, 
                $this->filter, 
                $this->perPage, 
                $offset
            );
            $this->totalWishes = $this->manager->getWishesCountBySendungsIds($this->modFilterSendungId, $this->filter);
        } else {
            $this->wishes = $this->manager->getWishes(
                $filterSendungsId, 
                $this->filter, 
                $this->perPage, 
                $offset
            );
            $this->totalWishes = $this->manager->getWishesCount($filterSendungsId, $this->filter);
        }
        
        $this->totalPages = (int)ceil($this->totalWishes / $this->perPage);
        
        $this->renderTemplate();
    }
    
    private function renderTemplate(): void
    {
        $wishes = $this->wishes;
        $sendungsId = $this->sendungsId;
        $deleted = $this->deleted;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;
        $userRole = $this->userRole;
        $filter = $this->filter;
        $currentPage = $this->currentPage;
        $totalPages = $this->totalPages;
        $totalWishes = $this->totalWishes;
        $perPage = $this->perPage;
        $refreshSeconds = (int)$this->getConfig('admin_refresh_seconds', '30');
        
        $modFilterActive = $this->modFilterActive;
        $modFilterSendungId = $this->modFilterSendungId;
        $modFilterMode = $this->modFilterMode;
        
        $modCanDelete = $this->getConfig('mod_can_delete', 'none');
        $isAdmin = ($this->userRole === 'admin' || $this->userRole === 'co_admin');
        
        $modViewMode = $this->modViewMode;
        $modSeeAll = $this->getConfig('mod_can_see_all', '1');
        $availableViews = $this->availableViews;
		
		// 🔥 NEU: Cleanup-Stunden für Button-Logik
		$wunschboxCleanupHours = (int)$this->getConfig('wunschbox_cleanup_hours', '3');
        
        include "styles/admin_tpl/indexWunschbox.tpl.html";
    }
    
    private function blockIp(): void
    {
        header('Content-Type: application/json');
    
        $ip = $_GET['ip'] ?? '';
        $wishId = (int)($_GET['wish_id'] ?? 0);
    
        if (empty($ip) || $ip === '0.0.0.0') {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_invalid_ip', 'Ungültige IP-Adresse')]);
            return;
        }
    
        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_wunschbox_ip_ban WHERE ban_until < NOW()",
            []
        );
    
        $existing = $this->dbObj->sqlGet(
            "SELECT id FROM {$this->_prefix}etchat_wunschbox_ip_ban 
            WHERE ip_address = :ip AND ban_until > NOW()",
            [':ip' => $ip]
        );
    
        if (!empty($existing)) {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_ip_already_banned', 'IP ist bereits gesperrt')]);
            return;
        }
    
        $success = $this->dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_wunschbox_ip_ban 
            (ip_address, ban_until, created_by, reason) 
            VALUES (:ip, DATE_ADD(NOW(), INTERVAL 30 MINUTE), :user_id, :reason)",
            [
                ':ip' => $ip,
                ':user_id' => $this->userId,
                ':reason' => str_replace('{id}', (string)$wishId, $this->lang->get('admin_wunschbox_ban_reason', 'Spam-Verdacht (Wunschbox) - Wunsch ID: {id}'))
            ]
        );
    
        if ($success) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_ip_ban_failed', 'Fehler beim Speichern der Sperrung')]);
        }
    }
    
    private function unblockIp(): void
    {
        header('Content-Type: application/json');
        
        $ip = $_GET['ip'] ?? '';
        $wishId = (int)($_GET['wish_id'] ?? 0);
    
        if (empty($ip) || $ip === '0.0.0.0') {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_invalid_ip', 'Ungültige IP-Adresse')]);
            return;
        }
    
        $existing = $this->dbObj->sqlGet(
            "SELECT id FROM {$this->_prefix}etchat_wunschbox_ip_ban 
            WHERE ip_address = :ip AND ban_until > NOW()",
            [':ip' => $ip]
        );
    
        if (empty($existing)) {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_ip_not_banned', 'IP ist nicht gesperrt')]);
            return;
        }
    
        $success = $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_wunschbox_ip_ban WHERE ip_address = :ip",
            [':ip' => $ip]
        );
    
        if ($success) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $this->lang->get('admin_wunschbox_error_ip_unban_failed', 'Fehler beim Entsperren der IP')]);
        }
    }
}