<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminCreateNewMenu extends ConnectDB
{
    /**
     * Popup-Muster – MUSS identisch sein mit Menu.class.php
     * Capture-Groups:
     *   [1] = Ziel-URL
     *   [2] = "width=...,height=..."
     */

    private const POPUP_REGEX =
        '~^window\.open\(\x27(https?://[a-zA-Z0-9\-._\x7E:/?#\[\]@!$&\x27()*+,;=%]+)\x27,\x27\x27,\x27\s*((?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4})(?:\s*,\s*(?:(?:toolbar|location|directories|status|menubar|scrollbars|resizable|copyhistory|personalbar|titlebar|alwaysRaised|alwaysLowered|dependent|modal|popup|noopener|noreferrer)=(?:0|1|yes|no)|(?:width|height|top|left|screenX|screenY|outerWidth|outerHeight|innerWidth|innerHeight)=\d{1,4}))*)\s*\x27\); return false;$~';
		
    /**
     * Normale URL
     */
    private const URL_REGEX =
        '~^https?://[a-zA-Z0-9\-._\x7E:/?#\[\]@!$&\'()*+,;=%]+$~i';

    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin Json
        // -------------------------
        $lang = new LangJson();

        // -------------------------
        // GET + POST kompatibel
        // -------------------------
        $data = $_POST + $_GET;

        // -------------------------
        // Rollenprüfung
        // -------------------------
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($role !== "admin") {
            echo $lang->get('admin_access_denied', 'Zugriff verweigert');
            $this->close();
            exit;
        }

        // -------------------------
        // CSRF prüfen
        // -------------------------
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';
        $requestToken = $data['csrf_token'] ?? '';
        if ($sessionToken === '' || $requestToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            die($lang->get('admin_createmenu_error_csrf', 'CSRF Fehler – Ungültige Anfrage.'));
        }

        // -------------------------
        // Werte holen
        // -------------------------
        $menu         = trim($data['menu'] ?? '');
        $link_text    = trim($data['link_text'] ?? '');
        $image_active = trim($data['image_active'] ?? '');
        $image        = trim($data['image'] ?? '');
        $url          = trim($data['url'] ?? '');
        $target       = trim($data['target'] ?? '');
        $gewicht      = max(0, (int)($data['gewicht'] ?? 0));

        // -------------------------
        // Pflichtfelder: menu muss vorhanden sein (wo soll es erscheinen?)
        // UND: link_text ODER image muss gefüllt sein (sonst sieht man nichts)
        // -------------------------
        if ($menu === '') {
            echo $lang->get('admin_createmenu_error_menu_required', 'Fehler: Der Menü-Ort (menu) muss angegeben werden.');
            $this->close();
            exit;
        }

        if ($link_text === '' && $image === '' && $image_active === '') {
            echo $lang->get('admin_createmenu_error_text_or_image', 'Fehler: Es muss entweder ein Link-Text oder ein Bild angegeben werden.');
            $this->close();
            exit;
        }

        // -------------------------
        // URL-Validierung:
        //   1) normale URL  ODER
        //   2) genau EIN erlaubtes Popup-Muster
        // -------------------------
        if ($url !== '') {

            $isNormalUrl = (bool) preg_match(self::URL_REGEX, $url);
            $isPopup     = (bool) preg_match(self::POPUP_REGEX, $url);

            if (!$isNormalUrl && !$isPopup) {
                echo $lang->get('admin_createmenu_error_url_invalid', 'Fehler: Die URL enthält ungültige Zeichen.');
                $this->close();
                exit;
            }
        }

        // -------------------------
        // target nur erlaubte Werte
        // -------------------------
        $allowedTargets = ['', '_blank', '_self', '_parent', '_top'];
        if (!in_array($target, $allowedTargets, true)) {
            $target = '';
        }

        // -------------------------
        // DB Insert mit Prepared Statement
        // -------------------------
        try {
            $this->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_menu 
                (menu, link_text, image_active, image, url, target, gewicht) 
                VALUES 
                (:menu, :link_text, :image_active, :image, :url, :target, :gewicht)",
                [
                    ':menu'         => $menu,
                    ':link_text'    => $link_text,
                    ':image_active' => $image_active,
                    ':image'        => $image,
                    ':url'          => $url,
                    ':target'       => $target,
                    ':gewicht'      => $gewicht
                ]
            );
        } catch (PDOException $e) {
            error_log("AdminCreateNewMenu Fehler: " . $e->getMessage());
            echo $lang->get('admin_createmenu_error_save', 'Fehler beim Speichern des Menüpunkts.');
            $this->close();
            exit;
        }

        // -------------------------
        // DB schließen & Weiterleitung
        // -------------------------
        $this->close();
        header("Location: ./?AdminMenusIndex&saved=1");
        exit;
    }
}