<?php
declare(strict_types=1);

/**
 * AdminSendeplanConfig – Verwaltung der Sendeplan-Einstellungen
 * Nur für Admin und Co-Admin sichtbar
 */

class AdminSendeplanConfig extends DbConectionMaker
{
    private string $csrfToken = '';
    private object $lang;
    private string $userRole = '';
    private array $config = [];
    private string $message = '';
    private bool $saved = false;
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        
        $this->lang = new LangJson('', 'wb_sendeplan_admin.json');
        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
        
        // 🔥 NUR Admin und Co-Admin
        $allowedRoles = ['admin', 'co_admin'];
        if (!in_array($this->userRole, $allowedRoles, true)) {
            header('Location: ./');
            exit;
        }
        
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
        
        $this->loadConfig();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        } else {
            $this->showConfig();
        }
    }
    
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_sendeplan_config"
        );
        
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
    private function handlePost(): void
    {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            exit($this->lang->get('admin_kontakt_error_csrf', 'Ungültiger CSRF Token'));
        }
        
        // Einstellungen speichern
        $configs = [
            'mod_can_create',
            'mod_can_edit',
            'mod_can_delete',
            'delete_after_days',
            'auto_delete_enabled',
            'max_days_ahead',
            'serien_monatlich_enabled',
            'serien_enabled',
            'serien_max_tage',
            'serien_max_termine',
            'serien_monate_max',
			'auto_dj_enabled',
			'auto_dj_time_from',
			'auto_dj_time_to',
			'nav_limit_days', 
			'wunschbox_vorab_enabled',
			'wunschbox_vorab_mods',
			'wunschbox_vorab_max_days',
        ];
        
        foreach ($configs as $key) {
            $value = $_POST[$key] ?? '';
            
            // Bei Checkboxen
            if ($key === 'auto_delete_enabled') {
                $value = isset($_POST[$key]) ? '1' : '0';
            }
            
            // Bei Zahlen
            if ($key === 'delete_after_days') {
                $value = (int)$value;
                if ($value < 1) $value = 1;
                if ($value > 365) $value = 365;
            }
			
            // 🔥 NEU: max_days_ahead
            if ($key === 'max_days_ahead') {
                $value = (int)$value;
                if ($value < 0) $value = 0;
                if ($value > 365) $value = 365;
            }
            
            // 🔥 NEU: Serien-Funktion
            if ($key === 'serien_enabled') {
                if (!in_array($value, ['admin', 'mod', 'none'], true)) {
                    $value = 'mod';
                }
            }
            if ($key === 'serien_max_tage') {
                $value = (int)$value;
                if ($value < 7) $value = 7;
                if ($value > 365) $value = 365;
            }
            if ($key === 'serien_max_termine') {
                $value = (int)$value;
                if ($value < 2) $value = 2;
                if ($value > 365) $value = 365;
            }
			
			// 🔥 NEU: serien_monatlich_enabled
			if ($key === 'serien_monatlich_enabled') {
				if (!in_array($value, ['admin', 'mod', 'none'], true)) {
					$value = 'mod';
				}
			}
			
            // 🔥 NEU: serien_monate_max (nur erlaubte Werte)
            if ($key === 'serien_monate_max') {
                $value = (int)$value;
                $erlaubteWerte = [24, 36, 48, 60, 72];
                if (!in_array($value, $erlaubteWerte, true)) {
                    $value = 36;  // Standard
                }
            }
			
			// 🔥 NEU: auto_dj_enabled (Checkbox)
			if ($key === 'auto_dj_enabled') {
				$value = isset($_POST[$key]) ? '1' : '0';
			}
			
			// 🔥 NEU: nav_limit_days
			if ($key === 'nav_limit_days') {
				$value = (int)$value;
				$allowed = [-1, 0, 7, 14, 21, 30, 60, 90, 180, 365];
				if (!in_array($value, $allowed, true)) {
					$value = -1;
				}
			}
			
			// 🔥 NEU: wunschbox_vorab_enabled (Checkbox)
			if ($key === 'wunschbox_vorab_enabled') {
				$value = isset($_POST[$key]) ? '1' : '0';
			}

			// 🔥 NEU: wunschbox_vorab_mods (Checkbox)
			if ($key === 'wunschbox_vorab_mods') {
				$value = isset($_POST[$key]) ? '1' : '0';
			}

			// 🔥 NEU: wunschbox_vorab_max_days (Zahl)
			if ($key === 'wunschbox_vorab_max_days') {
				$value = (int)$value;
				if ($value < 1) $value = 30;
				if ($value > 365) $value = 365;
			}

			// 🔥 NEU: auto_dj_time_from / auto_dj_time_to
			if ($key === 'auto_dj_time_from' || $key === 'auto_dj_time_to') {
				if (!preg_match('/^\d{2}:\d{2}$/', $value)) {
					$value = ($key === 'auto_dj_time_from') ? '08:00' : '22:00';
				}
			}
       
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_sendeplan_config 
                 SET config_value = :value 
                 WHERE config_key = :key",
                [':value' => $value, ':key' => $key]
            );
        }
        
			// 🔥 NEU: Auto-DJ Zeitfenster-Validierung
			$autoDjFrom = $_POST['auto_dj_time_from'] ?? '08:00';
			$autoDjTo   = $_POST['auto_dj_time_to']   ?? '22:00';

			// Erlaubte Sonderfälle
			$isAllDay1 = ($autoDjFrom === '00:00' && $autoDjTo === '00:00');
			$isAllDay2 = ($autoDjFrom === '00:00' && $autoDjTo === '24:00');

			if (!$isAllDay1 && !$isAllDay2) {
				// Normales Zeitfenster: from muss < to sein
				if ($autoDjFrom >= $autoDjTo) {
					// Fehler → zurück zum Formular mit Meldung
					$this->saved = false;
					$this->message = $this->lang->get('admin_sendeplan_config_auto_dj_time_error', 
						'⚠️ Ungültiges Zeitfenster: "Von" muss vor "Bis" liegen (außer 00:00 bis 00:00 oder 00:00 bis 24:00 für 24 Stunden).');
					$this->loadConfig();
					$this->showConfig();
					return;
				}
			}
		
        $this->saved = true;
        $this->message = $this->lang->get('admin_sendeplan_config_saved', 'Einstellungen wurden erfolgreich gespeichert!');
        $this->loadConfig(); // Neu laden
        $this->showConfig();
    }
    
    private function showConfig(): void
    {
        $config = $this->config;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;
        $userRole = $this->userRole;
        $saved = $this->saved;
        $message = $this->message;
        
        include "styles/admin_tpl/indexSendeplanConfig.tpl.html";
    }
}