<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteMenu extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // NEU: Sprache laden - Admin Json
        $lang = new LangJson();

        // Rechte prüfen (nur admin)
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($role !== 'admin') {
            echo $lang->get('admin_access_denied', 'Zugriff verweigert');
            $this->dbObj->close();
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $sessionToken = $_SESSION[$csrfKey];

        // GET + POST kompatibel
        $data = $_GET + $_POST;

        // ID absichern
        $id = (int)($data['id'] ?? 0);
        $requestToken = (string)($data['csrf_token'] ?? '');

        // CSRF Prüfung + ID
        if ($id <= 0) {
            $this->dbObj->close();
            header("Location: ./?AdminMenusIndex");
            exit;
        }

        if ($requestToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            echo $lang->get('admin_deletemenu_error_csrf', 'Manipulationsversuch erkannt.');
            $this->dbObj->close();
            exit;
        }

        // Menüpunkt löschen
        $this->deleteMenuItem($id);

        $this->dbObj->close();

        // Redirect
        header("Location: ./?AdminMenusIndex");
        exit;
    }

    /**
     * Löscht einen Menüpunkt aus der Datenbank
     */
    private function deleteMenuItem(int $id): void
    {
        try {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_menu WHERE id = :id",
                [':id' => $id]
            );
        } catch (PDOException $e) {
            error_log("AdminDeleteMenu Fehler: " . $e->getMessage());
            // Fehler still behandeln, redirect trotzdem
        }
    }
}