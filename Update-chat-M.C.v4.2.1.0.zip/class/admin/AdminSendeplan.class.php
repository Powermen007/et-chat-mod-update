<?php
declare(strict_types=1);

/**
 * AdminSendeplan – Verwaltung der Sendungen (Admin/Mod/Co-Admin)
 * Analog zu AdminKontakt.class.php
 */

class AdminSendeplan extends DbConectionMaker
{
    private Sendeplan $manager;
    private string $csrfToken = '';
    private object $lang;
    private string $userRole = '';
    private array $entries = [];
    private string $filter = '';
    private string $search = '';
    private int $currentPage = 1;
    private int $totalPages = 1;
    private int $totalAll = 0;
    private bool $saved = false;
    private bool $deleted = false;
    private array $config = [];
    private int $showStatus = 1;
	private int $filterModerator = 0;
    
    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        
        $this->lang = new LangJson('', 'wb_sendeplan_admin.json');
        $this->userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'gast';
        $this->manager = new Sendeplan();
        
        $this->loadConfig();
        
        $allowedRoles = ['admin', 'mod', 'co_admin'];
        if (!in_array($this->userRole, $allowedRoles, true)) {
            header('Location: ./');
            exit;
        }
        
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        } else {
            $this->showList();
        }
    }
    
    private function loadConfig(): void
    {
        $result = $this->dbObj->sqlGet(
            "SELECT config_key, config_value FROM {$this->_prefix}etchat_sendeplan_config"
        );
        foreach ($result as $row) {
            $this->config[$row['config_key']] = $row['config_value'];
        }
    }
    
    private function handlePost(): void
    {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            exit($this->lang->get('admin_sendeplan_error_csrf', 'Ungültiger CSRF Token'));
        }
        
        if (isset($_POST['save_sendeplan'])) {
            $this->saveEntries($_POST);
        } elseif (!empty($_POST['delete_sendeplan'])) {
            $this->deleteEntries($_POST);
        } elseif (isset($_POST['bulk_delete'])) {
            $this->bulkDelete($_POST);
        } elseif (isset($_POST['bulk_update'])) {
            $this->bulkUpdate($_POST);
        } elseif (isset($_POST['save_serie'])) {
            // 🔥 NEU: Serien-Berechtigung prüfen
            $serienEnabled = $this->config['serien_enabled'] ?? 'mod';
            
            if ($serienEnabled === 'none') {
                header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_disabled', 'Serienfunktion ist deaktiviert')));
                exit;
            }
            if ($serienEnabled === 'admin' && !in_array($this->userRole, ['admin', 'co_admin'], true)) {
                header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_no_permission', 'Keine Berechtigung für Serien')));
                exit;
            }
            
			// 🔥 NEU: Monatliche Serien-Berechtigung prüfen
			$wiederholung = $_POST['wiederholung'] ?? 'taeglich';
			if ($wiederholung === 'monatlich') {
				$serienMonatlichEnabled = $this->config['serien_monatlich_enabled'] ?? 'mod';
        
				if ($serienMonatlichEnabled === 'none') {
					header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_monthly_disabled', 'Monatliche Serien sind deaktiviert.')));
					exit;
				}
				if ($serienMonatlichEnabled === 'admin' && !in_array($this->userRole, ['admin', 'co_admin'], true)) {
					header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_no_permission', 'Keine Berechtigung für Serien')));
					exit;
				}
			}
    
			$this->saveSerieEntries($_POST);
		}
    }
    
    private function showList(): void
    {
        $this->filter = $_GET['filter'] ?? '';
        $this->search = trim((string)($_GET['search'] ?? ''));
        $this->currentPage = max(1, (int)($_GET['page'] ?? 1));
        $this->saved = isset($_GET['saved']);
		
		// 🔥 NEU: Serien-Abbruch (Konflikt-Session löschen)
        if (isset($_GET['serie_abbrechen'])) {
            unset($_SESSION['sendeplan_serie_konflikte']);
        }
		
        $this->deleted = isset($_GET['deleted']);
        
        // 🔥 NEU: Moderator-Filter
        $this->filterModerator = (int)($_GET['moderator'] ?? 0);
        
        // 🔥 NEU: Status (1 = Aktuelle, 2 = Abgelaufene)
        $this->showStatus = isset($_GET['status']) && $_GET['status'] == '2' ? 2 : 1;
        
        $perPage = 10;
        
        $where = [];
        $params = [];
        
        if ($this->filter) {
            $where[] = "datum = :filter";
            $params[':filter'] = $this->filter;
        }
		
		// 🔥 NEU: Serien-Filter
        $filterSerieGruppe = trim((string)($_GET['serie_gruppe'] ?? ''));
        if ($filterSerieGruppe !== '') {
            $where[] = "s.serie_gruppe = :serie_gruppe";
            $params[':serie_gruppe'] = $filterSerieGruppe;
        }
		
        if ($this->search) {
            $where[] = "(sendungsname LIKE :search OR beschreibung LIKE :search)";
            $params[':search'] = '%' . $this->search . '%';
        }
        // 🔥 NEU: Moderator-Filter
        if ($this->filterModerator > 0) {
            $where[] = "moderator_id = :moderator";
            $params[':moderator'] = $this->filterModerator;
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        
        // 🔥 NEU: ALLE Einträge holen (ohne LIMIT und OFFSET!)
        $sql = "SELECT s.*, u.etchat_username as moderator_name, u.etchat_avatar as moderator_avatar
                FROM {$this->_prefix}etchat_sendeplan s
                LEFT JOIN {$this->_prefix}etchat_user u ON s.moderator_id = u.etchat_user_id
                $whereSql
                ORDER BY s.datum ASC, s.zeit_von ASC";
        
        $allEntries = $this->dbObj->sqlGet($sql, $params) ?: [];
        
        // 🔥 NEU: Status in PHP berechnen (damit es nicht mit den Filtern kollidiert)
        $filteredEntries = [];
        $now = time();
        
        foreach ($allEntries as $entry) {
            $isOvernight = $entry['zeit_bis'] < $entry['zeit_von'];
            
            // Berechne den Zeitstempel für das Ende der Sendung
            if ($isOvernight) {
                // Endet am nächsten Tag
                $endTimestamp = strtotime($entry['datum'] . ' ' . $entry['zeit_bis'] . ' +1 day');
            } else {
                $endTimestamp = strtotime($entry['datum'] . ' ' . $entry['zeit_bis']);
            }
            
            // Ist die Sendung aktuell (noch nicht vorbei)?
            $isCurrent = ($endTimestamp >= $now);
            
            // 🔥 Filter: Wenn wir "Aktuell" wollen, aber die Sendung vorbei ist -> überspringen
            if ($this->showStatus === 1 && !$isCurrent) {
                continue;
            }
            // 🔥 Filter: Wenn wir "Abgelaufene" wollen, aber die Sendung noch läuft -> überspringen
            if ($this->showStatus === 2 && $isCurrent) {
                continue;
            }
            
            $filteredEntries[] = $entry;
        }
        
        // 🔥 NEU: Pagination ANWENDEN (nach der Filterung!)
        $this->totalAll = count($filteredEntries);
        $this->totalPages = max(1, (int)ceil($this->totalAll / $perPage));
        
        // 🔥 Wenn aktuelle Seite größer als letzte Seite ist -> auf letzte Seite setzen
        if ($this->currentPage > $this->totalPages) {
            $this->currentPage = $this->totalPages;
        }
        
        $offset = ($this->currentPage - 1) * $perPage;
        $this->entries = array_slice($filteredEntries, $offset, $perPage);
        
        $this->renderTemplate();
    }
    
    private function renderTemplate(): void
    {
        $entries = $this->entries;
        $filter = $this->filter;
        $search = $this->search;
        $currentPage = $this->currentPage;
        $totalPages = $this->totalPages;
        $totalAll = $this->totalAll;
        $saved = $this->saved;
        $deleted = $this->deleted;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;
        $userRole = $this->userRole;
        $error = isset($_GET['error']) && $_GET['error'] == 1;
        $errorMsg = $_GET['msg'] ?? '';
        $errorMsg = htmlspecialchars(urldecode($errorMsg), ENT_QUOTES, 'UTF-8');
        // 🔥 NEU: Erfolgs-Meldung aus der URL holen
        $msg = isset($_GET['msg']) && !isset($_GET['error']) ? htmlspecialchars(urldecode($_GET['msg']), ENT_QUOTES, 'UTF-8') : '';
        
        // 🔥 NEU: Status fürs Template
        $showStatus = $this->showStatus;
        $filterModerator = $this->filterModerator;
        
		$config = $this->config;
        $manager = $this->manager;
        $moderators = $this->manager->getModerators();
		$vorlagen = $this->manager->getVorlagen();
        $currentUserId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        
		$serieKonflikte = $_SESSION['sendeplan_serie_konflikte'] ?? null;
        $serieKonflikteAktiv = isset($_GET['serie_konflikte']) && $serieKonflikte !== null;
		
		$filterSerieGruppe = trim((string)($_GET['serie_gruppe'] ?? ''));
		
        $canCreate = $this->manager->canCreateEntry();
        $canEdit = function($entryId) use ($currentUserId) {
            return $this->manager->canEditEntry($entryId, $currentUserId);
        };
        $canDelete = function($entryId) use ($currentUserId) {
            return $this->manager->canDeleteEntry($entryId, $currentUserId);
        };
        
        $visibleModerators = $moderators;
        if ($userRole === 'mod') {
            $settingEdit = $this->config['mod_can_edit'] ?? 'own';
            $settingCreate = $this->config['mod_can_create'] ?? 'own';
            
            if ($settingEdit !== 'all' && $settingCreate !== 'all') {
                $visibleModerators = array_filter($moderators, function($mod) use ($currentUserId) {
                    return $mod['etchat_user_id'] == $currentUserId;
                });
            }
        }
        
        $successHtml = '';
        if ($saved) {
            $successHtml = '<div class="success-banner" id="successBanner"><span>' 
                . $this->lang->get('admin_sendeplan_save_success', 'Änderungen wurden erfolgreich gespeichert.') 
                . '</span><span class="close-btn" onclick="closeSuccessBanner()">✖</span></div>';
        }
        if ($deleted) {
            $successHtml = '<div class="success-banner" id="successBanner"><span>' 
                . $this->lang->get('admin_sendeplan_delete_success', 'Sendung wurde erfolgreich gelöscht.') 
                . '</span><span class="close-btn" onclick="closeSuccessBanner()">✖</span></div>';
        }
        
        include "styles/admin_tpl/indexSendeplan.tpl.html";
    }
    
    private function saveEntries(array $post): void
    {
        $firstError = null;
        $errorData = null;
        
        unset($_SESSION['sendeplan_error_data']);
        
        $newEntries = [];
        $existingEntries = [];
        
        foreach ($post['entries'] ?? [] as $id => $data) {
            if ($id === '0' || $id === 0) {
                $newEntries[$id] = $data;
            } else {
                $existingEntries[$id] = $data;
            }
        }
        
        // 🔥 NEU: Speichern neuer Einträge
        foreach ($newEntries as $id => $data) {
            if ($firstError !== null) break;
            
            $zeit_von = $data['zeit_von'] ?? '20:00';
            $zeit_bis = $data['zeit_bis'] ?? '22:00';
            if (strlen($zeit_von) === 5) $zeit_von .= ':00';
            if (strlen($zeit_bis) === 5) $zeit_bis .= ':00';
            
            $moderator_id = !empty($data['moderator_id']) ? (int)$data['moderator_id'] : null;
            
            $result = $this->manager->saveEntry([
                'id' => null,
                'datum' => $data['datum'] ?? '',
                'zeit_von' => $zeit_von,
                'zeit_bis' => $zeit_bis,
                'sendungsname' => $data['sendungsname'] ?? '',
                'beschreibung' => $data['beschreibung'] ?? '',
                'wunschbox_aktiv' => (int)($data['wunschbox_aktiv'] ?? 0),
                'moderator_id' => $moderator_id,
				'bild' => $data['bild'] ?? null
            ]);
            
            if ($result['success'] === false && $firstError === null) {
                $firstError = $result['error'] ?? $this->lang->get('admin_sendeplan_unknown_save_error', 'Unbekannter Fehler beim Speichern');
                $errorData = [
                    'id' => 0,
                    'datum' => $data['datum'] ?? date('Y-m-d'),
                    'zeit_von' => $zeit_von,
                    'zeit_bis' => $zeit_bis,
                    'sendungsname' => $data['sendungsname'] ?? '',
                    'beschreibung' => $data['beschreibung'] ?? '',
                    'wunschbox_aktiv' => (int)($data['wunschbox_aktiv'] ?? 1),
                    'moderator_id' => $moderator_id
                ];
            }
        }
        
        // 🔥 NEU: Speichern bestehender Einträge
        if ($firstError === null) {
            $originalEntries = [];
            foreach ($existingEntries as $id => $data) {
                $original = $this->manager->getEntry((int)$id);
                if ($original) {
                    $originalEntries[$id] = $original;
                }
            }
            
            foreach ($existingEntries as $id => $data) {
                $original = $originalEntries[$id] ?? null;
                
                $zeit_von = $data['zeit_von'] ?? '20:00';
                $zeit_bis = $data['zeit_bis'] ?? '22:00';
                if (strlen($zeit_von) === 5) $zeit_von .= ':00';
                if (strlen($zeit_bis) === 5) $zeit_bis .= ':00';
                
                $moderator_id = !empty($data['moderator_id']) ? (int)$data['moderator_id'] : null;
                
                // 🔥 Prüfen ob sich etwas geändert hat
                $hasChanged = false;
                if ($original) {
                    if ($original['datum'] != $data['datum']) $hasChanged = true;
                    if (substr($original['zeit_von'], 0, 5) != $zeit_von) $hasChanged = true;
                    if (substr($original['zeit_bis'], 0, 5) != $zeit_bis) $hasChanged = true;
                    if ($original['sendungsname'] != $data['sendungsname']) $hasChanged = true;
                    if ($original['beschreibung'] != ($data['beschreibung'] ?? '')) $hasChanged = true;
                    if (($original['wunschbox_aktiv'] ?? 0) != (int)($data['wunschbox_aktiv'] ?? 0)) $hasChanged = true;
                    if (($original['moderator_id'] ?? 0) != $moderator_id) $hasChanged = true;
					if (($original['bild'] ?? '') != ($data['bild'] ?? '')) $hasChanged = true;
                } else {
                    $hasChanged = false;
                }
                
                if ($hasChanged) {
                    $result = $this->manager->saveEntry([
                        'id' => (int)$id,
                        'datum' => $data['datum'] ?? '',
                        'zeit_von' => $zeit_von,
                        'zeit_bis' => $zeit_bis,
                        'sendungsname' => $data['sendungsname'] ?? '',
                        'beschreibung' => $data['beschreibung'] ?? '',
                        'wunschbox_aktiv' => (int)($data['wunschbox_aktiv'] ?? 0),
                        'moderator_id' => $moderator_id,
						'bild' => $data['bild'] ?? null
                    ]);
                    
                    if ($result['success'] === false && $firstError === null) {
                        $firstError = $result['error'] ?? $this->lang->get('admin_sendeplan_unknown_save_error', 'Unbekannter Fehler beim Speichern');
                        $errorData = [
                            'id' => (int)$id,
                            'datum' => $data['datum'] ?? date('Y-m-d'),
                            'zeit_von' => $zeit_von,
                            'zeit_bis' => $zeit_bis,
                            'sendungsname' => $data['sendungsname'] ?? '',
                            'beschreibung' => $data['beschreibung'] ?? '',
                            'wunschbox_aktiv' => (int)($data['wunschbox_aktiv'] ?? 1),
                            'moderator_id' => $moderator_id
                        ];
                    }
                }
            }
        }
        
        if ($firstError !== null) {
            $_SESSION['sendeplan_error_data'] = $errorData;
            $errorMsg = urlencode($firstError);
            header("Location: ./?AdminSendeplan&error=1&msg=" . $errorMsg);
            exit;
        }
        
        unset($_SESSION['sendeplan_error_data']);
        header("Location: ./?AdminSendeplan&saved=1");
        exit;
    }
    
    private function deleteEntries(array $post): void
    {
        foreach ($post['delete_sendeplan'] ?? [] as $id => $v) {
            $this->manager->deleteEntry((int)$id);
        }
        
        $params = [];
        // 🔥 NEU: Status aus der URL holen (weil die Formular-URL den Status enthält!)
        $status = isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], 'status=2') !== false ? 2 : 1;
        $params[] = 'status=' . $status;
        
        if (!empty($this->filter)) {
            $params[] = 'filter=' . urlencode($this->filter);
        }
        if (!empty($this->search)) {
            $params[] = 'search=' . urlencode($this->search);
        }
        
        header("Location: ./?AdminSendeplan&deleted=1" . ($params ? '&' . implode('&', $params) : ''));
        exit;
    }
	
    /**
     * 🔥 NEU: Massen-Löschen (nur markierte Einträge)
     */
    private function bulkDelete(array $post): void
    {
        $ids = $post['selected_ids'] ?? [];
        if (!is_array($ids) || empty($ids)) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_bulk_no_selection', 'Keine Einträge markiert')));
            exit;
        }

        $currentUserId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        $deletedCount = 0;
        $deniedCount = 0;

        foreach ($ids as $id) {
            $id = (int)$id;
            if ($id <= 0) continue;

            // 🔥 Rechte prüfen
            if (!$this->manager->canDeleteEntry($id, $currentUserId)) {
                $deniedCount++;
                continue;
            }

            $this->manager->deleteEntry($id);
            $deletedCount++;
        }

		if ($deniedCount > 0) {
			$msg = str_replace(
				['{count}', '{denied}'],
				[(string)$deletedCount, (string)$deniedCount],
				$this->lang->get('admin_sendeplan_bulk_deleted_with_denied', 'Gelöscht: {count} | Nicht erlaubt (keine Berechtigung): {denied}')
			);
		} else {
			$msg = str_replace(
				'{count}',
				(string)$deletedCount,
				$this->lang->get('admin_sendeplan_bulk_deleted', 'Gelöscht: {count}')
			);
		}

        // 🔥 NEU: Wenn keine einzige Löschung durchgeführt wurde, dann als "nicht erlaubt" behandeln
        if ($deletedCount === 0 && $deniedCount > 0) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_bulk_no_permission_delete', 'Keine Berechtigung zum Löschen der markierten Einträge')));
            exit;
        }

        header("Location: ./?AdminSendeplan&saved=1&msg=" . urlencode($msg));
        exit;
    }

    /**
     * 🔥 NEU: Massen-Update (nur markierte Einträge, nur ausgefüllte Felder)
     */
    private function bulkUpdate(array $post): void
    {
        $ids = $post['selected_ids'] ?? [];
        if (!is_array($ids) || empty($ids)) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_bulk_no_selection', 'Keine Einträge markiert')));
            exit;
        }

        $currentUserId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        $updatedCount = 0;
        $deniedCount = 0;

        // 🔥 Zu ändernde Felder einsammeln
        $updateFields = [];
        
        // Moderator (Sonderfall: "0" = Kein Moderator, "" = nicht ändern)
        if (isset($post['bulk_moderator_id']) && $post['bulk_moderator_id'] !== '') {
            $updateFields['moderator_id'] = ($post['bulk_moderator_id'] === '0') ? null : (int)$post['bulk_moderator_id'];
        }
        if (!empty($post['bulk_datum'])) {
            $updateFields['datum'] = $post['bulk_datum'];
        }
        if (!empty($post['bulk_zeit_von'])) {
            $zv = $post['bulk_zeit_von'];
            if (strlen($zv) === 5) $zv .= ':00';
            $updateFields['zeit_von'] = $zv;
        }
        if (!empty($post['bulk_zeit_bis'])) {
            $zb = $post['bulk_zeit_bis'];
            if (strlen($zb) === 5) $zb .= ':00';
            $updateFields['zeit_bis'] = $zb;
        }
        if (!empty($post['bulk_sendungsname'])) {
            $updateFields['sendungsname'] = $post['bulk_sendungsname'];
        }
        if (!empty($post['bulk_beschreibung'])) {
            $updateFields['beschreibung'] = $post['bulk_beschreibung'];
        }
        // Wunschbox (Sonderfall: "0" = Inaktiv, "1" = Aktiv, "" = nicht ändern)
        if (isset($post['bulk_wunschbox_aktiv']) && $post['bulk_wunschbox_aktiv'] !== '') {
            $updateFields['wunschbox_aktiv'] = (int)$post['bulk_wunschbox_aktiv'];
        }

        if (empty($updateFields)) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_bulk_no_fields', 'Keine Felder zum Ändern ausgefüllt')));
            exit;
        }

        // 🔥 NEU: Laufender Zähler für den {zahl}-Joker in Name/Beschreibung
        $jokerNummer = 0;

        foreach ($ids as $id) {
            $id = (int)$id;
            if ($id <= 0) continue;
            
            // 🔥 NEU: Joker-Zähler hochzählen (pro erfolgreich verarbeiteter Eintrag)
            $jokerNummer++;

            // 🔥 Rechte prüfen
            if (!$this->manager->canEditEntry($id, $currentUserId)) {
                $deniedCount++;
                $jokerNummer--;  // 🔥 Nicht gezählt, wenn abgelehnt
                continue;
            }

            // 🔥 Eintrag laden (um die fehlenden Felder zu ergänzen)
            $original = $this->manager->getEntry($id);
            if (!$original) {
                $jokerNummer--;  // 🔥 Nicht gezählt, wenn nicht gefunden
                continue;
            }

            // 🔥 NEU: Joker-Ersetzung in Name und Beschreibung
            $neuerName = $updateFields['sendungsname'] ?? $original['sendungsname'];
            $neueBeschreibung = $updateFields['beschreibung'] ?? $original['beschreibung'];
            
            // Nur ersetzen, wenn der Joker im Text enthalten ist
            $neuerName = $this->manager->ersetzeZahlJoker($neuerName, $jokerNummer);
            $neueBeschreibung = $this->manager->ersetzeZahlJoker($neueBeschreibung, $jokerNummer);

            // 🔥 Alle Felder zusammenbauen (Original + Update)
            $saveData = [
                'id' => $id,
                'datum' => $updateFields['datum'] ?? $original['datum'],
                'zeit_von' => $updateFields['zeit_von'] ?? $original['zeit_von'],
                'zeit_bis' => $updateFields['zeit_bis'] ?? $original['zeit_bis'],
                'sendungsname' => $neuerName,
                'beschreibung' => $neueBeschreibung,
                'wunschbox_aktiv' => $updateFields['wunschbox_aktiv'] ?? $original['wunschbox_aktiv'],
                'moderator_id' => array_key_exists('moderator_id', $updateFields) ? $updateFields['moderator_id'] : $original['moderator_id'],
                'bild' => $original['bild'] ?? null,
                // 🔥 NEU: Serie erhalten
                'serie_gruppe' => $original['serie_gruppe'] ?? null,
                'serie_nummer' => $original['serie_nummer'] ?? null,
                'erstellt_von' => $original['erstellt_von'] ?? $currentUserId
            ];

            $result = $this->manager->saveEntry($saveData);
            if ($result['success']) {
                $updatedCount++;
            } else {
                $jokerNummer--;  // 🔥 Nicht gezählt, wenn nicht gespeichert
            }
        }

		if ($deniedCount > 0) {
			$msg = str_replace(
				['{count}', '{denied}'],
				[(string)$updatedCount, (string)$deniedCount],
				$this->lang->get('admin_sendeplan_bulk_updated_with_denied', 'Aktualisiert: {count} | Nicht erlaubt (keine Berechtigung): {denied}')
			);
		} else {
			$msg = str_replace(
				'{count}',
				(string)$updatedCount,
				$this->lang->get('admin_sendeplan_bulk_updated', 'Aktualisiert: {count}')
			);
		}

        // 🔥 NEU: Wenn keine einzige Änderung durchgeführt wurde, dann als "nicht erlaubt" behandeln
        if ($updatedCount === 0 && $deniedCount > 0) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_bulk_no_permission_edit', 'Keine Berechtigung zum Bearbeiten der markierten Einträge')));
            exit;
        }

        header("Location: ./?AdminSendeplan&saved=1&msg=" . urlencode($msg));
        exit;
    }
	
    /**
     * 🔥 NEU: Speichert eine Serie (mehrere Termine auf einmal)
     */
    private function saveSerieEntries(array $post): void
    {
        // ============================================================
        // Die Serien-Felder teilen sich die Felder mit entries[0][...],
        // weil das Panel an derselben Zeile hängt.
        // ============================================================
        $entryData = $post['entries'][0] ?? [];
        
        if (empty($entryData)) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_no_data', 'Keine Seriendaten übermittelt')));
            exit;
        }
        
        // 🔥 NEU: Optionales Serien-Startdatum (nur bei Monatlich)
        // Wenn gesetzt, überschreibt es das Standard-Datum
        $serienStartDatum = trim((string)($post['serien_start_datum'] ?? ''));
        if ($serienStartDatum !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $serienStartDatum)) {
            $entryData['datum'] = $serienStartDatum;
        }

        // Zeit normalisieren
        $zeit_von = $entryData['zeit_von'] ?? '20:00';
        $zeit_bis = $entryData['zeit_bis'] ?? '22:00';
        if (strlen($zeit_von) === 5) $zeit_von .= ':00';
        if (strlen($zeit_bis) === 5) $zeit_bis .= ':00';

        $baseData = [
            'datum'           => $entryData['datum'] ?? date('Y-m-d'),
            'zeit_von'        => $zeit_von,
            'zeit_bis'        => $zeit_bis,
            'sendungsname'    => $entryData['sendungsname'] ?? '',
            'beschreibung'    => $entryData['beschreibung'] ?? '',
            'bild'            => $entryData['bild'] ?? null,
            'moderator_id'    => !empty($entryData['moderator_id']) ? (int)$entryData['moderator_id'] : null,
            'wunschbox_aktiv' => (int)($entryData['wunschbox_aktiv'] ?? 0),
        ];

        // Pflichtfelder prüfen
        if ($baseData['datum'] < date('Y-m-d')) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_past_date', 'Startdatum darf nicht in der Vergangenheit liegen')));
            exit;
        }
        if (empty($baseData['sendungsname'])) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_no_name', 'Sendungsname fehlt')));
            exit;
        }

        // Wochentage normalisieren
        $wochentage = $post['wochentage'] ?? [];
        if (!is_array($wochentage)) {
            $wochentage = [$wochentage];
        }
        $wochentage = array_map('intval', $wochentage);

        $regel = [
            'wiederholung'      => $post['wiederholung'] ?? 'taeglich',
            'wochentage'        => $wochentage,
            'wochen_intervall'  => (int)($post['wochen_intervall'] ?? 1),
            'intervall'         => (int)($post['intervall'] ?? 1),
            'monat_modus'       => $post['monat_modus'] ?? 'tag',
            'monat_tag'         => (int)($post['monat_tag'] ?? 1),
            'monat_intervall'   => (int)($post['monat_intervall'] ?? 1),  // 🔥 NEU
            'monat_position'    => (int)($post['monat_position'] ?? 1),
            'monat_wochentag'   => (int)($post['monat_wochentag'] ?? 1),
            'ende_typ'          => $post['ende_typ'] ?? 'anzahl',
            'ende_datum'        => $post['ende_datum'] ?? null,
            'ende_anzahl'       => (int)($post['ende_anzahl'] ?? 10),
        ];

        // 1. Termine berechnen
        $termine = $this->manager->calculateSerieTermine($baseData['datum'], $regel);

        if (empty($termine)) {
            header("Location: ./?AdminSendeplan&error=1&msg=" . urlencode($this->lang->get('admin_sendeplan_serie_no_terms', 'Keine Termine berechnet')));
            exit;
        }

        // 2. Konflikte prüfen
        $konflikte = [];
        foreach ($termine as $i => $datum) {
            $nummer = $i + 1;
            $check = $this->manager->checkOverlap($datum, $zeit_von, $zeit_bis, 0);
            if (!$check['success']) {
                $konflikte[] = [
                    'nummer'  => $nummer,
                    'datum'   => $datum,
                    'message' => $check['message'],
                ];
            }
        }

        // 3. Modus: 'check' oder 'force'
        $modus = $post['serie_modus'] ?? 'check';

        if (!empty($konflikte) && $modus === 'check') {
            $_SESSION['sendeplan_serie_konflikte'] = [
                'form_data' => $post,
                'konflikte' => $konflikte,
                'termine'   => $termine,
            ];
            header("Location: ./?AdminSendeplan&serie_konflikte=1");
            exit;
        }

        // 4. Speichern
        $gruppe = bin2hex(random_bytes(8));
        $erfolg = 0;
        $uebersprungen = 0;
        $fehlgeschlagen = [];

        $konfliktNummern = array_column($konflikte, 'nummer');

        foreach ($termine as $i => $datum) {
            $nummer = $i + 1;

            if ($modus === 'force' && in_array($nummer, $konfliktNummern, true)) {
                $uebersprungen++;
                continue;
            }

            // {zahl}-Joker in Name UND Beschreibung
            // Unterstützt: {zahl} (start 1) und {N zahl} (start N)
            $name = $this->manager->ersetzeZahlJoker($baseData['sendungsname'], $nummer);
            $beschreibung = $this->manager->ersetzeZahlJoker($baseData['beschreibung'], $nummer);

            $result = $this->manager->saveEntry([
                'id'              => null,
                'datum'           => $datum,
                'zeit_von'        => $zeit_von,
                'zeit_bis'        => $zeit_bis,
                'sendungsname'    => $name,
                'beschreibung'    => $beschreibung,
                'wunschbox_aktiv' => $baseData['wunschbox_aktiv'],
                'moderator_id'    => $baseData['moderator_id'],
                'bild'            => $baseData['bild'],
                'serie_gruppe'    => $gruppe,
                'serie_nummer'    => $nummer,
            ]);

            if ($result['success']) {
                $erfolg++;
            } else {
                // 🔥 NEU: Fehler sammeln
                $fehlgeschlagen[] = "#$nummer ($datum): " . ($result['error'] ?? $this->lang->get('admin_sendeplan_serie_unknown_error', 'Unbekannt'));
            }
        }

        // 5. Erfolgs-/Fehler-Meldung
		$msg = str_replace('{count}', (string)$erfolg, $this->lang->get('admin_sendeplan_serie_created', 'Serie angelegt: {count} Termine'));
		if ($uebersprungen > 0) {
			$msg .= ' · ' . str_replace('{count}', (string)$uebersprungen, $this->lang->get('admin_sendeplan_serie_skipped', '{count} wegen Konflikten übersprungen'));
		}
		if (!empty($fehlgeschlagen)) {
			$details = implode(' | ', array_slice($fehlgeschlagen, 0, 3));
			if (count($fehlgeschlagen) > 3) {
				$details .= ' ' . str_replace('{count}', (string)count($fehlgeschlagen), $this->lang->get('admin_sendeplan_serie_failed_more', '... ({count} insgesamt)'));
			}
			$msg .= ' · ' . str_replace(
				['{count}', '{details}'],
				[(string)count($fehlgeschlagen), $details],
				$this->lang->get('admin_sendeplan_serie_failed', '{count} fehlgeschlagen: {details}')
			);
		}

        unset($_SESSION['sendeplan_serie_konflikte']);
        header("Location: ./?AdminSendeplan&saved=1&msg=" . urlencode($msg));
        exit;
    }
	
}