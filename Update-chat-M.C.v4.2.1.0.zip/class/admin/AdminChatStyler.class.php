<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminChatStyler extends DbConectionMaker
{
    private string $style;
    private string $cssFile;
    private string $css;
    private array $variables = [];
    private array $categories = [];
    private string $message = '';
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        $lang = new LangJson();
        
        $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];
        
        $this->checkAccess();
        $this->initPaths($lang);
        $this->loadCss();
        $this->handlePost($lang);
        $this->renderTemplate($lang);
    }

    private function checkAccess(): void
    {
        $allowed = ['admin', 'grafik', 'co_admin'];
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userPriv, $allowed, true)) {
            header("Location: ../");
            exit;
        }
    }

    private function initPaths($lang): void
    {
        $this->style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'style_chat';
        $this->css = "styles/{$this->style}/style.css";
        $this->cssFile = "styles/{$this->style}/variables.css";
        
        if (!is_dir("styles/{$this->style}")) {
            $this->showStyleError($lang);
            exit;
        }
        
        if (!file_exists($this->cssFile)) {
            $this->showStyleError($lang);
            exit;
        }
    }

    private function showStyleError($lang): void
    {
        ob_start();
        
        echo "<div>
            <h2>⚠️ " . ($lang->get('admin_styler_error_title') ?? 'Style nicht konfigurierbar') . "</h2>
            <p>" . ($lang->get('admin_styler_error_text') ?? 'Das Design') . " '<strong>" . htmlspecialchars($this->style, ENT_QUOTES, 'UTF-8') . "</strong>' " . ($lang->get('admin_styler_error_not_configurable') ?? 'ist nicht konfigurierbar.') . "</p>
            <p>" . ($lang->get('admin_styler_error_solution') ?? 'Bitte wähle ein anderes Design unter') . " <a href='./?AdminPropertyIndex'>" . ($lang->get('admin_styler_error_link') ?? 'Design & Sprache') . "</a>.</p>
        </div>";
        
        $content = ob_get_clean();
        
        $pageTitle  = $lang->get('admin_styler_page_title') ?? 'Chat Styler';
        $backLink   = './?AdminIndex';
        $footerNote = '';
        
        include dirname(__DIR__, 2) . '/styles/admin_tpl/admin_master_template.php';
    }

    private function loadCss(): void
    {
        $cssContent = file_get_contents($this->cssFile);
        
        if ($cssContent === false) {
            $this->renderError();
            exit;
        }
        
        preg_match('/:root\s*{([^}]*)}/s', $cssContent, $matches);

        $currentCategory = 'Allgemein';

        if (!empty($matches[1])) {
            $lines = explode("\n", $matches[1]);

            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '') continue;

                if (preg_match('/\/\*\s*(.+?)\s*\*\//', $line, $match)) {
                    $currentCategory = $match[1];
                    continue;
                }

                if (str_contains($line, '--') && str_contains($line, ':')) {
                    [$key, $value] = explode(":", $line, 2);

                    $key = trim($key);
                    $value = trim($value, " ;");

                    if ($key === '--img' && preg_match('/^url\((["\']?)(.*?)\1\)$/', $value, $m)) {
                        $value = $m[2];
                    }

                    $this->variables[$key] = $value;
                    $this->categories[$key] = $currentCategory;
                }
            }
        }
    }
    
    private function normalizeChatColor(string $value): string
    {
        $value = trim($value);

        if (str_starts_with($value, '#')) {
            return strtoupper(substr($value, 1));
        }

        if (preg_match('/rgba?\((.*?)\)/i', $value, $m)) {
            $parts = explode(',', $m[1]);
            $r = (int)trim($parts[0]);
            $g = (int)trim($parts[1]);
            $b = (int)trim($parts[2]);
            return sprintf("%02X%02X%02X", $r, $g, $b);
        }

        return $value;
    }
    
    private function handlePost($lang): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            $this->message = "<div class='message error'>" . ($lang->get('admin_styler_error_csrf') ?? 'Ungültiger CSRF Token!') . "</div>";
            return;
        }

        foreach ($_POST as $key => $value) {
            if (!isset($this->variables[$key])) continue;

            $value = trim($value);
            
            if ($key === '--img') {
                if (preg_match('/^url\(/', $value)) {
                    $this->variables[$key] = $value;
                } else {
                    $filename = trim($value, " '\"");
                    $filename = basename($filename);
                    $this->variables[$key] = $filename === '' ? "none" : "url('hintergrund/$filename')";
                }
                continue;
            }

            if (in_array($key, ['--Textfarbe', '--Systemfarbe'], true)) {
                $this->variables[$key] = $this->normalizeChatColor($value);
            } else {
                $this->variables[$key] = $value;
            }
        }

        $this->saveCss();

        $this->message = '<div id="successBanner" class="success-banner">   
                            <span>✅ ' . ($lang->get('admin_styler_saved_success') ?? 'Gespeichert erfolgreich!') . '</span>
                            <span class="close-btn" onclick="closeSuccessBanner()">✖</span>
                        </div>';
    }

    private function saveCss(): void
    {
        $newContent = ":root {\n";
        $lastCategory = '';

        foreach ($this->variables as $key => $value) {
            $categoryName = $this->categories[$key] ?? 'Allgemein';

            if ($categoryName !== $lastCategory) {
                $newContent .= "\n  /* $categoryName */\n";
                $lastCategory = $categoryName;
            }

            $newContent .= "  $key: $value;\n";
        }

        $newContent .= "}\n";

        file_put_contents($this->cssFile, $newContent, LOCK_EX);
    }

    private function isColor(string $value): bool
    {
        $value = trim($value);
        
        return (bool)preg_match('/^#([a-fA-F0-9]{3}|[a-fA-F0-9]{6})$/', $value)
            || (bool)preg_match('/^rgba?\(/', $value)
            || (bool)preg_match('/^hsl\(/', $value);
    }

    private function getLabel(string $key, $lang): string
    {
        $map = [
            '--Textfarbe' => 'admin_styler_label_textfarbe',
            '--Systemfarbe' => 'admin_styler_label_systemfarbe',
            '--Botfarbe' => 'admin_styler_label_botfarbe',
            '--color-text-webfarbe' => 'admin_styler_label_textfarbe_webseite',
            '--color-backround' => 'admin_styler_label_hintergrundfarbe',
            '--color-border' => 'admin_styler_label_rahmenfarbe',
            '--color-box' => 'admin_styler_label_boxenfarbe',
            '--color-link' => 'admin_styler_label_links',
            '--color-link-hover' => 'admin_styler_label_links_hover',
            '--color-button-zeilen' => 'admin_styler_label_button_zeilen',
            '--color-button-hover' => 'admin_styler_label_button_hover',
            '--img' => 'admin_styler_label_hintergrund_bild',
            '--font-family' => 'admin_styler_label_schriftart',
            '--font-size-small' => 'admin_styler_label_klein',
            '--font-size-base' => 'admin_styler_label_base',
            '--font-size-large' => 'admin_styler_label_gross',
            '--font-size-xlarge' => 'admin_styler_label_extragross',
            '--banner_chat-on-off' => 'admin_styler_label_banner_chat',
            '--banner_index-on-off' => 'admin_styler_label_banner_index',
            '--uhrzeit-on-off' => 'admin_styler_label_uhrzeit',
            '--befehle-on-off' => 'admin_styler_label_befehle',
        ];
        
        $langKey = $map[$key] ?? '';
        return $langKey ? $lang->get($langKey, $key) : $key;
    }

    private function getCategoryName(string $category, $lang): string
    {
        $map = [
            'Farben' => 'admin_styler_category_colors',
            'Hintergrund' => 'admin_styler_category_background',
            'Schrift' => 'admin_styler_category_font',
            'Elemente ein- ausblenden' => 'admin_styler_category_elements',
        ];
        
        $langKey = $map[$category] ?? '';
        return $langKey ? $lang->get($langKey, $category) : $category;
    }

    private function renderError(): void
    {
        echo "<div class='error-box'>CSS Datei nicht gefunden: " . htmlspecialchars($this->cssFile, ENT_QUOTES, 'UTF-8') . "</div>";
    }

    private function renderTemplate($lang): void
    {
        $csrfToken = $this->csrfToken;
        $variables = $this->variables;
        $categories = $this->categories;
        $message = $this->message;
        $css = $this->css;
        $style = $this->style;

        // Gruppierung nach Kategorien mit übersetzten Kategorienamen
        $groupedVariables = [];

        foreach ($this->variables as $key => $value) {
            $category = $this->categories[$key] ?? 'Allgemein';
            $categoryName = $this->getCategoryName($category, $lang);

            $groupedVariables[$categoryName][] = [
                'key'   => $key,
                'value' => $value,
                'label' => $this->getLabel($key, $lang)
            ];
        }

        // Background Bilder
        $backgroundDir = "styles/{$this->style}/hintergrund/";
        $backgroundFiles = [];
        
        if (is_dir($backgroundDir)) {
            $files = scandir($backgroundDir);
            if ($files !== false) {
                $backgroundFiles = array_filter($files, fn($f) => (bool)preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $f));
            }
        }

        $isColor = fn($value) => $this->isColor($value);

        include "styles/admin_tpl/indexChatStyler.tpl.html";
    }
}