<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

class MessagesForJs extends EtChatConfig
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function getStruct(string $key): ?object
    {
        if ($this->lang !== null) {
            return $this->lang->getStruct($key);
        }
        return null;
    }

    private function getStructAttr(string $key, string $attr, string $default = ''): string
    {
        $struct = $this->getStruct($key);
        if ($struct && isset($struct->attributes[$attr])) {
            return $struct->attributes[$attr];
        }
        return $default;
    }

    private function getStructValue(string $key, string $default = ''): string
    {
        $struct = $this->getStruct($key);
        if ($struct && isset($struct->value)) {
            return $struct->value;
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();

        // Session starten falls nicht vorhanden
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/javascript; charset=utf-8');

        // ===== MODERNE SPRACHE LADEN =====
        $this->lang = new LangJson();

        $_SESSION['etchat_'.$this->_prefix.'chek_user_ajax_getted_data'] = array();

        // ============================================================
        // ALLE TEXTE AUS DER JSON LADEN - MIT json_encode()
        // ============================================================

        // 1. START PROPERTY LINKS (Array)
        for ($i = 1; $i <= 12; $i++) {
            $key = "start_prop_link_{$i}";
            $default = match($i) {
                1 => 'Anzeige säubern (cls)',
                2 => 'Verlauf anzeigen',
                3 => 'Nachrichtensound:',
                4 => 'alle an',
                5 => 'aus',
                6 => 'Passwortänderung',
                7 => 'Neues PW:',
                8 => 'nur privat an',
                9 => 'Systemnachrichten anzeigen',
                10 => 'Passwortschutz entfernen',
                11 => 'Avatar hochladen/löschen',
                12 => '-----------------------------------------------',
                default => ''
            };
            $value = $this->getText($key, $default);
            echo "var lang_start_prop_link_{$i}=" . json_encode($value) . ";\n";
        }

        // 2. AVATAR TEXT
        $avatarText = $this->getText('avatar_text', 'Ideal sind Bilder für Avatare, wenn sie ein quadratisches Format haben. Beachten Sie, dass die Änderung des Avatars nach dem Hochladen einige Sekunden dauern kann. Bitte wählen Sie eine Bilddatei:');
        echo "var lang_avatar_text=" . json_encode($avatarText) . ";\n";

        // 3. WARNING USER AWAY 1
        $title1 = $this->getText('warning_user_away_1_title', 'Warnung!');
        $text1 = $this->getText('warning_user_away_1_text', 'Dieser Benutzer wird aktuell nicht in der Online-Liste geführt. Der Benutzer hat sich entweder erst vor wenigen Sekunden in den Chat eingeloggt oder den Chat bereits verlassen.');
        echo "var lang_warning_user_away_1_1=" . json_encode($title1) . ";\n";
        echo "var lang_warning_user_away_1_2=" . json_encode($text1) . ";\n";

        // 4. WARNING USER AWAY 2
        $title2 = $this->getText('warning_user_away_2_title', 'Warnung!');
        $text2 = $this->getText('warning_user_away_2_text', 'Der Empfänger dieser Privatnachricht hat den Chat bereits verlassen.');
        echo "var lang_warning_user_away_2_1=" . json_encode($title2) . ";\n";
        echo "var lang_warning_user_away_2_2=" . json_encode($text2) . ";\n";

        // 5. REMOVE PW WIN
        $removePwKeys = [
            'title' => 'Passwortschutz aufheben für:',
            'text1' => 'Um den Passwortschutz für deinen Benutzernmen zu deaktivieren, bestätige dies durch die eingabe deines Passworts.',
            'text2' => 'Beachte!',
            'text3' => 'Nach der Bestätigung wirst du aus dem Chat ausgeloggt.',
            'button' => 'Passwortschutz aufheben',
            'confirm' => 'Ja, ich möchte das Passwort dauerhaft entfernen!',
            'confirm_error' => 'Bitte bestätige die Löschung des Passworts!'
        ];
        foreach ($removePwKeys as $suffix => $default) {
            $key = "remove_pw_win_{$suffix}";
            $value = $this->getText($key, $default);
            echo "var lang_remove_pw_win_{$suffix}=" . json_encode($value) . ";\n";
        }

        // 6. REGISTER
        $regLink = $this->getText('register_title', 'Namen durch Passwort schützen');
        echo "var lang_start_reg_link=" . json_encode($regLink) . ";\n";
        echo "var lang_start_reg_after_registering=" . json_encode($this->getText('start_reg_after_registering', 'Registrierung erfolgreich!')) . ";\n";
        echo "var lang_start_reg_after_registering_link=" . json_encode($this->getText('register_after_link', 'Chat verlassen')) . ";\n";
        
        $registerKeys = [
            'title' => 'Registriere',
            'pw1' => 'Passwort:',
            'pw2' => 'Passwort wiederholen:',
            'button_register' => 'Registrieren',
            'button_cancel' => 'Abbrechen',
            'before_text' => 'Durch die Vergabe eines Passwortes können Sie Ihren Chatnamen dauerhaft reservieren. Wenn Sie eine E-Mailadresse angeben müssen Sie diese frei schalten und können sich das Passwort bei vergessen wieder zusenden lassen.',
            'after_text' => 'Vielen Dank für Ihre Registrierung. Beim erneuten Anmelden im Chat werden Sie zur Passworteingabe aufgefordert.',
            'after_link' => 'Chat verlassen',
            'error' => 'Passwörter sind nicht identisch! Bitte korrigieren.'
        ];
        foreach ($registerKeys as $suffix => $default) {
            $key = "register_{$suffix}";
            $value = $this->getText($key, $default);
            echo "var lang_start_reg_{$suffix}=" . json_encode($value) . ";\n";
        }
        
        $registerbeforetext = $this->getText('register_before_text', 'Durch die Vergabe eines Passwortes können Sie Ihren Chatnamen dauerhaft reservieren. Wenn Sie eine E-Mailadresse angeben müssen Sie diese frei schalten und können sich das Passwort bei vergessen wieder zusenden lassen.');
        echo "var lang_register_before_text=" . json_encode($registerbeforetext) . ";\n";

        // 7. START MESSAGE
        $startMsg = $this->getText('start_message', 'an alle im Raum:');
        echo "var lang_start_1=" . json_encode($startMsg) . ";\n";

        // 8. AJAX INACTIVE WARNING
        $ajaxWarn = $this->getText('ajax_inactive_warning', 'du bist zu lange inaktiv und wirst in 30 sek. ausgeloggt...');
        echo "var lang_AjaxReadRequest_1=" . json_encode($ajaxWarn) . ";\n";
        $_SESSION['etchat_'.$this->_prefix.'chek_user_ajax_getted_data'][] = $ajaxWarn;

        // 9. RECEIVER RESULT JSON
        $rec1 = $this->getText('receiveresultjson_1', 'an');
        $rec2 = $this->getText('receiveresultjson_2', 'privat');
        echo "var lang_receiveResultJSON_1=" . json_encode($rec1) . ";\n";
        echo "var lang_receiveResultJSON_2=" . json_encode($rec2) . ";\n";

        // 10. RECEIVER RESULT PRIVAT
        $priv1 = $this->getText('receiveresultjson_priv_1', 'im Chat');
        $priv2 = $this->getText('receiveresultjson_priv_2', 'im Fenster');
        $priv3 = $this->getText('receiveresultjson_priv_3', 'Antworten in diesem Fenster');
        echo "var lang_receiveResultJSON_priv_1=" . json_encode($priv1) . ";\n";
        echo "var lang_receiveResultJSON_priv_2=" . json_encode($priv2) . ";\n";
        echo "var lang_receiveResultJSON_priv_3=" . json_encode($priv3) . ";\n";

        // 11. SEND BUTTON
        $sendBtn = $this->getText('send_button', 'Versende...');
        echo "var lang_send_1=" . json_encode($sendBtn) . ";\n";

        // 12. HISTORY WINDOW
        $historyTitle = $this->getText('history_window_title', 'Verlauf');
        echo "var lang_historyWindow_1=" . json_encode($historyTitle) . ";\n";

        // 13. UPDATE USER ONLINE ANZEIGE
        $update1 = $this->getText('updateuseronlineanzeige_1', 'Räume- und Useranzeige');
        $update2 = $this->getText('updateuseronlineanzeige_2', 'User im Chat:');
        $update3 = $this->getText('updateuseronlineanzeige_3', 'Benutzer anspechen');
        echo "var lang_updateUserOnlineAnzeige_1=" . json_encode($update1) . ";\n";
        echo "var lang_updateUserOnlineAnzeige_2=" . json_encode($update2) . ";\n";
        echo "var lang_updateUserOnlineAnzeige_3=" . json_encode($update3) . ";\n";

        // 14. CHANGE USER EVENT PRIVAT
        $privMsg1 = $this->getText('privat_messages_1', 'privat an');
        $privMsg2 = $this->getText('privat_messages_2', 'Privat beenden');
        echo "var lang_changeUserEvent_privat_1=" . json_encode($privMsg1) . ";\n";
        echo "var lang_changeUserEvent_privat_2=" . json_encode($privMsg2) . ";\n";

        // 15. TITLE ALERT
        $titleAlert = $this->getText('title_alert', 'Neue Nachricht/en');
        echo "var lang_titleAlert=" . json_encode($titleAlert) . ";\n";

        // 16. ROOM ENTER MESSAGE
        $roomMsg = $this->getText('room_enter_message', 'betritt den Raum');
        echo "var lang_changeUserEvent_room_1=" . json_encode($roomMsg) . ";\n";
        $_SESSION['etchat_'.$this->_prefix.'chek_user_ajax_getted_data'][] = $roomMsg;

        // 17. INFO BLOCK ITEMS
        $infoblockDefaults = [
            1 => 'Benutzer:',
            2 => 'Benutzer ansprechen',
            3 => 'Privatnachricht im Chatfenster',
            4 => 'Privatchat im separaten Fenster',
            5 => 'Nachrichten blokieren',
            6 => 'alle',
            7 => 'nur private'
        ];
        for ($i = 1; $i <= 7; $i++) {
            $key = "infoblock_items_{$i}";
            $value = $this->getText($key, $infoblockDefaults[$i]);
            echo "var lang_changeUserEvent_infoblock_{$i}=" . json_encode($value) . ";\n";
        }

        // 18. ADMINU TEXTS
        $adminuDefaults = [
            1 => 'User durch die Eintragung der IP in die BlackList aus dem Chat werfen oder nur Kicken? (Die IP kann nur durch Administrator aus der BlackList entfernt werden. Nach der Bestätigung dauert es einige Minuten, bis der blokierte User aus der Onileanzeige genommen wird.)',
            2 => 'Ausführen',
            3 => 'ist ein',
            4 => 'und darf daher nicht administriert werden.',
			5 => 'Einwahlpunkt anzeigen'
        ];
        for ($i = 1; $i <= 5; $i++) {
            $key = "adminu_texts_{$i}";
            $value = $this->getText($key, $adminuDefaults[$i]);
            echo "var lang_changeUserEvent_adminu_{$i}=" . json_encode($value) . ";\n";
        }

        // 19. ADMINU OPTIONS
        $adminuOptDefaults = [
            1 => 'Kick User',
            2 => '10 Minuten',
            3 => '30 Minuten',
            4 => '1 Stunde',
            5 => '3 Stunden',
            6 => '1 Tag',
            7 => '1 Woche',
            8 => 'Für immer'
        ];
        for ($i = 1; $i <= 8; $i++) {
            $key = "adminu_options_{$i}";
            $value = $this->getText($key, $adminuOptDefaults[$i]);
            echo "var lang_changeUserEvent_adminu_opt_{$i}=" . json_encode($value) . ";\n";
        }

        // 20. ROOM ERRORS
        $roomErr1 = $this->getText('room_errors_1', 'Sie haben keine Rechte um diesen Raum zu betretten.');
        $roomErr2 = $this->getText('room_errors_2', 'OK');
        echo "var lang_changeUserEvent_notallowedroom_1=" . json_encode($roomErr1) . ";\n";
        echo "var lang_changeUserEvent_notallowedroom_2=" . json_encode($roomErr2) . ";\n";

        // 21. ROOM PASSWORD MESSAGES
        $pwRoom1 = $this->getText('room_password_messages_1', 'Dieser Raum ist geschützt durch einen Passwort. Bitte Passwort eingeben:');
        $pwRoom2 = $this->getText('room_password_messages_2', 'Passwort ist Falsch!');
        echo "var lang_changeUserEvent_pwroom_1=" . json_encode($pwRoom1) . ";\n";
        echo "var lang_changeUserEvent_pwroom_2=" . json_encode($pwRoom2) . ";\n";

        // 22. STATUS LINK
        $statusLink = $this->getText('status_link', 'Benutzerstatus');
        echo "var lang_statuslink=" . json_encode($statusLink) . ";\n";

        // ============================================================
        // 23. STATUS DEFINITIONEN (STRUCT)
        // ============================================================
        echo "var lang_status_imgname = [];\n";
        echo "var lang_status_text = [];\n";
        echo "var lang_status_rights = [];\n";
        
        if ($this->lang !== null && method_exists($this->lang, 'getAllStructs')) {
            $allStructs = $this->lang->getAllStructs();
            
            foreach ($allStructs as $key => $struct) {
                if (strpos($key, 'status_') !== 0) {
                    continue;
                }
                
                $imagename = $key;
                $text = $struct->value ?? '';
                $rights = $struct->attributes['rights'] ?? 'all';
                
                if (!empty($text)) {
                    $rightsArray = array_map('trim', explode(',', $rights));
                    
                    foreach ($rightsArray as $singleRight) {
                        echo "lang_status_imgname.push(" . json_encode($imagename) . ");\n";
                        echo "lang_status_text.push(" . json_encode($text) . ");\n";
                        echo "lang_status_rights.push(" . json_encode($singleRight) . ");\n";
                    }
                }
            }
        }

        // ============================================================
        // 24. DIALOG TITEL
        // ============================================================
        $dialogKeys = [
            'dialog_admin' => 'Adminbereich',
            'dialog_admin_popup' => 'Adminbereich in einem separaten Fenster öffnen',
            'dialog_djbox' => 'DJ Box',
            'dialog_team' => 'Team',
            'dialog_bewerbung' => 'Bewerbung',
            'dialog_wunschbox' => 'Gruß & Wunschbox',
            'dialog_sendeplan' => 'Sendeplan',
            'dialog_titellist' => 'Titel-Liste',
            'dialog_toplist' => 'Top-Liste',
            'dialog_gallery' => 'Gallery',
            'dialog_profil' => 'Mein Benutzer Profil',
            'dialog_settings' => 'Einstellungen',
            'dialog_smileys' => 'Smileys',
            'dialog_color' => 'Schrift',
            'dialog_avatar' => 'Avatar-Upload',
            'dialog_upload' => 'Bildupload',
            'dialog_register' => 'Benutzernamen schützen',
            'dialog_unregister' => 'Passwort entfernen',
            'dialog_password' => 'Passwort',
            'dialog_user_manage' => 'Benutzer verwalten',
            'dialog_welcome_gast' => 'Willkommen Gast',
            'dialog_room_not_allowed' => 'Raum nicht erlaubt',
            'dialog_warning' => 'Hinweis'
        ];
        foreach ($dialogKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // ============================================================
        // 25. BUTTON TEXTE
        // ============================================================
        $buttonKeys = [
            'button_ok' => 'OK',
            'button_cancel' => 'Abbrechen',
            'button_save' => 'Speichern',
            'button_delete' => 'Löschen',
            'button_register' => 'Registrieren',
            'button_upload' => 'Hochladen',
            'button_send' => 'Senden',
            'button_close' => 'Schließen',
            'button_remove' => 'Entfernen',
            'button_execute' => 'Ausführen',
            'button_loading' => 'Registriere...',
            'button_logout' => 'Logout...'
        ];
        foreach ($buttonKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // ============================================================
        // 26. PASSWORT ÄNDERN
        // ============================================================
        $passwordKeys = [
            'password_new' => 'Neues Passwort:',
            'password_repeat' => 'Passwort wiederholen:',
            'password_old' => 'Passwort:',
            'password_email_optional' => '📧 E-Mail (optional):',
            'password_register' => 'Registrieren',
            'password_remove' => 'Entfernen',
            'password_cancel' => 'Abbrechen',
            'password_enter' => 'Bitte Passwort eingeben:',
            'password_confirm_remove' => 'Möchtest du deinen Benutzernamen wirklich von der Passwort-Sicherung befreien?',
            'password_confirm_remove_warning' => 'ACHTUNG:',
            'password_confirm_remove_text' => 'Der Name ist danach wieder für jeden frei zugänglich!'
        ];
        foreach ($passwordKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // ============================================================
        // 27. FEHLERMELDUNGEN
        // ============================================================
        $errorKeys = [
            'error_only_registered' => 'Nur registrierte Benutzer können diese Funktion nutzen.',
            'error_password_mismatch' => '❌ Die Passwörter stimmen nicht überein!',
            'error_password_short' => '❌ Passwort muss mindestens 8 Zeichen lang sein!',
            'error_password_weak' => '❌ Passwort muss mindestens 3 der 4 Kriterien enthalten:\n- Großbuchstaben\n- Kleinbuchstaben\n- Zahlen\n- Sonderzeichen',
            'error_password_changed' => '✅ Passwort erfolgreich geändert!',
            'error_password_failed' => '❌ Fehler beim Ändern des Passworts:\n\n',
            'error_network' => '❌ Netzwerkfehler! Bitte versuche es später erneut.',
            'error_enter_password' => '❌ Bitte Passwort eingeben!',
            'error_invalid_email' => '❌ Bitte eine gültige E-Mail-Adresse eingeben!',
            'error_register_failed' => '❌ Fehler bei der Registrierung:',
            'error_unknown' => '❌ Unbekannter Fehler',
            'error_upload_failed' => '❌ Upload gescheitert (Fehler) ',
            'error_connection_failed' => '❌ Verbindung zum Server fehlgeschlagen.'
        ];
        foreach ($errorKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // ============================================================
        // 28. PRIVAT CHAT
        // ============================================================
        $privateKeys = [
            'private_chat_title' => '💬 Privat mit ',
            'private_chat_placeholder' => 'Nachricht schreiben...',
            'private_user_not_online' => 'Benutzer nicht erreichbar',
            'private_user_not_online_text' => 'Der Benutzer ist nicht mehr online.',
            'private_opponent_offline' => '⚠️ Benutzer nicht erreichbar - Der Benutzer ist nicht mehr online.'
        ];
        foreach ($privateKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // ============================================================
        // 29. AVATAR UPLOAD
        // ============================================================
        $avatarKeys = [
            'avatar_hint' => '💡 Zoomen mit Mausrad, verschieben mit gedrückter linker Maustaste.',
            'avatar_no_image' => '❌ Kein gültiges Bild zum Hochladen.',
            'avatar_success' => '✅ Avatar erfolgreich hochgeladen!',
            'avatar_delete_confirm' => 'Möchtest du deinen Avatar wirklich löschen?',
            'avatar_delete_success' => '✅ Avatar erfolgreich gelöscht.',
            'avatar_delete_failed' => '❌ Löschen fehlgeschlagen (Fehler)',
            'avatar_select_file' => 'Beachte, dass Änderungen des Avatars nach dem Hochladen erst nach einigen Sekunden wirksam werden. Bitte wähle eine Bilddatei:',
            'avatar_button_save' => '💾 Speichern & Hochladen',
            'avatar_button_delete' => '🗑️ Löschen'
        ];
        foreach ($avatarKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // ============================================================
        // 30. BILD UPLOAD
        // ============================================================
        $uploadKeys = [
            'upload_select_file' => 'Bitte wählen Sie eine Bilddatei:',
            'upload_rules_accept' => 'Ich akzeptiere die Uploadregeln.',
            'upload_rules_title' => 'Uploadregeln',
            'upload_rules_agree' => 'Du musst unseren Uploadregeln zustimmen, wenn Du Bilder hochladen möchtest.',
            'upload_select_file_first' => 'Bitte wähle zuerst eine Datei aus.',
            'upload_gif_too_large' => 'Animierte GIFs dürfen max. 1,5 MB groß sein!',
            'upload_file_too_large' => 'Datei zu groß!',
            'upload_invalid_type' => 'Unzulässiger Dateityp!',
            'upload_success' => 'Datei erfolgreich hochgeladen!',
            'upload_failed' => 'Upload gescheitert! (Error ',
            'upload_placeholder' => ' ... Text zum Bild (optional)',
            'upload_max_size' => '(Max. Größe: GIF 1,5MB / andere Bilder bis 9MB werden serverseitig verkleinert)',
            'upload_footer' => 'Uploadscript by Fizzy Lemon'
        ];
        foreach ($uploadKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // Upload Rules Text
        $rulesText = $this->getText('upload_rules_text', '');
        echo "var lang_upload_rules_text=" . json_encode($rulesText) . ";\n";

        // ============================================================
        // 31. WÜRFEL
        // ============================================================
        $wuerfel = $this->getText('wuerfel_too_many', 'Du hast bereits {count} mal gewürfelt. Bitte warte {minutes} Minuten.');
        echo "var lang_wuerfel_too_many=" . json_encode($wuerfel) . ";\n";

        // ============================================================
        // 32. SONSTIGE
        // ============================================================
        $miscKeys = [
            'loading' => 'Laden...',
            'loading_error' => 'Fehler beim Laden',
            'close' => 'Schließen',
            'warning' => 'Hinweis',
            'smileys_loading' => 'Lade Smileys...',
            'admin_room_warning' => 'Sie haben keine Rechte um diesen Raum zu betretten.',
            'room_password_enter' => 'Dieser Raum ist geschützt durch einen Passwort. Bitte Passwort eingeben:',
            'room_password_wrong' => 'Passwort ist Falsch!',
            'user_profile' => 'Benutzer Profil',
            'user_online' => 'online',
            'user_offline' => 'offline',
            'user_typing' => 'schreibt...',
            'register_email_sent_title' => '📧 <strong>Bestätigungs-E-Mail gesendet!</strong>',
            'register_email_instruction' => 'Bitte klicke auf den Link inerhalb 30min. in der E-Mail, um deine Registrierung abzuschließen.',
            'register_guest_until_confirm' => 'Du bleibst solange Gast, bis du deine E-Mail bestätigt hast.',
            'room_password_enter_placeholder' => 'Passwort eingeben',
            'player_hide_js' => '⇓ Player ausblenden ⇓',
            'player_back_js' => '⇓ Player einblenden ⇓'
        ];
        foreach ($miscKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }

        // ============================================================
        // 33. STATUS-VARIABLEN FÜR chat.js
        // ============================================================
        echo "var lang_status_online=" . json_encode($this->getText('status_online', 'online')) . ";\n";
        echo "var lang_status_invisible=" . json_encode($this->getText('status_invisible', 'unsichtbar')) . ";\n";
        echo "var lang_status_busy=" . json_encode($this->getText('status_busy', 'beschäftigt')) . ";\n";
        echo "var lang_status_away=" . json_encode($this->getText('status_away', 'kurz weg')) . ";\n";
        echo "var lang_status_telephone=" . json_encode($this->getText('status_telephone', 'telefoniere')) . ";\n";
        
        // ============================================================
        // 34. SCROLL BUTTON TEXTE
        // ============================================================
        echo "var lang_scroll_an=" . json_encode($this->getText('scroll_an', 'Scroll an')) . ";\n";
        echo "var lang_scroll_aus=" . json_encode($this->getText('scroll_aus', 'Scroll aus')) . ";\n";
        
        // ============================================================
        // 35. UNREGISTER PW TEXTE
        // ============================================================
        $unregisterKeys = [
            'unregister_success' => 'Passwort wurde erfolgreich entfernt!',
            'unregister_no_password' => 'Dieser Account hat kein Passwort gesetzt!',
            'unregister_no_permission' => 'Du hast keine Berechtigung, das Passwort zu entfernen!',
            'unregister_no_session' => 'Keine gültige Sitzung! Bitte logge dich neu ein.',
            'unregister_wrong_password' => 'Falsches Passwort! Bitte versuche es erneut.',
            'unregister_network_error' => 'Netzwerkfehler! Bitte versuche es später erneut.',
            'unregister_generic_error' => 'Fehler beim Entfernen des Passworts.'
        ];
        foreach ($unregisterKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }
        
        // ============================================================
        // 36. REMOVE PW CONFIRM
        // ============================================================
        echo "var lang_remove_pw_confirm=" . json_encode($this->getText('remove_pw_confirm', 'Ja, ich möchte das Passwort dauerhaft entfernen!')) . ";\n";
        echo "var lang_remove_pw_confirm_error=" . json_encode($this->getText('remove_pw_confirm_error', 'Bitte bestätige die Löschung des Passworts!')) . ";\n";
        
        // ============================================================
        // 37. LOGOUT COUNTDOWN TEXTE
        // ============================================================
        echo "var lang_logout_countdown_text=" . json_encode($this->getText('logout_countdown_text', 'Du wirst in {seconds} Sekunden automatisch ausgeloggt...')) . ";\n";
        echo "var lang_logout_countdown_text_2=" . json_encode($this->getText('logout_countdown_text_2', 'Du wirst in 3 Sekunden automatisch ausgeloggt...')) . ";\n";
        
        // ============================================================
        // 38. LOGIN FEHLERMELDUNGEN
        // ============================================================
        $loginKeys = [
            'login_maintenance_denied' => 'Der Chat befindet sich im Wartungsmodus. Nur Administratoren haben Zugriff.',
            'login_guest_denied' => 'Der Gast-Zugang ist zurzeit deaktiviert. Bitte registriere dich oder wende dich an den Administrator.',
            'login_invalid_username' => 'Ungültiger Benutzername. Bitte verwende nur Buchstaben, Zahlen und maximal 3 Sonderzeichen.'
        ];
        foreach ($loginKeys as $key => $default) {
            $value = $this->getText($key, $default);
            echo "var lang_{$key}=" . json_encode($value) . ";\n";
        }
    }
}
?>