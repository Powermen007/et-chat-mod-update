<?php
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, Json sprache, PDO Prepared Statements Get Set sicherheit usw.
*/

// 1. Config laden (VOR session_start)
require_once __DIR__ . "/config.php";

// 2. Session starten (NACH config)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. Klassen laden
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/LangJson.class.php";  // ← Neu!
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/Bewerbung.class.php";

// 4. Sprache laden (NEU!)
$lang = new LangJson();
$style = $_SESSION['etchat_' . $prefix . 'style'] ?? 'etchat_dino_styles';

// 5. Bewerbung-Objekt mit Fehlerbehandlung
try {
    $bewerbung = new Bewerbung();
} catch (Exception $e) {
    $style = 'etchat_dino_styles';
    $meldung = $lang->get('bewerbung_hinweis_restricted', 'Hinweis: Die Bewerbungsfunktion ist vorübergehend eingeschränkt.');
}

$meldung = '';

// Formularverarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') == 1) {
    try {
        $meldung = $bewerbung->senden($_POST);
    } catch (Exception $e) {
        $meldung = $lang->get('bewerbung_error_prefix', 'Fehler beim Senden:') . " " . $e->getMessage();
    }
}

// Felder aus DB laden – mit Fehlerbehandlung
$fields = [];
try {
    if (isset($bewerbung) && $bewerbung->getDb()) {
        $fields = $bewerbung->getDb()->sqlGet(
            "SELECT *
             FROM {$prefix}etchat_bewerbung_fields
             WHERE etchat_visible = 1
             ORDER BY etchat_sort_order ASC"
        );
    }
} catch (Exception $e) {
    $meldung = $lang->get('bewerbung_db_error', 'Datenbankfehler:') . " " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang->get('bewerbung_title', 'Bewerbung'); ?></title>
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style.css" rel="stylesheet">
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style-mobil-index.css" rel="stylesheet">
</head>
<body id="body">

<center><h2><?php echo $lang->get('bewerbung_title', 'Bewerbung'); ?></h2></center>

<?php if ($meldung): ?>
    <div class="meldung" style="background: <?= strpos($meldung, $lang->get('bewerbung_error_prefix', 'Fehler')) !== false ? $lang->get('bewerbung_meldung_error_bg', '#ff4c4c') : $lang->get('bewerbung_meldung_success_bg', '#4caf50') ?>; color: white; padding: 10px; margin: 10px; border-radius: 5px;">
        <?= htmlspecialchars($meldung) ?>
    </div>
<?php endif; ?>

<?php if (!empty($fields)): ?>
<form method="POST" action="" class="bewerbung-form">
    <input type="hidden" name="action" value="1">
    <input type="hidden" name="https_ceck" value="">
    <input type="hidden" name="www" value="">

    <?php echo $lang->get('bewerbung_hinweis_pflichtfelder', 'Bitte füllen Sie die mit <span class="pflichthinweis">*</span> gekennzeichneten Felder aus (Pflichtfelder).'); ?>

<?php
foreach ($fields as $f) {
    $rawName = $f['etchat_field_name'] ?? '';
    $name = preg_replace('/[^a-zA-Z0-9_]/', '_', $rawName);
    $label = htmlspecialchars($rawName);
    $required = !empty($f['etchat_required']) ? 'required' : '';
    $pflichthinweis = !empty($f['etchat_required']) ? ' <span class="pflichthinweis">*</span>' : '';
    $type = $f['etchat_field_type'] ?? 'text';
    $value = $_POST[$name] ?? '';

    switch ($type) {
        case 'text':
        case 'email':
        case 'date':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<input type='{$type}' name='{$name}' id='{$name}' {$required} value='" . htmlspecialchars($value) . "'><br>";
            break;

        case 'textarea':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<textarea name='{$name}' id='{$name}' {$required}>" . htmlspecialchars($value) . "</textarea><br>";
            break;

        case 'select':
            $options = json_decode($f['etchat_options'] ?? '', true) ?: [];
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<select name='{$name}' id='{$name}' {$required}>";
            echo "<option value=''>" . $lang->get('bewerbung_select_default', 'Bitte auswählen:') . "</option>";
            foreach ($options as $opt) {
                $sel = ($value == $opt) ? 'selected' : '';
                echo "<option value='" . htmlspecialchars($opt) . "' {$sel}>" . htmlspecialchars($opt) . "</option>";
            }
            echo "</select><br>";
            break;

        case 'checkbox':
            $options = json_decode($f['etchat_options'] ?? '', true) ?: [];
            echo "<label>{$label}:{$pflichthinweis}</label>";
            echo '<div class="musikrichtungen">';
            foreach ($options as $opt) {
                $chk = in_array($opt, (array)$value, true) ? 'checked' : '';
                echo '<div class="musikrichtung-option">';
                echo "<label><input type='checkbox' name='{$name}[]' value='" . htmlspecialchars($opt) . "' {$chk}> " . htmlspecialchars($opt) . "</label>";
                echo '</div>';
            }
            echo '</div><br>';
            break;
    }
}
?>

    <label for="web_php_de"><?php echo $lang->get('bewerbung_captcha_label', 'Bitte geben Sie die Zeichen ein:'); ?><span class="pflichthinweis">*</span></label>
    <div class="captcha-group">
        <img src="captcha.php" alt="Captcha" onclick="this.src='captcha.php?'+Math.random();" title="Klicken zum Neuladen">
        <input type="text" name="web_php_de" id="web_php_de" maxlength="5" required>
    </div>

    <button type="submit"><?php echo $lang->get('bewerbung_button_senden', 'Anfrage senden'); ?></button>
</form>
<?php else: ?>
    <p style="text-align: center; color: red;"><?php echo $lang->get('bewerbung_not_available', 'Das Bewerbungsformular ist aktuell nicht verfügbar. Bitte versuchen Sie es später erneut.'); ?></p>
<?php endif; ?>

</body>
</html>