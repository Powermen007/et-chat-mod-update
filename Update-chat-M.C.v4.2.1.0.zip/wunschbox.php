<?php
/*
ET-Chat Wunschbox – Öffentliches Formular
*/

// 1. Config laden (VOR session_start)
require_once __DIR__ . "/config.php";

// 2. Session starten (NACH config)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. Klassen laden
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/LangJson.class.php";
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/Wunschbox.class.php";
require_once __DIR__ . "/class/Sendeplan.class.php";

// 4. Sprache laden
$lang = new LangJson('', 'wb_sendeplan.json');

// 5. Style aus Session oder Fallback
$style = $_SESSION['etchat_' . $prefix . 'style'] ?? 'etchat_dino_styles';

// 🔥 NEU: Benutzerdaten aus Session holen
$currentUsername = $_SESSION['etchat_' . $prefix . 'username'] ?? '';
$currentWohnort = $_SESSION['etchat_' . $prefix . 'ort'] ?? '';
$isLoggedIn = !empty($currentUsername);

// 6. Objekte
$wunschbox = new Wunschbox();
$sendeplan = new Sendeplan();
$wunschbox->maybeAutoCleanup();

// 🔥 IP-Adresse ermitteln + Sperre prüfen
$user_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
    $user_ip = trim($ips[0]);
}

$ipBanned = $wunschbox->isIpBanned($user_ip);
$meldung = '';  // 🔥 WICHTIG: $meldung IMMER definieren!

// 7. Aktuelle Sendung ermitteln (tagübergreifend)
$now = new DateTime();
$currentDate = $now->format('Y-m-d');
$currentTime = $now->format('H:i:s');

// 🔥 NEU: Zusätzlich den Vortag prüfen (für Sendungen die um 22 Uhr starten)
$yesterday = new DateTime();
$yesterday->modify('-1 day');
$yesterdayDate = $yesterday->format('Y-m-d');

// Entries von heute UND gestern holen
$entries = $sendeplan->getEntries($yesterdayDate, $currentDate);

// 🔥 NEU: Alle aktiven Sendungen sammeln und die NEUESTE nehmen
$activeEntries = [];

foreach ($entries as $entry) {
    $zeit_von = $entry['zeit_von'];
    $zeit_bis = $entry['zeit_bis'];
    $datum = $entry['datum'];
    
    // Prüfen ob die Sendung tagübergreifend ist (zeit_bis < zeit_von)
    $isOvernight = $zeit_bis < $zeit_von;
    
    $isActive = false;
    
    if ($isOvernight) {
        // Tagübergreifende Sendung: z.B. 22:00 - 02:00
        if ($datum === $yesterdayDate) {
            // Gestern gestartet → prüfen ob currentTime >= zeit_von ODER currentTime <= zeit_bis
            if ($currentTime >= $zeit_von || $currentTime <= $zeit_bis) {
                $isActive = true;
            }
        } else {
            // Heute gestartet → prüfen ob currentTime >= zeit_von
            if ($currentTime >= $zeit_von) {
                $isActive = true;
            }
        }
    } else {
        // Normale Sendung (nicht tagübergreifend)
        if ($datum === $currentDate && $zeit_von <= $currentTime && $zeit_bis >= $currentTime) {
            $isActive = true;
        }
    }
    
    if ($isActive) {
        $activeEntries[] = $entry;
    }
}

// 🔥 NEU: Die NEUESTE aktive Sendung nehmen (nach datum + zeit_von sortieren)
$activeEntry = null;
if (!empty($activeEntries)) {
    // Sortieren: Neueste zuerst (datum absteigend, dann zeit_von absteigend)
    usort($activeEntries, function($a, $b) {
        // Erst nach Datum vergleichen (neueste zuerst)
        $dateCompare = strcmp($b['datum'], $a['datum']);
        if ($dateCompare !== 0) {
            return $dateCompare;
        }
        // Dann nach Startzeit (späteste zuerst)
        return strcmp($b['zeit_von'], $a['zeit_von']);
    });
    
    $activeEntry = $activeEntries[0];
}

// 8. Prüfen ob WB aktiv ist
$showForm = false;
$wunschboxAktiv = false;
$sendungsName = '';
$sendungsId = null;
$wunschboxMode = 'closed'; // 'live' | 'vorab' | 'closed'
$vorabSendungDatum = '';
$vorabSendungZeit = '';

if ($ipBanned) {
    // 🔥 IP gesperrt → Meldung setzen
    $meldung = $lang->get('wunschbox_ip_banned', 'Deine IP-Adresse wurde vorübergehend gesperrt. Bitte versuche es später erneut.');
    $showForm = false;
} else {
    // 🔥 NEU: Sendungs-ID aus URL ODER POST prüfen
	// (POST ist wichtig, wenn das Formular abgeschickt wurde)
	$urlSendungsId = 0;
	if (isset($_GET['sendungs_id']) && (int)$_GET['sendungs_id'] > 0) {
		$urlSendungsId = (int)$_GET['sendungs_id'];
	} elseif (isset($_POST['sendungs_id']) && (int)$_POST['sendungs_id'] > 0) {
		$urlSendungsId = (int)$_POST['sendungs_id'];
	}
    
    $targetEntry = null;
    
    if ($urlSendungsId > 0) {
        // Sendung aus der URL laden
        $targetEntry = $sendeplan->getEntry($urlSendungsId);
    }
    
    // Falls keine URL-Sendung angegeben → aktuell laufende Sendung
    if (!$targetEntry && $activeEntry) {
        $targetEntry = $activeEntry;
    }
    
    if ($targetEntry) {
        // Prüfen ob Wünsche erlaubt sind
        $wishCheck = $sendeplan->canSendWish($targetEntry);
        
        if ($wishCheck['allowed']) {
            $sendungsName = $targetEntry['sendungsname'];
            $sendungsId = $targetEntry['id'];
            $wunschboxAktiv = true;
            $showForm = true;
            $wunschboxMode = $wishCheck['mode'];
            
            // 🔥 NEU: Für Vorab-Modus: Sendungsdatum + Zeit
            if ($wishCheck['mode'] === 'vorab') {
                $vorabSendungDatum = date('d.m.Y', strtotime($targetEntry['datum']));
                $vorabSendungZeit = substr($targetEntry['zeit_von'], 0, 5) . ' - ' . substr($targetEntry['zeit_bis'], 0, 5);
            }
        } else {
            // Nicht erlaubt → evtl. Meldung setzen
            if ($wishCheck['reason'] === 'vorab_too_early') {
                $maxDays = $wishCheck['maxDays'] ?? 30;
                $meldung = str_replace(
                    '{days}',
                    (string)$maxDays,
                    $lang->get('wunschbox_vorab_too_early', 'Wünsche für diese Sendung sind erst {days} Tage vorher möglich.')
                );
            } elseif ($wishCheck['reason'] === 'wb_future') {
                $meldung = $lang->get('wunschbox_wb_future', 'Die Wunschbox öffnet erst mit Beginn der Sendung.');
            } elseif ($wishCheck['reason'] === 'wb_past') {
                $meldung = $lang->get('wunschbox_wb_past', 'Diese Sendung ist bereits vorbei.');
            } elseif ($wishCheck['reason'] === 'vorab_disabled') {
                $meldung = $lang->get('wunschbox_vorab_disabled', 'Vorab-Wünsche sind deaktiviert.');
            } elseif ($wishCheck['reason'] === 'wb_off') {
                $meldung = $lang->get('wunschbox_wb_closed', 'Die Wunschbox ist für diese Sendung geschlossen.');
            }
        }
    }
}

// 9. Bei POST: Wunsch speichern (nur wenn Formular sichtbar)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $showForm) {
    try {
        $postSendungsId = isset($_POST['sendungs_id']) ? (int)$_POST['sendungs_id'] : $sendungsId;
        $_POST['sendungs_id'] = $postSendungsId;
        
        $result = $wunschbox->saveWish($_POST);
        if ($result['success']) {
            $meldung = $lang->get('wunschbox_success', 'Dein Wunsch wurde erfolgreich gesendet!');
        } else {
            $meldung = $result['error'] ?? $lang->get('wunschbox_error', 'Fehler beim Senden.');
        }
    } catch (Exception $e) {
        $meldung = $lang->get('wunschbox_error_prefix', 'Fehler:') . " " . $e->getMessage();
    }
}

// 10. Template einbinden
include "styles/wunschbox.tpl.html";