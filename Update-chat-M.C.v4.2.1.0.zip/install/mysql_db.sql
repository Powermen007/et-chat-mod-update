
SET NAMES utf8mb4;


CREATE TABLE IF NOT EXISTS `etchat_bewerbungen` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `bewerber_daten` mediumtext NOT NULL,
  `status` enum('neu','in Bearbeitung','angenommen','abgelehnt','gegangen') NOT NULL DEFAULT 'neu',
  `kommentar` mediumtext DEFAULT NULL,
  `erstellt_am` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_bewerbung_fields` (
  `etchat_id` int(11) NOT NULL AUTO_INCREMENT,
  `etchat_field_name` varchar(50) NOT NULL,
  `etchat_field_type` enum('text','email','select','checkbox','textarea','date') NOT NULL,
  `etchat_options` longtext DEFAULT NULL COMMENT 'JSON-kodierte Optionen für select/checkbox',
  `etchat_required` tinyint(1) DEFAULT 0,
  `etchat_visible` tinyint(1) DEFAULT 1,
  `etchat_sort_order` int(11) DEFAULT 0,
  `etchat_custom` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`etchat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `etchat_bewerbung_fields` (`etchat_id`, `etchat_field_name`, `etchat_field_type`, `etchat_options`, `etchat_required`, `etchat_visible`, `etchat_sort_order`, `etchat_custom`) VALUES
(1, 'Betreff', 'select', '[\"Moderator Bewerbung\",\"Gast Moderator Bewerbung\",\"Gelegenheitsmoderator Bewerbung\",\"Chatwache\",\"Grafiker\",\"Techniker\",\"Sponsor\"]', 1, 1, 0, 0),
(2, 'E-Mail', 'email', NULL, 1, 1, 1, 0),
(3, 'Anrede', 'select', '[\"Herr\",\"Frau\",\"Divers\"]', 0, 1, 2, 0),
(4, 'Name', 'text', NULL, 1, 1, 3, 0),
(5, 'Modiename', 'text', NULL, 0, 1, 4, 0),
(6, 'Telefon', 'text', NULL, 0, 1, 5, 0),
(7, 'Alter', 'text', NULL, 1, 1, 6, 0),
(8, 'Geburtsdatum', 'date', NULL, 0, 1, 7, 0),
(9, 'Ort', 'text', NULL, 1, 1, 8, 0),
(10, 'Beruf', 'select', '[\"Vollzeit berufstätig\",\"Teilzeit berufstätig\",\"Schichtarbeit\",\"Selbstständig\",\"Rentner(in)\",\"Rentner(in) in Teilzeit\",\"Arbeitssuchend \\/ aktuell ohne Job\",\"Schüler(in)\",\"Student(in)\",\"Student(in) in Teilzeit\",\"Sonstiges\"]', 0, 1, 9, 0),
(11, 'Betriebssystem', 'select', '[\"Windows 11\",\"Windows 10\",\"Windows 8.1\",\"MacOS\",\"Linux\"]', 1, 1, 10, 0),
(12, 'CPU', 'text', NULL, 0, 1, 11, 0),
(13, 'Arbeitsspeicher', 'select', '[\"Ich habe 8 GB RAM\",\"Ich habe 16 GB RAM\",\"Ich habe 24 GB RAM\",\"Ich habe 32 GB RAM\",\"Ich habe 48 GB RAM\",\"Ich habe 64 GB RAM\",\"Ich habe mehr als 64 GB RAM\"]', 0, 1, 12, 0),
(14, 'Weitere Angaben Hardware', 'text', NULL, 0, 1, 13, 0),
(15, 'Internetverbindung', 'text', NULL, 0, 1, 14, 0),
(16, 'Musikarchiv', 'text', NULL, 1, 1, 15, 0),
(17, 'Streamerfahrung', 'select', '[\"Ich bin Neuling\",\"Ich habe weniger als 1 Jahr Erfahrung\",\"Ich habe mehr als 1 Jahr Erfahrung\",\"Ich habe mehr als 2 Jahr Erfahrung\",\"Ich habe mehr als 3 Jahr Erfahrung\",\"Ich habe mehr als 5 Jahr Erfahrung\"]', 1, 1, 16, 0),
(18, 'Sendesoftware', 'select', '[\"Radio Boss\",\"Mixxx\",\"Virtual DJ\",\"Flatcast Player\",\"BPM Studio\",\"Winamp\",\"Sam Broadcast 3\",\"Sam Broadcast 4\",\"Sonstiger Player\"]', 1, 1, 18, 0),
(19, 'Sendezeiten', 'select', '[\"Ich sende bevorzugt morgens\",\"Ich sende bevorzugt mittags\",\"Ich sende bevorzugt abends\",\"Ich sende bevorzugt nachts\",\"Flexibel\"]', 1, 1, 19, 0),
(20, 'Musikrichtung', 'checkbox', '[\"Schlager\",\"Techno\",\"Hip Hop\",\"Rap\",\"Trance\",\"Discofox\",\"Dance\",\"Electronic\",\"Gothic\",\"Rock\",\"Oldies\",\"Volksmusik\",\"Soul\",\"Funk\",\"Folk\",\"Pop\",\"House\",\"Country\",\"80er\",\"90er\",\"2000er\",\"Charts\",\"Sonstiges\",\"Alles\"]', 1, 1, 21, 0),
(21, 'Nachricht', 'textarea', NULL, 0, 1, 22, 0),
(22, 'Streamerfahrungen wenn ja wo', 'text', NULL, 0, 1, 17, 1);


CREATE TABLE IF NOT EXISTS `etchat_blacklist` (
  `etchat_blacklist_id` int(8) NOT NULL AUTO_INCREMENT,
  `etchat_blacklist_ip` varchar(255) NOT NULL,
  `etchat_blacklist_userid` int(8) NOT NULL,
  `etchat_blacklist_time` int(30) NOT NULL,
  PRIMARY KEY (`etchat_blacklist_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_config` (
  `etchat_config_id` int(11) NOT NULL,
  `etchat_config_radio_name` varchar(50) NOT NULL,
  `etchat_config_reloadsequenz` int(11) NOT NULL,
  `etchat_config_messages_im_chat` int(11) NOT NULL,
  `etchat_config_style` varchar(100) NOT NULL,
  `etchat_config_loeschen_nach` longtext NOT NULL,
  `etchat_config_lang` varchar(30) NOT NULL,
  `etchat_config_wu` int(4) NOT NULL,
  `etchat_config_wuan` int(5) NOT NULL,
  `etchat_config_wuza` tinyint(2) NOT NULL,
  `etchat_config_wupau` tinyint(2) NOT NULL,
  `etchat_config_yo` int(4) NOT NULL,
  `etchat_config_bi` int(4) NOT NULL,
  `etchat_config_biup` int(4) NOT NULL,
  `etchat_config_av` int(4) NOT NULL,
  `etchat_config_pro` tinyint(1) NOT NULL,
  `etchat_config_onlie_li` tinyint(1) NOT NULL,
  `etchat_config_radio_box` int(4) NOT NULL,
  `etchat_config_radio_box_hi` int(3) NOT NULL,
  `etchat_config_radio_box_li` varchar(300) NOT NULL,
  `etchat_config_wb` int(3) NOT NULL,
  `etchat_config_wb_li` varchar(300) NOT NULL,
  `etchat_config_user_online` int(3) NOT NULL,
  `etchat_config_name_user` tinyint(1) NOT NULL,
  `etchat_config_name_user_anz` tinyint(3) NOT NULL DEFAULT 10,
  `etchat_config_vollbild` int(3) NOT NULL,
  `etchat_config_admin_color` varchar(8) NOT NULL,
  `etchat_config_mod_color` varchar(8) NOT NULL,
  `etchat_config_user_color` varchar(8) NOT NULL,
  `etchat_config_gast_color` varchar(8) NOT NULL,
  `etchat_config_time` tinyint(1) NOT NULL,
  `etchat_config_chat_gender` tinyint(1) NOT NULL,
  `etchat_config_chat_privi` tinyint(1) NOT NULL,
  `etchat_config_chat_anzsmily` tinyint(2) NOT NULL DEFAULT 5,
  `etchat_config_ol_privi` tinyint(1) NOT NULL,
  `etchat_config_be_in_pic` tinyint(1) NOT NULL,
  `etchat_config_chat_pic` tinyint(1) NOT NULL,
  `etchat_config_scroll` tinyint(1) NOT NULL,
  `etchat_config_dj_box_li` varchar(300) NOT NULL,
  `etchat_config_dj_box` tinyint(1) NOT NULL,
  `etchat_config_radio_se_li` varchar(300) NOT NULL,
  `etchat_config_radio_se` tinyint(1) NOT NULL,
  `etchat_config_reg_user_an` tinyint(1) NOT NULL,
  `etchat_config_gast` tinyint(1) NOT NULL,
  `etchat_config_wartung` tinyint(1) NOT NULL,
  `etchat_config_reg_an_aus` tinyint(1) NOT NULL,
  `etchat_config_index_team` tinyint(1) DEFAULT 1,
  `etchat_config_team` tinyint(1) DEFAULT 1,
  `etchat_config_index_bewer` tinyint(1) DEFAULT 1,
  `etchat_config_bewer` tinyint(1) DEFAULT 1,
  `etchat_top_user_onoff` tinyint(1) NOT NULL,
  `etchat_top_user` tinyint(2) NOT NULL,
  `etchat_bot` tinyint(2) NOT NULL,
  `etchat_config_for_inactivity` int(8) NOT NULL DEFAULT 1800000,
  `etchat_tab_away_delay` int(4) NOT NULL DEFAULT 150,
  `etchat_config_file_retention_days` int(11) NOT NULL DEFAULT 7,
  UNIQUE KEY `etchat_config_id` (`etchat_config_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `etchat_config` (`etchat_config_id`, `etchat_config_radio_name`, `etchat_config_reloadsequenz`, `etchat_config_messages_im_chat`, `etchat_config_style`, `etchat_config_loeschen_nach`, `etchat_config_lang`, `etchat_config_wu`, `etchat_config_wuan`, `etchat_config_wuza`, `etchat_config_wupau`, `etchat_config_yo`, `etchat_config_bi`, `etchat_config_biup`, `etchat_config_av`, `etchat_config_pro`, `etchat_config_onlie_li`, `etchat_config_radio_box`, `etchat_config_radio_box_hi`, `etchat_config_radio_box_li`, `etchat_config_wb`, `etchat_config_wb_li`, `etchat_config_user_online`, `etchat_config_name_user`, `etchat_config_name_user_anz`, `etchat_config_vollbild`, `etchat_config_admin_color`, `etchat_config_mod_color`, `etchat_config_user_color`, `etchat_config_gast_color`, `etchat_config_time`, `etchat_config_chat_gender`, `etchat_config_chat_privi`, `etchat_config_chat_anzsmily`, `etchat_config_ol_privi`, `etchat_config_be_in_pic`, `etchat_config_chat_pic`, `etchat_config_scroll`, `etchat_config_dj_box_li`, `etchat_config_dj_box`, `etchat_config_radio_se_li`, `etchat_config_radio_se`, `etchat_config_reg_user_an`, `etchat_config_gast`, `etchat_config_wartung`, `etchat_config_reg_an_aus`, `etchat_config_index_team`, `etchat_config_team`, `etchat_config_index_bewer`, `etchat_config_bewer`, `etchat_top_user_onoff`, `etchat_top_user`, `etchat_bot`, `etchat_config_for_inactivity`, `etchat_tab_away_delay`, `etchat_config_file_retention_days`) VALUES
(1, 'ET-Chat Two v.4.2.1.0', 3000, 100, 'etchat_dino_styles', '14', 'Deutsch', 1, 100, 4, 2, 1, 1, 1, 1, 1, 1, 1, 160, './radio-box/radio-box.php', 1, './wunschbox.php', 1, 1, 10, 1, '#ff0000', '#864b4b', '#00FF00', '#FFFF00', 1, 1, 1, 5, 1, 1, 1, 1, './?AdminWunschbox', 1, './sendeplan.php', 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 10, 1, 1800000, 300, 60);


CREATE TABLE IF NOT EXISTS `etchat_kick_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etchat_kicked_user_id` int(11) NOT NULL,
  `etchat_kicked_user_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_kontakt` (
  `etchat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `etchat_kontakt_daten` mediumtext NOT NULL,
  `etchat_status` enum('neu','bearbeitung_admin','bearbeitung_coadmin','bearbeitung_chatwache','abgeschlossen') NOT NULL DEFAULT 'neu',
  `etchat_kommentar` mediumtext DEFAULT NULL,
  `etchat_erstellt_am` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`etchat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_kontakt_fields` (
  `etchat_id` int(11) NOT NULL AUTO_INCREMENT,
  `etchat_field_name` varchar(50) NOT NULL,
  `etchat_field_type` enum('text','email','select','checkbox','textarea','date') NOT NULL,
  `etchat_options` longtext DEFAULT NULL COMMENT 'JSON-kodierte Optionen für select/checkbox',
  `etchat_required` tinyint(1) DEFAULT 0,
  `etchat_visible` tinyint(1) DEFAULT 1,
  `etchat_sort_order` int(11) DEFAULT 0,
  `etchat_custom` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`etchat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `etchat_kontakt_fields` (`etchat_id`, `etchat_field_name`, `etchat_field_type`, `etchat_options`, `etchat_required`, `etchat_visible`, `etchat_sort_order`, `etchat_custom`) VALUES
(1, 'Betreff', 'select', '[\"Sonstige\",\"Allgemein\",\"Musik\",\"Beschwerde\"]', 1, 1, 0, 0),
(2, 'E-Mail', 'email', NULL, 1, 1, 1, 0),
(3, 'Anrede', 'select', '[\"Herr\",\"Frau\",\"Divers\",\"Homo\\/Gay\",\"Transsexuel\"]', 0, 1, 2, 0),
(4, 'Name', 'text', NULL, 1, 1, 3, 0),
(5, 'Telefon', 'text', NULL, 0, 1, 4, 0),
(6, 'Ort', 'text', NULL, 0, 1, 5, 0),
(7, 'Nachricht', 'textarea', NULL, 1, 1, 7, 0);


CREATE TABLE IF NOT EXISTS `etchat_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `menu` int(1) NOT NULL,
  `link_text` longtext NOT NULL,
  `image_active` int(1) NOT NULL,
  `image` longtext NOT NULL,
  `url` mediumtext NOT NULL,
  `target` longtext NOT NULL,
  `gewicht` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_messages` (
  `etchat_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `etchat_user_fid` int(8) NOT NULL,
  `etchat_text` longtext NOT NULL,
  `etchat_text_css` longtext NOT NULL,
  `etchat_timestamp` bigint(20) NOT NULL,
  `etchat_fid_room` int(11) NOT NULL DEFAULT 1,
  `etchat_privat` int(8) DEFAULT 0,
  `etchat_user_ip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`etchat_id`),
  KEY `idx_room` (`etchat_fid_room`),
  KEY `idx_id` (`etchat_id`),
  KEY `idx_privat` (`etchat_privat`),
  KEY `idx_user` (`etchat_user_fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_radio_box` (
  `etchat_radio_id` int(1) NOT NULL AUTO_INCREMENT,
  `etchat_radio_horst` mediumtext NOT NULL,
  `etchat_radio_port` varchar(5) DEFAULT NULL,
  `etchat_radio_typ` mediumtext NOT NULL,
  `etchat_radio_stream` mediumtext NOT NULL,
  `etchat_radio_name` mediumtext NOT NULL,
  `etchat_radio_color` varchar(8) NOT NULL,
  `etchat_radio_bit` varchar(4) NOT NULL,
  `etchat_radio_box` tinyint(1) NOT NULL,
  `etchat_radio_player` tinyint(1) NOT NULL,
  `etchat_on_air` tinyint(1) NOT NULL,
  `etchat_system_titel_an` tinyint(1) NOT NULL DEFAULT 1,
  `etchat_titel_an` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`etchat_radio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `etchat_radio_history` (
  `etchat_id` int(11) NOT NULL AUTO_INCREMENT,
  `etchat_song_title` varchar(255) NOT NULL,
  `etchat_song_artist` varchar(255) DEFAULT '',
  `etchat_dj_name` varchar(100) DEFAULT 'Auto DJ',
  `etchat_played_at` int(11) NOT NULL,
  PRIMARY KEY (`etchat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `etchat_rooms` (
  `etchat_id_room` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `etchat_roomname` varchar(100) NOT NULL,
  `etchat_room_goup` int(6) NOT NULL DEFAULT 0,
  `etchat_room_pw` varchar(50) DEFAULT NULL,
  `etchat_room_message` longtext DEFAULT NULL,
  PRIMARY KEY (`etchat_id_room`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `etchat_rooms` (`etchat_id_room`, `etchat_roomname`, `etchat_room_goup`, `etchat_room_pw`, `etchat_room_message`) VALUES
(1, 'Lobby', 0, NULL, 'Hallo, schön das du zu uns gefunden hast, schau dich um, bei Fragen einfach melden.');


CREATE TABLE IF NOT EXISTS `etchat_sendeplan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serie_gruppe` varchar(32) DEFAULT NULL,
  `serie_nummer` int(11) DEFAULT NULL,
  `datum` date NOT NULL,
  `zeit_von` time NOT NULL,
  `zeit_bis` time NOT NULL,
  `sendungsname` varchar(255) NOT NULL,
  `beschreibung` text DEFAULT NULL,
  `wunschbox_aktiv` tinyint(1) NOT NULL DEFAULT 1,
  `erstellt_von` int(11) NOT NULL,
  `moderator_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bild` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_datum` (`datum`),
  KEY `idx_erstellt_von` (`erstellt_von`),
  KEY `idx_moderator_id` (`moderator_id`),
  KEY `idx_serie_gruppe` (`serie_gruppe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_sendeplan_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(50) NOT NULL,
  `config_value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `etchat_sendeplan_config` (`id`, `config_key`, `config_value`, `created_at`, `updated_at`) VALUES
(1, 'mod_can_create', 'own', '2026-09-03 11:57:08', '2026-09-04 11:26:48'),
(2, 'mod_can_edit', 'own', '2026-09-03 11:57:08', '2026-09-12 10:51:23'),
(3, 'mod_can_delete', 'none', '2026-09-03 11:57:08', '2026-09-12 11:13:44'),
(4, 'delete_after_days', '32', '2026-09-03 11:57:08', '2026-09-08 17:52:59'),
(5, 'auto_delete_enabled', '1', '2026-09-03 11:57:08', '2026-09-08 17:52:59'),
(6, 'max_days_ahead', '14', '2026-09-10 10:39:37', '2026-09-10 11:18:56'),
(7, 'serien_enabled', 'mod', '2026-09-16 08:05:40', '2026-10-05 17:27:01'),
(8, 'serien_max_tage', '46', '2026-09-16 08:05:40', '2026-09-18 07:45:06'),
(9, 'serien_max_termine', '30', '2026-09-16 08:05:40', '2026-09-18 07:44:24'),
(10, 'serien_monate_max', '36', '2026-09-17 13:47:21', '2026-09-18 07:43:13'),
(11, 'nav_limit_days', '21', '2026-10-03 11:10:47', '2026-10-04 17:38:56'),
(12, 'wunschbox_vorab_enabled', '1', '2026-10-03 13:36:33', '2026-10-03 20:20:52'),
(13, 'wunschbox_vorab_mods', '1', '2026-10-03 13:36:33', '2026-10-03 20:20:53'),
(14, 'wunschbox_vorab_max_days', '14', '2026-10-03 13:36:33', '2026-10-03 17:07:44'),
(15, 'serien_monatlich_enabled', 'mod', '2026-10-05 17:15:20', '2026-10-05 17:29:11'),
(16, 'auto_dj_enabled', '0', '2026-10-05 17:18:48', '2026-10-05 17:18:48'),
(17, 'auto_dj_time_from', '08:00', '2026-10-05 17:18:48', '2026-10-05 17:18:48'),
(18, 'auto_dj_time_to', '22:00', '2026-10-05 17:18:48', '2026-10-05 17:18:48');


CREATE TABLE IF NOT EXISTS `etchat_sendeplan_vorlagen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `bild` varchar(255) DEFAULT NULL,
  `sortierung` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `etchat_sendeplan_vorlagen` (`id`, `name`, `bild`, `sortierung`) VALUES
(1, 'Ü 30 Party', 'vorlage_1789387425_6c3a4971.jpg', 110),
(2, 'Ü 40 Party', 'vorlage_1789387444_d6cefb46.jpg', 120),
(3, 'Ü 50 Party', 'vorlage_1789387463_8b1d3385.jpg', 130),
(4, 'Abendprogramm', 'vorlage_1789387491_9236c9ff.jpg', 180),
(5, 'Adventsfest', 'vorlage_1789387515_155c2e10.jpg', 370),
(6, 'Buten Mischung', 'vorlage_1789387531_ec6f019a.jpg', 20),
(7, 'Chill Out', 'vorlage_1789387554_6c2d9356.jpg', 270),
(8, 'Clubzone', 'vorlage_1789387573_cf4006eb.jpg', 100),
(9, 'Dance Time', 'vorlage_1789387599_235d81a7.jpg', 90),
(10, 'Freitag ab ins Wochenende', 'vorlage_1789387630_1087647f.jpg', 160),
(11, 'Gnadenlos Deutsch', 'vorlage_1789387649_001eff2b.jpg', 250),
(12, 'Halloween', 'vorlage_1789387665_51e39901.jpg', 330),
(13, 'Hitkiste', 'vorlage_1789387707_084da83a.jpg', 50),
(14, 'Hits der 70er', 'vorlage_1789387727_0090fc5e.jpg', 200),
(15, 'Hits der 80er', 'vorlage_1789387748_c5284bfa.jpg', 210),
(16, 'Hits der 90er', 'vorlage_1789387765_c2ae30f5.jpg', 220),
(17, 'Hits der 2000er', 'vorlage_1789387804_90a30e2f.jpg', 230),
(18, 'In the Mix', 'vorlage_1789387819_c1baec6c.jpg', 40),
(19, 'Kaffee Zeit', 'vorlage_1789387838_b9639b7d.jpg', 150),
(20, 'Karneval', 'vorlage_1789387859_6b8caf2a.jpg', 340),
(21, 'Kein Plan ??', 'vorlage_1789387885_3058f7d1.jpg', 10),
(22, 'Love Time', 'vorlage_1789387903_c3c95fb6.jpg', 260),
(23, 'Morningshow', 'vorlage_1789387930_b1664501.jpg', 140),
(24, 'Musik von A bis Z', 'vorlage_1789387951_64285651.jpg', 30),
(25, 'Musik-Box', 'vorlage_1789387974_e02d177a.jpg', 70),
(26, 'Nachtexpress', 'vorlage_1789388000_5c222571.jpg', 190),
(27, 'Oktoberfest', 'vorlage_1789388015_8f70a973.jpg', 360),
(28, 'Oldies', 'vorlage_1789388030_bb3f1738.jpg', 240),
(29, 'Party Time', 'vorlage_1789388055_9180dcc9.jpg', 80),
(30, 'Querbeet', 'vorlage_1789388071_fd129067.jpg', 60),
(31, 'Rock', 'vorlage_1789388085_fc27bea7.jpg', 280),
(32, 'Silvester', 'vorlage_1789388098_3af40464.jpg', 390),
(33, 'Spezial', 'vorlage_1789388114_6c737f2d.jpg', 320),
(34, 'Tanz in den Mai', 'vorlage_1789388130_6e612829.jpg', 350),
(35, 'Trancetime', 'vorlage_1789388150_d7d5c3ec.jpg', 310),
(36, 'Weihnachts Party', 'vorlage_1789388174_1fdb4800.jpg', 380),
(37, 'Wochenende', 'vorlage_1789388189_8ca219f3.jpg', 170),
(38, 'Premiere', 'vorlage_1789389694_70e4ad2b.jpg', 410),
(39, 'Geburtstags Party', 'vorlage_1789390547_90796c70.jpg', 400),
(40, 'Country', 'vorlage_1789390598_6cbe392c.jpg', 290),
(41, 'Gothic', 'vorlage_1789390625_e0fad87b.jpg', 300),
(42, 'Reserviert', 'vorlage_1791023300_0bd3da5c.jpg', 420);


CREATE TABLE IF NOT EXISTS `etchat_smileys` (
  `etchat_smileys_id` int(5) NOT NULL AUTO_INCREMENT,
  `etchat_smileys_kat` varchar(255) NOT NULL,
  `etchat_smileys_sign` varchar(20) NOT NULL,
  `etchat_smileys_img` varchar(100) NOT NULL,
  `etchat_smileys_gewicht` int(5) NOT NULL,
  PRIMARY KEY (`etchat_smileys_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_smileys_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `aktiv` varchar(3) NOT NULL,
  `gewicht` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_start_boxes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ort` varchar(55) NOT NULL,
  `header_text` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_texte` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ort` varchar(55) NOT NULL,
  `header_text` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_user` (
  `etchat_user_id` int(8) NOT NULL AUTO_INCREMENT,
  `etchat_username` varchar(200) NOT NULL,
  `etchat_userpw` varchar(255) DEFAULT NULL,
  `etchat_userprivilegien` varchar(15) NOT NULL DEFAULT 'gast',
  `etchat_usersex` varchar(1) NOT NULL DEFAULT 'n',
  `etchat_reg_timestamp` timestamp NOT NULL DEFAULT '1979-12-31 23:00:00',
  `etchat_reg_ip` varchar(100) DEFAULT NULL,
  `etchat_avatar` varchar(40) NOT NULL DEFAULT 'noavatar.jpg',
  `etchat_logintime` bigint(20) DEFAULT NULL,
  `etchat_email` varchar(255) DEFAULT NULL,
  `etchat_reset_token` varchar(255) DEFAULT NULL,
  `etchat_reset_token_expiry` datetime DEFAULT NULL,
  `etchat_geb_tag` tinyint(2) DEFAULT NULL,
  `etchat_geb_monat` tinyint(2) DEFAULT NULL,
  `etchat_geb_jahr` smallint(4) DEFAULT NULL,
  `etchat_ort` varchar(255) DEFAULT NULL,
  `etchat_beschreibung` text DEFAULT NULL,
  `etchat_last_ip` varchar(100) DEFAULT NULL,
  `etchat_onlinetime` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`etchat_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `etchat_user` (
  `etchat_user_id`, `etchat_username`, `etchat_userpw`, `etchat_userprivilegien`,
  `etchat_usersex`, `etchat_reg_timestamp`, `etchat_reg_ip`, `etchat_avatar`,
  `etchat_logintime`, `etchat_email`, `etchat_reset_token`, `etchat_reset_token_expiry`,
  `etchat_geb_tag`, `etchat_geb_monat`, `etchat_geb_jahr`, `etchat_ort`,
  `etchat_beschreibung`, `etchat_last_ip`, `etchat_onlinetime`
)
SELECT
  -2, 'Auto-DJ', '0', 'autodj',
  'm', '2026-01-13 15:52:39', NULL, 'bot_avatar.png',
  0, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL,
  NULL, NULL, 0
FROM DUAL
WHERE NOT EXISTS (
  SELECT 1 FROM `etchat_user` WHERE `etchat_userprivilegien` = 'autodj'
);


CREATE TABLE IF NOT EXISTS `etchat_useronline` (
  `etchat_onlineid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `etchat_onlineuser_fid` int(8) NOT NULL,
  `etchat_onlinetimestamp` bigint(20) NOT NULL,
  `etchat_onlineip` varchar(255) NOT NULL,
  `etchat_fid_room` int(11) NOT NULL DEFAULT 1,
  `etchat_user_online_room_goup` int(6) NOT NULL,
  `etchat_user_online_room_name` varchar(100) NOT NULL,
  `etchat_user_online_user_name` varchar(200) NOT NULL,
  `etchat_user_online_user_priv` varchar(20) NOT NULL,
  `etchat_user_online_user_sex` varchar(1) NOT NULL,
  `etchat_user_online_user_status_img` varchar(200) DEFAULT NULL,
  `etchat_user_online_user_status_text` varchar(200) DEFAULT NULL,
  `etchat_avatar` varchar(40) NOT NULL DEFAULT 'noavatar.jpg',
  `etchat_logintime` bigint(20) NOT NULL,
  `etchat_onlineuser_zeit` int(11) NOT NULL DEFAULT 0,
  `etchat_last_ping` datetime NOT NULL DEFAULT current_timestamp(),
  `etchat_session_id` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`etchat_onlineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_wunschbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sendungs_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `wohnort` varchar(100) DEFAULT NULL,
  `interpret` varchar(100) NOT NULL,
  `titel` varchar(100) NOT NULL,
  `gruss` text DEFAULT NULL,
  `erstellt_von` int(11) NOT NULL,
  `user_ip` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `gespielt` tinyint(1) NOT NULL DEFAULT 0,
  `gespielt_am` datetime DEFAULT NULL,
  `gespielt_von` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sendungs_id` (`sendungs_id`),
  KEY `idx_erstellt_von` (`erstellt_von`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `etchat_wunschbox_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(50) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `etchat_wunschbox_config` (`id`, `config_key`, `config_value`, `description`) VALUES
(1, 'mod_can_delete', 'gespielt', 'Moderator darf löschen: none, own, gespielt, all'),
(2, 'mod_can_see_all', '2', 'Moderator sieht alle Wünsche: 0=Nein, 1=Ja'),
(3, 'rate_limit_seconds', '30', 'Wartezeit in Sekunden zwischen zwei Wünschen pro IP'),
(4, 'admin_refresh_seconds', '45', 'Auto-Refresh in Sekunden für Admin-Ansicht'),
(5, 'auto_delete_enabled', '1', 'Automatisches Löschen von gespielten Wünschen aktivieren: 0=Nein, 1=Ja'),
(6, 'auto_delete_after_days', '31', 'Gespielte Wünsche löschen nach X Tagen'),
(7, 'wunschbox_cleanup_hours', '1', NULL);


CREATE TABLE IF NOT EXISTS `etchat_wunschbox_ip_ban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `ban_until` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_ban_until` (`ban_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;