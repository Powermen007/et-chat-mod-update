<?php
/*
ET-Chat Sendeplan – Öffentliche Ansicht
Analog zu kontakt.php
*/

// 1. Config laden (VOR session_start)
require_once __DIR__ . "/config.php";

// 2. Session starten (NACH config)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. Klassen laden (GENAU WIE KONTAKT!)
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/LangJson.class.php";
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/Sendeplan.class.php";

// 4. Sprache laden
$lang = new LangJson('', 'wb_sendeplan.json');

// 5. Style aus Session oder Fallback
$style = $_SESSION['etchat_' . $prefix . 'style'] ?? 'etchat_dino_styles';

// 6. Sendeplan-Objekt
$sendeplan = new Sendeplan();

// 🔥 NEU: Automatische Bereinigung (max. 2x am Tag)
$sendeplan->maybeAutoCleanup();

// 7. Aktuelle Woche ermitteln
$start = $_GET['start'] ?? date('Y-m-d');
if (!isset($_GET['start'])) {
    $day = date('N');
    $diff = $day - 1;
    $start = date('Y-m-d', strtotime("-$diff days"));
}

// ============================================================
// 🔥 NEU: Navigation-Limit (Design-abhängig)
// ============================================================
// Design-Key schon bestimmen (brauchen wir für Sonderfall Design 6)
$designKeyPreview = isset($_GET['design']) ? (string)$_GET['design'] : '0';

// Limit aus Config holen (-1 = unbegrenzt, 0 = kein Blättern, > 0 = Tage)
$navLimitDays = (int)$sendeplan->getConfig('nav_limit_days', -1);

// 🔥 Sonderfall Design 6 (Tages-Ansicht): Mindestens 7 Tage
if ($designKeyPreview === '6' && $navLimitDays === 0) {
    $navLimitDays = 7;
}

// Serverseitige Begrenzung anwenden
if ($navLimitDays === 0) {
    // Kein Blättern → immer aktuelle Woche
    $day = date('N');
    $diff = $day - 1;
    $start = date('Y-m-d', strtotime("-$diff days"));
} elseif ($navLimitDays > 0) {
    // 🔥 Design-abhängige Basis
    $isWeekView = in_array($designKeyPreview, ['0', '1', '2', '3', '4']);
    
    if ($isWeekView) {
        // Wochen-Ansicht: Basis ist Montag dieser Woche
        $baseDate = (new DateTime())->modify('monday this week');
    } else {
        // Tages-Ansicht (Design 6): Basis ist heute
        $baseDate = new DateTime();
    }
    
    // 🔥 Design 1 (rollierendes Fenster): Limit großzügiger
    // (damit auch größere SP_DAYS-Werte abgedeckt sind)
    $effectiveLimit = $navLimitDays;
    if ($designKeyPreview === '1') {
        $effectiveLimit = $navLimitDays + 14;
    }
    
    $maxDate = (clone $baseDate)->modify("+{$effectiveLimit} days");
    $minDate = (clone $baseDate)->modify("-{$effectiveLimit} days");
    
    $requested = new DateTime($start);
    
    if ($requested > $maxDate) $start = $maxDate->format('Y-m-d');
    if ($requested < $minDate) $start = $minDate->format('Y-m-d');
}

// 8. Daten holen
$week = $sendeplan->getWeekRange($start);
$entries = $sendeplan->getEntries($week['start'], $week['end']);
$isAuthorized = $sendeplan->isAuthorized();
$manager = $sendeplan;
$currentTime = date('H:i:s');

// 🔥 NEU: Zusätzlicher 8-Tage-Zeitraum ab heute (für Design 1 usw.)
$days8 = $sendeplan->getNextDays(8);
$entries8 = $sendeplan->getEntries($days8['start'], $days8['end']);

// 🔥 NEU: Rollierendes Tagesfenster für Design 4
// Start = ?start= oder heute
$listStart = $_GET['start'] ?? date('Y-m-d');
// Validierung: nur gültiges Datum, sonst heute
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $listStart) || strtotime($listStart) === false) {
    $listStart = date('Y-m-d');
}

// Länge des Fensters (konfigurierbar, hier Standard 8)
$listDays = 8;

// Tagesfenster + Sendungen im Fenster holen
$daysList    = $sendeplan->getDaysRange($listStart, $listDays);
$entriesList = $sendeplan->getEntries($daysList['start'], $daysList['end']);

// 🔥 NEU: Tages-Ansicht für Design 6
// Start = ?start= oder heute
$dayStart = $_GET['start'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dayStart) || strtotime($dayStart) === false) {
    $dayStart = date('Y-m-d');
}

// Nur die Sendungen des Tages (Vortag wird im Template geholt)
$dayData    = $sendeplan->getDaysRange($dayStart, 1);
$dayEntries = $sendeplan->getEntries($dayData['start'], $dayData['end']);

// ============================================================
// 9. Template-Auswahl über ?design=N  (Whitelist-Mapping)
// ============================================================
// Hier trägst du einfach neue Templates ein, wenn du sie baust:
$designMap = [
    '0' => 'sendeplan.tpl.html',      // Standard (auch Fallback)
    '1' => '1_sendeplan.tpl.html',
    '2' => '2_sendeplan.tpl.html',
    '3' => '3_sendeplan.tpl.html',
    '4' => '4_sendeplan.tpl.html',
	'5' => '5_sendeplan.tpl.html',
	'6' => '6_sendeplan.tpl.html',
];

// Standard-Template (wird genutzt, wenn kein ?design= übergeben wurde)
$defaultDesign = '0';

// Aktuellen Design-Key bestimmen
$designKey = isset($_GET['design']) ? (string)$_GET['design'] : $defaultDesign;

// Wenn der Key nicht in der Map existiert → Standard nehmen
if (!isset($designMap[$designKey])) {
    $designKey = $defaultDesign;
}

// Dateiname des Templates
$templateFile = 'styles/etchat_sendeplan/' . $designMap[$designKey];

// Sicherheitscheck: Template muss existieren
if (!file_exists(__DIR__ . '/' . $templateFile)) {
    // Fallback auf Standard, falls Datei fehlt
    $templateFile = 'styles/etchat_sendeplan/' . $designMap[$defaultDesign];
}

// 10. Template einbinden
include $templateFile;