
ALTER TABLE `etchat_radio_box` ADD `etchat_on_air` TINYINT(1) NOT NULL AFTER `etchat_radio_player`; 
