<?php
/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Smileys extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");

        $cats = $this->dbObj->sqlGet("SELECT name, gewicht FROM {$this->_prefix}etchat_smileys_cat WHERE aktiv LIKE 'on'  ORDER BY `gewicht` ASC ");
		echo "<ul class=\"ul_cat\">";
        foreach ($cats as $cat) {
                 echo "<li class=\"cat\" >&#x2007<a href=\"#\" onclick=\"openCat(event, '".$cat[0]."');return false;\" class=\"tablinks\">".$cat[0]."</a>&#x2007</li>";
                    }
		echo "</ul>";
        echo "<hr><div class=\"items\">";
        foreach ($cats as $cat) {
            $smileys = $this->dbObj->sqlGet("SELECT etchat_smileys_kat, etchat_smileys_sign, etchat_smileys_img, etchat_smileys_gewicht FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_kat = '".$cat[0]."'  ORDER BY `etchat_smileys_gewicht` ASC, `etchat_smileys_img` ASC ");
            echo "<div id=\"".$cat[0]."\" class=\"tabcontent\">";

            if (empty($smileys)) {
    // Wenn die foreach leer wäre
    echo "Keine Smileys in dieser Katekorie vorhanden.";
				} else {
            foreach ($smileys as $smil) {
			echo "
			<div style='display:inline-block; text-align:center; margin:5px;'>
				<img class='img_smiley' data-src='".$smil[2]."' id='".$smil[1]."' style='cursor:pointer; display:block; margin:0 auto;' src='img/loading.gif'>
				<div style='border:1px solid #ccc; padding:2px 4px; margin-top:5px;'>".$smil[1]."</div>
			</div>";
            }}
            echo "</div>";
        }
        echo "</div>";
        $this->dbObj->close();
        echo "</table>";
    }
}

?>
