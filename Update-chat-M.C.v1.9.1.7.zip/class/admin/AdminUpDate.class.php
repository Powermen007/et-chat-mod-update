<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpDate extends DbConectionMaker
{
    protected $db;
    protected $prefix;
    protected $dbname;

    public function __construct()
    {
        parent::__construct();

        $desei = $this->dbObj->sqlGet(
            "SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'"
        );

        $configFile = dirname(dirname(__DIR__)) . "/config.php";
        if (!file_exists($configFile)) {
            die("FEHLER: config.php nicht gefunden!");
        }
        include $configFile;

        $this->prefix = $prefix;
        $this->dbname = $database;

        try {
            $this->db = new PDO(
                "mysql:host={$sqlhost};dbname={$database};charset=utf8mb4",
                $sqluser,
                $sqlpass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
        } catch (PDOException $e) {
            die("FEHLER: Datenbankverbindung: " . $e->getMessage());
        }

        session_start();

        if ($_SESSION["etchat_" . $this->prefix . "user_priv"] !== "admin") {
            die("Zugriff verweigert!");
        }

        if (isset($_GET["action"])) {
            switch ($_GET["action"]) {
                case "restore":
                    $this->showLoadingScreen($_GET["file"]);
                    break;
                case "delete":
                    if (isset($_GET["file"])) {
                        $this->deleteBackupFile($_GET["file"]);
                    }
                    break;
                case "restoreing":
                    if (isset($_GET["file"])) {
                        $this->restoreBackup($_GET["file"]);
                    }
                    break;
                case "upload":
                    $this->handleUpload();
                    break;
                case "downloadUpdate":
                    if (isset($_GET["version"])) {
                        // So wichtig: Version an die Methode weitergeben!
                        $this->downloadUpdate($_GET["version"]);
                    } else {
                        echo "<span style='color:red;'>Keine Versionsnummer angegeben.</span>";
                    }
                    break;
            }
            exit();
        }

        $this->showBackupInterface($desei);
    }

    private function getAvailableUpdates($localVersion)
    {
        $updateIndexUrl =
            "https://powermen007.github.io/et-chat-mod-update/updates.json";
        $response = $this->fetchRemoteVersion($updateIndexUrl);

        if (!$response) {
            echo "<span style='color:red;'>Fehler beim Laden der Update-Liste.</span><br>";
            return [];
        }

        $files = json_decode($response, true);
        if (!is_array($files)) {
            echo "<span style='color:red;'>Update-Liste ist ung�ltig.</span><br>";
            return [];
        }

        $updates = [];

        foreach ($files as $file) {
            if (
                preg_match("/v(\d+\.\d+(?:\.\d+)?(?:\.\d+)?)/i", $file, $match)
            ) {
                $version = $match[1];
                if (version_compare($version, $localVersion, ">")) {
                    $updates[] = [
                        "version" => $version,
                        "file" => $file,
                    ];
                }
            }
        }

        usort(
            $updates,
            fn($a, $b) => version_compare($a["version"], $b["version"])
        );
        return $updates;
    }

    private function deleteBackupFile($filename)
    {
        $updateFolder = dirname(dirname(__DIR__)) . "/update";
        $filePath = $updateFolder . "/" . basename($filename);

        if (file_exists($filePath)) {
            unlink($filePath);
            header("Location: ?AdminUpDate");
            exit();
        } else {
            $this->showResult("Datei nicht gefunden");
        }
    }

    private function restoreBackup($filename)
    {
        $updateFolder = dirname(dirname(__DIR__)) . "/update";
        $filePath = $updateFolder . "/" . basename($filename);

        if (!file_exists($filePath)) {
            $this->showResult("Chat Update-Datei nicht gefunden");
            return;
        }

        $extension = pathinfo($filePath, PATHINFO_EXTENSION);

        if ($extension === "zip") {
            $this->restoreFiles($filePath);
            $this->showResult("Chat Update Fertiggestellt");
        } else {
            $this->showResult(
                "Ung�ltiger Dateityp, nur ZIP-Dateien werden akzeptiert"
            );
        }
    }

    private function restoreFiles($zipFile)
    {
        $zip = new ZipArchive();
        if ($zip->open($zipFile) !== true) {
            $this->showResult("Fehler beim �ffnen der ZIP-Datei: $zipFile");
            return;
        }

        $basePath = dirname(dirname(__DIR__));
        $sqlFilePath = null;

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            $targetPath = $basePath . "/" . $filename;

            // Verzeichnisse �berspringen
            if (substr($filename, -1) === "/") {
                if (!is_dir($targetPath)) {
                    mkdir($targetPath, 0777, true);
                }
                continue;
            }

            // Falls "install/mysql_db.sql"
            if (strtolower($filename) === "install/mysql_db.sql") {
                $sqlFilePath = $targetPath;
            }

            // Zielverzeichnis erstellen, falls n�tig
            $dir = dirname($targetPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }

            // Datei extrahieren
            $fileContent = $zip->getFromIndex($i);
            if ($fileContent !== false) {
                file_put_contents($targetPath, $fileContent);
            }
        }

        $zip->close();

        // SQL-Datei ggf. importieren
        if ($sqlFilePath && file_exists($sqlFilePath)) {
            $this->importAdditionalSQL($sqlFilePath);
        }
    }

    private function handleUpload()
    {
        if (!isset($_FILES["update_file"])) {
            $this->showResult("Keine Datei hochgeladen");
            return;
        }

        $uploadedFile = $_FILES["update_file"];
        $updateFolder = dirname(dirname(__DIR__)) . "/update";

        $extension = pathinfo($uploadedFile["name"], PATHINFO_EXTENSION);
        if (strtolower($extension) !== "zip") {
            $this->showResult("Nur .zip Dateien erlaubt");
            return;
        }

        $targetPath = $updateFolder . "/" . basename($uploadedFile["name"]);

        if (move_uploaded_file($uploadedFile["tmp_name"], $targetPath)) {
            header("Location: ?AdminUpDate");
            exit();
        } else {
            $this->showResult("Fehler beim Hochladen");
        }
    }

    private function checkForNewVersion()
    {
        // Schritt 1: Lokale Version laden
        $localRaw = @file_get_contents(
            dirname(dirname(__DIR__)) . "/version.txt"
        );
        $localVersion = $this->extractVersion($localRaw);

        if (!$localVersion || $localVersion === "0.0.0.0") {
            echo "<span style='color: red;'>Lokale Version nicht erkennbar.</span><br>";
            return;
        }

        echo "<h3>Update Status</h3>";
        echo "<strong>Lokale Version:</strong> $localVersion<br>";

        // Erfolgsmeldung, falls Download war
        if (isset($_GET["msg"]) && $_GET["msg"] === "download_ok") {
            $v = htmlspecialchars($_GET["downloaded_version"] ?? "");
            echo "<div style='color: green;'><strong>Update-Version $v erfolgreich heruntergeladen.</strong></div><br>";
        }

        // Schritt 2: Verf�gbare Updates ermitteln
        $updates = $this->getAvailableUpdates($localVersion);

        if (empty($updates)) {
            echo "<span style='color: green;'>Deine Version ist aktuell.</span>";
        } else {
            echo "<strong>Verfügbare Updates:</strong><br>";
            foreach ($updates as $update) {
                $ver = $update["version"];
                echo "Version: <strong>$ver</strong> ";
                echo "<a href='?AdminUpDate&action=downloadUpdate&version=$ver'>Herunterladen</a><br>";
            }
        }
    }

    private function extractVersion($text)
    {
        // Suche nach Versionsnummern mit mindestens zwei Segmenten, z.B. "1.9" oder "1.9.1.4"
        if (preg_match("/\b(\d+(?:\.\d+)+)\b/", $text, $match)) {
            return $match[1]; // Gefundene Version zur�ckgeben
        }
        return "0.0.0"; // Default, falls keine Version gefunden wurde
    }

    private function fetchRemoteVersion($url)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // <-- Wichtig bei GitHub Pages
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Optional bei Problemen mit SSL

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $response = "";
        }

        curl_close($ch);
        return $response;
    }

    private function downloadUpdate($version)
    {
        $remoteUrlBase = "https://powermen007.github.io/et-chat-mod-update/";
        $downloadDir = dirname(dirname(__DIR__)) . "/update";
        $filename = "Update-chat-M.C.v$version.zip";
        $downloadUrl = $remoteUrlBase . $filename;
        $destination = $downloadDir . "/" . $filename;

        // Download mit cURL
        $ch = curl_init($downloadUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $data = curl_exec($ch);

        if (curl_errno($ch)) {
            echo "<span style='color: red;'>Fehler beim Herunterladen der Datei: " .
                curl_error($ch) .
                "</span>";
            curl_close($ch);
            return;
        }

        curl_close($ch);

        // Speicherverzeichnis pr�fen
        if (!is_dir($downloadDir)) {
            mkdir($downloadDir, 0755, true);
        }

        // Datei speichern
        if (file_put_contents($destination, $data)) {
            header(
                "Location: ?AdminUpDate&msg=download_ok&downloaded_version=$version"
            );
            exit();
        } else {
            echo "<span style='color: red;'>Fehler beim Speichern der Datei.</span>";
            exit();
        }
    }

    private function showBackupInterface($desei)
    {
        $updateFolder = dirname(dirname(__DIR__)) . "/update";
        $updateFiles = [];

        if (is_dir($updateFolder)) {
            $files = scandir($updateFolder, SCANDIR_SORT_DESCENDING);
            foreach ($files as $file) {
                if ($file !== "." && $file !== "..") {
                    $filePath = $updateFolder . "/" . $file;
                    $updateFiles[] = [
                        "name" => $file,
                        "size" => filesize($filePath),
                        "date" => date("d.m.Y H:i", filemtime($filePath)),
                        "type" => pathinfo($filePath, PATHINFO_EXTENSION),
                    ];
                }
            }
        }
        ?>

        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Update</title>

         <?php
         if (is_array($desei)) {
             foreach ($desei as $data) {
                 echo "<link href=\"styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
             }
         }
         $this->dbObj->close();
         ?>

            <style>
			.container { max-width: 1200px; margin: 0 auto; background: #1f2430; padding: 20px; box-shadow: 0 0 15px rgba(0, 0, 0, 0.5); border-radius: 5px; }
			.button.green { background: #3a4050; }
			.button.green:hover { background: #149d00; }
			.button.red { background: #C62828; }
			.button.red:hover { background: #D32F2F; }
			.button.gray { background: #424242; cursor: not-allowed; }
			.update-table { width: 100%; border-collapse: collapse; margin: 15px 0; }
			.update-table th { background: #3a4050; color: #ffffff; padding: 10px; text-align: left; border-bottom: 2px solid #4a5060; }
			.update-table td { padding: 10px; border-bottom: 1px solid #555; vertical-align: middle; }
			.update-table tr:hover { background: #2a2f3a; }
			.update-actions { white-space: nowrap; }
			.section { background: #2a2f3a; padding: 15px; margin-bottom: 20px; border-radius: 5px; border: 1px solid #4a5060; }
			.warning { background: #5D4037; color: #FFCCBC; padding: 15px; border-radius: 5px; margin-bottom: 20px; border: 1px solid #8D6E63; }
			.file-size { color: #BDC3C7; font-size: 13px; }
			.file-date { color: #BDC3C7; font-size: 13px; }
			.file-type { display: inline-block; padding: 2px 5px; background: #3a4050; border-radius: 3px; font-size: 12px; color: #ffffff; }
			input[type="file"] { padding: 8px; margin: 5px 0; background: #2a2f3a; border: 1px solid #444; border-radius: 4px; color: #ffffff; }
            </style>
        </head>
        <body id="adminbereich_body">
            <a href='./?AdminIndex'" style="cursor: pointer;">&lt;&lt;&lt; zurück zum Adminmenü</a>
            <hr size="1">

            <div class="container">
                <b>Chat Update System</b><br><br>

                <div class="warning">
                    <strong>Achtung:</strong> Update &Uuml;berschreibt nur Dateien und &auml;ndert evtl. die Datenbank!<br>Update immer der reihen nach Instalieren sonst kann es zu Probleme kommen!!
                </div>

                <div class="section">
                        <?php
                        $this->checkForNewVersion();
                        ?>
                </div>

                <div class="section">
                    <b>Update hochladen</b>
                    <form action="?AdminUpDate&action=upload" method="post" enctype="multipart/form-data">
                        <input type="file" name="update_file" accept=".zip" required>
                        <button type="submit" class="button green">Update hochladen</button>
                    </form>
                    <p style="font-size:13px; color:#BDBDBD;">Nur .zip (Dateien) erlaubt</p>
                </div>

                <div class="section">
                    <b>Vorhandene Updates</b>
                    <?php if (empty($updateFiles)): ?>
                        <p>Keine Update vorhanden</p>
                    <?php else: ?>
                        <table class="update-table">
                            <thead>
                                <tr>
                                    <th>Dateiname</th>
                                    <th>Typ</th>
                                    <th>Größe</th>
                                    <th>Datum</th>
                                    <th>Aktionen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($updateFiles as $file): ?>
                                    <tr>
                                        <td><?= htmlspecialchars(
                                            $file["name"]
                                        ) ?></td>
                                        <td><span class="file-type"><?= strtoupper(
                                            $file["type"]
                                        ) ?></span></td>
                                        <td class="file-size"><?= round(
                                            $file["size"] / 1024
                                        ) ?> KB</td>
                                        <td class="file-date"><?= $file[
                                            "date"
                                        ] ?></td>
                                        <td class="update-actions">
                                            <?php if (
                                                $file["type"] === "zip"
                                            ): ?>
                                                <a href="?AdminUpDate&action=restore&file=<?= urlencode(
                                                    $file["name"]
                                                ) ?>" class="button green">Update Einspielen</a>
                                            <?php else: ?>
                                                <span class="button gray">Nicht unterstützt</span>
                                            <?php endif; ?>
                                            <a href="?AdminUpDate&action=delete&file=<?= urlencode(
                                                $file["name"]
                                            ) ?>" class="button red">Löschen</a>
                                            <a href="update/<?= htmlspecialchars(
                                                $file["name"]
                                            ) ?>" download class="button">Download</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </body>
        </html>
        <?php
    }

    private function showLoadingScreen($file)
    {
        ?>
	    <!DOCTYPE html>
	    <html>
	    <head>
    	    <meta charset="UTF-8">
        	<title>Update wird instaliert�</title>
	        <style>
    	        body {
        	        background: #1f2430;
            	    color: #ffffff;
                	font-family: Arial, sans-serif;
	                text-align: center;
    	            padding-top: 100px;
        	    }

            	.spinner {
                	margin: 40px auto;
	                width: 60px;
    	            height: 60px;
        	        border: 8px solid #3a4050;
            	    border-top: 8px solid #00e676;
                	border-radius: 50%;
	                animation: spin 1s linear infinite;
    	        }

        	    @keyframes spin {
            	    0% { transform: rotate(0deg); }
                	100% { transform: rotate(360deg); }
	            }

    	        .message {
        	        font-size: 18px;
            	    color: #ccc;
	            }
    	    </style>
	    </head>
    	<body>
        	<div class="spinner"></div>
	        <div class="message">Update wird instaliert... Bitte einen Moment Geduld.</div>

    	    <form id="updateForm" method="get" action="">
        	    <input type="hidden" name="AdminUpDate" value="">
            	<input type="hidden" name="action" value="restoreing">
            	<input type="hidden" name="file" value="<?= htmlspecialchars(
                 $file
             ) ?>">
	        </form>

    	    <script>
        	    setTimeout(function() {
            	    document.getElementById('updateForm').submit();
	            }, 1500); // 1,5 Sekunden warten, um Spinner sichtbar zu machen
    	    </script>
	    </body>
    	</html>
	    <?php exit();
    }

    private function showResult($message, $files = [])
    {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Update Ergebnis</title>

         <?php
         $desei = $this->dbObj->sqlGet(
             "SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'"
         );

         if (is_array($desei)) {
             foreach ($desei as $data) {
                 echo "<link href=\"styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
             }
         }
         $this->dbObj->close();
         ?>

            <style>
                .result { max-width: 800px; margin: 20px auto; padding: 20px; background: #1f2430; border-radius: 5px; box-shadow: 0 0 15px rgba(0,0,0,0.5); border: 1px solid #4a5060; }
                .file-list { margin: 15px 0; padding: 10px; background: #2a2f3a; border-radius: 4px; border: 1px solid #4a5060; }
            </style>
        </head>
        <body id="adminbereich_body">
            <div class="result">
                <h2><?= htmlspecialchars($message) ?></h2>
                <?php if (!empty($files)): ?>
                    <div class="file-list">
                        <p>Erstellte Dateien:</p>
                        <ul>
                            <?php foreach ($files as $file): ?>
                                <li><?= htmlspecialchars(
                                    basename($file)
                                ) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <a href="?AdminUpDate" class="button">Zurück zum Update-Menü</a> | <a href="?AdminIndex" class="button">Zurück zum Adminmenü</a>
            </div>
        </body>
        </html>
        <?php exit();
    }

    private function importAdditionalSQL($sqlFile)
    {
        $sql = file_get_contents($sqlFile);
        if ($sql === false) {
            $this->showResult("Fehler beim Lesen von install/mysql_db.sql");
            return;
        }

        // Dynamisch den Tabellen-Prefix ersetzen
        $search = "etchat_";
        $replace = $this->prefix . "etchat_";
        $sql = str_replace($search, $replace, $sql);

        $this->db->exec("SET FOREIGN_KEY_CHECKS = 0");

        $statements = array_filter(
            array_map("trim", explode(";", $sql)),
            function ($statement) {
                return !empty($statement) &&
                    !preg_match("/^\s*--/", $statement);
            }
        );

        foreach ($statements as $statement) {
            try {
                $this->db->exec($statement);
            } catch (PDOException $e) {
                $this->showResult(
                    "Fehler beim Ausf�hren von install/mysql_db.sql: " .
                        $e->getMessage()
                );
                $this->db->exec("SET FOREIGN_KEY_CHECKS = 1");
                return;
            }
        }

        $this->db->exec("SET FOREIGN_KEY_CHECKS = 1");
    }
}