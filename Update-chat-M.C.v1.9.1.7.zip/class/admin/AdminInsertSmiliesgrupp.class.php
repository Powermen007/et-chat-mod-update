<?php
class AdminInsertSmiliesgrupp extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] != "admin") {
            echo $lang->error[0]->tagData;
            return false;
        }

        $uploaddir = "./smilies/";
        $notes = "";
        $cat = $_POST["cat"];
        $gw_start = (int)($_POST["gw"] ?? 0); // Startgewicht
        $gw_step = 5; // Schrittweite
        $gw_current = $gw_start;

        foreach ($_FILES['smiliefiles']['tmp_name'] as $key => $tmp_name) {
            if (!is_uploaded_file($tmp_name)) continue;

            $originalName = $_FILES['smiliefiles']['name'][$key];
            $basename = pathinfo($originalName, PATHINFO_FILENAME);

            // Sonderzeichen raus, Leerzeichen zu Unterstrich
            $basename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $basename);

            // K�rzen auf max. 19 Zeichen (weil Doppelpunkt z�hlt)
            $basename = substr($basename, 0, 19);

            // Startk�rzel
            $sign = ':' . $basename;

            // Falls K�rzel schon existiert ? Zahl anh�ngen und ggf. k�rzen
            $counter = 1;
            while (true) {
                $res = $this->dbObj->sqlGet("
                    SELECT etchat_smileys_id
                    FROM {$this->_prefix}etchat_smileys
                    WHERE etchat_smileys_sign = '" . $sign . "'
                ");

                if (!is_array($res)) {
                    // frei
                    break;
                }

                // K�rzen f�r Ziffernanhang
                $maxBaseLen = 19 - strlen($counter);
                $shortBase = substr($basename, 0, $maxBaseLen);
                $sign = ':' . $shortBase . $counter;
                $counter++;
            }

            // Pr�fen, ob Bild
            $is_image = getimagesize($tmp_name);
            if (!is_array($is_image)) {
                $notes .= "Datei {$originalName} ist kein Bild, �bersprungen.<br>";
                continue;
            }

            // Falls Datei mit gleichem Namen existiert ? umbenennen
            $checkfile = $uploaddir . $originalName;
            if (file_exists($checkfile)) {
                $nowname = time() . "_" . $originalName;
                $notes .= "Datei existiert schon, umbenannt zu {$nowname}<br>";
            } else {
                $nowname = $originalName;
            }

            // Datei verschieben
            move_uploaded_file($tmp_name, $uploaddir . $nowname);

            // In DB eintragen mit aktuellem Gewicht
            $this->dbObj->sqlSet("
                INSERT INTO {$this->_prefix}etchat_smileys
                (etchat_smileys_kat, etchat_smileys_sign, etchat_smileys_img, etchat_smileys_gewicht)
                VALUES ('{$cat}', '{$sign}', 'smilies/{$nowname}', '{$gw_current}')
            ");

            $notes .= "Smilie {$sign} hochgeladen (Gewicht {$gw_current}).<br>";

            // Gewicht f�r den n�chsten Smiley erh�hen
            $gw_current += $gw_step;
        }

        $print_result  = "<b>Upload abgeschlossen</b><br>";
        $print_result .= $notes;
        $print_result .= "<br><a href='./?AdminCreateNewSmiliesgrupp'>Weitere hochladen</a>";
        $print_result .= "<br><a href='./?AdminSmiliesIndex'>Zur&uuml;ck zur &Uuml;bersicht</a>";

        include_once "styles/admin_tpl/insertSmiliesMessage.tpl.html";
    }
}
?>