<?php

class EditProfil extends DbConectionMaker
{
    public function __construct() {
        parent::__construct();

        session_start();

        if (empty($_SESSION['etchat_' . $this->_prefix . 'user_id'])) {
            echo "Sie sind nicht angemeldet im Chat.";
            $this->dbObj->close();
            exit();
        }

         if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteUserImage'])) {
            $userId = $_SESSION['etchat_' . $this->_prefix . 'user_id'];
            $userResult = $this->dbObj->sqlGet("SELECT etchat_username FROM {$this->_prefix}etchat_user WHERE etchat_user_id = '$userId' LIMIT 1");
            if (empty($userResult)) {
                echo "Benutzer nicht gefunden.";
                exit;
            }
            $username = $userResult[0][0];

            $uploadDir = './userpic/';
            $imageName = basename(trim($_POST['deleteUserImage']));
            $imagePath = $uploadDir . $imageName;
            $metaPath = $imagePath . '.txt';

            if (file_exists($metaPath)) {
                $meta = file_get_contents($metaPath);
                list($uploader, $datum) = explode('|', $meta);
                if ($uploader === $username) {
                    if (file_exists($imagePath)) {
                        unlink($imagePath);
                    }
                    unlink($metaPath);
                }
            }

            header("Location: ./?EditProfil");
            exit;
        }




        $userId = $_SESSION['etchat_' . $this->_prefix . 'user_id'];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tag = (int)($_POST['geb_tag'] ?? 0);
            $monat = (int)($_POST['geb_monat'] ?? 0);
            $jahr = (int)($_POST['geb_jahr'] ?? 0);
            $ort = $this->dbObj->escape(trim($_POST['ort'] ?? ''));
            $beschreibung = $this->dbObj->escape(trim($_POST['beschreibung'] ?? ''));

            $updateSQL = "
                UPDATE {$this->_prefix}etchat_user
                SET etchat_geb_tag = $tag,
                    etchat_geb_monat = $monat,
                    etchat_geb_jahr = $jahr,
                    etchat_ort = '$ort',
                    etchat_beschreibung = '$beschreibung'
                WHERE etchat_user_id = $userId
            ";
            $this->dbObj->sqlSet($updateSQL);
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $feld = $this->dbObj->sqlGet("SELECT
            etchat_username,
            etchat_userprivilegien,
            etchat_reg_timestamp,
            etchat_usersex,
            etchat_avatar,
            etchat_geb_tag,
            etchat_geb_monat,
            etchat_geb_jahr,
            etchat_ort,
            etchat_beschreibung
        FROM {$this->_prefix}etchat_user
        WHERE etchat_user_id = $userId
        LIMIT 1");

        if (empty($feld)) {
            echo "Benutzerdaten konnten nicht geladen werden.";
            exit();
        }

        $gebTag   = (int)($feld[0][5] ?? 0);
        $gebMonat = (int)($feld[0][6] ?? 0);
        $gebJahr  = (int)($feld[0][7] ?? 0);
        $alter = null;

		$geburtstagsGruss = ''; // Standard: kein Geburtstagsgru�

		if (checkdate($gebMonat, $gebTag, $gebJahr)) {
		    $geburtsdatum = new DateTime("$gebJahr-$gebMonat-$gebTag");
		    $heute = new DateTime();
		    $alter = $heute->diff($geburtsdatum)->y;

		    // Direkt Tag und Monat vergleichen
		    if ((int)$heute->format('j') === $gebTag && (int)$heute->format('n') === $gebMonat) {
        		$geburtstagsGruss = "<b><p style=\"color:red\">" . $feld[0][0] .
		            " Du hast heute Geburtstag! Und du wirst $alter Jahre alt.</p></b>";
		    }
		}

		$geburt = '';
		if ($geburtstagsGruss !== '') {
		    $geburt = "<div>$geburtstagsGruss</div>";
		}

		// Alter in assoziatives Array f�r Template
		$feld[0]['alter'] = $alter;

        // Benutzerbilder laden
        $uploadDir = './userpic/';
        $userImages = [];

        foreach (scandir($uploadDir) as $file) {
            $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                $metaFile = $uploadDir . $file . '.txt';
                if (file_exists($metaFile)) {
                    $meta = file_get_contents($metaFile);
                    list($uploader, $datum) = explode('|', $meta);

                    if ($uploader == $feld[0][0]) {
                        $userImages[] = [
                            'image' => $file,
                            'datum' => $datum
                        ];
                    }
                }
            }
        }

		// Sotiere nach Datum neue zuerst
		usort($userImages, function ($a, $b) {
		    return strtotime($b['datum']) - strtotime($a['datum']);
		});

        // �bergabe der Bilder separat
        $feld[0]['user_images'] = $userImages;

        $avatar_an_aus = $_SESSION['etchat_'.$this->_prefix.'be_info_pic'];

        $this->dbObj->close();

        $this->initTemplate($feld, $geburt, $avatar_an_aus);
    }

    private function initTemplate($feld, $geburt, $avatar_an_aus) {
        include_once("styles/" . ($_SESSION['etchat_'.$this->_prefix.'style'] ?? 'default') . "/editprofil.tpl.html");
    }
}
?>