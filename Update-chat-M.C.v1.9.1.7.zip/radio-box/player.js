const audio = document.getElementById('audio');
const playPauseBtn = document.getElementById('playPauseBtn');
const timeDisplay = document.getElementById('timeDisplay');
const muteBtn = document.getElementById('muteBtn');
const volumeSlider = document.getElementById('volumeSlider');
const volumeControl = document.getElementById('volumeControl');
const player = document.getElementById('player');
const streamTitle = document.getElementById('streamTitle');
const volumeContainer = document.getElementById('volumeContainer');

let titleInterval;
let volumeHideTimeout;

// Standardlautstärke
// Standardlautst�rke je nach Ger�tetyp setzen
function isMobileDevice() {
  return /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
}

if (isMobileDevice()) {
  audio.volume = 0.7; // 0.0 (stumm) und 1.0 (maximal). auf Handy
} else {
  audio.volume = 0.3; // 0.0 (stumm) und 1.0 (maximal). auf Desktop
}
audio.dataset.lastVolume = audio.volume;
volumeControl.value = audio.volume; // Slider-Wert anpassen


// Play/Pause
playPauseBtn.addEventListener('click', () => {
  if (audio.paused) {
    audio.src = audio.dataset.stream;
    audio.play().then(() => {
      playPauseBtn.innerHTML = '&#10074;&#10074;';
      loadStreamTitle();
      titleInterval = setInterval(loadStreamTitle, 30000);
    }).catch(err => {
      console.error("Fehler beim Abspielen:", err);
    });
  } else {
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    playPauseBtn.innerHTML = '&#9654;';
    clearInterval(titleInterval);
    streamTitle.textContent = 'Drücke Play...';
    timeDisplay.textContent = '00:00';
  }
});

// Titel abrufen
function loadStreamTitle() {
  const streamUrl = encodeURIComponent(audio.dataset.stream);
  fetch('gettitle.php?url=' + streamUrl)
    .then(response => response.text())
    .then(title => {
      // Nur der Teil vor dem Pipe-Zeichen
      let songOnly = title.split('|')[0].trim();
      streamTitle.textContent = songOnly;
    })
    .catch(() => {
      streamTitle.textContent = 'Dr�cke Play...';
    });
}

// Mute bei Klick auf Lautsprecher
muteBtn.addEventListener('click', () => {
  if (audio.volume > 0) {
    audio.dataset.lastVolume = audio.volume;
    audio.volume = 0;
    volumeControl.value = 0;
    muteBtn.innerHTML = '&#128263;';
  } else {
    audio.volume = audio.dataset.lastVolume || 0.1;
    volumeControl.value = audio.volume;
    muteBtn.innerHTML = '&#128266;';
  }
});

// Lautstärkeregler anzeigen beim Hover
volumeContainer.addEventListener('mouseenter', () => {
  const rect = player.getBoundingClientRect();
const spaceAbove = rect.top;
const spaceBelow = window.innerHeight - rect.bottom;

// Wenn oben genug Platz (z. B. = 120px), dann nach oben – sonst nach unten
if (spaceAbove >= 120) {
  volumeSlider.classList.remove('below');
  volumeSlider.classList.add('above');
} else {
  volumeSlider.classList.remove('above');
  volumeSlider.classList.add('below');
}


  clearTimeout(volumeHideTimeout);
  volumeSlider.style.display = 'block';
});

// Verzögertes Ausblenden
volumeContainer.addEventListener('mouseleave', () => {
  volumeHideTimeout = setTimeout(() => {
    volumeSlider.style.display = 'none';
  }, 1000); // 1 Sekunde
});

volumeSlider.addEventListener('mouseenter', () => {
  clearTimeout(volumeHideTimeout);
});

// Lautstärke einstellen
volumeControl.addEventListener('input', () => {
  audio.volume = volumeControl.value;
  muteBtn.innerHTML = audio.volume == 0 ? '&#128263;' : '&#128266;';
});

// Anzeige der Zeit
audio.addEventListener('timeupdate', () => {
  let minutes = Math.floor(audio.currentTime / 60);
  let seconds = Math.floor(audio.currentTime % 60);
  if (seconds < 10) seconds = '0' + seconds;
  timeDisplay.textContent = `${minutes}:${seconds}`;
});