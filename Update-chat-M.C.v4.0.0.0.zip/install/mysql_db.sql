UPDATE etchat_config SET etchat_config_lang = 'Deutsch' WHERE etchat_config_id = 1
