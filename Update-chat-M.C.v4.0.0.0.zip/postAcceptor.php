<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

// Dynamische Origin-Erkennung
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://';
$current_host = $protocol . $_SERVER['HTTP_HOST'];

// Erlaubte Origins: aktuelle Domain + lokale Entwicklung
$accepted_origins = [
    $current_host,                                    // https://deine-domain.de oder http://localhost
    'http://localhost',
    'http://localhost:8080',
    'https://localhost',
    'http://127.0.0.1',
    'https://127.0.0.1'
];

// CORS-Header setzen
if (isset($_SERVER['HTTP_ORIGIN'])) {
    $origin = $_SERVER['HTTP_ORIGIN'];
    
    // Prüfen, ob die Origin erlaubt ist (exakter Match oder Subdomain)
    $allowed = false;
    foreach ($accepted_origins as $allowed_origin) {
        // Exakter Match oder Subdomain (z.B. https://sub.domain.de)
        if ($origin === $allowed_origin || strpos($origin, '://' . parse_url($allowed_origin, PHP_URL_HOST)) !== false) {
            $allowed = true;
            break;
        }
    }
    
    if ($allowed) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Credentials: true');
    } else {
        header("HTTP/1.1 403 Origin Denied");
        echo json_encode(['error' => 'Origin not allowed: ' . $origin]);
        return;
    }
} else {
    // Keine Origin gesetzt (Same-Origin Request) -> immer erlauben
    header('Access-Control-Allow-Origin: *');
}

// OPTIONS-Request (Preflight) behandeln
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
    header('Access-Control-Max-Age: 86400'); // 24 Stunden cachen
    return;
}

// Nur POST erlauben
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("HTTP/1.1 405 Method Not Allowed");
    echo json_encode(['error' => 'Only POST allowed']);
    return;
}

// Upload-Ordner (absoluter Pfad empfohlen)
$imageFolder = __DIR__ . '/img/images/';

// Ordner erstellen falls nicht vorhanden
if (!is_dir($imageFolder)) {
    mkdir($imageFolder, 0755, true);
}

// Datei-Upload verarbeiten
if (empty($_FILES)) {
    header("HTTP/1.1 400 Bad Request");
    echo json_encode(['error' => 'No file uploaded']);
    return;
}

$file = current($_FILES);

if (!is_uploaded_file($file['tmp_name'])) {
    header("HTTP/1.1 500 Server Error");
    echo json_encode(['error' => 'Upload failed']);
    return;
}

// Dateiname bereinigen (nur erlaubte Zeichen)
$filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', basename($file['name']));
$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

// Erlaubte Dateitypen
$allowed_extensions = ['gif', 'jpg', 'jpeg', 'png', 'webp', 'svg'];
if (!in_array($extension, $allowed_extensions)) {
    header("HTTP/1.1 400 Invalid extension.");
    echo json_encode(['error' => 'Invalid file type. Allowed: ' . implode(', ', $allowed_extensions)]);
    return;
}

// Maximale Dateigröße (z.B. 5MB)
$max_size = 5 * 1024 * 1024; // 5 MB
if ($file['size'] > $max_size) {
    header("HTTP/1.1 400 File too large.");
    echo json_encode(['error' => 'File too large. Max: 5MB']);
    return;
}

// Eindeutigen Dateinamen erstellen (verhindert Überschreiben und XSS)
$new_filename = time() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
$filepath = $imageFolder . $new_filename;

// Datei verschieben
if (!move_uploaded_file($file['tmp_name'], $filepath)) {
    header("HTTP/1.1 500 Server Error");
    echo json_encode(['error' => 'Failed to save file']);
    return;
}

// URL für den Client erstellen
$baseurl = $protocol . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['REQUEST_URI']), '/') . '/';
$imageUrl = $baseurl . 'img/images/' . $new_filename;

// Erfolgreiche Antwort
echo json_encode(['location' => $imageUrl]);