<!--
/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/
    Loginformular mit moderner Sprach-API -->

<?php
// Moderner Sprachzugriff über die Index-Klasse
$lang = $this->lang;

// Fallback, falls lang nicht verfügbar
if (!$lang || !($lang instanceof LangXml)) {
    $lang = new LangXml("./lang/");
}

// ===== GENDER AUS PROFIL-KEYS =====
$genderMale = $lang->get('profil_gender_male', 'männlich');
$genderFemale = $lang->get('profil_gender_female', 'weiblich');
$genderDiverse = $lang->get('profil_gender_diverse', 'divers');
$genderNone = $lang->get('profil_gender_unknown', 'keine Angabe');
?>

<!-- ===== HIDDEN FIELDS FÜR JS-TEXTE (aus XML) ===== -->
<input type="hidden" id="forgot_pw_text" value="<?php echo $lang->get('forgot_password', 'Passwort vergessen?'); ?>">
<input type="hidden" id="privacy_error_text" value="<?php echo $lang->get('privacy_error', 'Bitte akzeptieren Sie die Datenschutzbestimmungen und Chatregeln!'); ?>">
<input type="hidden" id="username_min_length_text" value="<?php echo $lang->get('username_min_length', 'Sorry ... mindestens 3 Buchstaben beim Namen eingegeben'); ?>">
<input type="hidden" id="gender_required_text" value="<?php echo $lang->get('gender_required', '???   Dein Geschlecht   ???'); ?>">
<input type="hidden" id="password_wrong_text" value="<?php echo $lang->get('password_wrong', '❌ Passwort falsch - bitte versuchen Sie es erneut'); ?>">
<input type="hidden" id="connection_error_text" value="<?php echo $lang->get('connection_error', 'Verbindungsfehler. Bitte versuche es erneut.'); ?>">

<form id="login" action="">
    <input type="hidden" name="<?php echo $_SESSION[$this->_prefix.'set_check']; ?>" value="<?php echo $this->aktuell_date_u; ?>" />
    <br />
    
    <!-- ===== BENUTZERNAME ===== -->
    <input type="text" name="username" id="username" value="" minlength="4" maxlength="25" 
           placeholder="<?php echo $lang->get('login_name', 'Dein Chatname'); ?> min.4 Zeichen max.25" required /> 
    <br />
    <br />
    
    <!-- ===== PASSWORT ===== -->
    <div id="lay_pw" style="display: none; position: relative;">
        <input type="password" name="pw" value="" id="pw" 
               placeholder="<?php echo $lang->get('login_password', 'Passwort:'); ?>" />
        <span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; bottom: 6px;" id="togglePassword">👁️</span>
        <span style="position: absolute; margin-left: -30px; margin-top: 8px; cursor: pointer; font-size: 18px; display: none; bottom: 6px;" id="togglePasswordOff">🙈</span>
        <br>
    </div>
    
    <!-- ===== UNSICHTBAR ===== -->
    <div id="lay_invisible" style="display: none;">
        <input type="checkbox" name="status_invisible" value="1" />
        <?php echo $lang->get('login_invisible', 'unsichtbar'); ?>
    </div>
    
    <!-- ===== GESCHLECHT ===== -->
    <div id="lay_gender">
        <input type="radio" name="gender" value="m" id="sex_m" class="gender-input">
        <label for="sex_m" class="gender-label"><?php echo $genderMale; ?></label>
        <input type="radio" name="gender" value="f" id="sex_f" class="gender-input">
        <label for="sex_f" class="gender-label"><?php echo $genderFemale; ?></label>
        <input type="radio" name="gender" value="d" id="sex_d" class="gender-input">
        <label for="sex_d" class="gender-label"><?php echo $genderDiverse; ?></label>
        <br><br>
        <input type="radio" name="gender" value="n" id="sex_n" class="gender-input" checked>
        <label for="sex_n" class="gender-label"><?php echo $genderNone; ?></label>
        <br />
    </div>
    
    <br />
    
    <!-- ===== NUR EINE CHECKBOX FÜR ALLES ===== -->
    <input type="checkbox" id="privacy_policy" name="privacy_policy" value="true" required />
    <label for="privacy_policy" style="cursor: pointer;">
        <?php echo $lang->get('datenschutz_ok', 'OK'); ?>
        <a onclick="self.location.href='#datenschutzbestimmung'"> <?php echo $lang->get('datenschutz_cookie', '(Cookie und Datenschutz akzeptieren)'); ?></a>
        <br><?php echo $lang->get('sowie_die', '(sowie die)'); ?> <a onclick="self.location.href='#chatregeln'"> <?php echo $lang->get('chat_rules', 'Chatregeln'); ?></a> <?php echo $lang->get('akzeptieren', '(akzeptieren.)'); ?>
    </label>
    
    <div class="popup" id="datenschutzbestimmung">
        <div class="popup_text">
            <iframe class="datenschutzbestimmung" src="?Text&id=2" style="position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%);"></iframe>
        </div>
        <a class="popup_close" onclick="self.location.href='#'">X</a>
    </div>
    
    <div class="popup" id="chatregeln">
        <div class="popup_text">
            <iframe class="chatregeln" src="?Text&amp;id=4" style="position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%);"></iframe>
        </div>
        <a class="popup_close" onclick="self.location.href='#'">X</a>
    </div>
    
    <br />
    
    <!-- ===== ANGEMELDET BLEIBEN (OPTIONAL) ===== -->
    <div id="lay_remember" style="margin-bottom: 5px; margin-top: 5px;">
        <label style="cursor: pointer;">
            <input type="checkbox" id="remember_me" name="remember_me" value="1"> 
            <?php echo $lang->get('remember_me', 'Ich möchte angemeldet bleiben'); ?>
        </label>
    </div>
    
    <!-- ===== SUBMIT BUTTON ===== -->
    <input type="submit" id="submit_button" name="go" value="<?php echo $lang->get('login_submit', 'Chat Login'); ?>" />
    <br />
    
    <!-- ===== REGISTRIEREN BUTTON ===== -->
    <?php if ($_SESSION['etchat_'.$this->_prefix.'reg_an_aus'] == '1') { ?>
        <button type="button" id="submit_button_reg" style="margin: 15px 0;" onclick="window.location.href='?register=1';"><?php echo $lang->get('register_button', 'Registrieren'); ?></button>
    <?php } else { echo '<br/>'; } ?>
</form>