tinymce.init({
  selector: "textarea#mytextarea",
  content_css: './js/tinymce/style.css',
  menubar: 'file edit insert view format table tools help',
  menu: {
    file: { title: 'Datei', items: 'customsave print pagebreak' },
    edit: { title: 'Bearbeiten', items: 'undo redo | cut copy paste | selectall | searchreplace' },
    view: { title: 'Ansicht', items: 'code | preview | visualaid visualchars visualblocks | fullscreen' },
    insert: { title: 'Einfügen', items: 'image link media codesample | charmap emoticons hr | pagebreak nonbreaking | template' },
    format: { title: 'Format', items: 'bold italic underline strikethrough superscript subscript | formats | removeformat' },
    tools: { title: 'Extras', items: 'wordcount | code' }
  },
  
  setup: function(editor) {
    editor.ui.registry.addMenuItem('customsave', {
      text: 'Speichern',
      icon: 'save',
      shortcut: 'Ctrl+S',
      onAction: function() {
        var form = document.querySelector('form.admin-form');
        if (form) {
          form.submit();
        }
      }
    });
    
    editor.addShortcut('Ctrl+S', 'Speichern', function() {
      var form = document.querySelector('form.admin-form');
      if (form) {
        form.submit();
      }
    });
  },
  
  plugins: [
    "anchor", "accordion", "advlist", "preview", "autosave", "autolink",
    "charmap", "codesample", "code", "directionality", "emoticons", "help",
    "image", "link", "lists", "media", "save", "searchreplace", "table",
    "visualblocks", "visualchars", "wordcount", "fullscreen",
    "pagebreak", "nonbreaking", "template", "importcss"
    // "quickbars" entfernt!
  ],
  
  toolbar: [
    "save | undo redo | print code preview searchreplace fullscreen",
    "blocks fontfamily fontsize | bold italic underline forecolor backcolor | link image",
    "alignleft aligncenter alignright alignjustify lineheight | bullist numlist indent outdent",
    "removeformat | accordion anchor | pagebreak nonbreaking | template"
  ].join(' | '),
  
  images_upload_url: 'postAcceptor.php',
  images_upload_credentials: true,
  images_reuse_filename: true,
  automatic_uploads: true,
  paste_data_images: true,
  image_title: true,
  image_advtab: true,
  
  height: "400px",
  language: 'de',
  skin: 'oxide-dark',
  license_key: 'gpl',
  
  table_default_attributes: {
    border: '1'
  },
  table_default_styles: {
    borderCollapse: 'collapse',
    width: '100%'
  }
});