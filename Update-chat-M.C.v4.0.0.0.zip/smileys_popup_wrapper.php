<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

ob_start(); // ? Output Buffering aktivieren
$GLOBALS["path"] = "./";

/* Autoloader */
spl_autoload_register(function ($class_name) {
    $file = $GLOBALS["path"] . "class/" . $class_name . ".class.php";
    if (file_exists($file)) require_once $file;
});

require_once __DIR__ . "/class/Smileys.class.php";

class SmileyPopup extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // Style aus DB laden
        $style = $styleData[0]['etchat_config_style'] ?? 'etchat_dino_styles';
        $styleData = $this->dbObj->sqlGet("
            SELECT etchat_config_style
            FROM {$this->_prefix}etchat_config
            WHERE etchat_config_id = 1
            LIMIT 1
        ");
        if ($styleData && isset($styleData[0]['etchat_config_style'])) {
            $style = $styleData[0]['etchat_config_style'];
        }

        // DB schließen
        $this->dbObj->close();

        // HTML ausgeben
        echo '<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Smileys</title>
<link rel="stylesheet" href="styles/' . htmlspecialchars($style, ENT_QUOTES, 'UTF-8') . '/style.css">
<link rel="stylesheet" href="styles/' . htmlspecialchars($style, ENT_QUOTES, 'UTF-8') . '/style-mobil.css">
<script src="js/popupsmiley.js" defer></script> <!-- ? defer sorgt dafür, dass DOM da ist -->
</head>
<body id="body" class="smiley-popup">
<div id="smileys_list">';
        new Smileys();
        echo '</div>
</body>
</html>';
    }
}

// Script starten
new SmileyPopup();