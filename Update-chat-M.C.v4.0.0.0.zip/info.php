<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

// Direkte Definition des Pfades (nicht über GLOBALS)
define('SITE_PATH', __DIR__ . '/');

// Autoload für Klassen
spl_autoload_register(function($class_name) {
    $file = SITE_PATH . 'class/' . $class_name . '.class.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

class Info extends DbConectionMaker
{
    private $lang;

    public function __construct()
    {
        parent::__construct();

        // Session starten falls nicht vorhanden
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ===== MODERNE SPRACHE LADEN (dynamisch) =====
        try {
            $this->lang = new LangXml("./lang/");
        } catch (Throwable $e) {
            $this->lang = null;
        }

        // PDO Prepared Statement – config abrufen
        $configId = 1; // fix für Info-Seite
        $config = $this->dbObj->sqlGet(
            "SELECT etchat_config_id, etchat_config_style 
             FROM {$this->_prefix}etchat_config 
             WHERE etchat_config_id = :id",
            ['id' => $configId]
        );

        $this->dbObj->close();

        $style = $config[0]['etchat_config_style'] ?? 'default';

        $this->render($style);
    }

    private function render(string $style): void
    {
        // === TEXTE AUS XML HOLEN ===
        $title = $this->lang->get('info_title', 'Info');
        $mainText = $this->lang->get('info_main_text', '');
        $contributorsTitle = $this->lang->get('info_contributors_title', 'Mitwirkende:');
        $copyrightNotice = $this->lang->get('info_copyright_notice', 'Copyright Hinweis verwendeter Fremdcode:');
        $emailLink = $this->lang->get('info_email_link', 'Anfragen per E-Mail');
        $emailAddress = $this->lang->get('info_email_address', 'et-chat-mod@abwesend.de');
        $contactForm = $this->lang->get('info_contact_form', 'Kontakt per Formular');
        $forumLink = $this->lang->get('info_forum_link', 'Forum &amp; Download');
        $forumUrl = $this->lang->get('info_forum_url', 'https://et-chat-mod.42web.io/forum/');

        // === CONTRIBUTORS (Einzel-Strings) ===
        $contributors = [];
        for ($i = 1; $i <= 6; $i++) {
            $contributor = $this->lang->get("info_contributor_{$i}", '');
            if (!empty($contributor)) {
                $contributors[] = $contributor;
            }
        }

        // === LIBRARIES (Einzel-Strings) ===
        $libraries = [];
        for ($i = 1; $i <= 4; $i++) {
            $library = $this->lang->get("info_library_{$i}", '');
            if (!empty($library)) {
                $libraries[] = $library;
            }
        }

        // === FALLBACKS FALLS NICHTS GELADEN WURDE ===
        if (empty($contributors)) {
            $contributors = [
                '<strong>Powermen (Christian K.):</strong> Modulentwicklung - Programmierung - Betreuung',
                '<strong>Chrno (Herman):</strong> Modulentwicklung - Programmierung',
                '<strong>Micha (Michael Krissel):</strong> Mod-Entwicklung',
                '<strong>FizzyLemmon:</strong> Modulentwicklung - Programmierung',
                '<strong>Svensken:</strong> Programmierung',
                '<strong>Sascha:</strong> Codebereinigung'
            ];
        }

        if (empty($libraries)) {
            $libraries = [
                '<a href="https://github.com/PHPMailer/PHPMailer?tab=readme-ov-file" target="_blank">Copyright &#169; 2025 PHPMailer</a>',
                '<a href="https://codemirror.net/" target="_blank">Copyright &#169; 2025 CodeMirror</a>',
                '<a href="https://www.tiny.cloud/get-tiny/" target="_blank">Copyright &#169; 2024 TinyMCE</a>',
                '<a href="https://bgrins.github.io/spectrum/" target="_blank">Copyright &#169; Spectrum Colorpicker</a>'
            ];
        }
        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title><?= htmlspecialchars($title) ?></title>
            <link href="styles/<?= htmlspecialchars($style) ?>/style.css" rel="stylesheet" type="text/css"/>
            <meta name="robots" content="noindex,nofollow">
            <meta name="viewport" content="width=300">
        </head>
        <body id="body" style="margin-left: 20px;margin-right: 20px;">

        <br>
        <?= nl2br($mainText) ?>
        <br><br>

        <strong><?= htmlspecialchars($contributorsTitle) ?></strong><br>
        <ul>
            <?php foreach ($contributors as $contributor): ?>
                <li><?= $contributor ?></li> <!-- KEIN htmlspecialchars() da HTML erlaubt -->
            <?php endforeach; ?>
        </ul>

        <br><br>
        <strong><?= htmlspecialchars($copyrightNotice) ?></strong><br><br>
        
        <?php foreach ($libraries as $lib): ?>
            <?= $lib ?><br> <!-- KEIN htmlspecialchars() da HTML erlaubt -->
        <?php endforeach; ?>
        
        <br>

        <a href="mailto:<?= htmlspecialchars($emailAddress) ?>"><?= htmlspecialchars($emailLink) ?></a><br><br>

        <a href="#kontakt" class="popup_link"><?= htmlspecialchars($contactForm) ?></a>
        <div class="popup" id="kontakt">
            <div class="popup_text">
                <iframe class="info" src="kontakt.php" title="<?= htmlspecialchars($contactForm) ?>" 
                        style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"></iframe>
            </div>
            <a class="popup_close" href="#">X</a>
        </div>

        <br><br>
        <a href="<?= htmlspecialchars($forumUrl) ?>" target="_blank"><?= htmlspecialchars($forumLink) ?></a><br>

        </body>
        </html>
        <?php
    }
}

// Initialisieren
new Info();