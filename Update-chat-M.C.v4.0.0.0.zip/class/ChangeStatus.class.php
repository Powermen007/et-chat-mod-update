<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ChangeStatus extends DbConectionMaker
{
    private ?object $lang = null;

    public function __construct()
    {
        parent::__construct();

        // Session starten, falls noch nicht
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        // === Systemmeldungen speichern ===
        if (isset($_POST['sys_messages'])) {
            $_SESSION['etchat_' . $this->_prefix . 'sys_messages'] = (int)$_POST['sys_messages'];
            exit;
        }

        // === Session prüfen ===
        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        if ($userId <= 0) {
            exit($this->getText('changestatus_invalid_session', 'Invalid session.'));
        }

        // === Input sicher lesen ===
        $img  = $_POST['img']  ?? '';
        $text = $_POST['text'] ?? '';

        // Nur erlaubte Zeichen für Bildnamen (Alphanumerisch, Unterstrich, Bindestrich, Punkt)
        $img  = preg_replace("/[^a-zA-Z0-9_\-.]/", "", $img);
        
        // Steuerzeichen entfernen, Länge begrenzen
        $text = preg_replace('/[\x00-\x1F]/u', '', $text);
        $text = mb_substr($text, 0, 255);

        // === Rechte prüfen ===
        if (!$this->checkRightsOfStatus($img)) {
            exit($this->getText('changestatus_not_allowed', 'Not allowed operation.'));
        }

        // Neutraler Status (online)
        if ($img === "status_online") {
            $img = '';
            $text = '';
        }

        // Prüfen ob die Bilddatei existiert (nur wenn nicht leer)
        if (!empty($img)) {
            $imgPath = __DIR__ . "/../img/{$img}.png";
            if (!is_file($imgPath)) {
                $img = '';
                $text = '';
            }
        }

        // ✅ SICHER MIT PREPARED STATEMENT
        $this->dbObj->sqlSet("
            UPDATE {$this->_prefix}etchat_useronline SET
                etchat_user_online_user_status_img = :img,
                etchat_user_online_user_status_text = :text
            WHERE etchat_onlineuser_fid = :user_id
        ", [
            ':img' => $img,
            ':text' => $text,
            ':user_id' => $userId
        ]);

        $this->dbObj->close();

        echo "1";
    }

    /**
     * Hilfsmethode für Sprachzugriff
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * Prüft, ob der Benutzer die Rechte hat, einen Status zu setzen
     */
    private function checkRightsOfStatus(string $statusImagename): bool
    {
        // Gültigkeit des Status-Namens prüfen
        if (substr($statusImagename, 0, 7) !== 'status_') {
            return false;
        }

        // Leerer Status (kein Bild) ist immer erlaubt
        if (empty($statusImagename)) {
            return true;
        }

        try {
            // Sprachdatei laden (über das moderne Objekt)
            // Wir nutzen das bereits geladene $this->lang
            // Die Status-Struktur ist noch in der alten XML für JS
            // Daher laden wir hier die alte Struktur für die Rechte-Prüfung
            $legacyLangObj = new LangXml();
            $legacyLang = $legacyLangObj->getLang();

            $requiredRights = [];

            // Alle <status>-Einträge mit dem gewünschten Bildnamen prüfen
            // Achtung: Die alte Struktur hat chat_js[0]->status
            if (isset($legacyLang->chat_js[0]->status)) {
                foreach ($legacyLang->chat_js[0]->status as $status_value) {
                    $attrs = $status_value->tagAttrs ?? [];
                    if (($attrs['imagename'] ?? '') === $statusImagename) {
                        $right = $attrs['rights'] ?? '';
                        
                        // "all" bedeutet: jeder darf diesen Status verwenden
                        if ($right === 'all') {
                            return true;
                        }
                        
                        if (!empty($right)) {
                            $requiredRights[] = $right;
                        }
                    }
                }
            }
        } catch (Exception $e) {
            // Bei Fehler: Status erlauben (Fallback)
            return true;
        }

        // Keine Rechte gefunden? Status darf jeder verwenden
        if (empty($requiredRights)) {
            return true;
        }

        // Aktuelles Benutzerrecht aus der Session holen
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        // Darf der User einen der erlaubten Werte?
        return in_array($userPriv, $requiredRights, true);
    }
}