<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class RoomAllowed extends EtChatConfig
{
    public int $room_status = 0;

    public function __construct($room_priv, $room_id)
    {
        parent::__construct();

        $prefix = 'etchat_'.$this->_prefix;

        $user_priv = $_SESSION[$prefix.'user_priv'] ?? '';

        // Rollen definieren
        $admin_roles = ['admin', 'chatwache', 'grafik', 'co_admin'];
        $mod_roles   = ['mod'];
        $user_roles  = ['user'];

        // Standard: kein Zugriff
        $room_allowed = 0;

        switch ((int)$room_priv) {

            // frei für alle
            case 0:
                $room_allowed = 1;
                break;

            // mod + admin
            case 1:
                if (in_array($user_priv, $mod_roles, true) || in_array($user_priv, $admin_roles, true)) {
                    $room_allowed = 1;
                }
                break;

            // nur admin
            case 2:
                if (in_array($user_priv, $admin_roles, true)) {
                    $room_allowed = 1;
                }
                break;

            // admin + mod + user
            case 4:
                if (
                    in_array($user_priv, $admin_roles, true) ||
                    in_array($user_priv, $mod_roles, true) ||
                    in_array($user_priv, $user_roles, true)
                ) {
                    $room_allowed = 1;
                }
                break;

            // Passwort Raum
            case 3:

                if (in_array($user_priv, $admin_roles, true)) {

                    // Admin immer erlaubt
                    $room_allowed = 1;

                } else {

                    $room_allowed = 2;

                    $roompw_array = $_SESSION[$prefix.'roompw_array'] ?? [];

                    if (is_array($roompw_array) && in_array($room_id, $roompw_array, true)) {
                        $room_allowed = 1;
                    }
                }

                break;
        }

        $this->room_status = $room_allowed;
    }
}