<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class BlockUser extends EtChatConfig
{
    private string $session_block_priv;
    private string $session_block_all;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        parent::__construct();

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        $this->session_block_priv = 'etchat_'.$this->_prefix.'block_priv';
        $this->session_block_all  = 'etchat_'.$this->_prefix.'block_all';

        $_SESSION[$this->session_block_priv] ??= [];
        $_SESSION[$this->session_block_all]  ??= [];

        if (isset($_POST['block_all'])) {
            $this->toggleBlock(trim((string)$_POST['block_all']), 'all');
        }

        if (isset($_POST['block_priv'])) {
            $this->toggleBlock(trim((string)$_POST['block_priv']), 'priv');
        }

        if (isset($_POST['show'])) {
            $this->showStatus(trim((string)$_POST['show']));
        }
    }

    private function toggleBlock(string $user, string $type): void
    {
        if ($user === '') {
            return;
        }

        $priv =& $_SESSION[$this->session_block_priv];
        $all  =& $_SESSION[$this->session_block_all];

        if ($type === 'all') {

            if (in_array($user, $all, true)) {
                $all = array_diff($all, [$user]);
            } else {
                $all[] = $user;
                $priv = array_diff($priv, [$user]);
            }

        } else {

            if (in_array($user, $priv, true)) {
                $priv = array_diff($priv, [$user]);
            } else {
                $priv[] = $user;
                $all = array_diff($all, [$user]);
            }

        }
    }

    private function showStatus(string $user): void
    {
        $priv = $_SESSION[$this->session_block_priv];
        $all  = $_SESSION[$this->session_block_all];

        if (in_array($user, $priv, true)) {
            echo "priv";
            return;
        }

        if (in_array($user, $all, true)) {
            echo "all";
        }
    }
}