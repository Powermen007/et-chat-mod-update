<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

require_once __DIR__ . '/LangXml.class.php';

class CompactUserView extends DbConectionMaker
{
    private ?LangXml $lang = null;

    public function __construct()
    {
        parent::__construct();

        // ============================================================
        // Sprache laden
        // ============================================================
        try {
            $this->lang = new LangXml("./lang/");
        } catch (Throwable $e) {
            $this->lang = null;
        }

        // Standardfarben
        $adminc = '#FF0000';
        $modc   = '#00AAFF';
        $userc  = '#CCCCCC';

        // Farben aus DB laden
        $color = $this->dbObj->sqlGet(
            "SELECT etchat_config_admin_color, etchat_config_mod_color, etchat_config_user_color
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = ?",
            [1]
        );

        if (is_array($color) && isset($color[0])) {
            $adminc = $color[0]['etchat_config_admin_color'] ?? $adminc;
            $modc   = $color[0]['etchat_config_mod_color'] ?? $modc;
            $userc  = $color[0]['etchat_config_user_color'] ?? $userc;
        }

        // Benutzer laden (nur 'user' Privileg, letzte 5)
        $users = $this->dbObj->sqlGet(
            "SELECT etchat_username, etchat_userprivilegien, etchat_reg_timestamp,
                    etchat_usersex, etchat_avatar
             FROM {$this->_prefix}etchat_user
             WHERE etchat_userprivilegien = ?
             ORDER BY etchat_user_id DESC
             LIMIT 5",
            ['user']
        );

        $this->dbObj->close();

        echo '<div class="compact-user-row">';

        if (is_array($users)) {
            foreach ($users as $user) {

                if (!is_array($user)) continue;

                $username = $user['etchat_username'] ?? '';
                $role     = $user['etchat_userprivilegien'] ?? 'user';
                $regRaw   = $user['etchat_reg_timestamp'] ?? '';
                $genderId = $user['etchat_usersex'] ?? '';
                $avatar   = basename($user['etchat_avatar'] ?? '');

                $colors = [
                    'admin'     => $adminc,
                    'mod'       => $modc,
                    'user'      => $userc,
                    'chatwache' => $adminc,
                    'grafik'    => $adminc,
                    'co_admin'  => $adminc
                ];

                $borderColor = $colors[$role] ?? '#CCCCCC';
                
                // ============================================================
                // Rollenname aus XML
                // ============================================================
                $roleKey = 'compact_role_' . $role;
                $roleName = $this->getText($roleKey, ucfirst($role));

                $regDate = '–';
                if (!empty($regRaw) && strtotime($regRaw)) {
                    $regDate = date('d.m.Y', strtotime($regRaw));
                }

                // ============================================================
                // Geschlecht aus XML
                // ============================================================
                $gender = match($genderId) {
                    'm' => $this->getText('compact_gender_male', 'Männlich'),
                    'f' => $this->getText('compact_gender_female', 'Weiblich'),
                    'n' => $this->getText('compact_gender_none', 'keine Angabe'),
                    'd' => $this->getText('compact_gender_diverse', 'Divers'),
                    default => ''
                };

                // ============================================================
                // Tooltip aus XML mit Platzhaltern
                // ============================================================
                $tooltipParts = [
                    $this->replacePlaceholders(
                        $this->getText('compact_tooltip_username', 'Benutzername: {username}'),
                        ['username' => $username]
                    ),
                    $this->replacePlaceholders(
                        $this->getText('compact_tooltip_gender', 'Geschlecht: {gender}'),
                        ['gender' => $gender]
                    ),
                    $this->replacePlaceholders(
                        $this->getText('compact_tooltip_privilege', 'Privileg: {privilege}'),
                        ['privilege' => $roleName]
                    ),
                    $this->replacePlaceholders(
                        $this->getText('compact_tooltip_since', 'Dabei seit: {since}'),
                        ['since' => $regDate]
                    )
                ];
                
                $title = implode("\n", $tooltipParts);

                echo <<<HTML
<div class="compact-user-card"
     title="{$title}"
     style="border-color:{$borderColor}">
    <img src="avatar/{$avatar}" alt="{$username}">
</div>
HTML;
            }
        }

        echo '</div>';
    }

    /**
     * Holt einen Sprachtext mit Fallback
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * Ersetzt Platzhalter in einem String
     */
    private function replacePlaceholders(string $text, array $replacements): string
    {
        foreach ($replacements as $placeholder => $value) {
            $text = str_replace('{' . $placeholder . '}', (string)$value, $text);
        }
        return $text;
    }
}

// Instanz erzeugen
new CompactUserView();