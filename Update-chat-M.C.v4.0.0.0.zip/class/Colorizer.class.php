<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Colorizer extends EtChatConfig
{
    public ?object $lang = null;  // Modernes Sprachobjekt

    public function __construct()
    {
        parent::__construct();

        // Session starten, falls noch nicht gestartet
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Header setzen, falls noch nichts gesendet
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Content-Type: text/html; charset=utf-8');
        }

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        // Template einbinden
        $template = dirname(__DIR__) . "/styles/colorizer.tpl.html";

        if (is_file($template)) {
            include $template;
        } else {
            throw new RuntimeException("Template colorizer.tpl.html nicht gefunden.");
        }
    }

    /**
     * Hilfsmethode für Sprachzugriff im Template
     */
    public function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * Holt ein Array aus der Sprachstruktur
     */
    public function getTextArray(string $key): array
    {
        if ($this->lang !== null) {
            return $this->lang->getArray($key);
        }
        return [];
    }

    /**
     * Prüft ob moderne XML geladen wurde
     */
    public function hasModernLanguage(): bool
    {
        return $this->lang !== null && $this->lang->hasModernXml();
    }
}