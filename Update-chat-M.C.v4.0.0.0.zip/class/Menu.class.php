<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Menu extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        $this->renderMenu();
    }

    private function renderMenu(): void
    {
        $sql = "SELECT id, menu, link_text, image_active, image, url, target, gewicht 
                FROM {$this->_prefix}etchat_menu 
                WHERE menu = 1 
                ORDER BY gewicht";

        $rows = $this->dbObj->sqlGet($sql);
        $this->dbObj->close();

        if (!is_array($rows) || empty($rows)) {
            return;
        }

        foreach ($rows as $row) {

            $linkText    = htmlspecialchars((string)$row['link_text'], ENT_QUOTES, 'UTF-8');
            $imageActive = (int)$row['image_active'];
            $image       = htmlspecialchars((string)$row['image'], ENT_QUOTES, 'UTF-8');
            $url         = htmlspecialchars((string)$row['url'], ENT_QUOTES, 'UTF-8');
            $target      = htmlspecialchars((string)$row['target'], ENT_QUOTES, 'UTF-8');

            echo '<a href="' . $url . '" class="img_home" target="' . $target . '" rel="noopener noreferrer">';

            if ($imageActive === 1 && !empty($image)) {
                echo '<img src="img/menu/' . $image . '" height="40" alt="' . $linkText . '" title="' . $linkText . '">';
            } else {
                echo '<span class="menu_text">' . $linkText . '</span>';
            }

            echo '</a>&nbsp;';
        }
    }
}

new Menu();
