<?php

declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class LangXml extends EtChatConfig
{
    public $langXmlDoc;
    public $lastError = '';
    
    private $xmlDoc = null;
    private $modernKeys = [];

    public function __construct($path = "./lang/", $xmlfile = "")
    {
        parent::__construct();

        // ============================================================
        // Sprache aus Session holen
        // ============================================================
        $sessionFile = $_SESSION['etchat_' . $this->_prefix . 'lang_xml_file'] ?? 'Deutsch';
        
        // Ordnername aus Session (z.B. "Deutsch")
        $langFolder = $sessionFile;
        
        if (empty($langFolder)) {
            $langFolder = 'Deutsch';
        }

        // ============================================================
        // Sprachcode aus Ordnername ableiten (Deutsch -> de)
        // ============================================================
        $langCode = $this->getLangCodeFromFolder($langFolder);

        // ============================================================
        // Admin-Bereich erkennen
        // ============================================================
        $isAdminRequest = false;
        
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5);
        foreach ($backtrace as $call) {
            $class = $call['class'] ?? '';
            if (str_starts_with($class, 'Admin')) {
                $isAdminRequest = true;
                break;
            }
        }
        
        if (str_contains($xmlfile, 'admin')) {
            $isAdminRequest = true;
        }

        // ============================================================
        // Wähle die richtige Datei im Sprach-Ordner
        // ============================================================
        if ($isAdminRequest) {
            $xmlfile = "lang_admin_" . $langCode . "_v2.xml";
        } else {
            $xmlfile = "lang_" . $langCode . "_v2.xml";
        }

        $fullpath = rtrim($path, "/") . "/" . $langFolder . "/" . $xmlfile;
        
        // ============================================================
        // Lade die XML
        // ============================================================
        if (!file_exists($fullpath)) {
            // Fallback: Versuche im Hauptverzeichnis
            $fallbackPath = rtrim($path, "/") . "/" . $xmlfile;
            if (file_exists($fallbackPath)) {
                $fullpath = $fallbackPath;
            } else {
                $this->lastError = "Language file not found: " . $fullpath;
                $this->langXmlDoc = new stdClass();
                $this->xmlDoc = new stdClass();
                return;
            }
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_file($fullpath, 'SimpleXMLElement', LIBXML_NOCDATA);
        
        if ($xml === false) {
            $this->lastError = "Failed to load XML: " . $fullpath;
            $this->langXmlDoc = new stdClass();
            $this->xmlDoc = new stdClass();
            return;
        }

        // ============================================================
        // Parse die XML
        // ============================================================
        $this->xmlDoc = $this->parseModernXml($xml);
        $this->langXmlDoc = $this->buildLegacyStructure($xml);
    }

    /**
     * Wandelt Ordnernamen in Sprachcode um (Deutsch -> de, Englisch -> en)
     */
    private function getLangCodeFromFolder(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
            'Französisch' => 'fr',
            'Spanisch' => 'es',
            'Italienisch' => 'it',
            'Niederländisch' => 'nl',
            'Russisch' => 'ru',
            'Türkisch' => 'tr',
            'Arabisch' => 'ar',
            'Chinesisch' => 'zh',
            'Japanisch' => 'ja',
        ];
        
        return $map[$folder] ?? 'de';
    }

    private function parseModernXml($xml): stdClass
    {
        $result = new stdClass();
        
        foreach ($xml->xpath('//string') as $string) {
            $key = (string)$string['key'];
            $result->$key = trim((string)$string);
            $this->modernKeys[$key] = 'string';
        }
        
        foreach ($xml->xpath('//array') as $array) {
            $key = (string)$array['key'];
            $result->$key = [];
            foreach ($array->item as $item) {
                $result->$key[] = trim((string)$item);
            }
            $this->modernKeys[$key] = 'array';
        }
        
        foreach ($xml->xpath('//struct') as $struct) {
            $key = (string)$struct['key'];
            $obj = new stdClass();
            $obj->value = trim((string)$struct->value);
            $obj->attributes = [];
            foreach ($struct->attr as $attr) {
                $name = (string)$attr['name'];
                $obj->attributes[$name] = trim((string)$attr);
            }
            $result->$key = $obj;
            $this->modernKeys[$key] = 'struct';
        }
        
        return $result;
    }

    private function buildLegacyStructure($xml): stdClass
    {
        $legacy = new stdClass();
        $adminGroups = [];
        $otherKeys = [];
        
        foreach ($xml->xpath('//string') as $string) {
            $key = (string)$string['key'];
            $value = trim((string)$string);
            
            if (str_starts_with($key, 'admin_')) {
                $parts = explode('_', $key, 2);
                $section = $parts[1] ?? '';
                if (!isset($adminGroups[$section])) {
                    $adminGroups[$section] = [];
                }
                $adminGroups[$section][$key] = $value;
            } else {
                $otherKeys[$key] = $value;
            }
        }
        
        $adminObj = new stdClass();
        foreach ($adminGroups as $section => $keys) {
            $sectionObj = new stdClass();
            foreach ($keys as $key => $value) {
                $entry = new stdClass();
                $entry->tagData = $value;
                $entry->tagAttrs = [];
                $sectionObj->$key = $entry;
            }
            $adminObj->$section = [$sectionObj];
        }
        $legacy->admin = [$adminObj];
        
        foreach ($otherKeys as $key => $value) {
            $entry = new stdClass();
            $entry->tagData = $value;
            $entry->tagAttrs = [];
            $legacy->$key = [$entry];
        }
        
        return $legacy;
    }

    public function get(string $key, $default = '')
    {
        if ($this->xmlDoc !== null && isset($this->xmlDoc->$key)) {
            $value = $this->xmlDoc->$key;
            if (is_object($value) && isset($value->value)) {
                return $value->value;
            }
            return $value;
        }
        return $default;
    }

    public function getArray(string $key): array
    {
        $value = $this->get($key);
        return is_array($value) ? $value : [];
    }

    public function getStruct(string $key)
    {
        if ($this->xmlDoc !== null && isset($this->xmlDoc->$key)) {
            $value = $this->xmlDoc->$key;
            if (is_object($value) && isset($value->value)) {
                return $value;
            }
        }
        return null;
    }

    public function getAllStructs(): array
    {
        if ($this->xmlDoc === null) {
            return [];
        }
        
        $structs = [];
        foreach (get_object_vars($this->xmlDoc) as $key => $value) {
            if (is_object($value) && isset($value->value)) {
                $structs[$key] = $value;
            }
        }
        return $structs;
    }

    public function getLang()
    {
        return $this->langXmlDoc;
    }

    public function getLastError(): string
    {
        return $this->lastError;
    }
}