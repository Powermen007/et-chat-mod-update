<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class UnregisterPw extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        $sessionPrefix = 'etchat_' . $this->_prefix;

        $userId = (int)($_SESSION[$sessionPrefix.'user_id'] ?? 0);

        if ($userId <= 0) {
            echo $this->getText('unregister_no_session', 'No Session');
            $this->dbObj->close();
            return;
        }

        $passwordInput = (string)($_POST['user_pw'] ?? '');

        // Benutzerdaten laden
        $user = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien, etchat_userpw, etchat_avatar
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :id
             LIMIT 1",
            [':id' => $userId]
        );

        // 🔄 ASSOZIATIVE INDIZES
        $priv   = $user[0]['etchat_userprivilegien'] ?? '';
        $dbHash = (string)($user[0]['etchat_userpw'] ?? '');

        if (!in_array($priv, ["admin", "mod", "user"], true)) {
            echo $this->getText('unregister_no_permission', 'No, no... ;-)');
            $this->dbObj->close();
            return;
        }

        $passwordOk = false;

        if ($dbHash !== '') {
            // moderner Hash
            if (password_verify($passwordInput, $dbHash)) {
                $passwordOk = true;
            }
            // alter MD5 Hash (Fallback)
            elseif (strlen($dbHash) === 32 && md5($passwordInput) === $dbHash) {
                $passwordOk = true;
            }
        }

        if ($passwordOk) {
            // 🔄 ASSOZIATIVER INDEX
            $avatar = $user[0]['etchat_avatar'] ?? '';

            $filedir = __DIR__ . '/../avatar';

            $protectedAvatars = ["noavatar.jpg", "mod_ohne_pic.png", "autodj.jpg"];
            
            if ($avatar && !in_array($avatar, $protectedAvatars, true)) {
                $avatar = basename($avatar);
                $delfile = $filedir . DIRECTORY_SEPARATOR . $avatar;

                if (file_exists($delfile)) {
                    @unlink($delfile);
                }
            }

            // Account zurücksetzen
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_user
                 SET
                    etchat_userpw = NULL,
                    etchat_userprivilegien = 'gast',
                    etchat_avatar = 'noavatar.jpg',
                    etchat_email = NULL,
                    etchat_reset_token = NULL,
                    etchat_reset_token_expiry = NULL,
                    etchat_geb_tag = NULL,
                    etchat_geb_monat = NULL,
                    etchat_geb_jahr = NULL,
                    etchat_ort = NULL,
                    etchat_beschreibung = NULL
                 WHERE etchat_user_id = :id",
                [':id' => $userId]
            );

            echo "1";
        } else {
            // ===== MODERNISIERT: Fehlermeldung aus XML =====
            $warn1 = $this->getText('unregister_warnings.0', 'Fehler!');
            $warn2 = $this->getText('unregister_warnings.1', 'Passwort ist leider falsch.');
            
            // Fallback für alte Struktur (XML hat Array)
            if (is_array($this->lang) || is_object($this->lang)) {
                $warnings = $this->getTextArray('unregister_warnings');
                if (!empty($warnings)) {
                    $warn1 = $warnings[0] ?? $warn1;
                    $warn2 = $warnings[1] ?? $warn2;
                }
            }
            
            echo "<b>{$warn1}</b><br>{$warn2}";
        }

        $this->dbObj->close();
    }
}