<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class UnregisterPw extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/plain; charset=utf-8'); // 🔥 WICHTIG!

        $this->lang = new LangXml("./lang/");

        $sessionPrefix = 'etchat_' . $this->_prefix;
        $userId = (int)($_SESSION[$sessionPrefix.'user_id'] ?? 0);

        if ($userId <= 0) {
            echo "no_session";
            $this->dbObj->close();
            return;
        }

        $passwordInput = (string)($_POST['user_pw'] ?? '');

        // 🔥 Prüfen ob Passwort überhaupt übergeben wurde
        if (empty($passwordInput)) {
            echo "no_password";
            $this->dbObj->close();
            return;
        }

        // Benutzerdaten laden
        $user = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien, etchat_userpw, etchat_avatar
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :id
             LIMIT 1",
            [':id' => $userId]
        );

        if (empty($user) || empty($user[0])) {
            echo "user_not_found";
            $this->dbObj->close();
            return;
        }

        $priv   = $user[0]['etchat_userprivilegien'] ?? '';
        $dbHash = (string)($user[0]['etchat_userpw'] ?? '');

        // 🔥 Prüfen ob der User überhaupt ein Passwort hat
        if (empty($dbHash)) {
            echo "no_password_set";
            $this->dbObj->close();
            return;
        }

        if (!in_array($priv, ["admin", "mod", "user"], true)) {
            echo "no_permission";
            $this->dbObj->close();
            return;
        }

        $passwordOk = false;

        if (password_verify($passwordInput, $dbHash)) {
            $passwordOk = true;
        } elseif (strlen($dbHash) === 32 && md5($passwordInput) === $dbHash) {
            $passwordOk = true;
        }

        if ($passwordOk) {
            $avatar = $user[0]['etchat_avatar'] ?? '';
            $filedir = __DIR__ . '/../avatar';
            $protectedAvatars = ["noavatar.jpg", "mod_ohne_pic.png", "autodj.jpg"];
            
            if ($avatar && !in_array($avatar, $protectedAvatars, true)) {
                $avatar = basename($avatar);
                $delfile = $filedir . DIRECTORY_SEPARATOR . $avatar;
                if (file_exists($delfile)) {
                    @unlink($delfile);
                }
            }

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_user
                 SET
                    etchat_userpw = '',
                    etchat_userprivilegien = 'gast',
                    etchat_avatar = 'noavatar.jpg',
                    etchat_email = NULL,
                    etchat_reset_token = NULL,
                    etchat_reset_token_expiry = NULL,
                    etchat_geb_tag = NULL,
                    etchat_geb_monat = NULL,
                    etchat_geb_jahr = NULL,
                    etchat_ort = NULL,
                    etchat_beschreibung = NULL
                 WHERE etchat_user_id = :id",
                [':id' => $userId]
            );

            echo "1"; // 🔥 ERFOLG
        } else {
            echo "wrong_password"; // 🔥 FALSCHES PASSWORT
        }

        $this->dbObj->close();
    }
}