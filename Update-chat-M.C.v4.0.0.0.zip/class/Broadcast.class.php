<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Broadcast extends DbConectionMaker
{
    private string $broadcast_file = __DIR__ . '/../cache/broadcast_current.txt';
    private ?object $lang = null;

    /**
     * Hilfsmethode für Sprachzugriff
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * Ersetzt Platzhalter im Text mit Werten
     */
    private function replacePlaceholders(string $text, array $placeholders): string
    {
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', $value, $text);
        }
        return $text;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Content-Type: application/json; charset=utf-8');

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        $function = $_GET['function'] ?? '';

        switch ($function) {

            case 'sendBroadcast':
                $this->sendBroadcast();
                break;

            case 'checkBroadcast':
                $this->checkBroadcast();
                break;

            case 'clearBroadcast':
                $this->clearBroadcast();
                break;

            case 'getBroadcastStatus':
                $this->getBroadcastStatus();
                break;

            default:
                echo json_encode(['error' => 'Unbekannte Funktion']);
        }

        if (isset($this->dbObj)) {
            $this->dbObj->close();
        }

        exit;
    }

    /* -------------------------------------------------- */
    /* ONLINE USER ERMITTELN */
    /* -------------------------------------------------- */

    private function getRealOnlineUsers(): array
    {
        $time_limit = time() - 300;

        $sqlRegistered = "
        SELECT 
            u.etchat_user_id as user_id
        FROM {$this->_prefix}etchat_useronline o
        JOIN {$this->_prefix}etchat_user u 
            ON o.etchat_user_online_user_name = u.etchat_username
        WHERE o.etchat_onlinetimestamp > :time_limit
        AND (
            o.etchat_user_online_user_status_img IS NULL
            OR o.etchat_user_online_user_status_img NOT IN ('status_invisible','status_off')
        )
        AND u.etchat_userprivilegien != 'admin'
        ";

        $sqlGuests = "
        SELECT 
            etchat_onlineuser_fid as user_id
        FROM {$this->_prefix}etchat_useronline
        WHERE etchat_onlinetimestamp > :time_limit
        AND (
            etchat_user_online_user_name LIKE 'Gast%'
            OR etchat_user_online_user_priv = 'gast'
        )
        AND (
            etchat_user_online_user_status_img IS NULL
            OR etchat_user_online_user_status_img NOT IN ('status_invisible','status_off')
        )
        GROUP BY LOWER(TRIM(etchat_user_online_user_name))
        ";

        $sql = "($sqlRegistered) UNION ALL ($sqlGuests)";

        $result = $this->dbObj->sqlGet($sql, [':time_limit' => $time_limit]);

        $users = [];

        if ($result) {
            foreach ($result as $row) {
                if (isset($row['user_id'])) {
                    $users[] = (int)$row['user_id'];
                }
            }
        }

        return array_unique($users);
    }

    /* -------------------------------------------------- */

    private function isUserOnline(int $user_id): bool
    {
        $time_limit = time() - 300;

        $sql = "
        SELECT COUNT(*) as user_count
        FROM {$this->_prefix}etchat_useronline
        WHERE etchat_onlineuser_fid = :user_id
        AND etchat_onlinetimestamp > :time_limit
        AND (
            etchat_user_online_user_status_img IS NULL
            OR etchat_user_online_user_status_img NOT IN ('status_invisible','status_off')
        )
        ";

        $result = $this->dbObj->sqlGet($sql, [
            ':user_id' => $user_id,
            ':time_limit' => $time_limit
        ]);

        return ($result && isset($result[0]['user_count']) && $result[0]['user_count'] > 0);
    }

    /* -------------------------------------------------- */
    /* BROADCAST SENDEN */
    /* -------------------------------------------------- */

    private function sendBroadcast(): void
    {
        $priv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        $allowedRoles = ['admin', 'co_admin'];

        if (!in_array($priv, $allowedRoles)) {
            echo json_encode(['success' => false, 'error' => 'Keine Admin- oder Co-Admin-Rechte']);
            return;
        }

        $message = trim($_POST['message'] ?? '');

        if ($message === '') {
            echo json_encode(['success' => false, 'error' => 'Leere Nachricht']);
            return;
        }

        $timestamp = time();

        $target_users = $this->getRealOnlineUsers();

        $data = [
            'timestamp' => $timestamp,
            'admin_id' => (int)($_POST['admin_id'] ?? 0),
            'message' => $message,
            'no_reload' => (int)($_POST['no_reload'] ?? 0),
            'message_type' => $_POST['message_type'] ?? 'standard',
            'target_users' => $target_users,
            'original_online_count' => count($target_users),
            'seen_by' => []
        ];

        file_put_contents(
            $this->broadcast_file,
            json_encode($data, JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );

        $_SESSION['last_broadcast_seen'] = $timestamp;

        echo json_encode([
            'success' => true,
            'target_count' => count($target_users),
            'message_type' => $data['message_type']
        ]);
    }

    /* -------------------------------------------------- */
    /* BROADCAST CHECKEN */
    /* -------------------------------------------------- */

    private function checkBroadcast(): void
    {
        $current_user_priv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? 'user';
        $current_user_id = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);

        $excludedRoles = ['admin', 'co_admin'];
    
        if (in_array($current_user_priv, $excludedRoles, true)) {
            echo json_encode(['hasBroadcast' => false]);
            return;
        }

        if (!file_exists($this->broadcast_file)) {
            echo json_encode(['hasBroadcast' => false]);
            return;
        }

        $broadcast = $this->readBroadcast();

        if (!$broadcast) {
            echo json_encode(['hasBroadcast' => false]);
            return;
        }

        $seen_by = $broadcast['seen_by'] ?? [];

        if (in_array($current_user_id, $seen_by, true)) {
            echo json_encode(['hasBroadcast' => false]);
            return;
        }

        $is_online = $this->isUserOnline($current_user_id);

        switch ($broadcast['message_type']) {

            case 'standard':

                if (!$is_online) {
                    echo json_encode(['hasBroadcast' => false]);
                    return;
                }

                if (!in_array($current_user_id, $broadcast['target_users'], true)) {
                    echo json_encode(['hasBroadcast' => false]);
                    return;
                }

                break;

            case 'general':
                break;

            case 'welcome':

                if (in_array($current_user_id, $broadcast['target_users'], true)) {
                    echo json_encode(['hasBroadcast' => false]);
                    return;
                }

                if (!$is_online) {
                    echo json_encode(['hasBroadcast' => false]);
                    return;
                }

                break;
        }

        $seen_by[] = $current_user_id;

        $broadcast['seen_by'] = $seen_by;

        file_put_contents(
            $this->broadcast_file,
            json_encode($broadcast, JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );

        echo json_encode([
            'hasBroadcast' => true,
            'message' => $broadcast['message'],
            'no_reload' => $broadcast['no_reload']
        ]);
    }

    /* -------------------------------------------------- */
    /* STATUS */
    /* -------------------------------------------------- */

    private function getBroadcastStatus(): void
    {
        if (!file_exists($this->broadcast_file)) {
            echo json_encode(['hasBroadcast' => false]);
            return;
        }

        $broadcast = $this->readBroadcast();

        if (!$broadcast) {
            echo json_encode(['hasBroadcast' => false]);
            return;
        }

        $current_online = count($this->getRealOnlineUsers());

        echo json_encode([
            'hasBroadcast' => true,
            'message' => $broadcast['message'],
            'timestamp' => $broadcast['timestamp'],
            'time_ago' => $this->getTimeAgo($broadcast['timestamp']),
            'no_reload' => $broadcast['no_reload'] ?? 0,
            'message_type' => $broadcast['message_type'] ?? 'standard',
            'original_online_count' => $broadcast['original_online_count'] ?? count($broadcast['target_users']),
            'target_count' => count($broadcast['target_users']),
            'seen_count' => count($broadcast['seen_by'] ?? []),
            'current_online_count' => $current_online
        ]);
    }

    /* -------------------------------------------------- */
    /* CLEAR */
    /* -------------------------------------------------- */

    private function clearBroadcast(): void
    {
        $priv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        $allowedRoles = ['admin', 'co_admin'];

        if (!in_array($priv, $allowedRoles)) {
            echo json_encode(['success' => false, 'error' => 'Keine Admin- oder Co-Admin-Rechte']);
            return;
        }

        if (file_exists($this->broadcast_file)) {
            unlink($this->broadcast_file);
        }

        echo json_encode(['success' => true]);
    }

    /* -------------------------------------------------- */
    /* HELPER */
    /* -------------------------------------------------- */

    private function readBroadcast(): ?array
    {
        if (!file_exists($this->broadcast_file)) {
            return null;
        }

        $data = file_get_contents($this->broadcast_file);

        if (!$data) {
            return null;
        }

        $json = json_decode($data, true);

        if (!is_array($json) || json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        return $json;
    }

    /* -------------------------------------------------- */
    /* ZEITANGABEN - MODERNISIERT */
    /* -------------------------------------------------- */

    private function getTimeAgo(int $timestamp): string
    {
        $diff = time() - $timestamp;

        // Gerade eben (unter 60 Sekunden)
        if ($diff < 60) {
            return $this->getText('broadcast_just_now', 'Gerade eben');
        }

        // Minuten
        if ($diff < 3600) {
            $m = floor($diff / 60);
            $text = $this->getText('broadcast_minutes_ago', 'Vor {minutes} Minute{n}');
            $n = $m > 1 ? 'n' : '';
            return $this->replacePlaceholders($text, ['minutes' => $m, 'n' => $n]);
        }

        // Stunden
        if ($diff < 86400) {
            $h = floor($diff / 3600);
            $text = $this->getText('broadcast_hours_ago', 'Vor {hours} Stunde{n}');
            $n = $h > 1 ? 'n' : '';
            return $this->replacePlaceholders($text, ['hours' => $h, 'n' => $n]);
        }

        // Tage
        $d = floor($diff / 86400);
        $text = $this->getText('broadcast_days_ago', 'Vor {days} Tag{en}');
        $en = $d > 1 ? 'en' : '';
        return $this->replacePlaceholders($text, ['days' => $d, 'en' => $en]);
    }
}