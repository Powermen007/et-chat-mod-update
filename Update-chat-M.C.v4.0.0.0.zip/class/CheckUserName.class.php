<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class CheckUserName extends DbConectionMaker
{
    public $lang = null;
    protected bool $user_application;
    protected string $username = '';
    protected string $gender = 'n';
    private ?object $modernLang = null;

    private function getCookieName(string $suffix = 'session_active'): string
    {
        $domain = $_SERVER['HTTP_HOST'];
        $domain = str_replace('www.', '', $domain);
        $domain = str_replace('.', '_', $domain);
        $domain = preg_replace('/[^a-zA-Z0-9_]/', '', $domain);
        return 'chat_' . $domain . '_' . $suffix;
    }

    private function getText(string $key, string $default = ''): string
    {
        if ($this->modernLang !== null) {
            return $this->modernLang->get($key, $default);
        }
        return $default;
    }

    private function validateUsernameFormat(string $username): bool {
        if (preg_match('/^[\p{L}\p{N}\s&@\._\-+=#~€$%§]+$/u', $username) !== 1) {
            return false;
        }
        if (preg_match_all('/[&@\._\-+=#~€$%§]/u', $username, $matches) > 3) {
            return false;
        }
        return true;
    }

    private function hasDangerousPatterns(string $username): bool {
        $dangerous = [
            '../', '..\\', './', '.\\',
            '<!--', '-->', '<script', '</script',
            '<?php', '?>', '<%', '%>',
            'javascript:', 'vbscript:', 'onclick=', 'onload=',
            'union select', 'or 1=1', 'drop table', 'delete from',
            '--', '/*', '*/', ';--', "' or '", '" or "'
        ];
        $lowerUser = strtolower($username);
        foreach ($dangerous as $pattern) {
            if (str_contains($lowerUser, strtolower($pattern))) {
                return true;
            }
        }
        return false;
    }

    private function loadBannedWordsFromJson(): array {
        $jsonFile = dirname(__DIR__) . '/cache/verbotene_user_namen.json';
        if (!file_exists($jsonFile)) {
            return [];
        }
        $content = file_get_contents($jsonFile);
        $words = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($words)) {
            return [];
        }
        return $words;
    }

    private function isUsernameAllowed(string $username, array $bannedWords): bool {
        $usernameNorm = mb_strtolower($username, 'UTF-8');
        foreach ($bannedWords as $banned) {
            if (empty(trim($banned))) continue;
            $bannedNorm = mb_strtolower($banned, 'UTF-8');
            if ($usernameNorm === $bannedNorm) return false;
            if (mb_strpos($usernameNorm, $bannedNorm, 0, 'UTF-8') !== false) return false;
        }
        return true;
    }

    public function __construct(bool $user_application = false, string $username = '', string $gender = '')
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
            if (!$user_application) {
                header('Content-Type: application/json; charset=utf-8');
            }
        }

        try {
            $this->modernLang = new LangXml("./lang/");
        } catch (Throwable $e) {
            $this->modernLang = null;
        }

        $this->user_application = $user_application;

        if (!$user_application) {
            $this->username = trim($_POST['username'] ?? '');
            $this->gender = trim($_POST['gender'] ?? 'n');
        } else {
            $this->username = $username;
            $this->gender = $gender ?: 'n';
        }

        if ($user_application) {
            $this->configTabData2Session();

            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_messages WHERE etchat_timestamp < ?", [
                time() - (($_SESSION['etchat_'.$this->_prefix.'loeschen_nach'] ?? 0) * 3600 * 24)
            ]);

            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_blacklist WHERE etchat_blacklist_time < ?", [time()]);
            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_kick_user WHERE etchat_kicked_user_time < ?", [time()]);
            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_user 
                                  WHERE etchat_userprivilegien = 'gast' 
                                  AND etchat_logintime < ?", 
                                  [time() - (($_SESSION['etchat_'.$this->_prefix.'loeschen_nach'] ?? 0) * 3600 * 24 * 2)]);
        }

        if (!$user_application) {
            $domain = $_SERVER['HTTP_HOST'];
            $domain = str_replace('www.', '', $domain);
            $domain = str_replace('.', '_', $domain);
            $domain = preg_replace('/[^a-zA-Z0-9_]/', '', $domain);
            $cookieName = 'chat_' . $domain . '_session_active';
            
            if (!isset($_COOKIE[$cookieName])) {
                $this->errorMessage($this->getText('checkusername_cookie_required', 'Bitte aktivieren Sie Cookies für diese Website.'));
                return;
            }
            
            $cookieValue = $_COOKIE[$cookieName];
            
            if ($cookieValue === '0') {
                $this->errorMessage($this->getText('checkusername_cookie_accept', 'Bitte akzeptieren Sie die Cookie-Richtlinien.'));
                return;
            }
            
            if ($cookieValue !== '1') {
                $this->errorMessage($this->getText('checkusername_cookie_invalid', 'Ungültiger Cookie-Wert.'));
                return;
            }
            
            $_SESSION[$this->_prefix . 'consent'] = 'accepted';
        }

        if (!$user_application) {
            $setCheckKey = $_SESSION[$this->_prefix.'set_check'] ?? null;
            if (!$setCheckKey || !isset($_POST[$setCheckKey])) {
                $this->errorMessage($this->getText('checkusername_no_hacks', 'no hacks and bots'));
                return;
            }
        }

        $isAdmin = false;
        $user_check = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien 
             FROM {$this->_prefix}etchat_user 
             WHERE etchat_username = :username 
             LIMIT 1",
            [':username' => $this->username]
        );
        
        if (!empty($user_check) && in_array($user_check[0]['etchat_userprivilegien'] ?? '', ["admin", "mod", "chatwache", "co_admin", "grafik"])) {
            $isAdmin = true;
        }
        
        if (!$user_application && !$isAdmin && !$this->loginCounter()) {
            return;
        }

        $this->loadColorsFromSession();

        $blackListObj = new Blacklist($this->dbObj);
        if ($blackListObj->userInBlacklist()) {
            if (!$user_application) $this->errorMessage("blacklist");
            $blackListObj->killUserSession();
            if ($user_application) header('Location: ./?AfterBlacklistInsertion');
            return;
        }

        $reloadSeq = $_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] ?? 1000;
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlinetimestamp < ?", [
            time() - ($reloadSeq / 1000 * 4)
        ]);

        if (empty($this->username) || strlen($this->username) > 100) {
            $this->errorMessage($this->getText('checkusername_invalid', 'invalid username'));
            return;
        }
        
        if (strlen($this->username) < 4 || strlen($this->username) > 25) {
            $this->errorMessage($this->getText('checkusername_length', 'Der Benutzername muss zwischen 4 und 25 Zeichen lang sein.'));
            return;
        }
        
        if (!$this->validateUsernameFormat($this->username)) {
            $this->errorMessage($this->getText('checkusername_invalid_chars', 'Der Benutzername enthält nicht erlaubte Zeichen ODER mehr als 3 Sonderzeichen.'));
            return;
        }
        
        if ($this->hasDangerousPatterns($this->username)) {
            $this->errorMessage($this->getText('checkusername_dangerous', 'Der Benutzername enthält ungültige Zeichenkombinationen.'));
            return;
        }
        
        $bannedWords = $this->loadBannedWordsFromJson();
        if (!$this->isUsernameAllowed($this->username, $bannedWords)) {
            $this->errorMessage($this->getText('checkusername_banned', 'Dieser Benutzername ist nicht erlaubt. Bitte wähle einen anderen Namen.'));
            return;
        }
        
        if (preg_match('/^[\s&@\._\-+=#~€$%§]+$/u', $this->username)) {
            $this->errorMessage($this->getText('checkusername_no_letters', 'Der Benutzername muss mindestens einen Buchstaben oder eine Zahl enthalten.'));
            return;
        }
        
        $this->username = htmlspecialchars(str_replace("\\", "/", preg_replace('/[\x00-\x1F\x90\x8F\x81\xA0\x9D]/', '', $this->username)), ENT_QUOTES, "UTF-8");

        if (!$user_application && $this->userInChatNow($this->username)) {
            $this->errorMessage($this->getText('name_busy', 'Dieser Name wird momentan von einem anderen User verwendet.'));
            return;
        }

        $user_exists = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien, etchat_avatar
            FROM {$this->_prefix}etchat_user 
            WHERE etchat_username = :username 
            ORDER BY etchat_userpw DESC",
            [':username' => $this->username]
        );

        $pw = $_POST['pw'] ?? '';
        $userCheckerAndInserterObj = new UserCheckerAndInserter(
            $this->dbObj,
            $user_exists,
            $this->username,
            $pw,
            preg_replace("/[^a-z]/i", "n", $this->gender),
            $this->lang
        );

        if ($userCheckerAndInserterObj->status == 1) {
            $this->messageOnEnter();
        } else {
            $this->errorMessage($userCheckerAndInserterObj->status);
        }
    }

    // ============================================================
    // KORRIGIERT: KEIN PARAMETER BEI sqlGet()!
    // ============================================================
    private function loadColorsFromSession(): void
    {
        $textcolor = $_SESSION['etchat_' . $this->_prefix . 'textcolor'] ?? null;
        $syscolor = $_SESSION['etchat_' . $this->_prefix . 'syscolor'] ?? null;
        
        // Nur wenn BEIDE Werte fehlen, die Config laden
        if ($textcolor === null || $syscolor === null) {
            // ===== KEIN PARAMETER-ARRAY! =====
            $config = $this->dbObj->sqlGet(
                "SELECT etchat_config_style 
                 FROM {$this->_prefix}etchat_config 
                 WHERE etchat_config_id = 1 
                 LIMIT 1"
            );
            
            // Standardfarben setzen, unabhängig vom Ergebnis
            if ($textcolor === null) {
                $textcolor = 'ffffff';
                $_SESSION['etchat_' . $this->_prefix . 'textcolor'] = $textcolor;
            }
            if ($syscolor === null) {
                $syscolor = '00ff02';
                $_SESSION['etchat_' . $this->_prefix . 'syscolor'] = $syscolor;
            }
        }
    }

    private function loginCounter(): bool
    {
        $domain = $_SERVER['HTTP_HOST'];
        $domain = str_replace('www.', '', $domain);
        $domain = str_replace('.', '_', $domain);
        $domain = preg_replace('/[^a-zA-Z0-9_]/', '', $domain);
        $cookieName = 'chat_' . $domain . '_login_counter';
        
        $cookieData = $_COOKIE[$cookieName] ?? null;
        $currentTime = time();
        $maxAttempts = $this->_limit_logins_in_three_minutes ?? 5;
        $resetTime = 180;
        
        if ($cookieData !== null) {
            $parts = explode('|', $cookieData);
            $lastLogin = (int)($parts[0] ?? 0);
            $attempts = (int)($parts[1] ?? 0);
        } else {
            $lastLogin = 0;
            $attempts = 0;
        }
        
        if ($currentTime - $lastLogin > $resetTime) {
            $attempts = 1;
            $lastLogin = $currentTime;
            setcookie($cookieName, $lastLogin . '|' . $attempts, time() + 3600, "/");
            return true;
        }
        
        $attempts++;
        
        if ($attempts > $maxAttempts) {
            $this->errorMessage($this->getText('many_logins', 'Sperre für 3 Minuten! Die Loginprozedur wurde von Ihnen zu oft durchgeführt.'));
            return false;
        }
        
        setcookie($cookieName, $lastLogin . '|' . $attempts, time() + 3600, "/");
        return true;
    }

    private function userInChatNow(string $user): bool
    {
        $res = $this->dbObj->sqlGet(
            "SELECT etchat_username 
             FROM {$this->_prefix}etchat_useronline uo
             JOIN {$this->_prefix}etchat_user u ON u.etchat_user_id = uo.etchat_onlineuser_fid
             WHERE u.etchat_username = :username
             LIMIT 1",
            [':username' => $user]
        );
        
        if (is_array($res) && count($res) > 0) {
            return true;
        }
        return false;
    }

    private function errorMessage(string $message): bool
    {
        echo $message;
        $this->dbObj->close();
        return false;
    }

    private function messageOnEnter(): bool
    {
        new RoomEntrance($this->dbObj, null);
        unset($_SESSION[$this->_prefix.'set_check']);
        $this->dbObj->close();

        if (!$this->user_application) {
            echo "1";
        } else {
            header('Location: ./?Chat');
        }

        return true;
    }
}
?>