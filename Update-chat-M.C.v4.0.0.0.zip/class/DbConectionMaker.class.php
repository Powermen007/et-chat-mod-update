<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

abstract class DbConectionMaker extends EtChatConfig
{
    protected $dbObj;

    protected function __construct()
    {
        parent::__construct();

        if ($this->_usedDatabaseExtension === "pdo") {
            $this->dbObj = new ConnectDB();
        } elseif ($this->_usedDatabaseExtension === "mysqli") {
            $this->dbObj = new ConnectDBMysqli();
        }

        if (!$this->dbObj) {
            throw new RuntimeException("Keine gültige DB Extension konfiguriert.");
        }
    }

    protected function configTabData2Session(): void
    {
        $sql = "SELECT 
            etchat_config_radio_name,
            etchat_config_reloadsequenz,
            etchat_config_messages_im_chat,
            etchat_config_style,
            etchat_config_loeschen_nach,
            etchat_config_lang,
            etchat_config_wu,
            etchat_config_wuan,
            etchat_config_wuza,
            etchat_config_wupau,
            etchat_config_yo,
            etchat_config_bi,
            etchat_config_biup,
            etchat_config_av,
            etchat_config_pro,
            etchat_config_onlie_li,
            etchat_config_radio_box,
            etchat_config_radio_box_hi,
            etchat_config_radio_box_li,
            etchat_config_wb,
            etchat_config_wb_li,
            etchat_config_user_online,
            etchat_config_name_user,
            etchat_config_name_user_anz,
            etchat_config_vollbild,
            etchat_config_admin_color,
            etchat_config_mod_color,
            etchat_config_user_color,
            etchat_config_gast_color,
            etchat_config_time,
            etchat_config_chat_gender,
            etchat_config_chat_privi,
            etchat_config_chat_anzsmily,
            etchat_config_ol_privi,
            etchat_config_be_in_pic,
            etchat_config_chat_pic,
            etchat_config_scroll,
            etchat_config_dj_box_li,
            etchat_config_dj_box,
            etchat_config_radio_se_li,
            etchat_config_radio_se,
            etchat_config_reg_user_an,
            etchat_config_gast,
            etchat_config_wartung,
            etchat_config_reg_an_aus,
            etchat_config_index_team,
            etchat_config_team,
            etchat_config_index_bewer,
            etchat_config_bewer,
            etchat_top_user_onoff,
            etchat_top_user,
            etchat_bot,
            etchat_tab_away_delay
            FROM {$this->_prefix}etchat_config
            WHERE etchat_config_id = 1";

        $feld = $this->dbObj->sqlGet($sql);

        if (empty($feld) || !isset($feld[0])) {
            throw new RuntimeException("Config-Tabelle leer oder nicht erreichbar.");
        }

        $data = $feld[0];

        // Session-Keys wie im alten System setzen (kompatibel!)
        $_SESSION['etchat_'.$this->_prefix.'radio_name']        = $data['etchat_config_radio_name'];
        $_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] = $data['etchat_config_reloadsequenz'];
        $_SESSION['etchat_'.$this->_prefix.'anz_messages_im_chat'] = $data['etchat_config_messages_im_chat'];
        $_SESSION['etchat_'.$this->_prefix.'style']               = $data['etchat_config_style'];
        $_SESSION['etchat_'.$this->_prefix.'loeschen_nach']        = $data['etchat_config_loeschen_nach'];
        $_SESSION['etchat_'.$this->_prefix.'lang_xml_file']        = $data['etchat_config_lang'];
        $_SESSION['etchat_'.$this->_prefix.'wu']                   = $data['etchat_config_wu'];
        $_SESSION['etchat_'.$this->_prefix.'wuan']                 = $data['etchat_config_wuan'];
        $_SESSION['etchat_'.$this->_prefix.'wuza']                 = $data['etchat_config_wuza'];
        $_SESSION['etchat_'.$this->_prefix.'wupau']                = $data['etchat_config_wupau'];
        $_SESSION['etchat_'.$this->_prefix.'yo']                   = $data['etchat_config_yo'];
        $_SESSION['etchat_'.$this->_prefix.'bi']                   = $data['etchat_config_bi'];
        $_SESSION['etchat_'.$this->_prefix.'biup']                 = $data['etchat_config_biup'];
        $_SESSION['etchat_'.$this->_prefix.'av']                   = $data['etchat_config_av'];
        $_SESSION['etchat_'.$this->_prefix.'pro']                  = $data['etchat_config_pro'];
        $_SESSION['etchat_'.$this->_prefix.'online_li']            = $data['etchat_config_onlie_li'];
        $_SESSION['etchat_'.$this->_prefix.'radio_box']            = $data['etchat_config_radio_box'];
        $_SESSION['etchat_'.$this->_prefix.'radio_box_hi']          = $data['etchat_config_radio_box_hi'];
        $_SESSION['etchat_'.$this->_prefix.'radio_box_li']          = $data['etchat_config_radio_box_li'];
        $_SESSION['etchat_'.$this->_prefix.'radio_wb']              = $data['etchat_config_wb'];
        $_SESSION['etchat_'.$this->_prefix.'radio_wb_li']           = $data['etchat_config_wb_li'];
        $_SESSION['etchat_'.$this->_prefix.'user_online']           = $data['etchat_config_user_online'];
        $_SESSION['etchat_'.$this->_prefix.'name_user_online']      = $data['etchat_config_name_user'];
        $_SESSION['etchat_'.$this->_prefix.'name_user_anz']         = $data['etchat_config_name_user_anz'];
        $_SESSION['etchat_'.$this->_prefix.'vollbild']              = $data['etchat_config_vollbild'];
        $_SESSION['etchat_'.$this->_prefix.'admin_color']           = $data['etchat_config_admin_color'];
        $_SESSION['etchat_'.$this->_prefix.'mod_color']              = $data['etchat_config_mod_color'];
        $_SESSION['etchat_'.$this->_prefix.'user_color']             = $data['etchat_config_user_color'];
        $_SESSION['etchat_'.$this->_prefix.'gast_color']             = $data['etchat_config_gast_color'];
        $_SESSION['etchat_'.$this->_prefix.'an-time']                = $data['etchat_config_time'];
        $_SESSION['etchat_'.$this->_prefix.'ch-an-gender']           = $data['etchat_config_chat_gender'];
        $_SESSION['etchat_'.$this->_prefix.'ch-an-privi']            = $data['etchat_config_chat_privi'];
        $_SESSION['etchat_'.$this->_prefix.'chat_anzsmily']          = $data['etchat_config_chat_anzsmily'];
        $_SESSION['etchat_'.$this->_prefix.'ol-an-privi']            = $data['etchat_config_ol_privi'];
        $_SESSION['etchat_'.$this->_prefix.'be_info_pic']            = $data['etchat_config_be_in_pic'];
        $_SESSION['etchat_'.$this->_prefix.'chat_pic']               = $data['etchat_config_chat_pic'];
        $_SESSION['etchat_'.$this->_prefix.'scroll']                 = $data['etchat_config_scroll'];
        $_SESSION['etchat_'.$this->_prefix.'dj_box_li']              = $data['etchat_config_dj_box_li'];
        $_SESSION['etchat_'.$this->_prefix.'dj_box']                 = $data['etchat_config_dj_box'];
        $_SESSION['etchat_'.$this->_prefix.'sendeplan_li']            = $data['etchat_config_radio_se_li'];
        $_SESSION['etchat_'.$this->_prefix.'sendeplan']               = $data['etchat_config_radio_se'];
        $_SESSION['etchat_'.$this->_prefix.'reg_user_an']             = $data['etchat_config_reg_user_an'];
        $_SESSION['etchat_'.$this->_prefix.'gast_zugang']              = $data['etchat_config_gast'];
        $_SESSION['etchat_'.$this->_prefix.'wartung']                  = $data['etchat_config_wartung'];
        $_SESSION['etchat_'.$this->_prefix.'reg_an_aus']               = $data['etchat_config_reg_an_aus'];
        $_SESSION['etchat_'.$this->_prefix.'index_team']               = $data['etchat_config_index_team'];
        $_SESSION['etchat_'.$this->_prefix.'team']                     = $data['etchat_config_team'];
        $_SESSION['etchat_'.$this->_prefix.'index_bewer']               = $data['etchat_config_index_bewer'];
        $_SESSION['etchat_'.$this->_prefix.'bewer']                     = $data['etchat_config_bewer'];
        $_SESSION['etchat_'.$this->_prefix.'top_user_onoff']            = $data['etchat_top_user_onoff'];
        $_SESSION['etchat_'.$this->_prefix.'top_user']                  = $data['etchat_top_user'];
        $_SESSION['etchat_'.$this->_prefix.'etchat_bot']                = $data['etchat_bot'];
        $_SESSION['etchat_'.$this->_prefix.'tab_away_delay']             = $data['etchat_tab_away_delay'];

        // Radio Box Daten
        $radio = $this->dbObj->sqlGet(
            "SELECT etchat_radio_box, etchat_titel_an 
             FROM {$this->_prefix}etchat_radio_box 
             WHERE etchat_radio_id = 1"
        );

        if (!empty($radio[0])) {
            $_SESSION['etchat_'.$this->_prefix.'etchat_radio_box'] = $radio[0]['etchat_radio_box'] ?? null;
            $_SESSION['etchat_'.$this->_prefix.'titelliste']       = $radio[0]['etchat_titel_an'] ?? null;
        }
    }
}