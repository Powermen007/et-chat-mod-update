<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Chat extends EtChatConfig
{
    public ?object $lang = null;  // Modernes Sprachobjekt

    public function __construct()
    {
        parent::__construct();

        // Session starten falls noch nicht
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Header nur senden, wenn noch nicht gesendet
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        // Alte Reload-Variable entfernen
        unset($_SESSION['etchat_' . $this->_prefix . 'reload_user_anz']);

        // Prüfen, ob Username gesetzt ist, sonst zurück auf Login
        if (empty($_SESSION['etchat_' . $this->_prefix . 'username'])) {
            header('Location: ./');
            exit;
        }

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        // Zufallszahl für User-Session
        $_SESSION['etchat_' . $this->_prefix . 'random_user_number'] = random_int(1, 99999999999);

        // Template laden
        $this->initTemplate();
    }

    /**
     * Hilfsmethode für Sprachzugriff im Template
     */
    public function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * Holt ein Array aus der Sprachstruktur
     */
    public function getTextArray(string $key): array
    {
        if ($this->lang !== null) {
            return $this->lang->getArray($key);
        }
        return [];
    }

    /**
     * Prüft ob moderne XML geladen wurde
     */
    public function hasModernLanguage(): bool
    {
        return $this->lang !== null && $this->lang->hasModernXml();
    }

    private function initTemplate(): void
    {
        $style = basename($_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'etchat_dino_styles');
        $templatePath = __DIR__ . "/../styles/{$style}/chat.tpl.html";

        if (is_file($templatePath)) {
            include_once($templatePath);
        } else {
            die("Template nicht gefunden: {$templatePath}");
        }
    }
}