<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Erg�nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Erg�nzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Box extends DbConectionMaker
{
    private $id;
    
    public function __construct($id = 4)
    {
        parent::__construct();
        $this->id = $id;
    }

    public function render(): void
    {
        $sql = "SELECT id, ort, header_text, content
                FROM {$this->_prefix}etchat_start_boxes
                WHERE id = ?
                LIMIT 1";

        $result = $this->dbObj->sqlGet($sql, [$this->id]);

        if ($result && isset($result[0])) {
            // ?? Nur assoziative Indizes (kein Fallback auf numerisch)
            $header  = $result[0]['header_text'] ?? '';
            $content = $result[0]['content'] ?? '';

            if (!empty($header)) {
                echo '<h2 style="margin-top:0.05px;margin-bottom:0.05px;text-align:center;">';
                echo htmlspecialchars_decode($header, ENT_QUOTES);
                echo '</h2>';
            }

            if (!empty($content)) {
                echo htmlspecialchars_decode($content, ENT_QUOTES);
            }
        }

        $this->dbObj->close();
    }
}