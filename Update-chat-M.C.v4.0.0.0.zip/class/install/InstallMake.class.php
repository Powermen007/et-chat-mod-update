<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class InstallMake extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (!isset($_GET['runInstall'])) {
            $this->showInstallLoadingScreen();
            return;
        }

        $this->runInstall();
    }

    private function showInstallLoadingScreen()
    {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Installation wird ausgef&uuml;hrt.</title>
            <style>
                body {
                    background: #1f2430;
                    color: #ffffff;
                    font-family: Arial, sans-serif;
                    text-align: center;
                    padding-top: 100px;
                }
                .spinner {
                    margin: 40px auto;
                    width: 60px;
                    height: 60px;
                    border: 8px solid #3a4050;
                    border-top: 8px solid #00e676;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                .message {
                    font-size: 18px;
                    color: #ccc;
                }
                #result {
                    margin-top: 30px;
                }
                .error-box {
                    background: #2a1a1a;
                    border: 1px solid #ff4444;
                    border-radius: 8px;
                    padding: 20px;
                    margin: 20px auto;
                    max-width: 800px;
                    text-align: left;
                }
                .error-box h2 {
                    color: #ff4444;
                    margin-top: 0;
                }
                .error-box li {
                    color: #ff8888;
                    margin: 5px 0;
                    word-break: break-all;
                }
                .success-box {
                    background: #1a2a1a;
                    border: 1px solid #44ff44;
                    border-radius: 8px;
                    padding: 20px;
                    margin: 20px auto;
                    max-width: 800px;
                }
                .success-box h2 {
                    color: #44ff44;
                    margin-top: 0;
                }
            </style>
        </head>
        <body>
            <div class="spinner"></div>
            <div class="message">Installation wird ausgef&uuml;hrt... Bitte einen Moment Geduld.</div>
            <div id="result"></div>

            <script>
                let params = new URLSearchParams(window.location.search);
                params.set("runInstall", "1");
                let newUrl = window.location.pathname + "?" + params.toString();

                let iframe = document.createElement("iframe");
                iframe.style.display = "none";
                iframe.src = newUrl;
                document.body.appendChild(iframe);

                iframe.onload = function () {
                    document.getElementById("result").innerHTML = iframe.contentDocument.body.innerHTML;
                    document.querySelector(".spinner").style.display = "none";
                    document.querySelector(".message").innerText = "Installation abgeschlossen!";
                };
                
                iframe.onerror = function () {
                    document.getElementById("result").innerHTML = "<div class='error-box'><h2>Fehler bei der Installation</h2><p>Die Installation konnte nicht abgeschlossen werden. Bitte prüfen Sie die Server-Logs.</p></div>";
                    document.querySelector(".spinner").style.display = "none";
                    document.querySelector(".message").innerText = "Installation fehlgeschlagen!";
                };
            </script>
        </body>
        </html>
        <?php
        exit;
    }

    /**
     * Teilt SQL-Statements korrekt bei ";" auf, 
     * aber ignoriert ";" die innerhalb von Anführungszeichen stehen.
     */
    private function splitSqlStatements(string $sql): array
    {
        $statements = [];
        $current = '';
        $inString = false;
        $stringChar = '';
        $len = strlen($sql);
        $i = 0;
        
        while ($i < $len) {
            $char = $sql[$i];
            
            // Prüfen ob wir in einem String sind
            if (!$inString && ($char === "'" || $char === '"')) {
                $inString = true;
                $stringChar = $char;
                $current .= $char;
                $i++;
                continue;
            }
            
            // String beenden
            if ($inString && $char === $stringChar) {
                // Prüfen ob es ein escaped String ist (Backslash davor)
                if ($i > 0 && $sql[$i-1] === '\\') {
                    $current .= $char;
                    $i++;
                    continue;
                }
                $inString = false;
                $stringChar = '';
                $current .= $char;
                $i++;
                continue;
            }
            
            // Statement-Trenner ";" (nur außerhalb von Strings)
            if (!$inString && $char === ';') {
                $trimmed = trim($current);
                if (!empty($trimmed)) {
                    $statements[] = $trimmed;
                }
                $current = '';
                $i++;
                continue;
            }
            
            $current .= $char;
            $i++;
        }
        
        // Letztes Statement
        $trimmed = trim($current);
        if (!empty($trimmed)) {
            $statements[] = $trimmed;
        }
        
        return $statements;
    }

    private function runInstall()
    {
        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

        // SQL-Datei auswählen
        if ($this->_usedDatabase == "mysql") {
            $sql_dump = "install/mysql_db.sql";
        } elseif ($this->_usedDatabase == "pgsql") {
            $sql_dump = "install/postgres_db.sql";
        } else {
            echo "<div class='error-box'><h2>Fehler</h2><p>Unbekannte Datenbank: " . htmlspecialchars($this->_usedDatabase) . "</p></div>";
            return;
        }

        if (!file_exists($sql_dump)) {
            echo "<div class='error-box'><h2>Fehler</h2><p>SQL-Datei nicht gefunden: " . htmlspecialchars($sql_dump) . "</p></div>";
            return;
        }

        // SQL-Datei einlesen
        $sqlContent = file_get_contents($sql_dump);
        
        // Tabellen-Prefix ersetzen
        $sqlContent = str_replace("###prefix###", $this->_prefix, $sqlContent);
        
        // Kommentare entfernen (einzeilig --)
        $lines = explode("\n", $sqlContent);
        $filteredLines = [];
        foreach ($lines as $line) {
            // Entferne einzeilige Kommentare (-- am Anfang oder nach Leerzeichen)
            $line = preg_replace('/^\s*--.*$/', '', $line);
            // Entferne MySQL-spezifische Kommentare /*! ... */
            $line = preg_replace('/\/\*![0-9]{5}.*?\*\//', '', $line);
            if (trim($line) !== '') {
                $filteredLines[] = $line;
            }
        }
        $sqlContent = implode("\n", $filteredLines);
        
        // Statements korrekt aufteilen
        $sqlStatements = $this->splitSqlStatements($sqlContent);
        
        $success_count = 0;
        $error_count = 0;
        $errors = [];

        // Jedes Statement einzeln ausführen
        foreach ($sqlStatements as $statement) {
            $statement = trim($statement);
            if (empty($statement)) continue;
            
            try {
                $result = $this->dbObj->sqlSet($statement);
                if ($result !== false) {
                    $success_count++;
                } else {
                    $error_count++;
                    $errors[] = substr($statement, 0, 150) . "...";
                }
            } catch (Exception $e) {
                $error_count++;
                $errors[] = "Fehler: " . $e->getMessage() . " in: " . substr($statement, 0, 100) . "...";
                error_log("InstallFehler: " . $e->getMessage() . " in SQL: " . substr($statement, 0, 500));
            }
        }

        // Ergebnis anzeigen
        if ($error_count === 0) {
            include_once("styles/install_tpl/installed.tpl.html");
        } else {
            echo "<div class='error-box'>";
            echo "<h2>Installation fehlgeschlagen</h2>";
            echo "<p><strong>Erfolgreiche Statements:</strong> $success_count</p>";
            echo "<p><strong>Fehlgeschlagene Statements:</strong> $error_count</p>";
            
            if (!empty($errors)) {
                echo "<h3>Fehlerdetails (erste 10):</h3>";
                echo "<ul>";
                $limit = min(10, count($errors));
                for ($i = 0; $i < $limit; $i++) {
                    echo "<li>" . htmlspecialchars($errors[$i]) . "</li>";
                }
                if (count($errors) > 10) {
                    echo "<li>... und " . (count($errors) - 10) . " weitere Fehler</li>";
                }
                echo "</ul>";
            }
            echo "</div>";
        }
    }
}