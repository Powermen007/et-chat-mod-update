<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

$GLOBALS["path"] = "./";

spl_autoload_register(function($class_name) {
    require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class Weiterleitung extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // Session starten falls nicht vorhanden
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ===== MODERNE SPRACHE LADEN (dynamisch) =====
        try {
            $this->lang = new LangXml("./lang/");
        } catch (Throwable $e) {
            $this->lang = null;
        }

        // 🔄 ASSOZIATIVER INDEX
        $config = $this->dbObj->sqlGet(
            "SELECT etchat_config_id, etchat_config_style 
             FROM {$this->_prefix}etchat_config 
             WHERE etchat_config_id = 1 
             LIMIT 1"
        );

        $style = $config[0]['etchat_config_style'] ?? 'etchat_dino_styles';
        
        $this->dbObj->close();

        // ===== TEXTE AUS XML =====
        $title = $this->getText('redirect_title', 'Weiterleitung');
        $heading = $this->getText('redirect_heading', 'WEITERLEITUNGSHINWEIS');
        $text = $this->getText('redirect_text', '');
        $buttonText = $this->getText('redirect_button', 'Weiter zum Link');
        $invalidLinkText = $this->getText('redirect_invalid_link', 'Ungültiger Link. Nur http:// und https:// sind erlaubt.');

?>
<!DOCTYPE html>
<html lang="de">

<head>
<title><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="styles/<?php echo htmlspecialchars($style, ENT_QUOTES, 'UTF-8'); ?>/style.css" rel="stylesheet" type="text/css"/>
</head>
<body id="body">

<center>
<div id="info">
<h1><?php echo htmlspecialchars($heading, ENT_QUOTES, 'UTF-8'); ?></h1><br/>
<p><?php echo nl2br(htmlspecialchars($text, ENT_QUOTES, 'UTF-8')); ?></p><br/>

<?php
if (isset($_GET['url'])) {
    // 🔄 SICHER: URL escapen (aber nicht für JavaScript, nur für href)
    $link = htmlspecialchars($_GET['url'], ENT_QUOTES, 'UTF-8');
    // Zusätzliche Prüfung: Erlaube nur http/https Links
    if (str_starts_with($link, 'http://') || str_starts_with($link, 'https://')) {
        echo "<a href=\"{$link}\" rel=\"nofollow noreferrer noopener\"><h1>" . htmlspecialchars($buttonText, ENT_QUOTES, 'UTF-8') . "</h1></a>";
    } else {
        echo "<p>" . htmlspecialchars($invalidLinkText, ENT_QUOTES, 'UTF-8') . "</p>";
    }
}
?>

<br/><br/>
</div>
</center>
</body>
</html>

<?php
    }
}
?>