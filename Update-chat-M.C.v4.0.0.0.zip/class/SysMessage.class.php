<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class SysMessage extends EtChatConfig
{
    protected $dbObj;
    public $lastInsertedId;

    public function __construct($dbObj, string $message, int $room_fid, int $privat)
    {
        parent::__construct();

        // Systemfarbe aus Session holen
        $sysColor = $_SESSION['etchat_' . $this->_prefix . 'syscolor'] ?? '00ff02';
        $css = 'color:#' . $sysColor . ';font-weight:normal;font-style:normal;';

        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        // INSERT mit Prepared Statement
        $dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_messages
            (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat, etchat_user_ip)
            VALUES (:uid, :msg, :css, :ts, :room, :priv, :ip)",
            [
                ':uid'  => 1,
                ':msg'  => $message,
                ':css'  => $css,
                ':ts'   => time(),  // 🔄 time() statt date('U')
                ':room' => $room_fid,
                ':priv' => $privat,
                ':ip'   => $ip
            ]
        );

        // 🔄 Letzte ID sicher holen
        if (!empty($dbObj->lastId)) {
            $this->lastInsertedId = $dbObj->lastId;
        } else {
            // Fallback: max ID aus der Datenbank holen (assoziativ)
            $lastID = $dbObj->sqlGet(
                "SELECT MAX(etchat_id) as max_id FROM {$this->_prefix}etchat_messages"
            );
            $this->lastInsertedId = (int)($lastID[0]['max_id'] ?? 0);
        }
    }
}