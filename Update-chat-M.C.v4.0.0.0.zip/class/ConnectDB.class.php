<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ConnectDB extends EtChatConfig
{
    protected ?PDO $_connid = null;
    public int $lastId = 0;

    public function __construct()
    {
        parent::__construct();

        try {
            $dsn = "{$this->_usedDatabase}:host={$this->_sqlhost};dbname={$this->_database};charset=utf8mb4";

            $this->_connid = new PDO(
                $dsn,
                $this->_sqluser,
                $this->_sqlpass,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => true,
                ]
            );

        } catch (PDOException $e) {
            error_log("PDO Verbindungsfehler: " . $e->getMessage());
            echo "Datenbankverbindung fehlgeschlagen.";
            exit;
        }
    }

    /**
     * Führt ein SELECT-Statement aus.
     * Unterstützt sowohl Queries mit Platzhaltern als auch ohne.
     */
    public function sqlGet(string $sql, array $params = []): array|false
    {
        if ($sql === '') return false;

        try {
            // Prüfen ob die Query Platzhalter enthält
            $hasPlaceholders = strpos($sql, '?') !== false || strpos($sql, ':') !== false;
            
            // Wenn KEINE Platzhalter in der Query, aber Parameter übergeben werden → Parameter ignorieren
            if (!$hasPlaceholders && !empty($params)) {
                $params = [];
            }

            $stmt = $this->_connid->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result ?: false;
        } catch (PDOException $e) {
            error_log("PDO sqlGet Fehler: " . $e->getMessage());
            return false;
        }
    }

    public function sqlSet(string $sql, array $params = []): bool|int
    {
        if ($sql === '') return false;

        try {
            // Prüfen ob die Query Platzhalter enthält
            $hasPlaceholders = strpos($sql, '?') !== false || strpos($sql, ':') !== false;
            
            // Wenn KEINE Platzhalter in der Query, aber Parameter übergeben werden → Parameter ignorieren
            if (!$hasPlaceholders && !empty($params)) {
                $params = [];
            }

            $stmt = $this->_connid->prepare($sql);
            $stmt->execute($params);
            $this->lastId = (int)$this->_connid->lastInsertId();
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("PDO sqlSet Fehler: " . $e->getMessage());
            return false;
        }
    }

    public function sqlExec(string $sql): bool|int
    {
        if ($sql === '') return false;

        try {
            $affected = $this->_connid->exec($sql);
            if ($affected === false) {
                return false;
            }
            $this->lastId = (int)$this->_connid->lastInsertId();
            return $affected;
        } catch (PDOException $e) {
            error_log("PDO sqlExec Fehler: " . $e->getMessage());
            return false;
        }
    }

    public function getConnection(): ?PDO
    {
        return $this->_connid;
    }

    public function close(): void
    {
        $this->_connid = null;
    }
}