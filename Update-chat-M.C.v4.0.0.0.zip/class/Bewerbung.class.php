<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

require_once __DIR__ . '/LangXml.class.php';
require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Bewerbung extends DbConectionMaker
{
    protected string $styleName = 'etchat_dino_styles';
    private ?LangXml $lang = null;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        parent::__construct();

        // ============================================================
        // Sprache laden
        // ============================================================
        try {
            $this->lang = new LangXml("./lang/");
        } catch (Throwable $e) {
            $this->lang = null;
        }

        // ============================================================
        // Style aus DB holen
        // ============================================================
        $config = $this->dbObj->sqlGet(
            "SELECT etchat_config_style
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = 1
             LIMIT 1",
            [1]
        );

        $this->styleName = $config[0]['etchat_config_style'] ?? 'etchat_dino_styles';
    }

    /**
     * Holt einen Sprachtext mit Fallback
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * Ersetzt Platzhalter in einem String
     */
    private function replacePlaceholders(string $text, array $replacements): string
    {
        foreach ($replacements as $placeholder => $value) {
            $text = str_replace('{' . $placeholder . '}', (string)$value, $text);
        }
        return $text;
    }

    public function getStyleName(): string
    {
        return $this->styleName;
    }

    public function getDb(): ConnectDB
    {
        return $this->dbObj;
    }

    public function senden(array $daten): string
    {
        // ============================================================
        // Spam Honeypots
        // ============================================================
        if (!empty($daten['https_ceck']) || !empty($daten['www'])) {
            return $this->getText('bewerbung_spam_detected', 'Spam erkannt!');
        }

        // ============================================================
        // Captcha (case-insensitive)
        // ============================================================
        $captchaInput = trim($daten['web_php_de'] ?? '');
        $captchaSession = $_SESSION['captcha_text'] ?? '';

        if ($captchaInput === '' || $captchaSession === '' ||
            strcasecmp($captchaInput, $captchaSession) !== 0) {
            return $this->getText('bewerbung_captcha_wrong', 'Falsches Captcha! Bitte erneut versuchen.');
        }

        // ============================================================
        // DB Speicherung
        // ============================================================
        $saveData = $daten;

        unset(
            $saveData['https_ceck'],
            $saveData['www'],
            $saveData['web_php_de'],
            $saveData['action']
        );

        $jsonData = json_encode($saveData, JSON_UNESCAPED_UNICODE);

        $this->dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_bewerbungen
            (bewerber_daten, status)
            VALUES (:json, 'neu')",
            [':json' => $jsonData]
        );

        global $host, $sendemail, $mailpass, $smtpsecure, $port;

        try {
            // ============================================================
            // Mail an Admin
            // ============================================================
            $betreff = $daten['Betreff'] ?? 'Unbekannte Bewerbung';
            $fromName = $this->getText('bewerbung_email_from_name', 'Chat Bewerbungsformular');

            $mailAdmin = $this->createMailer();
            $mailAdmin->setFrom($sendemail, $fromName);
            $mailAdmin->addAddress($sendemail);

            $mailAdmin->Subject = $this->replacePlaceholders(
                $this->getText('bewerbung_email_subject', 'Neue Bewerbung: {betreff}'),
                ['betreff' => $betreff]
            );

            $fixedOrder = ['Betreff', 'Anrede', 'Name', 'Modiename'];

            $heading = $this->getText('bewerbung_email_heading', 'Neue Bewerbung eingegangen');
            $message = "<h2>{$heading}</h2><table>";

            foreach ($fixedOrder as $field) {
                if (!empty($daten[$field])) {
                    $message .= "<tr>
                                    <td><strong>{$field}:</strong></td>
                                    <td>" . htmlspecialchars($daten[$field], ENT_QUOTES, 'UTF-8') . "</td>
                                </tr>";
                }
            }

            $skip = array_merge($fixedOrder, ['https_ceck', 'www', 'web_php_de', 'action']);

            foreach ($daten as $key => $val) {
                if (in_array($key, $skip, true)) {
                    continue;
                }

                if (is_array($val)) {
                    $val = implode(", ", $val);
                }

                $message .= "<tr>
                                <td><strong>{$key}:</strong></td>
                                <td>" . htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8') . "</td>
                            </tr>";
            }

            $message .= "</table>";

            $mailAdmin->isHTML(true);
            $mailAdmin->Body = $message;
            $mailAdmin->AltBody = strip_tags($message);
            $mailAdmin->send();

            // ============================================================
            // Bestätigung an Bewerber
            // ============================================================
            if (!empty($daten['E_Mail'])) {
                $mailBewerber = $this->createMailer();
                $mailBewerber->setFrom($sendemail, $fromName);
                $mailBewerber->addAddress($daten['E_Mail'], $daten['Name'] ?? 'Bewerber');

                $mailBewerber->Subject = $this->replacePlaceholders(
                    $this->getText('bewerbung_email_bestätigung_subject', 'Ihre Bewerbung: {betreff}'),
                    ['betreff' => $betreff]
                );

                $textTemplate = $this->getText(
                    'bewerbung_email_bestätigung_text',
                    "Hallo {name},\n\nvielen Dank für Ihre Bewerbung als {betreff}.\nWir haben Ihre Bewerbung erhalten und melden uns zeitnah.\n\nViele Grüße\nDas Team"
                );

                $text = $this->replacePlaceholders($textTemplate, [
                    'name' => $daten['Name'] ?? '',
                    'betreff' => $betreff
                ]);

                $mailBewerber->isHTML(true);
                $mailBewerber->Body = nl2br(htmlspecialchars($text));
                $mailBewerber->AltBody = $text;
                $mailBewerber->send();
            }

            return $this->getText('bewerbung_success', 'Bewerbung erfolgreich gesendet!');

        } catch (Exception $e) {
            $errorMsg = $this->getText('bewerbung_send_error', 'Fehler beim Versenden: ');
            return $errorMsg . $e->getMessage();
        }
    }

    private function createMailer(): PHPMailer
    {
        global $host, $sendemail, $mailpass, $smtpsecure, $port;

        $mail = new PHPMailer(true);
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        $mail->isSMTP();
        $mail->Host = $host;
        $mail->SMTPAuth = true;
        $mail->Username = $sendemail;
        $mail->Password = $mailpass;
        $mail->SMTPSecure = $smtpsecure;
        $mail->Port = (int)$port;

        return $mail;
    }
}