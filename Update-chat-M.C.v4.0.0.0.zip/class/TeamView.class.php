<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class TeamView extends DbConectionMaker
{
    public array $rolesFound = [];
    protected string $styleName = 'etchat_dino_styles';
    protected string $defaultRole = 'mod';

    protected string $adminColor = '#FF0000';
    protected string $modColor = '#00AAFF';
    protected string $userColor = '#CCCCCC';

    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function getRoleName(string $role): string
    {
        $names = [
            'admin' => $this->getText('profil_privilege_admin', 'Administrator'),
            'co_admin' => $this->getText('profil_privilege_co_admin', 'Co-Administrator'),
            'mod' => $this->getText('profil_privilege_mod', 'Moderator'),
            'chatwache' => $this->getText('profil_privilege_chatwache', 'Chatwache'),
            'grafik' => $this->getText('profil_privilege_grafik', 'Grafiker'),
            'user' => $this->getText('profil_privilege_user', 'Benutzer')
        ];
        return $names[$role] ?? ucfirst($role);
    }

    private function getGenderText(string $gender): string
    {
        return match($gender) {
            'm' => $this->getText('profil_gender_male', 'Männlich'),
            'f' => $this->getText('profil_gender_female', 'Weiblich'),
            'n' => $this->getText('profil_not_specified', 'keine Angabe'),
            'd' => $this->getText('profil_gender_diverse', 'Divers'),
            default => ''
        };
    }

    public function __construct()
    {
        parent::__construct();

        // Session starten falls nicht vorhanden
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ===== MODERNE SPRACHE LADEN =====
        try {
            $this->lang = new LangXml("./lang/");
        } catch (Throwable $e) {
            error_log("TeamView language load error: " . $e->getMessage());
            $this->lang = null;
        }

        $this->loadConfig();
        $this->renderHTML();
        $this->dbObj->close();
    }

    private function loadConfig(): void
    {
        $config = $this->dbObj->sqlGet(
            "SELECT etchat_config_admin_color, etchat_config_mod_color, etchat_config_user_color, etchat_config_style
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = ?",
            [1]
        );

        if (!empty($config[0])) {
            $this->styleName = $config[0]['etchat_config_style'] ?? 'etchat_dino_styles';
            $this->adminColor = $config[0]['etchat_config_admin_color'] ?? '#FF0000';
            $this->modColor   = $config[0]['etchat_config_mod_color'] ?? '#00AAFF';
            $this->userColor  = $config[0]['etchat_config_user_color'] ?? '#CCCCCC';
        }
    }

    private function getUsers(): array
    {
        return $this->dbObj->sqlGet(
            "SELECT etchat_username, etchat_userprivilegien, etchat_reg_timestamp, etchat_usersex,
                    etchat_avatar, etchat_email, etchat_geb_tag, etchat_geb_monat, etchat_geb_jahr,
                    etchat_ort, etchat_beschreibung
             FROM {$this->_prefix}etchat_user
             WHERE etchat_userprivilegien IN ('admin','co_admin','mod','chatwache','grafik')
             ORDER BY etchat_user_id DESC"
        ) ?: [];
    }

    private function renderHTML(): void
    {
        $users = $this->getUsers();

        echo '<!DOCTYPE html><html lang="de"><head>';
        echo '<meta charset="UTF-8">';
        echo '<title>' . $this->getText('team_title', 'Teamübersicht') . '</title>';
        echo '<link href="styles/' . htmlspecialchars($this->styleName, ENT_QUOTES | ENT_SUBSTITUTE) . '/style.css" rel="stylesheet">';
        echo '<link href="styles/' . htmlspecialchars($this->styleName, ENT_QUOTES | ENT_SUBSTITUTE) . '/style-mobil-index.css" rel="stylesheet">';
        echo '</head><body id="body">';

        $roles = [];
        foreach ($users as $user) {
            $roles[$user['etchat_userprivilegien']] = true;
        }
        $this->rolesFound = $roles;
        $this->defaultRole = $this->determineDefaultRole($roles);

        // ===== MODERNISIERT: Überschrift aus XML =====
        echo '<center><h2 id="role-title">' . $this->getText('team_heading_mod', 'Unsere Moderatoren') . '</h2></center>';
        echo '<div class="role-tabs" data-default-role="' . htmlspecialchars($this->defaultRole) . '">';
        if (!empty($roles['mod'])) echo '<button class="role-tab" data-role="mod">' . $this->getText('team_tab_mod', 'Moderatoren') . '</button>';
        if (!empty($roles['admin']) || !empty($roles['co_admin'])) echo '<button class="role-tab" data-role="admin-group">' . $this->getText('team_tab_admin', 'Administratoren') . '</button>';
        if (!empty($roles['chatwache'])) echo '<button class="role-tab" data-role="chatwache">' . $this->getText('team_tab_chatwache', 'Chatwache') . '</button>';
        if (!empty($roles['grafik'])) echo '<button class="role-tab" data-role="grafik">' . $this->getText('team_tab_grafik', 'Grafiker') . '</button>';
        echo '</div>';

        echo '<div class="compact-mod-row">';
        foreach ($users as $user) {
            $this->renderCard($user);
        }
        echo '</div>';

        $this->renderJS();
        echo '</body></html>';
    }

    private function determineDefaultRole(array $roles): string
    {
        if (!empty($roles['mod'])) return 'mod';
        if (!empty($roles['admin']) || !empty($roles['co_admin'])) return 'admin-group';
        if (!empty($roles['chatwache'])) return 'chatwache';
        if (!empty($roles['grafik'])) return 'grafik';
        return 'mod';
    }

    private function renderCard(array $user): void
    {
        $role = $user['etchat_userprivilegien'] ?? 'user';
        $this->rolesFound[$role] = true;

        $colors = [
            'admin' => $this->adminColor,
            'co_admin' => $this->adminColor,
            'mod' => $this->modColor,
            'chatwache' => $this->adminColor,
            'grafik' => $this->adminColor,
            'user' => $this->userColor
        ];
        $color = $colors[$role] ?? '#CCCCCC';

        $roleName = $this->getRoleName($role);

        $username = htmlspecialchars($user['etchat_username'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE);
        $avatar = basename($user['etchat_avatar'] ?? '');
        
        // ===== MODERNISIERT: Registrierungsdatum =====
        $noData = $this->getText('team_no_data', '-');
        $regDate = !empty($user['etchat_reg_timestamp']) ? date('d.m.Y', strtotime($user['etchat_reg_timestamp'])) : $noData;
        
        // ===== MODERNISIERT: Geschlecht =====
        $gender = $this->getGenderText($user['etchat_usersex'] ?? '');

        // Geburtstag / Alter
        $birth = '';
        $today = new DateTime('today');
        if (!empty($user['etchat_geb_tag']) && !empty($user['etchat_geb_monat'])) {
            $year = $user['etchat_geb_jahr'] ?? null;
            $birthDate = $year ? sprintf("%04d-%02d-%02d", $year, $user['etchat_geb_monat'], $user['etchat_geb_tag']) : null;
            $birthFormatted = $year
                ? sprintf("%02d.%02d.%04d", $user['etchat_geb_tag'], $user['etchat_geb_monat'], $year)
                : sprintf("%02d.%02d.", $user['etchat_geb_tag'], $user['etchat_geb_monat']);

            try {
                if ($birthDate) {
                    $birthDateObj = new DateTime($birthDate);
                    $age = $birthDateObj->diff($today)->y;
                }
                $isBirthday = ($today->format('d') == $user['etchat_geb_tag'] && $today->format('m') == $user['etchat_geb_monat']);
                if ($isBirthday) {
                    $birth = "<span style='color:red; font-weight:bold;'>{$birthFormatted}" . ($year ? " ({$age})" : "") .
                             " <img src=\"img/cake.png\" alt=\"Geburtstag\" style=\"width:16px;height:16px;vertical-align:middle;\"></span>";
                } else {
                    $birth = $birthFormatted . ($year ? " ({$age})" : "");
                }
            } catch (Exception) {
                $birth = $birthFormatted;
            }
        }
        if (empty($birth)) {
            $birth = $noData;
        }

        $email  = htmlspecialchars($user['etchat_email'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE);
        $emailk = mb_strimwidth($email, 0, 15, " ....");
        $ort    = !empty($user['etchat_ort']) ? htmlspecialchars($user['etchat_ort'], ENT_QUOTES | ENT_SUBSTITUTE) : $noData;
        $beschreibung = !empty($user['etchat_beschreibung']) ? nl2br(htmlspecialchars($user['etchat_beschreibung'], ENT_QUOTES | ENT_SUBSTITUTE)) : $noData;

        // ===== MODERNISIERT: Toggle Texte =====
        $moreText = $this->getText('team_toggle_more', 'mehr');
        $lessText = $this->getText('team_toggle_less', 'weniger');

        $maxLength = 40;
        if (mb_strlen(strip_tags($beschreibung)) > $maxLength) {
            $shortDesc = mb_substr(strip_tags($beschreibung), 0, $maxLength);
            $shortDesc = nl2br($shortDesc);
            $beschreibungHTML = "<div class='beschreibung-full' data-short='{$shortDesc}' data-full='{$beschreibung}'>{$shortDesc}... <a href='#' class='toggle-full'>{$moreText}</a></div>";
        } else {
            $beschreibungHTML = "<div class='beschreibung-full'>{$beschreibung}</div>";
        }

        // ===== MODERNISIERT: Labels =====
        $roleLabel = $this->getText('team_label_role', 'Rolle:');
        $genderLabel = $this->getText('profil_gender', 'Geschlecht:');
        $registeredLabel = $this->getText('team_label_registered', 'Registriert:');
        $birthdayLabel = $this->getText('profil_birthdate', 'Geburtsdatum:');
        $locationLabel = $this->getText('team_label_location', 'Ort:');
        $emailLabel = $this->getText('team_label_email', 'Email:');

        echo <<<HTML
<div class="compact-mod-card" data-role="{$role}">
    <div class="top-row">
        <div class="avatar-mod" style="border: 3px solid {$color};">
            <img src="avatar/{$avatar}" alt="{$username}" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        <div class="modinfo">
            <strong>{$username}</strong><br>
            {$roleLabel} {$roleName}<br>
            {$genderLabel} {$gender}<br>
            {$registeredLabel} {$regDate}<br>
            {$birthdayLabel} {$birth}<br>
            {$locationLabel} {$ort}<br>
            {$emailLabel} <a href="mailto:{$email}">{$emailk}</a><br>
        </div>
    </div>
    {$beschreibungHTML}
</div>
HTML;
    }

    private function renderJS(): void
    {
        $defaultRoleJS = htmlspecialchars($this->defaultRole);
        $moreText = $this->getText('team_toggle_more', 'mehr');
        $lessText = $this->getText('team_toggle_less', 'weniger');
        $headingMod = $this->getText('team_heading_mod', 'Unsere Moderatoren');
        $headingAdmin = $this->getText('team_heading_admin', 'Unsere Administratoren');
        $headingChatwache = $this->getText('team_heading_chatwache', 'Unsere Chatwachen');
        $headingGrafik = $this->getText('team_heading_grafik', 'Unsere Grafiker');

        echo <<<JS
<script>
// Toggle Beschreibung
document.addEventListener('click', function(e){
    if(e.target.classList.contains('toggle-full')){
        e.preventDefault();
        const container = e.target.parentNode;
        const isShort = container.innerHTML.includes('{$moreText}');
        if(isShort){
            container.innerHTML = container.dataset.full.replace(/\\n/g,'<br>') + ' <a href="#" class="toggle-full">{$lessText}</a>';
        } else {
            container.innerHTML = container.dataset.short + '... <a href="#" class="toggle-full">{$moreText}</a>';
        }
    }
});

// Rollen-Tabs
document.addEventListener("DOMContentLoaded", function() {
    const tabs = document.querySelectorAll(".role-tab");
    const cards = document.querySelectorAll(".compact-mod-card");
    const title = document.getElementById("role-title");

    function showRole(role) {
        cards.forEach(card => {
            if (
                card.dataset.role === role ||
                (role === "admin-group" && (card.dataset.role === "admin" || card.dataset.role === "co_admin"))
            ) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });

        const roleNames = {
            "mod": "{$headingMod}",
            "admin-group": "{$headingAdmin}",
            "chatwache": "{$headingChatwache}",
            "grafik": "{$headingGrafik}"
        };
        title.textContent = roleNames[role] ?? "Benutzer";
    }

    const defaultRole = '{$defaultRoleJS}';
    showRole(defaultRole);
    const defaultTab = document.querySelector('.role-tab[data-role="' + defaultRole + '"]');
    if (defaultTab) defaultTab.classList.add("active");

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            showRole(tab.dataset.role);
        });
    });
});
</script>
JS;
    }
}