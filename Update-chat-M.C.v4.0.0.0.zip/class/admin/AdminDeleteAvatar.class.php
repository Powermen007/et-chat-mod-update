<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteAvatar extends DbConectionMaker
{
    // Standard-Avatare, die nicht gelöscht werden dürfen
    private const PROTECTED_AVATARS = ['noavatar.jpg', 'mod_ohne_pic.png', 'autodj.jpg'];

    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rechte prüfen
        $allowedRoles = ["admin", "chatwache", "co_admin"];
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->get('admin_deleteavatar_error_access') ?? 'Zugriff verweigert';
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $csrfToken = $_SESSION[$csrfKey];

        // Request Parameter
        $id = (int)($_GET['id'] ?? 0);
        $requestToken = (string)($_GET['csrf_token'] ?? '');
        $delAvatar = isset($_GET['delavatar']);

        // Nur bei Lösch-Aktion CSRF prüfen
        if ($delAvatar && (!hash_equals($csrfToken, $requestToken))) {
            http_response_code(403);
            echo $lang->get('admin_deleteavatar_error_csrf') ?? "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            exit;
        }

        // Avatar löschen
        if ($delAvatar && $id > 0) {
            $this->deleteAvatar($id);
        }

        $this->dbObj->close();
    }

    /**
     * Löscht den Avatar eines Benutzers
     */
    private function deleteAvatar(int $userId): void
    {
        // Avatar aus DB holen (mit Prepared Statement)
        $avatarFile = $this->getAvatarFile($userId);
        
        if ($avatarFile !== '' && !$this->isProtectedAvatar($avatarFile)) {
            $this->deleteAvatarFile($avatarFile);
        }

        // DB auf Standard-Avatar zurücksetzen
        $this->resetAvatarToDefault($userId);

        // Zurück zur Benutzerliste
        header("Location: ./?AdminUserIndex");
        exit;
    }

    /**
     * Holt den Avatar-Dateinamen aus der Datenbank
     */
    private function getAvatarFile(int $userId): string
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_user_id = :id"
        );
        $stmt->execute([':id' => $userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['etchat_avatar'] ?? '';
    }

    /**
     * Prüft ob der Avatar geschützt ist (nicht gelöscht werden darf)
     */
    private function isProtectedAvatar(string $avatarFile): bool
    {
        return in_array($avatarFile, self::PROTECTED_AVATARS, true);
    }

    /**
     * Löscht die Avatar-Datei vom Server
     */
    private function deleteAvatarFile(string $avatarFile): void
    {
        $avatarRoot = realpath(__DIR__ . '/../../avatar/');
        
        if ($avatarRoot === false) {
            error_log("AdminDeleteAvatar: Avatar-Verzeichnis nicht gefunden");
            return;
        }

        $filePath = realpath($avatarRoot . '/' . $avatarFile);
        
        // Sicherheitscheck: Nur Dateien im Avatar-Ordner löschen
        if ($filePath !== false && str_starts_with($filePath, $avatarRoot) && is_file($filePath)) {
            if (!unlink($filePath)) {
                error_log("AdminDeleteAvatar: Konnte Datei nicht löschen: " . $filePath);
            }
        }
    }

    /**
     * Setzt den Avatar in der Datenbank auf den Standard zurück
     */
    private function resetAvatarToDefault(int $userId): void
    {
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_user 
             SET etchat_avatar = 'noavatar.jpg' 
             WHERE etchat_user_id = :id",
            [':id' => $userId]
        );
    }
}