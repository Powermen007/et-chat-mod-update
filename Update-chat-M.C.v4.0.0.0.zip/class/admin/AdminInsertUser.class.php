<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminInsertUser extends DbConectionMaker
{
    private array $allowedRoles = ["admin", "co_admin", "chatwache"];
    private string $message = '';
    private string $messageType = 'error'; // 'error' oder 'success'

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rolle prüfen
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        if (!in_array($role, $this->allowedRoles, true)) {
            $this->message = $lang->get('admin_insertuser_error_access') ?? 'Keine Berechtigung';
            $this->showResult($lang);
            return;
        }

        // CSRF Token prüfen (Token NICHT löschen!)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $csrfTokenSession = $_SESSION[$csrfKey] ?? '';
        $csrfTokenPost = $_POST['csrf_token'] ?? '';

        if (empty($csrfTokenPost) || !hash_equals($csrfTokenSession, $csrfTokenPost)) {
            $this->message = $lang->get('admin_insertuser_error_csrf') ?? "Ungültiger CSRF-Token.";
            $this->showResult($lang);
            return;
        }
        // KEIN unset($_SESSION[$csrfKey]) mehr!

        // Eingaben validieren
        $user  = trim($_POST['user'] ?? '');
        $priv  = trim($_POST['priv'] ?? '');
        $mail  = trim($_POST['mail'] ?? '');
        $pwRaw = trim($_POST['pw'] ?? '');

        // Benutzername validieren
        if (mb_strlen($user) < 3 || mb_strlen($user) > 50) {
            $this->message = $lang->get('admin_insertuser_error_username_length') ?? "Benutzername muss zwischen 3 und 50 Zeichen lang sein.";
            $this->showResult($lang);
            return;
        }

        // Benutzername auf erlaubte Zeichen prüfen
        if (!preg_match('/^[a-zA-Z0-9äöüßÄÖÜ\-_\.]+$/u', $user)) {
            $this->message = $lang->get('admin_insertuser_error_username_invalid') ?? "Benutzername enthält ungültige Zeichen. Erlaubt: Buchstaben, Zahlen, Punkte, Unterstriche, Bindestriche.";
            $this->showResult($lang);
            return;
        }

        // Rolle validieren
        $validPrivs = ["admin", "mod", "user", "grafik", "chatwache", "co_admin"];
        if (!in_array($priv, $validPrivs, true)) {
            $this->message = $lang->get('admin_insertuser_error_role_invalid') ?? "Ungültige Benutzerrolle.";
            $this->showResult($lang);
            return;
        }

        // E-Mail validieren (wenn angegeben)
        if ($mail !== '') {
            if (mb_strlen($mail) > 255) {
                $this->message = $lang->get('admin_insertuser_error_email_long') ?? "E-Mail-Adresse ist zu lang (max. 255 Zeichen).";
                $this->showResult($lang);
                return;
            }
            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                $this->message = $lang->get('admin_insertuser_error_email_invalid') ?? "Ungültige E-Mail-Adresse.";
                $this->showResult($lang);
                return;
            }
        }

        // Passwort prüfen (wenn angegeben)
        if ($pwRaw !== '' && mb_strlen($pwRaw) < 4) {
            $this->message = $lang->get('admin_insertuser_error_password_short') ?? "Passwort muss mindestens 4 Zeichen lang sein (oder leer lassen für kein Passwort).";
            $this->showResult($lang);
            return;
        }

        // Existenz prüfen
        if ($this->userExists($user)) {
            $this->message = $lang->get('admin_insertuser_error_username_exists') ?? "Benutzer mit diesem Namen existiert bereits.";
            $this->showResult($lang);
            return;
        }

        // Passwort hashen (oder null bei leerem Passwort)
        $pwHash = $pwRaw !== '' ? password_hash($pwRaw, PASSWORD_DEFAULT) : null;

        // In DB speichern
        try {
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_user
                (etchat_username, etchat_userpw, etchat_userprivilegien, etchat_reg_timestamp, etchat_email)
                VALUES (:user, :pw, :priv, :timestamp, :email)",
                [
                    ':user' => $user,
                    ':pw' => $pwHash,
                    ':priv' => $priv,
                    ':timestamp' => date("Y-m-d H:i:s"),
                    ':email' => $mail
                ]
            );

            $this->message = $lang->get('admin_insertuser_success') ?? "Benutzer '{$user}' wurde erfolgreich erstellt!";
            $this->messageType = 'success';
            
        } catch (PDOException $e) {
            error_log("AdminInsertUser Fehler: " . $e->getMessage());
            $this->message = $lang->get('admin_insertuser_error_database') ?? "Datenbankfehler beim Erstellen des Benutzers.";
        }

        $this->dbObj->close();
        $this->showResult($lang);
    }

    /**
     * Prüft ob ein Benutzer bereits existiert
     */
    private function userExists(string $username): bool
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_user_id FROM {$this->_prefix}etchat_user WHERE etchat_username = :username"
        );
        $stmt->execute([':username' => $username]);
        return $stmt->fetch() !== false;
    }

    private function showResult($lang): void
    {
        $message = $this->message;
        $messageType = $this->messageType;
        $backLink = './?AdminCreateNewUser';
        
        include_once "styles/admin_tpl/insertUserMessage.tpl.html";
    }
}