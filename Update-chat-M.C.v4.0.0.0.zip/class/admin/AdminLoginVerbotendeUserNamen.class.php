<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminLoginVerbotendeUserNamen extends DbConectionMaker
{
    private string $message = '';
    private string $csrfToken = '';
    private string $wordsFile;
    private array $defaultWords = ["@","adolf","arsch","fick","geil","göbbels","hitler","homo","hure","kack","moderator","nazi","scheiß","wixer","www","xxx"];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollen prüfen (nur admin)
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($userRole !== 'admin') {
            echo $lang->get('admin_bannednames_error_access') ?? "Zugriff verweigert.";
            return;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // JSON-Datei Pfad
        $this->wordsFile = __DIR__ . '/../../cache/verbotene_user_namen.json';

        // AJAX Request für GET (Wörter laden)
        if ($this->isAjaxRequest()) {
            $this->handleAjaxRequest();
            exit;
        }

        // POST Requests (AJAX)
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePostRequest($lang);
            exit;
        }

        // Wörter laden für die Anzeige
        $currentWords = $this->loadWordsForDisplay();

        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
        $chatUrl = $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
        $chatUrl = rtrim($chatUrl, '/\\') . '/';

        $this->renderTemplate($lang, $chatUrl, $currentWords);
    }

    private function isAjaxRequest(): bool
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';
    }

    private function handleAjaxRequest(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            header('Content-Type: application/json');
            $words = $this->loadWordsAsArray();
            echo json_encode(['words' => $words]);
            exit;
        }
    }

    private function handlePostRequest($lang): void
    {
        // CSRF prüfen (optional, da AJAX)
        $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
        if ($token && !hash_equals($this->csrfToken, $token)) {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_bannednames_error_csrf') ?? 'CSRF Token ungültig']);
            exit;
        }

        if (isset($_POST['add_single_word'])) {
            $this->addSingleWord($_POST['new_word'] ?? '', $lang);
        } elseif (isset($_POST['delete_single_word'])) {
            $this->deleteSingleWord($_POST['delete_word'] ?? '', $lang);
        }
    }

    private function loadWordsAsArray(): array
    {
        if (!file_exists($this->wordsFile)) {
            return $this->defaultWords;
        }

        $content = file_get_contents($this->wordsFile);
        if ($content === false) {
            return $this->defaultWords;
        }

        $words = json_decode($content, true);
        if (is_array($words) && !empty($words)) {
            return $words;
        }

        return $this->defaultWords;
    }

    private function loadWordsForDisplay(): string
    {
        $words = $this->loadWordsAsArray();
        return implode("\n", $words);
    }

    private function addSingleWord(string $newWord, $lang): void
    {
        $newWord = trim(strtolower($newWord));
        
        if ($newWord === '') {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_bannednames_error_empty') ?? 'Wort ist leer']);
            return;
        }

        if (strlen($newWord) < 2) {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_bannednames_error_too_short') ?? 'Wort muss mindestens 2 Zeichen haben']);
            return;
        }

        $currentWords = $this->loadWordsAsArray();

        if (!in_array($newWord, $currentWords, true)) {
            $currentWords[] = $newWord;
            sort($currentWords);
            $this->saveWords($currentWords);
            echo json_encode(['success' => true, 'words' => $currentWords]);
        } else {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_bannednames_error_exists') ?? 'Wort existiert bereits']);
        }
    }

    private function deleteSingleWord(string $deleteWord, $lang): void
    {
        $deleteWord = trim(strtolower($deleteWord));
        
        if ($deleteWord === '') {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_bannednames_error_no_word') ?? 'Kein Wort zum Löschen']);
            return;
        }

        $currentWords = $this->loadWordsAsArray();
        $key = array_search($deleteWord, $currentWords, true);

        if ($key !== false) {
            array_splice($currentWords, $key, 1);
            sort($currentWords);
            $this->saveWords($currentWords);
            echo json_encode(['success' => true, 'words' => $currentWords]);
        } else {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_bannednames_error_not_found') ?? 'Wort nicht gefunden']);
        }
    }

    private function saveWords(array $words): void
    {
        file_put_contents(
            $this->wordsFile, 
            json_encode($words, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    private function renderTemplate($lang, string $chatUrl, string $currentWords): void
    {
        $message = $this->message;
        $csrfToken = $this->csrfToken;
        
        include_once("styles/admin_tpl/indexLoginVerbotendeUserNamen.tpl.html");
    }
}
?>