<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateUser extends DbConectionMaker
{
    // Erlaubte Rollen
    private array $allowedRoles = ['admin', 'mod', 'user', 'grafik', 'chatwache', 'co_admin'];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Request vereinheitlichen
        $req = array_merge($_GET, $_POST);

        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        $userId = (int)($req['id'] ?? 0);
        $token = (string)($req['csrf_token'] ?? '');

        // CSRF prüfen
        if (!$this->isValidCsrfToken($token)) {
            $this->showError(($lang->get('admin_updateuser_error_csrf') ?? '❌ Fehler') . ' (CSRF)', "./?AdminUserIndex");
            exit;
        }

        // Zugriff prüfen
        if (!in_array($role, ["admin", "chatwache", "co_admin"], true) || $userId <= 0) {
            $this->showError($lang->get('admin_updateuser_error_access') ?? '❌ Zugriff verweigert', "./?AdminUserIndex");
            exit;
        }

        // Eingaben validieren
        $username = trim((string)($req['user'] ?? ''));
        $priv = trim((string)($req['priv'] ?? ''));
        $email = trim((string)($req['mail'] ?? ''));
        $password = trim((string)($req['pw'] ?? ''));

        // Pflichtfelder prüfen
        if ($username === '') {
            $this->showError($lang->get('admin_updateuser_error_username_empty') ?? "❌ Benutzername darf nicht leer sein", "./?AdminUserIndex");
            exit;
        }
        
        if ($priv === '') {
            $this->showError($lang->get('admin_updateuser_error_role_empty') ?? "❌ Rolle darf nicht leer sein", "./?AdminUserIndex");
            exit;
        }

        // Benutzername validieren (Zeichen)
        if (!preg_match('/^[a-zA-Z0-9äöüßÄÖÜ\-_\.]+$/u', $username)) {
            $this->showError($lang->get('admin_updateuser_error_username_invalid') ?? "❌ Benutzername enthält ungültige Zeichen", "./?AdminUserIndex");
            exit;
        }

        // Längenbegrenzung
        if (mb_strlen($username) > 50) {
            $username = mb_substr($username, 0, 50);
        }

        // Rolle validieren
        if (!in_array($priv, $this->allowedRoles, true)) {
            $this->showError($lang->get('admin_updateuser_error_role_invalid') ?? "❌ Ungültige Rolle", "./?AdminUserIndex");
            exit;
        }

        // E-Mail validieren (wenn angegeben)
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->showError($lang->get('admin_updateuser_error_email_invalid') ?? "❌ Ungültige E-Mail-Adresse", "./?AdminUserIndex");
            exit;
        }

        // Passwort validieren (wenn angegeben)
        if ($password !== '' && mb_strlen($password) < 4) {
            $this->showError($lang->get('admin_updateuser_error_password_short') ?? "❌ Passwort muss mindestens 4 Zeichen lang sein", "./?AdminUserIndex");
            exit;
        }

        // Letzter Admin darf nicht entrollt werden
        if ($priv !== "admin") {
            $stmt = $this->dbObj->getConnection()->prepare(
                "SELECT COUNT(etchat_user_id) as cnt
                 FROM {$this->_prefix}etchat_user
                 WHERE etchat_user_id != :id
                   AND etchat_userprivilegien = 'admin'"
            );
            $stmt->execute([':id' => $userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result && (int)$result['cnt'] === 0) {
                $this->showError($lang->get('admin_updateuser_error_last_admin') ?? "❌ Kann nicht durchgeführt werden. Es würde keinen Administrator mehr geben.", "./?AdminUserIndex");
                exit;
            }
        }

        // Prüfen ob Benutzername bereits existiert
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT COUNT(etchat_user_id) as cnt
             FROM {$this->_prefix}etchat_user
             WHERE etchat_username = :username
               AND etchat_userprivilegien != 'gast'
               AND etchat_user_id != :id"
        );
        $stmt->execute([':username' => $username, ':id' => $userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result && (int)$result['cnt'] > 0) {
            $this->showError($lang->get('admin_updateuser_error_username_exists') ?? "❌ Ein Benutzer mit diesem Namen existiert bereits", "./?AdminUserIndex");
            exit;
        }

        // Update vorbereiten
        try {
            $setParts = [
                "etchat_username = :username",
                "etchat_userprivilegien = :priv",
                "etchat_email = :email"
            ];

            $params = [
                ':username' => $username,
                ':priv' => $priv,
                ':email' => $email,
                ':id' => $userId
            ];

            if ($password !== '') {
                $setParts[] = "etchat_userpw = :pw";
                $params[':pw'] = password_hash($password, PASSWORD_DEFAULT);
            }

            $sql = "UPDATE {$this->_prefix}etchat_user 
                    SET " . implode(", ", $setParts) . " 
                    WHERE etchat_user_id = :id";

            $this->dbObj->sqlSet($sql, $params);
            $this->dbObj->close();

            // Erfolgsmeldung in Session speichern
            $_SESSION['user_update_success'] = true;

            header("Location: ./?AdminUserIndex");
            exit;

        } catch (PDOException $e) {
            error_log("AdminUpdateUser Fehler: " . $e->getMessage());
            $this->showError($lang->get('admin_updateuser_error_database') ?? '❌ Datenbankfehler', "./?AdminUserIndex");
            exit;
        }
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $sessionToken !== '' && hash_equals($sessionToken, $token);
    }

    private function showError(string $message, string $backLink): void
    {
        $msg = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        $back = htmlspecialchars($backLink, ENT_QUOTES, 'UTF-8');
        $backText = $lang->get('admin_updateuser_back') ?? '⬅️ Zurück';

        echo '<!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Adminbereich - Fehler</title>
            <link href="styles/admin_tpl/admin.css" rel="stylesheet">
        </head>
        <body id="adminbereich_body">
            <a href="./?AdminIndex">⬅️ zurück zum Adminmenü</a>
            <hr>
            <div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . $msg . '<br><br>
                <a href="' . $back . '" class="admin-button">' . $backText . '</a>
            </div>
        </body>
        </html>';
        exit;
    }
}