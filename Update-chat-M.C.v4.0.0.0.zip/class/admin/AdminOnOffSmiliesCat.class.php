<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminOnOffSmiliesCat extends DbConectionMaker
{
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        // Session starten, falls noch nicht aktiv
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollenprüfung
        $allowedRoles = ["admin", "co_admin", "grafik"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (aus Session)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$csrfKey] ?? '';

        // Request zusammenführen (POST + GET)
        $req = array_merge($_GET, $_POST);
        $requestToken = $req['csrf_token'] ?? '';

        // CSRF Token prüfen
        if ($requestToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            echo $lang->get('admin_onoffcat_error_csrf') ?? "Ungültiger Request (CSRF erkannt)";
            exit;
        }

        // ID validieren
        $id = (int)($req['id'] ?? 0);
        if ($id <= 0) {
            header("Location: ./?AdminSmiliesCatIndex");
            exit;
        }

        // Status validieren (nur 'on' oder 'off')
        $current = $req['on_on_off'] ?? 'off';
        $current = ($current === 'on') ? 'on' : 'off';

        // Update via Prepared Statement
        try {
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_smileys_cat 
                 SET aktiv = :status 
                 WHERE id = :id",
                [
                    ':status' => $current,
                    ':id' => $id
                ]
            );
        } catch (PDOException $e) {
            error_log("AdminOnOffSmiliesCat Fehler: " . $e->getMessage());
            header("Location: ./?AdminSmiliesCatIndex&error=1");
            exit;
        }

        $this->dbObj->close();

        // Weiterleitung zurück zur Kategorie-Übersicht
        header("Location: ./?AdminSmiliesCatIndex");
        exit;
    }
}