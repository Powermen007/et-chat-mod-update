<?php

declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminSmiliesIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private string $savedMsg = '';
    private array $smilies = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // CSRF Token
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // AJAX Request für Sortierung
        if (isset($_GET["SaveSmileyOrder"])) {
            $this->saveSmileyOrder($lang);
            exit;
        }

        // Rechte prüfen
        $allowedRoles = ["admin", "co_admin", "grafik"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // Erfolgsmeldung nach Speichern
        if (!empty($_GET['saved']) && $_GET['saved'] === '1') {
            $this->savedMsg = '<div class="success-banner" id="successBanner">
                <span>✅ ' . ($lang->get('admin_smilies_saved_success') ?? 'Reihenfolge gespeichert') . '</span>
                <span class="close-btn" onclick="closeSuccessBanner()">&times;</span>
            </div>';
        }

        // Kategorie-Filter
        $kategorie = $_GET['kat'] ?? '';
        $where = '';
        $params = [];

        if ($kategorie !== '') {
            $where = "WHERE etchat_smileys_kat = :kat";
            $params[':kat'] = $kategorie;
        }

        // Kategorien für Dropdown laden
        $alleKategorien = $this->loadCategories();

        // Pagination Einstellungen
        $site = max(1, (int)($_GET['site'] ?? 1));
        $proSeite = 30;
        $offset = ($site - 1) * $proSeite;

        // Gesamtanzahl Smileys
        $countTotal = $this->getSmileyCount($where, $params);

        // Smileys für aktuelle Seite laden
        $this->smilies = $this->loadSmilies($where, $params, $offset, $proSeite);

        // HTML-Komponenten bauen
        $paginationHtml = $this->buildPagination($countTotal, $proSeite, $site, $kategorie, $lang);
        $dropdownHtml = $this->buildDropdown($alleKategorien, $kategorie, $lang);
        $tableHtml = $this->buildSmileyTable($lang);
        $saveButtonHtml = $this->buildSaveButton($kategorie, $lang);

        // Template anzeigen
        $this->renderTemplate($lang, $paginationHtml, $tableHtml, $countTotal, $dropdownHtml, $saveButtonHtml);
    }

    /**
     * Lädt alle Kategorien für das Dropdown
     */
    private function loadCategories(): array
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT DISTINCT etchat_smileys_kat 
             FROM {$this->_prefix}etchat_smileys 
             ORDER BY etchat_smileys_kat ASC"
        );
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * Gibt die Gesamtanzahl der Smileys zurück
     */
    private function getSmileyCount(string $where, array $params): int
    {
        $countQuery = "SELECT COUNT(etchat_smileys_id) as cnt FROM {$this->_prefix}etchat_smileys $where";
        $result = $this->dbObj->sqlGet($countQuery, $params);
        return (int)($result[0]['cnt'] ?? $result[0][0] ?? 0);
    }

    /**
     * Lädt Smileys für die aktuelle Seite
     */
    private function loadSmilies(string $where, array $params, int $offset, int $limit): array
    {
        $sql = "SELECT etchat_smileys_id, etchat_smileys_kat, etchat_smileys_sign, 
                       etchat_smileys_img, etchat_smileys_gewicht
                FROM {$this->_prefix}etchat_smileys
                $where
                ORDER BY etchat_smileys_kat, etchat_smileys_gewicht, etchat_smileys_sign ASC
                LIMIT {$offset}, {$limit}";
        
        $result = $this->dbObj->sqlGet($sql, $params);
        return is_array($result) ? $result : [];
    }

    /**
     * Baut die Pagination HTML
     */
    private function buildPagination(int $total, int $perPage, int $currentPage, string $category, $lang): string
    {
        if ($total <= $perPage) {
            return '';
        }

        $sitemakerObj = new Sitemaker($perPage, $total);
        $sitemakerObj->href = true;

        $katQuery = ($category !== '') ? '&kat=' . urlencode($category) : '';
        
        $sitemakerObj->make(
            $currentPage,
            "./?AdminSmiliesIndex&site=#site#" . $katQuery,
            $lang->get('admin_smilies_site') ?? 'Seite',
            $lang->get('admin_smilies_site_of') ?? 'von'
        );

        return $sitemakerObj->get();
    }

    /**
     * Baut das Kategorie-Dropdown HTML
     */
    private function buildDropdown(array $categories, string $selectedCategory, $lang): string
    {
        $html = '<form method="get" action="" style="display:inline;">';
        $html .= '<input type="hidden" name="AdminSmiliesIndex" value="1">';
        $html .= '<select name="kat" onchange="this.form.submit()">';
        $html .= '<option value="">' . ($lang->get('admin_smilies_all_categories') ?? 'Alle Kategorien') . '</option>';
        
        foreach ($categories as $catRow) {
            $catVal = $catRow['etchat_smileys_kat'] ?? $catRow[0] ?? '';
            $selected = ($selectedCategory === $catVal) ? ' selected' : '';
            $html .= '<option value="' . htmlspecialchars($catVal, ENT_QUOTES, 'UTF-8') . '"' . $selected . '>';
            $html .= htmlspecialchars($catVal, ENT_QUOTES, 'UTF-8');
            $html .= '</option>';
        }
        
        $html .= '</select>';
        $html .= '</form>';
        
        return $html;
    }

    /**
     * Baut die Smiley-Tabelle HTML
     */
    private function buildSmileyTable($lang): string
    {
        if (empty($this->smilies)) {
            return '<tr><td colspan="7">' . ($lang->get('admin_smilies_no_data') ?? 'Keine Smileys gefunden.') . '</td></tr>';
        }

        $html = '';
        $i = 0;

        foreach ($this->smilies as $smiley) {
            $i++;
            
            $id = (int)($smiley['etchat_smileys_id'] ?? $smiley[0] ?? 0);
            $kat = $smiley['etchat_smileys_kat'] ?? $smiley[1] ?? '';
            $text = $smiley['etchat_smileys_sign'] ?? $smiley[2] ?? '';
            $pic = $smiley['etchat_smileys_img'] ?? $smiley[3] ?? '';
            $gew = (int)($smiley['etchat_smileys_gewicht'] ?? $smiley[4] ?? 0);
            
            $bgcolor = ($i % 2 === 0) ? 'class="ungerade"' : 'class="gerade"';
            
            $html .= '<tr ' . $bgcolor . ' draggable="true" data-id="' . $id . '" data-kat="' . htmlspecialchars($kat, ENT_QUOTES, 'UTF-8') . '">';
            $html .= '<td><img class="img_verschieben" src="./img/verschieben.png" alt="verschieben"></td>';
            $html .= '<td><img class="img_smiley" src="./' . htmlspecialchars($pic, ENT_QUOTES, 'UTF-8') . '" alt="smiley"></td>';
            $html .= '<td>' . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . '</td>';
            $html .= '<td>' . htmlspecialchars($kat, ENT_QUOTES, 'UTF-8') . '</td>';
            $html .= '<td><a href="./?AdminRenameSmilies&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '">' . ($lang->get('admin_smilies_edit') ?? '✏️ Editieren') . '</a></td>';
            $html .= '<td><a href="./?AdminDeleteSmilies&id=' . $id . '&pic=' . urlencode($pic) . '&csrf_token=' . urlencode($this->csrfToken) . '" onclick="return confirm(\'' . ($lang->get('admin_smilies_confirm_delete') ?? 'Wirklich löschen?') . '\')">' . ($lang->get('admin_smilies_delete') ?? '🗑️ Löschen') . '</a></td>';
            $html .= '<td>' . $gew . '</td>';
            $html .= '</tr>';
        }
        
        return $html;
    }

    /**
     * Baut den Save-Button (abhängig ob Kategorie gewählt)
     */
    private function buildSaveButton(string $category, $lang): string
    {
        $btnText = $lang->get('admin_smilies_save_order') ?? '💾 Neue Reihenfolge speichern';
        $disabledText = $lang->get('admin_smilies_only_with_category') ?? 'Nur mit Kategorie';
        
        if ($category !== '') {
            return '<button id="saveSmileyBtn" type="button" onclick="saveOrder()" class="admin-button">' . $btnText . '</button>';
        }
    
        return '<button id="saveSmileyBtn" type="button" class="admin-button" disabled title="' . $disabledText . '">' . $btnText . '</button>';
    }

    /**
     * AJAX: Speichert die Smiley-Reihenfolge
     */
    private function saveSmileyOrder($lang): void
    {
        // Rollen prüfen
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            http_response_code(403);
            exit($lang->get('admin_smilies_error_no_rights') ?? "Keine Rechte");
        }

        // CSRF aus Header holen
        $token = $this->getBearerToken();
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

        if (!hash_equals($sessionToken, $token)) {
            http_response_code(403);
            exit($lang->get('admin_smilies_error_csrf') ?? "CSRF Fehler");
        }

        // JSON-Daten parsen
        $data = json_decode(file_get_contents("php://input"), true);
        
        $kat = (string)($data['kat'] ?? '');
        $site = max(1, (int)($data['site'] ?? 1));
        $ids = $data['ids'] ?? [];

        if ($kat === '' || empty($ids)) {
            http_response_code(400);
            exit($lang->get('admin_smilies_error_no_data') ?? "Fehler: Keine Daten");
        }

        $proSeite = 30;
        $offset = ($site - 1) * $proSeite;
        $gewicht = ($offset * 5) + 5;

        try {
            foreach ($ids as $id) {
                $this->dbObj->sqlSet(
                    "UPDATE {$this->_prefix}etchat_smileys
                     SET etchat_smileys_gewicht = :gewicht
                     WHERE etchat_smileys_id = :id
                     AND etchat_smileys_kat = :kat",
                    [
                        ':gewicht' => $gewicht,
                        ':id' => (int)$id,
                        ':kat' => $kat
                    ]
                );
                $gewicht += 5;
            }
            
            echo $lang->get('admin_smilies_saved') ?? "Gespeichert";
            
        } catch (PDOException $e) {
            error_log("saveSmileyOrder Fehler: " . $e->getMessage());
            http_response_code(500);
            echo $lang->get('admin_smilies_error_database') ?? "Datenbankfehler";
        }
    }

    /**
     * Holt CSRF-Token aus verschiedenen Header-Quellen
     */
    private function getBearerToken(): string
    {
        // Apache
        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (isset($headers['X-CSRF-Token'])) {
                return $headers['X-CSRF-Token'];
            }
            if (isset($headers['X-CSRF-TOKEN'])) {
                return $headers['X-CSRF-TOKEN'];
            }
        }
        
        // Nginx / FastCGI
        if (isset($_SERVER['HTTP_X_CSRF_TOKEN'])) {
            return $_SERVER['HTTP_X_CSRF_TOKEN'];
        }
        if (isset($_SERVER['HTTP_X_CSRF_TOKEn'])) {
            return $_SERVER['HTTP_X_CSRF_TOKEn'];
        }
        
        return '';
    }

    /**
     * RENDERT DAS TEMPLATE mit den richtigen Variablen-Namen!
     */
    private function renderTemplate($lang, string $paginationHtml, string $tableHtml, int $countTotal, string $dropdownHtml, string $saveButtonHtml): void
    {
        // ACHTUNG: Das Template erwartet GENAU DIESE Variablen-Namen!
        $list2 = $paginationHtml;      // Pagination
        $list = $tableHtml;            // Tabellen-Inhalt
        $list3 = " " . $countTotal . " " . ($lang->get('admin_smilies_count') ?? 'Smileys gefunden') . "<br>";
        $list4 = $dropdownHtml;        // Kategorie-Dropdown
        $list5 = $saveButtonHtml;      // Save-Button
        $savedMsg = $this->savedMsg;   // Erfolgsmeldung
        
        include "styles/admin_tpl/indexSmilies.tpl.html";
        
        $this->dbObj->close();
    }
}