<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminCreateNewSmiliesCat extends DbConectionMaker
{
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        // SESSION & HEADER
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Rollen prüfen
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $allowedRoles = ["admin", "grafik", "co_admin"];
        
        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->get('admin_createsmiliescat_error_access') ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // Template anzeigen
        $this->showTemplate($lang);
    }

    private function showTemplate($lang): void
    {
        // Smilies-Kategorien laden (mit Prepared Statement)
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT name FROM {$this->_prefix}etchat_smileys_cat ORDER BY name ASC"
        );
        $stmt->execute();
        $cats = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        // HTML-Sicherheit für die Anzeige
        foreach ($cats as &$cat) {
            $cat['name'] = htmlspecialchars($cat['name'] ?? '', ENT_QUOTES, 'UTF-8');
        }
        unset($cat);

        $csrfToken = $this->csrfToken;

        // Template einbinden
        include __DIR__ . "/../../styles/admin_tpl/createNewSmiliesCat.tpl.html";

        $this->dbObj->close();
    }
}