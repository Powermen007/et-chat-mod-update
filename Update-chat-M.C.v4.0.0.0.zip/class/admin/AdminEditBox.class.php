<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditBox extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $boxData = [];

    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden - Admin XML
		$lang = new LangXml("./lang/", "lang_admin_de.xml");

		// Rechte prüfen (nur admin)
		$role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
		if (!in_array($role, ['admin'], true)) {
			echo $lang->get('admin_access_denied', 'Zugriff verweigert');
			return;
		}

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // GET + POST kompatibel
        $data = $_GET + $_POST;

        // ID absichern
        $id = (int)($data['id'] ?? 0);
        if ($id <= 0) {
            echo "Ungültige ID.";
            return;
        }

        // Box-Daten laden
        $this->loadBoxData($id);

        if (empty($this->boxData)) {
            echo "Eintrag nicht gefunden.";
            return;
        }

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    /**
     * Lädt die Box-Daten aus der Datenbank
     */
    private function loadBoxData(int $id): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id, ort, header_text, content
             FROM {$this->_prefix}etchat_start_boxes
             WHERE id = :id"
        );
        $stmt->execute([':id' => $id]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->boxData = is_array($result) ? $result : [];
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate(?object $lang): void
    {
		
		
		
        // Template-Variablen (für Kompatibilität mit editBox.tpl.html)
        $feld = [$this->boxData]; // Template erwartet ein numerisches Array von Arrays
        $csrfToken = $this->csrfToken;
        
        include __DIR__ . "/../../styles/admin_tpl/editBox.tpl.html";
    }
}