<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminLoginBox extends DbConectionMaker
{
    private string $message = '';
    private string $csrfToken = '';
    private string $domainFile;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollen prüfen (nur admin)
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($userRole !== 'admin') {
            echo $lang->get('admin_loginbox_error_access') ?? 'Zugriff verweigert.';
            return;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Domain-Datei Pfad
        $this->domainFile = __DIR__ . '/../../cache/loginbox.txt';

        // POST verarbeiten
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_domains'])) {
            $this->handlePost($lang);
        }

        // Aktuelle Domains laden
        $currentDomains = $this->loadDomains();

        // Chat-URL ermitteln
        $chatUrl = $this->getChatUrl();

        // Template anzeigen
        $this->renderTemplate($lang, $chatUrl, $currentDomains);
    }

    private function handlePost($lang): void
    {
        // CSRF prüfen
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            $this->message = '<div class="error" style="color:red;">' . ($lang->get('admin_loginbox_error_csrf') ?? 'Ungültiger CSRF Token!') . '</div>';
            return;
        }

        $domainsRaw = $_POST['allowed_domains_list'] ?? '';
        
        $lines = explode("\n", $domainsRaw);
        $cleanList = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;

            // Entferne http://, https://, www.
            $line = preg_replace('~^https?://~i', '', $line);
            $line = preg_replace('~^www\.~i', '', $line);
            
            // Entferne alles nach dem ersten Slash
            $line = explode('/', $line)[0];
            $line = strtolower(trim($line));

            if ($line !== '') {
                $cleanList[] = $line;
            }
        }

        $cleanList = array_unique($cleanList);
        
        $success = file_put_contents($this->domainFile, implode("\n", $cleanList), LOCK_EX);
        
        if ($success !== false) {
            $this->message = '<div class="success-banner">    
                                <span>✅ ' . ($lang->get('admin_loginbox_saved_success') ?? 'Gespeichert erfolgreich!') . '</span>
                                <span class="close-btn" onclick="closeSuccessBanner()">✖</span>
                              </div>';
        } else {
            $this->message = '<div class="error" style="color:red;">❌ ' . ($lang->get('admin_loginbox_error_save') ?? 'Fehler beim Speichern!') . '</div>';
        }
    }

    private function loadDomains(): string
    {
        if (!file_exists($this->domainFile)) {
            return '';
        }

        $content = file($this->domainFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($content === false) {
            return '';
        }

        return implode("\n", $content);
    }

    private function getChatUrl(): string
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
        $url = $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
        return rtrim($url, '/\\') . '/';
    }

    private function renderTemplate($lang, string $chatUrl, string $currentDomains): void
    {
        $message = $this->message;
        $csrfToken = $this->csrfToken;
        
        // Template-Variablen (das Template erwartet snake_case!)
        $current_domains = $currentDomains;
        $chat_url = $chatUrl;
        
        include_once("styles/admin_tpl/indexLoginBox.tpl.html");
    }
}