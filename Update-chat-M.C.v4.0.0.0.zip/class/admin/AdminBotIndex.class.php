<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminBotIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private string $jsonFile;
    private object $lang;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Cache-Datei Pfad
        $this->jsonFile = dirname(__DIR__, 2) . "/cache/bot_answers.json";

        // NEU: Sprache laden - Admin XML
        $this->lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollen prüfen
        $userPriv = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $allowedRoles = ["admin", "co_admin"];
        
        if (!in_array($userPriv, $allowedRoles, true)) {
            echo $this->lang->get('admin_access_denied', 'Zugriff verweigert');
            return;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

        // Aktionen verarbeiten
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost($_POST);
        } else {
            $this->showPage();
        }
    }

    private function handlePost(array $post): void
    {
        // CSRF Check
        $token = $post['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            die($this->lang->get('admin_bot_error_csrf', 'Ungültiger CSRF Token'));
        }

        // Neue Antwort hinzufügen
        if (isset($post["new_answer"])) {
            $this->addAnswer($post["new_answer"]);
        }

        // Bot Toggle (ein/aus)
        if (isset($post['toggle_bot'])) {
            $this->toggleBot((bool)($post['etchat_bot'] ?? false));
        }
    }

    private function showPage(): void
    {
        // Bot-Antworten laden
        $botAnswers = $this->loadBotAnswers();

        // DELETE (GET) – bleibt wie gewohnt, aber mit CSRF im Link (wird im Template eingefügt)
        if (isset($_GET["delete"])) {
            $this->deleteAnswer((int)$_GET["delete"]);
        }

        $botEnabled = (int)($_SESSION['etchat_' . $this->_prefix . 'etchat_bot'] ?? 0);
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;  // 🔥 WICHTIG: $lang an Template übergeben!

        include "styles/admin_tpl/indexBot.tpl.html";
    }

    /**
     * Lädt die Bot-Antworten aus der JSON-Datei
     */
    private function loadBotAnswers(): array
    {
        // Stelle sicher, dass die Datei existiert
        if (!file_exists($this->jsonFile)) {
            $this->saveBotAnswers([]);
            return [];
        }

        $content = file_get_contents($this->jsonFile);
        if ($content === false) {
            return [];
        }

        $decoded = json_decode($content, true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Speichert Bot-Antworten in die JSON-Datei
     */
    private function saveBotAnswers(array $answers): bool
    {
        $json = json_encode($answers, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        return file_put_contents($this->jsonFile, $json, LOCK_EX) !== false;
    }

    /**
     * Fügt eine neue Bot-Antwort hinzu
     */
    private function addAnswer(string $text): void
    {
        $new = trim($text);
        
        // Leere Einträge ignorieren
        if ($new === '') {
            header("Location: ?AdminBotIndex");
            exit;
        }
        
        // Auf 500 Zeichen begrenzen
        $new = mb_substr($new, 0, 500);
        
        $botAnswers = $this->loadBotAnswers();
        
        // Prüfen ob Antwort bereits existiert (optional)
        if (in_array($new, $botAnswers, true)) {
            header("Location: ?AdminBotIndex&exists=1");
            exit;
        }
        
        $botAnswers[] = $new;
        $this->saveBotAnswers($botAnswers);

        header("Location: ?AdminBotIndex&saved=1");
        exit;
    }

    /**
     * Schaltet den Bot ein oder aus
     */
    private function toggleBot(bool $enabled): void
    {
        $status = $enabled ? 1 : 0;

        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_config 
             SET etchat_bot = :status 
             WHERE etchat_config_id = 1",
            [':status' => $status]
        );

        $_SESSION['etchat_' . $this->_prefix . 'etchat_bot'] = $status;

        header("Location: ?AdminBotIndex&toggled=1");
        exit;
    }

    /**
     * Löscht eine Bot-Antwort anhand des Index
     */
    private function deleteAnswer(int $index): void
    {
        $botAnswers = $this->loadBotAnswers();
        
        if (isset($botAnswers[$index])) {
            unset($botAnswers[$index]);
            // Array neu indizieren
            $botAnswers = array_values($botAnswers);
            $this->saveBotAnswers($botAnswers);
        }

        header("Location: ?AdminBotIndex&deleted=1");
        exit;
    }
}