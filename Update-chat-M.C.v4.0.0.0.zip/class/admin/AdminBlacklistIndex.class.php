<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminBlacklistIndex extends DbConectionMaker
{
    private string $message = '';
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // -------------------------
        // Rollen prüfen
        // -------------------------
        $userPriv = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $allowedRoles = ["admin", "grafik", "chatwache", "co_admin"];
        
        if (!in_array($userPriv, $allowedRoles, true)) {
            echo $lang->get('admin_blacklist_error_access') ?? 'Zugriff verweigert';
            return;
        }

        // -------------------------
        // CSRF Token erzeugen (PHP 8+ mit ??=)
        // -------------------------
        $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

        // -------------------------
        // Formularverarbeitung mit CSRF-Prüfung
        // -------------------------
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_blacklist_submit'])) {
            $this->handleForm($lang);
        }

        // -------------------------
        // Alte Blacklist-Einträge löschen
        // -------------------------
        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_blacklist 
             WHERE etchat_blacklist_time < :time",
            [':time' => time()]
        );

        // -------------------------
        // Blacklist laden
        // -------------------------
        $feld = $this->dbObj->sqlGet("
            SELECT
                b.etchat_blacklist_ip,
                b.etchat_blacklist_id,
                IFNULL(u.etchat_username, 'Gelöschter Benutzer') AS etchat_username,
                IFNULL(u.etchat_userprivilegien, '-') AS etchat_userprivilegien,
                b.etchat_blacklist_time
            FROM
                {$this->_prefix}etchat_blacklist b
            LEFT JOIN
                {$this->_prefix}etchat_user u
            ON
                b.etchat_blacklist_userid = u.etchat_user_id
        ");
        
        // ⚠️ Sicherstellen, dass immer ein Array übergeben wird
        $feld = is_array($feld) ? $feld : [];

        $this->dbObj->close();

        $this->initTemplate($lang, $feld);
    }

    private function handleForm($lang): void
    {
        // 🔒 CSRF-Prüfung
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            $this->message = "<p style='color: red;'>" . ($lang->get('admin_blacklist_error_csrf') ?? 'Ungültiger CSRF-Token!') . "</p>";
            return;
        }

        $ip = trim($_POST['ip'] ?? '');
        $userID = (int)($_POST['user_id'] ?? 0);
        $duration = max(0, (int)($_POST['duration'] ?? 0));

        // IP/Wildcard-Validierung (IPv4, IPv6, Bereiche)
        if ($ip === '' || !$this->validateIpWildcard($ip)) {
            $this->message = "<p style='color: red;'>" . ($lang->get('admin_blacklist_error_invalid_ip') ?? 'Bitte eine gültige IP-Adresse oder einen gültigen IP-Bereich angeben.') . "<br>
                              " . ($lang->get('admin_blacklist_examples') ?? 'Beispiele: 192.168.1.100, 192.168.1., 192.168., 192., 2001:db8::1, 2001:db8::') . "</p>";
            return;
        }

        if ($userID <= 0) {
            $this->message = "<p style='color: red;'>" . ($lang->get('admin_blacklist_error_invalid_user') ?? 'Bitte eine gültige User-ID angeben.') . "</p>";
            return;
        }

        $time_to_hold = $duration > 0 ? time() + $duration : 0;

        if ($duration > 0) {
            // Prüfen ob IP bereits in der Blacklist ist
            $existing = $this->dbObj->sqlGet(
                "SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_blacklist 
                 WHERE etchat_blacklist_ip = :ip AND etchat_blacklist_userid = :userid",
                [':ip' => $ip, ':userid' => $userID]
            );
            
            if (($existing[0]['cnt'] ?? 0) > 0) {
                $this->message = "<p style='color: orange;'>" . ($lang->get('admin_blacklist_error_exists') ?? 'Dieser Eintrag existiert bereits in der Blacklist.') . "</p>";
                return;
            }
            
            // Benutzer sperren
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_blacklist
                 (etchat_blacklist_ip, etchat_blacklist_userid, etchat_blacklist_time)
                 VALUES (:ip, :userid, :time)",
                [
                    ':ip' => $ip,
                    ':userid' => $userID,
                    ':time' => $time_to_hold
                ]
            );
            $this->message = "<p style='color: green;'>" . ($lang->get('admin_blacklist_ban_success') ?? 'Benutzer wurde erfolgreich gebannt') . " (IP: " . htmlspecialchars($ip) . ").</p>";
        } else {
            // Benutzer nur kicken
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_useronline 
                 WHERE etchat_onlineuser_fid = :userid",
                [':userid' => $userID]
            );
            $this->message = "<p style='color: orange;'>" . ($lang->get('admin_blacklist_kick_success') ?? 'Benutzer wurde gekickt.') . "</p>";
        }
    }

    /**
     * Validiert IP-Adressen mit Wildcards (IPv4 und IPv6)
     * 
     * Beispiele für IPv4:
     * - 192.168.1.100 (vollständige IP)
     * - 192.168.1.   (Bereich 192.168.1.*)
     * - 192.168.     (Bereich 192.168.*.*)
     * - 192.         (Bereich 192.*.*.*)
     * - 192.168.1.*  (auch mit Sternchen)
     * 
     * Beispiele für IPv6:
     * - 2001:db8::1 (vollständige IPv6)
     * - 2001:db8::  (Bereich 2001:db8::*)
     * - 2001:       (Bereich 2001:*:*:*:*:*:*:*)
     */
    private function validateIpWildcard(string $ip): bool
    {
        $ip = trim($ip);
        if ($ip === '') {
            return false;
        }
        
        // IPv4 mit Wildcards prüfen
        if ($this->isValidIPv4Wildcard($ip)) {
            return true;
        }
        
        // IPv6 mit Wildcards prüfen
        if ($this->isValidIPv6Wildcard($ip)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Prüft IPv4 mit Wildcards
     * Erlaubt: 192.168.1.100, 192.168.1., 192.168., 192., 192.168.1.*
     */
    private function isValidIPv4Wildcard(string $ip): bool
    {
        // Sternchen durch leeren String ersetzen für einheitliche Prüfung
        $ip = str_replace('*', '', $ip);
        
        // Darf nur Zahlen, Punkte und Doppelpunkt (für Bereich) enthalten
        if (!preg_match('/^[\d\.]+$/', $ip)) {
            return false;
        }
        
        // Punkte zählen
        $parts = explode('.', $ip);
        $partCount = count($parts);
        
        // Maximal 4 Teile (wie bei IPv4)
        if ($partCount > 4) {
            return false;
        }
        
        // Letzter Teil kann leer sein (für Bereiche wie 192.168.1.)
        // oder eine Zahl zwischen 0-255
        for ($i = 0; $i < $partCount; $i++) {
            $part = $parts[$i];
            
            // Letzter Teil darf leer sein (Bereich)
            if ($i === $partCount - 1 && $part === '') {
                continue;
            }
            
            // Leere Teile in der Mitte sind nicht erlaubt
            if ($part === '') {
                return false;
            }
            
            // Prüfen ob es eine Zahl ist
            if (!ctype_digit($part)) {
                return false;
            }
            
            // Zahl muss zwischen 0 und 255 liegen
            $num = (int)$part;
            if ($num < 0 || $num > 255) {
                return false;
            }
            
            // Keine führenden Nullen (außer die Zahl ist genau 0)
            if (strlen($part) > 1 && $part[0] === '0') {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Prüft IPv6 mit Wildcards
     * Erlaubt: 2001:db8::1, 2001:db8::, 2001:, 2001:db8:
     */
    private function isValidIPv6Wildcard(string $ip): bool
    {
        // Sternchen entfernen
        $ip = str_replace('*', '', $ip);
        
        // Leerer String? Ungültig
        if ($ip === '') {
            return false;
        }
        
        // Prüfung für Bereich (endet mit :)
        $isRange = substr($ip, -1) === ':';
        
        // Doppelpunkt am Ende entfernen für die Prüfung
        $ipToCheck = $isRange ? substr($ip, 0, -1) : $ip;
        
        // : enthält? Dann ist es IPv6
        if (!str_contains($ipToCheck, ':')) {
            return false;
        }
        
        // Versuche es als gültige IPv6 zu parsen (für vollständige IPs)
        if (!$isRange && filter_var($ipToCheck, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false) {
            return true;
        }
        
        // Für Bereiche: Prüfen ob es ein gültiges IPv6-Präfix ist
        // Erlaubt: 2001:, 2001:db8:, 2001:db8:: (mit oder ohne Doppelpunkt am Ende)
        $pattern = '/^([0-9a-fA-F]{1,4}:)+$/';
        if (preg_match($pattern, $ipToCheck . ':')) {
            return true;
        }
        
        // Erlaubt auch :: am Ende (z.B. 2001:db8::)
        if (preg_match('/^([0-9a-fA-F]{1,4}:)+::$/', $ipToCheck)) {
            return true;
        }
        
        return false;
    }

    private function initTemplate($lang, array $feld): void
    {
        $message = $this->message;
        $csrfToken = $this->csrfToken;
        include_once("styles/admin_tpl/indexBlacklist.tpl.html");
    }

    public function getMessage(): string
    {
        return $this->message;
    }
}