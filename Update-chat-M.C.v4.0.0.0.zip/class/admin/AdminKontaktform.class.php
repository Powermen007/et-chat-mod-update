<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminKontaktform extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $felder = [];
    private object $lang;

    private const ALLOWED_TYPES = ['text', 'textarea', 'email', 'date', 'select', 'checkbox'];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // NEU: Sprache laden - Admin XML
        $this->lang = new LangXml("./lang/", "lang_admin_de.xml");

        if (!isset($this->dbObj)) {
            die($this->lang->get('admin_kontaktform_error_db', 'Datenbankverbindung nicht vorhanden!'));
        }

        // Rollencheck (nur admin)
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($userRole !== 'admin') {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        $req = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET;

        if (isset($req['delete'])) {
            $this->deleteField((int)$req['delete'], $req['csrf_token'] ?? '');
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->saveChanges($req);
        } else {
            $this->showForm(isset($req['saved']));
        }
    }

    private function showForm(bool $saved): void
    {
        $this->loadFields();
        $felder = $this->felder;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;  // 🔥 WICHTIG: $lang an Template übergeben!
        
        include "styles/admin_tpl/editKontaktform.tpl.html";
    }

    private function loadFields(): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT * FROM {$this->_prefix}etchat_kontakt_fields ORDER BY etchat_sort_order ASC"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->felder = is_array($result) ? $result : [];
    }

    private function saveChanges(array $post): void
    {
        $requestToken = $post['csrf_token'] ?? '';
        if (!$requestToken || !hash_equals($this->csrfToken, $requestToken)) {
            http_response_code(403);
            die($this->lang->get('admin_kontaktform_error_csrf', 'Ungültiger Request (CSRF erkannt)'));
        }

        $order = isset($post['order']) ? explode(',', $post['order']) : [];

        // Bestehende Felder aktualisieren
        foreach ($post['label'] ?? [] as $id => $label) {
            $id = (int)$id;
            $label = trim((string)$label);
            
            if ($label === '') continue;

            $sichtbar = isset($post['sichtbar'][$id]) ? 1 : 0;
            $pflicht  = isset($post['pflicht'][$id]) ? 1 : 0;

            $optionen = null;
            if (isset($post['optionen'][$id])) {
                $lines = array_filter(array_map('trim', explode("\n", $post['optionen'][$id])));
                if (!empty($lines)) {
                    $optionen = json_encode(array_values($lines), JSON_UNESCAPED_UNICODE);
                }
            }

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_kontakt_fields
                 SET etchat_field_name = :label, 
                     etchat_visible = :visible, 
                     etchat_required = :required, 
                     etchat_options = :options
                 WHERE etchat_id = :id",
                [
                    ':label' => $label,
                    ':visible' => $sichtbar,
                    ':required' => $pflicht,
                    ':options' => $optionen,
                    ':id' => $id
                ]
            );
        }

        // Sortierung aktualisieren
        foreach ($order as $sort => $id) {
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_kontakt_fields
                 SET etchat_sort_order = :sort 
                 WHERE etchat_id = :id",
                [
                    ':sort' => (int)$sort,
                    ':id' => (int)$id
                ]
            );
        }

        // Neues Feld hinzufügen
        $this->addNewField($post);

        header("Location: ./?AdminKontaktform&saved=1");
        exit;
    }

    private function addNewField(array $post): void
    {
        if (empty($post['new_label'])) {
            return;
        }

        $label = trim((string)$post['new_label']);
        // Erlaubte Zeichen für Label
        $label = preg_replace('/[^a-zA-Z0-9 äöüÄÖÜß_\-]/u', '', $label);
        
        if ($label === '') {
            return;
        }

        $type = $post['new_type'] ?? 'text';
        $type = in_array($type, self::ALLOWED_TYPES, true) ? $type : 'text';

        $sichtbar = isset($post['new_visible']) ? 1 : 0;
        $pflicht  = isset($post['new_required']) ? 1 : 0;

        $optionen = null;
        if (!empty($post['new_options'])) {
            $lines = array_filter(array_map('trim', explode("\n", $post['new_options'])));
            if (!empty($lines)) {
                $optionen = json_encode(array_values($lines), JSON_UNESCAPED_UNICODE);
            }
        }

        // Höchste Sortierung ermitteln
        $maxSort = $this->dbObj->sqlGet(
            "SELECT MAX(etchat_sort_order) AS max_sort FROM {$this->_prefix}etchat_kontakt_fields"
        );
        $sort = ((int)($maxSort[0]['max_sort'] ?? $maxSort[0][0] ?? 0)) + 1;

        $this->dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_kontakt_fields
             (etchat_field_name, etchat_field_type, etchat_visible, etchat_required, 
              etchat_options, etchat_sort_order, etchat_custom)
             VALUES (:label, :type, :visible, :required, :options, :sort, 1)",
            [
                ':label' => $label,
                ':type' => $type,
                ':visible' => $sichtbar,
                ':required' => $pflicht,
                ':options' => $optionen,
                ':sort' => $sort
            ]
        );
    }

    private function deleteField(int $id, string $requestToken): void
    {
        if (!$requestToken || !hash_equals($this->csrfToken, $requestToken)) {
            http_response_code(403);
            die($this->lang->get('admin_kontaktform_error_csrf', 'Ungültiger Request (CSRF erkannt)'));
        }

        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_kontakt_fields 
             WHERE etchat_id = :id AND etchat_custom = 1",
            [':id' => $id]
        );

        header("Location: ./?AdminKontaktform&saved=1");
        exit;
    }
}