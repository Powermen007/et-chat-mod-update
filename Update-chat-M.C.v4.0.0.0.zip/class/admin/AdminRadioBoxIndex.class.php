<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRadioBoxIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $radioList = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollenprüfung
        $allowedRoles = ["admin", "co_admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Radio-Daten laden
        $this->loadRadioList();

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang, $userRole);
    }

    /**
     * Lädt die Radio-Box Daten aus der Datenbank
     */
    private function loadRadioList(): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT 
                etchat_radio_id,
                etchat_radio_horst,
                etchat_radio_port,
                etchat_radio_typ,
                etchat_radio_stream,
                etchat_radio_name,
                etchat_radio_color,
                etchat_radio_bit,
                etchat_radio_box,
                etchat_radio_player,
                etchat_on_air,
                etchat_system_titel_an,
                etchat_titel_an
             FROM {$this->_prefix}etchat_radio_box
             ORDER BY etchat_radio_id ASC"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->radioList = is_array($result) ? $result : [];
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate($lang, string $userRole): void
    {
        $radioList = $this->prepareRadioListForTemplate($lang);
        $csrfToken = $this->csrfToken;
        
        include_once "styles/admin_tpl/indexRadioBox.tpl.html";
    }

    /**
     * Bereitet die Radio-Daten für das Template vor
     * Wandelt 0/1 Werte in farbige Punkte um
     */
    private function prepareRadioListForTemplate($lang): array
    {
        $prepared = [];

        foreach ($this->radioList as $row) {
            $box = (int)($row['etchat_radio_box'] ?? 0);
            $onAir = (int)($row['etchat_on_air'] ?? 0);
            $sysTitel = (int)($row['etchat_system_titel_an'] ?? 0);
            $titelHits = (int)($row['etchat_titel_an'] ?? 0);
            $player = (int)($row['etchat_radio_player'] ?? 0);

            $prepared[] = [
                'id'        => (int)($row['etchat_radio_id'] ?? 0),
                'box'       => $this->getStatusHtml($box, $lang),
                'host'      => $this->escape((string)($row['etchat_radio_horst'] ?? '')),
                'port'      => $this->escape((string)($row['etchat_radio_port'] ?? '')),
                'typ'       => $this->escape((string)($row['etchat_radio_typ'] ?? '')),
                'bit'       => $this->escape((string)($row['etchat_radio_bit'] ?? '')),
                'onAir'     => $this->getStatusHtml($onAir, $lang),
                'sysTitel'  => $this->getStatusHtml($sysTitel, $lang),
                'titelHits' => $this->getStatusHtml($titelHits, $lang),
                'player'    => $this->getStatusHtml($player, $lang),
                'stream'    => $this->escape((string)($row['etchat_radio_stream'] ?? ''))
            ];
        }

        return $prepared;
    }

    /**
     * Gibt HTML für Status (grüner/roter Punkt) zurück
     */
    private function getStatusHtml(int $value, $lang): string
    {
        if ($value == 1) {
            return '<span style="color: #4CAF50; font-size: 16px;">●</span> <span style="color: #4CAF50;">' . ($lang->get('admin_radio_status_on') ?? 'An') . '</span>';
        }
        return '<span style="color: #f44336; font-size: 16px;">●</span> <span style="color: #f44336;">' . ($lang->get('admin_radio_status_off') ?? 'Aus') . '</span>';
    }

    private function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }
}