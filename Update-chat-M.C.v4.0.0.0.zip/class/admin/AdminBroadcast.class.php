<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminBroadcast extends DbConectionMaker
{
    private string $csrfToken = '';
    private string $broadcastFile;
    private array $broadcastData = [];

    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Broadcast Cache-Datei
        $this->broadcastFile = dirname(__DIR__, 2) . "/cache/broadcast.json";

        // -------------------------
        // Config Daten in Session laden
        // -------------------------
        $this->configTabData2Session();

        // -------------------------
        // CSRF Token
        // -------------------------
        $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // -------------------------
        // Rollen prüfen
        // -------------------------
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        $allowedRoles = ['admin', 'co_admin'];
        
        if (!in_array($userPriv, $allowedRoles, true)) {
            if (isset($_GET['function'])) {
                // AJAX Request: JSON Fehler zurückgeben
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => $lang->get('admin_broadcast_error_access') ?? 'Zugriff verweigert']);
                exit;
            }
            echo $lang->get('admin_broadcast_error_access') ?? 'Zugriff verweigert';
            return;
        }

        // -------------------------
        // AJAX Requests verarbeiten
        // -------------------------
        if (isset($_GET['function'])) {
            $this->handleAjaxRequest($lang);
            exit;
        }

        // -------------------------
        // Template anzeigen
        // -------------------------
        $backlink = ($userPriv === 'co_admin') ? './?AdminIndexCoAdmin' : './?AdminIndex';
        
        $this->renderTemplate($lang, $backlink);
    }

    /**
     * Verarbeitet alle AJAX Requests
     */
    private function handleAjaxRequest($lang): void
    {
        header('Content-Type: application/json');
        
        $function = $_GET['function'] ?? '';
        $adminId = (int)($_GET['admin_id'] ?? $_POST['admin_id'] ?? 0);
        $sessionAdminId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        
        // Sicherheitsprüfung: admin_id muss mit Session übereinstimmen
        if ($adminId !== $sessionAdminId) {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_broadcast_error_invalid_admin') ?? 'Ungültige Admin-ID']);
            return;
        }
        
        // CSRF-Prüfung für POST-Requests
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
            if (!$token || !hash_equals($this->csrfToken, $token)) {
                echo json_encode(['success' => false, 'error' => $lang->get('admin_broadcast_error_csrf') ?? 'CSRF Token ungültig']);
                return;
            }
        }
        
        // Match-Expression für Funktionsdispatch
        $result = match($function) {
            'sendBroadcast' => $this->sendBroadcast($lang),
            'getBroadcastStatus' => $this->getBroadcastStatus($lang),
            'clearBroadcast' => $this->clearBroadcast($lang),
            default => false
        };
        
        // Wenn die Funktion bereits ein echo gemacht hat, nichts weiter tun
        if ($result === false && $function !== '') {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_broadcast_error_unknown') ?? 'Unbekannte Funktion']);
        }
    }

    /**
     * Sendet einen Broadcast
     */
    private function sendBroadcast($lang): bool
    {
        $message = trim($_POST['message'] ?? '');
        $messageType = $_POST['message_type'] ?? 'standard';
        $noReload = isset($_POST['no_reload']);
        
        if ($message === '') {
            echo json_encode(['success' => false, 'error' => $lang->get('admin_broadcast_error_empty') ?? 'Nachricht darf nicht leer sein']);
            return true;
        }
        
        // Nachrichtentyp validieren
        $allowedTypes = ['standard', 'general', 'welcome'];
        if (!in_array($messageType, $allowedTypes, true)) {
            $messageType = 'standard';
        }
        
        // Nachricht auf 5000 Zeichen begrenzen
        $message = mb_substr($message, 0, 5000);
        
        // Aktuelle Online-User zählen
        $onlineCount = $this->getOnlineUserCount();
        
        // Empfänger je nach Typ ermitteln
        $targetCount = $this->getTargetCount($messageType);
        
        // Broadcast-Daten speichern
        $this->broadcastData = [
            'message' => $message,
            'message_type' => $messageType,
            'no_reload' => $noReload,
            'created_at' => time(),
            'admin_id' => (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0),
            'target_count' => $targetCount,
            'seen_count' => 0,
            'current_online_count' => $onlineCount
        ];
        
        // Je nach Typ in Session oder Cache speichern
        if ($messageType === 'welcome') {
            // Willkommensnachricht nur in Session für neue User
            $_SESSION['etchat_' . $this->_prefix . 'welcome_message'] = $message;
        } else {
            // Standard/General Broadcast in Cache-Datei
            $this->saveBroadcast();
        }
        
        echo json_encode([
            'success' => true,
            'target_count' => $targetCount,
            'current_online_count' => $onlineCount
        ]);
        
        return true;
    }

    /**
     * Gibt den aktuellen Broadcast-Status zurück
     */
    private function getBroadcastStatus($lang): bool
    {
        $hasBroadcast = false;
        $broadcastData = null;
        
        // Prüfe ob Broadcast in Cache existiert
        if (file_exists($this->broadcastFile)) {
            $content = file_get_contents($this->broadcastFile);
            $data = json_decode($content, true);
            
            if (is_array($data) && !empty($data['message'])) {
                // Prüfe ob Broadcast noch gültig ist (max 24 Stunden)
                if (($data['created_at'] ?? 0) > time() - 86400) {
                    $hasBroadcast = true;
                    $broadcastData = $data;
                    $broadcastData['seen_count'] = $this->getSeenCount();
                    $broadcastData['current_online_count'] = $this->getOnlineUserCount();
                } else {
                    // Alter Broadcast löschen
                    $this->clearBroadcast($lang);
                }
            }
        }
        
        // Prüfe auch Willkommensnachricht
        if (!$hasBroadcast && !empty($_SESSION['etchat_' . $this->_prefix . 'welcome_message'])) {
            $hasBroadcast = true;
            $broadcastData = [
                'message' => $_SESSION['etchat_' . $this->_prefix . 'welcome_message'],
                'message_type' => 'welcome',
                'no_reload' => false,
                'created_at' => time(),
                'target_count' => null
            ];
        }
        
        echo json_encode([
            'hasBroadcast' => $hasBroadcast,
            'message' => $broadcastData['message'] ?? null,
            'message_type' => $broadcastData['message_type'] ?? null,
            'no_reload' => $broadcastData['no_reload'] ?? false,
            'target_count' => $broadcastData['target_count'] ?? 0,
            'seen_count' => $broadcastData['seen_count'] ?? 0,
            'current_online_count' => $this->getOnlineUserCount()
        ]);
        
        return true;
    }

    /**
     * Löscht den aktuellen Broadcast
     */
    private function clearBroadcast($lang): bool
    {
        if (file_exists($this->broadcastFile)) {
            unlink($this->broadcastFile);
        }
        
        unset($_SESSION['etchat_' . $this->_prefix . 'welcome_message']);
        
        echo json_encode(['success' => true]);
        return true;
    }

    /**
     * Speichert den Broadcast in der Cache-Datei
     */
    private function saveBroadcast(): void
    {
        file_put_contents(
            $this->broadcastFile,
            json_encode($this->broadcastData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    /**
     * Gibt die Anzahl der aktuell online User zurück
     */
    private function getOnlineUserCount(): int
    {
        try {
            $stmt = $this->dbObj->getConnection()->prepare(
                "SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_useronline"
            );
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return (int)($result['cnt'] ?? 0);
        } catch (Exception $e) {
            return 0;
        }
    }

    /**
     * Gibt die Anzahl der gesehenen Broadcasts zurück
     */
    private function getSeenCount(): int
    {
        // Hier könnte man in einer DB-Tabelle tracken wer den Broadcast gesehen hat
        // Aktuell simulieren wir einen Wert
        return rand(0, $this->getOnlineUserCount());
    }

    /**
     * Gibt die Anzahl der Empfänger je nach Nachrichtentyp zurück
     */
    private function getTargetCount(string $messageType): int
    {
        return match($messageType) {
            'standard' => $this->getOnlineUserCount(),
            'general' => $this->getTotalUserCount(),
            'welcome' => 0, // Unbekannt, da neue User
            default => $this->getOnlineUserCount()
        };
    }

    /**
     * Gibt die Gesamtzahl aller User zurück
     */
    private function getTotalUserCount(): int
    {
        try {
            $stmt = $this->dbObj->getConnection()->prepare(
                "SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_user"
            );
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return (int)($result['cnt'] ?? 0);
        } catch (Exception $e) {
            return 0;
        }
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate($lang, string $backlink): void
    {
        $csrfToken = $this->csrfToken;
        $adminId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        
        include __DIR__ . "/../../styles/admin_tpl/indexBroadcast.tpl.html";
    }
}