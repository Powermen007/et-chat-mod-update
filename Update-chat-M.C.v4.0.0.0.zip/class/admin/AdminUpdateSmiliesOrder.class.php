<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.

Speichert die Sortierreihenfolge der Smileys
*/

declare(strict_types=1);

class AdminUpdateSmiliesOrder extends DbConectionMaker
{
    // Maximale Anzahl Smileys pro Update (Sicherheit)
    private const MAX_SMILEYS = 500;
    
    // Minimales und maximales Gewicht
    private const MIN_WEIGHT = 1;
    private const MAX_WEIGHT = 99999;

    public function __construct()
    {
        parent::__construct();

        // Session sicher starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Content-Type: application/json; charset=utf-8");

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rechteprüfung
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($role, $allowedRoles, true)) {
            $this->sendError($lang->get('admin_updatesmiliesorder_error_access') ?? "Keine Berechtigung", 403);
            exit;
        }

        // JSON lesen
        $raw = file_get_contents("php://input");
        $data = json_decode($raw, true);

        if (!is_array($data)) {
            $this->sendError($lang->get('admin_updatesmiliesorder_error_invalid_json') ?? "Ungültige JSON-Daten", 400);
            exit;
        }

        // Prüfen ob Daten im erwarteten Format vorliegen
        // Unterstützt zwei Formate:
        // 1. [{id: 1, weight: 10}, ...]
        // 2. {ids: [1,2,3], kat: "name", site: 1}
        $isWeightFormat = isset($data[0]) && isset($data[0]['weight']);
        $isIdsFormat = isset($data['ids']) && is_array($data['ids']);

        if (!$isWeightFormat && !$isIdsFormat) {
            $this->sendError($lang->get('admin_updatesmiliesorder_error_invalid_format') ?? "Ungültiges Datenformat", 400);
            exit;
        }

        // Maximale Anzahl prüfen
        $itemCount = $isWeightFormat ? count($data) : count($data['ids']);
        if ($itemCount > self::MAX_SMILEYS) {
            $this->sendError($lang->get('admin_updatesmiliesorder_error_too_many') ?? "Zu viele Smileys (max. " . self::MAX_SMILEYS . ")", 400);
            exit;
        }

        // CSRF prüfen (Header)
        $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

        if (!hash_equals($sessionToken, $csrfHeader)) {
            $this->sendError($lang->get('admin_updatesmiliesorder_error_csrf') ?? "Ungültiger CSRF Token", 403);
            exit;
        }

        try {
            $pdo = $this->dbObj->getConnection();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                UPDATE {$this->_prefix}etchat_smileys
                SET etchat_smileys_gewicht = :weight
                WHERE etchat_smileys_id = :id
            ");

            $updatedCount = 0;
            $skippedCount = 0;

            if ($isWeightFormat) {
                // Format 1: [{id: 1, weight: 10}, ...]
                foreach ($data as $row) {
                    $id = (int)($row['id'] ?? 0);
                    $weight = (int)($row['weight'] ?? 0);
                    
                    if ($id <= 0) {
                        $skippedCount++;
                        continue;
                    }
                    
                    // Gewicht validieren
                    $weight = max(self::MIN_WEIGHT, min(self::MAX_WEIGHT, $weight));
                    
                    $stmt->execute([':id' => $id, ':weight' => $weight]);
                    if ($stmt->rowCount() > 0) {
                        $updatedCount++;
                    }
                }
            } else {
                // Format 2: {ids: [1,2,3], kat: "name", site: 1}
                // Gewicht wird serverseitig berechnet
                $ids = $data['ids'];
                $site = max(1, (int)($data['site'] ?? 1));
                $perPage = 30;
                $offset = ($site - 1) * $perPage;
                $weight = ($offset * 5) + 5;
                
                foreach ($ids as $id) {
                    $id = (int)$id;
                    if ($id <= 0) {
                        $skippedCount++;
                        continue;
                    }
                    
                    $stmt->execute([':id' => $id, ':weight' => $weight]);
                    if ($stmt->rowCount() > 0) {
                        $updatedCount++;
                    }
                    $weight += 5;
                }
            }

            $pdo->commit();
            $this->dbObj->close();

            echo json_encode([
                "success" => true,
                "message" => "✅ " . ($lang->get('admin_updatesmiliesorder_success') ?? "Sortierung gespeichert") . " ($updatedCount " . ($lang->get('admin_updatesmiliesorder_smilies') ?? "Smileys") . " " . ($lang->get('admin_updatesmiliesorder_updated') ?? "aktualisiert") . ")",
                "updated" => $updatedCount,
                "skipped" => $skippedCount
            ]);
            exit;

        } catch (PDOException $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log("AdminUpdateSmiliesOrder Fehler: " . $e->getMessage());
            $this->sendError($lang->get('admin_updatesmiliesorder_error_database') ?? "Datenbankfehler: " . $e->getMessage(), 500);
            exit;
        }
    }

    private function sendError(string $message, int $statusCode = 400): void
    {
        http_response_code($statusCode);
        echo json_encode([
            "success" => false,
            "error" => $message
        ]);
        exit;
    }
}