<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminInsertSmiliesgrupp extends DbConectionMaker
{
    private array $allowedRoles = ["admin", "grafik", "co_admin"];
    private string $uploaddir;
    private string $message = '';
    private const GW_STEP = 5;
    private const MAX_FILES = 100; // Maximale Anzahl Dateien pro Upload

    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollen prüfen
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        if (!in_array($role, $this->allowedRoles, true)) {
            echo $lang->get('admin_insertsmiliesgroup_error_access') ?? '<span style="color:red;">Zugriff verweigert</span>';
            exit;
        }
        
        // CSRF prüfen (Token NICHT löschen!)
        $csrfToken = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

        if (empty($csrfToken) || empty($sessionToken) || !hash_equals($sessionToken, $csrfToken)) {
            echo $lang->get('admin_insertsmiliesgroup_error_csrf') ?? '<span style="color:red;">Ungültiger CSRF-Token.</span>';
            exit;
        }
        // KEIN unset($_SESSION['...']) mehr!

        // Upload-Verzeichnis
        $basePath = realpath(__DIR__ . '/../../smilies');
        if ($basePath === false) {
            throw new RuntimeException('Smilies-Verzeichnis nicht gefunden.');
        }
        $this->uploaddir = $basePath . DIRECTORY_SEPARATOR;

        // Kategorie-Ordner erstellen
        $catRaw = $_POST['cat'] ?? $_GET['cat'] ?? 'default';
        $catDb = trim($catRaw);
        $catName = preg_replace("/[^a-zA-Z0-9_-]/", "_", $catRaw);
        $catFolder = $this->uploaddir . $catName . DIRECTORY_SEPARATOR;
        
        if (!is_dir($catFolder) && !mkdir($catFolder, 0775, true)) {
            throw new RuntimeException('Ordner konnte nicht erstellt werden.');
        }

        // Gewicht starten
        $gw_start = max(1, (int)($_POST['gw'] ?? $_GET['gw'] ?? 100));
        $gw_current = $gw_start;

        // Prüfen ob Dateien vorhanden
        if (!isset($_FILES['smiliefiles']['tmp_name']) || !is_array($_FILES['smiliefiles']['tmp_name'])) {
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmiliesgroup_error_no_files') ?? 'Keine Dateien hochgeladen.') . '</span>';
            $this->showResult($lang);
            return;
        }

        // Maximale Dateianzahl prüfen
        $fileCount = count($_FILES['smiliefiles']['tmp_name']);
        if ($fileCount > self::MAX_FILES) {
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmiliesgroup_error_max_files') ?? 'Maximal ' . self::MAX_FILES . ' Dateien pro Upload erlaubt.') . '</span>';
            $this->showResult($lang);
            return;
        }

        $notes = "";
        $successCount = 0;
        $errorCount = 0;

        foreach ($_FILES['smiliefiles']['tmp_name'] as $key => $tmp_name) {
            if (!is_uploaded_file($tmp_name)) continue;

            // Dateiname bereinigen
            $originalName = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($_FILES['smiliefiles']['name'][$key]));
            $basename = pathinfo($originalName, PATHINFO_FILENAME);
            $basename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $basename);
            $basename = mb_substr($basename, 0, 19);

            // Einzigartiges Kürzel generieren
            $sign = ':' . $basename;
            $counter = 1;
            while ($this->signExists($sign)) {
                $maxBaseLen = 19 - strlen((string)$counter);
                $shortBase = mb_substr($basename, 0, max(1, $maxBaseLen));
                $sign = ':' . $shortBase . $counter;
                $counter++;
                
                // Sicherheitsabbruch (verhindert Endlosschleife)
                if ($counter > 1000) {
                    $notes .= '<span style="color:red;">' . ($lang->get('admin_insertsmiliesgroup_error_unique_sign') ?? 'Konnte kein einzigartiges Kürzel für') . ' ' . htmlspecialchars($originalName) . ' ' . ($lang->get('admin_insertsmiliesgroup_error_find') ?? 'finden.') . '</span><br>';
                    $errorCount++;
                    continue 2;
                }
            }

            // Bild validieren
            $imageInfo = @getimagesize($tmp_name);
            if ($imageInfo === false) {
                $notes .= '<span style="color:red;">' . ($lang->get('admin_insertsmiliesgroup_error_invalid_image') ?? 'Datei ist kein gültiges Bild.') . ' ' . htmlspecialchars($originalName) . '</span><br>';
                $errorCount++;
                continue;
            }
            
            $allowedTypes = ['image/png', 'image/gif', 'image/jpeg', 'image/webp'];
            $mimeType = mime_content_type($tmp_name);

            if (!in_array($mimeType, $allowedTypes, true)) {
                $notes .= '<span style="color:red;">' . ($lang->get('admin_insertsmiliesgroup_error_invalid_type') ?? 'Datei hat ungültigen Dateityp.') . ' ' . htmlspecialchars($originalName) . '</span><br>';
                $errorCount++;
                continue;
            }

            // Datei speichern (bei Konflikt umbenennen)
            $targetFile = $catFolder . $originalName;
            if (file_exists($targetFile)) {
                $nowname = time() . "_" . $originalName;
                $targetFile = $catFolder . $nowname;
                $notes .= '<span style="color:orange;">' . ($lang->get('admin_insertsmiliesgroup_file_exists') ?? 'Datei existiert, umbenannt zu') . ' ' . htmlspecialchars($nowname) . '</span><br>';
            } else {
                $nowname = $originalName;
            }

            if (!move_uploaded_file($tmp_name, $targetFile)) {
                $notes .= '<span style="color:red;">' . ($lang->get('admin_insertsmiliesgroup_error_upload') ?? 'Fehler beim Upload von') . ' ' . htmlspecialchars($originalName) . '</span><br>';
                $errorCount++;
                continue;
            }

            $relativePath = "./smilies/{$catName}/" . $nowname;

            // In Datenbank speichern
            try {
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_smileys
                    (etchat_smileys_kat, etchat_smileys_sign, etchat_smileys_img, etchat_smileys_gewicht)
                    VALUES (:cat, :sign, :img, :gewicht)",
                    [
                        ':cat' => $catDb,
                        ':sign' => $sign,
                        ':img' => $relativePath,
                        ':gewicht' => $gw_current
                    ]
                );
                
                $notes .= '<span style="color:green;">✅ ' . ($lang->get('admin_insertsmiliesgroup_success') ?? 'Smilie') . ' ' . htmlspecialchars($sign) . ' ' . ($lang->get('admin_insertsmiliesgroup_uploaded') ?? 'hochgeladen') . ' (' . ($lang->get('admin_insertsmiliesgroup_weight') ?? 'Gewicht') . ' ' . $gw_current . ').</span><br>';
                $successCount++;
                
            } catch (PDOException $e) {
                error_log("AdminInsertSmiliesgrupp Fehler: " . $e->getMessage());
                $notes .= '<span style="color:red;">' . ($lang->get('admin_insertsmiliesgroup_error_database') ?? 'Datenbankfehler bei') . ' ' . htmlspecialchars($originalName) . '</span><br>';
                $errorCount++;
            }

            $gw_current += self::GW_STEP;
        }

        // Ergebnis zusammenstellen
        $this->message = "<b>" . ($lang->get('admin_insertsmiliesgroup_completed') ?? 'Upload abgeschlossen') . "</b><br>";
        $this->message .= "📁 " . ($lang->get('admin_insertsmiliesgroup_success_count') ?? 'Erfolgreich') . ": $successCount, ❌ " . ($lang->get('admin_insertsmiliesgroup_error_count') ?? 'Fehler') . ": $errorCount<br><br>";
        $this->message .= $notes;
        
        $this->showResult($lang);
    }

    /**
     * Prüft ob ein Smiley-Kürzel bereits existiert
     */
    private function signExists(string $sign): bool
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_smileys_id FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_sign = :sign"
        );
        $stmt->execute([':sign' => $sign]);
        return $stmt->fetch() !== false;
    }

    private function showResult($lang): void
    {
        $print_result = $this->message; // Für Kompatibilität mit altem Template
        $message = $this->message;
        include_once "styles/admin_tpl/insertSmiliesMessage.tpl.html";
        $this->dbObj->close();
    }
}