<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminImgManager extends DbConectionMaker
{
    private const ALLOWED_ROLES = ['admin', 'grafik', 'co_admin'];
    private const ALLOWED_EXTENSIONS = ['png', 'jpg', 'jpeg', 'gif'];
    
    private string $csrfToken = '';
    private array $icons = [];

    public function __construct()
    {
        parent::__construct();
        
        // Session starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        
        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");
        
        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];
        
        // Icons initialisieren
        $this->initIcons();
        
        // Zugriff prüfen
        $this->checkAccess();
        
        // POST verarbeiten
        $this->handlePost($lang);
        
        // Template anzeigen
        $this->render($lang);
    }

    private function checkAccess(): void
    {
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        
        if (!in_array($userRole, self::ALLOWED_ROLES, true)) {
            header("Location: ../");
            exit;
        }
    }

    private function initIcons(): void
    {
        $this->icons = [
            ["id"=>"grussbox","title"=>"Grussbox Icon","filename"=>"Grussbox.png","path"=>"img/Grussbox.png","default"=>"img_default/Grussbox.png"],
            ["id"=>"userliste","title"=>"Userliste Icon","filename"=>"Userliste.png","path"=>"img/Userliste.png","default"=>"img_default/Userliste.png"],
            ["id"=>"checked","title"=>"Senden Icon","filename"=>"Checked.png","path"=>"img/Checked.png","default"=>"img_default/Checked.png"],
            ["id"=>"smiley_cool","title"=>"Smiley Icon","filename"=>"Smiley_Cool.png","path"=>"img/Smiley_Cool.png","default"=>"img_default/Smiley_Cool.png"],
            ["id"=>"picture","title"=>"Picture Icon","filename"=>"picture.png","path"=>"img/picture.png","default"=>"img_default/picture.png"],
            ["id"=>"video","title"=>"Video Icon","filename"=>"video.png","path"=>"img/video.png","default"=>"img_default/video.png"],
            ["id"=>"colors","title"=>"Colors Icon","filename"=>"Colors.png","path"=>"img/Colors.png","default"=>"img_default/Colors.png"],
            ["id"=>"display","title"=>"Einstellungen Icon","filename"=>"Display.png","path"=>"img/Display.png","default"=>"img_default/Display.png"],
            ["id"=>"wuerfel_gif","title"=>"Würfel GIF Icon","filename"=>"wuerfel.gif","path"=>"img/wuerfel.gif","default"=>"img_default/wuerfel.gif"],
            ["id"=>"redwuerfel","title"=>"Roter Würfel im Chat","filename"=>"redwuerfel.png","path"=>"img/redwuerfel.png","default"=>"img_default/redwuerfel.png"],
            ["id"=>"vollbild","title"=>"Vollbild Icon","filename"=>"Vollbild.png","path"=>"img/Vollbild.png","default"=>"img_default/Vollbild.png"],
            ["id"=>"bild","title"=>"Bild Hochladen Icon","filename"=>"Bild.png","path"=>"img/Bild.png","default"=>"img_default/Bild.png"],
            ["id"=>"gallery","title"=>"Gallery Icon","filename"=>"Gallery.png","path"=>"img/Gallery.png","default"=>"img_default/Gallery.png"],
            ["id"=>"kurz_befehl","title"=>"Befehle Icon","filename"=>"gear.png","path"=>"img/gear.png","default"=>"img_default/gear.png"],
            ["id"=>"delete_big","title"=>"Logout Icon","filename"=>"Delete_big.png","path"=>"img/Delete_big.png","default"=>"img_default/Delete_big.png"],
            ["id"=>"team","title"=>"Team Icon","filename"=>"team.png","path"=>"img/team.png","default"=>"img_default/team.png"],
            ["id"=>"bewerbung","title"=>"Bewerbung Icon","filename"=>"bewerbung.png","path"=>"img/bewerbung.png","default"=>"img_default/bewerbung.png"],
            ["id"=>"sendeplan","title"=>"Sendeplan Icon","filename"=>"sendeplan.gif","path"=>"img/sendeplan.gif","default"=>"img_default/sendeplan.gif"],
            ["id"=>"playlist","title"=>"Playlist Icon","filename"=>"playlist.png","path"=>"img/playlist.png","default"=>"img_default/playlist.png"],
            ["id"=>"admin","title"=>"Admin Icon","filename"=>"admin.png","path"=>"img/admin.png","default"=>"img_default/admin.png"],
            ["id"=>"djbox","title"=>"DJ Box Icon","filename"=>"djbox.png","path"=>"img/djbox.png","default"=>"img_default/djbox.png"],
            ["id"=>"top_list","title"=>"Top List Icon","filename"=>"top_list.png","path"=>"img/top_list.png","default"=>"img_default/top_list.png"],
            ["id"=>"status_online","title"=>"Status Online","filename"=>"status_online.png","path"=>"img/status_online.png","default"=>"img_default/status_online.png"],
            ["id"=>"status_away","title"=>"Status Away","filename"=>"status_away.png","path"=>"img/status_away.png","default"=>"img_default/status_away.png"],
            ["id"=>"status_busy","title"=>"Status Busy","filename"=>"status_busy.png","path"=>"img/status_busy.png","default"=>"img_default/status_busy.png"],
            ["id"=>"status_chatwache","title"=>"Status Chatwache","filename"=>"status_chatwache.png","path"=>"img/status_chatwache.png","default"=>"img_default/status_chatwache.png"],
            ["id"=>"status_chef","title"=>"Status Chef","filename"=>"status_chef.png","path"=>"img/status_chef.png","default"=>"img_default/status_chef.png"],
            ["id"=>"status_grafik","title"=>"Status Grafik","filename"=>"status_grafik.png","path"=>"img/status_grafik.png","default"=>"img_default/status_grafik.png"],
            ["id"=>"status_invisible","title"=>"Status Invisible","filename"=>"status_invisible.png","path"=>"img/status_invisible.png","default"=>"img_default/status_invisible.png"],
            ["id"=>"status_moderator","title"=>"Status Moderator","filename"=>"status_moderator.png","path"=>"img/status_moderator.png","default"=>"img_default/status_moderator.png"],
            ["id"=>"status_onair","title"=>"Status OnAir","filename"=>"status_onair.png","path"=>"img/status_onair.png","default"=>"img_default/status_onair.png"],
            ["id"=>"status_teamleiter","title"=>"Status Teamleiter","filename"=>"status_teamleiter.png","path"=>"img/status_teamleiter.png","default"=>"img_default/status_teamleiter.png"],
            ["id"=>"status_techniker","title"=>"Status Techniker","filename"=>"status_techniker.png","path"=>"img/status_techniker.png","default"=>"img_default/status_techniker.png"],
            ["id"=>"status_telephone","title"=>"Status Telephone","filename"=>"status_telephone.png","path"=>"img/status_telephone.png","default"=>"img_default/status_telephone.png"],
            ["id"=>"status_user","title"=>"Status User","filename"=>"status_user.png","path"=>"img/status_user.png","default"=>"img_default/status_user.png"],
            ["id"=>"homepage","title"=>"Homepage Icon","filename"=>"homepage.png","path"=>"img/menu/homepage.png","default"=>"img_default/homepage.png"],
            ["id"=>"ts","title"=>"TS Icon","filename"=>"teamspeak.png","path"=>"img/menu/teamspeak.png","default"=>"img_default/teamspeak.png"]
        ];
    }

    private function handlePost($lang): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
        
        // CSRF CHECK
        $sessionToken = $this->csrfToken;
        $postToken = $_POST['csrf_token'] ?? '';

        if (!$postToken || !hash_equals($sessionToken, $postToken)) {
            http_response_code(403);
            exit($lang->get('admin_imgmanager_error_csrf') ?? 'Ungültiger CSRF Token!');
        }

        // ICON HANDLING (Upload / Reset einzelnes Icon)
        if (isset($_POST['id'])) {
            $this->handleIconAction($_POST['id'], $lang);
            return;
        }

        // RESET ALL
        if (isset($_POST['reset_all'])) {
            $this->resetAllIcons();
            return;
        }

        // MENÜ ICONS
        if (isset($_POST['delete_menu'])) {
            $this->deleteMenuItem($_POST['delete_menu']);
            return;
        }
        if (isset($_FILES['upload_menu'])) {
            $this->uploadMenuItem($_FILES['upload_menu'], $lang);
            return;
        }

        // IMAGES
        if (isset($_POST['delete_image'])) {
            $this->deleteImage($_POST['delete_image']);
            return;
        }
        if (isset($_FILES['upload_image'])) {
            $this->uploadImage($_FILES['upload_image'], $lang);
            return;
        }

        // BACKGROUND
        if (isset($_POST['delete_bg'])) {
            $this->deleteBackground($_POST['delete_bg']);
            return;
        }
        if (isset($_FILES['upload_bg'])) {
            $this->uploadBackground($_FILES['upload_bg'], $lang);
            return;
        }
    }

    private function handleIconAction(string $iconId, $lang): void
    {
        foreach ($this->icons as $icon) {
            if ($icon['id'] === $iconId) {
                
                // Reset auf Standard
                if (isset($_POST['reset'])) {
                    if (file_exists($icon['default'])) {
                        copy($icon['default'], $icon['path']);
                    }
                }
                
                // Upload neues Icon
                if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                    $this->uploadIcon($_FILES['file'], $icon, $lang);
                }
                
                break;
            }
        }
        
        header("Location: ./?AdminImgManager");
        exit;
    }

    private function uploadIcon(array $file, array $icon, $lang): void
    {
        $tmp = $file['tmp_name'];
        $uploadedExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $defaultExt = strtolower(pathinfo($icon['default'], PATHINFO_EXTENSION));

        if ($uploadedExt !== $defaultExt) {
            exit($lang->get('admin_imgmanager_error_invalid_ext') ?? "Ungültiges Dateiformat! Nur .$defaultExt erlaubt.");
        }

        if (!move_uploaded_file($tmp, $icon['path'])) {
            exit($lang->get('admin_imgmanager_error_upload') ?? "Fehler beim Hochladen!");
        }
        
        $this->resizeImageAuto($icon['path'], $icon['default'], $icon['path']);
    }

    private function resetAllIcons(): void
    {
        foreach ($this->icons as $icon) {
            if (file_exists($icon['default'])) {
                copy($icon['default'], $icon['path']);
            }
        }
        
        header("Location: ./?AdminImgManager");
        exit;
    }

    private function deleteMenuItem(string $filename): void
    {
        $file = basename($filename);
        $path = "img/menu/" . $file;
        if (file_exists($path)) {
            unlink($path);
        }
        header("Location: ./?AdminImgManager");
        exit;
    }

    private function uploadMenuItem(array $file, $lang): void
    {
        $this->uploadGeneralImage($file, "img/menu/", $lang);
    }

    private function deleteImage(string $filename): void
    {
        $file = basename($filename);
        $path = "img/images/" . $file;
        if (file_exists($path)) {
            unlink($path);
        }
        header("Location: ./?AdminImgManager");
        exit;
    }

    private function uploadImage(array $file, $lang): void
    {
        $this->uploadGeneralImage($file, "img/images/", $lang);
    }

    private function deleteBackground(string $filename): void
    {
        $style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'style_chat';
        $file = basename($filename);
        $path = "styles/" . $style . "/hintergrund/" . $file;
        
        if (file_exists($path)) {
            unlink($path);
        }
        
        header("Location: ./?AdminImgManager");
        exit;
    }

    private function uploadBackground(array $file, $lang): void
    {
        $style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'style_chat';
        $dir = "styles/" . $style . "/hintergrund/";
        
        if (is_dir($dir)) {
            $this->uploadGeneralImage($file, $dir, $lang);
        }
        
        header("Location: ./?AdminImgManager");
        exit;
    }

    private function uploadGeneralImage(array $file, string $targetDir, $lang): void
    {
        $tmp = $file['tmp_name'];
        $name = basename($file['name']);
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $dest = $targetDir . $name;

        if (in_array($ext, self::ALLOWED_EXTENSIONS, true) && is_uploaded_file($tmp)) {
            move_uploaded_file($tmp, $dest);
        }
    }

    private function resizeImageAuto(string $uploadedFile, string $defaultFile, string $outputFile): bool
    {
        $defaultInfo = @getimagesize($defaultFile);
        if (!$defaultInfo) return false;
        
        list($targetWidth, $targetHeight) = $defaultInfo;

        $uploadInfo = @getimagesize($uploadedFile);
        if (!$uploadInfo) return false;
        
        $mime = $uploadInfo['mime'];

        // GIF mit Imagick (Animation erhalten)
        if ($mime === 'image/gif' && class_exists('Imagick')) {
            return $this->resizeGifWithImagick($uploadedFile, $targetWidth, $targetHeight, $outputFile);
        }

        return $this->resizeStaticImage($uploadedFile, $targetWidth, $targetHeight, $outputFile, $uploadInfo);
    }

    private function resizeGifWithImagick(string $sourceFile, int $targetWidth, int $targetHeight, string $outputFile): bool
    {
        $gif = new Imagick();
        $gif->readImage($sourceFile);
        $gif = $gif->coalesceImages();

        foreach ($gif as $frame) {
            $frame->thumbnailImage($targetWidth, $targetHeight);
            $frame->setImagePage(0, 0, 0, 0);
        }

        $gif = $gif->deconstructImages();
        $gif->setImageFormat('gif');
        $gif->writeImages($outputFile, true);
        $gif->clear();
        $gif->destroy();

        return true;
    }

    private function resizeStaticImage(string $sourceFile, int $targetWidth, int $targetHeight, string $outputFile, array $sourceInfo): bool
    {
        switch ($sourceInfo[2]) {
            case IMAGETYPE_JPEG: 
                $src = imagecreatefromjpeg($sourceFile); 
                break;
            case IMAGETYPE_PNG:  
                $src = imagecreatefrompng($sourceFile); 
                break;
            case IMAGETYPE_GIF:  
                $src = imagecreatefromgif($sourceFile); 
                break;
            default: 
                return false;
        }

        $dst = imagecreatetruecolor($targetWidth, $targetHeight);

        // Transparenz erhalten
        if ($sourceInfo[2] == IMAGETYPE_PNG || $sourceInfo[2] == IMAGETYPE_GIF) {
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
            imagefill($dst, 0, 0, $transparent);
        }

        imagecopyresampled(
            $dst, $src,
            0, 0, 0, 0,
            $targetWidth, $targetHeight,
            imagesx($src), imagesy($src)
        );

        imagepng($dst, $outputFile);

        imagedestroy($src);
        imagedestroy($dst);

        return true;
    }

    public function formatBytes(int $bytes, int $precision = 2): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $pow = $bytes > 0 ? floor(log($bytes, 1024)) : 0;
        return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
    }

    private function render($lang): void
    {
        $icons = $this->icons;
        $csrfToken = $this->csrfToken;
        
        include __DIR__ . '/../../styles/admin_tpl/indexImgManager.tpl.html';
    }
}