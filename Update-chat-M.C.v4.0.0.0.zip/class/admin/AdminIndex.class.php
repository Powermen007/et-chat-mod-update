<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminIndex extends EtChatConfig
{
    private array $roleTemplates = [
        'admin'       => 'index.tpl.html',
        'co_admin'    => 'indexCoAdmin.tpl.html',
        'grafik'      => 'indexGrafik.tpl.html',
        'chatwache'   => 'indexChatwache.tpl.html'
    ];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Content-Type: text/html; charset=utf-8');
        }

        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        // Prüfen ob Rolle existiert
        if (!array_key_exists($userRole, $this->roleTemplates)) {
            header("Location: ./");
            exit;
        }

        $this->renderTemplate($lang, $userRole);
    }

    /**
     * Rendert das Template für die jeweilige Rolle
     */
    private function renderTemplate(?object $lang, string $role): void
    {
        $tplFile = dirname(__DIR__, 2) . '/styles/admin_tpl/' . $this->roleTemplates[$role];

        if (is_file($tplFile)) {
            include $tplFile;
        } else {
            http_response_code(500);
            echo "Ein Fehler ist aufgetreten. Template nicht gefunden.";
        }
    }
}