<?php
declare(strict_types=1);

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AdminSpracheBearbeiten extends DbConectionMaker
{
    private string $csrfToken = '';
    private string $langFolder = 'Deutsch';
    private LangXml $lang;
    private array $languageFolders = [];
    private array $categories = [];
    private array $allStrings = [];
    private array $categoryNames = [];

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        try {
            $this->lang = new LangXml("./lang/");
        } catch (Throwable $e) {
            $this->lang = null;
        }

        $userRole = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        if ($userRole !== "admin") {
            $this->fail($this->getText('admin_sprachebearbeiten_error_access', '🔒 Zugriff verweigert.'));
        }

        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        $this->langFolder = $_SESSION['etchat_' . $this->_prefix . 'lang_xml_file'] ?? 'Deutsch';
        $this->languageFolders = $this->getLanguageFolders(__DIR__ . '/../../lang/');

        // ============================================
        // SPEICHERN - Wenn POST, dann speichern!
        // ============================================
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_lang'])) {
            $this->handleSave();
            exit;
        }

        // ============================================
        // ANZEIGEN - Wenn GET, dann anzeigen!
        // ============================================
        $this->showEditor();
    }

    private function showEditor(): void
    {
        $langBase = __DIR__ . '/../../lang/';
        $fileType = $_GET['file_type'] ?? 'chat';
        $langFolder = $_GET['lang_folder'] ?? $this->langFolder;
        $selectedCategory = $_GET['category'] ?? '';
        $selectedFile = $_GET['xml_file'] ?? '';
        
        if (!in_array($langFolder, $this->languageFolders, true)) {
            $langFolder = $this->langFolder;
        }
        $this->langFolder = $langFolder;
        
        $langCode = $this->getLangCode($langFolder);
        
        $xmlFiles = $this->findXmlFiles($langBase, $langFolder, $langCode, $fileType);
        
        if (empty($xmlFiles)) {
            $this->fail($this->getText('admin_sprachebearbeiten_error_no_file', '📄 Keine XML-Datei gefunden in: ') . htmlspecialchars($langBase . $langFolder));
        }
        
        if ($selectedFile === '' || !in_array($selectedFile, $xmlFiles)) {
            $selectedFile = $xmlFiles[0];
        }
        
        $xmlPath = $langBase . $langFolder . '/' . $selectedFile;
        $fileLabel = $fileType === 'admin' ? $this->getText('admin_sprachebearbeiten_file_admin', 'Admin-Sprache') : $this->getText('admin_sprachebearbeiten_file_chat', 'Chat-Sprache');

        $this->parseXmlFile($xmlPath);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_backups'])) {
            $this->handleDeleteBackups($xmlPath);
        }

        $backupCount = $this->countBackups($xmlPath);

        $this->dbObj->close();

        $csrfToken = $this->csrfToken;
        $languageFolders = $this->languageFolders;
        $fileType = $fileType;
        $fileLabel = $fileLabel;
        $langFolder = $langFolder;
        $backupCount = $backupCount;
        $categories = $this->categories;
        $allStrings = $this->allStrings;
        $categoryNames = array_keys($this->categories);
        $xmlFiles = $xmlFiles;
        $selectedFile = $selectedFile;
        
        if ($selectedCategory === '' && !empty($categoryNames)) {
            $selectedCategory = $categoryNames[0];
        }
        
        if (!isset($this->categories[$selectedCategory]) && !empty($categoryNames)) {
            $selectedCategory = $categoryNames[0];
        }
        
        $langFile = basename($xmlPath);
        
        include "styles/admin_tpl/indexSpracheBearbeiten.tpl.html";
    }

    private function findXmlFiles(string $basePath, string $folder, string $langCode, string $fileType): array
    {
        $prefix = $fileType === 'admin' ? 'lang_admin_' : 'lang_';
        $searchPath = $basePath . $folder . '/';
        
        $pattern = $searchPath . $prefix . $langCode . '*.xml';
        $files = glob($pattern);
        
        $result = [];
        foreach ($files as $file) {
            $result[] = basename($file);
        }
        sort($result);
        return $result;
    }

    /**
     * Parst die XML-Datei und extrahiert Kategorien
     * 
     * WICHTIG: Verwendet DOMDocument für korrekte CDATA-Extraktion
     */
    private function parseXmlFile(string $xmlPath): void
    {
        $xmlContent = file_get_contents($xmlPath);
        
        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xmlContent);
        
        if ($xml === false) {
            $this->fail("❌ Fehler beim Parsen der XML-Datei: " . htmlspecialchars($xmlPath));
        }

        $this->categories = [];
        $this->allStrings = [];
        
        // ============================================================
        // Alle Strings sammeln - MIT DOMDocument für korrekte CDATA-Extraktion
        // ============================================================
        $allStringElements = [];
        
        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->loadXML($xmlContent);
        
        $strings = $dom->getElementsByTagName('string');
        foreach ($strings as $stringElement) {
            $key = $stringElement->getAttribute('key');
            
            // Wert extrahieren - CDATA wird automatisch korrekt gelesen
            $value = '';
            foreach ($stringElement->childNodes as $child) {
                if ($child->nodeType === XML_CDATA_SECTION_NODE) {
                    $value = $child->nodeValue;
                } elseif ($child->nodeType === XML_TEXT_NODE) {
                    $value = $child->nodeValue;
                }
            }
            
            // HTML-dekodieren für lesbare Anzeige (z.B. &lt; → <)
            $value = html_entity_decode(trim($value), ENT_QUOTES, 'UTF-8');
            $allStringElements[$key] = $value;
        }
        
        // Kategorien aus Kommentar-Blöcken extrahieren
        $lines = explode("\n", $xmlContent);
        $currentCategory = $this->getText('admin_sprachebearbeiten_category_default', 'Allgemein');
        $currentSubCategory = '';
        $foundCategories = [];
        $categoryOrder = [];
        $inMainBlock = false;
        
        foreach ($lines as $lineNum => $line) {
            $trimmedLine = trim($line);
            
            if (preg_match('/<!--\\s*[=\\-]{10,}\\s*-->/', $trimmedLine)) {
                if ($inMainBlock) {
                    $inMainBlock = false;
                } else {
                    $inMainBlock = true;
                    for ($i = $lineNum + 1; $i < min($lineNum + 10, count($lines)); $i++) {
                        if (isset($lines[$i])) {
                            $nextLine = trim($lines[$i]);
                            if (preg_match('/<!--\\s*([^-]+?)\\s*-->/', $nextLine, $catMatch)) {
                                $catText = trim($catMatch[1]);
                                if (!empty($catText) && strlen($catText) > 3 && 
                                    !preg_match('/^[=\\-\\s]+$/', $catText) &&
                                    !preg_match('/^\\s*$/', $catText)) {
                                    
                                    if (!isset($foundCategories[$catText])) {
                                        $foundCategories[$catText] = [];
                                        $categoryOrder[] = $catText;
                                    }
                                    $currentCategory = $catText;
                                    $currentSubCategory = '';
                                    break;
                                }
                            }
                        }
                    }
                }
                continue;
            }
            
            if (preg_match('/<!--\\s*([^-]+?)\\s*-->/', $trimmedLine, $subMatch)) {
                $subText = trim($subMatch[1]);
                if (!empty($subText) && strlen($subText) > 2 && 
                    !preg_match('/^[=\\-\\s]+$/', $subText) &&
                    !preg_match('/^\\s*$/', $subText) &&
                    $subText !== $currentCategory) {
                    
                    $currentSubCategory = $subText;
                    if (!isset($foundCategories[$currentCategory][$currentSubCategory])) {
                        $foundCategories[$currentCategory][$currentSubCategory] = [];
                    }
                }
                continue;
            }
            
            if (preg_match('/<string key="([^"]+)">/', $line, $strMatch)) {
                $key = trim($strMatch[1]);
                if (isset($allStringElements[$key])) {
                    if (!isset($foundCategories[$currentCategory])) {
                        $foundCategories[$currentCategory] = [];
                        if (!in_array($currentCategory, $categoryOrder)) {
                            $categoryOrder[] = $currentCategory;
                        }
                    }
                    
                    if (!empty($currentSubCategory)) {
                        if (!isset($foundCategories[$currentCategory][$currentSubCategory])) {
                            $foundCategories[$currentCategory][$currentSubCategory] = [];
                        }
                        $foundCategories[$currentCategory][$currentSubCategory][$key] = $allStringElements[$key];
                    } else {
                        if (!isset($foundCategories[$currentCategory]['Allgemein'])) {
                            $foundCategories[$currentCategory]['Allgemein'] = [];
                        }
                        $foundCategories[$currentCategory]['Allgemein'][$key] = $allStringElements[$key];
                    }
                }
            }
        }
        
        $this->categories = array_filter($foundCategories, function($cat) {
            return !empty($cat);
        });
        
        $sorted = [];
        foreach ($categoryOrder as $catName) {
            if (isset($this->categories[$catName])) {
                $sorted[$catName] = $this->categories[$catName];
            }
        }
        $this->categories = $sorted;
        
        foreach ($allStringElements as $key => $value) {
            $this->allStrings[$key] = $value;
        }
        
        if (empty($this->categories)) {
            $this->categories[$this->getText('admin_sprachebearbeiten_category_default', 'Allgemein')] = ['Allgemein' => $allStringElements];
        }
    }

    /**
     * ============================================
     * SPEICHERN - Die eigentliche Speicher-Funktion
     * ============================================
     */
    private function handleSave(): void
    {
        $token = $_POST['csrf'] ?? '';
        if (!hash_equals($this->csrfToken, $token)) {
            $_SESSION['lang_save_error'] = $this->getText('admin_sprachebearbeiten_error_csrf', '🔒 CSRF Fehler');
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $langFolder = trim((string)($_POST['lang_folder'] ?? ''));
        $fileType = trim((string)($_POST['file_type'] ?? 'chat'));
        $selectedCategory = $_POST['selected_category'] ?? '';
        $selectedFile = $_POST['selected_file'] ?? '';

        if ($langFolder === '' || $selectedFile === '') {
            $_SESSION['lang_save_error'] = $this->getText('admin_sprachebearbeiten_error_invalid_input', '❌ Ungültige Eingaben.');
            header("Location: ./?AdminSpracheBearbeiten");
            exit;
        }

        $xmlPath = __DIR__ . '/../../lang/' . $langFolder . '/' . $selectedFile;

        if (!file_exists($xmlPath)) {
            $_SESSION['lang_save_error'] = $this->getText('admin_sprachebearbeiten_error_file_not_found', '📄 Datei nicht gefunden: ') . htmlspecialchars($selectedFile);
            header("Location: ./?AdminSpracheBearbeiten&file_type=" . urlencode($fileType) . "&lang_folder=" . urlencode($langFolder));
            exit;
        }

        // Geänderte Strings sammeln
        $updatedStrings = [];
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'lang_') === 0) {
                $realKey = substr($key, 5);
                $updatedStrings[$realKey] = trim($value);
            }
        }

        if (empty($updatedStrings)) {
            $_SESSION['lang_save_error'] = $this->getText('admin_sprachebearbeiten_error_no_changes', '❌ Keine Änderungen zum Speichern gefunden.');
            header("Location: ./?AdminSpracheBearbeiten&file_type=" . urlencode($fileType) . "&lang_folder=" . urlencode($langFolder) . "&category=" . urlencode($selectedCategory) . "&xml_file=" . urlencode($selectedFile));
            exit;
        }

        // ============================================================
        // DOMDocument verwenden für bessere CDATA-Kontrolle
        // ============================================================
        libxml_use_internal_errors(true);
        
        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;
        $dom->load($xmlPath);
        
        // Alle string-Elemente durchgehen
        $strings = $dom->getElementsByTagName('string');
        $changed = 0;
        
        foreach ($strings as $stringElement) {
            $key = $stringElement->getAttribute('key');
            if (isset($updatedStrings[$key])) {
                $value = $updatedStrings[$key];
                
                // Prüfen ob CDATA benötigt wird
                $needsCdata = $this->needsCdata($value);
                
                // Alten Inhalt löschen
                while ($stringElement->hasChildNodes()) {
                    $stringElement->removeChild($stringElement->firstChild);
                }
                
                if ($needsCdata) {
                    // CDATA-Sektion erstellen
                    $cdata = $dom->createCDATASection($value);
                    $stringElement->appendChild($cdata);
                } else {
                    // Normaler Text
                    $text = $dom->createTextNode($value);
                    $stringElement->appendChild($text);
                }
                $changed++;
            }
        }

        // Backup erstellen
        $backupDir = dirname($xmlPath) . '/old/';
        if (!is_dir($backupDir) && !mkdir($backupDir, 0755, true) && !is_dir($backupDir)) {
            $_SESSION['lang_save_error'] = $this->getText('admin_sprachebearbeiten_error_backup_dir', '📁 Backup-Ordner konnte nicht erstellt werden.');
            header("Location: ./?AdminSpracheBearbeiten&file_type=" . urlencode($fileType) . "&lang_folder=" . urlencode($langFolder) . "&category=" . urlencode($selectedCategory) . "&xml_file=" . urlencode($selectedFile));
            exit;
        }

        $backupFile = basename($xmlPath) . '.bak.' . date('Ymd_His');
        if (!copy($xmlPath, $backupDir . $backupFile)) {
            $_SESSION['lang_save_error'] = $this->getText('admin_sprachebearbeiten_error_backup_failed', '💾 Backup konnte nicht erstellt werden!');
            header("Location: ./?AdminSpracheBearbeiten&file_type=" . urlencode($fileType) . "&lang_folder=" . urlencode($langFolder) . "&category=" . urlencode($selectedCategory) . "&xml_file=" . urlencode($selectedFile));
            exit;
        }

        // Speichern
        if ($dom->save($xmlPath) === false) {
            $_SESSION['lang_save_error'] = $this->getText('admin_sprachebearbeiten_error_save_failed', '❌ Speichern fehlgeschlagen.');
            header("Location: ./?AdminSpracheBearbeiten&file_type=" . urlencode($fileType) . "&lang_folder=" . urlencode($langFolder) . "&category=" . urlencode($selectedCategory) . "&xml_file=" . urlencode($selectedFile));
            exit;
        }

        // Erfolg
        $successMsg = str_replace('{count}', (string)$changed, $this->getText('admin_sprachebearbeiten_success', '✅ {count} Einträge wurden erfolgreich aktualisiert!'));
        $successMsg = str_replace('{file}', basename($xmlPath), $successMsg);
        $_SESSION['lang_save_success'] = $successMsg;
        
        header("Location: ./?AdminSpracheBearbeiten&file_type=" . urlencode($fileType) . 
               "&lang_folder=" . urlencode($langFolder) . 
               "&category=" . urlencode($selectedCategory) .
               "&xml_file=" . urlencode($selectedFile));
        exit;
    }

    /**
     * Prüft ob der Inhalt CDATA benötigt
     */
    private function needsCdata(string $value): bool
    {
        // Enthält HTML-Tags?
        if (preg_match('/<[^>]+>/', $value)) {
            return true;
        }
        
        // Enthält & (Sonderzeichen)
        if (strpos($value, '&') !== false) {
            return true;
        }
        
        // Enthält mehrzeiligen Text
        if (strpos($value, "\n") !== false) {
            return true;
        }
        
        // Enthält Anführungszeichen die Probleme machen könnten
        if (strpos($value, '"') !== false || strpos($value, "'") !== false) {
            return true;
        }
        
        return false;
    }

    private function countEntriesInCategory(array $subCats): int
    {
        $count = 0;
        foreach ($subCats as $strings) {
            $count += count($strings);
        }
        return $count;
    }

    private function getLangCode(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
            'Französisch' => 'fr',
            'Spanisch' => 'es',
            'Italienisch' => 'it',
            'Niederländisch' => 'nl',
            'Russisch' => 'ru',
            'Türkisch' => 'tr',
            'Arabisch' => 'ar',
            'Chinesisch' => 'zh',
            'Japanisch' => 'ja',
        ];
        return $map[$folder] ?? 'de';
    }

    private function getLanguageFolders(string $basePath): array
    {
        $folders = [];
        if (!is_dir($basePath)) return $folders;

        $handle = opendir($basePath);
        while (($item = readdir($handle)) !== false) {
            if ($item === '.' || $item === '..') continue;
            $fullPath = $basePath . '/' . $item;
            if (!is_dir($fullPath)) continue;
            
            $files = glob($fullPath . '/lang_*.xml');
            if (!empty($files)) {
                $folders[] = $item;
            }
        }
        closedir($handle);
        sort($folders);
        return $folders;
    }

    private function handleDeleteBackups(string $xmlPath): void
    {
        $token = $_POST['csrf'] ?? '';
        if (!hash_equals($this->csrfToken, $token)) {
            $this->fail($this->getText('admin_sprachebearbeiten_error_csrf', '🔒 CSRF Fehler'));
        }
        $this->deleteBackups($xmlPath);
        header("Location: ./?AdminSpracheBearbeiten&file_type=" . urlencode($_GET['file_type'] ?? 'chat') . "&lang_folder=" . urlencode($this->langFolder));
        exit;
    }

    private function deleteBackups(string $xmlPath): void
    {
        $backupDir = dirname($xmlPath) . '/old/';
        if (!is_dir($backupDir)) return;

        $baseName = basename($xmlPath);
        $files = glob($backupDir . $baseName . '.bak.*');
        if ($files === false) return;

        usort($files, fn($a, $b) => filemtime($b) <=> filemtime($a));
        $toDelete = array_slice($files, 3);

        foreach ($toDelete as $file) {
            if (is_file($file) && !unlink($file)) {
                error_log("AdminSpracheBearbeiten: Konnte Backup nicht löschen: " . $file);
            }
        }
    }

    private function countBackups(string $xmlPath): int
    {
        $backupDir = dirname($xmlPath) . '/old/';
        $baseName = basename($xmlPath);
        $files = is_dir($backupDir) ? glob($backupDir . $baseName . '.bak.*') : [];
        return $files !== false ? count($files) : 0;
    }

    private function fail(string $msg): void
    {
        http_response_code(400);
        $title = $this->getText('admin_sprachebearbeiten_error_title', '❌ Fehler');
        $backText = $this->getText('admin_sprachebearbeiten_error_back', '⬅️ Zurück');
        echo '<!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"><title>Fehler</title>
        <style>
            body { font-family: Arial, sans-serif; background: #f5f5f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .error-box { background: #fff; padding: 40px; border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); max-width: 600px; text-align: center; border-left: 5px solid #e53935; }
            .error-box h2 { color: #e53935; margin-top: 0; }
            .error-box p { color: #333; }
            .back-link { display: inline-block; margin-top: 20px; padding: 10px 25px; background: #1a73e8; color: #fff; text-decoration: none; border-radius: 5px; }
            .back-link:hover { background: #1557b0; }
        </style>
        </head>
        <body>
            <div class="error-box">
                <h2>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h2>
                <p>' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</p>
                <a href="./?AdminSpracheBearbeiten" class="back-link">' . htmlspecialchars($backText, ENT_QUOTES, 'UTF-8') . '</a>
            </div>
        </body>
        </html>';
        exit;
    }
}