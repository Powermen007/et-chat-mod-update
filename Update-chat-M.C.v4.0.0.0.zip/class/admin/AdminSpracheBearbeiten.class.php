<?php
declare(strict_types=1);

class AdminSpracheBearbeiten extends DbConectionMaker
{
    private string $csrfToken = '';
    private string $langFolder = 'Deutsch';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        $userRole = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        if ($userRole !== "admin") {
            $this->fail($lang->get('admin_sprachebearbeiten_error_access') ?? "🔒 Zugriff verweigert.");
        }

        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        $this->langFolder = $_SESSION['etchat_' . $this->_prefix . 'lang_xml_file'] ?? 'Deutsch';

        $this->showEditor($lang);
    }

    private function showEditor($lang): void
    {
        $langBase = __DIR__ . '/../../lang/';
        $langFolder = $this->langFolder;
        
        $fileType = $_GET['file_type'] ?? 'chat';
        $langCode = $this->getLangCode($langFolder);
        
        if ($fileType === 'admin') {
            $xmlFile = 'lang_admin_' . $langCode . '_v2.xml';
        } else {
            $xmlFile = 'lang_' . $langCode . '_v2.xml';
        }
        
        $xmlPath = $langBase . $langFolder . '/' . $xmlFile;

        if (!file_exists($xmlPath)) {
            $this->fail("📄 XML-Datei nicht gefunden: " . htmlspecialchars($xmlPath));
        }

        // XML-Inhalt laden
        $xmlContent = file_get_contents($xmlPath);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_backups'])) {
            $this->handleDeleteBackups($xmlPath, $lang);
        }

        $backupCount = $this->countBackups($xmlPath);
        $languageFolders = $this->getLanguageFolders($langBase);

        $this->dbObj->close();

        $csrfToken = $this->csrfToken;
        $langFile = basename($xmlPath);
        $fileType = $fileType;
        $langFolder = $langFolder;
        $languageFolders = $languageFolders;
        $xmlContent = $xmlContent;
        
        include "styles/admin_tpl/indexSpracheBearbeiten.tpl.html";
    }

    private function getLangCode(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
        ];
        return $map[$folder] ?? 'de';
    }

    private function getLanguageFolders(string $basePath): array
    {
        $folders = [];
        if (!is_dir($basePath)) return $folders;

        $handle = opendir($basePath);
        while (($item = readdir($handle)) !== false) {
            if ($item === '.' || $item === '..') continue;
            $fullPath = $basePath . '/' . $item;
            if (!is_dir($fullPath)) continue;
            
            $langCode = $this->getLangCode($item);
            $chatFile = $fullPath . '/lang_' . $langCode . '_v2.xml';
            $adminFile = $fullPath . '/lang_admin_' . $langCode . '_v2.xml';
            
            if (file_exists($chatFile) && file_exists($adminFile)) {
                $folders[] = $item;
            }
        }
        closedir($handle);
        sort($folders);
        return $folders;
    }

    private function handleDeleteBackups(string $xmlPath, $lang): void
    {
        $token = $_POST['csrf'] ?? '';
        if (!hash_equals($this->csrfToken, $token)) {
            $this->fail($lang->get('admin_sprachebearbeiten_error_csrf') ?? "🔒 CSRF Fehler");
        }
        $this->deleteBackups($xmlPath);
        header("Location: ./?AdminSpracheBearbeiten");
        exit;
    }

    private function deleteBackups(string $xmlPath): void
    {
        $backupDir = dirname($xmlPath) . '/old/';
        if (!is_dir($backupDir)) return;

        $baseName = basename($xmlPath);
        $files = glob($backupDir . $baseName . '.bak.*');
        if ($files === false) return;

        usort($files, fn($a, $b) => filemtime($b) <=> filemtime($a));
        $toDelete = array_slice($files, 3);

        foreach ($toDelete as $file) {
            if (is_file($file) && !unlink($file)) {
                error_log("AdminSpracheBearbeiten: Konnte Backup nicht löschen: " . $file);
            }
        }
    }

    private function countBackups(string $xmlPath): int
    {
        $backupDir = dirname($xmlPath) . '/old/';
        $baseName = basename($xmlPath);
        $files = is_dir($backupDir) ? glob($backupDir . $baseName . '.bak.*') : [];
        return $files !== false ? count($files) : 0;
    }

    private function fail(string $msg): void
    {
        http_response_code(400);
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px;">❌ ' . htmlspecialchars($msg) . '</div>';
        exit;
    }
}