<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class MenuIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        $feld = $this->dbObj->sqlGet(
            "SELECT id, menu, link_text, image_active, image, url, target, gewicht
             FROM {$this->_prefix}etchat_menu
             WHERE menu = 2
             ORDER BY gewicht"
        );

        if (!empty($feld)) {
            foreach ($feld as $datasets) {
                // Original-Logik: Kein Escaping! 1:1 Ausgabe aus der DB
                $url    = $datasets['url'] ?? '#';
                $target = $datasets['target'] ?? '_blank';
                $text   = $datasets['link_text'] ?? '';
                $img    = $datasets['image'] ?? '';
                
                // HTML-Attribut für ID (nur für den Text, sicher)
                $attr_html = !empty($text) ? "id=\"{$text}\"" : '';

                if (($datasets['image_active'] ?? 0) == 1 && !empty($img)) {
                    // Bild-Link
                    echo "<a class=\"start_text\" {$attr_html} href=\"{$url}\" target=\"{$target}\">"
                       . "<img height=\"55\" alt=\"{$text}\" title=\"{$text}\" src=\"img/menu/{$img}\" />"
                       . "</a>&nbsp;&nbsp;&nbsp;";
                } else {
                    // Text-Link
                    echo "<a class=\"start_text\" {$attr_html} href=\"{$url}\" target=\"{$target}\">{$text}</a>&nbsp;&nbsp;&nbsp;";
                }
            }
        }

        $this->dbObj->close();
    }
}

new MenuIndex();