<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Blacklist extends EtChatConfig
{
    private $dbObj;
    public $user_param_all;
    public $user_bann_time = 0;

    public function __construct($dbObj)
    {
        parent::__construct();

        $this->dbObj = $dbObj;

        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $host = gethostbyaddr($ip) ?: $ip;

        $this->user_param_all = $ip . '@' . $host;
    }

    public function userInBlacklist(): bool
    {
        $now = time();

        $cookie_ip = $_COOKIE['cookie_etchat_blacklist_ip'] ?? '';
        $cookie_time = (int)($_COOKIE['cookie_etchat_blacklist_until'] ?? 0);

        $blacklist_c = false;

        if ($cookie_ip !== '' && $cookie_time > $now) {
            $blacklist_c = $this->dbObj->sqlGet(
                "SELECT etchat_blacklist_time
                 FROM {$this->_prefix}etchat_blacklist
                 WHERE etchat_blacklist_ip = :ip
                 AND etchat_blacklist_time = :time
                 AND etchat_blacklist_time > :now",
                [
                    ':ip' => $cookie_ip,
                    ':time' => $cookie_time,
                    ':now' => $now
                ]
            );
        }

        $user_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $user_host = gethostbyaddr($user_ip) ?: '';
        $user_combined = $user_ip . '@' . $user_host;

        $blacklist = $this->dbObj->sqlGet(
            "SELECT etchat_blacklist_time
             FROM {$this->_prefix}etchat_blacklist
             WHERE (:ip LIKE CONCAT(etchat_blacklist_ip, '%')
                OR :combined LIKE CONCAT(etchat_blacklist_ip, '%'))
             AND etchat_blacklist_time > :now",
            [
                ':ip' => $user_ip,
                ':combined' => $user_combined,
                ':now' => $now
            ]
        );

        // 🔄 ASSOZIATIVE INDIZES
        if ($blacklist && isset($blacklist[0]['etchat_blacklist_time'])) {
            $this->user_bann_time = (int)$blacklist[0]['etchat_blacklist_time'];
            return true;
        }

        if ($blacklist_c && isset($blacklist_c[0]['etchat_blacklist_time'])) {
            $this->user_bann_time = (int)$blacklist_c[0]['etchat_blacklist_time'];
            return true;
        }

        return false;
    }

    public function allowedToAndSetCookie(): bool
    {
        $user_id = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);

        if ($user_id <= 0) {
            return false;
        }

        // 🔄 ASSOZIATIVER INDEX
        $role_result = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :user_id",
            [':user_id' => $user_id]
        );

        $role = $role_result[0]['etchat_userprivilegien'] ?? null;

        $excludedRoles = ["admin", "mod", "chatwache", "co_admin"];

        if (!in_array($role, $excludedRoles, true)) {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_useronline
                 WHERE etchat_onlineuser_fid = :user_id",
                [':user_id' => $user_id]
            );

            setcookie("cookie_etchat_blacklist_until", $this->user_bann_time, [
                "expires"  => $this->user_bann_time,
                "path"     => "/",
                "samesite" => "Lax",
                "httponly" => true
            ]);

            setcookie("cookie_etchat_blacklist_ip", $this->user_param_all, [
                "expires"  => $this->user_bann_time,
                "path"     => "/",
                "samesite" => "Lax",
                "httponly" => true
            ]);

            return true;
        }

        return false;
    }

    public function insertUser(int $userID, int $time): bool
    {
        // 🔄 ASSOZIATIVER INDEX
        $role_result = $this->dbObj->sqlGet(
            "SELECT etchat_userprivilegien
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = :user_id",
            [':user_id' => $userID]
        );

        $role = $role_result[0]['etchat_userprivilegien'] ?? null;

        $excludedRoles = ["admin", "mod", "chatwache", "co_admin"];

        if (in_array($role, $excludedRoles, true)) {
            return false;
        }

        // 🔄 ASSOZIATIVER INDEX
        $ip = $this->dbObj->sqlGet(
            "SELECT etchat_onlineip
             FROM {$this->_prefix}etchat_useronline
             WHERE etchat_onlineuser_fid = :user_id",
            [':user_id' => $userID]
        );

        if (!$ip || !isset($ip[0]['etchat_onlineip'])) {
            return false;
        }

        $time_to_hold = time() + $time;

        $this->dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_blacklist
             (etchat_blacklist_ip, etchat_blacklist_userid, etchat_blacklist_time)
             VALUES (:ip, :user_id, :time_to_hold)",
            [
                ':ip' => $ip[0]['etchat_onlineip'],
                ':user_id' => $userID,
                ':time_to_hold' => $time_to_hold
            ]
        );

        return true;
    }

    public function killUserSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_unset();
            session_destroy();
        }
    }
}