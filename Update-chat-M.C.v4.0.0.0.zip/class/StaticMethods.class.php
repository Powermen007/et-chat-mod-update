<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class StaticMethods
{
    private static function getText(string $key, string $default = ''): string
    {
        static $lang = null;
        
        if ($lang === null) {
            try {
                // ===== MODERNE SPRACHE LADEN (dynamisch) =====
                $lang = new LangXml("./lang/");
            } catch (Throwable $e) {
                $lang = null;
            }
        }
        
        if ($lang !== null) {
            return $lang->get($key, $default);
        }
        return $default;
    }

    private static function replacePlaceholders(string $text, array $placeholders): string
    {
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', $value, $text);
        }
        return $text;
    }

    public static function filtering($str, $sml, $_prefix)
    {
        $count_all = 0;

        // Steuerzeichen entfernen
        $str = preg_replace('/[\x00-\x1F]/', '', $str);

        // Smilies ersetzen
        foreach ($sml as $smiley) {
            // 🔄 KOMPATIBEL: Sowohl numerisch als auch assoziativ
            $sign = $smiley['etchat_smileys_sign'] ?? $smiley[0] ?? '';
            $imgPath = $smiley['etchat_smileys_img'] ?? $smiley[1] ?? '';
            
            $path = "./" . $imgPath;
            if ($sign !== '' && $imgPath !== '' && is_file($path) && ($img = getimagesize($path))) {
                $str = str_replace(
                    $sign,
                    "<img class=\"img_smiley\" src=\"{$imgPath}\" {$img[3]} id=\"smilchat_{$sign}\" style=\"cursor:pointer\">",
                    $str,
                    $count
                );
                if ($count > 0) {
                    $count_all += $count;
                }
            }
        }

        $max_smilies = (int)($_SESSION['etchat_' . $_prefix . 'chat_anzsmily'] ?? 6);
        if ($count_all > $max_smilies) {
            // ===== MODERNISIERT: Smiley-Limit aus XML =====
            $template = self::getText('static_max_smilies', 'Max {max} Smilies erlaubt!');
            return self::replacePlaceholders($template, ['max' => $max_smilies]);
        }

        // Externe Links erkennen
        if (stripos($str, ']http://') === false && stripos($str, ']https://') === false) {
            // ===== MODERNISIERT: Externer Link aus XML =====
            $externalLinkText = self::getText('static_external_link', 'Externer Link');
            $str = preg_replace(
                "/([\w]+:\/\/[\w\-?&;#~=\.\/\@]+[\w\/])/i",
                "<a target=\"_blank\" href=\"?Weiterleitung&url=$1\">" . $externalLinkText . "</a>",
                $str
            );
        }

        // ===== MODERNISIERT: Bild-Tooltip aus XML =====
        $imageTitle = self::getText('static_image_click_title', 'Klicken, um das Bild zu vergrößern.');

        // [pvi] Bilder
        $str = preg_replace(
            '/\[pvi\](.*?)\[\/pvi\]/',
            "&nbsp;&nbsp;<a href=\"$1\" target=\"_blank\"><img class=\"img_chat\" src=\"$1\" alt=\"Bild gepostet\" title=\"" . $imageTitle . "\"/></a>",
            $str
        );

        // Bad Words laden
        if (!isset($_SESSION['etchat_' . $_prefix . '_badwords']) && file_exists("./cache/bad_words.xml")) {
            $xml = simplexml_load_file("./cache/bad_words.xml", 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOERROR | LIBXML_NOWARNING);
            if ($xml) {
                foreach ($xml->word as $bword) {
                    $exceptions = [];
                    if (isset($bword->except)) {
                        foreach ($bword->except as $except) {
                            $exceptions[] = trim((string)$except);
                        }
                    }
                    $_SESSION['etchat_' . $_prefix . '_badwords'][] = [
                        'in'     => trim((string)$bword['in']),
                        'out'    => trim((string)$bword['out']),
                        'except' => $exceptions
                    ];
                }
            }
        }

        // Bad Words anwenden
        if (isset($_SESSION['etchat_' . $_prefix . '_badwords'])) {
            foreach ($_SESSION['etchat_' . $_prefix . '_badwords'] as $bword) {
                if (!empty($bword['except'])) {
                    foreach ($bword['except'] as $ex) {
                        $str = str_replace($ex, "<norepl>{$ex}</norepl>", $str);
                    }
                }
            }

            foreach ($_SESSION['etchat_' . $_prefix . '_badwords'] as $bword) {
                $pattern = '/(?<!\<norepl\>)' . preg_quote($bword['in'], '/') . '(?!\<\/norepl\>)/ui';
                $str = preg_replace($pattern, $bword['out'], $str);
            }

            $str = str_ireplace(["<norepl>", "</norepl>"], "", $str);
        }

        // Video Embed (nur [video] BBCode)
        if (substr($str, 0, 8) !== "/window:") {

            // [img] BBCode
            if (stripos($str, '[img]') !== false && stripos($str, '[/img]') !== false && stripos($str, '?admin') === false) {
                $str = preg_replace(
                    '#\[img\](.*?)\[/img\]#i',
                    '<a href="$1" target="_blank"><img class="img_chat" src="$1" alt="Bild gepostet" title="' . $imageTitle . '"/></a>',
                    $str
                );
            }

            // [video] BBCode mit YouTube, Dailymotion, Twitch VOD, TikTok
            $str = preg_replace_callback('/\[video\](.*?)\[\/video\]/i', function($matches){
                $url = trim($matches[1]);
                $embed = $url;

                // YouTube
                if (preg_match('~(?:https?://)?(?:www\.)?(?:youtube\.com/watch\?v=|youtu\.be/)([\w-]+)~i', $url, $m)) {
                    $embed = 'https://www.youtube.com/embed/' . $m[1];
                }
                // Dailymotion
                elseif (preg_match('~(?:https?://)?(?:www\.)?dailymotion\.com/video/([\w-]+)~i', $url, $m)) {
                    $embed = 'https://www.dailymotion.com/embed/video/' . $m[1];
                }
                // Twitch VOD
                elseif (preg_match('~(?:https?://)?(?:www\.)?twitch\.tv/videos/(\d+)~i', $url, $m)) {
                    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                    $embed = 'https://player.twitch.tv/?video=' . $m[1] . '&parent=' . $host;
                }
                // TikTok
                elseif (preg_match('~(?:https?://)?(?:www\.)?tiktok\.com/.+/video/(\d+)~i', $url, $m)) {
                    $embed = 'https://www.tiktok.com/embed/' . $m[1];
                }

                return '<iframe width="425" height="344" src="' . $embed . '" frameborder="0" allowfullscreen></iframe>';
            }, $str);
        }

        return $str;
    }
}