<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Filesend extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function errorExit(string $key, string $default = ''): void
    {
        echo $this->getText($key, $default);
        exit;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Content-Type: text/html; charset=utf-8');

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            $this->errorExit('filesend_no_upload', 'Kein Upload erkannt.');
        }

        if ($_FILES['file']['size'] > 10 * 1024 * 1024) {
            $this->errorExit('filesend_too_large', 'Datei zu groß. Maximal 10MB erlaubt.');
        }

        if (!is_uploaded_file($_FILES['file']['tmp_name'])) {
            $this->errorExit('filesend_invalid_upload', 'Ungültiger Upload.');
        }

        $filedir = dirname(__DIR__) . '/userpic/';

        if (!is_dir($filedir)) {
            mkdir($filedir, 0755, true);
        }

        // MIME prüfen – mit Fallback falls finfo nicht verfügbar
        $mime = $this->getMimeType($_FILES['file']['tmp_name']);

        $allowedMime = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/gif'  => 'gif',
            'image/webp' => 'webp'
        ];

        if (!isset($allowedMime[$mime])) {
            $this->errorExit('filesend_type_not_allowed', 'Dateityp nicht erlaubt. Erlaubt: JPEG, PNG, GIF, WebP');
        }

        // extra Bildprüfung
        $imageInfo = @getimagesize($_FILES['file']['tmp_name']);
        if ($imageInfo === false) {
            $this->errorExit('filesend_invalid_image', 'Ungültiges Bild.');
        }

        $extension = $allowedMime[$mime];

        $newname = bin2hex(random_bytes(8)) . '_' . time() . '.' . $extension;

        $targetPath = $filedir . $newname;

        if (!move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
            $this->errorExit('filesend_upload_failed', 'Upload fehlgeschlagen.');
        }

        // GIF Limit
        if ($mime === 'image/gif' && filesize($targetPath) > 1500000) {
            unlink($targetPath);
            $this->errorExit('filesend_gif_too_large', 'GIF zu groß. Maximal 1.5MB erlaubt.');
        }

        // Bilder optimieren (nur JPEG und PNG)
        if ($mime === 'image/jpeg' || $mime === 'image/png') {
            $this->resizeImageIfTooLarge($targetPath);
            $this->compressImageToTargetSize($targetPath);
        }

        // WebP optimieren (optional)
        if ($mime === 'image/webp') {
            $this->optimizeWebP($targetPath);
        }

        $username = $_SESSION['etchat_' . $this->_prefix . 'username'] ?? 'Unbekannt';
        $datum = date('d.m.Y H:i');

        file_put_contents(
            $targetPath . '.txt',
            $username . '|' . $datum . '|' . ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0')
        );

        $baseUrl = rtrim(dirname($_SERVER['PHP_SELF']), '/\\') . '/userpic/';
        $imgurl = $baseUrl . $newname;

        $messageText = '';

        if (!empty($_POST['bildtext'])) {
            $messageText = htmlspecialchars($_POST['bildtext'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . ' ';
        }

        $messageText .= '[img]' . $imgurl . '[/img]';

        // CSS sicher filtern
        $textcolor = substr($_POST['textcolor'] ?? '', 0, 7);
        $textbold  = substr($_POST['textbold'] ?? '', 0, 6);
        $textitalic = substr($_POST['textitalic'] ?? '', 0, 6);

        $fontstyle = "color:$textcolor;font-weight:$textbold;font-style:$textitalic;";

        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        $roomId = (int)($_POST['raum'] ?? 0);
        $privat = (int)($_POST['privat'] ?? 0);
        $ip     = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        // ✅ Prepared Statement
        $this->dbObj->sqlSet("
            INSERT INTO {$this->_prefix}etchat_messages
            (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp,
             etchat_fid_room, etchat_privat, etchat_user_ip)
            VALUES (?, ?, ?, ?, ?, ?, ?)",
            [$userId, $messageText, $fontstyle, time(), $roomId, $privat, $ip]
        );

        $this->cleanupOldFiles($filedir);
        
        echo $this->getText('filesend_success', 'Erfolg') . "|" . $imgurl;
    }

    // 🔄 NEU: MIME-Typ mit Fallback
    private function getMimeType(string $filePath): string
    {
        if (class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            return $finfo->file($filePath);
        }
        
        // Fallback: exif_imagetype oder getimagesize
        $imageInfo = @getimagesize($filePath);
        if ($imageInfo !== false) {
            return $imageInfo['mime'];
        }
        
        return 'application/octet-stream';
    }

    // 🔄 NEU: WebP Optimierung
    private function optimizeWebP(string $sourcePath, int $quality = 80): void
    {
        if (!function_exists('imagecreatefromwebp')) {
            return; // WebP nicht unterstützt
        }
        
        $image = @imagecreatefromwebp($sourcePath);
        if (!$image) return;
        
        imagewebp($image, $sourcePath, $quality);
        imagedestroy($image);
    }

    private function cleanupOldFiles(string $dir): void
    {
        $maxAge = 7 * 24 * 3600;
        $now = time();

        foreach (glob($dir . '*.{jpg,jpeg,png,gif,webp,txt}', GLOB_BRACE) as $file) {
            if (is_file($file) && ($now - filemtime($file) > $maxAge)) {
                @unlink($file);
            }
        }
    }

    private function resizeImageIfTooLarge(string $sourcePath, int $maxWidth = 1600, int $maxHeight = 900): void
    {
        $info = @getimagesize($sourcePath);
        if (!$info) return;

        [$width, $height, $type] = $info;

        if ($width <= $maxWidth && $height <= $maxHeight) return;

        $ratio = min($maxWidth / $width, $maxHeight / $height);

        $newWidth  = (int)($width * $ratio);
        $newHeight = (int)($height * $ratio);

        if ($type === IMAGETYPE_JPEG) {
            $src = @imagecreatefromjpeg($sourcePath);
        } elseif ($type === IMAGETYPE_PNG) {
            $src = @imagecreatefrompng($sourcePath);
        } else {
            return;
        }

        if (!$src) return;

        $dst = imagecreatetruecolor($newWidth, $newHeight);
        
        if ($type === IMAGETYPE_PNG) {
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
            imagefill($dst, 0, 0, $transparent);
        }

        imagecopyresampled($dst, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        if ($type === IMAGETYPE_JPEG) {
            imagejpeg($dst, $sourcePath, 85);
        } else {
            imagepng($dst, $sourcePath, 6);
        }

        imagedestroy($src);
        imagedestroy($dst);
    }

    private function compressImageToTargetSize(string $sourcePath, int $maxSizeBytes = 1500000): void
    {
        $info = @getimagesize($sourcePath);
        if (!$info || $info['mime'] !== 'image/jpeg') return;

        $image = @imagecreatefromjpeg($sourcePath);
        if (!$image) return;

        $quality = 85;

        do {
            ob_start();
            imagejpeg($image, null, $quality);
            $data = ob_get_clean();
            $size = strlen($data);
            $quality -= 5;
        } while ($size > $maxSizeBytes && $quality >= 40);

        if ($size <= $maxSizeBytes) {
            file_put_contents($sourcePath, $data);
        }

        imagedestroy($image);
    }
}