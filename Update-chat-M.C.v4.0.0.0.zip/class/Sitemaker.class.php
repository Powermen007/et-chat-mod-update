<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Sitemaker
{
    private string $print_site_count = '';
    private int $anzahl_der_messages_pro_seite;
    private int $counted;
    public bool $href = false;

    public function __construct(int $anz, int $count)
    {
        $this->anzahl_der_messages_pro_seite = $anz;
        $this->counted = $count;
    }

    public function make(
        int $seite,
        string $tpl,
        string $site_text = "Seite",
        string $of_text = "von",
        string $minus_stop = "&lt;&lt;&lt;",
        string $minus = "&lt;&lt;&lt;",
        string $plus = "&gt;&gt;&gt;",
        string $plus_stop = "&gt;&gt;&gt;"
    ): void {

        $anzahl_der_seiten_ermittelt = (int)(($this->counted / $this->anzahl_der_messages_pro_seite) + 0.99999999999999);

        if ($seite < 1) {
            $seite = 1;
        }

        if ($seite > $anzahl_der_seiten_ermittelt) {
            $seite = $anzahl_der_seiten_ermittelt;
        }

        if ($this->href) {
            $href_inc_minus = str_replace('#site#', ($seite - 1), $tpl);
            $href_inc_plus   = str_replace('#site#', ($seite + 1), $tpl);
        } else {
            $href_inc_minus = "#";
            $href_inc_plus   = "#";
        }

        if ($seite == 1) {
            $this->print_site_count = $minus_stop . "&nbsp;&nbsp;";
        } else {
            $id = str_replace('#site#', ($seite - 1), $tpl);

            $this->print_site_count = "<a class=\"sitemaker\" href=\"{$href_inc_minus}\" id=\"{$id}\" title=\"Site -\">"
                                   . $minus
                                   . "</a>&nbsp;&nbsp;";
        }

        $this->print_site_count .= $site_text . "\n<form action=\"\" style=\"display:inline;\">";
        $this->print_site_count .= "\n<div style=\"display:inline;\"><select id=\"site_selecter\" class=\"sitemaker_select\">\n";

        for ($i = 1; $i <= $anzahl_der_seiten_ermittelt; $i++) {
            $selected = ($seite == $i) ? ' selected="selected"' : '';
            $this->print_site_count .= "<option value=\"{$i}\"{$selected}>{$i}</option>\n";
        }

        $this->print_site_count .= "</select></div></form>";
        $this->print_site_count .= "&nbsp;{$of_text}&nbsp;{$anzahl_der_seiten_ermittelt}&nbsp;&nbsp;";

        if (($this->counted / $this->anzahl_der_messages_pro_seite) <= $seite) {
            $this->print_site_count .= $plus;
        } else {
            $id = str_replace('#site#', ($seite + 1), $tpl);

            $this->print_site_count .= "<a class=\"sitemaker\" href=\"{$href_inc_plus}\" id=\"{$id}\" title=\"Site +\">"
                                     . $plus_stop
                                     . "</a>";
        }
    }

    public function show(): void
    {
        echo $this->print_site_count;
    }

    public function get(): string
    {
        return $this->print_site_count;
    }
}