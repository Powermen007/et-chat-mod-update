<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class EditProfil extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function replacePlaceholders(string $text, array $placeholders): string
    {
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', $value, $text);
        }
        return $text;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);

        if ($userId === 0) {
            echo $this->getText('profil_not_logged_in', 'Sie sind nicht angemeldet im Chat.');
            exit;
        }

        /* ---------------------------------
           Bild löschen
        --------------------------------- */

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteUserImage'])) {

            $usernameResult = $this->dbObj->sqlGet(
                "SELECT etchat_username
                 FROM {$this->_prefix}etchat_user
                 WHERE etchat_user_id = ?
                 LIMIT 1",
                [$userId]
            );

            if ($usernameResult === false || empty($usernameResult[0]['etchat_username'])) {
                echo $this->getText('profil_user_not_found', 'Benutzer nicht gefunden.');
                exit;
            }

            $username = trim($usernameResult[0]['etchat_username']);

            $uploadDir = realpath('./userpic/');
            $imageName = basename(trim($_POST['deleteUserImage']));

            if ($uploadDir && $imageName) {

                $imagePath = $uploadDir . DIRECTORY_SEPARATOR . $imageName;
                $metaPath  = $imagePath . '.txt';

                if (is_file($metaPath)) {

                    $meta = @file_get_contents($metaPath);

                    if ($meta !== false) {

                        $parts = explode('|', $meta);

                        $uploader = trim($parts[0] ?? '');

                        if ($uploader === $username) {

                            if (is_file($imagePath)) {
                                unlink($imagePath);
                            }

                            unlink($metaPath);
                        }
                    }
                }
            }

            header("Location: ./?EditProfil");
            exit;
        }

        /* ---------------------------------
           Profil speichern
        --------------------------------- */

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['deleteUserImage'])) {

            $tag   = (int)($_POST['geb_tag'] ?? 0);
            $monat = (int)($_POST['geb_monat'] ?? 0);
            $jahr  = (int)($_POST['geb_jahr'] ?? 0);

            $ort = trim($_POST['ort'] ?? '');
            $beschreibung = trim($_POST['beschreibung'] ?? '');

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_user
                 SET etchat_geb_tag = ?,
                     etchat_geb_monat = ?,
                     etchat_geb_jahr = ?,
                     etchat_ort = ?,
                     etchat_beschreibung = ?
                 WHERE etchat_user_id = ?",
                [
                    $tag,
                    $monat,
                    $jahr,
                    $ort,
                    $beschreibung,
                    $userId
                ]
            );
        }

        /* ---------------------------------
           Benutzerdaten laden
        --------------------------------- */

        $feld = $this->dbObj->sqlGet(
            "SELECT
                etchat_username,
                etchat_userprivilegien,
                etchat_reg_timestamp,
                etchat_usersex,
                etchat_avatar,
                etchat_geb_tag,
                etchat_geb_monat,
                etchat_geb_jahr,
                etchat_ort,
                etchat_beschreibung
            FROM {$this->_prefix}etchat_user
            WHERE etchat_user_id = ?
            LIMIT 1",
            [$userId]
        );

        if ($feld === false || empty($feld[0])) {
            echo $this->getText('profil_data_not_loaded', 'Benutzerdaten konnten nicht geladen werden.');
            exit;
        }

        /* ---------------------------------
           Alter berechnen
        --------------------------------- */

        $gebTag   = (int)($feld[0]['etchat_geb_tag'] ?? 0);
        $gebMonat = (int)($feld[0]['etchat_geb_monat'] ?? 0);
        $gebJahr  = (int)($feld[0]['etchat_geb_jahr'] ?? 0);

        $alter = null;
        $geburtstagsGruss = '';
        $heute = new DateTime();

        if ($gebTag && $gebMonat) {

            if ($gebJahr > 0 && checkdate($gebMonat, $gebTag, $gebJahr)) {

                $geburtsdatum = new DateTime("$gebJahr-$gebMonat-$gebTag");

                $alter = $heute->diff($geburtsdatum)->y;

                if ((int)$heute->format('j') === $gebTag &&
                    (int)$heute->format('n') === $gebMonat) {

                    $username = htmlspecialchars($feld[0]['etchat_username'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                    
                    // Geburtstagsgruss aus XML mit Platzhaltern
                    $birthdayTemplate = $this->getText('profil_birthday_message', '<b><p style="color:red">{username} hat heute Geburtstag! {age}</p></b>');
                    $ageText = $this->replacePlaceholders(
                        $this->getText('profil_birthday_with_age', 'Und wird {age} Jahre alt.'),
                        ['age' => $alter]
                    );
                    
                    $geburtstagsGruss = $this->replacePlaceholders($birthdayTemplate, [
                        'username' => $username,
                        'age' => $ageText
                    ]);
                }

            } elseif (checkdate($gebMonat, $gebTag, 2000)) {

                if ((int)$heute->format('j') === $gebTag &&
                    (int)$heute->format('n') === $gebMonat) {

                    $username = htmlspecialchars($feld[0]['etchat_username'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                    
                    $birthdayTemplate = $this->getText('profil_birthday_message', '<b><p style="color:red">{username} hat heute Geburtstag! {age}</p></b>');
                    $geburtstagsGruss = $this->replacePlaceholders($birthdayTemplate, [
                        'username' => $username,
                        'age' => ''
                    ]);
                }
            }
        }

        $feld[0]['alter'] = $alter;

        /* ---------------------------------
           Benutzerbilder laden
        --------------------------------- */

        $uploadDir = realpath('./userpic/');
        $userImages = [];

        if ($uploadDir && is_dir($uploadDir)) {

            foreach (glob($uploadDir . '/*.{jpg,jpeg,png,gif}', GLOB_BRACE) as $filePath) {

                $file = basename($filePath);
                $metaFile = $filePath . '.txt';

                if (!is_file($metaFile)) {
                    continue;
                }

                $meta = @file_get_contents($metaFile);

                if ($meta === false) {
                    continue;
                }

                $parts = explode('|', $meta);

                $uploader = trim($parts[0] ?? '');
                $datum    = trim($parts[1] ?? '');

                if ($uploader === trim($feld[0]['etchat_username'] ?? '')) {

                    $userImages[] = [
                        'image' => $file,
                        'datum' => $datum
                    ];
                }
            }

            usort($userImages, function ($a, $b) {
                return strtotime($b['datum']) <=> strtotime($a['datum']);
            });
        }

        $feld[0]['user_images'] = $userImages;

        $avatar_an_aus = $_SESSION['etchat_' . $this->_prefix . 'be_info_pic'] ?? 0;

        $this->dbObj->close();

        $this->initTemplate($feld, $geburtstagsGruss, $avatar_an_aus);
    }

    private function initTemplate($feld, $geburt, $avatar_an_aus)
    {
        $style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'default';

        include_once("styles/$style/editprofil.tpl.html");
    }
}