<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Erg�nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Erg�nzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

require_once __DIR__ . '/LangXml.class.php';

class TabFocus extends DbConectionMaker
{
    private ?LangXml $lang = null;

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ============================================================
        // Sprache laden
        // ============================================================
        try {
            $this->lang = new LangXml("./lang/");
        } catch (Throwable $e) {
            $this->lang = null;
        }

        if (!isset($_SESSION['etchat_' . $this->_prefix . 'user_id'])) {
            exit;
        }

        $userID = (int)$_SESSION['etchat_' . $this->_prefix . 'user_id'];
        $mode   = $_GET['mode'] ?? '';

        // =========================================================
        // MODE AWAY
        // =========================================================
        if ($mode === 'away') {

            // Multi-Tab-Schutz
            $lastActive = $_SESSION['__TABFOCUS_LAST_ACTIVE__'] ?? 0;
            if ($lastActive > time() - 10) {
                return;
            }

            $res = $this->dbObj->sqlGet(
                "SELECT etchat_user_online_user_status_img,
                        etchat_user_online_user_status_text
                 FROM {$this->_prefix}etchat_useronline
                 WHERE etchat_onlineuser_fid = :id
                 LIMIT 1",
                [':id' => $userID]
            );

            $currentImg  = $res[0]['etchat_user_online_user_status_img'] ?? '';
            $currentText = $res[0]['etchat_user_online_user_status_text'] ?? '';

            // Away darf eigenen Status nicht �berschreiben
            if ($currentImg === 'status_tabaway') {
                return;
            }

            // Originalstatus sichern
            $_SESSION['__TABFOCUS__'] = [
                'old_img'  => $currentImg,
                'old_text' => $currentText,
                'ts'       => time()
            ];

            // ============================================================
            // Status auf away setzen - MIT SPRACHE!
            // ============================================================
            $awayText = $this->getText('tabfocus_status_away', 'Abwesend');

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_useronline
                 SET etchat_user_online_user_status_img = 'status_tabaway',
                     etchat_user_online_user_status_text = :away_text
                 WHERE etchat_onlineuser_fid = :id",
                [
                    ':away_text' => $awayText,
                    ':id'        => $userID
                ]
            );
        }

        // =========================================================
        // MODE BACK
        // =========================================================
        if ($mode === 'back' && isset($_SESSION['__TABFOCUS__'])) {

            $_SESSION['__TABFOCUS_LAST_ACTIVE__'] = time();

            $oldImg  = $_SESSION['__TABFOCUS__']['old_img']  ?? '';
            $oldText = $_SESSION['__TABFOCUS__']['old_text'] ?? '';

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_useronline
                 SET etchat_user_online_user_status_img = :img,
                     etchat_user_online_user_status_text = :txt
                 WHERE etchat_onlineuser_fid = :id",
                [
                    ':img' => $oldImg,
                    ':txt' => $oldText,
                    ':id'  => $userID
                ]
            );

            unset($_SESSION['__TABFOCUS__']);
        }
    }

    /**
     * Holt einen Sprachtext mit Fallback
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }
}