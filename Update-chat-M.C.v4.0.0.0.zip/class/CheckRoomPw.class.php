<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class CheckRoomPw extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session starten
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Header setzen
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Content-Type: text/plain; charset=utf-8');
        }

        // POST-Daten validieren
        $roomId = isset($_POST['roomid']) ? (int)$_POST['roomid'] : 0;
        $layerPw = $_POST['layerpw'] ?? '';

        if ($roomId <= 0 || $layerPw === '') {
            echo "wrong";
            $this->dbObj->close();
            exit;
        }

        // Prepared Statement verwenden, um SQL-Injection zu verhindern
        $sql = "SELECT etchat_id_room 
                FROM {$this->_prefix}etchat_rooms 
                WHERE etchat_id_room = :room_id 
                  AND etchat_room_pw = :room_pw";
        
        $freigabe = $this->dbObj->sqlGet($sql, [
            ':room_id' => $roomId,
            ':room_pw' => $layerPw
        ]);

        if (!is_array($freigabe) || empty($freigabe)) {
            echo "wrong";
            $this->dbObj->close();
            exit;
        }

        // 🔄 ASSOZIATIVER INDEX
        $roomIdFromDb = $freigabe[0]['etchat_id_room'] ?? 0;

        if ($roomIdFromDb <= 0) {
            echo "wrong";
            $this->dbObj->close();
            exit;
        }

        // Session speichern (Array initialisieren, falls nicht vorhanden)
        if (!isset($_SESSION['etchat_' . $this->_prefix . 'roompw_array'])) {
            $_SESSION['etchat_' . $this->_prefix . 'roompw_array'] = [];
        }

        $_SESSION['etchat_' . $this->_prefix . 'roompw_array'][] = $roomIdFromDb;

        $this->dbObj->close();
        echo "1";
        exit;
    }
}
?>