<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ReloaderMessages extends DbConectionMaker
{
    private ?object $lang = null;

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['etchat_'.$this->_prefix.'user_id'])) {
            die(json_encode(["error" => "Session user_id nicht gesetzt"]));
        }

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: application/json; charset=utf-8');
		
		// ===== NEU: Wenn keine neuen Nachrichten, NUR Session aktualisieren =====
        $noNewMessages = isset($_POST['no_new_messages']) && $_POST['no_new_messages'] == '1';
        
        if ($noNewMessages) {
            // Nur Session aktualisieren, keine Nachrichten laden
            $this->updateUserSessionOnly();
            return;
        }
        // ===== ENDE NEU =====

        if ($this->checkKicklist()) {
            $this->errorOutput("kick");
            return false;
        }

        $blackListObj = new Blacklist($this->dbObj);

        if ($blackListObj->userInBlacklist()) {
            if ($blackListObj->allowedToAndSetCookie()) {
                $blackListObj->killUserSession();
                $this->errorOutput("blacklist");
                return false;
            }
        }

        $raum_array = $this->getRoomArray();
        if (!is_array($raum_array)) return false;

        $user_id = (int)($_SESSION['etchat_'.$this->_prefix.'user_id'] ?? 0);

        if ($user_id === 0) {
            die(json_encode(["error" => "Ungültige User-ID"]));
        }

        $user_array = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_username, etchat_userprivilegien,
                    etchat_usersex, etchat_avatar
             FROM {$this->_prefix}etchat_user
             WHERE etchat_user_id = ?",
            [$user_id]
        );

        $this->refreshUserSession($user_array, $raum_array, $blackListObj->user_param_all);

        $_POST['privat'] = (int)($_POST['privat'] ?? 0);

        if (isset($_POST['message']) && !empty($_POST['message']) &&
            trim($_POST['message']) !== "/window:" &&
            !empty($_SESSION['etchat_'.$this->_prefix.'user_id'])) {

            $inserterObj = new MessageInserter($this->dbObj, $raum_array);

            if (!empty($inserterObj->status)) {
                $this->errorOutput($inserterObj->status);
                return false;
            }
        }

        $this->makeJsonOutput($this->selectMessagesForTheUser());
    }

    /**
     * Hilfsmethode für Sprachzugriff
     */
    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function makeJsonOutput($feld)
    {
        $ausgabeJSON_Inhalt = [];

        static $sml = null;

        if ($sml === null) {
            $sml = $this->dbObj->sqlGet(
                "SELECT etchat_smileys_sign, etchat_smileys_img FROM {$this->_prefix}etchat_smileys"
            ) ?: [];
        }

        if (!empty($feld) && is_array($feld)) {
            $ausgabeJSON_Anfang = "{\"data\" : [";

            foreach ($feld as $row) {
                // 🔄 ASSOZIATIVE INDIZES
                $user_id = $row['etchat_user_id'] ?? 0;
                $privat_id = $row['etchat_privat'] ?? 0;

                if (!$this->blockiere($user_id, $privat_id)) {

                    $message2send = addslashes(
                        StaticMethods::filtering(stripslashes($row['etchat_text'] ?? ''), $sml, $this->_prefix)
                    );

                    if (substr($message2send, 0, 8) === "/window:" && $privat_id != 0) {
                        $message2send = substr($message2send, 8);
                        $normal_message_counter = "";
                    } else {
                        $_SESSION['etchat_'.$this->_prefix.'count'] ??= 0;
                        $_SESSION['etchat_'.$this->_prefix.'count']++;
                        $normal_message_counter = $_SESSION['etchat_'.$this->_prefix.'count'];
                    }

                    $ausgabeJSON_Inhalt[] = "{\"id\":\"".$normal_message_counter.
                        "\",\"user\":\"".addslashes($row['etchat_username'] ?? '').
                        "\",\"user_id\":\"".addslashes($user_id).
                        "\",\"message\":\"".$message2send.
                        "\",\"time\":\"".date("H:i", $row['etchat_timestamp'] ?? 0).
                        "\",\"privat\":\"".$privat_id.
                        "\",\"css\":\"".($row['etchat_text_css'] ?? '').
                        "\",\"priv\":\"".($row['etchat_userprivilegien'] ?? '').
                        "\",\"sex\":\"".($row['etchat_usersex'] ?? '').
                        "\",\"avatar\":\"".($row['etchat_avatar'] ?? '')."\"}";
                }
            }

            $ausgabeJSON_Ende = "]}";
        }

        $this->dbObj->close();

        if (count($ausgabeJSON_Inhalt) > 0) {
            echo $ausgabeJSON_Anfang . implode(",", $ausgabeJSON_Inhalt) . $ausgabeJSON_Ende;
        } else {
            echo '{"data":[]}';
        }
    }

private function refreshUserSession($user_array, $raum_array, $user_param_all)
{
    // Session-ID holen
    $sessionId = session_id();
    
    $user_id = $_SESSION['etchat_'.$this->_prefix.'user_id'];
    $new_room_id = $raum_array[0]['etchat_id_room'] ?? 0;
    
    // ============================================================
    // NEU: Alte Raum-ID holen und Verlassen-Nachricht schreiben
    // ============================================================
    $old_room_data = $this->dbObj->sqlGet(
        "SELECT etchat_fid_room 
         FROM {$this->_prefix}etchat_useronline
         WHERE etchat_onlineuser_fid = ?",
        [$user_id]
    );
    
    $old_room_id = is_array($old_room_data) && isset($old_room_data[0]['etchat_fid_room']) 
        ? (int)$old_room_data[0]['etchat_fid_room'] 
        : 0;
    
    // Wenn Raumwechsel und alter Raum existiert (und nicht der neue Raum ist)
    if ($old_room_id > 0 && $old_room_id != $new_room_id) {
        
        // Benutzerdaten für die Nachricht
        $username = $user_array[0]['etchat_username'] ?? 'Unbekannt';
        $user_priv = $user_array[0]['etchat_userprivilegien'] ?? 'gast';
        $avatar = $user_array[0]['etchat_avatar'] ?? '';
        
        // Farben aus Session oder Default
        $admin_color = $_SESSION['etchat_'.$this->_prefix.'admin_color'] ?? '#ff0000';
        $mod_color = $_SESSION['etchat_'.$this->_prefix.'mod_color'] ?? '#00aaff';
        $user_color = $_SESSION['etchat_'.$this->_prefix.'user_color'] ?? '#cccccc';
        $gast_color = $_SESSION['etchat_'.$this->_prefix.'gast_color'] ?? '#ffff00';
        
        // Farbe je nach Privileg
        switch ($user_priv) {
            case 'admin':
            case 'grafik':
            case 'chatwache':
            case 'co_admin':
                $user_color2 = "color: " . $admin_color;
                break;
            case 'mod':
                $user_color2 = "color: " . $mod_color;
                break;
            case 'user':
                $user_color2 = "color: " . $user_color;
                break;
            case 'gast':
                $user_color2 = "color: " . $gast_color;
                break;
            default:
                $user_color2 = "color: #ffffff";
        }
        
        // Avatar-Icon (falls aktiv)
        $avataricon = '';
        if (($_SESSION['etchat_'.$this->_prefix.'chat_pic'] ?? '0') == '1' && !empty($avatar)) {
            $avatarPath = 'avatar/' . htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8');
            if (is_file($avatarPath)) {
                $avataricon = '<img src="' . $avatarPath . '" class="avatar_w" alt="" loading="lazy">';
            }
        }
        
        $username_with_color = "<span style=\"$user_color2\">" . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . "</span>";
        
        // ===== MODERNISIERT: Systemmeldung mit Sprachunterstützung =====
        $new_room_name = $raum_array[0]['etchat_roomname'] ?? 'Unbekannt';
        $new_room_name_safe = htmlspecialchars($new_room_name, ENT_QUOTES, 'UTF-8');
        
        // Text aus XML: "ist in den Raum {room} gewechselt"
        $roomChangeText = $this->getText('room_change_message', 'ist in den Raum <b>{room}</b> gewechselt.');
        $roomChangeText = str_replace('{room}', $new_room_name_safe, $roomChangeText);

        new SysMessage(
            $this->dbObj,
            $avataricon . " <b>" . $username_with_color . "</b> " . $roomChangeText,
            $old_room_id,  // Alter Raum (die Nachricht erscheint dort)
            0
        );
    }
    // ============================================================
    // ENDE NEU
    // ============================================================
    
    $user_onlineid = $this->dbObj->sqlGet(
        "SELECT etchat_onlineid
         FROM {$this->_prefix}etchat_useronline
         WHERE etchat_onlineuser_fid = ?",
        [$user_id]
    );

    if (is_array($user_onlineid) && !empty($user_onlineid[0])) {
        // UPDATE bestehender Eintrag
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_useronline SET
                etchat_onlineuser_fid = ?,
                etchat_onlinetimestamp = ?,
                etchat_onlineip = ?,
                etchat_fid_room = ?,
                etchat_user_online_room_goup = ?,
                etchat_user_online_room_name = ?,
                etchat_user_online_user_name = ?,
                etchat_user_online_user_priv = ?,
                etchat_user_online_user_sex = ?,
                etchat_avatar = ?,
                etchat_session_id = ?
             WHERE etchat_onlineid = ?",
            [
                $user_array[0]['etchat_user_id'] ?? 0,
                time(),
                $user_param_all,
                $new_room_id,
                $raum_array[0]['etchat_room_goup'] ?? '',
                $raum_array[0]['etchat_roomname'] ?? '',
                $user_array[0]['etchat_username'] ?? '',
                $user_array[0]['etchat_userprivilegien'] ?? '',
                $user_array[0]['etchat_usersex'] ?? '',
                $_SESSION['etchat_'.$this->_prefix.'avatar'] ?? 'noavatar.jpg',
                $sessionId,
                $user_onlineid[0]['etchat_onlineid'] ?? 0
            ]
        );

    } else {
        // INSERT neuer Eintrag
        $this->dbObj->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_useronline (
                etchat_onlineuser_fid,
                etchat_onlinetimestamp,
                etchat_onlineip,
                etchat_fid_room,
                etchat_user_online_room_goup,
                etchat_user_online_room_name,
                etchat_user_online_user_name,
                etchat_user_online_user_priv,
                etchat_user_online_user_sex,
                etchat_avatar,
                etchat_logintime,
                etchat_session_id
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            [
                $user_array[0]['etchat_user_id'] ?? 0,
                time(),
                $user_param_all,
                $new_room_id,
                $raum_array[0]['etchat_room_goup'] ?? '',
                $raum_array[0]['etchat_roomname'] ?? '',
                $user_array[0]['etchat_username'] ?? '',
                $user_array[0]['etchat_userprivilegien'] ?? '',
                $user_array[0]['etchat_usersex'] ?? '',
                $_SESSION['etchat_'.$this->_prefix.'avatar'] ?? 'noavatar.jpg',
                time(),
                $sessionId
            ]
        );

        if (!empty($_SESSION['etchat_'.$this->_prefix.'invisible_on_enter'])) {
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_useronline
                 SET etchat_user_online_user_status_img = 'status_invisible',
                     etchat_user_online_user_status_text = ''
                 WHERE etchat_onlineuser_fid = ?",
                [$user_id]
            );
        }
    }
}

    private function getRoomArray()
    {
        $raum_array = $this->dbObj->sqlGet(
            "SELECT etchat_id_room, etchat_roomname, etchat_room_goup, etchat_room_message
             FROM {$this->_prefix}etchat_rooms
             WHERE etchat_id_room = ?",
            [(int)($_POST['room'] ?? 0)]
        );

        if (!is_array($raum_array) || empty($raum_array)) {
            $_POST['room'] = 1;

            $raum_array = $this->dbObj->sqlGet(
                "SELECT etchat_id_room, etchat_roomname, etchat_room_goup
                 FROM {$this->_prefix}etchat_rooms
                 WHERE etchat_id_room = 1"
            );
        }
        else {
            // 🔄 ASSOZIATIVER INDEX
            $room_allowed = new RoomAllowed($raum_array[0]['etchat_room_goup'] ?? '', $raum_array[0]['etchat_id_room'] ?? 0);

            if ($room_allowed->room_status != 1) {
                $_POST['room'] = 1;
                unset($_POST['message']);

                $raum_array = $this->dbObj->sqlGet(
                    "SELECT etchat_id_room, etchat_roomname, etchat_room_goup
                     FROM {$this->_prefix}etchat_rooms
                     WHERE etchat_id_room = 1"
                );
            }
        }

        return $raum_array;
    }

    private function checkKicklist()
    {
        $kicklist = $this->dbObj->sqlGet(
            "SELECT id FROM {$this->_prefix}etchat_kick_user
             WHERE etchat_kicked_user_id = ?",
            [$_SESSION['etchat_'.$this->_prefix.'user_id']]
        );

        if (is_array($kicklist)) {

            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_kick_user
                 WHERE etchat_kicked_user_id = ?",
                [$_SESSION['etchat_'.$this->_prefix.'user_id']]
            );

            $rechte_zum_kicken = $this->dbObj->sqlGet(
                "SELECT etchat_userprivilegien
                 FROM {$this->_prefix}etchat_user
                 WHERE etchat_user_id = ?",
                [$_SESSION['etchat_'.$this->_prefix.'user_id']]
            );

            // 🔄 ASSOZIATIVER INDEX
            if (isset($rechte_zum_kicken[0]['etchat_userprivilegien']) && 
                $rechte_zum_kicken[0]['etchat_userprivilegien'] !== "admin" && 
                $rechte_zum_kicken[0]['etchat_userprivilegien'] !== "mod") {
                return true;
            }

            return false;
        }

        return false;
    }

    private function errorOutput($message = 0)
    {
        echo $message;
        $this->dbObj->close();
    }

    private function selectMessagesForTheUser()
    {
        $where_sys_messages = '';

        if (empty($_SESSION['etchat_'.$this->_prefix.'last_id'])) {

            if (isset($_SESSION['etchat_'.$this->_prefix.'sys_messages']) &&
                !$_SESSION['etchat_'.$this->_prefix.'sys_messages']) {

                $where_sys_messages = "(etchat_user_fid<>1 or (etchat_user_fid=1 and etchat_privat=?)) and ";
                $this->_messages_shown_on_entrance--;
            }

            $counted_ids = $this->dbObj->sqlGet(
                "SELECT count(etchat_id) as cnt
                 FROM {$this->_prefix}etchat_messages
                 WHERE etchat_id > ?
                 AND etchat_fid_room IN (?,0)
                 AND (etchat_privat = 0 OR etchat_privat = ?)",
                [
                    $_SESSION['etchat_'.$this->_prefix.'my_first_mess_id'],
                    (int)($_POST['room'] ?? 0),
                    $_SESSION['etchat_'.$this->_prefix.'user_id']
                ]
            );

            // 🔄 ASSOZIATIVER INDEX
            if (is_array($counted_ids) && isset($counted_ids[0]['cnt']) && $counted_ids[0]['cnt'] >= $this->_messages_shown_on_entrance) {
                $this->_messages_shown_on_entrance += $counted_ids[0]['cnt'];
            }

            $feld = $this->dbObj->sqlGet(
                "SELECT etchat_id, etchat_username, etchat_text, etchat_timestamp,
                        etchat_fid_room, etchat_privat, etchat_user_id,
                        etchat_text_css, etchat_userprivilegien, etchat_usersex,
                        etchat_avatar
                 FROM {$this->_prefix}etchat_messages
                 JOIN {$this->_prefix}etchat_user
                   ON etchat_user_id = etchat_user_fid
                 WHERE (etchat_fid_room IN (?,0) OR etchat_privat = ?)
                   AND ".$where_sys_messages."
                   (etchat_privat = 0 OR etchat_privat = ? OR etchat_user_fid = ?)
                 ORDER BY etchat_id DESC
                 LIMIT ?",
                [
                    (int)($_POST['room'] ?? 0),
                    $_SESSION['etchat_'.$this->_prefix.'user_id'],
                    $_SESSION['etchat_'.$this->_prefix.'user_id'],
                    $_SESSION['etchat_'.$this->_prefix.'user_id'],
                    $this->_messages_shown_on_entrance
                ]
            );

            // 🔄 ASSOZIATIVER INDEX
            $_SESSION['etchat_'.$this->_prefix.'last_id'] = ($feld && isset($feld[0]['etchat_id']))
                ? $feld[0]['etchat_id']
                : 0;

            $feld = array_reverse($feld);
        }
        else {

            if (isset($_SESSION['etchat_'.$this->_prefix.'sys_messages']) &&
                !$_SESSION['etchat_'.$this->_prefix.'sys_messages']) {

                $where_sys_messages = "(etchat_user_fid<>1 or (etchat_user_fid=1 and etchat_privat=?)) and ";
            }

            $feld = $this->dbObj->sqlGet(
                "SELECT etchat_id, etchat_username, etchat_text, etchat_timestamp,
                        etchat_fid_room, etchat_privat, etchat_user_id,
                        etchat_text_css, etchat_userprivilegien, etchat_usersex,
                        etchat_avatar
                 FROM {$this->_prefix}etchat_messages
                 JOIN {$this->_prefix}etchat_user
                   ON etchat_user_id = etchat_user_fid
                 WHERE (etchat_fid_room IN (?,0) OR etchat_privat = ?)
                   AND etchat_id > ?
                   AND ".$where_sys_messages."
                   (etchat_privat = 0 OR etchat_privat = ? OR etchat_user_fid = ?)
                 ORDER BY etchat_id",
                [
                    (int)($_POST['room'] ?? 0),
                    $_SESSION['etchat_'.$this->_prefix.'user_id'],
                    $_SESSION['etchat_'.$this->_prefix.'last_id'],
                    $_SESSION['etchat_'.$this->_prefix.'user_id'],
                    $_SESSION['etchat_'.$this->_prefix.'user_id']
                ]
            );

            // 🔄 ASSOZIATIVER INDEX
            $_SESSION['etchat_'.$this->_prefix.'last_id'] =
                ($feld && count($feld) > 0) ? $feld[count($feld)-1]['etchat_id'] : $_SESSION['etchat_'.$this->_prefix.'last_id'];
        }

        return $feld;
    }

    private function blockiere($user_id, $privat_id)
    {
        if (isset($_SESSION['etchat_'.$this->_prefix.'block_all']) &&
            is_array($_SESSION['etchat_'.$this->_prefix.'block_all']) &&
            in_array($user_id, $_SESSION['etchat_'.$this->_prefix.'block_all'])) {
            return true;
        }

        if (isset($_SESSION['etchat_'.$this->_prefix.'block_priv']) &&
            is_array($_SESSION['etchat_'.$this->_prefix.'block_priv']) &&
            in_array($user_id, $_SESSION['etchat_'.$this->_prefix.'block_priv']) &&
            $privat_id == $_SESSION['etchat_'.$this->_prefix.'user_id']) {
            return true;
        }

        return false;
    }
	
    /**
     * 🔥 NEU: Nur Session aktualisieren + System-Meldungen prüfen
     */
    private function updateUserSessionOnly()
    {
        $user_id = (int)($_SESSION['etchat_'.$this->_prefix.'user_id'] ?? 0);
        if ($user_id === 0) {
            echo '{"data":[]}';
            $this->dbObj->close();
            exit;
        }
        
        // 1. Nur den Timestamp aktualisieren (User bleibt online)
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_useronline 
             SET etchat_onlinetimestamp = ? 
             WHERE etchat_onlineuser_fid = ?",
            [time(), $user_id]
        );
        
        // 2. 🔥 NEU: Prüfen ob es System-Meldungen gibt (z.B. User verlässt Chat)
        $lastId = (int)($_SESSION['etchat_'.$this->_prefix.'last_id'] ?? 0);
        $roomId = (int)($_POST['room'] ?? 0);
        
        $systemMessages = $this->dbObj->sqlGet(
            "SELECT etchat_id, etchat_username, etchat_text, etchat_timestamp,
                    etchat_fid_room, etchat_privat, etchat_user_id,
                    etchat_text_css, etchat_userprivilegien, etchat_usersex,
                    etchat_avatar
             FROM {$this->_prefix}etchat_messages
             JOIN {$this->_prefix}etchat_user
               ON etchat_user_id = etchat_user_fid
             WHERE etchat_id > ?
               AND (etchat_fid_room IN (?,0) OR etchat_privat = ?)
               AND (etchat_user_fid = 1)  -- System-Nachrichten (user_id = 1)
               AND (etchat_privat = 0 OR etchat_privat = ? OR etchat_user_fid = ?)
             ORDER BY etchat_id",
            [$lastId, $roomId, $user_id, $user_id, $user_id]
        );
        
        if ($systemMessages && count($systemMessages) > 0) {
            // System-Meldungen gefunden → normal ausgeben
            $_SESSION['etchat_'.$this->_prefix.'last_id'] = $systemMessages[count($systemMessages)-1]['etchat_id'];
            $this->makeJsonOutput($systemMessages);
        } else {
            // Keine System-Meldungen → leeres JSON
            echo '{"data":[]}';
        }
        
        $this->dbObj->close();
        exit;
    }
}