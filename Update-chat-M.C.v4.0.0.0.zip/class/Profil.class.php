<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Profil extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    private function replacePlaceholders(string $text, array $placeholders): string
    {
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', $value, $text);
        }
        return $text;
    }

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        $sessionUserId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);

        if ($sessionUserId <= 0) {
            echo $this->getText('profil_not_logged_in', 'Sie sind nicht angemeldet im Chat.');
            $this->dbObj->close();
            return;
        }

        $userId = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT);
        if (!$userId) {
            echo $this->getText('profil_user_not_found', 'Benutzer nicht gefunden.');
            $this->dbObj->close();
            return;
        }

        // ✅ SICHER MIT PREPARED STATEMENT
        $feld = $this->dbObj->sqlGet("
            SELECT
                etchat_username      AS username,
                etchat_userprivilegien AS privilegien,
                etchat_reg_timestamp  AS reg_datum,
                etchat_usersex         AS geschlecht,
                etchat_avatar          AS avatar,
                etchat_geb_tag          AS geb_tag,
                etchat_geb_monat         AS geb_monat,
                etchat_geb_jahr           AS geb_jahr,
                etchat_ort                AS ort,
                etchat_beschreibung        AS beschreibung
            FROM {$this->_prefix}etchat_user
            WHERE etchat_user_id = :user_id
            LIMIT 1
        ", [':user_id' => $userId]);

        $this->dbObj->close();

        if (empty($feld)) {
            echo $this->getText('profil_data_not_loaded', 'Benutzerdaten konnten nicht geladen werden.');
            return;
        }

        $user = $feld[0];

        /* ===============================
           ALTER + GEBURTSTAG
        =============================== */

        $tag   = (int)($user['geb_tag'] ?? 0);
        $monat = (int)($user['geb_monat'] ?? 0);
        $jahr  = (int)($user['geb_jahr'] ?? 0);

        $alter = null;
        $geburtstagsGruss = '';
        $heute = new DateTime();

        if ($tag && $monat) {
            if ($jahr > 0 && checkdate($monat, $tag, $jahr)) {
                $geburtsdatum = new DateTime(sprintf('%04d-%02d-%02d', $jahr, $monat, $tag));
                $alter = $heute->diff($geburtsdatum)->y;

                if ((int)$heute->format('j') === $tag && (int)$heute->format('n') === $monat) {
                    $username = htmlspecialchars($user['username'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                    $birthdayTemplate = $this->getText('profil_birthday_message', '<b><p style="color:red">{username} hat heute Geburtstag! {age}</p></b>');
                    $ageText = $this->replacePlaceholders(
                        $this->getText('profil_birthday_with_age', 'Und wird {age} Jahre alt.'),
                        ['age' => $alter]
                    );
                    $geburtstagsGruss = $this->replacePlaceholders($birthdayTemplate, [
                        'username' => $username,
                        'age' => $ageText
                    ]);
                }
            } elseif (checkdate($monat, $tag, 2000)) {
                if ((int)$heute->format('j') === $tag && (int)$heute->format('n') === $monat) {
                    $username = htmlspecialchars($user['username'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                    $birthdayTemplate = $this->getText('profil_birthday_message', '<b><p style="color:red">{username} hat heute Geburtstag! {age}</p></b>');
                    $geburtstagsGruss = $this->replacePlaceholders($birthdayTemplate, [
                        'username' => $username,
                        'age' => ''
                    ]);
                }
            }
        }

        $geburt = $geburtstagsGruss ? "<div>$geburtstagsGruss</div>" : '';
        $user['alter'] = $alter;

        /* ===============================
           USER BILDER
        =============================== */

        $uploadDir = './userpic/';
        $userImages = [];

        if (is_dir($uploadDir)) {
            $files = scandir($uploadDir);
            if ($files !== false) {
                foreach ($files as $file) {
                    $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
                        $metaFile = $uploadDir . $file . '.txt';
                        if (is_file($metaFile)) {
                            $meta = file_get_contents($metaFile);
                            if ($meta !== false) {
                                $parts = explode('|', $meta);
                                if (count($parts) >= 2) {
                                    $uploader = trim($parts[0]);
                                    $datum    = trim($parts[1]);
                                    if ($uploader === $user['username']) {
                                        $userImages[] = [
                                            'image' => $file,
                                            'datum' => $datum
                                        ];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        usort($userImages, function ($a, $b) {
            return strtotime($b['datum']) <=> strtotime($a['datum']);
        });

        $user['bilder'] = $userImages;

        $avatar_an_aus = $_SESSION['etchat_' . $this->_prefix . 'be_info_pic'] ?? '0';

        $this->initTemplate($user, $geburt, $avatar_an_aus);
    }

    private function initTemplate(array $user, string $geburt, string $avatar_an_aus): void
    {
        $style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'etchat_dino_styles';
        include_once("styles/{$style}/profil.tpl.html");
    }
}