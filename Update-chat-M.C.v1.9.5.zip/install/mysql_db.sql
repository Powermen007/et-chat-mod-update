
CREATE TABLE `etchat_radio_history` (
  `etchat_id` int(11) NOT NULL,
  `etchat_song_title` varchar(255) NOT NULL,
  `etchat_song_artist` varchar(255) DEFAULT '',
  `etchat_dj_name` varchar(100) DEFAULT 'Auto DJ',
  `etchat_played_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `etchat_radio_history`
  ADD PRIMARY KEY (`etchat_id`);

ALTER TABLE `etchat_radio_history`
  MODIFY `etchat_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;


ALTER TABLE `etchat_radio_box` ADD `etchat_system_titel_an` TINYINT(1) NOT NULL DEFAULT '1' AFTER `etchat_on_air`, ADD `etchat_titel_an` TINYINT(1) NOT NULL DEFAULT '1' AFTER `etchat_system_titel_an`; 

ALTER TABLE `etchat_user` ADD COLUMN `etchat_onlinetime` BIGINT NOT NULL DEFAULT '0';


ALTER TABLE `etchat_config` ADD `etchat_top_user_onoff` TINYINT(1) NOT NULL DEFAULT '1' AFTER `etchat_config_bewer`, ADD `etchat_top_user` TINYINT(2) NOT NULL DEFAULT '15' AFTER `etchat_top_user_onoff`;


CREATE TABLE `etchat_kontakt` (
  `etchat_id` int(10) UNSIGNED NOT NULL,
  `etchat_kontakt_daten` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_status` enum('neu','bearbeitung_admin','bearbeitung_coadmin','bearbeitung_chatwache','abgeschlossen') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neu',
  `etchat_kommentar` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_erstellt_am` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `etchat_kontakt_fields` (
  `etchat_id` int(11) NOT NULL,
  `etchat_field_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_field_type` enum('text','email','select','checkbox','textarea','date') COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_options` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON-kodierte Optionen f�r select/checkbox',
  `etchat_required` tinyint(1) DEFAULT 0,
  `etchat_visible` tinyint(1) DEFAULT 1,
  `etchat_sort_order` int(11) DEFAULT 0,
  `etchat_custom` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `etchat_kontakt_fields` (`etchat_id`, `etchat_field_name`, `etchat_field_type`, `etchat_options`, `etchat_required`, `etchat_visible`, `etchat_sort_order`, `etchat_custom`) VALUES
(1, 'Betreff', 'select', '[\"Sonstige\",\"Allgemein\",\"Musik\",\"Beschwerde\"]', 1, 1, 0, 0),
(2, 'E-Mail', 'email', NULL, 1, 1, 1, 0),
(3, 'Anrede', 'select', '[\"Herr\",\"Frau\",\"Divers\"]', 0, 1, 2, 0),
(4, 'Name', 'text', NULL, 1, 1, 3, 0),
(5, 'Telefon', 'text', NULL, 0, 1, 5, 0),
(6, 'Ort', 'text', NULL, 0, 1, 8, 0),
(7, 'Nachricht', 'textarea', NULL, 1, 1, 21, 0);


ALTER TABLE `etchat_kontakt`
  ADD PRIMARY KEY (`etchat_id`);

ALTER TABLE `etchat_kontakt_fields`
  ADD PRIMARY KEY (`etchat_id`);



ALTER TABLE `etchat_kontakt`
  MODIFY `etchat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `etchat_kontakt_fields`
  MODIFY `etchat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;
