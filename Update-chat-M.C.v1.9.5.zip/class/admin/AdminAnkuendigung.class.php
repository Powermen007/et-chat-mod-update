<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminAnkuendigung extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $allowedRoles = ["admin", "co_admin"];
        if (!in_array($_SESSION['etchat_'.$this->_prefix.'user_priv'] ?? '', $allowedRoles)) {
            header("Location: ./");
            exit;
        }

        $desei = $this->dbObj->sqlGet("SELECT etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id='1'");
        $this->showForm($desei);
    }

    private function showForm($desei)
    {
        $file = 'class/Ankuendigung.class.php';
        $message = '';
        $bgcolor = $color = $text = '';

        // Speichern
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $bgcolor = ($_POST['bgcolor_select'] ?? '') === 'custom' ? trim($_POST['bgcolor']) : '';
            $colorSelect = $_POST['color_select'] ?? '';
            $color = $colorSelect === 'custom' ? trim($_POST['color']) : $colorSelect;
            $text = trim($_POST['text']);
            $bgAttr = $bgcolor ? 'bgcolor="' . htmlspecialchars($bgcolor) . '"' : '';

            // Ausgabe je nach Modus
            if ($colorSelect === 'rainbow') {
                $styleBlock = '<style>'
                    . '@keyframes rainbowAnim{0%{background-position:0% 0%}'
                    . '50%{background-position:100% 0%}'
                    . '100%{background-position:0% 0%}}'
                    . '.rnb{background:linear-gradient(90deg, red, orange, yellow, green, cyan, blue, purple);'
                    . 'background-size:200% 100%; -webkit-background-clip:text; color:transparent;'
                    . 'animation:rainbowAnim 7s linear infinite;}'
                    . '</style>';
                $newContent = $styleBlock
                    . '<marquee ' . $bgAttr . ' style="margin:5px 0; border-radius:10px;">'
                    . '<b class="rnb">' . htmlspecialchars($text) . '</b></marquee>';
            } else {
                $useColor = $color ?: '#FFFFFF';
                $newContent = '<marquee ' . $bgAttr
                    . ' style="margin:5px 0; border-radius:10px; color:' . htmlspecialchars($useColor) . ';">'
                    . '<b>' . htmlspecialchars($text) . '</b></marquee>';
            }

            if (!file_exists($file)) {
                $message = "❌ Datei nicht gefunden: <code>" . htmlspecialchars($file) . "</code>";
            } elseif (!is_writable($file)) {
                $message = "❌ Datei ist nicht beschreibbar! Bitte Schreibrechte prüfen (chmod 666)";
            } else {
                file_put_contents($file, $newContent);
                $message = "✅ Datei wurde erfolgreich gespeichert!";
            }
        }

        // Datei auslesen
        if (file_exists($file)) {
            $content = file_get_contents($file);
            if (preg_match('/bgcolor="([^"]+)"/', $content, $m)) $bgcolor = $m[1];
            if (strpos($content, 'class="rnb"') !== false) {
                $color = 'rainbow';
            } elseif (preg_match('/color:([^;"]+)/', $content, $m)) {
                $color = trim($m[1]);
            }
            if (preg_match('/<b[^>]*>(.*?)<\/b>/', $content, $m)) {
                $text = $m[1];
            } else {
                $text = '';
            }
            if (empty($color)) {
				$color = '#FFFFFF';
			}

			if ($this->isCustomColor($color)) {
				$colorSelect = 'custom';
			} elseif ($color === 'rainbow') {
				$colorSelect = 'rainbow';
			} else {
				$colorSelect = $color;
			}
        }

        $bgSelect = $bgcolor ? 'custom' : '';
        $placeholder = "Hier kommt euer Text eingetragen!!";

        // HTML Kopf
        echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Ankündigung bearbeiten</title>
HTML;

        if (is_array($desei)) {
            foreach ($desei as $data) {
                echo "<link href=\"styles/{$data[0]}/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
            }
        }

        $this->dbObj->close();

        // Stil + Vorschau
        echo <<<HTML
<style>
form { padding:15px 25px; border-radius:10px; box-shadow:0 0 8px rgba(0,0,0,0.1); width:420px; }
label { display:block; margin-top:10px; font-weight:bold; }
input[type="text"], input[type="color"], select {
    width:100%; padding:6px; border:1px solid #ccc; border-radius:6px;
}
input[type="submit"] {
    margin-top:15px; padding:8px 16px; background:#007BFF; border:none;
    border-radius:6px; color:white; cursor:pointer;
}
.marquee-preview { margin-top:25px; padding:10px; border-radius:10px;
    box-shadow:0 0 8px rgba(0,0,0,0.1);
}
</style>

<script>
function toggleBgColor(v){document.getElementById('bgcolor').style.display=(v==='custom')?'inline-block':'none';updatePreview();}
function toggleTextColor(v){document.getElementById('color').style.display=(v==='custom')?'inline-block':'none';updatePreview();}
function escapeHtml(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

function updatePreview(){
    const bgSel=document.getElementById('bgcolor_select').value;
    const bgCol=bgSel==='custom'?document.getElementById('bgcolor').value:'';
    const colSel=document.getElementById('color_select').value;
    const txtCol=colSel==='custom'?document.getElementById('color').value:colSel;
    const txt=document.getElementById('text').value||'';
    const prev=document.getElementById('preview');

    if(colSel==='rainbow'){
        const style='<style>@keyframes rainbowAnim{0%{background-position:0% 0%}50%{background-position:100% 0%}100%{background-position:0% 0%}}'
        +'.rnb{background:linear-gradient(90deg, red, orange, yellow, green, cyan, blue, purple);'
        +'background-size:200% 100%;-webkit-background-clip:text;color:transparent;animation:rainbowAnim 7s linear infinite;}</style>';
        const bgAttr=bgCol?'bgcolor="'+bgCol+'"':'';
        prev.innerHTML=style+'<marquee '+bgAttr+' style="margin:5px 0; border-radius:10px;"><b class="rnb">'+escapeHtml(txt)+'</b></marquee>';
    } else {
        const bgAttr=bgCol?'bgcolor="'+bgCol+'"':'';
        const col=txtCol||'#FFFFFF';
        prev.innerHTML='<marquee '+bgAttr+' style="margin:5px 0; border-radius:10px; color:'+col+';"><b>'+escapeHtml(txt)+'</b></marquee>';
    }
}

window.addEventListener('DOMContentLoaded',function(){
    toggleBgColor("{$bgSelect}");
    toggleTextColor("{$color}");
    updatePreview();
});
</script>
</head>
<body id="adminbereich_body">
HTML;

        // Zurück-Link + Überschrift
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $roleLinks = ["admin"=>"./?AdminIndex","co_admin"=>"./?AdminIndexCoAdmin"];
        $backlinkUrl = $roleLinks[$role] ?? "./";

        echo "<a href=\"{$backlinkUrl}\">&lt;&lt;&lt; zurück zum Adminmenü</a><hr size=\"1\">";
        echo "<h2>Ankündigung bearbeiten</h2>";

        // Erfolgsmeldung
        if (!empty($message)) {
            echo <<<HTML
<div id="msgBox" style="
    background:#e6ffe6; border:1px solid #5cb85c; color:#2d572c;
    padding:10px 15px; border-radius:8px; margin:10px 0; position:relative;
    max-width:450px; box-shadow:0 2px 6px rgba(0,0,0,0.15);">
    <strong>{$message}</strong>
    <span onclick="document.getElementById('msgBox').remove();" 
          style="position:absolute; top:5px; right:10px; cursor:pointer; font-weight:bold; color:#2d572c;">×</span>
</div>
<script>
setTimeout(()=>{
    const b=document.getElementById('msgBox');
    if(b){b.style.transition='opacity 1s';b.style.opacity='0';setTimeout(()=>b.remove(),1000);}
},30000);
</script>
HTML;
        }

        // Farbauswahl
        $rainbowColors = [
            "red"=>"Rot","orange"=>"Orange","yellow"=>"Gelb","green"=>"Grün",
            "cyan"=>"Cyan","blue"=>"Blau","purple"=>"Lila","pink"=>"Pink",
            "white"=>"Weiß","black"=>"Schwarz"
        ];

        echo <<<HTML
<form method="post" oninput="updatePreview()">
    <label>Hintergrundfarbe (bgcolor):</label>
    <select name="bgcolor_select" id="bgcolor_select" onchange="toggleBgColor(this.value);">
        <option value="">Keine / Transparent</option>
        <option value="custom" {$this->selected($bgSelect,'custom')}>Eigene Farbe wählen</option>
    </select>
    <input type="color" id="bgcolor" name="bgcolor" value="{$bgcolor}" style="display:none;">

    <label>Schriftfarbe (color):</label>
    <select name="color_select" id="color_select" onchange="toggleTextColor(this.value);">
HTML;

        if ($this->isCustomColor($color) && $color !== 'rainbow') $colorSelect = 'custom';
        if ($color === 'rainbow') $colorSelect = 'rainbow';

        foreach ($rainbowColors as $val => $label) {
            $sel = $this->selected($colorSelect ?? '', $val);
            echo "<option value=\"{$val}\" {$sel}>{$label}</option>";
        }

        $selRainbow = $this->selected($colorSelect ?? '', 'rainbow');
        $selCustom  = $this->selected($colorSelect ?? '', 'custom');
        echo "<option value=\"rainbow\" {$selRainbow}>Regenbogen-Effekt</option>";
        echo "<option value=\"custom\" {$selCustom}>Eigene Farbe wählen</option>";

        echo <<<HTML
    </select>
    <input type="color" id="color" name="color" value="{$color}" style="display:none;">

    <label>Text:</label>
    <input type="text" id="text" name="text" value="{$text}" placeholder="{$placeholder}">
    <input type="submit" value="Speichern">
</form>

<div class="marquee-preview">
    <h3>Vorschau:</h3>
    <div id="preview"></div>
</div>
</body>
</html>
HTML;
    }

    private function selected($val, $cmp){ return $val === $cmp ? 'selected' : ''; }

    private function isCustomColor($color){
        $preset = ["red","orange","yellow","green","cyan","blue","purple","pink","white","black","rainbow"];
        return !in_array(strtolower($color), $preset);
    }
}
?>
