<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

*/

// Klassen laden (Reihenfolge ist wichtig)
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/CompactModView.class.php";

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Team</title>

</head>

<body id="body">

<?php
// Karten erzeugen und gleichzeitig merken, welche Rollen vorkommen
ob_start();
$view = new CompactModView();
$allCards = ob_get_clean();

// vorhandene Rollen aus der Klasse
$roles = $view->rolesFound;

// Erste vorhandene Rolle bestimmen (Reihenfolge: mod, admin/co_admin, chatwache, grafik)
$defaultRole = null;
if (!empty($roles['mod'])) {
    $defaultRole = 'mod';
} elseif (!empty($roles['admin']) || !empty($roles['co_admin'])) {
    $defaultRole = 'admin-group';
} elseif (!empty($roles['chatwache'])) {
    $defaultRole = 'chatwache';
} elseif (!empty($roles['grafik'])) {
    $defaultRole = 'grafik';
}
?>

<center><h2 id="role-title">Unsere Moderatoren</h2></center>

<div class="role-tabs" data-default-role="<?php echo $defaultRole; ?>">
    <?php if (!empty($roles['mod'])): ?>
        <button class="role-tab" data-role="mod">Moderatoren</button>
    <?php endif; ?>
    <?php if (!empty($roles['admin']) || !empty($roles['co_admin'])): ?>
        <button class="role-tab" data-role="admin-group">Administratoren</button>
    <?php endif; ?>
    <?php if (!empty($roles['chatwache'])): ?>
        <button class="role-tab" data-role="chatwache">Chatwache</button>
    <?php endif; ?>
    <?php if (!empty($roles['grafik'])): ?>
        <button class="role-tab" data-role="grafik">Grafiker</button>
    <?php endif; ?>
</div>

<?php echo $allCards; ?>

<script>
// Mehr/Weniger Beschreibung
document.addEventListener('click', function(e){
    if(e.target.classList.contains('toggle-full')){
        e.preventDefault();
        const container = e.target.parentNode;
        const isShort = container.innerHTML.includes('mehr');
        if(isShort){
            container.innerHTML = container.dataset.full.replace(/\n/g,'<br>') + ' <a href="#" class="toggle-full">weniger</a>';
        } else {
            container.innerHTML = container.dataset.short + '... <a href="#" class="toggle-full">mehr</a>';
        }
    }
});

// Tabs: Rollen filtern
document.addEventListener("DOMContentLoaded", function() {
    const tabs = document.querySelectorAll(".role-tab");
    const cards = document.querySelectorAll(".compact-mod-card");
    const title = document.getElementById("role-title");

    function showRole(role) {
        cards.forEach(card => {
            if (
                card.dataset.role === role ||
                (role === "admin-group" && (card.dataset.role === "admin" || card.dataset.role === "co_admin"))
            ) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });

        const roleNames = {
            "mod": "Unsere Moderatoren",
            "admin-group": "Unsere Administratoren",
            "chatwache": "Unsere Chatwachen",
            "grafik": "Unsere Grafiker"
        };
        title.textContent = roleNames[role] ?? "Benutzer";
    }

    // Standardrolle anzeigen
    const tabsContainer = document.querySelector('.role-tabs');
    const defaultRole = tabsContainer?.dataset.defaultRole || null;
    if (defaultRole) {
        showRole(defaultRole);
        const defaultTab = document.querySelector('.role-tab[data-role="' + defaultRole + '"]');
        if (defaultTab) defaultTab.classList.add("active");
    }

    // Klick-Event für Tabs
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            showRole(tab.dataset.role);
        });
    });
});
</script>

</body>
</html>