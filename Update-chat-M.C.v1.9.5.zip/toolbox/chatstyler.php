<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

include '../config.php';
session_start();


if ($_SESSION['etchat_'.$prefix.'user_priv'] !== 'admin') {
	header("Location: ../");
    exit;
}


// Präfix aus config.php verwenden
$style = $_SESSION['etchat_'.$prefix.'style'] ?? 'style_chat';
$css = "../styles/$style/style.css";
$cssFile = "../styles/$style/variables.css";

if(!file_exists($cssFile)){
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Chat Styler</title>

<link href="<?php echo htmlspecialchars($css); ?>" rel="stylesheet">

<style>
.error-box {
	background: #d41313;
	border: 1px solid #740000;
	padding: 20px;
	border-radius: 8px;
	max-width: 700px;
}
</style>
</head>
<body id="adminbereich_body">
    <div><a href="../?AdminIndex">&laquo;&laquo;&laquo; Zurück zum Adminbereich</a></div>
    <hr size="1">
    <div class="error-box">
        <h2>⚠️ CSS-Datei nicht gefunden</h2>
        <p><strong>Datei:</strong> <code><?php echo htmlspecialchars($cssFile); ?></code></p>
        <p>Das Layout kann nicht gestylt werden.  
        Wechsle das Layout unter <br><em>Allgemeine Chateinstellungen &rarr; Style</em>.</p>
    </div>
</body>
</html>
<?php
    exit;
}

$cssContent = file_get_contents($cssFile);
preg_match('/:root\s*{([^}]*)}/s', $cssContent, $matches);

$variables = [];
$categories = [];
$currentCategory = 'Allgemein';

$labels = [
	'--Textfarbe' => 'User Standardt Schriftfarbe',
	'--Systemfarbe' => 'System Schriftfarbe',
	'--color-text-webfarbe' => 'Textfarbe Webseite',
	'--color-backround' => 'Hintergundfarbe',
    '--color-border' => 'Rahmenfarbe',
    '--color-link' => 'Links',
    '--color-link-hover' => 'Links (hover)',
	'--img' => 'Hintergrund Bild',
    '--font-family' => 'Schriftart',
    '--font-size-base' => 'Base',
    '--font-size-large' => 'Groß',
    '--font-size-small' => 'Klein',
    '--font-size-xlarge' => 'Extragroß',
];

$onOffVars = [
    '--banner_chat-on-off' => 'Banner im Chat',
    '--banner_index-on-off' => 'Banner auf der Indexseite',
    '--uhrzeit-on-off' => 'Uhrzeit mit Datum',
];

// CSS-Datei auslesen
if (!empty($matches[1])) {
    $lines = explode("\n", $matches[1]);
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;

        if (preg_match('/\/\*\s*(.+?)\s*\*\//', $line, $match)) {
            $currentCategory = $match[1];
            continue;
        }

        if (strpos($line, '--') !== false && strpos($line, ':') !== false) {
            [$key, $value] = explode(":", $line);
            $key = trim($key);
            $value = trim($value, " ;");

            // Falls es ein url(...) ist, rausfiltern für die Anzeige
            if ($key === '--img' && preg_match('/^url\((["\']?)(.*?)\1\)$/', $value, $m)) {
                $value = $m[2]; // Nur den Dateinamen behalten
            }

            $variables[$key] = $value;
            $categories[$key] = $currentCategory;
        }
    }
}


// Speichern
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
foreach ($_POST as $key => $value) {
    if (isset($variables[$key])) {

        // Sonderbehandlung für Hintergrundbild
        if ($key === '--img') {
            $filename = trim($value, " '\"");
            if ($filename === '') {
                $value = "none";
            } else {
                if (!str_contains($filename, '/')) {
                    $filename = "hintergrund/" . $filename;
                }
                $value = "url('" . $filename . "')";
            }
        }

        // 🟢 Text- & Systemfarbe in reinen HEX ohne #
        if (in_array($key, ['--Textfarbe', '--Systemfarbe'])) {
            $value = trim($value);

            // Falls rgb(...) → umwandeln
            if (preg_match('/^rgba?\s*\((.*?)\)/i', $value, $m)) {
                $parts = explode(',', $m[1]);
                $r = (int)trim($parts[0]);
                $g = (int)trim($parts[1]);
                $b = (int)trim($parts[2]);
                $value = strtoupper(sprintf("%02X%02X%02X", $r, $g, $b));
            }

            // Falls Hexwert → ohne #
            elseif (preg_match('/^#?([a-f0-9]{3}|[a-f0-9]{6})$/i', $value, $m)) {
                $hex = strtoupper($m[1]);
                // ggf. Kurzform (#fff → ffffff)
                if (strlen($hex) == 3) {
                    $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
                }
                $value = $hex;
            }
        }

        $variables[$key] = $value;
    }
}

    $newContent = ":root {\n";
    $lastCategory = '';
    foreach ($variables as $key => $value) {
        $categoryName = $categories[$key] ?? 'Allgemein';
			if ($categoryName !== $lastCategory) {
			    $newContent .= "  /* $categoryName */\n";
			    $lastCategory = $categoryName;
			}
			        $newContent .= "  $key: $value;\n";
			    }
			    
    $newContent .= "}\n";

    file_put_contents($cssFile, $newContent);
    $message = "<div class='message success'>Variablen gespeichert!<span class='close-btn' onclick='this.parentElement.style.display=\"none\";'>&times;</span></div>";

}

// Prüfen ob Farbwert
function isColor($value) {
    $value = trim($value);

    return preg_match('/^#?([a-fA-F0-9]{3}|[a-fA-F0-9]{6})$/', $value)   // ← erkennt jetzt auch "FFFFFF" oder "#FFF"
        || preg_match('/^rgba?\(/', $value)
        || preg_match('/^hsl\(/', $value);
}


// Hilfsfunktionen für Farbkonvertierung
function toRGBA($value){
    $value = trim($value);

    if (preg_match('/^#([a-f0-9]{3})$/i', $value, $m)) {
        $r = hexdec(str_repeat($m[1][0],2));
        $g = hexdec(str_repeat($m[1][1],2));
        $b = hexdec(str_repeat($m[1][2],2));
        return "rgba($r,$g,$b,1)";
    } elseif (preg_match('/^#([a-f0-9]{6})$/i', $value, $m)) {
        $r = hexdec(substr($m[1],0,2));
        $g = hexdec(substr($m[1],2,2));
        $b = hexdec(substr($m[1],4,2));
        return "rgba($r,$g,$b,1)";
    } elseif (preg_match('/^hsl\(\s*(\d+),\s*(\d+)%?,\s*(\d+)%?\)/i', $value, $m)) {
        $h = $m[1]/360;
        $s = $m[2]/100;
        $l = $m[3]/100;
        $r = $g = $b = 0;
        if($s == 0){
            $r = $g = $b = $l;
        } else {
            $q = $l < 0.5 ? $l*(1+$s) : $l+$s-$l*$s;
            $p = 2*$l - $q;
            $r = hue2rgb($p,$q,$h+1/3);
            $g = hue2rgb($p,$q,$h);
            $b = hue2rgb($p,$q,$h-1/3);
        }
        $r = round($r*255); $g = round($g*255); $b = round($b*255);
        return "rgba($r,$g,$b,1)";
    } elseif (preg_match('/^rgba?\(/i', $value)) {
        return preg_replace('/\s+/','',$value);
    }
    return $value;
}
function hue2rgb($p,$q,$t){
    if($t<0) $t+=1;
    if($t>1) $t-=1;
    if($t<1/6) return $p+($q-$p)*6*$t;
    if($t<1/2) return $q;
    if($t<2/3) return $p+($q-$p)*(2/3-$t)*6;
    return $p;
}

// Variablen in RGBA
foreach ($variables as $key => $value){
    if(isColor($value)){
        $variables[$key] = toRGBA($value);
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Chat Styler</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@simonwep/pickr/dist/themes/classic.min.css"/>

<link href="<?php echo htmlspecialchars($css); ?>" rel="stylesheet">

<style>

form { max-width: 700px; margin: 20px auto; }
.category { margin-top: 20px; font-weight: bold; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
.label-container { display: flex; align-items: center; gap: 10px; margin-top: 10px; }
.label-container label { width: 200px; flex-shrink: 0; }
input[type="text"] { flex: 1; padding: 5px; min-width: 150px; max-width: 350px; }
.pickr-container { width: 36px; height: 36px; border: 1px solid #ccc; cursor: pointer; }
button { margin-top: 15px; }

.message {
    position: relative;
    margin: 10px auto;
    padding: 12px 40px 12px 15px;
    border-radius: 6px;
    max-width: 600px;
    text-align: center;
    font-size: 14px;
}

.message.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.message .close-btn {
    position: absolute;
    top: 8px;
    right: 12px;
    color: #155724;
    font-size: 20px;
    font-weight: bold;
    cursor: pointer;
}

.sp-container {
	width: 245px;
}

</style>
</head>
<body id="adminbereich_body">

<div><a href='../?AdminIndex'"><<< Zurück zum Adminbereich</a></div>
<hr size="1">

<div id="message-area"><?php echo $message; ?></div>

<center><b>Chat Styler</b></center>
<form method="post">
<?php
$lastCategory = '';

// Hintergrundbilder automatisch einlesen
$backgroundDir = "../styles/$style/hintergrund/";
$backgroundFiles = [];
if (is_dir($backgroundDir)) {
    foreach (scandir($backgroundDir) as $file) {
        if (preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $file)) {
            $backgroundFiles[] = $file;
        }
    }
}

foreach ($variables as $key => $value):
    $category = $categories[$key] ?? 'Allgemein';
    $label = $labels[$key] ?? $key;
    if ($category !== $lastCategory):
        echo "<div class='category'>{$category}</div>";
        $lastCategory = $category;
    endif;

    $isColor = isColor($value);
?>
<div class="label-container">
    <label for="<?php echo $key; ?>">
        <?php
        $label = $labels[$key] ?? $onOffVars[$key] ?? $key;
        echo htmlspecialchars($label);
        ?>
    </label>

    <?php if($isColor): ?>
        <!-- Spectrum Input -->
                        <input type="text"
                       class="spectrum-picker"
                       id="input-<?php echo md5($key); ?>"
                       name="<?php echo $key; ?>"
                       value="<?php echo htmlspecialchars($value); ?>">
<?php else: ?>
    <?php if (array_key_exists($key, $onOffVars)): ?>
        <select id="<?php echo $key; ?>" name="<?php echo $key; ?>">
            <option value="" <?php echo ($value === '') ? 'selected' : ''; ?>>Anzeigen</option>
            <option value="none" <?php echo ($value === 'none') ? 'selected' : ''; ?>>Ausblenden</option>
        </select>
<?php elseif ($key === '--img'): ?>
    <?php
        // Falls der Wert als url('...') gespeichert ist → nur Dateiname extrahieren
        $cleanValue = $value;
        if (preg_match('/^url\((["\']?)(.*?)\1\)$/', $cleanValue, $m)) {
            $cleanValue = $m[2];
        }
        $cleanValue = basename($cleanValue); // nur den Dateinamen behalten
    ?>

<select id="<?php echo $key; ?>" name="<?php echo $key; ?>">
    <option value="" <?php echo empty($cleanValue) ? 'selected' : ''; ?>>— Kein Hintergrundbild —</option>
    <?php foreach ($backgroundFiles as $file): ?>
        <?php $selected = ($file === $cleanValue) ? 'selected' : ''; ?>
        <option value="<?php echo htmlspecialchars($file); ?>" <?php echo $selected; ?>>
            <?php echo htmlspecialchars($file); ?>
        </option>
    <?php endforeach; ?>
</select>


<?php if (!empty($cleanValue) && file_exists("../styles/$style/hintergrund/$cleanValue")): ?>
    <div style="margin-top:5px;">Aktuelles:
        <img src="<?php echo htmlspecialchars("../styles/$style/hintergrund/$cleanValue"); ?>"
             alt="Aktuelles Vorschau"
             style="max-width:200px; max-height:100px; border:1px solid #444; border-radius:6px;">
    </div>
<?php endif; ?>



    <?php else: ?>
        <input type="text" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($value); ?>" />
    <?php endif; ?>
<?php endif; ?>

</div>
<?php endforeach; ?>

<button type="submit">Speichern</button>
</form>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.1/spectrum.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.1/spectrum.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    $(".spectrum-picker").spectrum({
        type: "component",          // kleines Farbfeld + Input
        showInput: true,            // Textfeld bearbeiten
        showAlpha: true,            // Transparenz (RGBA)
        preferredFormat: "rgb",     // Ausgabe als rgb/rgba
        allowEmpty: false,          // keine leeren Werte
        showInitial: true,          // alten Wert anzeigen
        cancelText: "Abbrechen",    // deutsche Texte
        chooseText: "Übernehmen",
        clearText: "Zur�cksetzen"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    // Meldung nach 5s automatisch ausblenden
    const msg = document.querySelector(".message");
    if (msg) {
        setTimeout(() => {
            msg.style.display = "none";
        }, 5000);
    }
});


document.addEventListener("DOMContentLoaded", function () {
    const select = document.querySelector('select[name="--img"]');
    const style = "<?php echo $style; ?>";

    // Container und Bild für Vorschau erstellen
    const previewContainer = document.createElement("div");
    const previewLabel = document.createElement("div");
    const previewImg = document.createElement("img");

    // Label-Styling
    previewLabel.textContent = "Vorschau:";

    // Bild-Styling
    previewImg.style.maxWidth = "200px";
    previewImg.style.maxHeight = "100px";
    previewImg.style.border = "1px solid #444";
    previewImg.style.borderRadius = "6px";

    // Zusammenbauen
    previewContainer.appendChild(previewLabel);
    previewContainer.appendChild(previewImg);
    previewContainer.style.marginTop = "8px";

    // An DOM anhängen
    if (select) {
        select.parentElement.appendChild(previewContainer);

        function updatePreview() {
            const filename = select.value.trim();
            if (filename === "" || filename === "none") {
                previewImg.style.display = "none";
                previewLabel.style.display = "none";
            } else {
                previewImg.src = `../styles/${style}/hintergrund/${filename}`;
                previewLabel.style.display = "block";
            }
        }

        select.addEventListener("change", updatePreview);
        updatePreview(); // Initial anzeigen
    }
});


</script>

</body>
</html>
