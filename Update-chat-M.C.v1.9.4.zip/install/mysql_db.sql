
ALTER TABLE `etchat_config` ADD `etchat_config_index_team` TINYINT(1) NULL DEFAULT '1' AFTER `etchat_config_reg_an_aus`, ADD `etchat_config_team` TINYINT(1) NULL DEFAULT '1' AFTER `etchat_config_index_team`, ADD `etchat_config_index_bewer` TINYINT(1) NULL DEFAULT '1' AFTER `etchat_config_team`, ADD `etchat_config_bewer` TINYINT(1) NULL DEFAULT '1' AFTER `etchat_config_index_bewer`;


CREATE TABLE `etchat_bewerbungen` (
  `id` int(10) UNSIGNED NOT NULL,
  `bewerber_daten` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('neu','in Bearbeitung','angenommen','abgelehnt','gegangen') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neu',
  `kommentar` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `erstellt_am` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `etchat_bewerbung_fields` (
  `etchat_id` int(11) NOT NULL,
  `etchat_field_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_field_type` enum('text','email','select','checkbox','textarea','date') COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_options` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON-kodierte Optionen für select/checkbox',
  `etchat_required` tinyint(1) DEFAULT 0,
  `etchat_visible` tinyint(1) DEFAULT 1,
  `etchat_sort_order` int(11) DEFAULT 0,
  `etchat_custom` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




ALTER TABLE `etchat_bewerbungen`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `etchat_bewerbung_fields`
  ADD PRIMARY KEY (`etchat_id`);



ALTER TABLE `etchat_bewerbungen`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


ALTER TABLE `etchat_bewerbung_fields`
  MODIFY `etchat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;




INSERT INTO `etchat_bewerbung_fields` (`etchat_id`, `etchat_field_name`, `etchat_field_type`, `etchat_options`, `etchat_required`, `etchat_visible`, `etchat_sort_order`, `etchat_custom`) VALUES
(1, 'Betreff', 'select', '[\"Moderator Bewerbung\",\"Gast Moderator Bewerbung\",\"Gelegenheitsmoderator Bewerbung\",\"Chatwache\",\"Grafiker\",\"Techniker\",\"Sponsor\"]', 1, 1, 0, 0),
(2, 'E-Mail', 'email', NULL, 1, 1, 1, 0),
(3, 'Anrede', 'select', '[\"Herr\",\"Frau\",\"Divers\"]', 0, 1, 2, 0),
(4, 'Name', 'text', NULL, 1, 1, 3, 0),
(5, 'Modiename', 'text', NULL, 0, 1, 4, 0),
(6, 'Telefon', 'text', NULL, 0, 1, 5, 0),
(7, 'Alter', 'text', NULL, 1, 1, 6, 0),
(8, 'Geburtsdatum', 'date', NULL, 0, 1, 7, 0),
(9, 'Ort', 'text', NULL, 1, 1, 8, 0),
(10, 'Beruf', 'select', '[\"Vollzeit berufstätig\",\"Teilzeit berufstätig\",\"Schichtarbeit\",\"Selbstständig\",\"Rentner(in)\",\"Arbeitssuchend \\/ aktuell ohne Job\",\"Schüler(in)\",\"Student(in)\",\"Sonstiges\"]', 0, 1, 9, 0),
(11, 'Betriebssystem', 'select', '[\"Windows 11\",\"Windows 10\",\"Windows 8.1\",\"MacOS\",\"Linux\"]', 1, 1, 10, 0),
(12, 'CPU', 'text', NULL, 0, 1, 11, 0),
(13, 'Arbeitsspeicher', 'select', '[\"Ich habe 8 GB RAM\",\"Ich habe 16 GB RAM\",\"Ich habe 24 GB RAM\",\"Ich habe 32 GB RAM\",\"Ich habe 48 GB RAM\",\"Ich habe 64 GB RAM\",\"Ich habe mehr als 64 GB RAM\"]', 0, 1, 12, 0),
(14, 'Weitere Angaben Hardware', 'text', NULL, 0, 1, 13, 0),
(15, 'Internetverbindung', 'text', NULL, 0, 1, 14, 0),
(16, 'Musikarchiv', 'text', NULL, 1, 1, 15, 0),
(17, 'Streamerfahrung', 'select', '[\"Ich bin Neuling\",\"Ich habe weniger als 1 Jahr Erfahrung\",\"Ich habe mehr als 1 Jahr Erfahrung\",\"Ich habe mehr als 2 Jahr Erfahrung\",\"Ich habe mehr als 3 Jahr Erfahrung\",\"Ich habe mehr als 5 Jahr Erfahrung\"]', 1, 1, 16, 0),
(18, 'Sendesoftware', 'select', '[\"Radio Boss\",\"Mixxx\",\"Virtual DJ\",\"Flatcast Player\",\"BPM Studio\",\"Winamp\",\"Sam Broadcast 3\",\"Sam Broadcast 4\",\"Sonstiger Player\"]', 1, 1, 17, 0),
(19, 'Sendezeiten', 'select', '[\"Ich sende bevorzugt morgens\",\"Ich sende bevorzugt mittags\",\"Ich sende bevorzugt abends\",\"Ich sende bevorzugt nachts\",\"Flexibel\"]', 1, 1, 18, 0),
(20, 'Musikrichtung', 'checkbox', '[\"Schlager\",\"Techno\",\"Hip Hop\",\"Rap\",\"Trance\",\"Discofox\",\"Dance\",\"Electronic\",\"Gothic\",\"Rock\",\"Oldies\",\"Volksmusik\",\"Soul\",\"Funk\",\"Folk\",\"Pop\",\"House\",\"Country\",\"80er\",\"90er\",\"2000er\",\"Charts\",\"Sonstiges\",\"Alles\"]', 1, 1, 19, 0),
(21, 'Nachricht', 'textarea', NULL, 0, 1, 20, 0);


INSERT INTO `etchat_bewerbungen` (`id`, `bewerber_daten`, `status`, `kommentar`, `erstellt_am`) VALUES
(1, '{\"Betreff\":\"Moderator Bewerbung\",\"E_Mail\":\"chk1@gmx.de\",\"Anrede\":\"Herr\",\"Name\":\"Christian\",\"Modiename\":\"Powermen\",\"Telefon\":\"03044045915\",\"Alter\":\"57\",\"Geburtsdatum\":\"1968-05-06\",\"Ort\":\"Berlin\",\"Beruf\":\"Rentner(in)\",\"Betriebssystem\":\"Windows 11\",\"CPU\":\"I9\",\"Arbeitsspeicher\":\"Ich habe 64 GB RAM\",\"Weitere_Angaben_Hardware\":\"bis zu 5 Mic und 3 Headset zugleich bis zu 4 MIC\",\"Internetverbindung\":\"LAN \\/ 100 MB\\/bits\",\"Musikarchiv\":\"70.000\",\"Streamerfahrung\":\"Ich habe mehr als 5 Jahr Erfahrung\",\"Sendesoftware\":\"Mixxx\",\"Sendezeiten\":\"Flexibel\",\"Musikrichtung\":[\"Trance\",\"Discofox\",\"Dance\",\"Electronic\",\"Gothic\",\"Volksmusik\",\"Country\"],\"Nachricht\":\"Nachricht:Bitte geben Sie die Zeichen ein:*\"}', 'neu', NULL, '2025-09-14 18:30:28');

-- --------------------------------------------------------
