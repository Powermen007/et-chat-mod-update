


ALTER TABLE `etchat_user`
ADD `etchat_last_ip` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL;

