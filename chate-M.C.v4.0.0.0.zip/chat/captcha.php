<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

session_start();

// Captcha-Zeichen generieren (5 Zeichen)
$zeichen = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
$captcha_text = '';
for ($i = 0; $i < 5; $i++) {
    $captcha_text .= $zeichen[random_int(0, strlen($zeichen)-1)];
}

// In Session speichern
$_SESSION['captcha_text'] = $captcha_text;

// Bildgröße
$breite = 140;
$hoehe = 50;
$bild = imagecreatetruecolor($breite, $hoehe);

// Farben
$hintergrund = imagecolorallocate($bild, 255, 255, 255);
$schriftfarbe = imagecolorallocate($bild, 0, 0, 0);
$störfarbe = imagecolorallocate($bild, 150, 150, 150);

// Hintergrund füllen
imagefilledrectangle($bild, 0, 0, $breite, $hoehe, $hintergrund);

// Text ins Bild schreiben
$fontSize = 5; // Bilder-GD Standardfont: 1-5
$x = 15;
$y = 15;
imagestring($bild, $fontSize, $x, $y, $captcha_text, $schriftfarbe);

// Optional: leichtes Rauschen (Punkte)
for ($i = 0; $i < 150; $i++) {
    imagesetpixel($bild, random_int(0, $breite-1), random_int(0, $hoehe-1), $störfarbe);
}

// Optional: ein paar Linien für schwerere Erkennung
for ($i = 0; $i < 3; $i++) {
    imageline(
        $bild,
        random_int(0, $breite-1),
        random_int(0, $hoehe-1),
        random_int(0, $breite-1),
        random_int(0, $hoehe-1),
        $störfarbe
    );
}

// Header & Bild ausgeben
header('Content-Type: image/png');
header('Cache-Control: no-store, no-cache, must-revalidate');
imagepng($bild);
imagedestroy($bild);