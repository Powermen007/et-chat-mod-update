<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

echo '<script src="js/uhr.js"></script>';
echo '<center style="margin-top:20px;"><b>';

/* Wochentage */
$days = [
    1 => 'Mo.',
    2 => 'Di.',
    3 => 'Mi.',
    4 => 'Do.',
    5 => 'Fr.',
    6 => 'Sa.',
    7 => 'So.'
];

/* Monate */
$months = [
    1  => 'Januar',
    2  => 'Februar',
    3  => 'M&auml;rz',
    4  => 'April',
    5  => 'Mai',
    6  => 'Juni',
    7  => 'Juli',
    8  => 'August',
    9  => 'September',
    10 => 'Oktober',
    11 => 'November',
    12 => 'Dezember'
];

$dayNumber   = (int) date('N');
$monthNumber = (int) date('n');

echo $days[$dayNumber] . ' ';
echo date('d');
echo '. ' . $months[$monthNumber] . ' ';
echo date('Y');

echo '<br><span id="localtime"></span></b></center>';