<?php 
// Konfigurationsdatei einbinden
include 'box_config.php';

// Modi-Button zur Wunschbox von Chrno © 2025 | Für ET-Chat_T-FISH-MOD
// Funktioniert nur in Verbindung mit meiner wunschbox.php

// Seite automatisch alle X Sekunden neu laden (definiert durch $modiButton)
header("Refresh: $modiButton");

// Verbindung zur Datenbank aufbauen
$connection = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Fehler bei der Verbindung prüfen
if ($connection->connect_errno) {
    die('Connection Error: ' . $connection->connect_error);
}

// SQL-Abfrage vorbereiten (Benutzerabhängiger Abruf von Wunschbox-Texten)
$query = "SELECT von_wen FROM web_php_plugin_" . $web_php_id . "_radio_wunschbox_text ORDER BY von_wen DESC LIMIT 1";
$result = $connection->query($query);

// Wenn Ergebnisse gefunden wurden
if ($result->num_rows > 0) {
    while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
        // Wenn ein neuer Wunsch vorliegt
        echo '<div style="text-align: center; padding-top: 3px;"><span style="color: red;">Neuer Musikwunsch</span></div>';
    }
} else {
    // Wenn keine Wünsche vorhanden sind
    echo '<div style="text-align: center; padding-top: 3px;"><span>Wunschbox</span></div>';
}

$connection->close();
?>

