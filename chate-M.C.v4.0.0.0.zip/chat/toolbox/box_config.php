<?php
/*
	Wunschbox und Sendeplan von Chrno © 2025 | Für ET-Chat_T-FISH-MOD
	Diese Scripte unterstützten Webseiten auf Basis von Web-PHP
	Es werden die Zugangsdaten zur Datenbank der Homepage und dessen ID 'web_php_14458_' benötigt
	Für die Bilder bitte die Domain zur Webseite eintragen
*/

/* Datenbank zur Homepage */
$dbhost='xxx';
$dbuser='xxx';
$dbpass='xxx';
$dbname='xxx';
$web_php_id='xxx';
$web_php_domain='https://dance-music-radio.de';

// Pfad zum Auto DJ Bild
$auto_dj_bild = $web_php_domain . '/plugins/images/radio_sendeplan/autodj.png';

/* ModiButton alle 30 Sekunden prüfen */
$modiButton = 30;

?>