
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_bewerbungen`
--

CREATE TABLE `###prefix###etchat_bewerbungen` (
  `id` int(10) UNSIGNED NOT NULL,
  `bewerber_daten` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('neu','in Bearbeitung','angenommen','abgelehnt','gegangen') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neu',
  `kommentar` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `erstellt_am` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_bewerbung_fields`
--

CREATE TABLE `###prefix###etchat_bewerbung_fields` (
  `etchat_id` int(11) NOT NULL,
  `etchat_field_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_field_type` enum('text','email','select','checkbox','textarea','date') COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_options` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON-kodierte Optionen für select/checkbox',
  `etchat_required` tinyint(1) DEFAULT 0,
  `etchat_visible` tinyint(1) DEFAULT 1,
  `etchat_sort_order` int(11) DEFAULT 0,
  `etchat_custom` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_bewerbung_fields`
--

INSERT INTO `###prefix###etchat_bewerbung_fields` (`etchat_id`, `etchat_field_name`, `etchat_field_type`, `etchat_options`, `etchat_required`, `etchat_visible`, `etchat_sort_order`, `etchat_custom`) VALUES
(1, 'Betreff', 'select', '[\"Moderator Bewerbung\",\"Gast Moderator Bewerbung\",\"Gelegenheitsmoderator Bewerbung\",\"Chatwache\",\"Grafiker\",\"Techniker\",\"Sponsor\"]', 1, 1, 0, 0),
(2, 'E-Mail', 'email', NULL, 1, 1, 1, 0),
(3, 'Anrede', 'select', '[\"Herr\",\"Frau\",\"Divers\"]', 0, 1, 2, 0),
(4, 'Name', 'text', NULL, 1, 1, 3, 0),
(5, 'Modiename', 'text', NULL, 0, 1, 4, 0),
(6, 'Telefon', 'text', NULL, 0, 1, 5, 0),
(7, 'Alter', 'text', NULL, 1, 1, 6, 0),
(8, 'Geburtsdatum', 'date', NULL, 0, 1, 7, 0),
(9, 'Ort', 'text', NULL, 1, 1, 8, 0),
(10, 'Beruf', 'select', '[\"Vollzeit berufstätig\",\"Teilzeit berufstätig\",\"Schichtarbeit\",\"Selbstständig\",\"Rentner(in)\",\"Arbeitssuchend / aktuell ohne Job\",\"Schüler(in)\",\"Student(in)\",\"Sonstiges\"]', 0, 1, 9, 0),
(11, 'Betriebssystem', 'select', '[\"Windows 11\",\"Windows 10\",\"Windows 8.1\",\"MacOS\",\"Linux\"]', 1, 1, 10, 0),
(12, 'CPU', 'text', NULL, 0, 1, 11, 0),
(13, 'Arbeitsspeicher', 'select', '[\"Ich habe 8 GB RAM\",\"Ich habe 16 GB RAM\",\"Ich habe 24 GB RAM\",\"Ich habe 32 GB RAM\",\"Ich habe 48 GB RAM\",\"Ich habe 64 GB RAM\",\"Ich habe mehr als 64 GB RAM\"]', 0, 1, 12, 0),
(14, 'Weitere Angaben Hardware', 'text', NULL, 0, 1, 13, 0),
(15, 'Internetverbindung', 'text', NULL, 0, 1, 14, 0),
(16, 'Musikarchiv', 'text', NULL, 1, 1, 15, 0),
(17, 'Streamerfahrung', 'select', '[\"Ich bin Neuling\",\"Ich habe weniger als 1 Jahr Erfahrung\",\"Ich habe mehr als 1 Jahr Erfahrung\",\"Ich habe mehr als 2 Jahr Erfahrung\",\"Ich habe mehr als 3 Jahr Erfahrung\",\"Ich habe mehr als 5 Jahr Erfahrung\"]', 1, 1, 16, 0),
(18, 'Sendesoftware', 'select', '[\"Radio Boss\",\"Mixxx\",\"Virtual DJ\",\"Flatcast Player\",\"BPM Studio\",\"Winamp\",\"Sam Broadcast 3\",\"Sam Broadcast 4\",\"Sonstiger Player\"]', 1, 1, 18, 0),
(19, 'Sendezeiten', 'select', '[\"Ich sende bevorzugt morgens\",\"Ich sende bevorzugt mittags\",\"Ich sende bevorzugt abends\",\"Ich sende bevorzugt nachts\",\"Flexibel\"]', 1, 1, 19, 0),
(20, 'Musikrichtung', 'checkbox', '[\"Schlager\",\"Techno\",\"Hip Hop\",\"Rap\",\"Trance\",\"Discofox\",\"Dance\",\"Electronic\",\"Gothic\",\"Rock\",\"Oldies\",\"Volksmusik\",\"Soul\",\"Funk\",\"Folk\",\"Pop\",\"House\",\"Country\",\"80er\",\"90er\",\"2000er\",\"Charts\",\"Sonstiges\",\"Alles\"]', 1, 1, 21, 0),
(21, 'Nachricht', 'textarea', NULL, 0, 1, 22, 0),
(22, 'Streamerfahrungen wenn ja wo', 'text', NULL, 0, 1, 17, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_blacklist`
--

CREATE TABLE `###prefix###etchat_blacklist` (
  `etchat_blacklist_id` int(8) NOT NULL,
  `etchat_blacklist_ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_blacklist_userid` int(8) NOT NULL,
  `etchat_blacklist_time` int(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_config`
--

CREATE TABLE `###prefix###etchat_config` (
  `etchat_config_id` int(11) NOT NULL,
  `etchat_config_radio_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_reloadsequenz` int(11) NOT NULL,
  `etchat_config_messages_im_chat` int(11) NOT NULL,
  `etchat_config_style` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_loeschen_nach` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_lang` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_wu` int(4) NOT NULL,
  `etchat_config_wuan` int(5) NOT NULL,
  `etchat_config_wuza` tinyint(2) NOT NULL,
  `etchat_config_wupau` tinyint(2) NOT NULL,
  `etchat_config_yo` int(4) NOT NULL,
  `etchat_config_bi` int(4) NOT NULL,
  `etchat_config_biup` int(4) NOT NULL,
  `etchat_config_av` int(4) NOT NULL,
  `etchat_config_pro` tinyint(1) NOT NULL,
  `etchat_config_onlie_li` tinyint(1) NOT NULL,
  `etchat_config_radio_box` int(4) NOT NULL,
  `etchat_config_radio_box_hi` int(3) NOT NULL,
  `etchat_config_radio_box_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_wb` int(3) NOT NULL,
  `etchat_config_wb_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_user_online` int(3) NOT NULL,
  `etchat_config_name_user` tinyint(1) NOT NULL,
  `etchat_config_name_user_anz` tinyint(3) NOT NULL DEFAULT 10,
  `etchat_config_vollbild` int(3) NOT NULL,
  `etchat_config_admin_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_mod_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_user_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_gast_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_time` tinyint(1) NOT NULL,
  `etchat_config_chat_gender` tinyint(1) NOT NULL,
  `etchat_config_chat_privi` tinyint(1) NOT NULL,
  `etchat_config_chat_anzsmily` tinyint(2) NOT NULL DEFAULT 5,
  `etchat_config_ol_privi` tinyint(1) NOT NULL,
  `etchat_config_be_in_pic` tinyint(1) NOT NULL,
  `etchat_config_chat_pic` tinyint(1) NOT NULL,
  `etchat_config_scroll` tinyint(1) NOT NULL,
  `etchat_config_dj_box_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_dj_box` tinyint(1) NOT NULL,
  `etchat_config_radio_se_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_radio_se` tinyint(1) NOT NULL,
  `etchat_config_reg_user_an` tinyint(1) NOT NULL,
  `etchat_config_gast` tinyint(1) NOT NULL,
  `etchat_config_wartung` tinyint(1) NOT NULL,
  `etchat_config_reg_an_aus` tinyint(1) NOT NULL,
  `etchat_config_index_team` tinyint(1) DEFAULT 1,
  `etchat_config_team` tinyint(1) DEFAULT 1,
  `etchat_config_index_bewer` tinyint(1) DEFAULT 1,
  `etchat_config_bewer` tinyint(1) DEFAULT 1,
  `etchat_top_user_onoff` tinyint(1) NOT NULL,
  `etchat_top_user` tinyint(2) NOT NULL,
  `etchat_bot` tinyint(2) NOT NULL,
  `etchat_tab_away_delay` int(4) NOT NULL DEFAULT 150
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_config`
--

INSERT INTO `###prefix###etchat_config` (`etchat_config_id`, `etchat_config_radio_name`, `etchat_config_reloadsequenz`, `etchat_config_messages_im_chat`, `etchat_config_style`, `etchat_config_loeschen_nach`, `etchat_config_lang`, `etchat_config_wu`, `etchat_config_wuan`, `etchat_config_wuza`, `etchat_config_wupau`, `etchat_config_yo`, `etchat_config_bi`, `etchat_config_biup`, `etchat_config_av`, `etchat_config_pro`, `etchat_config_onlie_li`, `etchat_config_radio_box`, `etchat_config_radio_box_hi`, `etchat_config_radio_box_li`, `etchat_config_wb`, `etchat_config_wb_li`, `etchat_config_user_online`, `etchat_config_name_user`, `etchat_config_name_user_anz`, `etchat_config_vollbild`, `etchat_config_admin_color`, `etchat_config_mod_color`, `etchat_config_user_color`, `etchat_config_gast_color`, `etchat_config_time`, `etchat_config_chat_gender`, `etchat_config_chat_privi`, `etchat_config_chat_anzsmily`, `etchat_config_ol_privi`, `etchat_config_be_in_pic`, `etchat_config_chat_pic`, `etchat_config_scroll`, `etchat_config_dj_box_li`, `etchat_config_dj_box`, `etchat_config_radio_se_li`, `etchat_config_radio_se`, `etchat_config_reg_user_an`, `etchat_config_gast`, `etchat_config_wartung`, `etchat_config_reg_an_aus`, `etchat_config_index_team`, `etchat_config_team`, `etchat_config_index_bewer`, `etchat_config_bewer`, `etchat_top_user_onoff`, `etchat_top_user`, `etchat_bot`, `etchat_tab_away_delay`) VALUES
(1, 'ET-Chat_Two_M.C.v.4.0.0.0', 5000, 100, 'etchat_dino_styles', '14', 'Deutsch', 1, 100, 4, 2, 1, 1, 1, 1, 1, 1, 1, 160, 'radio-box/radio-box.php', 1, '/sendeplan/index.php?page=wunschbox', 1, 1, 10, 1, '#ff0000', '#864b4b', '#00FF00', '#FFFF00', 1, 1, 1, 5, 1, 1, 1, 1, '/sendeplan/index.php?page=login', 1, '/sendeplan/index.php', 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 10, 1, 300);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_kick_user`
--

CREATE TABLE `###prefix###etchat_kick_user` (
  `id` int(11) NOT NULL,
  `etchat_kicked_user_id` int(11) NOT NULL,
  `etchat_kicked_user_time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_kontakt`
--

CREATE TABLE `###prefix###etchat_kontakt` (
  `etchat_id` int(10) UNSIGNED NOT NULL,
  `etchat_kontakt_daten` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_status` enum('neu','bearbeitung_admin','bearbeitung_coadmin','bearbeitung_chatwache','abgeschlossen') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neu',
  `etchat_kommentar` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_erstellt_am` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_kontakt_fields`
--

CREATE TABLE `###prefix###etchat_kontakt_fields` (
  `etchat_id` int(11) NOT NULL,
  `etchat_field_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_field_type` enum('text','email','select','checkbox','textarea','date') COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_options` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON-kodierte Optionen für select/checkbox',
  `etchat_required` tinyint(1) DEFAULT 0,
  `etchat_visible` tinyint(1) DEFAULT 1,
  `etchat_sort_order` int(11) DEFAULT 0,
  `etchat_custom` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_kontakt_fields`
--

INSERT INTO `###prefix###etchat_kontakt_fields` (`etchat_id`, `etchat_field_name`, `etchat_field_type`, `etchat_options`, `etchat_required`, `etchat_visible`, `etchat_sort_order`, `etchat_custom`) VALUES
(1, 'Betreff', 'select', '[\"Sonstige\",\"Allgemein\",\"Musik\",\"Beschwerde\"]', 1, 1, 0, 0),
(2, 'E-Mail', 'email', NULL, 1, 1, 1, 0),
(3, 'Anrede', 'select', '[\"Herr\",\"Frau\",\"Divers\",\"Homo/Gay\",\"Transsexuel\"]', 0, 1, 2, 0),
(4, 'Name', 'text', NULL, 1, 1, 3, 0),
(5, 'Telefon', 'text', NULL, 0, 1, 4, 0),
(6, 'Ort', 'text', NULL, 0, 1, 5, 0),
(7, 'Nachricht', 'textarea', NULL, 1, 1, 6, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_menu`
--

CREATE TABLE `###prefix###etchat_menu` (
  `id` int(10) NOT NULL,
  `menu` int(1) NOT NULL,
  `link_text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_active` int(1) NOT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `gewicht` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_menu`
--

INSERT INTO `###prefix###etchat_menu` (`id`, `menu`, `link_text`, `image_active`, `image`, `url`, `target`, `gewicht`) VALUES
(1, 1, 'Homepage', 1, 'homepage.png', 'http://chris.pcip.de/joomla/', '_blank', 10),
(2, 1, 'Teamspeak', 1, 'teamspeak.png', 'ts3server://chris.pcip.de', '_blank', 30),
(3, 3, 'Banner', 1, 'banner_1.jpg', 'http://chris.pcip.de/joomla/', '_blank', 10),
(4, 3, 'Dance Music Radio', 1, 'dmr.png', 'https://dance-music-radio.de', '_blank', 20),
(5, 2, 'Sendeplan', 0, '', '#\" onClick=\"window.open(\'http://chris.pcip.de/sendeplan/index.php?page=start\',\'\',\'width=800,height=500\'); return false;\"', '_blank', 5),
(6, 2, 'Wunsch und Gruß- Box', 0, '', '#\" onClick=\"window.open(\'http://chris.pcip.de/sendeplan/index.php?page=wunschbox\',\'\',\'width=800,height=500\'); return false;\"', '_blank', 10),
(7, 2, 'Impressum', 0, '', '#\" onClick=\"window.open(\'http://chris.pcip.de/chat/?Text&id=1\',\'\',\'width=800,height=600\'); return false;\"', '_blank', 15),
(8, 2, 'Kontakt', 0, '', '#\" onClick=\"window.open(\'http://chris.pcip.de/chat/kontakt.php\',\'\',\'width=800,height=600\'); return false;\"', '_blank', 20),
(9, 2, 'Player', 0, '', '#\" onClick=\"window.open(\'http://chris.pcip.de/chat/radio-box/radio-box.php\',\'\',\'width=250,height=160\'); return false;\"', '_blank', 25);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_messages`
--

CREATE TABLE `###prefix###etchat_messages` (
  `etchat_id` bigint(20) UNSIGNED NOT NULL,
  `etchat_user_fid` int(8) NOT NULL,
  `etchat_text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_text_css` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_timestamp` bigint(20) NOT NULL,
  `etchat_fid_room` int(11) NOT NULL DEFAULT 1,
  `etchat_privat` int(8) DEFAULT 0,
  `etchat_user_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_radio_box`
--

CREATE TABLE `###prefix###etchat_radio_box` (
  `etchat_radio_id` int(1) NOT NULL,
  `etchat_radio_horst` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_port` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_radio_typ` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_stream` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_bit` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_box` tinyint(1) NOT NULL,
  `etchat_radio_player` tinyint(1) NOT NULL,
  `etchat_on_air` tinyint(1) NOT NULL,
  `etchat_system_titel_an` tinyint(1) NOT NULL DEFAULT 1,
  `etchat_titel_an` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_radio_box`
--

INSERT INTO `###prefix###etchat_radio_box` (`etchat_radio_id`, `etchat_radio_horst`, `etchat_radio_port`, `etchat_radio_typ`, `etchat_radio_stream`, `etchat_radio_name`, `etchat_radio_color`, `etchat_radio_bit`, `etchat_radio_box`, `etchat_radio_player`, `etchat_on_air`, `etchat_system_titel_an`, `etchat_titel_an`) VALUES
(1, 'dance-music-radio.de', '8002', 'shoutcast', 'https://dance-music-radio.de:8002/stream.mp3', '0', '0', '256', 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_radio_history`
--

CREATE TABLE `###prefix###etchat_radio_history` (
  `etchat_id` int(11) NOT NULL,
  `etchat_song_title` varchar(255) NOT NULL,
  `etchat_song_artist` varchar(255) DEFAULT '',
  `etchat_dj_name` varchar(100) DEFAULT 'Auto DJ',
  `etchat_played_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_rooms`
--

CREATE TABLE `###prefix###etchat_rooms` (
  `etchat_id_room` int(3) UNSIGNED NOT NULL,
  `etchat_roomname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_room_goup` int(6) NOT NULL DEFAULT 0,
  `etchat_room_pw` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_room_message` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_rooms`
--

INSERT INTO `###prefix###etchat_rooms` (`etchat_id_room`, `etchat_roomname`, `etchat_room_goup`, `etchat_room_pw`, `etchat_room_message`) VALUES
(1, 'Lobby', 0, NULL, 'Hallo, schön das du zu uns gefunden hast, schau dich um, bei Fragen einfach melden.');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_smileys`
--

CREATE TABLE `###prefix###etchat_smileys` (
  `etchat_smileys_id` int(5) NOT NULL,
  `etchat_smileys_kat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_smileys_sign` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_smileys_img` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_smileys_gewicht` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_smileys_cat`
--

CREATE TABLE `###prefix###etchat_smileys_cat` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aktiv` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gewicht` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_smileys_cat`
--

INSERT INTO `###prefix###etchat_smileys_cat` (`id`, `name`, `aktiv`, `gewicht`) VALUES
(1, 'Winter', 'off', 190),
(2, 'Frühling', 'on', 200),
(3, 'Herbst', 'off', 220),
(4, 'Team', 'on', 90),
(5, 'Ostern', 'off', 240),
(6, 'Weihnachten', 'off', 270),
(7, 'Helloween', 'off', 250),
(8, 'Silvester', 'off', 280),
(9, 'Karneval', 'off', 230),
(10, 'Oktoberfest', 'off', 260),
(11, 'Ab 18 ...', 'on', 290),
(12, 'Sommer', 'off', 210),
(13, 'Essen/Trinken', 'on', 150),
(14, 'Modi', 'on', 100),
(15, 'Geburstag', 'on', 160),
(16, 'Feuerwerk', 'on', 170),
(17, 'Bitte/Danke', 'on', 110),
(18, 'Lieb haben', 'on', 140),
(19, 'Sendungen', 'on', 80),
(20, 'Lachen/Weinen', 'on', 130),
(21, 'Fun', 'on', 120),
(22, 'Comic/Tiere', 'on', 50),
(23, 'Rock/Gothic/Country', 'on', 60),
(24, 'Disco', 'on', 40),
(25, 'Tanzen', 'on', 30),
(26, 'Instrumente', 'on', 70),
(27, 'Fußball', 'off', 180),
(28, 'Verabschieden', 'on', 20),
(29, 'Begrüßen', 'on', 10);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_start_boxes`
--

CREATE TABLE `###prefix###etchat_start_boxes` (
  `id` int(10) UNSIGNED NOT NULL,
  `ort` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_start_boxes`
--

INSERT INTO `###prefix###etchat_start_boxes` (`id`, `ort`, `header_text`, `content`) VALUES
(1, 'Index Box Li.', 'Chat', '<p style=\"text-align: center;\">Wir w&uuml;nschen euch viel Spass &amp; eine sch&ouml;ne Unterhaltung im Chat.&nbsp;<br>Die amtssprache ist 🇩🇪 😃</p>\r\n<p style=\"text-align: center;\"><span style=\"font-size: 10pt;\">Ihr k&ouml;nnt den Chat jederzeit als Gast betreten.</span><br><span style=\"font-size: 8pt;\">Achte darauf das Ihr&nbsp;</span></p>\r\n<ol>\r\n<li style=\"text-align: left; font-size: 8pt;\"><span style=\"font-size: 8pt;\">Cookies im Browser zugelassen habt</span></li>\r\n<li style=\"text-align: left; font-size: 8pt;\"><span style=\"font-size: 8pt;\">Eure Name mindestens 4 Zeichen lang ist</span></li>\r\n<li style=\"text-align: left; font-size: 8pt;\"><span style=\"font-size: 8pt;\">Cookies und Datenschutz akzeptiert</span></li>\r\n</ol>\r\n<p style=\"font-size: 8pt; text-align: center;\"><span style=\"font-size: 10pt;\">Los gehts!</span></p>'),
(2, 'Index Box Re.', 'Wir bieten Jede Menge Spaß', '<p style=\"text-align: center;\">Ihr k&ouml;nnt den Chat jederzeit als Gast betreten.<br>🔒 Es steht euch frei, euren Benutzernamen mit einem Passwort zu sichern.</p>\r\n<p>So wird es gemacht:</p>\r\n<ol>\r\n<li style=\"font-size: 8pt;\"><span style=\"font-size: 8pt;\">Klickt auf Registrieren / Passwort vergessen.</span></li>\r\n<li style=\"font-size: 8pt;\"><span style=\"font-size: 8pt;\">F&uuml;llt das Formular aus mit E-Mail-Adresse.</span></li>\r\n<li style=\"font-size: 8pt;\"><span style=\"font-size: 8pt;\">Geht in euer E-Mail Postfach (evtl. Spam) und folgt dem Link innerhalb von 30 min.</span></li>\r\n<li style=\"font-size: 8pt;\"><span style=\"font-size: 8pt;\">Die E-Mail-Adresse ist wichtig! Zum Freischalten und falls ihr euer Passwort vergesst!</span></li>\r\n</ol>\r\n<p>Somit ist euer Name gesch&uuml;tzt</p>\r\n<p style=\"text-align: center;\">Wir w&uuml;nschen euch viel Spass &amp; sch&ouml;ne Unterhaltung im Chat</p>'),
(3, 'Index Oben Text', 'Index Oben', '<p style=\"text-align: center;\">Index Text Oben</p>'),
(4, 'Index Unten Text', 'Index Unten', '<p style=\"text-align: center;\">Index Text Unten</p>');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_texte`
--

CREATE TABLE `###prefix###etchat_texte` (
  `id` int(10) UNSIGNED NOT NULL,
  `ort` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_texte`
--

INSERT INTO `###prefix###etchat_texte` (`id`, `ort`, `header_text`, `content`) VALUES
(1, 'Impressum', 'Impressum', '<p><span style=\"color: #ffffff;\">Chris &amp; Mike Stra&szlig;e Nr. PLZ / Ort</span></p>\r\n<p><span style=\"color: #ffffff;\"><a title=\"Kontaktformular\" href=\"kontakt.php\">Kontakt</a></span></p>'),
(2, 'Datenschutz', 'Datenschutz', '<h1><span style=\"color: #ffffff;\">Datenschutzerkl&auml;rung</span></h1>\r\n<p><span style=\"color: #ffffff;\">Stand: 29. Mai 2025</span></p>\r\n<h2><span style=\"color: #ffffff;\">Inhalts&uuml;bersicht</span></h2>\r\n<ul class=\"index\">\r\n<li><a class=\"index-link\" href=\"#m3\">Verantwortlicher</a></li>\r\n<li><a class=\"index-link\" href=\"#mOverview\">&Uuml;bersicht der Verarbeitungen</a></li>\r\n<li><a class=\"index-link\" href=\"#m2427\">Ma&szlig;gebliche Rechtsgrundlagen</a></li>\r\n<li><a class=\"index-link\" href=\"#m27\">Sicherheitsma&szlig;nahmen</a></li>\r\n<li><a class=\"index-link\" href=\"#m12\">Allgemeine Informationen zur Datenspeicherung und L&ouml;schung</a></li>\r\n<li><a class=\"index-link\" href=\"#m225\">Bereitstellung des Onlineangebots und Webhosting</a></li>\r\n<li><a class=\"index-link\" href=\"#m134\">Einsatz von Cookies</a></li>\r\n<li><a class=\"index-link\" href=\"#m367\">Registrierung, Anmeldung und Nutzerkonto</a></li>\r\n<li><a class=\"index-link\" href=\"#m432\">Community Funktionen</a></li>\r\n<li><a class=\"index-link\" href=\"#m182\">Kontakt- und Anfrageverwaltung</a></li>\r\n<li><a class=\"index-link\" href=\"#m296\">Audioinhalte</a></li>\r\n</ul>\r\n<h2 id=\"m3\"><span style=\"color: #ffffff;\">Verantwortlicher</span></h2>\r\n<p><span style=\"color: #ffffff;\">Vorname Name</span><br><span style=\"color: #ffffff;\">Stra&szlig;e</span><br><span style=\"color: #ffffff;\">Ort PLZ</span></p>\r\n<p><span style=\"color: #ffffff;\">E-Mail-Adresse: <a style=\"color: #ffffff;\" href=\"mailto:email@email.de\">email@email.de</a></span></p>\r\n<h2 id=\"mOverview\"><span style=\"color: #ffffff;\">&Uuml;bersicht der Verarbeitungen</span></h2>\r\n<p><span style=\"color: #ffffff;\">Die nachfolgende &Uuml;bersicht fasst die Arten der verarbeiteten Daten und die Zwecke ihrer Verarbeitung zusammen und verweist auf die betroffenen Personen.</span></p>\r\n<h3><span style=\"color: #ffffff;\">Arten der verarbeiteten Daten</span></h3>\r\n<ul>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Bestandsdaten.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Kontaktdaten.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Inhaltsdaten.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Nutzungsdaten.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Meta-, Kommunikations- und Verfahrensdaten.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Protokolldaten.</span></li>\r\n</ul>\r\n<h3><span style=\"color: #ffffff;\">Kategorien betroffener Personen</span></h3>\r\n<ul>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Kommunikationspartner.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Nutzer.</span></li>\r\n</ul>\r\n<h3><span style=\"color: #ffffff;\">Zwecke der Verarbeitung</span></h3>\r\n<ul>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Erbringung vertraglicher Leistungen und Erf&uuml;llung vertraglicher Pflichten.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Kommunikation.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Sicherheitsma&szlig;nahmen.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Reichweitenmessung.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Organisations- und Verwaltungsverfahren.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Feedback.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Profile mit nutzerbezogenen Informationen.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">Informationstechnische Infrastruktur.</span></li>\r\n</ul>\r\n<h2 id=\"m2427\"><span style=\"color: #ffffff;\">Ma&szlig;gebliche Rechtsgrundlagen</span></h2>\r\n<p><span style=\"color: #ffffff;\"><strong>Ma&szlig;gebliche Rechtsgrundlagen nach der DSGVO: </strong>Im Folgenden erhalten Sie eine &Uuml;bersicht der Rechtsgrundlagen der DSGVO, auf deren Basis wir personenbezogene Daten verarbeiten. Bitte nehmen Sie zur Kenntnis, dass neben den Regelungen der DSGVO nationale Datenschutzvorgaben in Ihrem bzw. unserem Wohn- oder Sitzland gelten k&ouml;nnen. Sollten ferner im Einzelfall speziellere Rechtsgrundlagen ma&szlig;geblich sein, teilen wir Ihnen diese in der Datenschutzerkl&auml;rung mit.</span></p>\r\n<ul>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Einwilligung (Art. 6 Abs. 1 S. 1 lit. a) DSGVO)</strong> - Die betroffene Person hat ihre Einwilligung in die Verarbeitung der sie betreffenden personenbezogenen Daten f&uuml;r einen spezifischen Zweck oder mehrere bestimmte Zwecke gegeben.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO)</strong> - Die Verarbeitung ist f&uuml;r die Erf&uuml;llung eines Vertrags, dessen Vertragspartei die betroffene Person ist, oder zur Durchf&uuml;hrung vorvertraglicher Ma&szlig;nahmen erforderlich, die auf Anfrage der betroffenen Person erfolgen.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO)</strong> - die Verarbeitung ist zur Wahrung der berechtigten Interessen des Verantwortlichen oder eines Dritten notwendig, vorausgesetzt, dass die Interessen, Grundrechte und Grundfreiheiten der betroffenen Person, die den Schutz personenbezogener Daten verlangen, nicht &uuml;berwiegen.</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Nationale Datenschutzregelungen in Deutschland: </strong>Zus&auml;tzlich zu den Datenschutzregelungen der DSGVO gelten nationale Regelungen zum Datenschutz in Deutschland. Hierzu geh&ouml;rt insbesondere das Gesetz zum Schutz vor Missbrauch personenbezogener Daten bei der Datenverarbeitung (Bundesdatenschutzgesetz &ndash; BDSG). Das BDSG enth&auml;lt insbesondere Spezialregelungen zum Recht auf Auskunft, zum Recht auf L&ouml;schung, zum Widerspruchsrecht, zur Verarbeitung besonderer Kategorien personenbezogener Daten, zur Verarbeitung f&uuml;r andere Zwecke und zur &Uuml;bermittlung sowie automatisierten Entscheidungsfindung im Einzelfall einschlie&szlig;lich Profiling. Ferner k&ouml;nnen Landesdatenschutzgesetze der einzelnen Bundesl&auml;nder zur Anwendung gelangen.</span></p>\r\n<p><span style=\"color: #ffffff;\"><strong>Hinweis auf Geltung DSGVO und Schweizer DSG: </strong>Diese Datenschutzhinweise dienen sowohl der Informationserteilung nach dem Schweizer DSG als auch nach der Datenschutzgrundverordnung (DSGVO). Aus diesem Grund bitten wir Sie zu beachten, dass aufgrund der breiteren r&auml;umlichen Anwendung und Verst&auml;ndlichkeit die Begriffe der DSGVO verwendet werden. Insbesondere statt der im Schweizer DSG verwendeten Begriffe &bdquo;Bearbeitung\" von &bdquo;Personendaten\", \"&uuml;berwiegendes Interesse\" und \"besonders sch&uuml;tzenswerte Personendaten\" werden die in der DSGVO verwendeten Begriffe &bdquo;Verarbeitung\" von &bdquo;personenbezogenen Daten\" sowie \"berechtigtes Interesse\" und \"besondere Kategorien von Daten\" verwendet. Die gesetzliche Bedeutung der Begriffe wird jedoch im Rahmen der Geltung des Schweizer DSG weiterhin nach dem Schweizer DSG bestimmt.</span></p>\r\n<h2 id=\"m27\"><span style=\"color: #ffffff;\">Sicherheitsma&szlig;nahmen</span></h2>\r\n<p><span style=\"color: #ffffff;\">Wir treffen nach Ma&szlig;gabe der gesetzlichen Vorgaben unter Ber&uuml;cksichtigung des Stands der Technik, der Implementierungskosten und der Art, des Umfangs, der Umst&auml;nde und der Zwecke der Verarbeitung sowie der unterschiedlichen Eintrittswahrscheinlichkeiten und des Ausma&szlig;es der Bedrohung der Rechte und Freiheiten nat&uuml;rlicher Personen geeignete technische und organisatorische Ma&szlig;nahmen, um ein dem Risiko angemessenes Schutzniveau zu gew&auml;hrleisten.</span></p>\r\n<p><span style=\"color: #ffffff;\">Zu den Ma&szlig;nahmen geh&ouml;ren insbesondere die Sicherung der Vertraulichkeit, Integrit&auml;t und Verf&uuml;gbarkeit von Daten durch Kontrolle des physischen und elektronischen Zugangs zu den Daten als auch des sie betreffenden Zugriffs, der Eingabe, der Weitergabe, der Sicherung der Verf&uuml;gbarkeit und ihrer Trennung. Des Weiteren haben wir Verfahren eingerichtet, die eine Wahrnehmung von Betroffenenrechten, die L&ouml;schung von Daten und Reaktionen auf die Gef&auml;hrdung der Daten gew&auml;hrleisten. Ferner ber&uuml;cksichtigen wir den Schutz personenbezogener Daten bereits bei der Entwicklung bzw. Auswahl von Hardware, Software sowie Verfahren entsprechend dem Prinzip des Datenschutzes, durch Technikgestaltung und durch datenschutzfreundliche Voreinstellungen.</span></p>\r\n<p><span style=\"color: #ffffff;\">Sicherung von Online-Verbindungen durch TLS-/SSL-Verschl&uuml;sselungstechnologie (HTTPS): Um die Daten der Nutzer, die &uuml;ber unsere Online-Dienste &uuml;bertragen werden, vor unerlaubten Zugriffen zu sch&uuml;tzen, setzen wir auf die TLS-/SSL-Verschl&uuml;sselungstechnologie. Secure Sockets Layer (SSL) und Transport Layer Security (TLS) sind die Eckpfeiler der sicheren Daten&uuml;bertragung im Internet. Diese Technologien verschl&uuml;sseln die Informationen, die zwischen der Website oder App und dem Browser des Nutzers (oder zwischen zwei Servern) &uuml;bertragen werden, wodurch die Daten vor unbefugtem Zugriff gesch&uuml;tzt sind. TLS, als die weiterentwickelte und sicherere Version von SSL, gew&auml;hrleistet, dass alle Daten&uuml;bertragungen den h&ouml;chsten Sicherheitsstandards entsprechen. Wenn eine Website durch ein SSL-/TLS-Zertifikat gesichert ist, wird dies durch die Anzeige von HTTPS in der URL signalisiert. Dies dient als ein Indikator f&uuml;r die Nutzer, dass ihre Daten sicher und verschl&uuml;sselt &uuml;bertragen werden.</span></p>\r\n<h2 id=\"m12\"><span style=\"color: #ffffff;\">Allgemeine Informationen zur Datenspeicherung und L&ouml;schung</span></h2>\r\n<p><span style=\"color: #ffffff;\">Wir l&ouml;schen personenbezogene Daten, die wir verarbeiten, gem&auml;&szlig; den gesetzlichen Bestimmungen, sobald die zugrundeliegenden Einwilligungen widerrufen werden oder keine weiteren rechtlichen Grundlagen f&uuml;r die Verarbeitung bestehen. Dies betrifft F&auml;lle, in denen der urspr&uuml;ngliche Verarbeitungszweck entf&auml;llt oder die Daten nicht mehr ben&ouml;tigt werden. Ausnahmen von dieser Regelung bestehen, wenn gesetzliche Pflichten oder besondere Interessen eine l&auml;ngere Aufbewahrung oder Archivierung der Daten erfordern.</span></p>\r\n<p><span style=\"color: #ffffff;\">Insbesondere m&uuml;ssen Daten, die aus handels- oder steuerrechtlichen Gr&uuml;nden aufbewahrt werden m&uuml;ssen oder deren Speicherung notwendig ist zur Rechtsverfolgung oder zum Schutz der Rechte anderer nat&uuml;rlicher oder juristischer Personen, entsprechend archiviert werden.</span></p>\r\n<p><span style=\"color: #ffffff;\">Unsere Datenschutzhinweise enthalten zus&auml;tzliche Informationen zur Aufbewahrung und L&ouml;schung von Daten, die speziell f&uuml;r bestimmte Verarbeitungsprozesse gelten.</span></p>\r\n<p><span style=\"color: #ffffff;\">Bei mehreren Angaben zur Aufbewahrungsdauer oder L&ouml;schungsfristen eines Datums, ist stets die l&auml;ngste Frist ma&szlig;geblich.</span></p>\r\n<p><span style=\"color: #ffffff;\">Beginnt eine Frist nicht ausdr&uuml;cklich zu einem bestimmten Datum und betr&auml;gt sie mindestens ein Jahr, so startet sie automatisch am Ende des Kalenderjahres, in dem das fristausl&ouml;sende Ereignis eingetreten ist. Im Fall laufender Vertragsverh&auml;ltnisse, in deren Rahmen Daten gespeichert werden, ist das fristausl&ouml;sende Ereignis der Zeitpunkt des Wirksamwerdens der K&uuml;ndigung oder sonstige Beendigung des Rechtsverh&auml;ltnisses.</span></p>\r\n<p><span style=\"color: #ffffff;\">Daten, die nicht mehr f&uuml;r den urspr&uuml;nglich vorgesehenen Zweck, sondern aufgrund gesetzlicher Vorgaben oder anderer Gr&uuml;nde aufbewahrt werden, verarbeiten wir ausschlie&szlig;lich zu den Gr&uuml;nden, die ihre Aufbewahrung rechtfertigen.</span></p>\r\n<p><span style=\"color: #ffffff;\"><strong>Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:</strong></span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Aufbewahrung und L&ouml;schung von Daten: </strong>Die folgenden allgemeinen Fristen gelten f&uuml;r die Aufbewahrung und Archivierung nach deutschem Recht:</span>\r\n<ul>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">10 Jahre - Aufbewahrungsfrist f&uuml;r B&uuml;cher und Aufzeichnungen, Jahresabschl&uuml;sse, Inventare, Lageberichte, Er&ouml;ffnungsbilanz sowie die zu ihrem Verst&auml;ndnis erforderlichen Arbeitsanweisungen und sonstigen Organisationsunterlagen (&sect; 147 Abs. 1 Nr. 1 i.V.m. Abs. 3 AO, &sect; 14b Abs. 1 UStG, &sect; 257 Abs. 1 Nr. 1 i.V.m. Abs. 4 HGB).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">8 Jahre - Buchungsbelege, wie z.&nbsp;B. Rechnungen und Kostenbelege (&sect; 147 Abs. 1 Nr. 4 und 4a i.V.m. Abs. 3 Satz 1 AO sowie &sect; 257 Abs. 1 Nr. 4 i.V.m. Abs. 4 HGB).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">6 Jahre - &Uuml;brige Gesch&auml;ftsunterlagen: empfangene Handels- oder Gesch&auml;ftsbriefe, Wiedergaben der abgesandten Handels- oder Gesch&auml;ftsbriefe, sonstige Unterlagen, soweit sie f&uuml;r die Besteuerung von Bedeutung sind, z.&nbsp;B. Stundenlohnzettel, Betriebsabrechnungsb&ouml;gen, Kalkulationsunterlagen, Preisauszeichnungen, aber auch Lohnabrechnungsunterlagen, soweit sie nicht bereits Buchungsbelege sind und Kassenstreifen (&sect; 147 Abs. 1 Nr. 2, 3, 5 i.V.m. Abs. 3 AO, &sect; 257 Abs. 1 Nr. 2 u. 3 i.V.m. Abs. 4 HGB).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\">3 Jahre - Daten, die erforderlich sind, um potenzielle Gew&auml;hrleistungs- und Schadensersatzanspr&uuml;che oder &auml;hnliche vertragliche Anspr&uuml;che und Rechte zu ber&uuml;cksichtigen sowie damit verbundene Anfragen zu bearbeiten, basierend auf fr&uuml;heren Gesch&auml;ftserfahrungen und &uuml;blichen Branchenpraktiken, werden f&uuml;r die Dauer der regul&auml;ren gesetzlichen Verj&auml;hrungsfrist von drei Jahren gespeichert (&sect;&sect; 195, 199 BGB).</span></li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<h2 id=\"m225\"><span style=\"color: #ffffff;\">Bereitstellung des Onlineangebots und Webhosting</span></h2>\r\n<p><span style=\"color: #ffffff;\">Wir verarbeiten die Daten der Nutzer, um ihnen unsere Online-Dienste zur Verf&uuml;gung stellen zu k&ouml;nnen. Zu diesem Zweck verarbeiten wir die IP-Adresse des Nutzers, die notwendig ist, um die Inhalte und Funktionen unserer Online-Dienste an den Browser oder das Endger&auml;t der Nutzer zu &uuml;bermitteln.</span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Verarbeitete Datenarten:</strong> Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&auml;t und -frequenz, verwendete Ger&auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen); Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen). Protokolldaten (z.&nbsp;B. Logfiles betreffend Logins oder den Abruf von Daten oder Zugriffszeiten.).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Betroffene Personen:</strong> Nutzer (z.&nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Zwecke der Verarbeitung:</strong> Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit; Informationstechnische Infrastruktur (Betrieb und Bereitstellung von Informationssystemen und technischen Ger&auml;ten (Computer, Server etc.)). Sicherheitsma&szlig;nahmen.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Aufbewahrung und L&ouml;schung:</strong> L&ouml;schung entsprechend Angaben im Abschnitt \"Allgemeine Informationen zur Datenspeicherung und L&ouml;schung\".</span></li>\r\n<li class=\"\" style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Rechtsgrundlagen:</strong> Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:</strong></span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Erhebung von Zugriffsdaten und Logfiles: </strong>Der Zugriff auf unser Onlineangebot wird in Form von sogenannten \"Server-Logfiles\" protokolliert. Zu den Serverlogfiles k&ouml;nnen die Adresse und der Name der abgerufenen Webseiten und Dateien, Datum und Uhrzeit des Abrufs, &uuml;bertragene Datenmengen, Meldung &uuml;ber erfolgreichen Abruf, Browsertyp nebst Version, das Betriebssystem des Nutzers, Referrer URL (die zuvor besuchte Seite) und im Regelfall IP-Adressen und der anfragende Provider geh&ouml;ren. Die Serverlogfiles k&ouml;nnen zum einen zu Sicherheitszwecken eingesetzt werden, z.&nbsp;B. um eine &Uuml;berlastung der Server zu vermeiden (insbesondere im Fall von missbr&auml;uchlichen Angriffen, sogenannten DDoS-Attacken), und zum anderen, um die Auslastung der Server und ihre Stabilit&auml;t sicherzustellen; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). </span><strong>L&ouml;schung von Daten:</strong> Logfile-Informationen werden f&uuml;r die Dauer von maximal 30 Tagen gespeichert und danach gel&ouml;scht oder anonymisiert. Daten, deren weitere Aufbewahrung zu Beweiszwecken erforderlich ist, sind bis zur endg&uuml;ltigen Kl&auml;rung des jeweiligen Vorfalls von der L&ouml;schung ausgenommen.</span></li>\r\n</ul>\r\n<h2 id=\"m134\"><span style=\"color: #ffffff;\">Einsatz von Cookies</span></h2>\r\n<p><span style=\"color: #ffffff;\">Unter dem Begriff &bdquo;Cookies\" werden Funktionen, die Informationen auf Endger&auml;ten der Nutzer speichern und aus ihnen auslesen, verstanden. Cookies k&ouml;nnen ferner in Bezug auf unterschiedliche Anliegen Einsatz finden, etwa zu Zwecken der Funktionsf&auml;higkeit, der Sicherheit und des Komforts von Onlineangeboten sowie der Erstellung von Analysen der Besucherstr&ouml;me. Wir verwenden Cookies gem&auml;&szlig; den gesetzlichen Vorschriften. Dazu holen wir, wenn erforderlich, vorab die Zustimmung der Nutzer ein. Ist eine Zustimmung nicht notwendig, setzen wir auf unsere berechtigten Interessen. Dies gilt, wenn das Speichern und Auslesen von Informationen unerl&auml;sslich ist, um ausdr&uuml;cklich angeforderte Inhalte und Funktionen bereitstellen zu k&ouml;nnen. Dazu z&auml;hlen etwa die Speicherung von Einstellungen sowie die Sicherstellung der Funktionalit&auml;t und Sicherheit unseres Onlineangebots. Die Einwilligung kann jederzeit widerrufen werden. Wir informieren klar &uuml;ber deren Umfang und welche Cookies genutzt werden.</span></p>\r\n<p><span style=\"color: #ffffff;\"><strong>Hinweise zu datenschutzrechtlichen Rechtsgrundlagen: </strong>Ob wir personenbezogene Daten mithilfe von Cookies verarbeiten, h&auml;ngt von einer Einwilligung ab. Liegt eine Einwilligung vor, dient sie als Rechtsgrundlage. Ohne Einwilligung st&uuml;tzen wir uns auf unsere berechtigten Interessen, die vorstehend in diesem Abschnitt und im Kontext der jeweiligen Dienste und Verfahren erl&auml;utert sind.</span></p>\r\n<p><span style=\"color: #ffffff;\"><strong>Speicherdauer:&nbsp;</strong>Im Hinblick auf die Speicherdauer werden die folgenden Arten von Cookies unterschieden:</span></p>\r\n<ul>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Tempor&auml;re Cookies (auch: Session- oder Sitzungscookies):</strong> Tempor&auml;re Cookies werden sp&auml;testens gel&ouml;scht, nachdem ein Nutzer ein Onlineangebot verlassen und sein Endger&auml;t (z.&nbsp;B. Browser oder mobile Applikation) geschlossen hat.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Permanente Cookies:</strong> Permanente Cookies bleiben auch nach dem Schlie&szlig;en des Endger&auml;ts gespeichert. So k&ouml;nnen beispielsweise der Log-in-Status gespeichert und bevorzugte Inhalte direkt angezeigt werden, wenn der Nutzer eine Website erneut besucht. Ebenso k&ouml;nnen die mithilfe von Cookies erhobenen Nutzerdaten zur Reichweitenmessung Verwendung finden. Sofern wir Nutzern keine expliziten Angaben zur Art und Speicherdauer von Cookies mitteilen (z.&nbsp;B. im Rahmen der Einholung der Einwilligung), sollten sie davon ausgehen, dass diese permanent sind und die Speicherdauer bis zu zwei Jahre betragen kann.</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Allgemeine Hinweise zum Widerruf und Widerspruch (Opt-out):&nbsp;</strong>Nutzer k&ouml;nnen die von ihnen abgegebenen Einwilligungen jederzeit widerrufen und zudem einen Widerspruch gegen die Verarbeitung entsprechend den gesetzlichen Vorgaben, auch mittels der Privatsph&auml;re-Einstellungen ihres Browsers, erkl&auml;ren.</span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Verarbeitete Datenarten:</strong> Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Betroffene Personen:</strong> Nutzer (z.&nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).</span></li>\r\n<li class=\"\" style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Rechtsgrundlagen:</strong> Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). Einwilligung (Art. 6 Abs. 1 S. 1 lit. a) DSGVO).</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:</strong></span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Verarbeitung von Cookie-Daten auf Grundlage einer Einwilligung: </strong>Wir setzen eine Einwilligungs-Management-L&ouml;sung ein, bei der die Einwilligung der Nutzer zur Verwendung von Cookies oder zu den im Rahmen der Einwilligungs-Management-L&ouml;sung genannten Verfahren und Anbietern eingeholt wird. Dieses Verfahren dient der Einholung, Protokollierung, Verwaltung und dem Widerruf von Einwilligungen, insbesondere bezogen auf den Einsatz von Cookies und vergleichbaren Technologien, die zur Speicherung, zum Auslesen und zur Verarbeitung von Informationen auf den Endger&auml;ten der Nutzer eingesetzt werden. Im Rahmen dieses Verfahrens werden die Einwilligungen der Nutzer f&uuml;r die Nutzung von Cookies und die damit verbundenen Verarbeitungen von Informationen, einschlie&szlig;lich der im Einwilligungs-Management-Verfahren genannten spezifischen Verarbeitungen und Anbieter, eingeholt. Die Nutzer haben zudem die M&ouml;glichkeit, ihre Einwilligungen zu verwalten und zu widerrufen. Die Einwilligungserkl&auml;rungen werden gespeichert, um eine erneute Abfrage zu vermeiden und den Nachweis der Einwilligung gem&auml;&szlig; der gesetzlichen Anforderungen f&uuml;hren zu k&ouml;nnen. Die Speicherung erfolgt serverseitig und/oder in einem Cookie (sogenanntes Opt-In-Cookie) oder mittels vergleichbarer Technologien, um die Einwilligung einem spezifischen Nutzer oder dessen Ger&auml;t zuordnen zu k&ouml;nnen. Sofern keine spezifischen Angaben zu den Anbietern von Einwilligungs-Management-Diensten vorliegen, gelten folgende allgemeine Hinweise: Die Dauer der Speicherung der Einwilligung betr&auml;gt bis zu zwei Jahre. Dabei wird ein pseudonymer Nutzer-Identifikator erstellt, der zusammen mit dem Zeitpunkt der Einwilligung, den Angaben zum Umfang der Einwilligung (z.&nbsp;B. betreffende Kategorien von Cookies und/oder Diensteanbieter) sowie Informationen &uuml;ber den Browser, das System und das verwendete Endger&auml;t gespeichert wird; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Einwilligung (Art. 6 Abs. 1 S. 1 lit. a) DSGVO).</span></span></li>\r\n</ul>\r\n<h2 id=\"m367\"><span style=\"color: #ffffff;\">Registrierung, Anmeldung und Nutzerkonto</span></h2>\r\n<p><span style=\"color: #ffffff;\">Nutzer k&ouml;nnen ein Nutzerkonto anlegen. Im Rahmen der Registrierung werden den Nutzern die erforderlichen Pflichtangaben mitgeteilt und zu Zwecken der Bereitstellung des Nutzerkontos auf Grundlage vertraglicher Pflichterf&uuml;llung verarbeitet. Zu den verarbeiteten Daten geh&ouml;ren insbesondere die Login-Informationen (Nutzername, Passwort sowie eine E-Mail-Adresse).</span></p>\r\n<p><span style=\"color: #ffffff;\">Im Rahmen der Inanspruchnahme unserer Registrierungs- und Anmeldefunktionen sowie der Nutzung des Nutzerkontos speichern wir die IP-Adresse und den Zeitpunkt der jeweiligen Nutzerhandlung. Die Speicherung erfolgt auf Grundlage unserer berechtigten Interessen als auch jener der Nutzer an einem Schutz vor Missbrauch und sonstiger unbefugter Nutzung. Eine Weitergabe dieser Daten an Dritte erfolgt grunds&auml;tzlich nicht, es sei denn, sie ist zur Verfolgung unserer Anspr&uuml;che erforderlich oder es besteht eine gesetzliche Verpflichtung hierzu.</span></p>\r\n<p><span style=\"color: #ffffff;\">Die Nutzer k&ouml;nnen &uuml;ber Vorg&auml;nge, die f&uuml;r deren Nutzerkonto relevant sind, wie z.&nbsp;B. technische &Auml;nderungen, per E-Mail informiert werden.</span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Verarbeitete Datenarten:</strong> Bestandsdaten (z.&nbsp;B. der vollst&auml;ndige Name, Wohnadresse, Kontaktinformationen, Kundennummer, etc.); Kontaktdaten (z.&nbsp;B. Post- und E-Mail-Adressen oder Telefonnummern); Inhaltsdaten (z. B. textliche oder bildliche Nachrichten und Beitr&auml;ge sowie die sie betreffenden Informationen, wie z. B. Angaben zur Autorenschaft oder Zeitpunkt der Erstellung); Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&auml;t und -frequenz, verwendete Ger&auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen). Protokolldaten (z.&nbsp;B. Logfiles betreffend Logins oder den Abruf von Daten oder Zugriffszeiten.).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Betroffene Personen:</strong> Nutzer (z.&nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Zwecke der Verarbeitung:</strong> Erbringung vertraglicher Leistungen und Erf&uuml;llung vertraglicher Pflichten; Sicherheitsma&szlig;nahmen; Organisations- und Verwaltungsverfahren. Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Aufbewahrung und L&ouml;schung:</strong> L&ouml;schung entsprechend Angaben im Abschnitt \"Allgemeine Informationen zur Datenspeicherung und L&ouml;schung\". L&ouml;schung nach K&uuml;ndigung.</span></li>\r\n<li class=\"\" style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Rechtsgrundlagen:</strong> Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO). Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:</strong></span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Registrierung mit Pseudonymen: </strong>Nutzer d&uuml;rfen statt Klarnamen Pseudonyme als Nutzernamen verwenden; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).</span></span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Profile der Nutzer sind &ouml;ffentlich: </strong>Die Profile der Nutzer sind &ouml;ffentlich sichtbar und zug&auml;nglich.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>L&ouml;schung von Daten nach K&uuml;ndigung: </strong>Wenn Nutzer ihr Nutzerkonto gek&uuml;ndigt haben, werden deren Daten im Hinblick auf das Nutzerkonto, vorbehaltlich einer gesetzlichen Erlaubnis, Pflicht oder Einwilligung der Nutzer, gel&ouml;scht; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).</span></span></li>\r\n</ul>\r\n<h2 id=\"m432\"><span style=\"color: #ffffff;\">Community Funktionen</span></h2>\r\n<p><span style=\"color: #ffffff;\">Die von uns bereitgestellten Community Funktionen erlauben es Nutzern miteinander in Konversationen oder sonst miteinander in einen Austausch zu treten. Hierbei bitten wir zu beachten, dass die Nutzung der Communityfunktionen nur unter Beachtung der geltenden Rechtslage, unserer Bedingungen und Richtlinien sowie der Rechte anderer Nutzer und Dritter gestattet ist.</span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Verarbeitete Datenarten:</strong> Bestandsdaten (z.&nbsp;B. der vollst&auml;ndige Name, Wohnadresse, Kontaktinformationen, Kundennummer, etc.). Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&auml;t und -frequenz, verwendete Ger&auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Betroffene Personen:</strong> Nutzer (z.&nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Zwecke der Verarbeitung:</strong> Erbringung vertraglicher Leistungen und Erf&uuml;llung vertraglicher Pflichten; Sicherheitsma&szlig;nahmen. Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Aufbewahrung und L&ouml;schung:</strong> L&ouml;schung entsprechend Angaben im Abschnitt \"Allgemeine Informationen zur Datenspeicherung und L&ouml;schung\".</span></li>\r\n<li class=\"\" style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Rechtsgrundlagen:</strong> Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO). Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:</strong></span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Beitr&auml;ge der Nutzer sind &ouml;ffentlich: </strong>Die von Nutzern erstellten Beitr&auml;ge und Inhalte sind &ouml;ffentlich sichtbar und zug&auml;nglich; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).</span></span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Speicherung von Daten zu Sicherheitszwecken: </strong>Die Beitr&auml;ge und sonstige Eingaben der Nutzer werden zu Zwecken der Community- und Konversationsfunktionen verarbeitet und, vorbehaltlich gesetzlicher Pflichten oder gesetzlicher Erlaubnis nicht an Dritte herausgegeben. Eine Herausgabepflicht kann insbesondere im Fall von rechtswidrigen Beitr&auml;gen zu Zwecken der Rechtsverfolgung entstehen. Wir weisen darauf hin, dass neben den Inhalten der Beitr&auml;ge auch deren Zeitpunkt und die IP-Adresse der Nutzer gespeichert werden. Dies geschieht, um zum Schutz anderer Nutzer und der Community angemessene Ma&szlig;nahmen ergreifen zu k&ouml;nnen; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).</span></span></li>\r\n</ul>\r\n<h2 id=\"m182\"><span style=\"color: #ffffff;\">Kontakt- und Anfrageverwaltung</span></h2>\r\n<p><span style=\"color: #ffffff;\">Bei der Kontaktaufnahme mit uns (z.&nbsp;B. per Post, Kontaktformular, E-Mail, Telefon oder via soziale Medien) sowie im Rahmen bestehender Nutzer- und Gesch&auml;ftsbeziehungen werden die Angaben der anfragenden Personen verarbeitet, soweit dies zur Beantwortung der Kontaktanfragen und etwaiger angefragter Ma&szlig;nahmen erforderlich ist.</span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Verarbeitete Datenarten:</strong> Bestandsdaten (z.&nbsp;B. der vollst&auml;ndige Name, Wohnadresse, Kontaktinformationen, Kundennummer, etc.); Kontaktdaten (z.&nbsp;B. Post- und E-Mail-Adressen oder Telefonnummern); Inhaltsdaten (z. B. textliche oder bildliche Nachrichten und Beitr&auml;ge sowie die sie betreffenden Informationen, wie z. B. Angaben zur Autorenschaft oder Zeitpunkt der Erstellung); Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&auml;t und -frequenz, verwendete Ger&auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen). Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Betroffene Personen:</strong> Kommunikationspartner.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Zwecke der Verarbeitung:</strong> Kommunikation; Organisations- und Verwaltungsverfahren; Feedback (z.&nbsp;B. Sammeln von Feedback via Online-Formular). Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Aufbewahrung und L&ouml;schung:</strong> L&ouml;schung entsprechend Angaben im Abschnitt \"Allgemeine Informationen zur Datenspeicherung und L&ouml;schung\".</span></li>\r\n<li class=\"\" style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Rechtsgrundlagen:</strong> Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:</strong></span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Kontaktformular: </strong>Bei Kontaktaufnahme &uuml;ber unser Kontaktformular, per E-Mail oder anderen Kommunikationswegen, verarbeiten wir die uns &uuml;bermittelten personenbezogenen Daten zur Beantwortung und Bearbeitung des jeweiligen Anliegens. Dies umfasst in der Regel Angaben wie Name, Kontaktinformationen und gegebenenfalls weitere Informationen, die uns mitgeteilt werden und zur angemessenen Bearbeitung erforderlich sind. Wir nutzen diese Daten ausschlie&szlig;lich f&uuml;r den angegebenen Zweck der Kontaktaufnahme und Kommunikation; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Vertragserf&uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO), Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).</span></span></li>\r\n</ul>\r\n<h2 id=\"m296\"><span style=\"color: #ffffff;\">Audioinhalte</span></h2>\r\n<p><span style=\"color: #ffffff;\">Wir nutzen Hosting-Angebote von Dienstanbietern, um unsere Audio-Inhalte zum Anh&ouml;ren und zum Download anzubieten. Dabei setzen wir Plattformen ein, die das Hochladen, Speichern und Verbreiten von Audio-Material erm&ouml;glichen.</span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Verarbeitete Datenarten:</strong> Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&auml;t und -frequenz, verwendete Ger&auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen); Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen). Protokolldaten (z.&nbsp;B. Logfiles betreffend Logins oder den Abruf von Daten oder Zugriffszeiten.).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Betroffene Personen:</strong> Nutzer (z.&nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Zwecke der Verarbeitung:</strong> Reichweitenmessung (z.&nbsp;B. Zugriffsstatistiken, Erkennung wiederkehrender Besucher); Profile mit nutzerbezogenen Informationen (Erstellen von Nutzerprofilen). Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.</span></li>\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Aufbewahrung und L&ouml;schung:</strong> L&ouml;schung entsprechend Angaben im Abschnitt \"Allgemeine Informationen zur Datenspeicherung und L&ouml;schung\".</span></li>\r\n<li class=\"\" style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Rechtsgrundlagen:</strong> Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).</span></li>\r\n</ul>\r\n<p><span style=\"color: #ffffff;\"><strong>Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:</strong></span></p>\r\n<ul class=\"m-elements\">\r\n<li style=\"color: #ffffff;\"><span style=\"color: #ffffff;\"><strong>Abrufstatistiken beim Audiohosting: </strong>Erfassung und Analyse von Nutzungsdaten bei der Bereitstellung von Audioinhalten. Dies beinhaltet die Sammlung von Daten &uuml;ber die H&auml;ufigkeit des Abrufs, die Dauer der Nutzung und geografische Informationen der Nutzer. Die gewonnenen Statistiken helfen bei der Beurteilung der Reichweite und des Engagements der H&ouml;rer. Erfassung von Nutzungsdaten: Systematische Aufzeichnung der Anzahl der Downloads und Streams, inklusive Zeitstempel und Dauer der Audio Nutzung. Analyse und Reporting: Auswertung der gesammelten Daten zur Erstellung von Leistungsberichten, die Einblicke in Nutzerverhalten und Pr&auml;ferenzen geben. Nutzungsstatistiken: Bereitstellung von detaillierten Abrufstatistiken zur Optimierung der Inhalte und zur strategischen Planung k&uuml;nftiger Publikationen. Diese Verfahren unterst&uuml;tzen die zielgerichtete Weiterentwicklung und Anpassung von Audioinhalten, um die Bed&uuml;rfnisse und Interessen der Zielgruppe effektiver zu bedienen; <span class=\"\"><strong>Rechtsgrundlagen:</strong> Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). </span><strong>Sicherheitsma&szlig;nahmen:</strong> IP-Masking (Pseudonymisierung der IP-Adresse).</span></li>\r\n</ul>\r\n<p class=\"seal\"><a title=\"Rechtstext von Dr. Schwenke - f&uuml;r weitere Informationen bitte anklicken.\" href=\"https://datenschutz-generator.de/\" target=\"_blank\" rel=\"noopener noreferrer nofollow\">Erstellt mit kostenlosem Datenschutz-Generator.de von Dr. Thomas Schwenke</a></p>'),
(3, 'Hilfe', 'Hilfe', '<center><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Ihr k&ouml;nnt den Chat jederzeit als Gast betreten.</span><br><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Es steht euch frei, euren Benutzernamen mit einem Passwort zu sichern.</span><br><br><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">So wird es gemacht:</span></center><center>\r\n<ol>\r\n<li style=\"text-align: left;\"><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Am Chateingang auf der Startseite vom Chat! (nicht hier im Chat)</span></li>\r\n<li style=\"text-align: left;\"><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Klickt auf Registrieren / Passwort vergessen.</span></li>\r\n<li style=\"text-align: left;\"><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">F&uuml;llt das Formular aus mit E-Mail-Adresse.</span></li>\r\n<li style=\"text-align: left;\"><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Geht in euer E-Mail Postfach (evtl. Spam) und folgt dem Link innerhalb von 30 min.</span></li>\r\n<li style=\"text-align: left;\"><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Die E-Mail-Adresse ist wichtig! Zum Freischalten und falls ihr euer Passwort vergesst!</span></li>\r\n<li style=\"text-align: left;\"><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Beim n&auml;chsten Login mit euren Namen werdet Ihr nach dem Passwart gefragt.</span></li>\r\n</ol>\r\n<br><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Somit ist euer Name gesch&uuml;tzt</span><br><span style=\"font-family: arial, helvetica, sans-serif; color: #ffffff;\">Wir w&uuml;nschen euch viel Spass &amp; sch&ouml;ne Unterhaltung im Chat.</span></center>');
INSERT INTO `###prefix###etchat_texte` (`id`, `ort`, `header_text`, `content`) VALUES
(4, 'Regeln', 'Regeln', '<p><span style=\"color: #ffffff;\">Radio XXX CHAT REGELN! </span><br><br><span style=\"color: #ffffff;\">Es ist darauf zu achten das die User im Chat mit deren Nicknamen in der Userlist angesprochen werden und nicht mit realem Namen!!! Au&szlig;er es steht ein User mit realem Namen in der Userlist !!! </span><br><br><span style=\"color: #ffffff;\">Unsere Chatregeln</span><br><span style=\"color: #ffffff;\">Wie auch im richtigen Leben gelten im Chat allgemeine Umgangsformen, die einen respektvollen und st&ouml;rungsfreien Umgang unter den Chattern regeln sollen. Anstand geh&ouml;rt hier ebenso dazu wie die Achtung anderer Chatter und deren Meinungen. </span><br><br><span style=\"color: #ffffff;\">Im Folgenden werden diese Regeln, auch Chatiquette genannt, erkl&auml;rt. Die Chat-Admins bitten um Beachtung und Einhaltung dieser Regeln. Zuwiderhandlungen werden je nach Art der Zuwiderhandlung mit Verwarnungen, mit dem Hinauswurf aus dem Chat, im Wiederholungsfall oder bei extremer Missachtung mit einem andauernden Ausschluss (Bann) vom Chat geahndet. </span><br><br><span style=\"color: #ffffff;\">Auflistung Jugendschutzgesetz, Kinder und Jugendliche verlassen den Chat (Webradio) </span><br><br><span style=\"color: #ffffff;\">bis zum 6.Lebensjahr ab 16:00 Uhr</span><br><span style=\"color: #ffffff;\">bis zum 12 Lebensjahr ab 18:00 Uhr</span><br><span style=\"color: #ffffff;\">bis zum 14.Lebensjahr ab 20:00 Uhr</span><br><span style=\"color: #ffffff;\">bis zum 16.Lebensjahr ab 22:00 Uhr</span><br><br><br><span style=\"color: #ffffff;\">Ab den 18.Lebensjahr ist 24 Stunden unbegrenzter Aufenthalt erlaubt. Wir bitte die Eltern, uns beim Einhalten der Chatzeiten ihrer Kinder zu unterst&uuml;tzen. </span><br><br><span style=\"color: #ffffff;\">Grundregel 1</span><br><span style=\"color: #ffffff;\">Denke immer daran, dass am anderen Ende auch nur ein Mensch wie du und ich sitzt, der genau so behandelt werden m&ouml;chte, wie du es dir f&uuml;r dich w&uuml;nschst! Respekt und H&ouml;flichkeit sollten selbstverst&auml;ndlich sein. Kraftausdr&uuml;cke und der Gossen-Slang sind keine geeigneten Sprachen im Chat. Was du eventuell als lustig ansiehst, wird auf der anderen Seite nicht immer genauso aufgefasst.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 2</span><br><span style=\"color: #ffffff;\">Wenn du den Chat betrittst, haue nicht gleich in die Vollen, mische dich nicht direkt in ein laufendes Gespr&auml;ch ein. Schau erst zu, worum es geht, welche User anwesend sind und welche Stimmung herrscht. Du springst ja auch nicht fr&ouml;hlich schreiend und tanzend in ein Kaffee hinein und rufst \'Heja, hier bin ich! Unterhaltet mich!\'. Erst wenn du siehst, was im Raum los ist, wie die User gelaunt sind, kannst du entscheiden, ob dir das Geschehen entspricht oder ob du lieber weitergehst und die anderen R&auml;ume besuchst. </span><br><br><span style=\"color: #ffffff;\">Grundregel 3</span><br><span style=\"color: #ffffff;\">Wer flirtet nicht gerne? Der Chat ist eine ideale Plattform daf&uuml;r, jedoch sollte man daran denken, dass dies kein Flirt-Chat, sondern ein Fantasy-Chat ist. Respektiere dies. Es reicht schon ein *** Bist du m oder w ? ***, um zu nerven. Meldet ein User aufdringliches rumgeflirte, wird dies von einem Admin oder Moderator geregelt werden. </span><br><br><span style=\"color: #ffffff;\">Grundregel 3.1</span><br><span style=\"color: #ffffff;\">Das Leben ist nicht immer sonnig, dass weis jeder von uns. Dies ist aber kein Grund, die angestauten Frustrationen an anderen Usern auszulassen. Wenn es Dir schlecht geht, hei&szlig;t das nicht, dass du den anderen Usern das Leben auch noch schwer machen musst.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 4</span><br><span style=\"color: #ffffff;\">Jeder war mal neu im Chat und musste sich erst orientieren, musste herausfinden, wie der Chat funktioniert. Deshalb sollte jeder den Neulingen gegen&Atilde;&frac14;ber helfend zur Seite stehen, auch um f&uuml;r *** Nachwuchs *** im Chat zu sorgen. Wer weis, vielleicht wird der Neuling irgendwann mal ein Stammchatter oder gar ein guter Freund! Hat man keine Lust zu helfen, sollte man lieber gar nichts sagen als den Neuling zu verunsichern oder gar zu verjagen.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 5</span><br><span style=\"color: #ffffff;\">Wir bietet es unseren Mitgliedern an, ein Profil anzulegen. Die Bilder und Texte, die dort hochgeladen werden, sind kein Eigentum vom Chatadmin. Als Profilersteller, haftet ein jeder User f&uuml;r sein Profil, sollte er geltendes Recht verletzen (Urheberrecht). Da es uns nicht m&ouml;glich ist, nachzupr&uuml;fen, ob eine Erlaubnis zur Nutzung (Bildmaterial, Text) vorliegt ist eine Ahndung schwer durchzuf&uuml;hren. Urheber sind dazu angehalten, bei dem Verstoss des Urheberrechts, eine E-Mail an den Webmaster dieser Seite zu schicken, indem sie den Fall darlegen. Texte mit rassistischem, werblichen oder pornografischen Inhalten, werden von den Admin oder Moderatoren gel&ouml;scht, wenn sie gesichtet werden und der User verwarnt und/oder aus der Community ausgeschlossen.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 6</span><br><span style=\"color: #ffffff;\">Ohne Humor ist der Chat langweilig. Denke jedoch immer daran, dass nicht jeder User den gleichen Humor mit dir teilt. Was dir Tr&auml;nen vor Lachen in die Augen treibt, kann den anderen entsetzen. Dabei sollte man auch immer daran denken, dass man im Chat Gesten und Tonlagen, die einen Witz oft erst witzig machen, oft nur schlecht darstellen kann! </span><br><br><span style=\"color: #ffffff;\">Grundregel 7</span><br><span style=\"color: #ffffff;\">Pers&ouml;nliche Daten, wie z. B. Telefonnummern oder gar vollst&auml;ndige Adressen haben in &Ouml;ffentlichen R&auml;umen grunds&auml;tzlich nichts verloren. Dr&auml;nge niemanden dazu, solche Daten von sich preiszugeben. Man sollte sich damit abfinden, wenn ein User keinen n&auml;heren Kontakt haben m&ouml;chte und lieber die Anonymit&auml;t im Chat geniesst.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 8</span><br><span style=\"color: #ffffff;\">Gro&szlig;buchstaben sind nur in Ausnahmef&auml;llen als Betonung zu verwenden. Im Allgemeinen gilt das Gro&szlig;schreiben als Br&uuml;llen/Schreien im Chat. Weder im Chat noch im normalen Leben wird es geduldet, wenn jemand durchweg schreit. Schreibst du st&auml;ndig und durchweg in Gro&szlig;buchstaben, solltest du dich nicht wundern, wenn die anderen von dir genervt sind und du eventuell von einem Admin oder Moderator ermahnt und/oder still gelegt wirst. </span><br><br><span style=\"color: #ffffff;\">Grundregel 9</span><br><span style=\"color: #ffffff;\">Der Chat ist nicht der richtige Ort, um mit Schimpfw&ouml;rtern um sich zu werfen. Damit machst du dir keine Freunde und st&ouml;rst die anderen User, die in Ruhe chatten wollen. </span><br><br><span style=\"color: #ffffff;\">Zudem denk immer daran: auch im Internet k&ouml;nnen Gewalt- und Drogenverherrlichung, pornographische Darstellungen und rassistische &Auml;&uuml;&szlig;erungen strafrechtlich geahndet werden! </span><br><br><span style=\"color: #ffffff;\">Grundregel 10</span><br><span style=\"color: #ffffff;\">Taucht im Chat ein St&ouml;renfried auf, ignoriere ihn! Diskussionen oder gar eine Antwort auf gleichem Niveau bringt nichts au&szlig;er &Auml;rger. Wird ein solcher User ignoriert, langweilt er sich und wird schnell von alleine verschwinden, wenn er merkt, dass er sein Ziel nicht erreichen kann.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Bei besonders schlimmen F&auml;llen benachrichtige einen Moderator &uuml;ber den User und bitte ihn, das Geschehen zu beobachten und entsprechend zu handeln. Sollte kein Moderator oder Admin im Chat sein, kannst du auch einen Notruf &uuml;ber das Notrufsystem absetzen dadurch wird dann ein Moderator per Email informiert.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 11</span><br><span style=\"color: #ffffff;\">Du solltest dir einen Nicknamen aussuchen, der niemanden beleidigt. Verboten sind Nicknamen, die (wenn auch nur zum Teil) aus zensierten W&ouml;rtern bestehen, rassistisch oder gewaltverherrlichend sind oder einen pornographischen Inhalt haben. </span><br><br><span style=\"color: #ffffff;\">Grundregel 12</span><br><span style=\"color: #ffffff;\">Unser Chat ist eine Community, die &Uuml;berwiegend aus Usern mittleren Alters besteht. Erotik-Chats gibt es zur Gen&uuml;ge im Netz, bei uns jedoch sind Gespr&auml;che mit erotischem Inhalt nicht erw&uuml;nscht und werden entsprechend geahndet! Wenn es unbedingt sein muss, sind Plays und Gespr&auml;che solcher Art, in abgeschlossene R&auml;ume oder Privatchats zu verlegen.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Ebensowenig werden Fragen oder Aufforderungen zu sexuellen Handlungen im Chat (CyberSex, CS) geduldet. </span><br><br><span style=\"color: #ffffff;\">Grundregel 13</span><br><span style=\"color: #ffffff;\">Auch wenn es viele gerne so sehen: du bist nicht vollkommen anonym im Chat. Deine Rechner-Adresse (IP) wird bei jedem Login im Chat mitgeschnitten und im Rahmen des Datenschutzes gespeichert. &Uuml;ber diese Adresse kann der Betreiber jederzeit deinen Provider in Erfahrung bringen, welcher wiederum deine Telefonnummer speichert. Solltest du also den Chatbetrieb extrem st&ouml;ren oder gar rechts- oder sittenwidrige Dinge im Chat begehen, ist es dem Betreiber jederzeit m&ouml;glich, deine Identit&auml;t in Erfahrung zu bringen und dich entsprechend zur Rechenschaft zu ziehen. Dies solltest du beachten, wenn du nicht zu denen geh&ouml;rst, die einfach nur friedlich miteinander chatten und playn wollen.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 14</span><br><span style=\"color: #ffffff;\">Der Chat ist keine Plakatwand. Sicher hat niemand etwas dagegen, wenn du ab und zu die Adresse (URL) deiner Homepage postest. Missbrauchst du den Chat allerdings, um nur Werbung zu machen, wird dich fr&uuml;her oder sp&auml;ter ein Moderator oder Admin aus dem Chat entfernen. </span><br><br><span style=\"color: #ffffff;\">Notorische Spammer oder User, die f&uuml;r kommerzielle Angebote werben (z. B. Seiten, die zu Dialern f&uuml;hren), werden auf Dauer gebannt!&nbsp;</span><br><br><span style=\"color: #ffffff;\">Wirb niemals f&uuml;r eine andere Community oder einen anderen Chat. Gef&auml;llt dir der Chat nicht, brauchst du das nicht st&auml;ndig &Auml;u&szlig;ern. Konsequent und ehrlich w&Atilde;&curren;re es, in solch einem Fall den Chat zu verlassen und den Chat deines Vertrauens aufzusuchen.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Grundregel 15</span><br><span style=\"color: #ffffff;\">Admins und Moderatoren sind auch nur Menschen. Ihr Amt ist ehrenamtlich, sie tun ihren Job, um Usern zu helfen und die Einhaltung der Regeln zu &Uuml;berwachen. Sollte ein Admin oder Moderator mal nicht sofort auf deine Fragen reagieren, denke bitte daran, dass auch andere User Fragen haben und der Admin oder Moderator vielleicht gerade im Stress ist, um allen Usern gerecht zu werden.&nbsp;</span><br><br><span style=\"color: #ffffff;\">Wenn Du diese Regeln befolgst,dann steht einem tollen Chat-Leben nichts mehr im Wege. </span><br><br></p>'),
(5, 'Gäste Begrüßen', '<center>Hallo Gast sei gegrüßt bei DMR- by Radio-Dino</center>', '<p><span style=\"color: #ffffff;\">Hallo, du bist neu hier als Gast.</span></p>\r\n<p><span style=\"color: #ffffff;\">bitte benehme dich und baggere keine anderen User Chatter an.</span></p>\r\n<p><span style=\"color: #ffffff;\">Sollte es dir gefallen, kannst du gerne deinen Chattername regestrieren.</span></p>\r\n<p><span style=\"color: #ffffff;\">Das machst du auf der Login Seite unter \"<span style=\"font-family: Arial; font-size: 14.6667px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: center; text-indent: 0px; text-transform: none; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: #ac0a12; display: inline !important; float: none;\">Registrieren / Passwort vergessen</span>\"</span></p>\r\n<p><span style=\"color: #ffffff;\">Solltest du mit dem Handy oder eine zu kleine Aufl&ouml;sung haben, findes du den Player und die Userliste<br>hinter diesem Butoon <img src=\"img/Userliste.png\" alt=\"\" width=\"25\" height=\"25\"></span></p>\r\n<p><span style=\"color: #ffffff;\">Wir w&uuml;nschen dir viel Spa&szlig; ....</span></p>'),
(6, 'Div. 1', '1. Eigene Seite', '<p><span style=\"color: #ffffff;\">1. Text f&uuml;r eigne Seite auch HTML -Code erlaubt</span></p>'),
(7, 'Div. 2', '2. Eigene Seite', '<p><span style=\"color: #ffffff;\">2. Text f&uuml;r eigne Seite auch HTML -Code erlaubt</span></p>'),
(8, 'Div. 3', '3. Eigene Seite', '<p><span style=\"color: #ffffff;\">3. Text f&uuml;r eigne Seite auch HTML -Code erlaubt</span></p>'),
(9, 'Div. 4', '4. Eigene Seite', '<p><span style=\"color: #ffffff;\">4. Text f&uuml;r eigne Seite auch HTML -Code erlaubt</span></p>'),
(10, 'Div. 5', '5. Eigene Seite', '<p><span style=\"color: #ffffff;\">4. Text f&uuml;r eigne Seite auch HTML -Code erlaubt</span></p>');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_user`
--

CREATE TABLE `###prefix###etchat_user` (
  `etchat_user_id` int(8) NOT NULL,
  `etchat_username` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_userpw` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_userprivilegien` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gast',
  `etchat_usersex` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `etchat_reg_timestamp` timestamp NOT NULL DEFAULT '1979-12-31 23:00:00',
  `etchat_reg_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_avatar` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noavatar.jpg',
  `etchat_logintime` bigint(20) DEFAULT NULL,
  `etchat_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_reset_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_reset_token_expiry` datetime DEFAULT NULL,
  `etchat_geb_tag` tinyint(2) DEFAULT NULL,
  `etchat_geb_monat` tinyint(2) DEFAULT NULL,
  `etchat_geb_jahr` smallint(4) DEFAULT NULL,
  `etchat_ort` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_beschreibung` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_last_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_onlinetime` bigint(20) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_user`
--

INSERT INTO `###prefix###etchat_user` (`etchat_user_id`, `etchat_username`, `etchat_userpw`, `etchat_userprivilegien`, `etchat_usersex`, `etchat_reg_timestamp`, `etchat_reg_ip`, `etchat_avatar`, `etchat_logintime`, `etchat_email`, `etchat_reset_token`, `etchat_reset_token_expiry`, `etchat_geb_tag`, `etchat_geb_monat`, `etchat_geb_jahr`, `etchat_ort`, `etchat_beschreibung`, `etchat_last_ip`, `etchat_onlinetime`) VALUES
(1, '<i>System</i>', 'NULL', 'system', 'n', '1979-12-31 22:00:00', 'NULL', 'system.png', 1746638719, 'NULL', NULL, '2025-04-25 20:09:09', 0, 0, 0, NULL, NULL, NULL, 0),
(2, 'Admin', '$2y$10$wKEUe1hXlL8LcBWswGbhYOWWLonNk0EhLUEUEEjbq8/uFKf3A4sbC', 'admin', 'm', '2024-09-10 11:00:00', NULL, 'Admin-1777639202.png', 1784227270, 'p-berg007@gmx.de', '1e91e435abe00967902b8510a1cc820980ba5f747469c6bd42c304e484370af0', '2026-03-10 18:30:06', 6, 5, 1968, 'Berlin', 'Hallo liebe Hörer/innen von Dance Music Radio, ihr wollt immer aktuelle News  unsere Sendungen und unser Radio erhalten? ?', '80.136.86.67', 1775208600),
(3, 'Admin-2', '$2y$10$kdu4LY5MNPRp63MjovEkKeJpenvQdrfyQ1NJrQf5fGH/v4cwetehC', 'admin', 'm', '2025-07-09 17:50:11', '2003:fc:d716:5f00:80d8:e9f7:a285:b23e', 'Admin-2-1752129680.jpg', 1772826049, 'p-berg007@gmx.de', NULL, '0000-00-00 00:00:00', 0, 0, 0, NULL, NULL, '93.227.180.175', 1200),
(-1, 'ChatBot', '0', 'ChatBot', 'm', '2026-01-13 15:52:39', NULL, 'bot_avatar.png', 1769619342, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '80.136.85.183', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_useronline`
--

CREATE TABLE `###prefix###etchat_useronline` (
  `etchat_onlineid` bigint(20) UNSIGNED NOT NULL,
  `etchat_onlineuser_fid` int(8) NOT NULL,
  `etchat_onlinetimestamp` bigint(20) NOT NULL,
  `etchat_onlineip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_fid_room` int(11) NOT NULL DEFAULT 1,
  `etchat_user_online_room_goup` int(6) NOT NULL,
  `etchat_user_online_room_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_priv` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_sex` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_status_img` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_user_online_user_status_text` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_avatar` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noavatar.jpg',
  `etchat_logintime` bigint(20) NOT NULL,
  `etchat_onlineuser_zeit` int(11) NOT NULL DEFAULT 0,
  `etchat_last_ping` datetime NOT NULL DEFAULT current_timestamp(),
  `etchat_session_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `###prefix###etchat_bewerbungen`
--
ALTER TABLE `###prefix###etchat_bewerbungen`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_bewerbung_fields`
--
ALTER TABLE `###prefix###etchat_bewerbung_fields`
  ADD PRIMARY KEY (`etchat_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_blacklist`
--
ALTER TABLE `###prefix###etchat_blacklist`
  ADD PRIMARY KEY (`etchat_blacklist_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_config`
--
ALTER TABLE `###prefix###etchat_config`
  ADD UNIQUE KEY `etchat_config_id` (`etchat_config_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_kick_user`
--
ALTER TABLE `###prefix###etchat_kick_user`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_kontakt`
--
ALTER TABLE `###prefix###etchat_kontakt`
  ADD PRIMARY KEY (`etchat_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_kontakt_fields`
--
ALTER TABLE `###prefix###etchat_kontakt_fields`
  ADD PRIMARY KEY (`etchat_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_menu`
--
ALTER TABLE `###prefix###etchat_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_messages`
--
ALTER TABLE `###prefix###etchat_messages`
  ADD PRIMARY KEY (`etchat_id`),
  ADD KEY `idx_room` (`etchat_fid_room`),
  ADD KEY `idx_id` (`etchat_id`),
  ADD KEY `idx_privat` (`etchat_privat`),
  ADD KEY `idx_user` (`etchat_user_fid`);

--
-- Indizes für die Tabelle `###prefix###etchat_radio_box`
--
ALTER TABLE `###prefix###etchat_radio_box`
  ADD PRIMARY KEY (`etchat_radio_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_radio_history`
--
ALTER TABLE `###prefix###etchat_radio_history`
  ADD PRIMARY KEY (`etchat_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_rooms`
--
ALTER TABLE `###prefix###etchat_rooms`
  ADD PRIMARY KEY (`etchat_id_room`);

--
-- Indizes für die Tabelle `###prefix###etchat_smileys`
--
ALTER TABLE `###prefix###etchat_smileys`
  ADD PRIMARY KEY (`etchat_smileys_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_smileys_cat`
--
ALTER TABLE `###prefix###etchat_smileys_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_start_boxes`
--
ALTER TABLE `###prefix###etchat_start_boxes`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_texte`
--
ALTER TABLE `###prefix###etchat_texte`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_user`
--
ALTER TABLE `###prefix###etchat_user`
  ADD PRIMARY KEY (`etchat_user_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_useronline`
--
ALTER TABLE `###prefix###etchat_useronline`
  ADD PRIMARY KEY (`etchat_onlineid`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_bewerbungen`
--
ALTER TABLE `###prefix###etchat_bewerbungen`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_bewerbung_fields`
--
ALTER TABLE `###prefix###etchat_bewerbung_fields`
  MODIFY `etchat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_blacklist`
--
ALTER TABLE `###prefix###etchat_blacklist`
  MODIFY `etchat_blacklist_id` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_kick_user`
--
ALTER TABLE `###prefix###etchat_kick_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_kontakt`
--
ALTER TABLE `###prefix###etchat_kontakt`
  MODIFY `etchat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_kontakt_fields`
--
ALTER TABLE `###prefix###etchat_kontakt_fields`
  MODIFY `etchat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_menu`
--
ALTER TABLE `###prefix###etchat_menu`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_messages`
--
ALTER TABLE `###prefix###etchat_messages`
  MODIFY `etchat_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_radio_box`
--
ALTER TABLE `###prefix###etchat_radio_box`
  MODIFY `etchat_radio_id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_radio_history`
--
ALTER TABLE `###prefix###etchat_radio_history`
  MODIFY `etchat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_rooms`
--
ALTER TABLE `###prefix###etchat_rooms`
  MODIFY `etchat_id_room` int(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_smileys`
--
ALTER TABLE `###prefix###etchat_smileys`
  MODIFY `etchat_smileys_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_smileys_cat`
--
ALTER TABLE `###prefix###etchat_smileys_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_start_boxes`
--
ALTER TABLE `###prefix###etchat_start_boxes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_texte`
--
ALTER TABLE `###prefix###etchat_texte`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_user`
--
ALTER TABLE `###prefix###etchat_user`
  MODIFY `etchat_user_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_useronline`
--
ALTER TABLE `###prefix###etchat_useronline`
  MODIFY `etchat_onlineid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
