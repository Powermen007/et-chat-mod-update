<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteSmiliesCat extends DbConectionMaker
{
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rollen prüfen
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->get('admin_deletesmiliescat_error_access') ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // GET + POST kompatibel
        $data = $_GET + $_POST;

        // Eingaben absichern
        $categoryName = trim($data['cat'] ?? '');
        $categoryId = (int)($data['id'] ?? 0);
        $requestToken = (string)($data['csrf_token'] ?? '');

        // CSRF prüfen (nur wenn eine Aktion ausgeführt wird)
        if ($categoryName !== '') {
            if ($requestToken === '' || !hash_equals($this->csrfToken, $requestToken)) {
                http_response_code(403);
                echo $lang->get('admin_deletesmiliescat_error_csrf') ?? "Manipulationsversuch erkannt.";
                $this->dbObj->close();
                exit;
            }

            $this->deleteCategory($categoryName, $categoryId);
        }

        $this->dbObj->close();

        // Redirect zurück zur Smilies-Kategorie Übersicht
        header("Location: ./?AdminSmiliesCatIndex");
        exit;
    }

    /**
     * Löscht eine gesamte Smiley-Kategorie
     */
    private function deleteCategory(string $categoryName, int $categoryId): void
    {
        // Projekt-Pfade ermitteln
        $projectRoot = realpath(__DIR__ . '/../../');
        if ($projectRoot === false) {
            error_log("AdminDeleteSmiliesCat: Projekt-Root nicht gefunden");
            return;
        }

        $smilieRoot = realpath($projectRoot . '/smilies');
        if ($smilieRoot === false) {
            error_log("AdminDeleteSmiliesCat: Smilies-Ordner nicht gefunden");
            return;
        }

        // 1. Alle Smileys der Kategorie aus DB holen
        $smilies = $this->getSmiliesByCategory($categoryName);

        // 2. Dateien löschen
        $this->deleteSmileyFiles($smilies, $projectRoot, $smilieRoot);

        // 3. DB-Einträge löschen
        $this->deleteSmiliesFromDatabase($categoryName);

        if ($categoryId > 0) {
            $this->deleteCategoryFromDatabase($categoryId);
        }

        // 4. Kategorie-Ordner löschen
        $this->deleteCategoryFolder($categoryName, $smilieRoot);
    }

    /**
     * Holt alle Smileys einer Kategorie aus der DB
     */
    private function getSmiliesByCategory(string $categoryName): array
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_smileys_img FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_kat = :cat"
        );
        $stmt->execute([':cat' => $categoryName]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Löscht alle Smiley-Dateien einer Kategorie
     */
    private function deleteSmileyFiles(array $smilies, string $projectRoot, string $smilieRoot): void
    {
        foreach ($smilies as $smiley) {
            $imgPath = $smiley['etchat_smileys_img'] ?? '';
            if ($imgPath === '') {
                continue;
            }

            $imgPath = ltrim($imgPath, './');
            $fullPath = realpath($projectRoot . '/' . $imgPath);

            // Sicherheitscheck: Nur Dateien im Smilies-Ordner löschen
            if ($fullPath === false) {
                error_log("AdminDeleteSmiliesCat: Datei nicht gefunden: " . $imgPath);
                continue;
            }

            if (!str_starts_with($fullPath, $smilieRoot)) {
                error_log("AdminDeleteSmiliesCat: Sicherheitsverletzung – Datei außerhalb des Smilies-Ordners: " . $fullPath);
                continue;
            }

            if (is_file($fullPath) && !unlink($fullPath)) {
                error_log("AdminDeleteSmiliesCat: Konnte Datei nicht löschen: " . $fullPath);
            }
        }
    }

    /**
     * Löscht alle Smiley-DB-Einträge einer Kategorie
     */
    private function deleteSmiliesFromDatabase(string $categoryName): void
    {
        try {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_kat = :cat",
                [':cat' => $categoryName]
            );
        } catch (PDOException $e) {
            error_log("AdminDeleteSmiliesCat DB Fehler (Smileys): " . $e->getMessage());
        }
    }

    /**
     * Löscht den Kategorie-Eintrag aus der DB
     */
    private function deleteCategoryFromDatabase(int $categoryId): void
    {
        try {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_smileys_cat WHERE id = :id",
                [':id' => $categoryId]
            );
        } catch (PDOException $e) {
            error_log("AdminDeleteSmiliesCat DB Fehler (Kategorie): " . $e->getMessage());
        }
    }

    /**
     * Löscht den physischen Kategorie-Ordner
     */
    private function deleteCategoryFolder(string $categoryName, string $smilieRoot): void
    {
        $safeFolder = preg_replace("/[^a-zA-Z0-9_-]/", "_", $categoryName);
        $catFolder = $smilieRoot . '/' . $safeFolder;

        if (!is_dir($catFolder)) {
            return;
        }

        // Alle Dateien im Ordner löschen
        $files = glob($catFolder . '/*');
        if (is_array($files)) {
            foreach ($files as $file) {
                if (is_file($file)) {
                    if (!unlink($file)) {
                        error_log("AdminDeleteSmiliesCat: Konnte Datei nicht löschen: " . $file);
                    }
                }
            }
        }

        // Ordner löschen
        if (!rmdir($catFolder)) {
            error_log("AdminDeleteSmiliesCat: Konnte Ordner nicht löschen: " . $catFolder);
        }
    }
}