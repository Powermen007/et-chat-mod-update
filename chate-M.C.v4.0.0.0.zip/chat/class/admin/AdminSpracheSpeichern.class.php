<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminSpracheSpeichern extends DbConectionMaker
{
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Rollenprüfung (nur admin)
        $allowedRoles = ["admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (aus Session)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $this->csrfToken = $_SESSION[$csrfKey] ?? '';

        // CSRF prüfen
        $csrfPost = $_POST['csrf'] ?? '';
        if (!$this->csrfToken || !$csrfPost || !hash_equals($this->csrfToken, $csrfPost)) {
            $this->fail("🔒 Ungültige Anfrage (CSRF).");
        }

        // Eingaben validieren
        $bereich = trim((string)($_POST['bereich'] ?? ''));
        $eintraege = $_POST['eintraege'] ?? [];

        if ($bereich === '' || !preg_match('/^[a-zA-Z0-9_\/-]+$/', $bereich) || !is_array($eintraege)) {
            $this->fail("❌ Ungültige Eingaben.");
        }

        // Config laden (mit Prepared Statement)
        $config = $this->loadConfig();

        // Änderungen speichern
        $this->saveChanges($config, $bereich, $eintraege);
    }

    private function loadConfig(): array
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_config_style, etchat_config_lang
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = 1"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return is_array($result) ? $result : [];
    }

    private function saveChanges(array $config, string $bereich, array $eintraege): void
    {
        $langFile = 'lang_de.xml';
        $langBase = realpath(__DIR__ . '/../../lang/');

        // Aktuelle Sprachdatei aus Config ermitteln
        foreach ($config as $data) {
            $langValue = $data['etchat_config_lang'] ?? '';
            if (!empty($langValue)) {
                $safeFile = basename($langValue);
                $fullPath = realpath(__DIR__ . '/../../lang/' . $safeFile);

                if ($fullPath && $langBase && str_starts_with($fullPath, $langBase)) {
                    $langFile = $safeFile;
                }
            }
        }

        $xmlFile = realpath(__DIR__ . '/../../lang/' . $langFile);

        if (!$xmlFile || !file_exists($xmlFile)) {
            $this->fail("📄 XML-Datei nicht gefunden: " . htmlspecialchars($langFile));
        }

        // Backup erstellen
        $backupDir = __DIR__ . '/../../lang/old/';
        if (!is_dir($backupDir) && !mkdir($backupDir, 0755, true) && !is_dir($backupDir)) {
            $this->fail("📁 Backup-Ordner konnte nicht erstellt werden.");
        }

        $backupFile = basename($xmlFile) . '.bak.' . date('Ymd_His');
        $backupPath = $backupDir . $backupFile;

        if (!copy($xmlFile, $backupPath)) {
            $this->fail("💾 Backup konnte nicht erstellt werden!");
        }

        // XML laden
        libxml_use_internal_errors(true);

        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;

        if (!$dom->load($xmlFile)) {
            copy($backupPath, $xmlFile);
            $this->fail("❌ Fehler beim Laden der XML.");
        }

        $xpath = new DOMXPath($dom);

        $teileBereich = array_values(array_filter(explode('/', $bereich)));

        if (empty($teileBereich)) {
            $this->fail("❌ Ungültiger Bereich.");
        }

        $rootName = $dom->documentElement->nodeName;
        $query = '/' . $rootName . '/' . implode('/', $teileBereich);

        $nodes = $xpath->query($query);

        if ($nodes->length === 0) {
            copy($backupPath, $xmlFile);
            $this->fail("❌ Bereich nicht gefunden: " . htmlspecialchars($bereich));
        }

        $targetNode = $nodes->item(0);
        $bereichName = end($teileBereich);

        // Einträge aktualisieren
        foreach ($eintraege as $pfadRelativ => $wert) {
            $wert = (string)$wert;
            $pfadRelativ = trim((string)$pfadRelativ, "/");

            if ($pfadRelativ === '') continue;

            if (str_starts_with($pfadRelativ, $bereichName . '/')) {
                $pfadRelativ = substr($pfadRelativ, strlen($bereichName) + 1);
            }

            $parts = array_values(array_filter(explode('/', $pfadRelativ)));
            $current = $targetNode;

            foreach ($parts as $segment) {
                if (preg_match('/^(.*)_(\d+)$/', $segment, $matches)) {
                    $tag = $matches[1];
                    $index = (int)$matches[2];
                } else {
                    $tag = $segment;
                    $index = 0;
                }

                $existing = [];
                foreach ($current->childNodes as $child) {
                    if ($child->nodeType === XML_ELEMENT_NODE && $child->nodeName === $tag) {
                        $existing[] = $child;
                    }
                }

                while (count($existing) <= $index) {
                    $new = $dom->createElement($tag);
                    $current->appendChild($new);
                    $existing[] = $new;
                }

                $current = $existing[$index];
            }

            // Textinhalt ersetzen
            while ($current->firstChild) {
                $current->removeChild($current->firstChild);
            }
            $current->appendChild($dom->createTextNode($wert));
        }

        // Speichern
        $tmpFile = $xmlFile . '.tmp';

        if (!$dom->save($tmpFile)) {
            copy($backupPath, $xmlFile);
            $this->fail("❌ Fehler beim Schreiben der XML.");
        }

        if (!rename($tmpFile, $xmlFile)) {
            if (!copy($tmpFile, $xmlFile)) {
                copy($backupPath, $xmlFile);
                if (is_file($tmpFile)) unlink($tmpFile);
                $this->fail("❌ Speichern fehlgeschlagen.");
            }
            unlink($tmpFile);
        }

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($bereich, $config);
    }

    private function renderTemplate(string $bereich, array $config): void
    {
        $style = '';
        foreach ($config as $data) {
            $style = $data['etchat_config_style'] ?? '';
        }

        $bereichEsc = htmlspecialchars($bereich, ENT_QUOTES, 'UTF-8');

        include __DIR__ . '/../../styles/admin_tpl/insertSpracheSpeichern.tpl.html';
    }

    private function fail(string $msg): void
    {
        http_response_code(400);
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px;">❌ ' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</div>';
        exit;
    }
}