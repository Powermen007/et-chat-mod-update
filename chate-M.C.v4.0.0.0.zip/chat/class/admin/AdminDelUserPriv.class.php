<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDelUserPriv extends DbConectionMaker
{
    // Geschützte Avatare, die nicht gelöscht werden dürfen
    private const PROTECTED_AVATARS = ['noavatar.jpg', 'mod_ohne_pic.png', 'autodj.jpg'];

    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rollen prüfen
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        $allowedRoles = ['admin', 'chatwache', 'co_admin'];

        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->get('admin_deluserpriv_error_access') ?? 'Zugriff verweigert';
            return;
        }

        // CSRF prüfen
        $id = (int)($_GET['id'] ?? 0);
        $requestToken = (string)($_GET['csrf_token'] ?? '');
        $sessionToken = (string)($_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '');

        if ($id <= 0 || $requestToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            echo $lang->get('admin_deluserpriv_error_csrf') ?? "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            return;
        }

        // Benutzer löschen
        $this->deleteUser($id);

        $this->dbObj->close();

        // Redirect zurück zur User-Übersicht
        header("Location: ./?AdminUserIndex");
        exit;
    }

    /**
     * Löscht einen Benutzer komplett
     */
    private function deleteUser(int $userId): void
    {
        // Avatar löschen (falls vorhanden und nicht geschützt)
        $this->deleteUserAvatar($userId);

        // Benutzer aus DB löschen
        $this->deleteUserFromDatabase($userId);
    }

    /**
     * Löscht den Avatar eines Benutzers
     */
    private function deleteUserAvatar(int $userId): void
    {
        $avatarFile = $this->getUserAvatar($userId);
        
        if ($avatarFile === '') {
            return;
        }

        $fileName = basename($avatarFile);
        
        // Geschützte Avatare nicht löschen
        if (in_array($fileName, self::PROTECTED_AVATARS, true)) {
            return;
        }

        $avatarPath = dirname(__DIR__, 2) . '/avatar/' . $fileName;
        
        if (file_exists($avatarPath) && is_file($avatarPath)) {
            if (!unlink($avatarPath)) {
                error_log("AdminDelUserPriv: Konnte Avatar nicht löschen: " . $avatarPath);
            }
        }
    }

    /**
     * Holt den Avatar-Dateinamen aus der Datenbank
     */
    private function getUserAvatar(int $userId): string
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_user_id = :id"
        );
        $stmt->execute([':id' => $userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['etchat_avatar'] ?? '';
    }

    /**
     * Löscht den Benutzer aus der Datenbank
     */
    private function deleteUserFromDatabase(int $userId): void
    {
        try {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_user WHERE etchat_user_id = :id",
                [':id' => $userId]
            );
        } catch (PDOException $e) {
            error_log("AdminDelUserPriv DB Fehler: " . $e->getMessage());
        }
    }
}