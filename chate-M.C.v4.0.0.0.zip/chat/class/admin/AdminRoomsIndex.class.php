<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRoomsIndex extends ConnectDB
{
    private string $csrfToken = '';
    private array $rooms = [];
    private object $lang;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // NEU: Sprache laden - Admin XML
        $this->lang = new LangXml("./lang/");

        // Rechte prüfen
        if (!$this->isAllowed()) {
            echo $this->lang->get('admin_access_denied', 'Zugriff verweigert');
            return;
        }

        // Räume laden
        $this->loadRooms();

        $this->close();

        // Template anzeigen
        $this->renderTemplate();
    }

    private function isAllowed(): bool
    {
        $allowedRoles = ["admin", "co_admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        return true;
    }

    private function loadRooms(): void
    {
        $result = $this->sqlGet(
            "SELECT etchat_id_room, etchat_roomname, etchat_room_goup 
             FROM {$this->_prefix}etchat_rooms
             ORDER BY etchat_id_room ASC"
        );
        
        $this->rooms = is_array($result) ? $result : [];
    }

    private function renderTemplate(): void
    {
        $print_room_list = $this->buildRoomList();
        $csrf = $this->csrfToken;
        
        // Für das Template: Option für registrierte Benutzer (wenn aktiviert)
        $room4user_print = '';
        if ($this->_allow_nick_registration ?? false) {
            $room4user_print = '<option value="4">' . $this->lang->get('admin_rooms_priv_registered', 'Alle registrierten Benutzer') . '</option>';
        }
        
        $lang = $this->lang;  // 🔥 WICHTIG: $lang an Template übergeben!
        
        include_once("styles/admin_tpl/indexRooms.tpl.html");
    }

    private function buildRoomList(): string
    {
        if (empty($this->rooms)) {
            return '<p>' . $this->lang->get('admin_rooms_empty', 'Keine Räume vorhanden.') . '</p>';
        }

        $html = '<table border="1" cellpadding="5" cellspacing="0" class="room-table">
            <thead>
                <tr>
                    <th>' . $this->lang->get('admin_rooms_table_name', 'Raumname') . '</th>
                    <th></th>
                    <th>' . $this->lang->get('admin_rooms_table_delete', 'Löschen') . '</th>
                    <th>' . $this->lang->get('admin_rooms_table_edit', 'Bearbeiten') . '</th>
                    <th>' . $this->lang->get('admin_rooms_table_privilege', 'Berechtigung') . '</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($this->rooms as $room) {
            $id = (int)($room['etchat_id_room'] ?? 0);
            $name = htmlspecialchars($room['etchat_roomname'] ?? '', ENT_QUOTES, 'UTF-8');
            $priv = (int)($room['etchat_room_goup'] ?? 0);
            
            // Privattext aus Sprache oder Fallback
            $privText = match($priv) {
                0 => $this->lang->get('admin_rooms_priv_all', 'offen für alle'),
                1 => $this->lang->get('admin_rooms_priv_admin_mod', 'Admins und Mods'),
                2 => $this->lang->get('admin_rooms_priv_admin', 'nur Admins'),
                3 => $this->lang->get('admin_rooms_priv_password', 'passwortgeschützt'),
                4 => $this->lang->get('admin_rooms_priv_registered', 'alle registrierten Benutzer'),
                default => 'Unbekannt'
            };

            // Raum 1 (Standard-Raum) kann nicht gelöscht werden
            $isProtected = ($id === 1);
            
            $html .= '<tr>';
            $html .= '<td><b>' . $name . '</b></td>';
            $html .= '<td>&nbsp;&nbsp;&nbsp;</td>';
            
            if ($isProtected) {
                $html .= '<td style="color:#888;"><strike>' . $this->lang->get('admin_rooms_table_delete', 'Löschen') . '</strike></td>';
            } else {
                $html .= '<td><a href="./?AdminDeleteRoom&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '"
                            onclick="return confirm(\'' . $this->lang->get('admin_rooms_delete_confirm', 'Raum wirklich löschen?') . '\')">' 
                            . $this->lang->get('admin_rooms_table_delete', 'Löschen') . '</a></td>';
            }
            
            $html .= '<td><a href="./?AdminEditRoom&id=' . $id . '">' . $this->lang->get('admin_rooms_table_edit', 'Bearbeiten') . '</a></td>';
            $html .= '<td>&nbsp;&nbsp;&nbsp;<i>' . htmlspecialchars($privText, ENT_QUOTES, 'UTF-8') . '</i></td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';
        return $html;
    }
}