<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminDBGastCleaner extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $guests = [];

    // Zeitkonstanten (in Sekunden)
    private const ONLINE_TIMEOUT = 600;      // 10 Minuten
    private const GUEST_TIMEOUT = 300;       // 5 Minuten für normale Gäste
    private const REGISTERED_TIMEOUT = 2100; // 35 Minuten für registrierte Gäste

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rollen prüfen
        $allowedRoles = ["admin", "chatwache", "co_admin"];
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userPriv, $allowedRoles, true)) {
            exit($lang->get('admin_gastcleaner_error_access') ?? 'Keine Berechtigung.');
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // ★★★ WICHTIG: Aktionen zuerst verarbeiten ★★★
        $this->handleActions($lang);

        // Gäste laden (NACH der Aktionen-Verarbeitung)
        $this->loadGuests();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    /**
     * Verarbeitet Lösch-Aktionen aus GET-Requests
     */
    private function handleActions($lang): void
    {
        // Prüfen ob eine Aktion vorhanden ist
        if (!isset($_GET['action']) || $_GET['action'] === '') {
            return;
        }

        $action = $_GET['action'];
        
        // CSRF für GET-Aktionen prüfen
        $token = $_GET['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            die($lang->get('admin_gastcleaner_error_csrf') ?? 'Manipulationsversuch erkannt.');
        }

        try {
            if ($action === 'delete' && isset($_GET['id'])) {
                $id = (int)$_GET['id'];
                $this->deleteSingleGuest($id);
                $_SESSION['flash_message'] = $lang->get('admin_gastcleaner_deleted_single') ?? "Gast ID $id wurde gelöscht.";
            }

            if ($action === 'delete_all') {
                $deleted = $this->deleteAllGuests();
                $_SESSION['flash_message'] = $lang->get('admin_gastcleaner_deleted_all') ?? "Alle offline Gäste wurden gelöscht. ($deleted Gäste)";
            }
        } catch (PDOException $e) {
            error_log("AdminDBGastCleaner Fehler: " . $e->getMessage());
            $_SESSION['flash_message'] = $lang->get('admin_gastcleaner_error_database') ?? 'Datenbankfehler beim Löschen: ' . $e->getMessage();
        }

        $this->dbObj->close();
        
        // Redirect mit Flash-Message
        $redirect = "./?AdminDBGastCleaner";
        if (isset($_SESSION['flash_message'])) {
            $redirect .= "&msg=" . urlencode($_SESSION['flash_message']);
            unset($_SESSION['flash_message']);
        }
        
        header("Location: " . $redirect);
        exit;
    }

    /**
     * Löscht einen einzelnen Gast
     */
    private function deleteSingleGuest(int $id): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "DELETE FROM {$this->_prefix}etchat_user 
             WHERE etchat_user_id = :id 
             AND etchat_userprivilegien = 'gast'"
        );
        $stmt->execute([':id' => $id]);
    }

    /**
     * Löscht alle inaktiven Gäste
     * @return int Anzahl der gelöschten Gäste
     */
    private function deleteAllGuests(): int
    {
        $totalDeleted = 0;
        
        // 1. Normale Gäste (kein Passwort) – nach 5 Minuten
        $threshold = time() - self::GUEST_TIMEOUT;
        
        $stmt = $this->dbObj->getConnection()->prepare(
            "DELETE FROM {$this->_prefix}etchat_user
            WHERE etchat_userprivilegien = 'gast'
            AND (etchat_userpw IS NULL OR etchat_userpw = '')
            AND etchat_logintime IS NOT NULL
            AND etchat_logintime < :threshold
            AND NOT EXISTS (
                SELECT 1 FROM {$this->_prefix}etchat_useronline uo 
                WHERE uo.etchat_onlineuser_fid = {$this->_prefix}etchat_user.etchat_user_id
            )"
        );
        $stmt->execute([':threshold' => $threshold]);
        $totalDeleted += $stmt->rowCount();
        
        // 2. Registrierte Gäste (mit Passwort, nicht aktiviert) – nach 35 Minuten
        $thresholdReg = time() - self::REGISTERED_TIMEOUT;
        
        $stmt2 = $this->dbObj->getConnection()->prepare(
            "DELETE FROM {$this->_prefix}etchat_user
            WHERE etchat_userprivilegien = 'gast'
            AND etchat_userpw IS NOT NULL 
            AND etchat_userpw != ''
            AND etchat_reg_timestamp != '1980-01-01 00:00:00'
            AND UNIX_TIMESTAMP(etchat_reg_timestamp) < :threshold
            AND NOT EXISTS (
                SELECT 1 FROM {$this->_prefix}etchat_useronline uo 
                WHERE uo.etchat_onlineuser_fid = {$this->_prefix}etchat_user.etchat_user_id
            )"
        );
        $stmt2->execute([':threshold' => $thresholdReg]);
        $totalDeleted += $stmt2->rowCount();
        
        return $totalDeleted;
    }

    /**
     * Lädt alle Gäste aus der Datenbank
     */
    private function loadGuests(): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT u.etchat_user_id, u.etchat_username, u.etchat_userpw, u.etchat_email, 
                    u.etchat_logintime, u.etchat_last_ip, u.etchat_reg_timestamp, u.etchat_reg_ip,
                    uo.etchat_onlinetimestamp
            FROM {$this->_prefix}etchat_user u
            LEFT JOIN {$this->_prefix}etchat_useronline uo
            ON uo.etchat_onlineuser_fid = u.etchat_user_id
            WHERE u.etchat_userprivilegien = 'gast'
            ORDER BY u.etchat_username ASC"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->guests = is_array($result) ? $result : [];
    }

    /**
     * Baut die HTML-Tabelle der Gäste
     */
    private function buildGuestRows($lang): string
    {
        if (empty($this->guests)) {
            return '<tr><td colspan="7" style="text-align: center;">' . ($lang->get('admin_gastcleaner_no_guests') ?? 'Keine Gäste gefunden.') . '</td></tr>';
        }

        $html = '';
        $threshold = time() - self::ONLINE_TIMEOUT;

        foreach ($this->guests as $guest) {
            $online = (!empty($guest['etchat_onlinetimestamp']) && (int)$guest['etchat_onlinetimestamp'] >= $threshold);
        
            $username = htmlspecialchars($guest['etchat_username'] ?? 'Unbekannt', ENT_QUOTES, 'UTF-8');
        
            $email = '-';
            if (!empty($guest['etchat_email'])) {
                $emailClean = htmlspecialchars($guest['etchat_email'], ENT_QUOTES, 'UTF-8');
                $email = '<a href="mailto:' . $emailClean . '" title="E-Mail schreiben">📧 ' . $emailClean . '</a>';
            }
        
            $hasPassword = !empty($guest['etchat_userpw']);
        
            $status = $lang->get('admin_gastcleaner_status_guest') ?? 'Gast';
            $statusClass = '';
            if ($hasPassword) {
                $status = $lang->get('admin_gastcleaner_status_registered') ?? '⏳ Registriert (nicht aktiviert, 35min.)';
                $statusClass = 'style="color: orange;"';
            }
        
            $logintime = $lang->get('admin_gastcleaner_unknown') ?? 'unbekannt';
            if ($hasPassword && !empty($guest['etchat_reg_timestamp']) && $guest['etchat_reg_timestamp'] !== '1980-01-01 00:00:00') {
                $logintime = date("d.m.Y H:i", strtotime($guest['etchat_reg_timestamp']));
            } elseif (!$hasPassword && !empty($guest['etchat_logintime'])) {
                $logintime = date("d.m.Y H:i", (int)$guest['etchat_logintime']);
            }
            $logintime = htmlspecialchars($logintime, ENT_QUOTES, 'UTF-8');
        
            $displayIp = '-';
            if ($hasPassword) {
                $displayIp = htmlspecialchars($guest['etchat_reg_ip'] ?? '-', ENT_QUOTES, 'UTF-8');
            } else {
                $displayIp = htmlspecialchars($guest['etchat_last_ip'] ?? '-', ENT_QUOTES, 'UTF-8');
            }
        
            $id = (int)($guest['etchat_user_id'] ?? 0);
        
            $html .= '<tr>
                        <td>' . $username . '</td>
                        <td class="' . ($online ? 'online' : 'offline') . '">' . ($online ? '🟢 ' . ($lang->get('admin_gastcleaner_online') ?? 'Online') : '⚫ ' . ($lang->get('admin_gastcleaner_offline') ?? 'Offline')) . '</td>
                        <td ' . $statusClass . '>' . $status . '</td>
                        <td>' . $email . '</td>
                        <td>
                            <a href="?AdminDBGastCleaner&action=delete&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '"
                            onclick="return confirm(\'' . ($lang->get('admin_gastcleaner_confirm_delete') ?? 'Gast wirklich löschen?') . ' ' . addslashes($username) . '?\')"
                            class="delete-btn">🗑️ ' . ($lang->get('admin_gastcleaner_delete') ?? 'Löschen') . '</a>
                        </td>
                        <td>' . $logintime . '</td>
                        <td>' . $displayIp . '</td>
                    </tr>';
        }

        return $html;
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate($lang): void
    {
        $vari1 = $this->buildGuestRows($lang);
        $vari2 = $this->csrfToken;
        
        // Flash-Message anzeigen
        $flashMessage = '';
        if (isset($_GET['msg'])) {
            $flashMessage = '<div class="flash-message" style="background: #4CAF50; color: white; padding: 15px; margin: 10px 0; border-radius: 5px;">' 
                          . htmlspecialchars($_GET['msg'], ENT_QUOTES, 'UTF-8') 
                          . '</div>';
        }
        
        $tplPath = __DIR__ . '/../../styles/admin_tpl/indexGastCleaner.tpl.html';
        
        if (!is_file($tplPath)) {
            exit($lang->get('admin_gastcleaner_error_template') ?? 'Template nicht gefunden: ' . $tplPath);
        }
        
        include $tplPath;
    }
}