<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminKontakt extends DbConectionMaker
{
    private array $kontakte = [];
    private string $filter = '';
    private int $perPage = 10;
    private string $csrfToken = '';
    private array $statusLabels = [];
    private object $lang;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // NEU: Sprache laden - Admin XML
        $this->lang = new LangXml("./lang/");

        // Status-Labels aus XML laden
        $this->statusLabels = [
            'neu' => $this->lang->get('admin_kontakt_status_new', 'Neu'),
            'bearbeitung_admin' => $this->lang->get('admin_kontakt_status_admin', 'In Bearbeitung v. Admin'),
            'bearbeitung_coadmin' => $this->lang->get('admin_kontakt_status_coadmin', 'In Bearbeitung v. Co-Admin'),
            'bearbeitung_chatwache' => $this->lang->get('admin_kontakt_status_chatwache', 'In Bearbeitung v. Chatwache'),
            'abgeschlossen' => $this->lang->get('admin_kontakt_status_done', 'Abgeschlossen')
        ];

        $allowedRoles = ['admin', 'co_admin', 'chatwache'];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header('Location: ./');
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        } else {
            $this->showList($userRole);
        }
    }

    private function handlePost(): void
    {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            exit($this->lang->get('admin_kontakt_error_csrf', 'Ungültiger CSRF Token'));
        }

        if (isset($_POST['save_kontakt'])) {
            $this->saveStatus($_POST);
        } elseif (!empty($_POST['delete_kontakt'])) {
            $this->deleteKontakt($_POST);
        }
    }

    private function showList(string $userRole): void
    {
        $this->filter = $_GET['status_filter'] ?? '';
        $search = trim((string)($_GET['search'] ?? ''));
        $saved = isset($_GET['saved']);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $offset = ($page - 1) * $this->perPage;

        $where = [];
        $params = [];

        if ($this->filter !== '') {
            $where[] = "etchat_status = :status";
            $params[':status'] = $this->filter;
        }

        if ($search !== '') {
            $where[] = "etchat_kontakt_daten LIKE :search";
            $searchParam = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $search) . '%';
            $params[':search'] = $searchParam;
        }

        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        // Prepared Statements mit LIMIT/OFFSET (als Integers sicher)
        $limit = (int)$this->perPage;
        $offsetVal = (int)$offset;
        
        $sql = "SELECT * FROM {$this->_prefix}etchat_kontakt
                $whereSql
                ORDER BY etchat_erstellt_am DESC
                LIMIT {$limit} OFFSET {$offsetVal}";

        $this->kontakte = $this->dbObj->sqlGet($sql, $params) ?: [];

        $countSql = "SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_kontakt $whereSql";
        $result = $this->dbObj->sqlGet($countSql, $params);
        $totalAll = (int)($result[0]['cnt'] ?? $result[0][0] ?? 0);
        $totalPages = max(1, (int)ceil($totalAll / $this->perPage));

        $this->renderTemplate($userRole, $page, $totalPages, $totalAll, $saved, $search);
    }

    private function renderTemplate(
        string $userRole,
        int $currentPage,
        int $totalPages,
        int $totalAll,
        bool $saved,
        string $search
    ): void {
        $kontakte = $this->kontakte;
        $filter = $this->filter;
        $statusLabels = $this->statusLabels;
        $csrfToken = $this->csrfToken;
        $lang = $this->lang;

        $successHtml = $saved
            ? '<div class="success-banner" id="successBanner"><span>' . $this->lang->get('admin_kontakt_save_success', 'Änderungen wurden erfolgreich gespeichert.') . '</span>
                <span class="close-btn" onclick="closeSuccessBanner()">✖</span></div>'
            : '';

        include "styles/admin_tpl/indexKontakt.tpl.html";
    }

    private function saveStatus(array $post): void
    {
        foreach ($post['status'] ?? [] as $id => $status) {
            if (!array_key_exists($status, $this->statusLabels)) {
                continue;
            }

            $kommentar = $post['kommentar'][$id] ?? '';

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_kontakt 
                 SET etchat_status = :status, etchat_kommentar = :kommentar 
                 WHERE etchat_id = :id",
                [
                    ':status' => $status,
                    ':kommentar' => $kommentar,
                    ':id' => (int)$id
                ]
            );
        }

        header("Location: ./?AdminKontakt&saved=1");
        exit;
    }

    private function deleteKontakt(array $post): void
    {
        foreach ($post['delete_kontakt'] ?? [] as $id => $v) {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_kontakt WHERE etchat_id = :id",
                [':id' => (int)$id]
            );
        }

        $params = [];
        if ($this->filter) {
            $params[] = 'status_filter=' . urlencode($this->filter);
        }
        if (!empty($_GET['search'] ?? '')) {
            $params[] = 'search=' . urlencode($_GET['search']);
        }

        header("Location: ./?AdminKontakt" . ($params ? '&' . implode('&', $params) : ''));
        exit;
    }
}