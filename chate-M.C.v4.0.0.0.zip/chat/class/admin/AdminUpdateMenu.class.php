<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateMenu extends DbConectionMaker
{
    // Erlaubte Felder für das Update
    private array $allowedFields = [
        'menu' => 'int',
        'link_text' => 'string',
        'image_active' => 'int',
        'image' => 'string',
        'url' => 'string',
        'target' => 'string',
        'gewicht' => 'int'
    ];

    // Erlaubte Zielwerte für target
    private array $allowedTargets = ['_blank', '_top', '_self', '_parent'];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Eingaben
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // CSRF prüfen
        if (!$this->isValidCsrfToken($token)) {
            $this->showError(($lang->get('admin_updatemenu_error_csrf') ?? '❌ Fehler') . ' (CSRF)');
            exit;
        }

        // Adminrechte prüfen (nur admin)
        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        if ($role !== 'admin' || $id <= 0) {
            $this->showError($lang->get('admin_updatemenu_error_access') ?? '❌ Zugriff verweigert');
            exit;
        }

        // Daten sammeln und validieren
        $updates = [];
        $params = [];

        foreach ($this->allowedFields as $field => $type) {
            if (isset($_POST[$field])) {
                $value = trim((string)$_POST[$field]);
                
                // Typ-spezifische Validierung
                if ($type === 'int') {
                    $value = (int)$value;
                    if ($field === 'gewicht') {
                        $value = max(1, min(999, $value));
                    }
                    if ($field === 'menu') {
                        $value = max(1, min(3, $value));
                    }
                    if ($field === 'image_active') {
                        $value = ($value === 1) ? 1 : 0;
                    }
                } else {
                    // String-Felder
                    if ($field === 'target' && !in_array($value, $this->allowedTargets, true)) {
                        $value = '_blank';
                    }
                    if ($field === 'link_text' && mb_strlen($value) > 100) {
                        $value = mb_substr($value, 0, 100);
                    }
                    if ($field === 'url' && mb_strlen($value) > 500) {
                        $value = mb_substr($value, 0, 500);
                    }
                    if ($field === 'image' && mb_strlen($value) > 100) {
                        $value = mb_substr($value, 0, 100);
                    }
                }
                
                $updates[] = "$field = :$field";
                $params[$field] = $value;
            }
        }

        // Update ausführen
        if (!empty($updates)) {
            try {
                $sql = "UPDATE {$this->_prefix}etchat_menu 
                        SET " . implode(", ", $updates) . " 
                        WHERE id = :id";

                $params['id'] = $id;
                $this->dbObj->sqlSet($sql, $params);
                
                // Erfolgsmeldung in Session speichern
                $_SESSION['menu_update_success'] = true;
                
            } catch (PDOException $e) {
                error_log("AdminUpdateMenu Fehler: " . $e->getMessage());
                $this->showError($lang->get('admin_updatemenu_error_database') ?? '❌ Datenbankfehler');
                exit;
            }
        }

        $this->dbObj->close();

        // Redirect nach Erfolg
        header("Location: ./?AdminMenusIndex");
        exit;
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $sessionToken !== '' && hash_equals($sessionToken, $token);
    }

    private function showError(string $message): void
    {
        $backText = $lang->get('admin_updatemenu_back') ?? '⬅️ Zurück zur Menü-Übersicht';
        
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '
              </div>';
        echo '<p><a href="./?AdminMenusIndex" class="admin-button">' . $backText . '</a></p>';
        exit;
    }
}