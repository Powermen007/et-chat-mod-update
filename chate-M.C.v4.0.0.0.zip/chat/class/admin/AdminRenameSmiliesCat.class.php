<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRenameSmiliesCat extends ConnectDB
{
    private array $request = [];
    private string $csrfToken = '';
    private array $categoryData = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // GET + POST vereinheitlichen
        $this->request = array_merge($_GET, $_POST);

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rechte prüfen
        if (!$this->isAllowed()) {
            echo $lang->get('admin_renamesmiliescat_error_access') ?? 'Zugriff verweigert';
            return;
        }

        // CSRF prüfen (nur bei POST!)
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->checkCsrf()) {
                echo $lang->get('admin_renamesmiliescat_error_csrf') ?? "Ungültiger CSRF Token";
                return;
            }
        }

        // ID absichern
        $id = (int)($this->request['id'] ?? 0);
        if ($id <= 0) {
            echo $lang->get('admin_renamesmiliescat_error_invalid_id') ?? "Ungültige ID";
            return;
        }

        // Daten laden
        $this->loadCategoryData($id);

        if (empty($this->categoryData)) {
            echo $lang->get('admin_renamesmiliescat_error_not_found') ?? "Kategorie nicht gefunden";
            return;
        }

        $this->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    private function isAllowed(): bool
    {
        $allowedRoles = ["admin", "co_admin", "grafik"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        return true;
    }

    private function checkCsrf(): bool
    {
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $token = $this->request['csrf_token'] ?? '';
        $sessionToken = $_SESSION[$csrfKey] ?? '';

        return $token !== '' && hash_equals($sessionToken, $token);
    }

    private function loadCategoryData(int $id): void
    {
        $result = $this->sqlGet(
            "SELECT * FROM {$this->_prefix}etchat_smileys_cat WHERE id = :id",
            [':id' => $id]
        );

        if (is_array($result) && !empty($result)) {
            // Konvertiere numerisches Array in assoziatives Array
            $row = $result[0];
            if (isset($row[0]) && !isset($row['id'])) {
                $this->categoryData = [
                    'id' => $row[0] ?? 0,
                    'name' => $row[1] ?? '',
                    'aktiv' => $row[2] ?? '',
                    'gewicht' => $row[3] ?? 0
                ];
            } else {
                $this->categoryData = $row;
            }
        }
    }

    private function renderTemplate($lang): void
    {
        // Template erwartet $feld[0] mit numerischen Indizes
        $numericalData = [];
        
        if (!empty($this->categoryData)) {
            $numericalData[0] = [
                $this->categoryData['id'] ?? 0,
                $this->categoryData['name'] ?? '',
                $this->categoryData['aktiv'] ?? '',
                $this->categoryData['gewicht'] ?? 0
            ];
        }
        
        $feld = $numericalData;
        $csrf = $this->csrfToken;
        
        include_once("styles/admin_tpl/renameSmiliesCat.tpl.html");
    }
}