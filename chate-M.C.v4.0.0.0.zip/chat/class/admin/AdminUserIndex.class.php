<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUserIndex extends DbConectionMaker
{
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Zugriff prüfen
        $allowedRoles = ["admin", "co_admin", "chatwache"];
        $userRole = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = (string)$_SESSION[$csrfKey];

        // Rollenliste absichern
        $roles = ["admin", "mod", "grafik", "chatwache", "co_admin"];
        $rolesList = "'" . implode("','", $roles) . "'";

        // Sortierung absichern
        $sort = filter_input(INPUT_GET, 'sort', FILTER_SANITIZE_SPECIAL_CHARS) ?? 'username';
        $orderBy = match($sort) {
            'reg'   => "etchat_reg_timestamp DESC",
            'login' => "(etchat_logintime = 0), etchat_logintime DESC",
            default => "etchat_username ASC",
        };

        // Nutzer laden
        $users = $this->dbObj->sqlGet("
            SELECT 
                etchat_user_id,
                etchat_username,
                etchat_userprivilegien,
                etchat_reg_timestamp,
                etchat_reg_ip,
                etchat_logintime,
                etchat_avatar,
                etchat_email,
                etchat_last_ip
            FROM {$this->_prefix}etchat_user
            WHERE etchat_userprivilegien IN ($rolesList)
            ORDER BY $orderBy
        ");

        $userCount = count($users ?? []);

        $this->dbObj->close();

        $userListHtml = $this->buildTable($users ?? [], $lang);

        $this->renderTemplate($lang, $userListHtml, $userCount);
    }

    private function buildTable(array $users, $lang): string
    {
        $currentSort = filter_input(INPUT_GET, 'sort', FILTER_SANITIZE_SPECIAL_CHARS) ?? 'username';

        $html = '<form method="get" class="sort-form">
                    <input type="hidden" name="AdminUserIndex" value="">
                    <label for="sort">🔽 ' . ($lang->get('admin_user_sort_label') ?? 'Sortieren nach') . ': </label>
                    <select name="sort" id="sort" onchange="this.form.submit()">
                        <option value="username"' . ($currentSort === 'username' ? ' selected' : '') . '>📝 ' . ($lang->get('admin_user_sort_username') ?? 'Username') . '</option>
                        <option value="reg"' . ($currentSort === 'reg' ? ' selected' : '') . '>📅 ' . ($lang->get('admin_user_sort_reg') ?? 'Registrierungsdatum') . '</option>
                        <option value="login"' . ($currentSort === 'login' ? ' selected' : '') . '>🕐 ' . ($lang->get('admin_user_sort_login') ?? 'Letzter Login') . '</option>
                    </select>
                 </form><br>';

        if (empty($users)) {
            return $html . '<p>📭 ' . ($lang->get('admin_user_no_users') ?? 'Keine Nutzer gefunden.') . '</p>';
        }

        $html .= '<table border="1" cellpadding="5" cellspacing="0" class="user-table">
                    <thead>
                    <tr>
                        <th>' . ($lang->get('admin_user_th_username') ?? 'Username') . '</th>
                        <th>' . ($lang->get('admin_user_th_privileges') ?? 'Privilegien') . '</th>
                        <th>' . ($lang->get('admin_user_th_reg_date') ?? 'Reg. Datum') . '</th>
                        <th>' . ($lang->get('admin_user_th_reg_ip') ?? 'IP während Reg.') . '</th>
                        <th>' . ($lang->get('admin_user_th_last_login') ?? 'Letzter Login') . '</th>
                        <th>' . ($lang->get('admin_user_th_last_ip') ?? 'Letzte IP') . '</th>
                        <th>' . ($lang->get('admin_user_th_email') ?? 'E-Mail') . '</th>
                        <th>' . ($lang->get('admin_user_th_avatar') ?? 'Avatar') . '</th>
                    </tr>
                    </thead>
                    <tbody>';

        foreach ($users as $u) {
            $id       = (int)($u['etchat_user_id'] ?? 0);
            $username = htmlspecialchars((string)($u['etchat_username'] ?? ''), ENT_QUOTES, 'UTF-8');
            $priv     = htmlspecialchars((string)($u['etchat_userprivilegien'] ?? ''), ENT_QUOTES, 'UTF-8');
            $regTs    = htmlspecialchars((string)($u['etchat_reg_timestamp'] ?? ''), ENT_QUOTES, 'UTF-8');
            $regIp    = htmlspecialchars((string)($u['etchat_reg_ip'] ?? ''), ENT_QUOTES, 'UTF-8');
            $loginTs  = (int)($u['etchat_logintime'] ?? 0);
            $avatar   = htmlspecialchars((string)($u['etchat_avatar'] ?? ''), ENT_QUOTES, 'UTF-8');
            $email    = htmlspecialchars((string)($u['etchat_email'] ?? ''), ENT_QUOTES, 'UTF-8');
            $lastIp   = htmlspecialchars((string)($u['etchat_last_ip'] ?? ''), ENT_QUOTES, 'UTF-8');

            $loginDate = $loginTs ? date("d.m.Y H:i", $loginTs) : '-';

            $html .= '<tr>
                        <td><b><a href="./?AdminEditUser&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '">✏️ ' . $username . '</a></b></td>
                        <td>(<i>' . $priv . '</i>)</td>
                        <td>' . $regTs . '</td>
                        <td>' . $regIp . '</td>
                        <td>' . $loginDate . '</td>
                        <td>' . $lastIp . '</td>
                        <td><a href="mailto:' . $email . '">📧 ' . $email . '</a></td>
                        <td>
                            <a href="./?AdminDeleteAvatar&delavatar&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '" 
                               onclick="return confirm(\'' . ($lang->get('admin_user_confirm_delete_avatar') ?? 'Bist du sicher, dass du diesen Avatar wirklich löschen möchtest?') . '\')">
                                ' . ($lang->get('admin_user_delete_avatar') ?? 'Löschen') . '
                            </a>&nbsp;
                            <img class="avatar_list_admin" src="avatar/' . $avatar . '" width="16" height="16" alt="avatar">
                        </td>
                     </tr>';
        }

        $html .= '</tbody>
                </table>';

        return $html;
    }

    private function renderTemplate($lang, string $userListHtml, int $userCount): void
    {
        include_once __DIR__ . "/../../styles/admin_tpl/indexUser.tpl.html";
    }
}