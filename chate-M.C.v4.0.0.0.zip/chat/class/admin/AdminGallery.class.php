<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminGallery extends DbConectionMaker
{
    private const UPLOAD_DIR = './userpic/';
    private const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif'];
    private const ALLOWED_ROLES = ['admin', 'grafik', 'co_admin', 'chatwache'];

    private string $csrfToken = '';
    private array $images = [];
    private int $imageCount = 0;
    private $lang = null;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $this->lang = new LangXml("./lang/");

        // CSRF Token setzen
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Config laden
        $style = $this->loadConfig();

        // Zugriff prüfen
        $this->checkAccess();

        // Aktionen verarbeiten
        $this->handleActions();

        // Bilder scannen
        $this->scanImages();

        // Template anzeigen
        $this->renderTemplate($style);
    }

    private function translate(string $key, string $default = ''): string
    {
        if (method_exists($this->lang, 'get')) {
            $result = $this->lang->get($key);
            return ($result !== null && $result !== '') ? $result : $default;
        } elseif (method_exists($this->lang, 'getText')) {
            $result = $this->lang->getText($key);
            return ($result !== null && $result !== '') ? $result : $default;
        } elseif (method_exists($this->lang, 'translate')) {
            $result = $this->lang->translate($key);
            return ($result !== null && $result !== '') ? $result : $default;
        } else {
            return isset($this->lang->$key) ? $this->lang->$key : $default;
        }
    }

    private function loadConfig(): string
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = 1"
        );
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['etchat_config_style'] ?? 'default';
    }

    private function checkAccess(): void
    {
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($role, self::ALLOWED_ROLES, true)) {
            exit($this->translate('admin_gallery_error_access', 'Zugriff verweigert'));
        }
    }

    private function handleActions(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
            $this->handleDelete($_POST['delete'], $_POST['csrf_token'] ?? '');
            exit;
        }
        if (isset($_GET['cleanup'])) {
            $this->handleCleanup($_GET['csrf_token'] ?? '');
            exit;
        }
    }

    private function handleDelete(string $imageName, string $token): void
    {
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            echo $this->translate('admin_gallery_error_csrf', 'CSRF Fehler - Token ungültig');
            exit;
        }

        $imageName = basename($imageName);
        $imagePath = self::UPLOAD_DIR . $imageName;
        
        if (!file_exists($imagePath)) {
            echo $this->translate('admin_gallery_error_not_found', 'Datei nicht gefunden');
            exit;
        }
        
        if (!is_file($imagePath)) {
            echo $this->translate('admin_gallery_error_invalid', 'Keine gültige Datei');
            exit;
        }
        
        if (unlink($imagePath)) {
            $metaPath = $imagePath . '.txt';
            if (is_file($metaPath)) {
                unlink($metaPath);
            }
            echo "success";
            exit;
        } else {
            echo $this->translate('admin_gallery_error_delete', 'Konnte Datei nicht löschen');
            exit;
        }
    }

    private function handleCleanup(string $token): void
    {
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            echo $this->translate('admin_gallery_error_csrf', 'CSRF Fehler - Token ungültig');
            exit;
        }

        $days = (int)($_GET['days'] ?? 7);
        $days = max(1, $days);
        $limitTime = time() - ($days * 86400);

        if (!is_dir(self::UPLOAD_DIR)) {
            $_SESSION['gallery_cleanup_msg'] = $this->translate('admin_gallery_error_dir', 'Fehler: Verzeichnis nicht gefunden.');
            header("Location: ./?AdminGallery");
            exit;
        }

        $files = scandir(self::UPLOAD_DIR);
        if ($files === false) {
            $_SESSION['gallery_cleanup_msg'] = $this->translate('admin_gallery_error_read', 'Fehler: Konnte Verzeichnis nicht lesen.');
            header("Location: ./?AdminGallery");
            exit;
        }

        $deleted = 0;
        $errors = 0;

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $path = self::UPLOAD_DIR . $file;
            if (!is_file($path)) continue;
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (!in_array($ext, self::ALLOWED_EXTENSIONS, true)) continue;
            if (filemtime($path) < $limitTime) {
                if (unlink($path)) {
                    $deleted++;
                    $metaPath = $path . '.txt';
                    if (is_file($metaPath)) unlink($metaPath);
                } else {
                    $errors++;
                }
            }
        }

        if ($deleted > 0 || $errors > 0) {
            $msg = $this->translate('admin_gallery_cleanup_deleted', "🧹 {deleted} Bilder gelöscht, {errors} Fehler.");
            $msg = str_replace(['{deleted}', '{errors}'], [$deleted, $errors], $msg);
            $_SESSION['gallery_cleanup_msg'] = $msg;
        } else {
            $msg = $this->translate('admin_gallery_cleanup_none', "Keine alten Bilder gefunden (älter als {days} Tage).");
            $msg = str_replace('{days}', (string)$days, $msg);
            $_SESSION['gallery_cleanup_msg'] = $msg;
        }
        
        header("Location: ./?AdminGallery");
        exit;
    }

    private function scanImages(): void
    {
        if (!is_dir(self::UPLOAD_DIR)) {
            $this->images = [];
            $this->imageCount = 0;
            return;
        }

        $files = scandir(self::UPLOAD_DIR);
        if ($files === false) {
            $this->images = [];
            $this->imageCount = 0;
            return;
        }

        $images = array_filter($files, function ($file) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            return in_array($ext, self::ALLOWED_EXTENSIONS, true)
                && is_file(self::UPLOAD_DIR . $file);
        });

        $this->images = array_values($images);
        $this->imageCount = count($this->images);
    }

    private function readMeta(string $image): array
    {
        $metaFile = self::UPLOAD_DIR . $image . '.txt';
        if (!is_file($metaFile)) {
            return [$this->translate('admin_gallery_unknown', 'Unbekannt'), '', ''];
        }
        $content = file_get_contents($metaFile);
        if ($content === false) {
            return [$this->translate('admin_gallery_unknown', 'Unbekannt'), '', ''];
        }
        $parts = explode('|', $content, 3);
        return [
            trim($parts[0] ?? ''),
            trim($parts[1] ?? ''),
            trim($parts[2] ?? '')
        ];
    }

    private function buildGallery(): string
    {
        if (empty($this->images)) {
            return '<p>' . ($this->translate('admin_gallery_empty', 'Keine Bilder vorhanden.')) . '</p>';
        }

        $html = '';
        foreach ($this->images as $image) {
            $safe = htmlspecialchars($image, ENT_QUOTES, 'UTF-8');
            $url = self::UPLOAD_DIR . $safe;
            [$uploader, $datum, $ip] = $this->readMeta($image);

            $html .= '
            <div class="gallery-card" style="border:1px solid #444; padding:10px; background:rgba(0,0,0,0.3); display:flex; flex-direction:column;">
                <div style="margin-bottom:5px;">
                    <b>' . htmlspecialchars($uploader, ENT_QUOTES, 'UTF-8') . '</b><br>
                    ' . htmlspecialchars($datum, ENT_QUOTES, 'UTF-8') . '<br>
                    IP: ' . htmlspecialchars($ip, ENT_QUOTES, 'UTF-8') . '
                </div>
                <div style="text-align:center; margin:10px 0;">
                    <img src="' . $url . '" style="max-height:150px; max-width:95%;" alt="' . $safe . '">
                </div>
                <div style="text-align:center; margin-top:auto;">
                    <button type="button" onclick="sendToChat(\'' . addslashes($safe) . '\')">' . ($this->translate('admin_gallery_button_post', '📤 posten')) . '</button>
                    <button type="button" class="delete-btn" onclick="deleteImage(\'' . addslashes($safe) . '\')">' . ($this->translate('admin_gallery_button_delete', '🗑️ X')) . '</button>
                </div>
            </div>';
        }
        return $html;
    }

    private function renderTemplate(string $style): void
    {
        $vari1 = $this->buildGallery();
        $vari2 = $this->csrfToken;
        $vari3 = htmlspecialchars($style, ENT_QUOTES, 'UTF-8');
        $vari4 = $this->imageCount;
        
        // Übersetzungen für Template
        $translations = [
            'page_title' => $this->translate('admin_gallery_page_title', '🖼️ Gallery verwalten'),
            'images' => $this->translate('admin_gallery_images', 'Bilder'),
            'confirm_cleanup' => $this->translate('admin_gallery_confirm_cleanup', 'Wirklich alle Bilder älter als 7 Tage löschen?'),
            'cleanup_button' => $this->translate('admin_gallery_cleanup_button', '🗑️ ALLE BILDER ÄLTER ALS 7 TAGE LÖSCHEN'),
            'confirm_delete' => $this->translate('admin_gallery_confirm_delete', 'Wirklich löschen?'),
            'error_delete_failed' => $this->translate('admin_gallery_error_delete_failed', 'Fehler beim Löschen:'),
            'error_network' => $this->translate('admin_gallery_error_network', 'Netzwerkfehler:')
        ];

        $cleanupMessage = '';
        if (isset($_SESSION['gallery_cleanup_msg'])) {
            $cleanupMessage = $_SESSION['gallery_cleanup_msg'];
            unset($_SESSION['gallery_cleanup_msg']);
        }

        $tplPath = __DIR__ . '/../../styles/admin_tpl/indexGallery.tpl.html';
        if (!is_file($tplPath)) {
            exit($this->translate('admin_gallery_error_template', 'Template fehlt: ') . $tplPath);
        }

        include $tplPath;
    }
}