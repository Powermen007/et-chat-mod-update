<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateRoom extends DbConectionMaker
{
    // Erlaubte Raumtypen
    private array $allowedRoomPriv = [0, 1, 2, 3, 4];
    
    // Standard-Raum (ID 1) kann nicht geändert werden (außer Name und Nachricht)
    private const PROTECTED_ROOM_ID = 1;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Eingaben
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // CSRF prüfen
        if (!$this->isValidCsrfToken($token)) {
            $this->showError($lang->get('admin_update_room_error_csrf') ?? '❌ Fehler (CSRF)', $lang);
            exit;
        }

        // Berechtigung prüfen (admin oder co_admin)
        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        if (!in_array($role, ['admin', 'co_admin'], true) || $id <= 0) {
            $this->showError($lang->get('admin_update_room_error_access') ?? '❌ Zugriff verweigert', $lang);
            exit;
        }

        // Eingaben validieren
        $roomname = trim((string)($_POST['room'] ?? ''));
        $roomPriv = (int)($_POST['room_priv'] ?? 0);
        $roomPw = trim((string)($_POST['roompw'] ?? ''));
        $roomMessage = trim((string)($_POST['roommessage'] ?? ''));

        // Raumname validieren
        if ($roomname === '') {
            $this->showError($lang->get('admin_update_room_error_name_empty') ?? '❌ Raumname darf nicht leer sein.', $lang);
            exit;
        }
        if (mb_strlen($roomname) > 50) {
            $roomname = mb_substr($roomname, 0, 50);
        }
        // Nur erlaubte Zeichen im Raumnamen
        $roomname = preg_replace('/[^a-zA-Z0-9äöüßÄÖÜ\s\-_]/u', '', $roomname);

        // Raumtyp validieren
        if (!in_array($roomPriv, $this->allowedRoomPriv, true)) {
            $roomPriv = 0;
        }

        // Passwort validieren (nur bei privatem Raum mit Passwort)
        if ($roomPriv === 3) {
            if ($roomPw === '') {
                $this->showError($lang->get('admin_update_room_error_password_required') ?? '❌ Bei passwortgeschütztem Raum ist ein Passwort erforderlich.', $lang);
                exit;
            }
            if (mb_strlen($roomPw) > 100) {
                $roomPw = mb_substr($roomPw, 0, 100);
            }
        }

        // Nachricht validieren (max. Länge)
        if (mb_strlen($roomMessage) > 1000) {
            $roomMessage = mb_substr($roomMessage, 0, 1000);
        }

        try {
            $updates = [];
            $params = [];

            // Raumname
            $updates[] = "etchat_roomname = :roomname";
            $params['roomname'] = $roomname;

            // Raumrechte
            $updates[] = "etchat_room_goup = :room_priv";
            $params['room_priv'] = $roomPriv;

            // Passwort nur bei geschütztem Raum
            if ($roomPriv === 3) {
                $updates[] = "etchat_room_pw = :roompw";
                $params['roompw'] = $roomPw;
            } else {
                $updates[] = "etchat_room_pw = NULL";
            }

            // Raum-Nachricht
            $updates[] = "etchat_room_message = :roommessage";
            $params['roommessage'] = $roomMessage;

            // UPDATE
            $sql = "UPDATE {$this->_prefix}etchat_rooms 
                    SET " . implode(", ", $updates) . " 
                    WHERE etchat_id_room = :id";

            $params['id'] = $id;

            $this->dbObj->sqlSet($sql, $params);

            $this->dbObj->close();

            // Erfolgsmeldung in Session speichern
            $_SESSION['room_update_success'] = true;

            // Redirect nach Erfolg
            header("Location: ./?AdminRoomsIndex");
            exit;

        } catch (PDOException $e) {
            error_log("AdminUpdateRoom Fehler: " . $e->getMessage());
            $this->showError($lang->get('admin_update_room_error_database') ?? '❌ Datenbankfehler', $lang);
            exit;
        }
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $sessionToken !== '' && hash_equals($sessionToken, $token);
    }

    private function showError(string $message, $lang): void
    {
        $backText = $lang->get('admin_update_room_back_button') ?? '⬅️ Zurück zur Raum-Übersicht';
        
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '
              </div>';
        echo '<p><a href="./?AdminRoomsIndex" class="admin-button">' . $backText . '</a></p>';
        exit;
    }
}