<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRegUserEdit extends ConnectDB
{
    private const PROTECTED_AVATARS = ['noavatar.jpg', 'mod_ohne_pic.png', 'autodj.jpg', 'bot_avatar.png', 'system.png'];
    private const PROTECTED_ROLES = ['admin', 'co_admin', 'chatwache', 'grafik', 'mod'];
    private const PROTECTED_IDS = [1, 2]; // System-User

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden - Admin XML
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollenprüfung
        $allowedRoles = ["admin", "co_admin", "chatwache"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        $csrfSess = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';
        $csrfGet  = $_GET['csrf_token'] ?? '';
        $csrfPost = $_POST['csrf_token'] ?? '';

        // --- POST: Benutzer löschen ---
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['userids'])) {
            if (!$this->validateCsrf($csrfSess, $csrfPost)) {
                header("Location: ./");
                exit;
            }
            $this->deleteUsers($_POST['userids']);
        }

        // --- GET: Avatar löschen / Rolle ändern / Inaktive löschen ---
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $id = (int)($_GET['id'] ?? 0);

            if ($id > 0 && isset($_GET['delavatar'])) {
                if (!$this->validateCsrf($csrfSess, $csrfGet)) {
                    header("Location: ./");
                    exit;
                }
                $this->deleteAvatar($id);
            }

            if ($id > 0 && isset($_GET['mod'])) {
                $this->setRole($id, 'mod');
            }
            if ($id > 0 && isset($_GET['admin'])) {
                $this->setRole($id, 'admin');
            }

            if (isset($_GET['deleteinactive'], $_GET['inactive_months'])) {
                if (!$this->validateCsrf($csrfSess, $csrfGet)) {
                    header("Location: ./");
                    exit;
                }
                $months = (int)$_GET['inactive_months'];
                if ($months > 0) {
                    $this->deleteInactiveUsers($months);
                }
            }
        }

        $this->close();
        header("Location: ./?AdminRegUserIndex");
        exit;
    }

    private function validateCsrf(string $sessionToken, string $requestToken): bool
    {
        return $sessionToken !== '' && $requestToken !== '' && hash_equals($sessionToken, $requestToken);
    }

    private function deleteUsers(string|array $userids): void
    {
        $ids = is_array($userids) ? array_map('intval', $userids) : array_map('intval', explode(',', $userids));
        $ids = array_filter($ids);

        foreach ($ids as $id) {
            $this->deleteAvatar($id, true);
        }
    }

    private function deleteAvatar(int $id, bool $deleteUser = false): void
    {
        try {
            $avatar = $this->getUserAvatar($id);

            // Avatar-Datei löschen (wenn nicht geschützt)
            if ($avatar !== null && !in_array($avatar, self::PROTECTED_AVATARS, true)) {
                $filePath = "avatar/$avatar";
                if (is_file($filePath)) {
                    @unlink($filePath);
                }
            }

            // 1. Permanenter Avatar in etchAT_USER zurücksetzen
            $this->sqlSet(
                "UPDATE {$this->_prefix}etchat_user 
                 SET etchat_avatar = 'noavatar.jpg' 
                 WHERE etchat_user_id = ?",
                [$id]
            );

            // 2. 🔥 NEU: Avatar in etchAT_USERONLINE aktualisieren (falls User online)
            $this->updateOnlineAvatar($id);

            // 3. 🔥 NEU: Session-Hash zurücksetzen
            unset($_SESSION['etchat_' . $this->_prefix . 'reload_user_hash']);

            // Benutzer komplett löschen (falls gewünscht)
            if ($deleteUser) {
                $this->sqlSet(
                    "DELETE FROM {$this->_prefix}etchat_user WHERE etchat_user_id = ?",
                    [$id]
                );
            }
        } catch (PDOException $e) {
            // Fehler still ignorieren
        }
    }

    /**
     * 🔥 NEU: Aktualisiert den Avatar in etchAT_USERONLINE (für Live-Anzeige)
     * Nur wenn der User gerade online ist!
     */
    private function updateOnlineAvatar(int $userId): void
    {
        // Prüfen ob der User online ist
        $online = $this->sqlGet(
            "SELECT etchat_onlineid 
             FROM {$this->_prefix}etchat_useronline 
             WHERE etchat_onlineuser_fid = ?
             LIMIT 1",
            [$userId]
        );

        if (!empty($online)) {
            // User ist online → Avatar in useronline aktualisieren
            $sql = "UPDATE {$this->_prefix}etchat_useronline 
                    SET etchat_avatar = 'noavatar.jpg' 
                    WHERE etchat_onlineuser_fid = " . (int)$userId;
            
            $this->sqlSet($sql);
        }
    }

    private function getUserAvatar(int $id): ?string
    {
        $result = $this->sqlGet(
            "SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_user_id = ?",
            [$id]
        );
        return $result[0]['etchat_avatar'] ?? null;
    }

    private function setRole(int $id, string $userRole): void
    {
        try {
            $this->sqlSet(
                "UPDATE {$this->_prefix}etchat_user 
                 SET etchat_userprivilegien = ? 
                 WHERE etchat_user_id = ?",
                [$userRole, $id]
            );
        } catch (PDOException $e) {
            // Fehler still ignorieren
        }
    }

    private function deleteInactiveUsers(int $months): void
    {
        $cutoff = time() - ($months * 30 * 24 * 60 * 60);

        $rolePlaceholders = implode(',', array_fill(0, count(self::PROTECTED_ROLES), '?'));
        $idPlaceholders = implode(',', array_fill(0, count(self::PROTECTED_IDS), '?'));

        $sqlSelect = "SELECT etchat_user_id, etchat_avatar
                      FROM {$this->_prefix}etchat_user
                      WHERE (etchat_logintime < ? OR etchat_logintime IS NULL)
                        AND etchat_userprivilegien NOT IN ($rolePlaceholders)
                        AND etchat_user_id NOT IN ($idPlaceholders)";

        $params = array_merge([$cutoff], self::PROTECTED_ROLES, self::PROTECTED_IDS);
        
        $inactiveUsers = $this->sqlGet($sqlSelect, $params);

        if (is_array($inactiveUsers)) {
            foreach ($inactiveUsers as $user) {
                $avatar = $user['etchat_avatar'] ?? '';
                if ($avatar !== '' && !in_array($avatar, self::PROTECTED_AVATARS, true)) {
                    $filePath = "avatar/$avatar";
                    if (is_file($filePath)) {
                        @unlink($filePath);
                    }
                }
            }
        }

        $sqlDelete = "DELETE FROM {$this->_prefix}etchat_user
                      WHERE (etchat_logintime < ? OR etchat_logintime IS NULL)
                        AND etchat_userprivilegien NOT IN ($rolePlaceholders)
                        AND etchat_user_id NOT IN ($idPlaceholders)";

        try {
            $this->sqlSet($sqlDelete, $params);
        } catch (PDOException $e) {
            // Fehler still ignorieren
        }
    }

    // -------------------
    // PUBLIC SQL METHODS (für ConnectDB Kompatibilität)
    // -------------------
    public function sqlGet(string $sql, array $params = []): array
    {
        $stmt = $this->_connid->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function sqlSet(string $sql, array $params = []): int|bool
    {
        $stmt = $this->_connid->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }
}