<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditRoom extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $roomData = [];

    public function __construct()
    {
        parent::__construct();

        // Session sicher starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rollenprüfung
        $allowedRoles = ["admin", "co_admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // GET + POST kompatibel
        $data = $_GET + $_POST;

        // ID absichern
        $id = (int)($data['id'] ?? 0);
        if ($id <= 0) {
            echo $lang->get('admin_rooms_invalid_id') ?? 'Ungültige ID.';
            return;
        }

        // Raum-Daten laden
        $this->loadRoomData($id);

        if (empty($this->roomData)) {
            echo $lang->get('admin_rooms_not_found') ?? 'Eintrag nicht gefunden.';
            return;
        }

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    /**
     * Lädt die Raum-Daten aus der Datenbank
     */
    private function loadRoomData(int $id): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT 
                etchat_id_room, 
                etchat_roomname, 
                etchat_room_goup, 
                etchat_room_pw, 
                etchat_room_message 
             FROM {$this->_prefix}etchat_rooms 
             WHERE etchat_id_room = :id"
        );
        $stmt->execute([':id' => $id]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->roomData = is_array($result) ? $result : [];
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate($lang): void
    {
        // Template erwartet $feld[0] mit numerischen Indizes
        $numericalData = [];
        
        if (!empty($this->roomData)) {
            $numericalData[0] = [
                $this->roomData['etchat_id_room'] ?? 0,
                $this->roomData['etchat_roomname'] ?? '',
                $this->roomData['etchat_room_goup'] ?? 0,
                $this->roomData['etchat_room_pw'] ?? '',
                $this->roomData['etchat_room_message'] ?? ''
            ];
        }
        
        $feld = $numericalData;
        $csrfToken = $this->csrfToken;
        
        include __DIR__ . "/../../styles/admin_tpl/editRoom.tpl.html";
    }
}