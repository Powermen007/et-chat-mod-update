<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateText extends DbConectionMaker
{
    // Maximale Längen für Textfelder
    private const MAX_HEADER_LENGTH = 255;
    private const MAX_CONTENT_LENGTH = 65535;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // NEU: Sprache laden - Admin XML
        $lang = new LangXml("./lang/");

        // Eingaben
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // Admin + Pflichtfelder prüfen
        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        if ($role !== 'admin' || $id <= 0) {
            $this->showError($lang->get('admin_updatetext_error_access_denied', '❌ Zugriff verweigert'), $lang);
            exit;
        }

        // CSRF prüfen
        if (!$this->isValidCsrfToken($token)) {
            $this->showError($lang->get('admin_updatetext_error_csrf', '❌ Fehler') . ' (CSRF)', $lang);
            exit;
        }

        // Eingaben holen und validieren
        $ueber = trim((string)($_POST['ueberschrift'] ?? ''));
        $cod = trim((string)($_POST['code'] ?? ''));

        if ($ueber === '') {
            $this->showError($lang->get('admin_updatetext_error_header_empty', '❌ Überschrift darf nicht leer sein'), $lang);
            exit;
        }

        // Längenbegrenzungen
        if (mb_strlen($ueber) > self::MAX_HEADER_LENGTH) {
            $ueber = mb_substr($ueber, 0, self::MAX_HEADER_LENGTH);
        }
        
        if (mb_strlen($cod) > self::MAX_CONTENT_LENGTH) {
            $cod = mb_substr($cod, 0, self::MAX_CONTENT_LENGTH);
        }

        try {
            $pdo = $this->dbObj->getConnection();

            if (!$pdo) {
                $this->showError($lang->get('admin_updatetext_error_db_connection', '❌ Datenbankverbindung fehlgeschlagen'), $lang);
                exit;
            }

            $stmt = $pdo->prepare("
                UPDATE {$this->_prefix}etchat_texte
                SET header_text = :header,
                    content = :content
                WHERE id = :id
            ");

            $stmt->execute([
                ':header' => $ueber,
                ':content' => $cod,
                ':id' => $id
            ]);

            $this->dbObj->close();

            // Erfolgsmeldung in Session speichern
            $_SESSION['text_update_success'] = true;

            // Redirect nach Erfolg
            header("Location: ./?AdminTextsIndex");
            exit;

        } catch (PDOException $e) {
            error_log("AdminUpdateText Fehler: " . $e->getMessage());
            $this->showError($lang->get('admin_updatetext_error_db', '❌ Datenbankfehler'), $lang);
            exit;
        }
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $sessionToken !== '' && hash_equals($sessionToken, $token);
    }

    private function showError(string $message, object $lang): void
    {
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '
              </div>';
        echo '<p><a href="./?AdminTextsIndex" class="admin-button">' . $lang->get('admin_updatetext_back_button', '⬅️ Zurück zur Text-Übersicht') . '</a></p>';
        exit;
    }
}