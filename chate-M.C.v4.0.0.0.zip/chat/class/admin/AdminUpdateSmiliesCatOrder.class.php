<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateSmiliesCatOrder extends DbConectionMaker
{
    // Startgewicht für erste Kategorie
    private const START_WEIGHT = 10;
    private const WEIGHT_STEP = 10;
    
    // Maximale Anzahl Kategorien (Sicherheit)
    private const MAX_CATEGORIES = 500;

    public function __construct()
    {
        parent::__construct();

        // Session sicher starten
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Content-Type: application/json; charset=utf-8");

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rollen prüfen
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        if (!in_array($role, $allowedRoles, true)) {
            $this->sendError($lang->get('admin_updatecatorder_error_access') ?? "Keine Berechtigung", 403);
            exit;
        }

        // JSON lesen
        $raw = file_get_contents("php://input");
        $data = json_decode($raw, true);

        if (!is_array($data)) {
            $this->sendError($lang->get('admin_updatecatorder_error_invalid_json') ?? "Ungültige JSON-Daten", 400);
            exit;
        }

        // IDs auslesen
        $ids = $data['ids'] ?? [];

        if (!is_array($ids) || empty($ids)) {
            $this->sendError($lang->get('admin_updatecatorder_error_no_data') ?? "Keine Daten erhalten", 400);
            exit;
        }

        // Maximale Anzahl prüfen (Sicherheit gegen Overload)
        if (count($ids) > self::MAX_CATEGORIES) {
            $this->sendError($lang->get('admin_updatecatorder_error_too_many') ?? "Zu viele Kategorien (max. " . self::MAX_CATEGORIES . ")", 400);
            exit;
        }

        // IDs als Integer validieren
        $validIds = [];
        foreach ($ids as $id) {
            if (is_numeric($id) && (int)$id > 0) {
                $validIds[] = (int)$id;
            }
        }

        if (empty($validIds)) {
            $this->sendError($lang->get('admin_updatecatorder_error_invalid_ids') ?? "Keine gültigen IDs", 400);
            exit;
        }

        // CSRF prüfen (Header)
        $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

        if (!is_string($csrfHeader) || !hash_equals($sessionToken, $csrfHeader)) {
            $this->sendError($lang->get('admin_updatecatorder_error_csrf') ?? "Ungültiger CSRF Token", 403);
            exit;
        }

        try {
            $pdo = $this->dbObj->getConnection();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                UPDATE {$this->_prefix}etchat_smileys_cat
                SET gewicht = :weight
                WHERE id = :id
            ");

            $weight = self::START_WEIGHT;
            $updatedCount = 0;

            foreach ($validIds as $id) {
                $stmt->execute([
                    ':id' => $id,
                    ':weight' => $weight
                ]);
                
                if ($stmt->rowCount() > 0) {
                    $updatedCount++;
                }
                
                $weight += self::WEIGHT_STEP;
            }

            $pdo->commit();
            $this->dbObj->close();

            echo json_encode([
                "success" => true,
                "message" => "✅ " . ($lang->get('admin_updatecatorder_success') ?? "Sortierung gespeichert") . " ($updatedCount " . ($lang->get('admin_updatecatorder_categories') ?? "Kategorien") . " " . ($lang->get('admin_updatecatorder_updated') ?? "aktualisiert") . ")"
            ]);
            exit;

        } catch (PDOException $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log("AdminUpdateSmiliesCatOrder Fehler: " . $e->getMessage());
            $this->sendError($lang->get('admin_updatecatorder_error_database') ?? "Datenbankfehler", 500);
            exit;
        }
    }

    private function sendError(string $message, int $statusCode = 400): void
    {
        http_response_code($statusCode);
        echo json_encode([
            "success" => false,
            "error" => $message
        ]);
        exit;
    }
}