<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminGalleryCleaner extends DbConectionMaker
{
    private const ALLOWED_ROLES = ['admin', 'grafik', 'co_admin'];
    private const MAX_AGE = 604800; // 7 Tage

    private string $csrfKey;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        $this->csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';

        if (empty($_SESSION[$this->csrfKey])) {
            $_SESSION[$this->csrfKey] = bin2hex(random_bytes(16));
        }

        $csrfToken = $_SESSION[$this->csrfKey];

        $lang = (new LangXml())->getLang();
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($role, self::ALLOWED_ROLES, true)) {
            exit($lang->error[0]->tagData ?? 'Zugriff verweigert');
        }

        // 🔐 CSRF prüfen
        $token = $_GET['csrf_token'] ?? '';
        if (!$token || !hash_equals($csrfToken, $token)) {
            exit('Ungültiger CSRF-Token.');
        }

        // 🔥 CLEANER AUSFÜHREN
        [$log, $deleted] = $this->runCleaner();

        // 🔹 Variablen fürs Template
        $vari1 = $log;
        $vari2 = $deleted ? '1' : '0';

        // 🔹 Template laden
        $tplPath = __DIR__ . '/../../styles/admin_tpl/insertGalleryCleaner.tpl.html';

        if (!is_file($tplPath)) {
            exit('Template fehlt: ' . $tplPath);
        }

        include $tplPath;
    }

    private function runCleaner(): array
    {
        $uploadDir = realpath(__DIR__ . '/../../userpic/');
        $uploadDir = $uploadDir ? $uploadDir . DIRECTORY_SEPARATOR : null;

        if (!$uploadDir || !is_dir($uploadDir)) {
            return ['Upload-Verzeichnis nicht gefunden.', false];
        }

        $files = scandir($uploadDir);
        if ($files === false) {
            return ['Fehler beim Lesen des Verzeichnisses.', false];
        }

        $now = time();
        $deleted = false;
        $log = '';

        foreach ($files as $file) {

            if (in_array($file, ['.', '..', 'index.html', '.htaccess'], true)) {
                continue;
            }

            if (!preg_match('/\.(jpg|jpeg|png|gif)$/i', $file)) {
                continue;
            }

            $filePath = $uploadDir . $file;
            if (!is_file($filePath)) continue;

            $metaFile = $filePath . '.txt';
            if (!is_file($metaFile)) continue;

            $content = file_get_contents($metaFile);
            if ($content === false) continue;

            $parts = explode('|', trim($content));
            if (count($parts) < 2) continue;

            $date = DateTime::createFromFormat('d.m.Y H:i', trim($parts[1]));
            if (!$date) {
                $log .= 'Fehler: Datum ungültig bei <b>' . htmlspecialchars($file) . '</b><br>';
                continue;
            }

            if (($now - $date->getTimestamp()) <= self::MAX_AGE) {
                continue;
            }

            if (unlink($filePath)) {
                $log .= 'Bild <b>' . htmlspecialchars($file) . '</b> gelöscht.<br>';
                $deleted = true;
            } else {
                $log .= 'Fehler beim Löschen von <b>' . htmlspecialchars($file) . '</b><br>';
            }

            if (is_file($metaFile)) {
                unlink($metaFile);
                $log .= 'Meta <b>' . htmlspecialchars(basename($metaFile)) . '</b> gelöscht.<br>';
            }
        }

        if (!$deleted) {
            $log .= 'Keine Dateien älter als 7 Tage vorhanden.<br>';
        }

        return [$log, $deleted];
    }
}