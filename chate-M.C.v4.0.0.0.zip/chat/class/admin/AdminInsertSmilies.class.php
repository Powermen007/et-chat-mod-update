<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminInsertSmilies extends DbConectionMaker
{
    private array $allowedRoles = ["admin", "grafik", "co_admin"];
    private string $uploaddir;
    private string $message = '';

    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        $basePath = realpath(__DIR__ . '/../../smilies');
        if ($basePath === false) {
            throw new RuntimeException('Smilies-Verzeichnis nicht gefunden.');
        }
        $this->uploaddir = $basePath . DIRECTORY_SEPARATOR;

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rollen prüfen
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($userRole, $this->allowedRoles, true)) {
            echo $lang->get('admin_insertsmilies_error_access') ?? '<span style="color:red;">Zugriff verweigert</span>';
            exit;
        }

        // CSRF prüfen (Token NICHT löschen!)
        $csrfToken = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

        if (empty($csrfToken) || empty($sessionToken) || !hash_equals($sessionToken, $csrfToken)) {
            echo $lang->get('admin_insertsmilies_error_csrf') ?? '<span style="color:red;">Ungültiger CSRF-Token.</span>';
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cat'], $_POST['sign'], $_POST['gw'], $_FILES['smiliefile'])) {
            $this->handleUpload($_POST, $_FILES, $lang);
        } else {
            $this->showResult($lang);
        }
    }

    private function handleUpload(array $post, array $files, $lang): void
    {
        // Eingaben validieren
        $catName = trim($post['cat'] ?? '');
        $sign = trim($post['sign'] ?? '');
        $gewicht = max(1, min(99999, (int)($post['gw'] ?? 1)));

        if ($catName === '' || $sign === '') {
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmilies_error_required') ?? 'Kategorie und Kürzel sind Pflichtfelder!') . '</span>';
            $this->showResult($lang);
            return;
        }

        // Kategorie-Ordner erstellen (mit sicherem Namen)
        $safeCatName = preg_replace("/[^a-zA-Z0-9_-]/", "_", $catName);
        $catFolder = $this->uploaddir . $safeCatName . DIRECTORY_SEPARATOR;
        
        if (!is_dir($catFolder) && !mkdir($catFolder, 0775, true)) {
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmilies_error_folder') ?? 'Konnte Kategorie-Ordner nicht erstellen.') . '</span>';
            $this->showResult($lang);
            return;
        }

        // Datei validieren
        $originalName = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($files['smiliefile']['name']));
        $targetFile = $catFolder . $originalName;
        $notes = '';

        // Prüfen ob Datei bereits existiert → bei Smilies gewünscht: umbenennen mit Zeitstempel
        if (file_exists($targetFile)) {
            $nowname = time() . "_" . $originalName;
            $targetFile = $catFolder . $nowname;
            $notes = ($lang->get('admin_insertsmilies_file_exists') ?? 'Datei existiert bereits, umbenannt in') . " " . htmlspecialchars($nowname) . "<br>";
        } else {
            $nowname = $originalName;
        }

        // Prüfen, ob Smiley-Kürzel bereits existiert
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_smileys_id FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_sign = :sign"
        );
        $stmt->execute([':sign' => $sign]);
        $exists = $stmt->fetch();

        if ($exists) {
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmilies_error_sign_exists') ?? 'Dieses Kürzel existiert bereits!') . '</span>';
            $this->showResult($lang);
            return;
        }

        // Dateityp prüfen
        $mimeType = mime_content_type($files['smiliefile']['tmp_name']);
        $allowedTypes = ['image/png', 'image/gif', 'image/jpeg', 'image/webp'];
        $imageInfo = @getimagesize($files['smiliefile']['tmp_name']);

        if (!in_array($mimeType, $allowedTypes, true) || $imageInfo === false) {
            @unlink($files['smiliefile']['tmp_name']);
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmilies_error_invalid_type') ?? 'Ungültiger Dateityp! Nur PNG, GIF, JPEG, WEBP erlaubt.') . '</span>';
            $this->showResult($lang);
            return;
        }

        // Datei verschieben
        if (!move_uploaded_file($files['smiliefile']['tmp_name'], $targetFile)) {
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmilies_error_upload') ?? 'Fehler beim Upload') . '</span>';
            $this->showResult($lang);
            return;
        }

        // Relativen Pfad für die Datenbank
        $relativePath = "./smilies/{$safeCatName}/{$nowname}";

        // In Datenbank speichern
        try {
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_smileys
                (etchat_smileys_kat, etchat_smileys_sign, etchat_smileys_img, etchat_smileys_gewicht)
                VALUES (:cat, :sign, :img, :gewicht)",
                [
                    ':cat' => $catName,
                    ':sign' => $sign,
                    ':img' => $relativePath,
                    ':gewicht' => $gewicht
                ]
            );

            $this->message = '<span style="color:green;">' . ($lang->get('admin_insertsmilies_success') ?? 'Smiley erfolgreich hochgeladen!') . '</span><br>' . $notes;
            
        } catch (PDOException $e) {
            error_log("AdminInsertSmilies Fehler: " . $e->getMessage());
            $this->message = '<span style="color:red;">' . ($lang->get('admin_insertsmilies_error_database') ?? 'Datenbankfehler beim Speichern!') . '</span>';
        }

        $this->showResult($lang);
    }

    private function showResult($lang): void
    {
        $message = $this->message;
        include_once "styles/admin_tpl/insertSmiliesMessage.tpl.html";
        $this->dbObj->close();
    }
}