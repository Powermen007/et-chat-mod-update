<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteSmilies extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/");

        // Rollen prüfen
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        
        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->get('admin_deletesmilies_error_access') ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $sessionToken = $_SESSION[$csrfKey];

        // Request-Daten
        $id = (int)($_GET['id'] ?? 0);
        $requestToken = (string)($_GET['csrf_token'] ?? '');
        $picRaw = $_GET['pic'] ?? '';

        // CSRF + ID prüfen
        if ($id <= 0 || $requestToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            echo $lang->get('admin_deletesmilies_error_csrf') ?? "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            exit;
        }

        // Smiley aus DB löschen
        $this->deleteSmileyFromDatabase($id);

        // Datei löschen (falls vorhanden)
        $this->deleteSmileyFile($picRaw);

        $this->dbObj->close();

        // Redirect
        header("Location: ./?AdminSmiliesIndex");
        exit;
    }

    /**
     * Löscht den Smiley aus der Datenbank
     */
    private function deleteSmileyFromDatabase(int $id): void
    {
        try {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_id = :id",
                [':id' => $id]
            );
        } catch (PDOException $e) {
            error_log("AdminDeleteSmilies DB Fehler: " . $e->getMessage());
        }
    }

    /**
     * Löscht die Smiley-Datei vom Server
     */
    private function deleteSmileyFile(string $picPath): void
    {
        if (empty($picPath)) {
            return;
        }

        // Pfad bereinigen
        $picSafe = ltrim($picPath, './');
        
        $projectRoot = realpath(__DIR__ . '/../../');
        if ($projectRoot === false) {
            error_log("AdminDeleteSmilies: Projekt-Root nicht gefunden");
            return;
        }

        $fullPath = realpath($projectRoot . '/' . $picSafe);
        $smiliesRoot = realpath($projectRoot . '/smilies/');

        // Sicherheitscheck: Nur Dateien im Smilies-Ordner löschen
        if ($fullPath === false || $smiliesRoot === false) {
            error_log("AdminDeleteSmilies: Pfad-Validierung fehlgeschlagen");
            return;
        }

        if (!str_starts_with($fullPath, $smiliesRoot)) {
            error_log("AdminDeleteSmilies: Sicherheitsverletzung – Datei außerhalb des Smilies-Ordners: " . $fullPath);
            return;
        }

        if (!is_file($fullPath)) {
            error_log("AdminDeleteSmilies: Datei nicht gefunden: " . $fullPath);
            return;
        }

        // Datei löschen
        if (!unlink($fullPath)) {
            error_log("AdminDeleteSmilies: Konnte Datei nicht löschen: " . $fullPath);
        }
    }
}