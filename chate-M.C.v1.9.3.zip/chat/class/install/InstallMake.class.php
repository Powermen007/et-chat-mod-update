<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class InstallMake extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

		if ($this->_usedDatabase == "mysql") $sql_dump="install/mysql_db.sql";
		if ($this->_usedDatabase == "pgsql") $sql_dump="install/postgres_db.sql";

		if (file_exists($sql_dump)){
			$sql=explode("-- limit --", file_get_contents($sql_dump));
			for($a=0; $a<(count($sql)); $a++){
				$zeile=trim($sql[$a]);
				if (!empty( $zeile )) {
					$zeile = str_replace("###prefix###", $this->_prefix, $zeile);
					$this->dbObj->sqlSet($zeile);
				}
			}
			$this->dbObj->close();

			include_once("styles/install_tpl/installed.tpl.html");
		}
		else
			echo "Install directory was not found.";

	}
}
