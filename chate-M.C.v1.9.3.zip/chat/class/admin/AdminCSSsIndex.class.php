<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminCSSsIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$langData = $langObj->getLang();

		if (isset($langData->admin[0]->admin_menus[0])) {
			$lang = $langData->admin[0]->admin_menus[0];
		} else {
			$lang = (object)[ 'error' => [ (object)[ 'tagData' => 'Fehler: Sprachdatei unvollst�ndig.' ] ] ];
		}

		if (in_array($_SESSION["etchat_" . $this->_prefix . "user_priv"], ["admin", "grafik", "co_admin"])) {
			$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] = rand(1,999999999);

		$datei2 = $_SESSION['etchat_'.$this->_prefix.'style'];

		$data4 = $_GET['data3'];

		$print_css_list3=''.$data4.'';

		$print_css_list1='<form action="./?AdminCSSsIndex&data3='.$data4.'" method="post">
							<textarea id="b" name="text">';

		$datei = 'styles/'.$datei2.'/'.$data4.'';
        $handle = fopen($datei,"r+");
        $read_style = fread($handle, filesize($datei));
        $close = fclose($handle);
        $print_css_list= $read_style;

		$print_css_list2='</textarea></div><input type="hidden" name="data4" value="'.$data4.'"><input type="hidden" name="datei_css" value="styles/'.$datei2.'/'.$data4.'"><div class="codemirror-menu" id="editor-menu"><input type="submit" value="Speichern" name="submit"></div></form>';

			$this->initTemplate($lang, $print_css_list3, $print_css_list1, $print_css_list2, $print_css_list);

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}

	private function initTemplate($lang, $print_css_list3, $print_css_list1, $print_css_list2, $print_css_list){
		include_once("styles/admin_tpl/indexCSSs.tpl.html");
	}
}
if(isset($_POST['submit']))
{

$filename = $_POST['datei_css'];
$somecontent = $_POST['text'];
$data5 = $_POST['data4'];
if (is_writable($filename)) {

    if (!$fp = fopen($filename, "w+")) {
         print "Kann die Datei $filename nicht �ffnen";
         exit;
    }

    if (fwrite($fp, $somecontent) === FALSE) {
        print "Kann nicht in die Datei $filename schreiben";
        exit;
    }



	header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

   header("Location: ./?AdminCSSsIndex&data3=$data5&saved=1");

    fclose($fp);

} else {
    print "Die Datei $filename ist nicht schreibbar";
}
}
