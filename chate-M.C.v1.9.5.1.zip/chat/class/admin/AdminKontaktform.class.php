<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminKontaktform extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: text/html; charset=utf-8');

        $saved = isset($_GET['saved']);

        if (!isset($this->dbObj)) {
            die("Datenbankverbindung nicht vorhanden!");
        }

        if ($_SESSION['etchat_'.$this->_prefix.'user_priv'] !== "admin") {
            header("Location: ./");
            exit;
        }

        if (isset($_GET['delete'])) {
            $this->deleteField((int)$_GET['delete']);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->saveChanges();
        } else {
            $this->showForm($saved);
        }
    }

    private function showForm(bool $saved = false)
    {
        // Felder aus Kontaktformular-Tabelle laden
        $felder = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_kontakt_fields ORDER BY etchat_sort_order ASC");

        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="utf-8">
            <title>Kontaktformular Admin</title>
            <link href="styles/<?php echo $_SESSION['etchat_'.$this->_prefix.'style']; ?>/style.css" rel="stylesheet" type="text/css"/>
            <style>
                table { border-collapse: collapse; width: 100%; }
                th, td { border: 1px solid #ccc; padding: 5px; text-align: left; vertical-align: top; }
                textarea { width: 100%; min-height: 60px; }
                tr.dragging { background-color: #f0f0f0; }
                .success-banner {
                    background-color: #4CAF50;
                    color: white;
                    padding: 10px;
                    position: relative;
                    border-radius: 5px;
                    margin-bottom: 10px;
                }
                .close-btn {
                    position: absolute;
                    right: 10px;
                    top: 5px;
                    cursor: pointer;
                    font-weight: bold;
                }
            </style>
        </head>
        <body id="adminbereich_body">

        <?php if ($saved): ?>
            <div class="success-banner" id="successBanner">
                Änderungen wurden erfolgreich gespeichert.
                <span class="close-btn" onclick="document.getElementById('successBanner').style.display='none'">X</span>
            </div>
        <?php endif; ?>

        <?php
        // Rollen-abhängiger Link zurück zum Adminmenü
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $roleLinks = [
            "admin"     => "./?AdminIndex",
            "chatwache" => "./?AdminIndexChatwache",
            "co_admin"  => "./?AdminIndexCoAdmin"
        ];
        $backlinkUrl = $roleLinks[$role] ?? "./";
        echo "<a href=\"$backlinkUrl\">&lt;&lt;&lt; zurück zum Adminmenü</a><hr>";
        ?>

        <h2>Kontaktformular bearbeiten</h2>

        <form method="post" action="" id="adminForm">
        <table id="bewerbungsTable">
        <thead>
        <tr>
            <th> </th>
            <th>Label</th>
            <th>Typ</th>
            <th>Sichtbar</th>
            <th>Pflicht</th>
            <th>Optionen (eine pro Zeile)</th>
            <th>Aktion</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($felder as $feld): ?>
            <tr data-id="<?php echo $feld['etchat_id']; ?>" draggable="true">
                <td style="text-align:center;">
                    <img class="img_verschieben" src="./img/verschieben.png" alt="verschieben" style="cursor:move;">
                </td>
                <td>
                    <input type="text" name="label[<?php echo $feld['etchat_id']; ?>]"
                           value="<?php echo htmlspecialchars($feld['etchat_field_name']); ?>">
                </td>
                <td><?php echo htmlspecialchars($feld['etchat_field_type']); ?></td>
                <td style="text-align:center;">
                    <input type="checkbox" name="sichtbar[<?php echo $feld['etchat_id']; ?>]"
                           value="1" <?php echo ($feld['etchat_visible'] ? 'checked' : ''); ?>>
                </td>
                <td style="text-align:center;">
                    <input type="checkbox" name="pflicht[<?php echo $feld['etchat_id']; ?>]"
                           value="1" <?php echo ($feld['etchat_required'] ? 'checked' : ''); ?>>
                </td>
                <td>
                    <?php if (in_array($feld['etchat_field_type'], ['select','checkbox'])): ?>
                        <?php
                        $optionen = [];
                        if (!empty($feld['etchat_options'])) {
                            $decoded = json_decode($feld['etchat_options'], true);
                            if (is_array($decoded)) $optionen = $decoded;
                        }
                        echo '<textarea name="optionen['.$feld['etchat_id'].']">'.htmlspecialchars(implode("\n",$optionen),ENT_QUOTES,'UTF-8').'</textarea>';
                        ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($feld['etchat_custom']==1): ?>
                        <a href="?AdminKontaktform&delete=<?php echo $feld['etchat_id']; ?>" onclick="return confirm('Dieses Feld wirklich löschen?')">Löschen</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        </table>

        <!-- Neues Feld -->
        <h3>Neues Feld hinzufügen</h3>
        <label>Label: <input type="text" name="new_label"></label>
        | <label>Typ:
            <select name="new_type">
                <option value="text">Textfeld</option>
                <option value="email">E-Mail</option>
                <option value="date">Datum</option>
                <option value="select">Select</option>
                <option value="checkbox">Checkbox</option>
            </select>
        </label>
        | <label>Sichtbar: <input type="checkbox" name="new_visible" value="1" checked></label>
        | <label>Pflicht: <input type="checkbox" name="new_required" value="1"></label>
        <br>
        <label>Optionen (eine pro Zeile):<br>
            <textarea name="new_options"></textarea>
        </label>
        <br><br>
        <input type="hidden" name="order" id="orderInput" value="">
        <button type="submit">Änderungen speichern</button>
        </form>

        <script>
// --- Drag & Drop und Warnung bei Änderungen ---
const tableBody = document.querySelector("#bewerbungsTable tbody");
let dragSrcEl = null;

// Drag-Handle nur auf Bild
tableBody.querySelectorAll('.img_verschieben').forEach(handle => {
    handle.addEventListener('mousedown', e => {
        const tr = e.target.closest('tr');
        tr.draggable = true;
    });
});

tableBody.addEventListener('dragstart', e => {
    dragSrcEl = e.target.closest('tr');
    dragSrcEl.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
});

tableBody.addEventListener('dragover', e => {
    e.preventDefault();
    const target = e.target.closest('tr');
    if(target && target !== dragSrcEl){
        const rect = target.getBoundingClientRect();
        const next = (e.clientY - rect.top)/(rect.bottom - rect.top) > 0.5;
        tableBody.insertBefore(dragSrcEl, next ? target.nextSibling : target);
    }
});

tableBody.addEventListener('dragend', e => {
    dragSrcEl.classList.remove('dragging');
    dragSrcEl.draggable = false;
    updateOrder();
});

let formChanged = false;
document.querySelectorAll("#bewerbungsTable input, #bewerbungsTable textarea").forEach(el => {
    el.addEventListener("input", () => formChanged = true);
    el.addEventListener("change", () => formChanged = true);
});
document.querySelectorAll("input[name='new_label'], textarea[name='new_options'], select[name='new_type'], input[name='new_visible']").forEach(el => {
    el.addEventListener("input", () => formChanged = true);
    el.addEventListener("change", () => formChanged = true);
});

function updateOrder(){
    const order = [];
    tableBody.querySelectorAll('tr').forEach(row => order.push(row.dataset.id));
    document.getElementById('orderInput').value = order.join(',');
    formChanged = true;
}

window.addEventListener("beforeunload", function (e) {
    if (formChanged) {
        e.preventDefault();
        e.returnValue = '';
    }
});

document.getElementById('adminForm').addEventListener("submit", function() {
    formChanged = false;
});

window.addEventListener('DOMContentLoaded', function() {
    let banner = document.getElementById('successBanner');
    if(banner) setTimeout(() => banner.style.display = 'none', 5000);
});
        </script>
        </body>
        </html>
        <?php
    }

    private function saveChanges()
    {
        $order = isset($_POST['order']) ? explode(',', $_POST['order']) : [];

        // Bestehende Felder aktualisieren
        foreach ($_POST['label'] as $id => $label) {
            $sichtbar = isset($_POST['sichtbar'][$id]) ? 1 : 0;
            $pflicht  = isset($_POST['pflicht'][$id]) ? 1 : 0;
            $optionen = null;
            if (isset($_POST['optionen'][$id])) {
                $lines = array_filter(array_map('trim', explode("\n", $_POST['optionen'][$id])));
                if (!empty($lines)) $optionen = json_encode(array_values($lines), JSON_UNESCAPED_UNICODE);
            }
            $labelEsc = $this->dbObj->escape($label);
            $optionenEsc = $optionen !== null ? $this->dbObj->escape($optionen) : null;
            $id = (int)$id;

            $this->dbObj->sqlSet("
                UPDATE {$this->_prefix}etchat_kontakt_fields
                SET
                    etchat_field_name = '{$labelEsc}',
                    etchat_visible = '{$sichtbar}',
                    etchat_required = '{$pflicht}',
                    etchat_options = " . ($optionenEsc !== null ? "'{$optionenEsc}'" : "NULL") . "
                WHERE etchat_id = '{$id}'
            ");
        }

        // Sortierreihenfolge updaten
        foreach ($order as $sort => $id) {
            $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_kontakt_fields SET etchat_sort_order='{$sort}' WHERE etchat_id='{$id}'");
        }

        // Neues Feld speichern
        if (!empty($_POST['new_label'])) {
            $labelEsc = $this->dbObj->escape($_POST['new_label']);
            $typeEsc  = $this->dbObj->escape($_POST['new_type']);
            $sichtbar = isset($_POST['new_visible']) ? 1 : 0;
            $pflicht  = isset($_POST['new_required']) ? 1 : 0;
            $optionen = null;
            if (!empty($_POST['new_options'])) {
                $lines = array_filter(array_map('trim', explode("\n", $_POST['new_options'])));
                if (!empty($lines)) $optionen = json_encode(array_values($lines), JSON_UNESCAPED_UNICODE);
            }
            $optionenEsc = $optionen !== null ? $this->dbObj->escape($optionen) : null;

            $maxSort = $this->dbObj->sqlGet("SELECT MAX(etchat_sort_order) AS max_sort FROM {$this->_prefix}etchat_kontakt_fields LIMIT 1");
            $sort = (isset($maxSort[0]['max_sort']) ? (int)$maxSort[0]['max_sort'] : 0) + 1;

            $this->dbObj->sqlSet("
                INSERT INTO {$this->_prefix}etchat_kontakt_fields
                (etchat_field_name, etchat_field_type, etchat_visible, etchat_required, etchat_options, etchat_sort_order, etchat_custom)
                VALUES
                ('{$labelEsc}', '{$typeEsc}', '{$sichtbar}', '{$pflicht}', " . ($optionenEsc !== null ? "'{$optionenEsc}'" : "NULL") . ", '{$sort}', 1)
            ");
        }

        header("Location: ./?AdminKontaktform&saved=1");
        exit;
    }

    private function deleteField($id)
    {
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_kontakt_fields WHERE etchat_id='{$id}' AND etchat_custom=1");
        header("Location: ./?AdminKontaktform");
        exit;
    }
}
