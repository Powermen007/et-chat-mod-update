<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

if (version_compare(phpversion(), '8.0.0', '<')) echo "<div style=\"color:red\">FEHLER!!!<br><br>PHP Version = ".phpversion()." (sollte jedoch >= 8.0.0 sein!)</div>";
else		
header('Location: ../?InstallIndex');