-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 21. Jul 2025 um 15:24
-- Server-Version: 10.5.8-MariaDB-log
-- PHP-Version: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `chat`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_blacklist`
--

CREATE TABLE `###prefix###etchat_blacklist` (
  `etchat_blacklist_id` int(8) NOT NULL,
  `etchat_blacklist_ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_blacklist_userid` int(8) NOT NULL,
  `etchat_blacklist_time` int(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_config`
--

CREATE TABLE `###prefix###etchat_config` (
  `etchat_config_id` int(11) NOT NULL,
  `etchat_config_radio_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_reloadsequenz` int(11) NOT NULL,
  `etchat_config_messages_im_chat` int(11) NOT NULL,
  `etchat_config_style` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_loeschen_nach` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_lang` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_wu` int(4) NOT NULL,
  `etchat_config_wuan` int(5) NOT NULL,
  `etchat_config_wuza` tinyint(2) NOT NULL,
  `etchat_config_wupau` tinyint(2) NOT NULL,
  `etchat_config_yo` int(4) NOT NULL,
  `etchat_config_bi` int(4) NOT NULL,
  `etchat_config_biup` int(4) NOT NULL,
  `etchat_config_av` int(4) NOT NULL,
  `etchat_config_pro` tinyint(1) NOT NULL,
  `etchat_config_onlie_li` tinyint(1) NOT NULL,
  `etchat_config_radio_box` int(4) NOT NULL,
  `etchat_config_radio_box_hi` int(3) NOT NULL,
  `etchat_config_radio_box_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_wb` int(3) NOT NULL,
  `etchat_config_wb_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_user_online` int(3) NOT NULL,
  `etchat_config_name_user` tinyint(1) NOT NULL,
  `etchat_config_name_user_anz` tinyint(3) NOT NULL DEFAULT 10,
  `etchat_config_vollbild` int(3) NOT NULL,
  `etchat_config_admin_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_mod_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_user_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_gast_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_time` tinyint(1) NOT NULL,
  `etchat_config_chat_gender` tinyint(1) NOT NULL,
  `etchat_config_chat_privi` tinyint(1) NOT NULL,
  `etchat_config_chat_anzsmily` tinyint(2) NOT NULL DEFAULT 5,
  `etchat_config_ol_privi` tinyint(1) NOT NULL,
  `etchat_config_be_in_pic` tinyint(1) NOT NULL,
  `etchat_config_chat_pic` tinyint(1) NOT NULL,
  `etchat_config_scroll` tinyint(1) NOT NULL,
  `etchat_config_dj_box_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_dj_box` tinyint(1) NOT NULL,
  `etchat_config_radio_se_li` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_config_radio_se` tinyint(1) NOT NULL,
  `etchat_config_reg_user_an` tinyint(1) NOT NULL,
  `etchat_config_gast` tinyint(1) NOT NULL,
  `etchat_config_wartung` tinyint(1) NOT NULL,
  `etchat_config_reg_an_aus` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_config`
--

INSERT INTO `###prefix###etchat_config` (`etchat_config_id`, `etchat_config_radio_name`, `etchat_config_reloadsequenz`, `etchat_config_messages_im_chat`, `etchat_config_style`, `etchat_config_loeschen_nach`, `etchat_config_lang`, `etchat_config_wu`, `etchat_config_wuan`, `etchat_config_wuza`, `etchat_config_wupau`, `etchat_config_yo`, `etchat_config_bi`, `etchat_config_biup`, `etchat_config_av`, `etchat_config_pro`, `etchat_config_onlie_li`, `etchat_config_radio_box`, `etchat_config_radio_box_hi`, `etchat_config_radio_box_li`, `etchat_config_wb`, `etchat_config_wb_li`, `etchat_config_user_online`, `etchat_config_name_user`, `etchat_config_name_user_anz`, `etchat_config_vollbild`, `etchat_config_admin_color`, `etchat_config_mod_color`, `etchat_config_user_color`, `etchat_config_gast_color`, `etchat_config_time`, `etchat_config_chat_gender`, `etchat_config_chat_privi`, `etchat_config_chat_anzsmily`, `etchat_config_ol_privi`, `etchat_config_be_in_pic`, `etchat_config_chat_pic`, `etchat_config_scroll`, `etchat_config_dj_box_li`, `etchat_config_dj_box`, `etchat_config_radio_se_li`, `etchat_config_radio_se`, `etchat_config_reg_user_an`, `etchat_config_gast`, `etchat_config_wartung`, `etchat_config_reg_an_aus`) VALUES
(1, 'Chat-DMR by Radio-Dino v.1.9.1', 5000, 100, 'etchat_dino', '14', 'lang_de.xml', 1, 100, 3, 15, 1, 1, 1, 1, 1, 1, 1, 175, 'http://chris.pcip.de/chatm/radio-box/radio-box.php', 1, 'http://chris.pcip.de/joomla/index.php/wunsch-und-grussbox-chat', 1, 1, 10, 1, '#b83231', '#864b4b', '#00FF00', '#FFFF00', 1, 1, 1, 5, 1, 1, 1, 1, 'https://www.dance-music-radio.de/index.php?seite=radio_wunschbox', 1, 'http://chris.pcip.de/joomla/index.php/sendeplan', 1, 1, 1, 0, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_kick_user`
--

CREATE TABLE `###prefix###etchat_kick_user` (
  `id` int(11) NOT NULL,
  `etchat_kicked_user_id` int(11) NOT NULL,
  `etchat_kicked_user_time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_menu`
--

CREATE TABLE `###prefix###etchat_menu` (
  `id` int(10) NOT NULL,
  `menu` int(1) NOT NULL,
  `link_text` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_active` int(1) NOT NULL,
  `image` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `gewicht` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_menu`
--

INSERT INTO `###prefix###etchat_menu` (`id`, `menu`, `link_text`, `image_active`, `image`, `url`, `target`, `gewicht`) VALUES
(1, 1, 'Homepage', 1, 'homepage.png', 'http://chris.pcip.de/joomla/', '_blank', 10),
(3, 1, 'Teamspeak', 1, 'teamspeak.png', 'ts3server://chris.pcip.de', '_blank', 30),
(4, 2, 'Homepage', 0, 'homepage.gif', 'http://chris.pcip.de/joomla/', '_blank', 10),
(5, 2, 'Datenschutz', 0, '', '#\" onClick=\"popup=window.open(\'http://chris.pcip.de/chatm/?Text&id=2\',\'\',\'toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=900,height=600\'); return false;', '_blank', 40),
(6, 3, 'Banner', 1, 'banner_1.jpg', 'http://chris.pcip.de/joomla/', '_blank', 10),
(7, 3, 'Dance Music Radio', 1, 'dmr.png', 'https://dance-music-radio.de', '_blank', 20),
(8, 2, 'Player I', 0, '', '#\" onClick=\"popup=window.open(\'http://chris.pcip.de/chatm/radio-box/radio-box.php\',\'\',\'toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=300,height=175\'); return false; ', '_blank', 45),
(9, 2, 'Impressum', 0, '', '#\" onClick=\"popup=window.open(\'http://chris.pcip.de/chatm/?Text&id=1\',\'\',\'toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=900,height=600\'); return false;  ', '_blank', 35);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_messages`
--

CREATE TABLE `###prefix###etchat_messages` (
  `etchat_id` bigint(20) UNSIGNED NOT NULL,
  `etchat_user_fid` int(8) NOT NULL,
  `etchat_text` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_text_css` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_timestamp` bigint(20) NOT NULL,
  `etchat_fid_room` int(11) NOT NULL DEFAULT 1,
  `etchat_privat` int(8) DEFAULT 0,
  `etchat_user_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_radio_box`
--

CREATE TABLE `###prefix###etchat_radio_box` (
  `etchat_radio_id` int(1) NOT NULL,
  `etchat_radio_horst` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_port` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_radio_typ` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_stream` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_color` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_bit` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_radio_box` tinyint(1) NOT NULL,
  `etchat_radio_player` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_radio_box`
--

INSERT INTO `###prefix###etchat_radio_box` (`etchat_radio_id`, `etchat_radio_horst`, `etchat_radio_port`, `etchat_radio_typ`, `etchat_radio_stream`, `etchat_radio_name`, `etchat_radio_color`, `etchat_radio_bit`, `etchat_radio_box`, `etchat_radio_player`) VALUES
(1, 'dance-music-radio.de', '8002', 'shoutcast', 'https://dance-music-radio.de:8002/radio.mp3', 'DMR by Radio-Dino', '#214fcf', '256', 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_rooms`
--

CREATE TABLE `###prefix###etchat_rooms` (
  `etchat_id_room` int(3) UNSIGNED NOT NULL,
  `etchat_roomname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_room_goup` int(6) NOT NULL DEFAULT 0,
  `etchat_room_pw` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_room_message` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_rooms`
--

INSERT INTO `###prefix###etchat_rooms` (`etchat_id_room`, `etchat_roomname`, `etchat_room_goup`, `etchat_room_pw`, `etchat_room_message`) VALUES
(1, 'Lobby', 0, NULL, '<marquee bgcolor=#F00><b>Der Neue Chat ist da !!</marquee></b>');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_smileys`
--

CREATE TABLE `###prefix###etchat_smileys` (
  `etchat_smileys_id` int(5) NOT NULL,
  `etchat_smileys_kat` varchar(255) NOT NULL,
  `etchat_smileys_sign` varchar(20) NOT NULL,
  `etchat_smileys_img` varchar(100) NOT NULL,
  `etchat_smileys_gewicht` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_smileys_cat`
--

CREATE TABLE `###prefix###etchat_smileys_cat` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `aktiv` varchar(3) NOT NULL,
  `gewicht` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `###prefix###etchat_smileys_cat`
--

INSERT INTO `###prefix###etchat_smileys_cat` (`id`, `name`, `aktiv`, `gewicht`) VALUES
(1, 'Lachen/Weinen', 'on', 80),
(2, 'Tanzen', 'on', 30),
(3, 'Winter', 'off', 160),
(4, 'FrÃ¼hling', 'off', 170),
(5, 'Sommer', 'on', 180),
(6, 'Herbst', 'off', 190),
(7, 'Fun', 'on', 70),
(8, 'BegrÃ¼ÃŸen', 'on', 10),
(9, 'Bitte/Danke', 'on', 90),
(10, 'Verabschieden', 'on', 20),
(11, 'Modi', 'on', 120),
(12, 'Team', 'on', 110),
(13, 'Sendungen', 'on', 100),
(14, 'Essen/Trinken', 'on', 130),
(15, 'Ostern', 'off', 250),
(16, 'Feuerwerk', 'on', 150),
(17, 'Weihnachten', 'off', 275),
(18, 'Helloween', 'off', 260),
(19, 'Rock/Gothic/Country', 'on', 50),
(20, 'Disco', 'on', 40),
(21, 'Instrumente', 'on', 55),
(22, 'Lieb haben', 'on', 85),
(23, 'Geburstag', 'on', 140),
(24, 'Comic/Tiere', 'on', 60),
(25, 'Silvester', 'off', 280),
(26, 'Karneval', 'off', 240),
(27, 'Oktoberfest', 'off', 270),
(28, 'Ab 18 ...', 'on', 290),
(29, 'FuÃŸball', 'off', 95);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_start_boxes`
--

CREATE TABLE `###prefix###etchat_start_boxes` (
  `id` int(10) UNSIGNED NOT NULL,
  `ort` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_start_boxes`
--

INSERT INTO `###prefix###etchat_start_boxes` (`id`, `ort`, `header_text`, `content`) VALUES
(1, 'Index Li.', 'Chat', '&lt;p style=&quot;text-align: center;&quot;&gt;Wir w&amp;uuml;nschen euch viel Spass &amp;amp; eine sch&amp;ouml;ne Unterhaltung im Chat.&lt;br&gt;Die amtssprache ist ðŸ‡©ðŸ‡ª ðŸ˜&lt;/p&gt;'),
(2, 'Index Re.', 'Wir bieten Jede Menge SpaÃŸ', '&lt;center&gt;Ihr k&amp;ouml;nnt den Chat jederzeit als Gast betreten.&lt;br&gt;Es steht euch frei, euren Benutzernamen mit einem Passwort zu sichern.&lt;br&gt;&lt;br&gt;So wird es gemacht:&lt;/center&gt;&lt;center&gt;\r\n&lt;ol&gt;\r\n&lt;li style=&quot;text-align: left;&quot;&gt;Klickt auf Registrieren / Passwort vergessen.&lt;/li&gt;\r\n&lt;li style=&quot;text-align: left;&quot;&gt;F&amp;uuml;llt das Formular aus mit E-Mail-Adresse.&lt;/li&gt;\r\n&lt;li style=&quot;text-align: left;&quot;&gt;Geht in euer E-Mail Postfach (evtl. Spam) und folgt dem Link innerhalb von 30 min.&lt;/li&gt;\r\n&lt;li style=&quot;text-align: left;&quot;&gt;Die E-Mail-Adresse ist wichtig! Zum Freischalten und falls ihr euer Passwort vergesst!&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;br&gt;Somit ist euer Name gesch&amp;uuml;tzt&lt;br&gt;Wir w&amp;uuml;nschen euch viel Spass &amp;amp; sch&amp;ouml;ne Unterhaltung im Chat.&lt;/center&gt;'),
(3, 'oben', 'Der neue ET-Chat-M.C.v.1.9.1', 'Index Text Oben'),
(4, 'unten', 'Index Unten', '&lt;p style=&quot;text-align: center;&quot;&gt;Index Text Unten&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_texte`
--

CREATE TABLE `###prefix###etchat_texte` (
  `id` int(10) UNSIGNED NOT NULL,
  `ort` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_texte`
--

INSERT INTO `###prefix###etchat_texte` (`id`, `ort`, `header_text`, `content`) VALUES
(1, 'Impressum', 'Impressum', '&lt;p&gt;Chris &amp;amp; Mike Stra&amp;szlig;e Nr. PLZ / Ort E-mail&lt;/p&gt;'),
(2, 'Datenschutz', 'Datenschutz', '&lt;h1&gt;Datenschutzerkl&amp;auml;rung&lt;/h1&gt;\r\n&lt;p&gt;Stand: 29. Mai 2025&lt;/p&gt;\r\n&lt;h2&gt;Inhalts&amp;uuml;bersicht&lt;/h2&gt;\r\n&lt;ul class=&quot;index&quot;&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m3&quot;&gt;Verantwortlicher&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#mOverview&quot;&gt;&amp;Uuml;bersicht der Verarbeitungen&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m2427&quot;&gt;Ma&amp;szlig;gebliche Rechtsgrundlagen&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m27&quot;&gt;Sicherheitsma&amp;szlig;nahmen&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m12&quot;&gt;Allgemeine Informationen zur Datenspeicherung und L&amp;ouml;schung&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m225&quot;&gt;Bereitstellung des Onlineangebots und Webhosting&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m134&quot;&gt;Einsatz von Cookies&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m367&quot;&gt;Registrierung, Anmeldung und Nutzerkonto&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m432&quot;&gt;Community Funktionen&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m182&quot;&gt;Kontakt- und Anfrageverwaltung&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a class=&quot;index-link&quot; href=&quot;#m296&quot;&gt;Audioinhalte&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m3&quot;&gt;Verantwortlicher&lt;/h2&gt;\r\n&lt;p&gt;Vorname Name&lt;br&gt;Stra&amp;szlig;e&lt;br&gt;Ort PLZ&lt;/p&gt;\r\n&lt;p&gt;E-Mail-Adresse: &lt;a href=&quot;mailto:email@email.de&quot;&gt;email@email.de&lt;/a&gt;&lt;/p&gt;\r\n&lt;h2 id=&quot;mOverview&quot;&gt;&amp;Uuml;bersicht der Verarbeitungen&lt;/h2&gt;\r\n&lt;p&gt;Die nachfolgende &amp;Uuml;bersicht fasst die Arten der verarbeiteten Daten und die Zwecke ihrer Verarbeitung zusammen und verweist auf die betroffenen Personen.&lt;/p&gt;\r\n&lt;h3&gt;Arten der verarbeiteten Daten&lt;/h3&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Bestandsdaten.&lt;/li&gt;\r\n&lt;li&gt;Kontaktdaten.&lt;/li&gt;\r\n&lt;li&gt;Inhaltsdaten.&lt;/li&gt;\r\n&lt;li&gt;Nutzungsdaten.&lt;/li&gt;\r\n&lt;li&gt;Meta-, Kommunikations- und Verfahrensdaten.&lt;/li&gt;\r\n&lt;li&gt;Protokolldaten.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h3&gt;Kategorien betroffener Personen&lt;/h3&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Kommunikationspartner.&lt;/li&gt;\r\n&lt;li&gt;Nutzer.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h3&gt;Zwecke der Verarbeitung&lt;/h3&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Erbringung vertraglicher Leistungen und Erf&amp;uuml;llung vertraglicher Pflichten.&lt;/li&gt;\r\n&lt;li&gt;Kommunikation.&lt;/li&gt;\r\n&lt;li&gt;Sicherheitsma&amp;szlig;nahmen.&lt;/li&gt;\r\n&lt;li&gt;Reichweitenmessung.&lt;/li&gt;\r\n&lt;li&gt;Organisations- und Verwaltungsverfahren.&lt;/li&gt;\r\n&lt;li&gt;Feedback.&lt;/li&gt;\r\n&lt;li&gt;Profile mit nutzerbezogenen Informationen.&lt;/li&gt;\r\n&lt;li&gt;Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.&lt;/li&gt;\r\n&lt;li&gt;Informationstechnische Infrastruktur.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m2427&quot;&gt;Ma&amp;szlig;gebliche Rechtsgrundlagen&lt;/h2&gt;\r\n&lt;p&gt;&lt;strong&gt;Ma&amp;szlig;gebliche Rechtsgrundlagen nach der DSGVO: &lt;/strong&gt;Im Folgenden erhalten Sie eine &amp;Uuml;bersicht der Rechtsgrundlagen der DSGVO, auf deren Basis wir personenbezogene Daten verarbeiten. Bitte nehmen Sie zur Kenntnis, dass neben den Regelungen der DSGVO nationale Datenschutzvorgaben in Ihrem bzw. unserem Wohn- oder Sitzland gelten k&amp;ouml;nnen. Sollten ferner im Einzelfall speziellere Rechtsgrundlagen ma&amp;szlig;geblich sein, teilen wir Ihnen diese in der Datenschutzerkl&amp;auml;rung mit.&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;&lt;strong&gt;Einwilligung (Art. 6 Abs. 1 S. 1 lit. a) DSGVO)&lt;/strong&gt; - Die betroffene Person hat ihre Einwilligung in die Verarbeitung der sie betreffenden personenbezogenen Daten f&amp;uuml;r einen spezifischen Zweck oder mehrere bestimmte Zwecke gegeben.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO)&lt;/strong&gt; - Die Verarbeitung ist f&amp;uuml;r die Erf&amp;uuml;llung eines Vertrags, dessen Vertragspartei die betroffene Person ist, oder zur Durchf&amp;uuml;hrung vorvertraglicher Ma&amp;szlig;nahmen erforderlich, die auf Anfrage der betroffenen Person erfolgen.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO)&lt;/strong&gt; - die Verarbeitung ist zur Wahrung der berechtigten Interessen des Verantwortlichen oder eines Dritten notwendig, vorausgesetzt, dass die Interessen, Grundrechte und Grundfreiheiten der betroffenen Person, die den Schutz personenbezogener Daten verlangen, nicht &amp;uuml;berwiegen.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Nationale Datenschutzregelungen in Deutschland: &lt;/strong&gt;Zus&amp;auml;tzlich zu den Datenschutzregelungen der DSGVO gelten nationale Regelungen zum Datenschutz in Deutschland. Hierzu geh&amp;ouml;rt insbesondere das Gesetz zum Schutz vor Missbrauch personenbezogener Daten bei der Datenverarbeitung (Bundesdatenschutzgesetz &amp;ndash; BDSG). Das BDSG enth&amp;auml;lt insbesondere Spezialregelungen zum Recht auf Auskunft, zum Recht auf L&amp;ouml;schung, zum Widerspruchsrecht, zur Verarbeitung besonderer Kategorien personenbezogener Daten, zur Verarbeitung f&amp;uuml;r andere Zwecke und zur &amp;Uuml;bermittlung sowie automatisierten Entscheidungsfindung im Einzelfall einschlie&amp;szlig;lich Profiling. Ferner k&amp;ouml;nnen Landesdatenschutzgesetze der einzelnen Bundesl&amp;auml;nder zur Anwendung gelangen.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Hinweis auf Geltung DSGVO und Schweizer DSG: &lt;/strong&gt;Diese Datenschutzhinweise dienen sowohl der Informationserteilung nach dem Schweizer DSG als auch nach der Datenschutzgrundverordnung (DSGVO). Aus diesem Grund bitten wir Sie zu beachten, dass aufgrund der breiteren r&amp;auml;umlichen Anwendung und Verst&amp;auml;ndlichkeit die Begriffe der DSGVO verwendet werden. Insbesondere statt der im Schweizer DSG verwendeten Begriffe &amp;bdquo;Bearbeitung&quot; von &amp;bdquo;Personendaten&quot;, &quot;&amp;uuml;berwiegendes Interesse&quot; und &quot;besonders sch&amp;uuml;tzenswerte Personendaten&quot; werden die in der DSGVO verwendeten Begriffe &amp;bdquo;Verarbeitung&quot; von &amp;bdquo;personenbezogenen Daten&quot; sowie &quot;berechtigtes Interesse&quot; und &quot;besondere Kategorien von Daten&quot; verwendet. Die gesetzliche Bedeutung der Begriffe wird jedoch im Rahmen der Geltung des Schweizer DSG weiterhin nach dem Schweizer DSG bestimmt.&lt;/p&gt;\r\n&lt;h2 id=&quot;m27&quot;&gt;Sicherheitsma&amp;szlig;nahmen&lt;/h2&gt;\r\n&lt;p&gt;Wir treffen nach Ma&amp;szlig;gabe der gesetzlichen Vorgaben unter Ber&amp;uuml;cksichtigung des Stands der Technik, der Implementierungskosten und der Art, des Umfangs, der Umst&amp;auml;nde und der Zwecke der Verarbeitung sowie der unterschiedlichen Eintrittswahrscheinlichkeiten und des Ausma&amp;szlig;es der Bedrohung der Rechte und Freiheiten nat&amp;uuml;rlicher Personen geeignete technische und organisatorische Ma&amp;szlig;nahmen, um ein dem Risiko angemessenes Schutzniveau zu gew&amp;auml;hrleisten.&lt;/p&gt;\r\n&lt;p&gt;Zu den Ma&amp;szlig;nahmen geh&amp;ouml;ren insbesondere die Sicherung der Vertraulichkeit, Integrit&amp;auml;t und Verf&amp;uuml;gbarkeit von Daten durch Kontrolle des physischen und elektronischen Zugangs zu den Daten als auch des sie betreffenden Zugriffs, der Eingabe, der Weitergabe, der Sicherung der Verf&amp;uuml;gbarkeit und ihrer Trennung. Des Weiteren haben wir Verfahren eingerichtet, die eine Wahrnehmung von Betroffenenrechten, die L&amp;ouml;schung von Daten und Reaktionen auf die Gef&amp;auml;hrdung der Daten gew&amp;auml;hrleisten. Ferner ber&amp;uuml;cksichtigen wir den Schutz personenbezogener Daten bereits bei der Entwicklung bzw. Auswahl von Hardware, Software sowie Verfahren entsprechend dem Prinzip des Datenschutzes, durch Technikgestaltung und durch datenschutzfreundliche Voreinstellungen.&lt;/p&gt;\r\n&lt;p&gt;Sicherung von Online-Verbindungen durch TLS-/SSL-Verschl&amp;uuml;sselungstechnologie (HTTPS): Um die Daten der Nutzer, die &amp;uuml;ber unsere Online-Dienste &amp;uuml;bertragen werden, vor unerlaubten Zugriffen zu sch&amp;uuml;tzen, setzen wir auf die TLS-/SSL-Verschl&amp;uuml;sselungstechnologie. Secure Sockets Layer (SSL) und Transport Layer Security (TLS) sind die Eckpfeiler der sicheren Daten&amp;uuml;bertragung im Internet. Diese Technologien verschl&amp;uuml;sseln die Informationen, die zwischen der Website oder App und dem Browser des Nutzers (oder zwischen zwei Servern) &amp;uuml;bertragen werden, wodurch die Daten vor unbefugtem Zugriff gesch&amp;uuml;tzt sind. TLS, als die weiterentwickelte und sicherere Version von SSL, gew&amp;auml;hrleistet, dass alle Daten&amp;uuml;bertragungen den h&amp;ouml;chsten Sicherheitsstandards entsprechen. Wenn eine Website durch ein SSL-/TLS-Zertifikat gesichert ist, wird dies durch die Anzeige von HTTPS in der URL signalisiert. Dies dient als ein Indikator f&amp;uuml;r die Nutzer, dass ihre Daten sicher und verschl&amp;uuml;sselt &amp;uuml;bertragen werden.&lt;/p&gt;\r\n&lt;h2 id=&quot;m12&quot;&gt;Allgemeine Informationen zur Datenspeicherung und L&amp;ouml;schung&lt;/h2&gt;\r\n&lt;p&gt;Wir l&amp;ouml;schen personenbezogene Daten, die wir verarbeiten, gem&amp;auml;&amp;szlig; den gesetzlichen Bestimmungen, sobald die zugrundeliegenden Einwilligungen widerrufen werden oder keine weiteren rechtlichen Grundlagen f&amp;uuml;r die Verarbeitung bestehen. Dies betrifft F&amp;auml;lle, in denen der urspr&amp;uuml;ngliche Verarbeitungszweck entf&amp;auml;llt oder die Daten nicht mehr ben&amp;ouml;tigt werden. Ausnahmen von dieser Regelung bestehen, wenn gesetzliche Pflichten oder besondere Interessen eine l&amp;auml;ngere Aufbewahrung oder Archivierung der Daten erfordern.&lt;/p&gt;\r\n&lt;p&gt;Insbesondere m&amp;uuml;ssen Daten, die aus handels- oder steuerrechtlichen Gr&amp;uuml;nden aufbewahrt werden m&amp;uuml;ssen oder deren Speicherung notwendig ist zur Rechtsverfolgung oder zum Schutz der Rechte anderer nat&amp;uuml;rlicher oder juristischer Personen, entsprechend archiviert werden.&lt;/p&gt;\r\n&lt;p&gt;Unsere Datenschutzhinweise enthalten zus&amp;auml;tzliche Informationen zur Aufbewahrung und L&amp;ouml;schung von Daten, die speziell f&amp;uuml;r bestimmte Verarbeitungsprozesse gelten.&lt;/p&gt;\r\n&lt;p&gt;Bei mehreren Angaben zur Aufbewahrungsdauer oder L&amp;ouml;schungsfristen eines Datums, ist stets die l&amp;auml;ngste Frist ma&amp;szlig;geblich.&lt;/p&gt;\r\n&lt;p&gt;Beginnt eine Frist nicht ausdr&amp;uuml;cklich zu einem bestimmten Datum und betr&amp;auml;gt sie mindestens ein Jahr, so startet sie automatisch am Ende des Kalenderjahres, in dem das fristausl&amp;ouml;sende Ereignis eingetreten ist. Im Fall laufender Vertragsverh&amp;auml;ltnisse, in deren Rahmen Daten gespeichert werden, ist das fristausl&amp;ouml;sende Ereignis der Zeitpunkt des Wirksamwerdens der K&amp;uuml;ndigung oder sonstige Beendigung des Rechtsverh&amp;auml;ltnisses.&lt;/p&gt;\r\n&lt;p&gt;Daten, die nicht mehr f&amp;uuml;r den urspr&amp;uuml;nglich vorgesehenen Zweck, sondern aufgrund gesetzlicher Vorgaben oder anderer Gr&amp;uuml;nde aufbewahrt werden, verarbeiten wir ausschlie&amp;szlig;lich zu den Gr&amp;uuml;nden, die ihre Aufbewahrung rechtfertigen.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Aufbewahrung und L&amp;ouml;schung von Daten: &lt;/strong&gt;Die folgenden allgemeinen Fristen gelten f&amp;uuml;r die Aufbewahrung und Archivierung nach deutschem Recht:\r\n&lt;ul&gt;\r\n&lt;li&gt;10 Jahre - Aufbewahrungsfrist f&amp;uuml;r B&amp;uuml;cher und Aufzeichnungen, Jahresabschl&amp;uuml;sse, Inventare, Lageberichte, Er&amp;ouml;ffnungsbilanz sowie die zu ihrem Verst&amp;auml;ndnis erforderlichen Arbeitsanweisungen und sonstigen Organisationsunterlagen (&amp;sect; 147 Abs. 1 Nr. 1 i.V.m. Abs. 3 AO, &amp;sect; 14b Abs. 1 UStG, &amp;sect; 257 Abs. 1 Nr. 1 i.V.m. Abs. 4 HGB).&lt;/li&gt;\r\n&lt;li&gt;8 Jahre - Buchungsbelege, wie z.&amp;nbsp;B. Rechnungen und Kostenbelege (&amp;sect; 147 Abs. 1 Nr. 4 und 4a i.V.m. Abs. 3 Satz 1 AO sowie &amp;sect; 257 Abs. 1 Nr. 4 i.V.m. Abs. 4 HGB).&lt;/li&gt;\r\n&lt;li&gt;6 Jahre - &amp;Uuml;brige Gesch&amp;auml;ftsunterlagen: empfangene Handels- oder Gesch&amp;auml;ftsbriefe, Wiedergaben der abgesandten Handels- oder Gesch&amp;auml;ftsbriefe, sonstige Unterlagen, soweit sie f&amp;uuml;r die Besteuerung von Bedeutung sind, z.&amp;nbsp;B. Stundenlohnzettel, Betriebsabrechnungsb&amp;ouml;gen, Kalkulationsunterlagen, Preisauszeichnungen, aber auch Lohnabrechnungsunterlagen, soweit sie nicht bereits Buchungsbelege sind und Kassenstreifen (&amp;sect; 147 Abs. 1 Nr. 2, 3, 5 i.V.m. Abs. 3 AO, &amp;sect; 257 Abs. 1 Nr. 2 u. 3 i.V.m. Abs. 4 HGB).&lt;/li&gt;\r\n&lt;li&gt;3 Jahre - Daten, die erforderlich sind, um potenzielle Gew&amp;auml;hrleistungs- und Schadensersatzanspr&amp;uuml;che oder &amp;auml;hnliche vertragliche Anspr&amp;uuml;che und Rechte zu ber&amp;uuml;cksichtigen sowie damit verbundene Anfragen zu bearbeiten, basierend auf fr&amp;uuml;heren Gesch&amp;auml;ftserfahrungen und &amp;uuml;blichen Branchenpraktiken, werden f&amp;uuml;r die Dauer der regul&amp;auml;ren gesetzlichen Verj&amp;auml;hrungsfrist von drei Jahren gespeichert (&amp;sect;&amp;sect; 195, 199 BGB).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m225&quot;&gt;Bereitstellung des Onlineangebots und Webhosting&lt;/h2&gt;\r\n&lt;p&gt;Wir verarbeiten die Daten der Nutzer, um ihnen unsere Online-Dienste zur Verf&amp;uuml;gung stellen zu k&amp;ouml;nnen. Zu diesem Zweck verarbeiten wir die IP-Adresse des Nutzers, die notwendig ist, um die Inhalte und Funktionen unserer Online-Dienste an den Browser oder das Endger&amp;auml;t der Nutzer zu &amp;uuml;bermitteln.&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Verarbeitete Datenarten:&lt;/strong&gt; Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&amp;auml;t und -frequenz, verwendete Ger&amp;auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen); Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen). Protokolldaten (z.&amp;nbsp;B. Logfiles betreffend Logins oder den Abruf von Daten oder Zugriffszeiten.).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Betroffene Personen:&lt;/strong&gt; Nutzer (z.&amp;nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Zwecke der Verarbeitung:&lt;/strong&gt; Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit; Informationstechnische Infrastruktur (Betrieb und Bereitstellung von Informationssystemen und technischen Ger&amp;auml;ten (Computer, Server etc.)). Sicherheitsma&amp;szlig;nahmen.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Aufbewahrung und L&amp;ouml;schung:&lt;/strong&gt; L&amp;ouml;schung entsprechend Angaben im Abschnitt &quot;Allgemeine Informationen zur Datenspeicherung und L&amp;ouml;schung&quot;.&lt;/li&gt;\r\n&lt;li class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Erhebung von Zugriffsdaten und Logfiles: &lt;/strong&gt;Der Zugriff auf unser Onlineangebot wird in Form von sogenannten &quot;Server-Logfiles&quot; protokolliert. Zu den Serverlogfiles k&amp;ouml;nnen die Adresse und der Name der abgerufenen Webseiten und Dateien, Datum und Uhrzeit des Abrufs, &amp;uuml;bertragene Datenmengen, Meldung &amp;uuml;ber erfolgreichen Abruf, Browsertyp nebst Version, das Betriebssystem des Nutzers, Referrer URL (die zuvor besuchte Seite) und im Regelfall IP-Adressen und der anfragende Provider geh&amp;ouml;ren. Die Serverlogfiles k&amp;ouml;nnen zum einen zu Sicherheitszwecken eingesetzt werden, z.&amp;nbsp;B. um eine &amp;Uuml;berlastung der Server zu vermeiden (insbesondere im Fall von missbr&amp;auml;uchlichen Angriffen, sogenannten DDoS-Attacken), und zum anderen, um die Auslastung der Server und ihre Stabilit&amp;auml;t sicherzustellen; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). &lt;/span&gt;&lt;strong&gt;L&amp;ouml;schung von Daten:&lt;/strong&gt; Logfile-Informationen werden f&amp;uuml;r die Dauer von maximal 30 Tagen gespeichert und danach gel&amp;ouml;scht oder anonymisiert. Daten, deren weitere Aufbewahrung zu Beweiszwecken erforderlich ist, sind bis zur endg&amp;uuml;ltigen Kl&amp;auml;rung des jeweiligen Vorfalls von der L&amp;ouml;schung ausgenommen.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m134&quot;&gt;Einsatz von Cookies&lt;/h2&gt;\r\n&lt;p&gt;Unter dem Begriff &amp;bdquo;Cookies&quot; werden Funktionen, die Informationen auf Endger&amp;auml;ten der Nutzer speichern und aus ihnen auslesen, verstanden. Cookies k&amp;ouml;nnen ferner in Bezug auf unterschiedliche Anliegen Einsatz finden, etwa zu Zwecken der Funktionsf&amp;auml;higkeit, der Sicherheit und des Komforts von Onlineangeboten sowie der Erstellung von Analysen der Besucherstr&amp;ouml;me. Wir verwenden Cookies gem&amp;auml;&amp;szlig; den gesetzlichen Vorschriften. Dazu holen wir, wenn erforderlich, vorab die Zustimmung der Nutzer ein. Ist eine Zustimmung nicht notwendig, setzen wir auf unsere berechtigten Interessen. Dies gilt, wenn das Speichern und Auslesen von Informationen unerl&amp;auml;sslich ist, um ausdr&amp;uuml;cklich angeforderte Inhalte und Funktionen bereitstellen zu k&amp;ouml;nnen. Dazu z&amp;auml;hlen etwa die Speicherung von Einstellungen sowie die Sicherstellung der Funktionalit&amp;auml;t und Sicherheit unseres Onlineangebots. Die Einwilligung kann jederzeit widerrufen werden. Wir informieren klar &amp;uuml;ber deren Umfang und welche Cookies genutzt werden.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Hinweise zu datenschutzrechtlichen Rechtsgrundlagen: &lt;/strong&gt;Ob wir personenbezogene Daten mithilfe von Cookies verarbeiten, h&amp;auml;ngt von einer Einwilligung ab. Liegt eine Einwilligung vor, dient sie als Rechtsgrundlage. Ohne Einwilligung st&amp;uuml;tzen wir uns auf unsere berechtigten Interessen, die vorstehend in diesem Abschnitt und im Kontext der jeweiligen Dienste und Verfahren erl&amp;auml;utert sind.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Speicherdauer:&amp;nbsp;&lt;/strong&gt;Im Hinblick auf die Speicherdauer werden die folgenden Arten von Cookies unterschieden:&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;&lt;strong&gt;Tempor&amp;auml;re Cookies (auch: Session- oder Sitzungscookies):&lt;/strong&gt; Tempor&amp;auml;re Cookies werden sp&amp;auml;testens gel&amp;ouml;scht, nachdem ein Nutzer ein Onlineangebot verlassen und sein Endger&amp;auml;t (z.&amp;nbsp;B. Browser oder mobile Applikation) geschlossen hat.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Permanente Cookies:&lt;/strong&gt; Permanente Cookies bleiben auch nach dem Schlie&amp;szlig;en des Endger&amp;auml;ts gespeichert. So k&amp;ouml;nnen beispielsweise der Log-in-Status gespeichert und bevorzugte Inhalte direkt angezeigt werden, wenn der Nutzer eine Website erneut besucht. Ebenso k&amp;ouml;nnen die mithilfe von Cookies erhobenen Nutzerdaten zur Reichweitenmessung Verwendung finden. Sofern wir Nutzern keine expliziten Angaben zur Art und Speicherdauer von Cookies mitteilen (z.&amp;nbsp;B. im Rahmen der Einholung der Einwilligung), sollten sie davon ausgehen, dass diese permanent sind und die Speicherdauer bis zu zwei Jahre betragen kann.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Allgemeine Hinweise zum Widerruf und Widerspruch (Opt-out):&amp;nbsp;&lt;/strong&gt;Nutzer k&amp;ouml;nnen die von ihnen abgegebenen Einwilligungen jederzeit widerrufen und zudem einen Widerspruch gegen die Verarbeitung entsprechend den gesetzlichen Vorgaben, auch mittels der Privatsph&amp;auml;re-Einstellungen ihres Browsers, erkl&amp;auml;ren.&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Verarbeitete Datenarten:&lt;/strong&gt; Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Betroffene Personen:&lt;/strong&gt; Nutzer (z.&amp;nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).&lt;/li&gt;\r\n&lt;li class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). Einwilligung (Art. 6 Abs. 1 S. 1 lit. a) DSGVO).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Verarbeitung von Cookie-Daten auf Grundlage einer Einwilligung: &lt;/strong&gt;Wir setzen eine Einwilligungs-Management-L&amp;ouml;sung ein, bei der die Einwilligung der Nutzer zur Verwendung von Cookies oder zu den im Rahmen der Einwilligungs-Management-L&amp;ouml;sung genannten Verfahren und Anbietern eingeholt wird. Dieses Verfahren dient der Einholung, Protokollierung, Verwaltung und dem Widerruf von Einwilligungen, insbesondere bezogen auf den Einsatz von Cookies und vergleichbaren Technologien, die zur Speicherung, zum Auslesen und zur Verarbeitung von Informationen auf den Endger&amp;auml;ten der Nutzer eingesetzt werden. Im Rahmen dieses Verfahrens werden die Einwilligungen der Nutzer f&amp;uuml;r die Nutzung von Cookies und die damit verbundenen Verarbeitungen von Informationen, einschlie&amp;szlig;lich der im Einwilligungs-Management-Verfahren genannten spezifischen Verarbeitungen und Anbieter, eingeholt. Die Nutzer haben zudem die M&amp;ouml;glichkeit, ihre Einwilligungen zu verwalten und zu widerrufen. Die Einwilligungserkl&amp;auml;rungen werden gespeichert, um eine erneute Abfrage zu vermeiden und den Nachweis der Einwilligung gem&amp;auml;&amp;szlig; der gesetzlichen Anforderungen f&amp;uuml;hren zu k&amp;ouml;nnen. Die Speicherung erfolgt serverseitig und/oder in einem Cookie (sogenanntes Opt-In-Cookie) oder mittels vergleichbarer Technologien, um die Einwilligung einem spezifischen Nutzer oder dessen Ger&amp;auml;t zuordnen zu k&amp;ouml;nnen. Sofern keine spezifischen Angaben zu den Anbietern von Einwilligungs-Management-Diensten vorliegen, gelten folgende allgemeine Hinweise: Die Dauer der Speicherung der Einwilligung betr&amp;auml;gt bis zu zwei Jahre. Dabei wird ein pseudonymer Nutzer-Identifikator erstellt, der zusammen mit dem Zeitpunkt der Einwilligung, den Angaben zum Umfang der Einwilligung (z.&amp;nbsp;B. betreffende Kategorien von Cookies und/oder Diensteanbieter) sowie Informationen &amp;uuml;ber den Browser, das System und das verwendete Endger&amp;auml;t gespeichert wird; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Einwilligung (Art. 6 Abs. 1 S. 1 lit. a) DSGVO).&lt;/span&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m367&quot;&gt;Registrierung, Anmeldung und Nutzerkonto&lt;/h2&gt;\r\n&lt;p&gt;Nutzer k&amp;ouml;nnen ein Nutzerkonto anlegen. Im Rahmen der Registrierung werden den Nutzern die erforderlichen Pflichtangaben mitgeteilt und zu Zwecken der Bereitstellung des Nutzerkontos auf Grundlage vertraglicher Pflichterf&amp;uuml;llung verarbeitet. Zu den verarbeiteten Daten geh&amp;ouml;ren insbesondere die Login-Informationen (Nutzername, Passwort sowie eine E-Mail-Adresse).&lt;/p&gt;\r\n&lt;p&gt;Im Rahmen der Inanspruchnahme unserer Registrierungs- und Anmeldefunktionen sowie der Nutzung des Nutzerkontos speichern wir die IP-Adresse und den Zeitpunkt der jeweiligen Nutzerhandlung. Die Speicherung erfolgt auf Grundlage unserer berechtigten Interessen als auch jener der Nutzer an einem Schutz vor Missbrauch und sonstiger unbefugter Nutzung. Eine Weitergabe dieser Daten an Dritte erfolgt grunds&amp;auml;tzlich nicht, es sei denn, sie ist zur Verfolgung unserer Anspr&amp;uuml;che erforderlich oder es besteht eine gesetzliche Verpflichtung hierzu.&lt;/p&gt;\r\n&lt;p&gt;Die Nutzer k&amp;ouml;nnen &amp;uuml;ber Vorg&amp;auml;nge, die f&amp;uuml;r deren Nutzerkonto relevant sind, wie z.&amp;nbsp;B. technische &amp;Auml;nderungen, per E-Mail informiert werden.&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Verarbeitete Datenarten:&lt;/strong&gt; Bestandsdaten (z.&amp;nbsp;B. der vollst&amp;auml;ndige Name, Wohnadresse, Kontaktinformationen, Kundennummer, etc.); Kontaktdaten (z.&amp;nbsp;B. Post- und E-Mail-Adressen oder Telefonnummern); Inhaltsdaten (z. B. textliche oder bildliche Nachrichten und Beitr&amp;auml;ge sowie die sie betreffenden Informationen, wie z. B. Angaben zur Autorenschaft oder Zeitpunkt der Erstellung); Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&amp;auml;t und -frequenz, verwendete Ger&amp;auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen). Protokolldaten (z.&amp;nbsp;B. Logfiles betreffend Logins oder den Abruf von Daten oder Zugriffszeiten.).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Betroffene Personen:&lt;/strong&gt; Nutzer (z.&amp;nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Zwecke der Verarbeitung:&lt;/strong&gt; Erbringung vertraglicher Leistungen und Erf&amp;uuml;llung vertraglicher Pflichten; Sicherheitsma&amp;szlig;nahmen; Organisations- und Verwaltungsverfahren. Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Aufbewahrung und L&amp;ouml;schung:&lt;/strong&gt; L&amp;ouml;schung entsprechend Angaben im Abschnitt &quot;Allgemeine Informationen zur Datenspeicherung und L&amp;ouml;schung&quot;. L&amp;ouml;schung nach K&amp;uuml;ndigung.&lt;/li&gt;\r\n&lt;li class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO). Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Registrierung mit Pseudonymen: &lt;/strong&gt;Nutzer d&amp;uuml;rfen statt Klarnamen Pseudonyme als Nutzernamen verwenden; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).&lt;/span&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Profile der Nutzer sind &amp;ouml;ffentlich: &lt;/strong&gt;Die Profile der Nutzer sind &amp;ouml;ffentlich sichtbar und zug&amp;auml;nglich.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;L&amp;ouml;schung von Daten nach K&amp;uuml;ndigung: &lt;/strong&gt;Wenn Nutzer ihr Nutzerkonto gek&amp;uuml;ndigt haben, werden deren Daten im Hinblick auf das Nutzerkonto, vorbehaltlich einer gesetzlichen Erlaubnis, Pflicht oder Einwilligung der Nutzer, gel&amp;ouml;scht; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).&lt;/span&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m432&quot;&gt;Community Funktionen&lt;/h2&gt;\r\n&lt;p&gt;Die von uns bereitgestellten Community Funktionen erlauben es Nutzern miteinander in Konversationen oder sonst miteinander in einen Austausch zu treten. Hierbei bitten wir zu beachten, dass die Nutzung der Communityfunktionen nur unter Beachtung der geltenden Rechtslage, unserer Bedingungen und Richtlinien sowie der Rechte anderer Nutzer und Dritter gestattet ist.&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Verarbeitete Datenarten:&lt;/strong&gt; Bestandsdaten (z.&amp;nbsp;B. der vollst&amp;auml;ndige Name, Wohnadresse, Kontaktinformationen, Kundennummer, etc.). Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&amp;auml;t und -frequenz, verwendete Ger&amp;auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Betroffene Personen:&lt;/strong&gt; Nutzer (z.&amp;nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Zwecke der Verarbeitung:&lt;/strong&gt; Erbringung vertraglicher Leistungen und Erf&amp;uuml;llung vertraglicher Pflichten; Sicherheitsma&amp;szlig;nahmen. Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Aufbewahrung und L&amp;ouml;schung:&lt;/strong&gt; L&amp;ouml;schung entsprechend Angaben im Abschnitt &quot;Allgemeine Informationen zur Datenspeicherung und L&amp;ouml;schung&quot;.&lt;/li&gt;\r\n&lt;li class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO). Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Beitr&amp;auml;ge der Nutzer sind &amp;ouml;ffentlich: &lt;/strong&gt;Die von Nutzern erstellten Beitr&amp;auml;ge und Inhalte sind &amp;ouml;ffentlich sichtbar und zug&amp;auml;nglich; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).&lt;/span&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Speicherung von Daten zu Sicherheitszwecken: &lt;/strong&gt;Die Beitr&amp;auml;ge und sonstige Eingaben der Nutzer werden zu Zwecken der Community- und Konversationsfunktionen verarbeitet und, vorbehaltlich gesetzlicher Pflichten oder gesetzlicher Erlaubnis nicht an Dritte herausgegeben. Eine Herausgabepflicht kann insbesondere im Fall von rechtswidrigen Beitr&amp;auml;gen zu Zwecken der Rechtsverfolgung entstehen. Wir weisen darauf hin, dass neben den Inhalten der Beitr&amp;auml;ge auch deren Zeitpunkt und die IP-Adresse der Nutzer gespeichert werden. Dies geschieht, um zum Schutz anderer Nutzer und der Community angemessene Ma&amp;szlig;nahmen ergreifen zu k&amp;ouml;nnen; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).&lt;/span&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m182&quot;&gt;Kontakt- und Anfrageverwaltung&lt;/h2&gt;\r\n&lt;p&gt;Bei der Kontaktaufnahme mit uns (z.&amp;nbsp;B. per Post, Kontaktformular, E-Mail, Telefon oder via soziale Medien) sowie im Rahmen bestehender Nutzer- und Gesch&amp;auml;ftsbeziehungen werden die Angaben der anfragenden Personen verarbeitet, soweit dies zur Beantwortung der Kontaktanfragen und etwaiger angefragter Ma&amp;szlig;nahmen erforderlich ist.&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Verarbeitete Datenarten:&lt;/strong&gt; Bestandsdaten (z.&amp;nbsp;B. der vollst&amp;auml;ndige Name, Wohnadresse, Kontaktinformationen, Kundennummer, etc.); Kontaktdaten (z.&amp;nbsp;B. Post- und E-Mail-Adressen oder Telefonnummern); Inhaltsdaten (z. B. textliche oder bildliche Nachrichten und Beitr&amp;auml;ge sowie die sie betreffenden Informationen, wie z. B. Angaben zur Autorenschaft oder Zeitpunkt der Erstellung); Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&amp;auml;t und -frequenz, verwendete Ger&amp;auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen). Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Betroffene Personen:&lt;/strong&gt; Kommunikationspartner.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Zwecke der Verarbeitung:&lt;/strong&gt; Kommunikation; Organisations- und Verwaltungsverfahren; Feedback (z.&amp;nbsp;B. Sammeln von Feedback via Online-Formular). Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Aufbewahrung und L&amp;ouml;schung:&lt;/strong&gt; L&amp;ouml;schung entsprechend Angaben im Abschnitt &quot;Allgemeine Informationen zur Datenspeicherung und L&amp;ouml;schung&quot;.&lt;/li&gt;\r\n&lt;li class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Kontaktformular: &lt;/strong&gt;Bei Kontaktaufnahme &amp;uuml;ber unser Kontaktformular, per E-Mail oder anderen Kommunikationswegen, verarbeiten wir die uns &amp;uuml;bermittelten personenbezogenen Daten zur Beantwortung und Bearbeitung des jeweiligen Anliegens. Dies umfasst in der Regel Angaben wie Name, Kontaktinformationen und gegebenenfalls weitere Informationen, die uns mitgeteilt werden und zur angemessenen Bearbeitung erforderlich sind. Wir nutzen diese Daten ausschlie&amp;szlig;lich f&amp;uuml;r den angegebenen Zweck der Kontaktaufnahme und Kommunikation; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Vertragserf&amp;uuml;llung und vorvertragliche Anfragen (Art. 6 Abs. 1 S. 1 lit. b) DSGVO), Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).&lt;/span&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;m296&quot;&gt;Audioinhalte&lt;/h2&gt;\r\n&lt;p&gt;Wir nutzen Hosting-Angebote von Dienstanbietern, um unsere Audio-Inhalte zum Anh&amp;ouml;ren und zum Download anzubieten. Dabei setzen wir Plattformen ein, die das Hochladen, Speichern und Verbreiten von Audio-Material erm&amp;ouml;glichen.&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Verarbeitete Datenarten:&lt;/strong&gt; Nutzungsdaten (z. B. Seitenaufrufe und Verweildauer, Klickpfade, Nutzungsintensit&amp;auml;t und -frequenz, verwendete Ger&amp;auml;tetypen und Betriebssysteme, Interaktionen mit Inhalten und Funktionen); Meta-, Kommunikations- und Verfahrensdaten (z. B. IP-Adressen, Zeitangaben, Identifikationsnummern, beteiligte Personen). Protokolldaten (z.&amp;nbsp;B. Logfiles betreffend Logins oder den Abruf von Daten oder Zugriffszeiten.).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Betroffene Personen:&lt;/strong&gt; Nutzer (z.&amp;nbsp;B. Webseitenbesucher, Nutzer von Onlinediensten).&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Zwecke der Verarbeitung:&lt;/strong&gt; Reichweitenmessung (z.&amp;nbsp;B. Zugriffsstatistiken, Erkennung wiederkehrender Besucher); Profile mit nutzerbezogenen Informationen (Erstellen von Nutzerprofilen). Bereitstellung unseres Onlineangebotes und Nutzerfreundlichkeit.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;Aufbewahrung und L&amp;ouml;schung:&lt;/strong&gt; L&amp;ouml;schung entsprechend Angaben im Abschnitt &quot;Allgemeine Informationen zur Datenspeicherung und L&amp;ouml;schung&quot;.&lt;/li&gt;\r\n&lt;li class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Weitere Hinweise zu Verarbeitungsprozessen, Verfahren und Diensten:&lt;/strong&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;m-elements&quot;&gt;\r\n&lt;li&gt;&lt;strong&gt;Abrufstatistiken beim Audiohosting: &lt;/strong&gt;Erfassung und Analyse von Nutzungsdaten bei der Bereitstellung von Audioinhalten. Dies beinhaltet die Sammlung von Daten &amp;uuml;ber die H&amp;auml;ufigkeit des Abrufs, die Dauer der Nutzung und geografische Informationen der Nutzer. Die gewonnenen Statistiken helfen bei der Beurteilung der Reichweite und des Engagements der H&amp;ouml;rer. Erfassung von Nutzungsdaten: Systematische Aufzeichnung der Anzahl der Downloads und Streams, inklusive Zeitstempel und Dauer der Audio Nutzung. Analyse und Reporting: Auswertung der gesammelten Daten zur Erstellung von Leistungsberichten, die Einblicke in Nutzerverhalten und Pr&amp;auml;ferenzen geben. Nutzungsstatistiken: Bereitstellung von detaillierten Abrufstatistiken zur Optimierung der Inhalte und zur strategischen Planung k&amp;uuml;nftiger Publikationen. Diese Verfahren unterst&amp;uuml;tzen die zielgerichtete Weiterentwicklung und Anpassung von Audioinhalten, um die Bed&amp;uuml;rfnisse und Interessen der Zielgruppe effektiver zu bedienen; &lt;span class=&quot;&quot;&gt;&lt;strong&gt;Rechtsgrundlagen:&lt;/strong&gt; Berechtigte Interessen (Art. 6 Abs. 1 S. 1 lit. f) DSGVO). &lt;/span&gt;&lt;strong&gt;Sicherheitsma&amp;szlig;nahmen:&lt;/strong&gt; IP-Masking (Pseudonymisierung der IP-Adresse).&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;seal&quot;&gt;&lt;a title=&quot;Rechtstext von Dr. Schwenke - f&amp;uuml;r weitere Informationen bitte anklicken.&quot; href=&quot;https://datenschutz-generator.de/&quot; target=&quot;_blank&quot; rel=&quot;noopener noreferrer nofollow&quot;&gt;Erstellt mit kostenlosem Datenschutz-Generator.de von Dr. Thomas Schwenke&lt;/a&gt;&lt;/p&gt;'),
(3, 'Hilfe', '&lt;center&gt;Hilfe fÃ¼r die Registrierung&lt;/center&gt;', '&lt;p class=&quot;MsoNormal&quot;&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;Wie registriere ich mich bzw. sch&amp;uuml;tze meinen Namen mit einem Passwort? &lt;/span&gt;&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;Hier eine kurze Anleitung wie ihr eure Namen (Nick) in unserem Chat &quot;registrieren&quot; bzw. mit einem Passwort sch&amp;uuml;tzen k&amp;ouml;nnt. &lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;Wir nutzen das Chatsystem &quot;ET-CHAT&quot; und in diesem Chat ist keine Registration notwendig, ihr k&amp;ouml;nnt also zu jeder Zeit als Gast, mit euren eingegeben Namen, unserem Chat betreten. Wenn ihr aber nicht m&amp;ouml;chtet, das andere euren Namen nutzen dann k&amp;ouml;nnt ihr diese mit einem Passwort sichern und euer Name ist quasi &quot;registriert&quot;. &lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;Wie geht das mit dem Passwort sichern? &lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;&lt;strong&gt;Logt euch zun&amp;auml;chst einmal aus dem Chat wieder aus Ihr landet automatisch auf der Login Seite vom Chat.&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;So wird es gemacht:&lt;/span&gt;&lt;/p&gt;\r\n&lt;ol style=&quot;margin-top: 0cm;&quot; start=&quot;1&quot; type=&quot;1&quot;&gt;\r\n&lt;li class=&quot;MsoNormal&quot; style=&quot;color: #ffffff;&quot;&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;&lt;strong&gt;Klickt auf Registrieren / Passwort vergessen.&lt;/strong&gt;&lt;/span&gt;&lt;/li&gt;\r\n&lt;li class=&quot;MsoNormal&quot; style=&quot;color: #ffffff;&quot;&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;&lt;strong&gt;F&amp;uuml;llt das Formular aus mit E-Mail-Adresse diese ist f&amp;uuml;r den Notfall, wenn Ihr euer Passwort vergessen tut.&lt;br&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;2.1 Chat Name mindestens 4 Zeichen maximal 25&lt;br&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;2.2 Gibt ein sicheres Passwort ein!!&amp;nbsp;&lt;br&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;2.3 Wiederholt das Passwort&lt;br&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;2.4 Gibt eure E-Mail-Adresse an&lt;br&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;2.5 Klickt auf Registrieren&lt;/strong&gt;&lt;/span&gt;&lt;/li&gt;\r\n&lt;li class=&quot;MsoNormal&quot; style=&quot;color: #ffffff;&quot;&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;&lt;strong&gt;Geht in euren E-Mail-Postfach (evtl. Spam) und folgt dem Link innerhalb von 30 min.&lt;/strong&gt;&lt;/span&gt;&lt;/li&gt;\r\n&lt;li class=&quot;MsoNormal&quot; style=&quot;color: #ffffff;&quot;&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;&lt;strong&gt;Die E-Mail-Adresse ist wichtig! Zum Freischalten und falls ihr euer Passwort vergesst!&lt;/strong&gt;&lt;/span&gt;&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;&lt;br&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;Somit ist euer Name gesch&amp;uuml;tzt&lt;/span&gt;&lt;br&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;Wir w&amp;uuml;nschen euch viel Spa&amp;szlig; &amp;amp; sch&amp;ouml;ne Unterhaltung im Chat.&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;MsoNormal&quot;&gt;&amp;nbsp;&lt;/p&gt;'),
(4, 'Regeln', 'Regeln', 'Radio XXX CHAT REGELN!\r\n&lt;br&gt;&lt;br&gt;\r\nEs ist darauf zu achten das die User im Chat mit deren Nicknamen in der Userlist angesprochen werden und nicht mit realem Namen!!! AuÃŸer es steht ein User mit realem Namen in der Userlist !!!\r\n&lt;br&gt;&lt;br&gt;\r\nUnsere Chatregeln&lt;br&gt;\r\nWie auch im richtigen Leben gelten im Chat allgemeine Umgangsformen, die einen respektvollen und stÃ¶rungsfreien Umgang unter den Chattern regeln sollen. Anstand gehÃ¶rt hier ebenso dazu wie die Achtung anderer Chatter und deren Meinungen.\r\n&lt;br&gt;&lt;br&gt;\r\nIm Folgenden werden diese Regeln, auch Chatiquette genannt, erklÃ¤rt. Die Chat-Admins bitten um Beachtung und Einhaltung dieser Regeln. Zuwiderhandlungen werden je nach Art der Zuwiderhandlung mit Verwarnungen, mit dem Hinauswurf aus dem Chat, im Wiederholungsfall oder bei extremer Missachtung mit einem andauernden Ausschluss (Bann) vom Chat geahndet.\r\n&lt;br&gt;&lt;br&gt;\r\nAuflistung Jugendschutzgesetz, Kinder und Jugendliche verlassen den Chat (Webradio)\r\n&lt;br&gt;&lt;br&gt;\r\nbis zum 6.Lebensjahr ab 16:00 Uhr&lt;br&gt;\r\nbis zum 12 Lebensjahr ab 18:00 Uhr&lt;br&gt;\r\nbis zum 14.Lebensjahr ab 20:00 Uhr&lt;br&gt;\r\nbis zum 16.Lebensjahr ab 22:00 Uhr&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\nAb den 18.Lebensjahr ist 24 Stunden unbegrenzter Aufenthalt erlaubt. Wir bitte die Eltern, uns beim Einhalten der Chatzeiten ihrer Kinder zu unterstÃ¼tzen.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 1&lt;br&gt;\r\nDenke immer daran, dass am anderen Ende auch nur ein Mensch wie du und ich sitzt, der genau so behandelt werden mÃ¶chte, wie du es dir fÃ¼r dich wÃ¼nschst! Respekt und HÃ¶flichkeit sollten selbstverstÃ¤ndlich sein. KraftausdrÃ¼cke und der Gossen-Slang sind keine geeigneten Sprachen im Chat. Was du eventuell als lustig ansiehst, wird auf der anderen Seite nicht immer genauso aufgefasst.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 2&lt;br&gt;\r\nWenn du den Chat betrittst, haue nicht gleich in die Vollen, mische dich nicht direkt in ein laufendes GesprÃ¤ch ein. Schau erst zu, worum es geht, welche User anwesend sind und welche Stimmung herrscht. Du springst ja auch nicht frÃ¶hlich schreiend und tanzend in ein CafÃ© hinein und rufst &#039;Heja, hier bin ich! Unterhaltet mich!&#039;. Erst wenn du siehst, was im Raum los ist, wie die User gelaunt sind, kannst du entscheiden, ob dir das Geschehen entspricht oder ob du lieber weitergehst und die anderen RÃ¤ume besuchst.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 3&lt;br&gt;\r\nWer flirtet nicht gerne? Der Chat ist eine ideale Plattform dafÃ¼r, jedoch sollte man daran denken, dass dies kein Flirt-Chat, sondern ein Fantasy-Chat ist. Respektiere dies. Es reicht schon ein *** Bist du m oder w ? ***, um zu nerven. Meldet ein User aufdringliches rumgeflirte, wird dies von einem Admin oder Moderator geregelt werden.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 3.1&lt;br&gt;\r\nDas Leben ist nicht immer sonnig, dass weis jeder von uns. Dies ist aber kein Grund, die angestauten Frustrationen an anderen Usern auszulassen. Wenn es Dir schlecht geht, heiÃŸt das nicht, dass du den anderen Usern das Leben auch noch schwer machen musst.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 4&lt;br&gt;\r\nJeder war mal neu im Chat und musste sich erst orientieren, musste herausfinden, wie der Chat funktioniert. Deshalb sollte jeder den Neulingen gegenÃ¼ber helfend zur Seite stehen, auch um fÃ¼r *** Nachwuchs *** im Chat zu sorgen. Wer weis, vielleicht wird der Neuling irgendwann mal ein Stammchatter oder gar ein guter Freund! Hat man keine Lust zu helfen, sollte man lieber gar nichts sagen als den Neuling zu verunsichern oder gar zu verjagen.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 5&lt;br&gt;\r\nWir bietet es unseren Mitgliedern an, ein Profil anzulegen. Die Bilder und Texte, die dort hochgeladen werden, sind kein Eigentum vom Chatadmin. Als Profilersteller, haftet ein jeder User fÃ¼r sein Profil, sollte er geltendes Recht verletzen (Urheberrecht). Da es uns nicht mÃ¶glich ist, nachzuprÃ¼fen, ob eine Erlaubnis zur Nutzung (Bildmaterial, Text) vorliegt ist eine Ahndung schwer durchzufÃ¼hren. Urheber sind dazu angehalten, bei dem Verstoss des Urheberrechts, eine E-Mail an den Webmaster dieser Seite zu schicken, indem sie den Fall darlegen. Texte mit rassistischem, werblichen oder pornografischen Inhalten, werden von den Admin oder Moderatoren gelÃ¶scht, wenn sie gesichtet werden und der User verwarnt und/oder aus der Community ausgeschlossen.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 6&lt;br&gt;\r\nOhne Humor ist der Chat langweilig. Denke jedoch immer daran, dass nicht jeder User den gleichen Humor mit dir teilt. Was dir TrÃ¤nen vor Lachen in die Augen treibt, kann den anderen entsetzen. Dabei sollte man auch immer daran denken, dass man im Chat Gesten und Tonlagen, die einen Witz oft erst witzig machen, oft nur schlecht darstellen kann!\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 7&lt;br&gt;\r\nPersÃ¶nliche Daten, wie z. B. Telefonnummern oder gar vollstÃ¤ndige Adressen haben in Ã¶ffentlichen RÃ¤umen grundsÃ¤tzlich nichts verloren. DrÃ¤nge niemanden dazu, solche Daten von sich preiszugeben. Man sollte sich damit abfinden, wenn ein User keinen nÃ¤heren Kontakt haben mÃ¶chte und lieber die AnonymitÃ¤t im Chat geniesst.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 8&lt;br&gt;\r\nGroÃŸbuchstaben sind nur in AusnahmefÃ¤llen als Betonung zu verwenden. Im Allgemeinen gilt das GroÃŸschreiben als BrÃ¼llen/Schreien im Chat. Weder im Chat noch im normalen Leben wird es geduldet, wenn jemand durchweg schreit. Schreibst du stÃ¤ndig und durchweg in GroÃŸbuchstaben, solltest du dich nicht wundern, wenn die anderen von dir genervt sind und du eventuell von einem Admin oder Moderator ermahnt und/oder still gelegt wirst.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 9&lt;br&gt;\r\nDer Chat ist nicht der richtige Ort, um mit SchimpfwÃ¶rtern um sich zu werfen. Damit machst du dir keine Freunde und stÃ¶rst die anderen User, die in Ruhe chatten wollen.\r\n&lt;br&gt;&lt;br&gt;\r\nZudem denk immer daran: auch im Internet kÃ¶nnen Gewalt- und Drogenverherrlichung, pornographische Darstellungen und rassistische Ã„uÃŸerungen strafrechtlich geahndet werden!\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 10&lt;br&gt;\r\nTaucht im Chat ein StÃ¶renfried auf, ignoriere ihn! Diskussionen oder gar eine Antwort auf gleichem Niveau bringt nichts auÃŸer Ã„rger. Wird ein solcher User ignoriert, langweilt er sich und wird schnell von alleine verschwinden, wenn er merkt, dass er sein Ziel nicht erreichen kann.\r\n&lt;br&gt;&lt;br&gt;\r\nBei besonders schlimmen FÃ¤llen benachrichtige einen Moderator Ã¼ber den User und bitte ihn, das Geschehen zu beobachten und entsprechend zu handeln. Sollte kein Moderator oder Admin im Chat sein, kannst du auch einen Notruf Ã¼ber das Notrufsystem absetzen dadurch wird dann ein Moderator per Email informiert.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 11&lt;br&gt;\r\nDu solltest dir einen Nicknamen aussuchen, der niemanden beleidigt. Verboten sind Nicknamen, die (wenn auch nur zum Teil) aus zensierten WÃ¶rtern bestehen, rassistisch oder gewaltverherrlichend sind oder einen pornographischen Inhalt haben.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 12&lt;br&gt;\r\nUnser Chat ist eine Community, die Ã¼berwiegend aus Usern mittleren Alters besteht. Erotik-Chats gibt es zur GenÃ¼ge im Netz, bei uns jedoch sind GesprÃ¤che mit erotischem Inhalt nicht erwÃ¼nscht und werden entsprechend geahndet! Wenn es unbedingt sein muss, sind Plays und GesprÃ¤che solcher Art, in abgeschlossene RÃ¤ume oder Privatchats zu verlegen.\r\n&lt;br&gt;&lt;br&gt;\r\nEbensowenig werden Fragen oder Aufforderungen zu sexuellen Handlungen im Chat (CyberSex, CS) geduldet.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 13&lt;br&gt;\r\nAuch wenn es viele gerne so sehen: du bist nicht vollkommen anonym im Chat. Deine Rechner-Adresse (IP) wird bei jedem Login im Chat mitgeschnitten und im Rahmen des Datenschutzes gespeichert. Ãœber diese Adresse kann der Betreiber jederzeit deinen Provider in Erfahrung bringen, welcher wiederum deine Telefonnummer speichert. Solltest du also den Chatbetrieb extrem stÃ¶ren oder gar rechts- oder sittenwidrige Dinge im Chat begehen, ist es dem Betreiber jederzeit mÃ¶glich, deine IdentitÃ¤t in Erfahrung zu bringen und dich entsprechend zur Rechenschaft zu ziehen. Dies solltest du beachten, wenn du nicht zu denen gehÃ¶rst, die einfach nur friedlich miteinander chatten und playn wollen.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 14&lt;br&gt;\r\nDer Chat ist keine Plakatwand. Sicher hat niemand etwas dagegen, wenn du ab und zu die Adresse (URL) deiner Homepage postest. Missbrauchst du den Chat allerdings, um nur Werbung zu machen, wird dich frÃ¼her oder spÃ¤ter ein Moderator oder Admin aus dem Chat entfernen.\r\n&lt;br&gt;&lt;br&gt;\r\nNotorische Spammer oder User, die fÃ¼r kommerzielle Angebote werben (z. B. Seiten, die zu Dialern fÃ¼hren), werden auf Dauer gebannt!\r\n&lt;br&gt;&lt;br&gt;\r\nWirb niemals fÃ¼r eine andere Community oder einen anderen Chat. GefÃ¤llt dir der Chat nicht, brauchst du das nicht stÃ¤ndig Ã¤uÃŸern. Konsequent und ehrlich wÃ¤re es, in solch einem Fall den Chat zu verlassen und den Chat deines Vertrauens aufzusuchen.\r\n&lt;br&gt;&lt;br&gt;\r\nGrundregel 15&lt;br&gt;\r\nAdmins und Moderatoren sind auch nur Menschen. Ihr Amt ist ehrenamtlich, sie tun ihren Job, um Usern zu helfen und die Einhaltung der Regeln zu Ã¼berwachen. Sollte ein Admin oder Moderator mal nicht sofort auf deine Fragen reagieren, denke bitte daran, dass auch andere User Fragen haben und der Admin oder Moderator vielleicht gerade im Stress ist, um allen Usern gerecht zu werden.\r\n&lt;br&gt;&lt;br&gt;\r\nWenn Du diese Regeln befolgst,dann steht einem tollen Chat-Leben nichts mehr im Wege.\r\n&lt;br&gt;&lt;br&gt;');
INSERT INTO `###prefix###etchat_texte` (`id`, `ort`, `header_text`, `content`) VALUES
(5, 'G&auml;ste Begr&uuml;&szlig;en', '&lt;center&gt;Hallo Gast sei gegrÃ¼ÃŸt bei DMR- by Radio-Dino&lt;/center&gt;', '&lt;p&gt;Hallo, du bist neu hier als Gast.&lt;/p&gt;\r\n&lt;p&gt;bitte benehme dich und baggere keine anderen User Chatter an.&lt;/p&gt;\r\n&lt;p&gt;Sollte es dir gefallen, kannst du gerne deinen Chattername regestrieren.&lt;/p&gt;\r\n&lt;p&gt;Das machst du auf der Login Seite unter &lt;span style=&quot;color: #000000;&quot;&gt;&quot;&lt;span style=&quot;font-family: Arial; font-size: 14.6667px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: center; text-indent: 0px; text-transform: none; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: #fbeeb8; display: inline !important; float: none;&quot;&gt;Registrieren / Passwort vergessen&lt;/span&gt;&quot;&lt;/span&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;span style=&quot;color: #000000;&quot;&gt;Wenn du mit dem Handy online gekommen bist oder eine zu kleine aufl&amp;ouml;sung hast findest du den &lt;br&gt;Player und Userliste unter diesem Butoon&amp;nbsp; &lt;img src=&quot;img/Userliste.png&quot; alt=&quot;Userliste&quot; width=&quot;25&quot; height=&quot;25&quot;&gt;&lt;/span&gt;&lt;/p&gt;\r\n&lt;p&gt;Wir w&amp;uuml;nschen dir viel Spa&amp;szlig; ....&lt;/p&gt;'),
(6, 'div1', '1. Eigene Seite', '1. Text fÃ¼r eigne Seite auch HTML -Code erlaubt\r\n\r\n'),
(7, 'div2', '2. Eigene Seite', '2. Text fÃ¼r eigne Seite auch HTML -Code erlaubt\r\n'),
(8, 'div3', '3. Eigene Seite', '3. Text fÃ¼r eigne Seite auch HTML -Code erlaubt'),
(9, 'div4', '4. Eigene Seite 	', '4. Text fÃ¼r eigne Seite auch HTML -Code erlaubt');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_user`
--

CREATE TABLE `###prefix###etchat_user` (
  `etchat_user_id` int(8) NOT NULL,
  `etchat_username` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_userpw` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_userprivilegien` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gast',
  `etchat_usersex` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `etchat_reg_timestamp` timestamp NOT NULL DEFAULT '1979-12-31 23:00:00',
  `etchat_reg_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_avatar` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noavatar.jpg',
  `etchat_logintime` bigint(20) DEFAULT NULL,
  `etchat_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_reset_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_reset_token_expiry` datetime DEFAULT NULL,
  `etchat_geb_tag` tinyint(2) DEFAULT NULL,
  `etchat_geb_monat` tinyint(2) DEFAULT NULL,
  `etchat_geb_jahr` smallint(4) DEFAULT NULL,
  `etchat_ort` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_beschreibung` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `###prefix###etchat_user`
--

INSERT INTO `###prefix###etchat_user` (`etchat_user_id`, `etchat_username`, `etchat_userpw`, `etchat_userprivilegien`, `etchat_usersex`, `etchat_reg_timestamp`, `etchat_reg_ip`, `etchat_avatar`, `etchat_logintime`, `etchat_email`, `etchat_reset_token`, `etchat_reset_token_expiry`, `etchat_geb_tag`, `etchat_geb_monat`, `etchat_geb_jahr`, `etchat_ort`, `etchat_beschreibung`) VALUES
(1, '<i>System</i>', 'NULL', 'system', 'n', '1979-12-31 22:00:00', 'NULL', 'system.png', 1746638719, 'NULL', '', '2025-04-25 20:09:09', NULL, NULL, NULL, NULL, NULL),
(2, 'Admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'm', '2024-09-10 11:00:00', '', 'Admi-1752064291.jpg', 1753103823, 'p-berg007@gmx.de', '26c747810cec960f88cfe923041e2078c9e9f837296d6591799ea70b553c9c7c', '2025-06-29 17:07:54', 6, 5, 1968, 'Berlin', 'Hallo liebe HÃ¶rer/innen von Dance Music Radio, ihr wollt immer aktuelle News Ã¼ber unsere Sendungen und unser Radio erhalten?'),
(3, 'Admin-2', 'bd4a73c724d2a57140e356fdfa6be53c', 'admin', 'm', '1979-12-31 22:00:00', '', 'Admin-2.jpg', 1751567620, 'p-berg007@gmx.de', '', '2025-04-25 20:09:09', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `###prefix###etchat_useronline`
--

CREATE TABLE `###prefix###etchat_useronline` (
  `etchat_onlineid` bigint(20) UNSIGNED NOT NULL,
  `etchat_onlineuser_fid` int(8) NOT NULL,
  `etchat_onlinetimestamp` bigint(20) NOT NULL,
  `etchat_onlineip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_fid_room` int(11) NOT NULL DEFAULT 1,
  `etchat_user_online_room_goup` int(6) NOT NULL,
  `etchat_user_online_room_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_priv` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_sex` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etchat_user_online_user_status_img` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_user_online_user_status_text` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `etchat_avatar` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noavatar.jpg',
  `etchat_logintime` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `###prefix###etchat_blacklist`
--
ALTER TABLE `###prefix###etchat_blacklist`
  ADD PRIMARY KEY (`etchat_blacklist_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_config`
--
ALTER TABLE `###prefix###etchat_config`
  ADD UNIQUE KEY `etchat_config_id` (`etchat_config_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_kick_user`
--
ALTER TABLE `###prefix###etchat_kick_user`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_menu`
--
ALTER TABLE `###prefix###etchat_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_messages`
--
ALTER TABLE `###prefix###etchat_messages`
  ADD PRIMARY KEY (`etchat_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_radio_box`
--
ALTER TABLE `###prefix###etchat_radio_box`
  ADD PRIMARY KEY (`etchat_radio_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_rooms`
--
ALTER TABLE `###prefix###etchat_rooms`
  ADD PRIMARY KEY (`etchat_id_room`);

--
-- Indizes für die Tabelle `###prefix###etchat_smileys`
--
ALTER TABLE `###prefix###etchat_smileys`
  ADD PRIMARY KEY (`etchat_smileys_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_smileys_cat`
--
ALTER TABLE `###prefix###etchat_smileys_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_start_boxes`
--
ALTER TABLE `###prefix###etchat_start_boxes`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_texte`
--
ALTER TABLE `###prefix###etchat_texte`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `###prefix###etchat_user`
--
ALTER TABLE `###prefix###etchat_user`
  ADD PRIMARY KEY (`etchat_user_id`);

--
-- Indizes für die Tabelle `###prefix###etchat_useronline`
--
ALTER TABLE `###prefix###etchat_useronline`
  ADD PRIMARY KEY (`etchat_onlineid`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_blacklist`
--
ALTER TABLE `###prefix###etchat_blacklist`
  MODIFY `etchat_blacklist_id` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_kick_user`
--
ALTER TABLE `###prefix###etchat_kick_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_menu`
--
ALTER TABLE `###prefix###etchat_menu`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_messages`
--
ALTER TABLE `###prefix###etchat_messages`
  MODIFY `etchat_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_radio_box`
--
ALTER TABLE `###prefix###etchat_radio_box`
  MODIFY `etchat_radio_id` int(1) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_rooms`
--
ALTER TABLE `###prefix###etchat_rooms`
  MODIFY `etchat_id_room` int(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_smileys`
--
ALTER TABLE `###prefix###etchat_smileys`
  MODIFY `etchat_smileys_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_smileys_cat`
--
ALTER TABLE `###prefix###etchat_smileys_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_start_boxes`
--
ALTER TABLE `###prefix###etchat_start_boxes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_texte`
--
ALTER TABLE `###prefix###etchat_texte`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_user`
--
ALTER TABLE `###prefix###etchat_user`
  MODIFY `etchat_user_id` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `###prefix###etchat_useronline`
--
ALTER TABLE `###prefix###etchat_useronline`
  MODIFY `etchat_onlineid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
