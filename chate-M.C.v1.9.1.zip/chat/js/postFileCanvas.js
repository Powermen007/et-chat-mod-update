const postFile = {
  canvas: null,
  ctx: null,
  img: null,
  zoom: 1,
  offsetX: 0,
  offsetY: 0,
  dragging: false,
  startX: 0,
  startY: 0,

  init() {
    this.canvas = document.getElementById("get_image");
    this.ctx = this.canvas.getContext("2d");

    const fileInput = document.getElementById("post_file");
    fileInput.addEventListener("change", (e) => this.loadImage(e));

    this.canvas.addEventListener("mousedown", (e) => this.startDrag(e));
    this.canvas.addEventListener("mousemove", (e) => this.onDrag(e));
    this.canvas.addEventListener("mouseup", () => this.endDrag());
    this.canvas.addEventListener("mouseleave", () => this.endDrag());
    this.canvas.addEventListener("wheel", (e) => this.onZoom(e));
  },

  loadImage(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const image = new Image();
      image.onload = () => {
        this.img = image;
        this.zoom = 1;
        this.offsetX = (200 - image.width) / 2;
        this.offsetY = (200 - image.height) / 2;
        this.draw();
      };
      image.src = e.target.result;
    };
    reader.readAsDataURL(file);
  },

  draw() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, 200, 200);

    if (!this.img) return;

    ctx.drawImage(
      this.img,
      this.offsetX,
      this.offsetY,
      this.img.width * this.zoom,
      this.img.height * this.zoom
    );

    // Graues Overlay au�en
    ctx.save();
    ctx.fillStyle = "rgba(50, 50, 50, 0.7)";
    ctx.beginPath();
    ctx.rect(0, 0, 200, 200);
    ctx.rect(50, 50, 100, 100);
    ctx.fill("evenodd");
    ctx.restore();

    // Wei�er Rahmen
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;
    ctx.strokeRect(50, 50, 100, 100);
  },

  startDrag(e) {
    this.dragging = true;
    this.startX = e.offsetX;
    this.startY = e.offsetY;
  },

  onDrag(e) {
    if (!this.dragging || !this.img) return;

    const dx = e.offsetX - this.startX;
    const dy = e.offsetY - this.startY;
    this.startX = e.offsetX;
    this.startY = e.offsetY;

    this.offsetX += dx;
    this.offsetY += dy;
    this.draw();
  },

  endDrag() {
    this.dragging = false;
  },

  onZoom(e) {
    if (!this.img) return;

    e.preventDefault();
    const zoomAmount = 0.05;
    const oldZoom = this.zoom;
    const mouseX = e.offsetX;
    const mouseY = e.offsetY;

    this.zoom *= e.deltaY < 0 ? (1 + zoomAmount) : (1 - zoomAmount);
    this.zoom = Math.max(0.1, Math.min(this.zoom, 5));

    const scaleChange = this.zoom / oldZoom;
    this.offsetX = mouseX - (mouseX - this.offsetX) * scaleChange;
    this.offsetY = mouseY - (mouseY - this.offsetY) * scaleChange;

    this.draw();
  },

save(callback, mime = "image/png", ext = "png") {
  if (!this.img || typeof callback !== "function") return;

  const cropCanvas = document.createElement("canvas");
  cropCanvas.width = 100;
  cropCanvas.height = 100;
  const cropCtx = cropCanvas.getContext("2d");

  cropCtx.drawImage(
    this.canvas,
    50, 50, 100, 100,
    0, 0, 100, 100
  );

  cropCanvas.toBlob((blob) => {
    callback(blob);
  }, mime);
}

};

window.onload = () => postFile.init();