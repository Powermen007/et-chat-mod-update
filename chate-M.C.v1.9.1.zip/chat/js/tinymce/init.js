tinymce.init({
  selector: "#mytextarea",
  menubar: 'file edit insert view format table tools help',
  menu: {
  file: { title: 'File', items: 'print' },
  view: { title: 'View', items: 'code | preview | visualaid visualchars visualblocks' },
  insert: { title: 'Insert', items: 'Image link media codesample | charmap Emoticons hr' },
   tools: { title: 'Tools', items: 'wordcount' }
   },
  plugins:
    "anchor accordion advlist preview autosave autolink charmap codesample code directionality emoticons help image link lists media save searchreplace table visualblocks visualchars wordcount fullscreen",
  toolbar:
    "save | undo redo | print code preview searchreplace fullscreen | blocks fontfamily fontsize | bold italic underline forecolor backcolor | link image | alignleft aligncenter alignright alignjustify lineheight | bullist numlist indent outdent | removeformat | accordion anchor",
    images_upload_url: 'postAcceptor.php',
    images_upload_credentials: true,
    images_reuse_filename: true,
 	height: "400px",
   	language: 'de',
   	skin: 'oxide-dark',
   	license_key: 'gpl'
 });
;