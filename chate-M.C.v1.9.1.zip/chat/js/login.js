/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

window.onload = function() {

// only needed becouse of a bug in ie8 rc1, there is no BG-image without any div manipilation by js
Element.show('lay_pw');
Element.hide('lay_pw');
//-------------------------------------------

  $("login").onsubmit = function(){

	if($F('username').length < 3){
	alert('Sorry ... mindestens 3 Buchstaben beim Namen eingegeben');
	return false;
	}

	if($F('gender')=='n') {
	alert('???   Dein Geschlecht   ???');
	return false;
	}

	var verbotene_woerter = /@|adolf|arsch|fick|geil|göbbels|hitler|homo|hure|kack|moderator|nazi|scheiß|wixer|www|xxx/i;
	if( $("username").value.search(verbotene_woerter)!=-1) { alert('!!!   Unerlaubter Name   !!!'); return false; }

	if (!Element.visible('lay_pw')) $('pw').value='';
	$('submit_button').disabled = true;

    var myAjaxObj= new Ajax.Request(
                 "./?CheckUserName",
                 {
                  onSuccess: function(ajaxResult) {
                 	if (ajaxResult.responseText==1) location.href='./?Chat';
                 	else{
							$('submit_button').disabled = false;
                            if (ajaxResult.responseText=='pw' || ajaxResult.responseText=='pw+invisible') {
                                 	Element.show('lay_pw');
									if (ajaxResult.responseText=='pw+invisible') Element.show('lay_invisible');
                                 	Element.hide('lay_gender');
                                 	$("pw").focus();
                            } else {
                         		if (ajaxResult.responseText=='blacklist') location.href="./?AfterBlacklistInsertion";
                         		else if(!ajaxResult.responseText.empty()) alert(ajaxResult.responseText);
								else {
									$('username').value='';
									$('username').focus();
									}
                         		}
                         }
                 	},
                  postBody: $("login").serialize()
                 }
		);

	return false;
  }
}

