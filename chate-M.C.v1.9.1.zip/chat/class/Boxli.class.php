<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class ExternUserView4 extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

			$feld=$this->dbObj->sqlGet("SELECT id, ort, header_text, content FROM {$this->_prefix}etchat_start_boxes WHERE id = 1");
			$this->dbObj->close();

			if (is_array($feld)){

				foreach($feld as $datasets){

						echo "<h2 style=\"margin-top: 0.05px;margin-bottom: 0.05px;text-align: center;\">";
						echo htmlspecialchars_decode ("$datasets[2]");
						echo "</h2>";
						echo htmlspecialchars_decode ("$datasets[3]");

				}

			}
	}
}

new ExternUserView4();

?>


