<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class MessageInserter extends EtChatConfig
{

	private $dbObj;

	public $status;

	public function __construct ($dbObj, $raum_array){

		parent::__construct();

		$this->dbObj=$dbObj;

		if (isset($_POST['roomchange']) && $_POST['roomchange']=="true" && !empty($raum_array[0][3])){
			$room_message_insert = str_replace("\r\n","<br />",$raum_array[0][3]);
			$room_message_insert = str_replace("\n","<br />",$room_message_insert);

			new SysMessage($this->dbObj, "<br /><div style=\"margin: 4px;\">".$room_message_insert."<div>",(int)$_POST['room'],$_SESSION['etchat_'.$this->_prefix.'user_id']);
		}

		if (isset($_POST['sysmess'])){

			if ($this->spamTester()) {
				$this->status = "spam";
				return false;
			}

			if (!in_array($_POST['message'], $_SESSION['etchat_'.$this->_prefix.'chek_user_ajax_getted_data'])) {
				return false;
			}

			if ($_POST['roomchange']=="true"){
				$raum_name=$this->dbObj->sqlGet("SELECT etchat_roomname FROM {$this->_prefix}etchat_rooms where etchat_id_room =".(int)$_POST['room']);
				$_POST['message'] = $_POST['message']." ".$raum_name[0][0];
			}

			$_POST['message'] = htmlspecialchars($_POST['message'], ENT_QUOTES, "UTF-8");
			$_POST['message'] = "<b>".$_SESSION['etchat_'.$this->_prefix.'username']."</b> ".$_POST['message'];

			if ($_POST['roomchange']=="true" && $_SESSION['etchat_'.$this->_prefix.'userstatus']=="status_invisible")
				$_POST['privat']=$_SESSION['etchat_'.$this->_prefix.'user_id'];
			else{
				if($_POST['privat']>0) $_POST['privat']=$_SESSION['etchat_'.$this->_prefix.'user_id'];
			}

			new SysMessage($this->dbObj, $_POST['message'],(int)$_POST['room'],(int)$_POST['privat']);
		}
		else{

			if ($this->spamTester()) {
				$this->status = "spam";
				return false;
			}

			$this->messageTransformer();

			$_POST['color'] = substr($_POST['color'], 0, 7);
			$_POST['bold'] = substr($_POST['bold'], 0, 6);
			$_POST['italic'] = substr($_POST['italic'], 0, 6);

			$style = "color:".htmlentities($_POST['color'], ENT_QUOTES, "UTF-8").";font-weight:".htmlentities($_POST['bold'], ENT_QUOTES, "UTF-8").";font-style:".htmlentities($_POST['italic'], ENT_QUOTES, "UTF-8").";";

			$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages ( etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat, etchat_user_ip)
				VALUES ( '".$_SESSION['etchat_'.$this->_prefix.'user_id']."', '".$_POST['message']."', '".$style."', ".date('U').", ".(int)$_POST['room'].", ".(int)$_POST['privat'].", '".$_SERVER['REMOTE_ADDR']."')");


			// BOT -------------------------------------------

			if (substr($_POST['message'], 0, 5)==".time"){
				$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages ( etchat_user_fid , etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
					VALUES ( 1, '".date('d.m.Y - H:i')."', 'color:#".$_SESSION['etchat_'.$this->_prefix.'syscolor'].";font-weight:normal;font-style:normal;', ".date('U').", ".(int)$_POST['room'].", 0)", false);
			}
			if (substr($_POST['message'], 0, 8)==".version"){
				$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages ( etchat_user_fid , etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
					VALUES ( 1, 'ET-Chat v3.0.7 r3 / M.C.v.1.9.1.', 'color:#".$_SESSION['etchat_'.$this->_prefix.'syscolor'].";font-weight:normal;font-style:normal;', ".date('U').", ".(int)$_POST['room'].", 0)", false);
			}

			   if (substr($_POST['message'], 0,11)==".chatregeln" && $_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin" || substr($_POST['message'], 0,11)==".chatregeln" && $_SESSION['etchat_'.$this->_prefix.'user_priv']=="mod" )
			{
                $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages ( etchat_user_fid , etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                    VALUES ( 1, '<center> Regeln<br><iframe src=\"?Text&id=4\" width=\"70%\"</iframe></center>', 'color:#".$_SESSION['etchat_'.$this->_prefix.'syscolor'].";font-weight:normal;font-style:normal;', ".date('U').", ".(int)$_POST['room'].", 0)", false);

			}
			   if (substr($_POST['message'], 0,4)==".reg" && $_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin" || substr($_POST['message'], 0,4)==".reg" && $_SESSION['etchat_'.$this->_prefix.'user_priv']=="mod" )
			{
                $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages ( etchat_user_fid , etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                    VALUES ( 1, '<center> Registrieren (Name durch Passwort sch&uuml;tzen)<br><iframe src=\"?Text&id=3\" width=\"70%\"</iframe></center>', 'color:#".$_SESSION['etchat_'.$this->_prefix.'syscolor'].";font-weight:normal;font-style:normal;', ".date('U').", ".(int)$_POST['room'].", 0)", false);

			}

			//--------------------------------
		}
	}

	private function messageTransformer(){
		$_POST['message'] =	substr($_POST['message'], 0, 1000);
		if (strlen($_POST['message'])>999) $_POST['message'] .="...";

		$woerter_array=explode(" ",$_POST['message']);
		foreach($woerter_array as $wort){
			if (strlen($wort)>50 && substr($wort, 0, 7)!="http://" && substr($wort, 0, 8)!="https://" && substr($wort, 0, 6)!="ftp://" && stripos($wort, ']http://')===false && stripos($wort, ']https://')===false){
				$new_wort = wordwrap( $wort, 50, " ", 1);
				$_POST['message'] = str_replace($wort, $new_wort, $_POST['message']);
			}
		}
		$_POST['message'] = htmlspecialchars(str_replace("\\","\\\\",$_POST['message']), ENT_QUOTES, "UTF-8");
	}

	private function spamTester(){

		$_SESSION['etchat_'.$this->_prefix.'spam'][]=date('U');

		if (count($_SESSION['etchat_'.$this->_prefix.'spam'])>200) {
			unset($_SESSION['etchat_'.$this->_prefix.'spam']);
			$_SESSION['etchat_'.$this->_prefix.'spam']=array();
		}

		if (count($_SESSION['etchat_'.$this->_prefix.'spam'])>3 && $_SESSION['etchat_'.$this->_prefix.'user_priv']!="admin" && $_SESSION['etchat_'.$this->_prefix.'user_priv']!="mod"){

			$spam_interval=($_SESSION['etchat_'.$this->_prefix.'spam'][(count($_SESSION['etchat_'.$this->_prefix.'spam'])-1)] - $_SESSION['etchat_'.$this->_prefix.'spam'][(count($_SESSION['etchat_'.$this->_prefix.'spam'])-4)]);

			if ($spam_interval < 6 ){
				$langObj = new LangXml();
				$lang=$langObj->getLang()->reloader_php[0];
				new SysMessage($this->dbObj, $lang->spam[0]->tagData,(int)$_POST['room'],(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);

				$_SESSION['etchat_'.$this->_prefix.'spam_warn']++;

				if ($_SESSION['etchat_'.$this->_prefix.'spam_warn']>2){
					$blObj = new Blacklist($this->dbObj);
					$blObj->insertUser($_SESSION['etchat_'.$this->_prefix.'user_id'],300);
					$blObj->userInBlacklist();
					$blObj->allowedToAndSetCookie();
					$blObj->killUserSession();
					return true;
				}
				else return false;
			}
		}
	}
}
