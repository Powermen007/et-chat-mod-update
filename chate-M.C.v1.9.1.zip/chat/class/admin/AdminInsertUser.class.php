<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminInsertUser extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();

        header(
            "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0"
        );
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_user[0];

        if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] == "admin") {
            if (empty($_POST["user"])) {
            	echo "<a href=\"./?AdminIndex\" style=\"cursor:pointer;\">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml;</a><hr>";
                echo "<font color='FFFFFF'>Bitte Username angeben.<br><br><a href=\"./?AdminCreateNewUser\">Zur&uuml;ck</a>";
                return false;
            }

            // Benutzername s�ubern
            $user = $_POST["user"] = htmlentities($_POST["user"], ENT_QUOTES, "UTF-8");
            $priv = $_POST["priv"] = htmlentities($_POST["priv"], ENT_QUOTES, "UTF-8");
            $mail = $_POST["mail"] = htmlentities($_POST["mail"], ENT_QUOTES, "UTF-8");

            if (!empty($_POST["pw"])) {
                $_POST["pw"] = "'" . md5($_POST["pw"]) . "'";
            } else {
                $_POST["pw"] = "NULL";
            }

			$reg_timestamp = date("Y-m-d H:i:s");

            // Nur Benutzer mit bestimmten Privilegien beachten (nicht 'gast')
            $sql = "SELECT etchat_user_id FROM {$this->_prefix}etchat_user WHERE etchat_username = '" . $user . "' AND etchat_userprivilegien IN ('admin', 'mod', 'user')";

            $res = $this->dbObj->sqlGet($sql);

            if (is_array($res)) {
                // Benutzer mit diesen Rechten existiert schon � nichts tun
                echo "<a href=\"./?AdminIndex\" style=\"cursor:pointer;\">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml;</a><hr>";
                echo "<font color='FFFFFF'>Benutzer mit diesem Namen existiert bereits.<br><br><a href=\"./?AdminCreateNewUser\">zur&uuml;ck</a>";
                return false;
            } else {
                // Benutzer darf neu angelegt werden
                $sqlInsert = "INSERT INTO {$this->_prefix}etchat_user (etchat_username, etchat_userpw, etchat_userprivilegien, etchat_reg_timestamp, etchat_email) VALUES ('" . $user . "', " . $_POST["pw"] . ", '" . $priv . "', '". $reg_timestamp . "', '" . $mail . "')";
                $this->dbObj->sqlSet($sqlInsert);
            }
            $this->dbObj->close();
            header("Location: ./?AdminIndex");
        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }
}

