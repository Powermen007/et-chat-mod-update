<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUserIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_user[0];

		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin"){
		
			if (!isset($_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"])) {
    				$_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] = rand(1, 999999999);
			}

			$feld=$this->dbObj->sqlGet("SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien, etchat_reg_timestamp, etchat_reg_ip, etchat_logintime, etchat_avatar, etchat_email FROM {$this->_prefix}etchat_user WHERE etchat_userprivilegien='admin' OR etchat_userprivilegien='mod'");
			$this->dbObj->close();

			if (is_array($feld)){
				$print_user_list="<table><tr><td>".$lang->name[0]->tagData."</td><td>".$lang->status[0]->tagData."</td><td>&nbsp;</td><td>".$lang->reg_date[0]->tagData."</td><td>&nbsp;</td><td>".$lang->reg_ip[0]->tagData."</td><td>&nbsp;</td><td>".$lang->login[0]->tagData."</td><td>&nbsp;</td><td>E-Mail</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
				foreach($feld as $datasets)
					$print_user_list.="<tr><td>".$datasets[1]."</td><td>(<i>".$datasets[3]."</i>)</td><td>&nbsp;&nbsp;&nbsp;</td><td>".$datasets[4]."</td><td>&nbsp;&nbsp;&nbsp;</td><td>".$datasets[5]."</td><td>&nbsp;&nbsp;&nbsp;</td><td>".date("d.m.Y-H:i",$datasets[6])."</td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"mailto:".$datasets[8]."\">".$datasets[8]."</a></td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"./?AdminEditUser&id=".$datasets[0]."\">".$lang->edit[0]->tagData."</a> | <a href=\"./?AdminDeleteAvatar&delavatar&cs4rue=".$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit']."&id=".$datasets[0]."\" onclick=\"return confirm('Bist du sicher, dass du diesen Avatar wirklich l&ouml;schen m&ouml;chtest?')\">L&ouml;sche Avatar</a>&nbsp; &nbsp; <img src=\"avatar/$datasets[7]\" width=\"16\" height=\"16\"></td></tr>";
				$print_user_list.="</table>";
			} else $print_user_list=$lang->noadmins[0]->tagData;
			$this->initTemplate($lang, $print_user_list);

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}

	private function initTemplate($lang, $print_user_list){
		include_once("styles/admin_tpl/indexUser.tpl.html");
	}
}





