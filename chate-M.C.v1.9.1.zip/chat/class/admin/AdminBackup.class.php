<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminBackup extends DbConectionMaker
{
    protected $db;
    protected $prefix;
    protected $dbname;

    public function __construct()
    {
        parent::__construct();

        $desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

        $configFile = dirname(dirname(__DIR__)) . '/config.php';
        if (!file_exists($configFile)) {
            die("FEHLER: config.php nicht gefunden!");
        }
        include $configFile;

        $this->prefix = $prefix;
        $this->dbname = $database;

        try {
            $this->db = new PDO(
                "mysql:host={$sqlhost};dbname={$database};charset=utf8mb4",
                $sqluser,
                $sqlpass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch (PDOException $e) {
            die("FEHLER: Datenbankverbindung: " . $e->getMessage());
        }

        session_start();

        if ($_SESSION['etchat_' . $this->prefix . 'user_priv'] !== 'admin') {
            die("Zugriff verweigert!");
        }

        if (isset($_GET['action'])) {
            switch ($_GET['action']) {
                case 'creating':
		            $this->showLoadingScreen(); // <-- Das ist Punkt 2!
        		    break;
                case 'create':
                    $this->createBackup();
                    break;
                case 'delete':
                    if (isset($_GET['file'])) {
                        $this->deleteBackupFile($_GET['file']);
                    }
                    break;
                case 'restore':
                    if (isset($_GET['file'])) {
                        $this->restoreBackup($_GET['file']);
                    }
                    break;
                case 'upload':
                    $this->handleUpload();
                    break;
            }
            exit;
        }

        $this->showBackupInterface($desei);
    }

    private function createBackup()
    {
        $backupFolder = dirname(dirname(__DIR__)) . '/backup';
        if (!is_dir($backupFolder)) {
            mkdir($backupFolder, 0777, true);
        }

        $date = date('Y-m-d_H-i-s');
        $backupFiles = [];

        try {
            $dbBackupFile = $backupFolder . '/db_' . $this->dbname . '_' . $date . '.sql';
            $this->backupDatabaseToFile($dbBackupFile);
            $backupFiles[] = $dbBackupFile;

            $zipFile = $backupFolder . '/files_' . $date . '.zip';
            $this->backupFilesToZip($zipFile);
            $backupFiles[] = $zipFile;

            $this->showResult("Backup erfolgreich erstellt", $backupFiles);

        } catch (Exception $e) {
            $this->showResult("Fehler: " . $e->getMessage());
        }
    }

    private function backupDatabaseToFile($filename)
    {
        $output = "-- ET-Chat_T-FISH-MOD Backup\n";
        $output .= "-- Erstellt am: " . date('Y-m-d H:i:s') . "\n";
        $output .= "-- Datenbank: " . $this->dbname . "\n\n";

        $tables = $this->db->query("SHOW TABLES LIKE '{$this->prefix}%'")->fetchAll(PDO::FETCH_COLUMN);

        foreach ($tables as $table) {
            $output .= "DROP TABLE IF EXISTS `$table`;\n";
            $create = $this->db->query("SHOW CREATE TABLE `$table`")->fetch();
            $output .= $create['Create Table'] . ";\n\n";

            $rows = $this->db->query("SELECT * FROM `$table`")->fetchAll();
            foreach ($rows as $row) {
                $columns = implode('`, `', array_keys($row));
                $values = array_map(function ($value) {
				    if (is_null($value)) {
        				return "NULL";
				    }
				    if ($value === '') {
        				return "NULL"; // Leere Strings ? auch NULL (z.�B. bei INT/DATETIME)
				    }
				    if (is_numeric($value)) {
		        		return $value; // keine Quotes
				    }
				    return "'" . str_replace("'", "''", $value) . "'"; // sauber escapen
				}, array_values($row));

                $output .= "INSERT INTO `$table` (`$columns`) VALUES (" . implode(', ', $values) . ");\n";
            }
            $output .= "\n";
        }

        file_put_contents($filename, $output);
    }

private function backupFilesToZip($zipFile)
{
    $zip = new ZipArchive();
    $zip->open($zipFile, ZipArchive::CREATE);

    $basePath = dirname(dirname(__DIR__));

    $desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

    // Sammle styles-Pfade aus $desei (falls vorhanden)
    $stylesFolders = [];
    if (is_array($desei)) {
        foreach ($desei as $data) {
            $stylesFolders[] = "styles/" . $data[1];
        }
    }

    // Feste Ordner + styles
    $folders = array_merge(['userpic', 'avatar', 'smilies', 'img'], $stylesFolders);

    foreach ($folders as $folder) {
        $folderPath = $basePath . '/' . $folder;
        if (is_dir($folderPath)) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($folderPath, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $file) {
                if ($file->isFile() && $file->getFilename() !== 'index.html') {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($basePath) + 1);
                    $zip->addFile($filePath, $relativePath);
                }
            }
        }
    }

    // Einzeldateien wie config.php
    $files = ['config.php'];
    foreach ($files as $file) {
        $filePath = $basePath . '/' . $file;
        if (file_exists($filePath)) {
            $zip->addFile($filePath, $file);
        }
    }

    $zip->close();
}


    private function deleteBackupFile($filename)
    {
        $backupFolder = dirname(dirname(__DIR__)) . '/backup';
        $filePath = $backupFolder . '/' . basename($filename);

        if (file_exists($filePath)) {
            unlink($filePath);
            header("Location: ?AdminBackup");
            exit;
        } else {
            $this->showResult("Datei nicht gefunden");
        }
    }

    private function restoreBackup($filename)
    {
        $backupFolder = dirname(dirname(__DIR__)) . '/backup';
        $filePath = $backupFolder . '/' . basename($filename);

        if (!file_exists($filePath)) {
            $this->showResult("Backup-Datei nicht gefunden");
            return;
        }

        $extension = pathinfo($filePath, PATHINFO_EXTENSION);

        if ($extension === 'sql') {
            $this->restoreDatabase($filePath);
            $this->showResult("Datenbank wiederhergestellt");
        } elseif ($extension === 'zip') {
            $this->restoreFiles($filePath);
            $this->showResult("Dateien wiederhergestellt");
        } else {
            $this->showResult("Ungültiger Dateityp");
        }
    }

    private function restoreDatabase($sqlFile)
    {
        $this->db->exec("SET FOREIGN_KEY_CHECKS = 0");

        $sql = file_get_contents($sqlFile);
        if ($sql === false) {
            $this->showResult("Fehler beim Lesen der Backup-Datei: $sqlFile");
            return;
        }

        $allowedTables = [
            $this->prefix . 'etchat_smileys',
            $this->prefix . 'etchat_smileys_cat',
            $this->prefix . 'etchat_user'
        ];

        $statements = array_filter(array_map('trim', explode(';', $sql)), function ($statement) {
            return !empty($statement) && !preg_match('/^\s*--/', $statement);
        });

        foreach ($statements as $statement) {
            $isAllowed = false;
            foreach ($allowedTables as $table) {
                if (preg_match("/(DROP TABLE IF EXISTS|CREATE TABLE|INSERT INTO)\s+`?$table`?/i", $statement)) {
                    $isAllowed = true;
                    break;
                }
            }

            if ($isAllowed) {
                try {
                    $this->db->exec($statement);
                } catch (PDOException $e) {
                    $this->showResult("Fehler beim Ausführen des Statements für $table: " . $e->getMessage());
                    $this->db->exec("SET FOREIGN_KEY_CHECKS = 1");
                    return;
                }
            }
        }

        $this->db->exec("SET FOREIGN_KEY_CHECKS = 1");
    }

    private function restoreFiles($zipFile)
    {
        $zip = new ZipArchive();
        $zip->open($zipFile);

        $basePath = dirname(dirname(__DIR__));

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            $targetPath = $basePath . '/' . $filename;

            $dir = dirname($targetPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }

            $fileContent = $zip->getFromIndex($i);
            if ($fileContent !== false) {
                file_put_contents($targetPath, $fileContent);
            }
        }

        $zip->close();
    }

    private function handleUpload()
    {
        if (!isset($_FILES['backup_file'])) {
            $this->showResult("Keine Datei hochgeladen");
            return;
        }

        $uploadedFile = $_FILES['backup_file'];
        $backupFolder = dirname(dirname(__DIR__)) . '/backup';

        $extension = pathinfo($uploadedFile['name'], PATHINFO_EXTENSION);
        if (!in_array(strtolower($extension), ['sql', 'zip'])) {
            $this->showResult("Nur .sql und .zip Dateien erlaubt");
            return;
        }

        $targetPath = $backupFolder . '/' . basename($uploadedFile['name']);

        if (move_uploaded_file($uploadedFile['tmp_name'], $targetPath)) {
            header("Location: ?AdminBackup");
            exit;
        } else {
            $this->showResult("Fehler beim Hochladen");
        }
    }

    private function showBackupInterface($desei)
    {
        $backupFolder = dirname(dirname(__DIR__)) . '/backup';
        $backupFiles = [];

        if (is_dir($backupFolder)) {
            $files = scandir($backupFolder, SCANDIR_SORT_DESCENDING);
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..') {
                    $filePath = $backupFolder . '/' . $file;
                    $backupFiles[] = [
                        'name' => $file,
                        'size' => filesize($filePath),
                        'date' => date('d.m.Y H:i', filemtime($filePath)),
                        'type' => pathinfo($filePath, PATHINFO_EXTENSION)
                    ];
                }
            }
        }
        ?>

        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Backup</title>

         <?php
 			if (is_array($desei)){
     			   foreach($desei as $data){
        				echo"<link href=\"styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        		}
        	}
			  $this->dbObj->close();
		?>

            <style>
			.container { max-width: 1200px; margin: 0 auto; background: #1f2430; padding: 20px; box-shadow: 0 0 15px rgba(0, 0, 0, 0.5); border-radius: 5px; }
			.button.green { background: #3a4050; }
			.button.green:hover { background: #149d00; }
			.button.red { background: #C62828; }
			.button.red:hover { background: #D32F2F; }
			.button.gray { background: #424242; cursor: not-allowed; }
			.backup-table { width: 100%; border-collapse: collapse; margin: 15px 0; }
			.backup-table th { background: #3a4050; color: #ffffff; padding: 10px; text-align: left; border-bottom: 2px solid #4a5060; }
			.backup-table td { padding: 10px; border-bottom: 1px solid #555; vertical-align: middle; }
			.backup-table tr:hover { background: #2a2f3a; }
			.backup-actions { white-space: nowrap; }
			.section { background: #2a2f3a; padding: 15px; margin-bottom: 20px; border-radius: 5px; border: 1px solid #4a5060; }
			.warning { background: #5D4037; color: #FFCCBC; padding: 15px; border-radius: 5px; margin-bottom: 20px; border: 1px solid #8D6E63; }
			.file-size { color: #BDC3C7; font-size: 13px; }
			.file-date { color: #BDC3C7; font-size: 13px; }
			.file-type { display: inline-block; padding: 2px 5px; background: #3a4050; border-radius: 3px; font-size: 12px; color: #ffffff; }
			input[type="file"] { padding: 8px; margin: 5px 0; background: #2a2f3a; border: 1px solid #444; border-radius: 4px; color: #ffffff; }
            </style>
        </head>
        <body id="adminbereich_body">
            <a href='./?AdminIndex'" style="cursor: pointer;">&lt;&lt;&lt; zurück zum Adminmenü</a>
            <hr size="1">

            <div class="container">
                <b>Chat Backup System</b><br><br>

                <div class="warning">
                    <strong>Achtung:</strong> Wiederherstellung überschreibt Daten!
                </div>

                <div class="section">
                    <b>Neues Backup erstellen</b>
                    <p>Erstellt ein komplettes Backup der Datenbank und aller wichtigen Dateien.</p>
                    <a href="?AdminBackup&action=creating" class="button green">Backup erstellen</a>
                </div>

                <div class="section">
                    <b>Backup hochladen</b>
                    <form action="?AdminBackup&action=upload" method="post" enctype="multipart/form-data">
                        <input type="file" name="backup_file" accept=".sql,.zip" required>
                        <button type="submit" class="button green">Backup hochladen</button>
                    </form>
                    <p style="font-size:13px; color:#BDBDBD;">Nur .sql (Datenbank) und .zip (Dateien) erlaubt</p>
                </div>

                <div class="section">
                    <b>Vorhandene Backups</b>
                    <?php if (empty($backupFiles)): ?>
                        <p>Keine Backups vorhanden</p>
                    <?php else: ?>
                        <table class="backup-table">
                            <thead>
                                <tr>
                                    <th>Dateiname</th>
                                    <th>Typ</th>
                                    <th>Größe</th>
                                    <th>Datum</th>
                                    <th>Aktionen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($backupFiles as $file): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($file['name']) ?></td>
                                        <td><span class="file-type"><?= strtoupper($file['type']) ?></span></td>
                                        <td class="file-size"><?= round($file['size']/1024) ?> KB</td>
                                        <td class="file-date"><?= $file['date'] ?></td>
                                        <td class="backup-actions">
                                            <?php if ($file['type'] === 'sql' || $file['type'] === 'zip'): ?>
                                                <a href="?AdminBackup&action=restore&file=<?= urlencode($file['name']) ?>" class="button green">Wiederherstellen</a>
                                            <?php else: ?>
                                                <span class="button gray">Nicht unterstützt</span>
                                            <?php endif; ?>
                                            <a href="?AdminBackup&action=delete&file=<?= urlencode($file['name']) ?>" class="button red">Löschen</a>
                                            <a href="backup/<?= htmlspecialchars($file['name']) ?>" download class="button">Download</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </body>
        </html>
        <?php
    }


	private function showLoadingScreen()
	{
    	?>
	    <!DOCTYPE html>
	    <html>
	    <head>
    	    <meta charset="UTF-8">
        	<title>Backup wird erstellt�</title>
	        <style>
    	        body {
        	        background: #1f2430;
            	    color: #ffffff;
                	font-family: Arial, sans-serif;
	                text-align: center;
    	            padding-top: 100px;
        	    }

            	.spinner {
                	margin: 40px auto;
	                width: 60px;
    	            height: 60px;
        	        border: 8px solid #3a4050;
            	    border-top: 8px solid #00e676;
                	border-radius: 50%;
	                animation: spin 1s linear infinite;
    	        }

        	    @keyframes spin {
            	    0% { transform: rotate(0deg); }
                	100% { transform: rotate(360deg); }
	            }

    	        .message {
        	        font-size: 18px;
            	    color: #ccc;
	            }
    	    </style>
	    </head>
    	<body>
        	<div class="spinner"></div>
	        <div class="message">Backup wird erstellt... Bitte einen Moment Geduld.</div>

    	    <form id="backupForm" method="get" action="">
        	    <input type="hidden" name="AdminBackup" value="">
            	<input type="hidden" name="action" value="create">
	        </form>

    	    <script>
        	    setTimeout(function() {
            	    document.getElementById('backupForm').submit();
	            }, 1500); // 1,5 Sekunden warten, um Spinner sichtbar zu machen
    	    </script>
	    </body>
    	</html>
	    <?php
    	exit;
	}

    private function showResult($message, $files = [])
    {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Backup Ergebnis</title>

         <?php

                 $desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

 			if (is_array($desei)){
     			   foreach($desei as $data){
        				echo"<link href=\"styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        		}
        	}
			  $this->dbObj->close();
		?>

            <style>
                .result { max-width: 800px; margin: 20px auto; padding: 20px; background: #1f2430; border-radius: 5px; box-shadow: 0 0 15px rgba(0,0,0,0.5); border: 1px solid #4a5060; }
                .file-list { margin: 15px 0; padding: 10px; background: #2a2f3a; border-radius: 4px; border: 1px solid #4a5060; }
            </style>
        </head>
        <body id="adminbereich_body">
            <div class="result">
                <h2><?= htmlspecialchars($message) ?></h2>
                <?php if (!empty($files)): ?>
                    <div class="file-list">
                        <p>Erstellte Dateien:</p>
                        <ul>
                            <?php foreach ($files as $file): ?>
                                <li><?= htmlspecialchars(basename($file)) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <a href="?AdminBackup" class="button">Zurück zum Backup-Menü</a> | <a href="?AdminIndex" class="button">Zurück zum Adminmenü</a>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}