<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateRadioBox extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_rooms[0];

		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin" && !empty($_POST['id'])){

		   $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_radio_box SET etchat_radio_horst = '".$_POST['1horst']."',
				 etchat_radio_port = '".$_POST['1port']."',
				 etchat_radio_typ = '".$_POST['1adminpass']."',
				 etchat_radio_stream = '".$_POST['1stream']."',
				 etchat_radio_name = '".$_POST['1streamname']."',
				 etchat_radio_color  = '".$_POST['1color']."',
				 etchat_radio_bit = '".$_POST['1bits']."',
				 etchat_radio_box  = '".$_POST['radiobox']."',
				 etchat_radio_player  = '".$_POST['player']."'
				  WHERE etchat_radio_id = ".(int)$_POST['id']);

			$this->dbObj->close();

			header("Location: ./?AdminRadioBoxIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
