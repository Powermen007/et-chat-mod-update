<?php

class AdminGallery extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

		$desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang();

        if ($_SESSION['etchat_' . $this->_prefix . 'user_priv'] !== 'admin') {
            echo $lang->error[0]->tagData;
            return;
        }

        // CSRF-Token setzen (wenn nicht vorhanden)
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        $uploadDir = './userpic/';
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'JPG', 'JPEG', 'PNG', 'GIF'];

        // Bild löschen
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
            if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
                http_response_code(403);
                die('Ung&uuml;ltiger CSRF-Token.');
            }

            $imageToDelete = trim($_POST['delete']);
            $imagePath = realpath($uploadDir . basename($imageToDelete));
            $metaPath = $imagePath . '.txt';

            if ($imagePath && strpos($imagePath, realpath($uploadDir)) === 0 && file_exists($imagePath)) {
                if (!unlink($imagePath)) {
                    http_response_code(500);
                    die('Fehler beim L&ouml;schen der Datei.');
                }
            if (file_exists($metaPath) && is_file($metaPath)) {
				unlink($metaPath);
				}


                header("Location: ./?AdminGallery");
                exit;
            }
        }

        $images = array_values(array_filter(
            scandir($uploadDir),
            fn($image) => in_array(strtolower(pathinfo($image, PATHINFO_EXTENSION)), $allowedExtensions) && is_file($uploadDir . $image)
        ));

        $this->renderGallery($images, $uploadDir, $desei);
    }

    private function renderGallery($images, $uploadDir, $desei)
    {
        $csrfToken = $_SESSION['csrf_token'];
        ?>

        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Galerie</title>

            <?php
 			if (is_array($desei)){
     			   foreach($desei as $data){
        				echo"<link href=\"styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        		}
        	}
			  $this->dbObj->close();
			?>

            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="robots" content="noindex, nofollow">
            <style>
                body { background-color: black; color: white; font-family: sans-serif; }
                .gallery { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
.image-container {
  text-align: center;
  width: calc(20% - 10px);
  display: flex;
  flex-direction: column;
  color: #fff;
  background-color: #8080809e;
}

.meta {
  padding: 5px 0;
}

.image-wrapper {
  flex-grow: 1;                 /* nimmt den verfügbaren Platz ein */
  display: flex;
  align-items: center;          /* vertikal zentrieren */
  justify-content: center;      /* horizontal zentrieren */
  width: 100%;
}

img {
  max-width: 95%;
  max-height: 150px;
  display: block;
}

.button-group {
    display: flex;
    justify-content: center;
    gap: 6px; /* Abstand zwischen den Buttons */
    margin-top: 5px;
}

                .button {
                    margin-top: 5px;
                    padding: 4px 8px;
                    background: #444;
                    color: white;
                    border: none;
                    cursor: pointer;
                    border-radius: 4px;
                }
                .button:hover { background: #666; }
                .danger { color: red; }
            </style>
            <script>
                function sendToChat(imageUrl) {
                    const imgCode = "[img]" + imageUrl + "[/img]";
                    const chatInput = window.parent.document.getElementById("message");
                    const sendButton = window.parent.document.getElementById("link_sagen");
                    if (chatInput && sendButton) {
                        chatInput.value += imgCode;
                        sendButton.click();
                        window.close();
                    } else {
                        alert("Fehler: Chat-Eingabe oder Senden-Button nicht gefunden.");
                    }
                }

                function deleteImage(imageUrl) {
                    if (!confirm("Bist du sicher, dass du dieses Bild lÃ¶schen mÃ¶chtest?")) return;

                    const formData = new URLSearchParams();
                    formData.append("delete", imageUrl);
                    formData.append("csrf_token", "<?= $csrfToken ?>");

                    fetch("", {
                        method: "POST",
                        body: formData,
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded"
                        }
                    }).then(response => {
                        if (response.ok) {
                            location.reload();
                        } else {
                            alert("Fehler beim LÃ¶schen des Bildes.");
                        }
                    });
                }
            </script>
        </head>
        <body id="adminbereich_body">
            <a href="./?AdminIndex" style="cursor:pointer;">&lt;&lt;&lt; zur&uuml;ck zum Adminmen&uuml;</a>
            <hr>
            <center><br>
                <a class="button" href="./?AdminGalleryCleaner">ALLES bereinigen</a>
                &#8209 (ACHTUNG: l&ouml;scht alle Bilder bis auf die letzten 24 Stunden)
            <br><br></center>
            <hr>
            <div class="gallery">
                <?php if (count($images) === 0): ?>
                    <p style="text-align: center; width: 100%;">Zurzeit keine Bilder in der Galerie.</p>
                <?php else: ?>
                    <?php foreach ($images as $image):
                        $safeImage = htmlspecialchars($image, ENT_QUOTES, 'UTF-8');
                        $imageUrl = "./userpic/" . $safeImage;
                        ?>
                    						<?php
								$metaFile = $uploadDir . $image . '.txt';
								$uploader = 'Unbekannt';
								$datum = '';
								$IP = '';

								if (file_exists($metaFile)) {
								    $meta = file_get_contents($metaFile);
								    $metaParts = explode('|', $meta);

										if (count($metaParts) >= 1) $uploader = trim($metaParts[0]);
									    if (count($metaParts) >= 2) $datum = trim($metaParts[1]);
									    if (count($metaParts) >= 3) $IP = trim($metaParts[2]);
									}
						?>
						<div class="image-container">
							<div class="meta">Bild gepostet von<br>
								<?php echo htmlspecialchars($uploader); ?><br>
								    <?php echo htmlspecialchars($datum); ?><br>
								    IP: <?php echo htmlspecialchars($IP); ?><br>
							</div>
							<div class="image-wrapper">
                            <img src="<?= $uploadDir . $safeImage ?>" alt="Bild"><br>
                            </div>
							<div class="button-group">
						    <button class="button" onclick="sendToChat('<?= $imageUrl ?>')">posten</button>
						    <button class="button danger" onclick="deleteImage('<?= $safeImage ?>')" title="Bild löschen">X</button>
							</div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <hr>
            <p style="text-align: center;">Diese administrativen &Auml;nderungen sind sofort sichtbar.</p>
        </body>
        </html>

        <?php
    }
}