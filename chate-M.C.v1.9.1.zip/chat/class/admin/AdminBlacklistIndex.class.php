<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminBlacklistIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_blacklist[0];


		// Formularverarbeitung
		if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_blacklist_submit'])) {
			$ip = trim($_POST['ip']);
			$userID = (int)$_POST['user_id'];
			$duration = (int)$_POST['duration'];

			if (!empty($ip) && $userID > 0) {
				$ip_sanitized = addslashes($ip);
				$time_to_hold = ($duration > 0) ? (time() + $duration) : 0;

				if ($duration > 0) {
					$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_blacklist
						(etchat_blacklist_ip, etchat_blacklist_userid, etchat_blacklist_time)
						VALUES ('{$ip_sanitized}', {$userID}, {$time_to_hold})");
					$this->message = "<p style='color: green;'>Benutzer wurde erfolgreich gebannt.</p>";
				} else {
					$this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = {$userID}");
					$this->message = "<p style='color: orange;'>Benutzer wurde gekickt.</p>";
				}
			} else {
				$this->message = "<p style='color: red;'>Bitte IP und UserID korrekt angeben.</p>";
			}
		}



		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin"){

			$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] = rand(1,999999999);

			$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_blacklist where etchat_blacklist_time < ".date('U'));
			$feld = $this->dbObj->sqlGet("
    SELECT 
        b.etchat_blacklist_ip, 
        b.etchat_blacklist_id, 
        IFNULL(u.etchat_username, 'Gel&ouml;schter Benutzer') AS etchat_username, 
        IFNULL(u.etchat_userprivilegien, '-') AS etchat_userprivilegien, 
        b.etchat_blacklist_time 
    FROM 
        {$this->_prefix}etchat_blacklist b
    LEFT JOIN 
        {$this->_prefix}etchat_user u 
    ON 
        b.etchat_blacklist_userid = u.etchat_user_id
");


			$this->dbObj->close();

			$this->initTemplate($lang,$feld);

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}

	}

	private function initTemplate($lang, $feld){
		include_once("styles/admin_tpl/indexBlacklist.tpl.html");
	}
}
