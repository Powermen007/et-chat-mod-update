<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminTextsIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$langData = $langObj->getLang();

		if (isset($langData->admin[0]->admin_menus[0])) {
			$lang = $langData->admin[0]->admin_menus[0];
		} else {
			$lang = (object)[ 'error' => [ (object)[ 'tagData' => 'Fehler: Sprachdatei unvollständig.' ] ] ];
		}

		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin"){

			$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] = rand(1,999999999);

			$feld=$this->dbObj->sqlGet("SELECT id, ort, header_text, content FROM {$this->_prefix}etchat_texte  ORDER BY id");
			$this->dbObj->close();

			if (is_array($feld)){
				$print_text_list = "<table>";

				foreach($feld as $datasets){

				$inhalt = mb_substr(".$datasets[3].", 1, 500, 'UTF-8');

				$print_text_list.= "<tr><td><b>ID</td><td><b>Bezeichnung</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><b>&Uuml;berschrift</td><td>&nbsp;&nbsp;&nbsp;</td><td><b>HTML-Code</td><td>&nbsp;&nbsp;&nbsp;</td><td><b>Bearbeiten</b></td><td>&nbsp;&nbsp;&nbsp;</td></tr>";
				$print_text_list.= "<tr><td><b>".$datasets[0]."</b></td><td><b>".$datasets[1]."</b></td><td>&nbsp;&nbsp;&nbsp;</td><td>".$datasets[2]."</td><td>&nbsp;&nbsp;&nbsp;</td><td>$inhalt ......</td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"./?AdminEditText&id=".$datasets[0]."\">Editieren</a></td><td>&nbsp;&nbsp;&nbsp;</td></tr>";
				}

				$print_text_list.= "</table>";
			}

			$this->initTemplate($lang, $print_text_list);

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}

	private function initTemplate($lang, $print_text_list){
		include_once("styles/admin_tpl/indexTexts.tpl.html");
	}
}
