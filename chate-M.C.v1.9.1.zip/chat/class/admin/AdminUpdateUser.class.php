<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateUser extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_user[0];


		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin" && !empty($_POST['id'])){

		$pass = (!empty($_POST['pw'])) ? "etchat_userpw = '".md5($_POST['pw'])."'," : "";

        if ($_POST['priv']=="mod"){
			$res = $this->dbObj->sqlGet("select count(etchat_user_id) FROM {$this->_prefix}etchat_user where etchat_user_id <> ".(int)$_POST['id']." AND etchat_userprivilegien = 'admin'");
			if ($res[0][0]==0){
				echo "Not possible. There will be no administrators in chat.<br><br><a href=\"./?AdminUserIndex\">back</a>";
				return false;
            }
        }

        $res_dop = $this->dbObj->sqlGet("select count(etchat_user_id) FROM {$this->_prefix}etchat_user where etchat_username = '".htmlspecialchars($_POST['user'], ENT_QUOTES, "UTF-8")."' and etchat_userprivilegien <> 'gast' and etchat_user_id<>".(int)$_POST['id']);
        if ($res_dop[0][0]>0){
            echo "Not possible, because a user with this name exists.<br><br><a href=\"./?AdminUserIndex\">back</a>";
            return false;
        }
		$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET ".$pass." etchat_username = '".htmlspecialchars($_POST['user'], ENT_QUOTES, "UTF-8")."', etchat_userprivilegien  = '".htmlspecialchars($_POST['priv'], ENT_QUOTES, "UTF-8")."', etchat_email = '".htmlspecialchars($_POST['mail'], ENT_QUOTES, "UTF-8")."' WHERE etchat_user_id=".(int)$_POST['id']);

		$this->dbObj->close();
		header("Location: ./?AdminUserIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
