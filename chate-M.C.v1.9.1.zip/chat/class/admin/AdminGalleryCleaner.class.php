<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminGalleryCleaner extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();
        
   		$desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang();

        if ($_SESSION['etchat_' . $this->_prefix . 'user_priv'] !== 'admin') {
            echo $lang->error[0]->tagData;
            return;
        }

        $this->runCleaner($desei);
    }

    private function runCleaner($desei)
    {
        $uploadDir = realpath(__DIR__ . '/../../userpic/') . '/';
        $jetzt = time();
        $etwasGelöscht = false;

        echo '<!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Bilduploadcleaner</title>
            <link href="styles/';

if (is_array($desei) && !empty($desei)) {
    foreach($desei as $data){
        echo $data[1];
    }
} else {
    echo "desei ist leer oder kein Array.";
}

			  $this->dbObj->close();
            
          echo '/style.css" rel="stylesheet" type="text/css">
        </head>
       <body id="adminbereich_body">
        <a onclick="self.location.href=\'./?AdminIndex\'" style="cursor: pointer"><<< zurück zum Adminmenü</a>
        <hr size="1">';

        if (is_dir($uploadDir)) {
            if ($handle = opendir($uploadDir)) {
                while (false !== ($datei = readdir($handle))) {
                    $dateipfad = $uploadDir . $datei;

                    if (in_array($datei, ['.', '..', 'index.html', '.htaccess'])) {
                        continue;
                    }

                    if (is_file($dateipfad) && ($jetzt - filemtime($dateipfad)) > 86400) {
                        if (unlink($dateipfad)) {
                            echo "Datei <b>$datei</b> wurde gelöscht.<br>";
                            $etwasGelöscht = true;
                        } else {
                            echo "Fehler beim Löschen von <b>$datei</b><br>";
                        }
                    }
                }
                closedir($handle);
            }

            if (!$etwasGelöscht) {
                echo "Keine Dateien älter als 24h vorhanden.";
            }
        } else {
            echo "Upload-Verzeichnis <b>$uploadDir</b> nicht gefunden.";
        }

        echo '<br><br><br>
        <a onclick="window.location.href=\'./?AdminGallery\'" style="cursor: pointer"><<< zurück zur Galerie</a>
        <hr size="1">
        </body>
        </html>';
    }
}
?>