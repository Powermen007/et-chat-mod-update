<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminDelUserPriv extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_user[0];

		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin"){

		if($_GET['cs4rue']!=$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] || !isset($_GET['cs4rue']) || !isset($_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'])){
			echo "Dear Admin this User tried to fake you. ;-)";
			return false;
		}


        $res = $this->dbObj->sqlGet("select count(etchat_user_id) FROM {$this->_prefix}etchat_user where etchat_user_id <> ".(int)$_GET['id']." AND etchat_userprivilegien = 'admin'");

		if ($res[0][0]==0){
            echo "Not possible. There will be no administrators in chat.<br><br><a href=\"./?AdminUserIndex\">back</a>";
            return false;
        }

		if ($this->_allow_nick_registration)
			$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET etchat_userprivilegien = 'user' WHERE etchat_user_id=".(int)$_GET['id']);
		else
			$this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_user WHERE etchat_user_id =".(int)$_GET['id']);

		$this->dbObj->close();
		header("Location: ./?AdminUserIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}


