<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminUpdateConfigTab extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_prop[0];

		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin"){

			$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_config SET
			etchat_config_radio_name = '".$_POST['radio_name']."',
			etchat_config_wartung = ".(int)$_POST['wartung'].",
			etchat_config_gast = ".(int)$_POST['gast_zugang'].",
			etchat_config_reg_an_aus = ".(int)$_POST['reg_an_aus'].",
			etchat_config_reloadsequenz = ".(int)$_POST['reload'].",
			etchat_config_messages_im_chat = ".(int)$_POST['anz_mess'].",
			etchat_config_style = '".$_POST['style']."',
			etchat_config_loeschen_nach = ".(int)$_POST['loeschen_nach'].",
			etchat_config_lang = '".$_POST['lang']."',
			etchat_config_wu = ".(int)$_POST['wu'].",
			etchat_config_wuan = ".(int)$_POST['wuan'].",
			etchat_config_wuza = ".(int)$_POST['wuza'].",
			etchat_config_wupau = ".(int)$_POST['wupau'].",
			etchat_config_yo = ".(int)$_POST['yo'].",
			etchat_config_bi = ".(int)$_POST['bi'].",
			etchat_config_biup = ".(int)$_POST['biup'].",
			etchat_config_av = ".(int)$_POST['av'].",
			etchat_config_pro = ".(int)$_POST['pro'].",
			etchat_config_onlie_li = ".(int)$_POST['online_li'].",
			etchat_config_radio_box = ".(int)$_POST['radio_box'].",
			etchat_config_radio_box_hi = ".(int)$_POST['radio_box_hi'].",
			etchat_config_radio_box_li = '".$_POST['radio_box_li']."',
			etchat_config_wb = ".(int)$_POST['radio_wb'].",
			etchat_config_wb_li = '".$_POST['radio_wb_li']."',
			etchat_config_user_online = '".$_POST['list_user_online']."',
			etchat_config_name_user = ".(int)$_POST['name_user_online'].",
			etchat_config_name_user_anz = ".(int)$_POST['name_user_anz'].",
			etchat_config_vollbild = '".$_POST['vb']."',
			etchat_config_admin_color = '".$_POST['c_admin']."',
			etchat_config_mod_color = '".$_POST['c_mod']."',
			etchat_config_user_color = '".$_POST['c_user']."',
			etchat_config_gast_color = '".$_POST['c_gast']."',
			etchat_config_time = '".$_POST['zeit']."',
			etchat_config_chat_gender = '".$_POST['gender']."',
			etchat_config_chat_privi = '".$_POST['privi']."',
			etchat_config_chat_anzsmily = ".(int)$_POST['chat_anzsmily'].",
			etchat_config_ol_privi = '".$_POST['privi-ol']."',
			etchat_config_be_in_pic = '".$_POST['pic_ben_info']."',
			etchat_config_chat_pic = '".$_POST['pic_chat']."',
			etchat_config_scroll = '".$_POST['sc']."',
			etchat_config_dj_box_li = '".$_POST['radio_dj_box_li']."',
			etchat_config_dj_box = ".(int)$_POST['radio_dj_box'].",
			etchat_config_radio_se_li = '".$_POST['radio_sendeplan_li']."',
			etchat_config_radio_se = ".(int)$_POST['radio_sendeplan'].",
			etchat_config_reg_user_an = ".(int)$_POST['reg_user_an']."
			WHERE etchat_config_id = 1");
			$this->dbObj->close();
			header("Location: ./?AdminPropertyIndex");

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
	}
}
