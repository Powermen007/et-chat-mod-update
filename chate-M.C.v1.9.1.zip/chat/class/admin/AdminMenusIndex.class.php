<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminMenusIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');

		$langObj = new LangXml();
		$langData = $langObj->getLang();

		if (isset($langData->admin[0]->admin_menus[0])) {
			$lang = $langData->admin[0]->admin_menus[0];
		} else {
			$lang = (object)[ 'error' => [ (object)[ 'tagData' => 'Fehler: Sprachdatei unvollständig.' ] ] ];
		}


		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin"){
			$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] = rand(1,999999999);


			$feld=$this->dbObj->sqlGet("SELECT id, menu, link_text, image_active, image, url, target, gewicht FROM {$this->_prefix}etchat_menu ORDER BY menu , gewicht");
			$this->dbObj->close();

			if (is_array($feld)){
				$print_menu_list = "<table>";

				$print_menu_list.= "<tr><td><b>Link Name</td><td>&nbsp;&nbsp;&nbsp;</td><td><b>URL</td><td>&nbsp;&nbsp;&nbsp;</td><td>Fenster</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;<b>Menu</b></td><td><b>Reihenfolge<br> Gewichtung</b></td><td><b>&nbsp;&nbsp;&nbsp;Bild</b></td></tr>";

				foreach($feld as $datasets){

					if ($datasets[1] == 1) { $ort = 'Chat';}
					if ($datasets[1] == 2) { $ort = 'Index';}
					if ($datasets[1] == 3) { $ort = 'Banner';}

					$inhalt = mb_substr(".$datasets[5].", 1, 75, 'UTF-8');

					if ($datasets[6] == '_top') { $fenster = 'Selben Fenster';} else { $fenster = 'Neues Fenster';}

				if ($datasets[3] == 1) {
				    	$print_menu_list.= "<tr><td><b>".$datasets[2]."</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><b>$inhalt ...</b></td><td>&nbsp;&nbsp;&nbsp;</td><td>$fenster&nbsp;&nbsp;</td><td><a href=\"./?AdminDeleteMenu&id=".$datasets[0]."&cs4rue=".$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit']."\">L&ouml;schen</a></td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"./?AdminEditMenu&id=".$datasets[0]."\">Editieren</a></td><td>&nbsp;&nbsp;&nbsp;<i>$ort</i></td><td>&nbsp;&nbsp;&nbsp;".$datasets[7]."</td><td><img height=\"30\" src=\"img/menu/".$datasets[4]."\"></td></tr>";
						}
					else{
					   $print_menu_list.= "<tr><td><b>".$datasets[2]."</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><b>$inhalt ...</b></td><td>&nbsp;&nbsp;&nbsp;</td><td>$fenster&nbsp;&nbsp;</td><td><a href=\"./?AdminDeleteMenu&id=".$datasets[0]."&cs4rue=".$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit']."\">L&ouml;schen</a></td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"./?AdminEditMenu&id=".$datasets[0]."\">Editieren</a></td><td>&nbsp;&nbsp;&nbsp;<i>$ort</i></td><td>&nbsp;&nbsp;&nbsp;".$datasets[7]."</td></tr>";
					}
				}
				$print_menu_list.= "</table>";
			}

			$this->initTemplate($lang, $print_menu_list);

		}else{
			echo $lang->error[0]->tagData;
			return false;
		}

	}

	private function initTemplate($lang, $print_menu_list){
		include_once("styles/admin_tpl/indexMenus.tpl.html");
	}
}
