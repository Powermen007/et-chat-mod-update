<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminRegUserEdit extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        session_start();

        header(
            "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0"
        );
        header("content-type: text/html; charset=utf-8");

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_reg_user[0];

        if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] == "admin") {
            if (isset($_POST["userids"])) {
                $ids = explode(",", $_POST["userids"]);

                foreach ($ids as $id) {
                    $filedir = "avatar"; // Uploadverzeichnis + Muss CHMOD 777 sein!

                    $avatarfile = $this->dbObj->sqlGet(
                        "SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_user_id = " .
                            (int) $id
                    );

                    if (
                        $avatarfile[0][0] != "noavatar.jpg" &&
                        $avatarfile[0][0] != "mod_ohne_pic.png" &&
                        $avatarfile[0][0] != "autodj.jpg"
                    ) {
                        $delfile = $filedir . "/" . $avatarfile[0][0];
                        if (file_exists($delfile)) {
                            unlink($delfile);
                        }
                    }

                    $this->dbObj->sqlSet(
                        "DELETE FROM {$this->_prefix}etchat_user WHERE etchat_user_id = " .
                            (int) $id
                    );
                }
            } else {
                if (
                    $_GET["cs4rue"] !=
                        $_SESSION[
                            "etchat_" . $this->_prefix . "CheckSum4RegUserEdit"
                        ] ||
                    !isset($_GET["cs4rue"]) ||
                    !isset(
                        $_SESSION[
                            "etchat_" . $this->_prefix . "CheckSum4RegUserEdit"
                        ]
                    )
                ) {
                    echo "Dear Admin this User tried to fake you. ;-)";
                    $this->dbObj->close();
                    return false;
                }

                if (isset($_GET["delavatar"])) {
                    $filedir = "avatar"; // Uploadverzeichnis + Muss CHMOD 777 sein!
                    $avatarfile = $this->dbObj->sqlGet(
                        "SELECT etchat_avatar FROM {$this->_prefix}etchat_user where etchat_user_id = " .
                            (int) $_GET["id"]
                    );
                    if (
                        $avatarfile[0][0] != "noavatar.jpg" &&
                        $avatarfile[0][0] != "mod_ohne_pic.png" &&
                        $avatarfile[0][0] != "autodj.jpg"
                    ) {
                        $delfile = $filedir . "/" . $avatarfile[0][0];
                        unlink($delfile);
                    }
                    $this->dbObj->sqlSet(
                        "update {$this->_prefix}etchat_user set etchat_avatar='noavatar.jpg' WHERE etchat_user_id = " .
                            (int) $_GET["id"]
                    );
                }

                if (isset($_GET["mod"])) {
                    $this->dbObj->sqlSet(
                        "update {$this->_prefix}etchat_user set etchat_userprivilegien='mod' WHERE etchat_user_id = " .
                            (int) $_GET["id"]
                    );
                }

                if (isset($_GET["admin"])) {
                    $this->dbObj->sqlSet(
                        "update {$this->_prefix}etchat_user set etchat_userprivilegien='admin' WHERE etchat_user_id = " .
                            (int) $_GET["id"]
                    );
                }

if (isset($_GET['deleteinactive']) && isset($_GET['inactive_months'])) {
    $months = intval($_GET['inactive_months']);
    $cutoff_timestamp = time() - ($months * 30 * 24 * 60 * 60);
    $cutoff_timestamp = (int)$cutoff_timestamp;

    $filedir = 'avatar';

    // 1. Alle inaktiven User + Avatar holen
    $inactiveUsers = $this->dbObj->sqlGet("SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_logintime < $cutoff_timestamp");

    foreach ($inactiveUsers as $user) {
        $avatar = $user[0];
        if ($avatar != "noavatar.jpg" && $avatar != "mod_ohne_pic.png" && $avatar != "autodj.jpg") {
            $delfile = $filedir . "/" . $avatar;
            if (file_exists($delfile)) {
                unlink($delfile);
            }
        }
    }

    // 2. Danach alle inaktiven User aus DB l�schen
    $sql = "DELETE FROM {$this->_prefix}etchat_user WHERE etchat_logintime < $cutoff_timestamp";
    $this->dbObj->sqlSet($sql);
}

            }
            $this->dbObj->close();
            header("Location: ./?AdminRegUserIndex");
        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }
}

