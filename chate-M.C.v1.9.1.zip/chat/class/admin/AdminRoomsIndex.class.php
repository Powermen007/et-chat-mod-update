<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class AdminRoomsIndex extends DbConectionMaker
{

	public function __construct (){ 
		
		parent::__construct(); 

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		header('content-type: text/html; charset=utf-8');
		
		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->admin_rooms[0];
		
		
		if ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin"){

			
			$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit'] = rand(1,999999999);
			
		
			$feld=$this->dbObj->sqlGet("SELECT etchat_id_room, etchat_roomname, etchat_room_goup FROM {$this->_prefix}etchat_rooms");
			$this->dbObj->close();
			
			if (is_array($feld)){
				$print_room_list = "<table>";
				foreach($feld as $datasets){
					if ($datasets[0]!=1) 
						$print_room_list.= "<tr><td><b>".$datasets[1]."</b></td><td>&nbsp;&nbsp;&nbsp;</td><td><a href=\"./?AdminDeleteRoom&id=".$datasets[0]."&cs4rue=".$_SESSION['etchat_'.$this->_prefix.'CheckSum4RegUserEdit']."\">".$lang->delete[0]->tagData."</a></td><td><a href=\"./?AdminEditRoom&id=".$datasets[0]."\">".$lang->rename[0]->tagData."</a></td><td>&nbsp;&nbsp;&nbsp;<i>".$lang->room_priv[$datasets[2]]->tagData."</i></td></tr>";
					else 
						$print_room_list.= "<tr><td><b>".$datasets[1]."</b></td><td>&nbsp;&nbsp;&nbsp;</td><td style=\"color: #888888;\"><strike>".$lang->delete[0]->tagData."</strike></td><td><a href=\"./?AdminEditRoom&id=".$datasets[0]."\">".$lang->rename[0]->tagData."</a></td><td>&nbsp;&nbsp;&nbsp;<i>".$lang->room_priv[$datasets[2]]->tagData."</i></td></tr>";
				}
				$print_room_list.= "</table>";
			}
			

			$this->initTemplate($lang, $print_room_list);
			
		}else{
			echo $lang->error[0]->tagData;
			return false;
		}
		
	}

	private function initTemplate($lang, $print_room_list){
		include_once("styles/admin_tpl/indexRooms.tpl.html");
	}
}