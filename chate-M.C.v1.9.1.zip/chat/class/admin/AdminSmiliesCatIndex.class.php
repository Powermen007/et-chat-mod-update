<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class AdminSmiliesCatIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();
        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
        header("content-type: text/html; charset=utf-8");
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];
        if ($_SESSION["etchat_" . $this->_prefix . "user_priv"] == "admin") {
			$print_smil_list  = '';

            $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] = rand(1, 999999999);
            $feld = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_smileys_cat ORDER BY `gewicht` ASC ");
            $this->dbObj->close();
            if (is_array($feld)) {
                $i = 0;
                foreach ($feld as $datasets) {
                    $i++;
                    if ($i % 2 == 0) {
                        $bgcolor = "class=\"ungerade\"";
                    } else {
                        $bgcolor = "class=\"gerade\"";
                    }
                    $print_smil_list .= "<tr " . $bgcolor . ">
                    <td>" . $i . ".</td>
                    <td align='center'>" . $datasets[0] . "</td>
                    <td >" . $datasets[1] . "</td>\t\t
                    <td ><a href=\"./?AdminRenameSmiliesCat&id=" . $datasets[0] . "\">" . $lang->rename[0]->tagData . "</a></td>
					<td><a href=\"./?AdminDeleteSmiliesCat&id=" . $datasets[0] . "&cat=" . $datasets[1] . "&cs4rue=" . $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] . "\" onclick=\"return confirm('Bist du sicher, dass du diese Smiley-Kategorie inkl. aller Smileys wirklich löschen möchtest?')\">" . $lang->delete[0]->tagData . "</a></td>
                    <td ><a href=\"./?AdminOnOffSmiliesCat&id=" . $datasets[0] . "&on_on_off=" . $datasets[2] . "&cs4rue=" . $_SESSION["etchat_" . $this->_prefix . "CheckSum4RegUserEdit"] . "\">" . $datasets[2] . "</a></td>
                    <td>" . $datasets[3] . "</td>
                    </tr>";
                }
            }
            $this->initTemplate($lang, $print_smil_list);
        } else {
            echo $lang->error[0]->tagData;
            return false;
        }
    }
    private function initTemplate($lang, $print_smil_list)
    {
        include_once "styles/admin_tpl/indexSmiliesCat.tpl.html";
    }
}

?>
