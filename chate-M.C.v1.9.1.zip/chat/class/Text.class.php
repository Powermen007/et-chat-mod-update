<?php

class Text extends DbConectionMaker
{
    public function __construct (){

        parent::__construct();

        $feld = $this->dbObj->sqlGet("SELECT id, ort, header_text, content FROM {$this->_prefix}etchat_texte WHERE id = ".(int)$_GET['id']);
        $desei = $this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");
        $this->dbObj->close();

        echo "<!doctype html>
            <html lang=\"de\">
            <head>
            <meta charset=\"UTF-8\" />
            <title></title>
            <link href=\"styles/";

        if (is_array($desei)){
            foreach($desei as $data){
                echo "$data[1]";
            }
        }

        echo "/style.css\" rel=\"stylesheet\" type=\"text/css\"/></head>";
        echo "<body id=\"body\">";

        if (is_array($feld) && count($feld) > 0) {
            $datasets = $feld[0];  // nur der erste Datensatz

            echo "<h1 style=\"margin-top: 0.05px;margin-bottom: 0.05px;\">";
            echo htmlspecialchars_decode($datasets[2]);
            echo "</h1><br>";
            echo htmlspecialchars_decode($datasets[3]);
        } else {
            echo "<p>Kein Inhalt gefunden.</p>";
        }

        echo "</body></html>";
    }
}

?>


