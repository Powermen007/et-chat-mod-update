<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Blacklist extends EtChatConfig
{

	private $dbObj;

	public $user_param_all;

	public $user_bann_time;

	public function __construct ($dbObj){

		parent::__construct();

		$this->dbObj = $dbObj;

		$this->user_param_all = $_SERVER['REMOTE_ADDR']."@".@gethostbyaddr($_SERVER['REMOTE_ADDR']);
	}

public function userInBlacklist(){

    $blacklist_c = '';
    if (isset($_COOKIE['cookie_etchat_blacklist_ip']) && isset($_COOKIE['cookie_etchat_blacklist_until'])) {
        $blacklist_c = $this->dbObj->sqlGet(
            "SELECT etchat_blacklist_time FROM {$this->_prefix}etchat_blacklist
             WHERE etchat_blacklist_ip = '".addslashes($_COOKIE['cookie_etchat_blacklist_ip'])."'
             AND etchat_blacklist_time = ".(int)$_COOKIE['cookie_etchat_blacklist_until']."
             AND etchat_blacklist_time > ".date('U')
        );
    }

    // IP und Hostname
    $user_ip = $_SERVER['REMOTE_ADDR'];
    $user_host = @gethostbyaddr($user_ip);
    $user_combined = $user_ip . '@' . $user_host;

    // Basis f�r LIKE-Abfragen
    $user_ip_prefix = substr($user_ip, 0, strrpos($user_ip, '.') + 1); // z.�B. "80.136.88."
    $user_combined_prefix = $user_ip_prefix; // falls du IP+Hostname-Pattern brauchst, hier erweiterbar

	$user_ip_prefix_2block = implode('.', array_slice(explode('.', $user_ip), 0, 2)) . '.'; // ergibt z.�B. "80.136."

	$blacklist = $this->dbObj->sqlGet(
	    "SELECT etchat_blacklist_time FROM {$this->_prefix}etchat_blacklist
    	 WHERE '".addslashes($user_ip)."' LIKE CONCAT(etchat_blacklist_ip, '%')
	     AND etchat_blacklist_time > ".date('U')
	);

    if (is_array($blacklist)) $this->user_bann_time = $blacklist[0][0];
    if (is_array($blacklist_c)) $this->user_bann_time = $blacklist_c[0][0];

    return is_array($blacklist) || is_array($blacklist_c);
}



	public function allowedToAndSetCookie(){
		$rechte_zum_sperren=$this->dbObj->sqlGet("select etchat_userprivilegien FROM {$this->_prefix}etchat_user where etchat_user_id = ".$_SESSION['etchat_'.$this->_prefix.'user_id']);
		if ($rechte_zum_sperren[0][0]!="admin" && $rechte_zum_sperren[0][0]!="mod"){
			$this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = ".$_SESSION['etchat_'.$this->_prefix.'user_id']);
			setcookie("cookie_etchat_blacklist_until", $this->user_bann_time, ["expires"  => $this->user_bann_time, "path" => "/", "samesite" => "lax"]);
			setcookie("cookie_etchat_blacklist_ip", $this->user_param_all, ["expires"  => $this->user_bann_time, "path" => "/", "samesite" => "lax"]);
			return true;
		}
		else return false;
	}

	public function insertUser($userID,$time){
		$rechte_zum_sperren=$this->dbObj->sqlGet("select etchat_userprivilegien FROM {$this->_prefix}etchat_user where etchat_user_id = ".$userID);
		if ($rechte_zum_sperren[0][0]!="admin" && $rechte_zum_sperren[0][0]!="mod"){
			$ip=$this->dbObj->sqlGet("SELECT etchat_onlineip FROM {$this->_prefix}etchat_useronline WHERE etchat_onlineuser_fid = ".$userID);
			$time_to_hold = date("U")+$time;
			$this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_blacklist (etchat_blacklist_ip, etchat_blacklist_userid, etchat_blacklist_time) VALUES ('".$ip[0][0]."', ".$userID.", ".$time_to_hold.")");
			return true;
		}
		else return false;
	}

	public function killUserSession(){
		@session_unset();
		@session_destroy();
	}
}
