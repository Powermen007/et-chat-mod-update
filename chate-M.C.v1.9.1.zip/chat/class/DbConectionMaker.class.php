<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

abstract class DbConectionMaker extends EtChatConfig
{

	protected $dbObj;

	protected function __construct (){

		parent::__construct();

		if ($this->_usedDatabaseExtension=="pdo") $this->dbObj = new ConnectDB;
		if ($this->_usedDatabaseExtension=="mysqli") $this->dbObj = new ConnectDBMysqli;

	}

	protected function configTabData2Session (){
		// gets a array with the params from the etchat_config table
		$feld = $this->dbObj->sqlGet("select etchat_config_radio_name, etchat_config_reloadsequenz, etchat_config_messages_im_chat, etchat_config_style, etchat_config_loeschen_nach, etchat_config_lang, etchat_config_wu, etchat_config_wuan, etchat_config_wuza, etchat_config_wupau, etchat_config_yo, etchat_config_bi, etchat_config_biup, etchat_config_av, etchat_config_pro, etchat_config_onlie_li, etchat_config_radio_box, etchat_config_radio_box_hi, etchat_config_radio_box_li, etchat_config_wb, etchat_config_wb_li, etchat_config_user_online, etchat_config_name_user, etchat_config_name_user_anz, etchat_config_vollbild, etchat_config_admin_color, etchat_config_mod_color, etchat_config_user_color, etchat_config_gast_color, etchat_config_time, etchat_config_chat_gender, etchat_config_chat_privi, etchat_config_chat_anzsmily, etchat_config_ol_privi, etchat_config_be_in_pic, etchat_config_chat_pic, etchat_config_scroll, etchat_config_dj_box_li, etchat_config_dj_box, etchat_config_radio_se_li, etchat_config_radio_se, etchat_config_reg_user_an, etchat_config_gast, etchat_config_wartung, etchat_config_reg_an_aus FROM {$this->_prefix}etchat_config where etchat_config_id=1");

		// setting all the session vars
		$_SESSION['etchat_'.$this->_prefix.'radio_name'] = $feld[0][0];
		$_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] = $feld[0][1];
		$_SESSION['etchat_'.$this->_prefix.'anz_messages_im_chat'] = $feld[0][2];
		$_SESSION['etchat_'.$this->_prefix.'style'] = $feld[0][3];
        $_SESSION['etchat_'.$this->_prefix.'loeschen_nach'] = $feld[0][4];
        $_SESSION['etchat_'.$this->_prefix.'lang_xml_file'] = $feld[0][5];
        $_SESSION['etchat_'.$this->_prefix.'wu'] = $feld[0][6];
        $_SESSION['etchat_'.$this->_prefix.'wuan'] = $feld[0][7];
        $_SESSION['etchat_'.$this->_prefix.'wuza'] = $feld[0][8];
        $_SESSION['etchat_'.$this->_prefix.'wupau'] = $feld[0][9];
        $_SESSION['etchat_'.$this->_prefix.'yo'] = $feld[0][10];
        $_SESSION['etchat_'.$this->_prefix.'bi'] = $feld[0][11];
        $_SESSION['etchat_'.$this->_prefix.'biup'] = $feld[0][12];
        $_SESSION['etchat_'.$this->_prefix.'av'] = $feld[0][13];
        $_SESSION['etchat_'.$this->_prefix.'pro'] = $feld[0][14];
        $_SESSION['etchat_'.$this->_prefix.'online_li'] = $feld[0][15];
        $_SESSION['etchat_'.$this->_prefix.'radio_box'] = $feld[0][16];
        $_SESSION['etchat_'.$this->_prefix.'radio_box_hi'] = $feld[0][17];
        $_SESSION['etchat_'.$this->_prefix.'radio_box_li'] = $feld[0][18];
        $_SESSION['etchat_'.$this->_prefix.'radio_wb'] = $feld[0][19];
        $_SESSION['etchat_'.$this->_prefix.'radio_wb_li'] = $feld[0][20];
        $_SESSION['etchat_'.$this->_prefix.'user_online'] = $feld[0][21];
        $_SESSION['etchat_'.$this->_prefix.'name_user_online'] = $feld[0][22];
        $_SESSION['etchat_'.$this->_prefix.'name_user_anz'] = $feld[0][23];
        $_SESSION['etchat_'.$this->_prefix.'vollbild'] = $feld[0][24];
        $_SESSION['etchat_'.$this->_prefix.'admin_color'] = $feld[0][25];
        $_SESSION['etchat_'.$this->_prefix.'mod_color'] = $feld[0][26];
        $_SESSION['etchat_'.$this->_prefix.'user_color'] = $feld[0][27];
        $_SESSION['etchat_'.$this->_prefix.'gast_color'] = $feld[0][28];
        $_SESSION['etchat_'.$this->_prefix.'an-time'] = $feld[0][29];
        $_SESSION['etchat_'.$this->_prefix.'ch-an-gender'] = $feld[0][30];
        $_SESSION['etchat_'.$this->_prefix.'ch-an-privi'] = $feld[0][31];
        $_SESSION['etchat_'.$this->_prefix.'chat_anzsmily'] = $feld[0][32];
        $_SESSION['etchat_'.$this->_prefix.'ol-an-privi'] = $feld[0][33];
        $_SESSION['etchat_'.$this->_prefix.'be_info_pic'] = $feld[0][34];
        $_SESSION['etchat_'.$this->_prefix.'chat_pic'] = $feld[0][35];
        $_SESSION['etchat_'.$this->_prefix.'scroll'] = $feld[0][36];
        $_SESSION['etchat_'.$this->_prefix.'dj_box_li'] = $feld[0][37];
        $_SESSION['etchat_'.$this->_prefix.'dj_box'] = $feld[0][38];
        $_SESSION['etchat_'.$this->_prefix.'sendeplan_li'] = $feld[0][39];
        $_SESSION['etchat_'.$this->_prefix.'sendeplan'] = $feld[0][40];
        $_SESSION['etchat_'.$this->_prefix.'reg_user_an'] = $feld[0][41];
        $_SESSION['etchat_'.$this->_prefix.'gast_zugang'] = $feld[0][42];
        $_SESSION['etchat_'.$this->_prefix.'wartung'] = $feld[0][43];
        $_SESSION['etchat_'.$this->_prefix.'reg_an_aus'] = $feld[0][44];
	}
}
