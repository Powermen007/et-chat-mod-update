<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class CheckRoomPw extends DbConectionMaker
{

	public function __construct (){
	
		parent::__construct();
	
		session_start();
		
		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		
		$freigabe=$this->dbObj->sqlGet("SELECT etchat_id_room FROM {$this->_prefix}etchat_rooms WHERE etchat_id_room = ".(int)$_POST['roomid']." AND etchat_room_pw = '".addslashes($_POST['layerpw'])."'");
		
		if (!is_array($freigabe)) echo "wrong";
		else{
			$_SESSION['etchat_'.$this->_prefix.'roompw_array'][]=$freigabe[0][0];
			echo "1";
		}
		
		$this->dbObj->close();
	}
}