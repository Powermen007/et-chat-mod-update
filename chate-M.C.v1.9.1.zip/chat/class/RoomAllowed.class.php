<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class RoomAllowed extends EtChatConfig
{

	public $room_status=0;

	public function __construct ($room_priv, $room_id){
	
		parent::__construct();
		
		$room_allowed=0;
		if ($room_priv==4 && ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin" || $_SESSION['etchat_'.$this->_prefix.'user_priv']=="mod" || $_SESSION['etchat_'.$this->_prefix.'user_priv']=="user")) $room_allowed=1;
		if ($room_priv==1 && ($_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin" || $_SESSION['etchat_'.$this->_prefix.'user_priv']=="mod")) $room_allowed=1;
		if ($room_priv==2 && $_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin") $room_allowed=1;
		if ($room_priv==0) $room_allowed=1;

		if ($room_priv==3 && $_SESSION['etchat_'.$this->_prefix.'user_priv']!="admin") $room_allowed=2;
		if ($room_priv==3 && $_SESSION['etchat_'.$this->_prefix.'user_priv']=="admin") $room_allowed=1;

		if (isset($_SESSION['etchat_'.$this->_prefix.'roompw_array']) && is_array($_SESSION['etchat_'.$this->_prefix.'roompw_array']) && $room_priv==3 && in_array($room_id, $_SESSION['etchat_'.$this->_prefix.'roompw_array']))$room_allowed=1;

		$this->room_status = $room_allowed;
	}
}