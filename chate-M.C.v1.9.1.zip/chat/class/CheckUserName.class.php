<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Erg�nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class CheckUserName extends DbConectionMaker
{

	public $lang;

	protected $user_application;

	public function __construct ($user_application=false, $username='', $gender=''){

		parent::__construct();

		@session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

		$this->user_application = $user_application;


		if (!$this->user_application){
			header('content-type: application/json; charset=utf-8');
			$username = trim($_POST['username']);
			$gender = trim($_POST['gender']);

		}else{
			$this->configTabData2Session();

			$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_messages where etchat_timestamp < ".(date('U')-($_SESSION['etchat_'.$this->_prefix.'loeschen_nach']*3600*24)));
			$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_blacklist where etchat_blacklist_time < ".date('U'));
			$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_kick_user where etchat_kicked_user_time < ".date('U'));
			$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_user WHERE etchat_userprivilegien = 'gast' AND etchat_logintime < ".(date('U')-($_SESSION['etchat_'.$this->_prefix.'loeschen_nach']*3600*24*2)));
		}

		if (empty($gender))$gender="n";

		if (!$this->user_application)
			if(!isset($_COOKIE[$this->_prefix.'cookie_test'])){ $this->errorMessage("Please aktivate your cookies."); return false;}

		if (!$this->user_application)
			if(!isset($_POST[$_SESSION[$this->_prefix.'set_check']])){ $this->errorMessage("no hacks and bots"); return false;}

		$langObj = new LangXml();
		$this->lang=$langObj->getLang()->checkusername_php[0];

		if (!$this->user_application)
			if (!$this->loginCounter()) return false;

		$style_lines = file("styles/".$_SESSION['etchat_'.$this->_prefix.'style']."/style.css");
		foreach($style_lines as $line){
			if (substr($line, 0, 10)=="Textfarbe:") {
				$ft = explode(":", $line);
				$_SESSION['etchat_'.$this->_prefix.'textcolor'] = trim($ft[1]);
			}
			if (substr($line, 0, 12)=="Systemfarbe:") {
				$fs = explode(":", $line);
				$_SESSION['etchat_'.$this->_prefix.'syscolor'] = trim($fs[1]);
			}
		}

		$blackListObj = new Blacklist($this->dbObj);

		if ($blackListObj->userInBlacklist()){
			setcookie("cookie_anzahl_logins_in_XX_sek",1,["samesite" => "lax"]);
			if (!$this->user_application) $this->errorMessage("blacklist");
			$blackListObj->killUserSession();
			if ($this->user_application) header('Location: ./?AfterBlacklistInsertion');
			return false;
		}

		$this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlinetimestamp < ".(date('U')-(($_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz']/1000)*4)));

		if (empty($username) || strlen($username)>100) { $this->errorMessage(""); return false; }

		$username = htmlspecialchars(str_replace("\\","/",preg_replace('/[\x00-\x1F\x90\x8F\x81\xA0\x9D]/', '', $username)), ENT_QUOTES, "UTF-8");

		if (!$this->user_application)
			if ($this->userInChatNow($username)) { $this->errorMessage($this->lang->name_busy[0]->tagData); return false; }

		$user_exists = $this->dbObj->sqlGet("SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien FROM {$this->_prefix}etchat_user WHERE etchat_username = '".$username."' order by etchat_userpw DESC");

		$userCheckerAndInserterObj = new UserCheckerAndInserter($this->dbObj, $user_exists, $username, $_POST['pw'], preg_replace("/[^a-z]/i", "n", $gender), $this->lang);

		if ($userCheckerAndInserterObj->status==1) $this->messageOnEnter();
		else $this->errorMessage($userCheckerAndInserterObj->status);
	}

	private function loginCounter (){
		if(!isset($_COOKIE['cookie_last_login'])) {
			setcookie("cookie_last_login", date('U'), ["samesite" => "lax"]);
			setcookie("cookie_anzahl_logins_in_XX_sek",1,["samesite" => "lax"]);
			return true;
		}
		else{
			if (date('U')-$_COOKIE['cookie_last_login'] < 180) {
				$c_anzahl_logins=$_COOKIE['cookie_anzahl_logins_in_XX_sek']+1;
				setcookie("cookie_anzahl_logins_in_XX_sek", $c_anzahl_logins, ["samesite" => "lax"]);

				if ($_COOKIE['cookie_anzahl_logins_in_XX_sek']>($this->_limit_logins_in_three_minutes-1)) {
				setcookie("cookie_last_login", date('U'), ["samesite" => "lax"]);
				$this->errorMessage($this->lang->many_logins[0]->tagData);
				return false;
				}
			else return true;
			}
			else {
				setcookie("cookie_last_login", date('U'), ["samesite" => "lax"]);
				setcookie("cookie_anzahl_logins_in_XX_sek", 1, ["samesite" => "lax"]);
				return true;
			}
		}
	}

	private function userInChatNow($user){
		if(is_array($this->dbObj->sqlGet("SELECT etchat_username FROM {$this->_prefix}etchat_useronline, {$this->_prefix}etchat_user WHERE etchat_username = '".$user."' AND etchat_user_id = etchat_onlineuser_fid LIMIT 1"))){
			setcookie("cookie_anzahl_logins_in_XX_sek",1,["samesite" => "lax"]);
			return true;
		}
		else return false;
	}

	private function errorMessage($message){
		echo $message;
		$this->dbObj->close();
		return false;
	}

	private function messageOnEnter(){
		new RoomEntrance($this->dbObj, $this->lang);

		unset($_SESSION[$this->_prefix.'set_check']);

		$this->dbObj->close();

		if (!$this->user_application) echo "1";
		else header('Location: ./?Chat');
		return true;
	}
}