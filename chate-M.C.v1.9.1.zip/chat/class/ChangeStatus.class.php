<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class ChangeStatus extends DbConectionMaker
{

	public function __construct (){
	
		parent::__construct();
	
		session_start();
		
		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		
		if(isset($_POST['sys_messages'])){
			$_SESSION['etchat_'.$this->_prefix.'sys_messages']=$_POST['sys_messages'];
			return false;
		}
		
		if (!$this->checkRightsOfStatus($_POST['img'])) {
			$_POST['img']=""; 
			$_POST['text']="";
			echo "Not allowed operation.";
			return false;
		}
		
		$_POST['img']= htmlspecialchars(preg_replace("/[^a-zA-Z_0-9\-. ]/i", "", $_POST['img']), ENT_QUOTES, "UTF-8");
		$_POST['text']= htmlspecialchars(preg_replace('/[\x00-\x1F]/', '', $_POST['text']), ENT_QUOTES, "UTF-8");

		if($_POST['img']=="status_online"){$_POST['img']=""; $_POST['text']="";}

		if (!empty($_POST['img']) && !file_exists("./img/".$_POST['img'].".png")) {$_POST['img']=""; $_POST['text']="";}
		
		$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_useronline SET 
			etchat_user_online_user_status_img = '".addslashes($_POST['img'])."',
			etchat_user_online_user_status_text = '".addslashes(urldecode($_POST['text']))."'
			WHERE etchat_onlineuser_fid = ".(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);
		
		$this->dbObj->close();
		
		echo "1";
	}

	private function checkRightsOfStatus($statusImagename){
		
		if(substr($statusImagename, 0, 7)!='status_') return false;
		
		$langObj = new LangXml();
		$lang=$langObj->getLang();
		
		foreach($lang->chat_js[0]->status as $status_value) 
			if ($status_value->tagAttrs['imagename']==$statusImagename && $status_value->tagAttrs['rights']!='all')	
				$thisStatusImagenameRights[]=$status_value->tagAttrs['rights'];
		
		$thisStatusImagenameRights = '';
		if (!is_array($thisStatusImagenameRights)) return true;
		else{
			if (in_array($_SESSION['etchat_'.$this->_prefix.'user_priv'], $thisStatusImagenameRights)) return true;
			else return false;
		}
	}
}