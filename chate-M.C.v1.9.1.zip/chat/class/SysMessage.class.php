<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class SysMessage extends EtChatConfig
{

	protected $dbObj;

	public $lastInsertedId;

	public function __construct ($dbObj, $message, $room_fid, $privat){

		parent::__construct();

		$dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages ( etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat, etchat_user_ip)
		VALUES ( 1, '".$message."', 'color:#".$_SESSION['etchat_'.$this->_prefix.'syscolor'].";font-weight:normal;font-style:normal;', '".date('U')."', ".$room_fid.", ".$privat.", '".$_SERVER['REMOTE_ADDR']."')");

		if (!empty($dbObj->lastId)) $this->lastInsertedId = $dbObj->lastId;
		else {
			$lastID = $dbObj->sqlGet("SELECT max(etchat_id) from {$this->_prefix}etchat_messages");
			$this->lastInsertedId = $lastID[0][0];
		}
	}
}