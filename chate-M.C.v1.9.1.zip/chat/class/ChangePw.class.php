<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class ChangePw extends DbConectionMaker
{

	public function __construct (){
	
		parent::__construct();
	
		session_start();
		
		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		
		$userprivilegien = $this->dbObj->sqlGet("select etchat_userprivilegien from {$this->_prefix}etchat_user WHERE etchat_user_id = ".(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);
		
		if ($userprivilegien[0][0]=="admin" || $userprivilegien[0][0]=="mod" || $userprivilegien[0][0]=="user"){
			
			if(!empty($_POST['modpw'])){
				$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET etchat_userpw = '".md5($_POST['modpw'])."' WHERE etchat_user_id = ".(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);
				echo "1";
			} else 
				echo "Error! You shouldn't be here.";
		}

		else if ($this->_allow_nick_registration && $_SESSION['etchat_'.$this->_prefix.'user_priv']=="gast" && !empty($_POST['user_pw'])){
			
			if (isset($_COOKIE['cookie_etchat_nik_registered'])){
				$langObj = new LangXml();
				$lang=$langObj->getLang()->changepw_php[0];
				echo $lang->warning[0]->tagData;
			}
			else{	
				setcookie("cookie_etchat_nik_registered", "1", ["expires"  => time()+(24*3600), "path" => "/", "samesite" => "lax"]);
				$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET etchat_userpw = '".md5($_POST['user_pw'])."', etchat_userprivilegien='user', etchat_reg_timestamp=now(), etchat_reg_ip='".$_SERVER['REMOTE_ADDR']."' WHERE etchat_user_id = ".(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);
				echo "1";
			}
		}
		$this->dbObj->close();
	}
}