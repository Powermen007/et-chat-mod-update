<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

 class Sitemaker{

	private $print_site_count;

	private $anzahl_der_messages_pro_seite;

	private $counted;

	public $href=false;

	public function __construct($anz, $count){
		$this->anzahl_der_messages_pro_seite = $anz; 
		$this->counted = $count; 
	}

 	public function make($seite, 
	$tpl, 
	$site_text = "Site",
	$of_text = "of",
	$minus_stop = "&lt;&lt;&lt;",
	$minus = "&lt;&lt;&lt;",
	$plus = "&gt;&gt;&gt;",
	$plus_stop = "&gt;&gt;&gt;"
	){
		
		$anzahl_der_seiten_ermittelt = (int)(($this->counted/$this->anzahl_der_messages_pro_seite)+0.99999999999999);
		
		if ($seite<1) $seite=1;
		if ($seite>$anzahl_der_seiten_ermittelt) $seite=$anzahl_der_seiten_ermittelt ;

		if ($this->href) {
			$href_inc_minus = str_replace ( '#site#', ($seite-1), $tpl );
			$href_inc_plus= str_replace ( '#site#', ($seite+1), $tpl );
		}
		else {
			$href_inc_minus ="#";
			$href_inc_plus ="#";
		}
		
		if ($seite==1) $this->print_site_count =  $minus_stop."&nbsp;&nbsp;";
		else $this->print_site_count = "<a class=\"sitemaker\" href=\"".$href_inc_minus."\" id=\"".str_replace ( '#site#', ($seite-1), $tpl )."\" title=\"Site -\">".$minus."</a>&nbsp;&nbsp;";


		$this->print_site_count .= $site_text."\n<form action=\"\" style=\"display:inline;\">";
		$this->print_site_count .="\n<div style=\"display:inline;\"><select id=\"site_selecter\" class=\"sitemaker_select\">\n";

                 for ($i=1; $i<=$anzahl_der_seiten_ermittelt; $i++) {
                       if ($seite == $i) $this->print_site_count .="<option value=\"".$i."\" selected=\"selected\">$i</option>\n";
                       else $this->print_site_count .= "<option value=\"".$i."\">$i</option>\n";
                 }

                 $this->print_site_count .="</select></div></form>";

		$this->print_site_count .= "&nbsp;".$of_text."&nbsp;".$anzahl_der_seiten_ermittelt."&nbsp;&nbsp;";

		if (($this->counted/$this->anzahl_der_messages_pro_seite) <= $seite) $this->print_site_count .= $plus;
		else $this->print_site_count .= "<a class=\"sitemaker\" href=\"".$href_inc_plus."\" id=\"".str_replace ( '#site#', ($seite+1), $tpl )."\"  title=\"Site +\">".$plus_stop."</a>";

	}

	function show(){
		echo $this->print_site_count;
	}

	function get(){
		return $this->print_site_count;
	}
} 

?>