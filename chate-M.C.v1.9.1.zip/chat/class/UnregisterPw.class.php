<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class UnregisterPw extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

		$userprivilegien = $this->dbObj->sqlGet("select etchat_userprivilegien, etchat_userpw from {$this->_prefix}etchat_user WHERE etchat_user_id = ".(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);

		if ($userprivilegien[0][0]=="admin" || $userprivilegien[0][0]=="mod" || $userprivilegien[0][0]=="user"){
			if($userprivilegien[0][1]==md5($_POST['user_pw'])){
			
					$filedir = 'avatar'; // Uploadverzeichnis + Muss CHMOD 777 sein!
					$avatarfile = $this->dbObj->sqlGet("SELECT etchat_avatar FROM {$this->_prefix}etchat_user where etchat_user_id = ".(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);
					if($avatarfile[0][0]!="noavatar.jpg" && $avatarfile[0][0]!="mod_ohne_pic.png" && $avatarfile[0][0]!="autodj.jpg") {
						    $delfile = $filedir."/".$avatarfile[0][0];
						    unlink($delfile);
					}

				$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET
					etchat_userpw = NULL,
					etchat_userprivilegien = 'gast',
					etchat_avatar = 'noavatar.jpg',
					etchat_email = NULL,
					etchat_reset_token = NULL,
					etchat_reset_token_expiry = NULL,
				 	etchat_geb_tag = NULL,
				 	etchat_geb_monat = NULL,
				 	etchat_geb_jahr = NULL,
				 	etchat_ort = NULL,
				 	etchat_beschreibung = NULL
					WHERE etchat_user_id = ".(int)$_SESSION['etchat_'.$this->_prefix.'user_id']);
				echo "1";
			} else {
				$langObj = new LangXml();
				$lang=$langObj->getLang()->unregisterpw_php[0];
				echo "<b>".$lang->warning[0]->tagData."</b><br>".$lang->warning[1]->tagData;
			}
		} else {
			echo "No, no... ;-)";
		}
		$this->dbObj->close();
	}
}
