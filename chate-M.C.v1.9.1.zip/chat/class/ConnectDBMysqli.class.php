<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class ConnectDBMysqli extends EtChatConfig{

	protected $_connid;

	public $lastId;

	public function __construct (){
	
		parent::__construct();
	
		$this->_connid = new mysqli($this->_sqlhost, $this->_sqluser, $this->_sqlpass, $this->_database);

		if ($this->_connid->connect_error) {
			printf("Connect failed: %s\n", mysqli_connect_error());
			return false;
		}

	}

	public function sqlGet($sql){
	
		$result = $this->_connid->query($sql);
		
		$a=0;

		while($row = $result->fetch_array(MYSQLI_NUM)) {
			$b=0;
			foreach ($row as $field) {
				$resultArray[$a][$b]=$field;
				$b++;
			}
			$a++;
		}
		
		if (!is_array($resultArray)) return 0;
		return $resultArray;
	}

	public function sqlSet($sql){
		
		$datasets = $this->_connid->query($sql);
		
		$this->lastId = $this->_connid->insert_id;
		return $datasets;
	}

	public function close(){
		$this->_connid->close();
	}
}