<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class AfterSpamlistInsertion extends DbConectionMaker
{

	public function __construct (){ 
		
		parent::__construct(); 

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		
		$this->configTabData2Session();
		
		$this->dbObj->close();
		
		$langObj = new LangXml();
		$lang=$langObj->getLang()->admin[0]->spam[0];
		
		$this->initTemplate($lang);
	}

	private function initTemplate($lang){
		include_once("styles/".$_SESSION['etchat_'.$this->_prefix.'style']."/spamlisted.tpl.html");
	}
}