<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class ConnectDB extends EtChatConfig{

	protected $_connid;

	public $lastId;

	public function __construct (){

		parent::__construct();

		try
		{
			$this->_connid = new PDO("{$this->_usedDatabase}:host={$this->_sqlhost};dbname=".$this->_database, $this->_sqluser, $this->_sqlpass);
		}
		catch(PDOException $e)
		{
			echo "ERROR: " . $e->getMessage();
			echo "<br /><h3>Bitte editieren Sie die config.php und tragen Sie dort die geforderten Parameter ein. Danach machen Sie weiter mit der Installationsroutine. Mehr dazu finden Sie unter install.txt !</h3>";
		}
	}

public function escape($value) {
    return substr($this->_connid->quote($value), 1, -1);
}



	public function sqlGet($sql){

		if (empty($sql)) {
		die(json_encode(["error" => "Leere SQL-Abfrage!"]));
		}
		$erg = $this->_connid->query($sql);

		$error_code=(int)$this->_connid->errorCode();
		if (!empty($error_code)) {
			$arr = $this->_connid->errorInfo();
			print_r($arr);
			echo $sql;
			if ($arr[1]==1146)
				echo "<br /><h4>Dieser Fehler deutet darauf, dass der ET-Chat nicht ordentlich in die Datenbank installiert wurde.
				Lesen Sie bitte dazu die readme.txt und nutzen Sie die <a href=\"install/\">Installationsroutine</a>.</h4>";
		}

		$resultArray = $erg->fetchAll(PDO::FETCH_NUM);

		$erg = null;

		if (!isset($resultArray) || empty($resultArray)) return 0;
		return $resultArray;
	}

	public function sqlSet($sql){

		$datasets = $this->_connid->exec($sql);

		$error_code=(int)$this->_connid->errorCode();
		if (!empty($error_code)) {
			$arr = $this->_connid->errorInfo();
			print_r($arr);
			echo $sql;
		}

		$this->lastId = $this->_connid->lastInsertId();
		return $datasets;
	}

	public function close(){
		$this->_connid=null;
	}
}
