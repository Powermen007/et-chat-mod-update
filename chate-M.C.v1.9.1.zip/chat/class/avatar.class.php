<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Erg�nzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class avatar extends DbConectionMaker
{

public function __construct (){

parent::__construct();

session_start();

header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
header('content-type: text/html; charset=utf-8');

$filedir = 'avatar/temp'; // Uploadverzeichnis Temp + Muss CHMOD 777 sein!
$filedir1 = 'avatar';	  // Uploadverzeichnis + Muss CHMOD 777 sein!
$accepted = array('png', 'jpg', 'jpeg', 'gif');

$userId = $_POST['userid'];

if ($_POST['task']=="insert"){
if (isset($_FILES['file']))
{
$avatarfile = $this->dbObj->sqlGet("SELECT etchat_avatar, etchat_username FROM {$this->_prefix}etchat_user where etchat_user_id = '".$userId."'");
if($avatarfile[0][0]!="noavatar.jpg" AND $avatarfile[0][0]!="mod_ohne_pic.png" AND $avatarfile[0][0]!="autodj.jpg") {
$delfile = $filedir1."/".$avatarfile[0][0];
unlink($delfile);
}

preg_match('/.([a-zA-Z]+?)$/', $_FILES['file']['name'], $matches);
if(in_array(strtolower($matches[1]), $accepted)) {
$newname = $avatarfile[0][1] . '-' . time() . '.' . $matches[1];
move_uploaded_file($_FILES['file']['tmp_name'], $filedir.'/'.$newname);

$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET etchat_avatar = '".$newname."' WHERE etchat_user_id = '".$userId."'");

$this->dbObj->close();



$filepath_old = 'avatar/temp/'.$newname;
$filepath_new = 'avatar/'.$newname;
$image_dimension = 100;
$scale_mode = 0;


  $image_attributes = getimagesize($filepath_old);
  $image_width_old = $image_attributes[0];
  $image_height_old = $image_attributes[1];
  $image_filetype = $image_attributes[2];

  if ($image_width_old <= 0 || $image_height_old <= 0) return false;
  $image_aspectratio = $image_width_old / $image_height_old;

  if ($scale_mode == 0) {
   $scale_mode = ($image_aspectratio > 1 ? -1 : -2);
  } elseif ($scale_mode == 1) {
   $scale_mode = ($image_aspectratio > 1 ? -2 : -1);
  }

  if ($scale_mode == -1) {
   $image_width_new = $image_dimension;
   $image_height_new = round($image_dimension / $image_aspectratio);
  } elseif ($scale_mode == -2) {
   $image_height_new = $image_dimension;
   $image_width_new = round($image_dimension * $image_aspectratio);
  } else {
   return false;
  }

  switch ($image_filetype) {
   case 1:
    $image_old = imagecreatefromgif($filepath_old);
    $image_new = imagecreate($image_width_new, $image_height_new);
    imagecopyresampled($image_new, $image_old, 0, 0, 0, 0, $image_width_new, $image_height_new, $image_width_old, $image_height_old);
    imagegif($image_new, $filepath_new);
    break;

   case 2:
    $image_old = imagecreatefromjpeg($filepath_old);
    $image_new = imagecreatetruecolor($image_width_new, $image_height_new);
    imagecopyresampled($image_new, $image_old, 0, 0, 0, 0, $image_width_new, $image_height_new, $image_width_old, $image_height_old);
    imagejpeg($image_new, $filepath_new);
    break;

   case 3:
    $image_old = imagecreatefrompng($filepath_old);
    $image_colordepth = imagecolorstotal($image_old);

    if ($image_colordepth == 0 || $image_colordepth > 255) {
     $image_new = imagecreatetruecolor($image_width_new, $image_height_new);
    } else {
     $image_new = imagecreate($image_width_new, $image_height_new);
    }

    imagealphablending($image_new, false);
    imagecopyresampled($image_new, $image_old, 0, 0, 0, 0, $image_width_new, $image_height_new, $image_width_old, $image_height_old);
    imagesavealpha($image_new, true);
    imagepng($image_new, $filepath_new);
    break;

   default:
    return false;
  }
  unlink($filepath_old);
  imagedestroy($image_old);
  imagedestroy($image_new);
  return true;
}
}
}



if ($_POST['task']=="delete"){
$userId = (int)$_POST['userid'];
$avatarfile2 = $this->dbObj->sqlGet("SELECT etchat_avatar, etchat_username FROM {$this->_prefix}etchat_user where etchat_user_id = '".$userId."'");
if($avatarfile2[0][0]!="noavatar.jpg" AND $avatarfile2[0][0]!="mod_ohne_pic.png" AND $avatarfile2[0][0]!="autodj.jpg") {
$delfile = $filedir1."/".$avatarfile2[0][0];
unlink($delfile);
$this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET etchat_avatar = 'noavatar.jpg' WHERE etchat_user_id = '".$userId."'");
}

$this->dbObj->close();
}
}
}





