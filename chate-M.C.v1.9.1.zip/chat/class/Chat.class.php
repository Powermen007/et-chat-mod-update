<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class Chat extends EtChatConfig
{

	public $lang;

	public function __construct (){

		parent::__construct();
		
		session_start();

		header('content-type: text/html; charset=utf-8');
		
		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');

		unset($_SESSION['etchat_'.$this->_prefix.'reload_user_anz']);
		
		if (empty($_SESSION['etchat_'.$this->_prefix.'username'])){
			header('Location: ./');
			return false;
		}
		
		$langObj = new LangXml;
		$this->lang=$langObj->getLang()->chat_php[0];

		$_SESSION['etchat_'.$this->_prefix.'random_user_number'] = rand(1,99999999999);
		$this->initTemplate();
	}

	private function initTemplate(){
		include_once("styles/".$_SESSION['etchat_'.$this->_prefix.'style']."/chat.tpl.html");
	}
	
}