<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class ExternUserView2 extends DbConectionMaker
{

	public function __construct (){

	echo "<div class=\"w3-content w3-display-container\">";

		parent::__construct();

			$feld=$this->dbObj->sqlGet("SELECT id, menu, link_text, image_active, image, url, target, gewicht FROM {$this->_prefix}etchat_menu WHERE menu = 3 ORDER BY gewicht");
			$this->dbObj->close();

			if (is_array($feld)){

				foreach($feld as $datasets){
				if ($datasets[3] == 1) {
						echo "<a class=\"img_banner\" href=\"".$datasets[5]."\" target=\"".$datasets[6]."\"><img class=\"mySlides\"  border=\"0\" alt=\"".$datasets[2]."\" longdesc=\"".$datasets[2]."\" src=\"img/menu/".$datasets[4]."\" /></a>";
						}
					else{
					echo "<a href=\"".$datasets[5]."\" target=\"".$datasets[6]."\"><b><FONT class=\"mySlides\" SIZE=\"+4\"><br>&nbsp;&nbsp;&nbsp;&nbsp;".$datasets[2]."&nbsp;&nbsp;&nbsp;&nbsp;<br></FONT></b></a>&nbsp;&nbsp;&nbsp;";
					}
				}

			}
		echo "</div>";
		echo " <script>
 					var slideIndex = 0;
			   carousel();

				function carousel() {
				    var i;
				    var x = document.getElementsByClassName(\"mySlides\");
				    for (i = 0; i < x.length; i++) {
				      x[i].style.display = \"none\";
				    }
				    slideIndex++;
				    if (slideIndex > x.length) {slideIndex = 1}
				    x[slideIndex-1].style.display = \"block\";
				    setTimeout(carousel, 30000); // Change image every 30 seconds
				}
				 </script>";
	}
}

new ExternUserView2();

?>


