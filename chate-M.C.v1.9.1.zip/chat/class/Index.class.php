<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Index extends DbConectionMaker
{

	public $lang;

	public $aktuell_date_u;

	public function __construct (){

		parent::__construct();

		session_start();

		setcookie($this->_prefix."cookie_test", date('U'), ["samesite" => "lax"]);

		header('content-type: text/html; charset=utf-8');

		$this->configTabData2Session();

		$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_messages where etchat_timestamp < ".(date('U')-($_SESSION['etchat_'.$this->_prefix.'loeschen_nach']*3600*24)));
		$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_blacklist where etchat_blacklist_time < ".date('U'));
		$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_kick_user where etchat_kicked_user_time < ".date('U'));
		$this->dbObj->sqlSet("delete FROM {$this->_prefix}etchat_user WHERE etchat_userprivilegien = 'gast' AND etchat_logintime < ".(date('U')-($_SESSION['etchat_'.$this->_prefix.'loeschen_nach']*3600*24*2)));

		$this->dbObj->close();

		$langObj = new LangXml;
		$this->lang=$langObj->getLang()->index_php[0];

		$this->aktuell_date_u=date('U');
		$_SESSION[$this->_prefix.'set_check']=md5($this->aktuell_date_u);

		$this->initTemplate();
	}

	private function initTemplate(){
		include_once("styles/".$_SESSION['etchat_'.$this->_prefix.'style']."/index.tpl.html");
	}

	// set the db messages all 31 days the etchat_id back
	private function monthlyMaintenance() {
		if (date("d") == 31) {
			try {
				$this->dbObj->beginTransaction();
				$this->dbObj->exec("SET @a = 0");
				$this->dbObj->exec("UPDATE {$this->_prefix}etchat_messages SET etchat_id = (@a := @a +1)");
				$this->dbObj->exec("ALTER TABLE {$this->_prefix}etchat_messages AUTO_INCREMENT = 1");
				$this->dbObj->commit();
			} catch (Exception $e) {
				$this->dbObj->rollBack();
				error_log("Maintenance error: " . $e->getMessage());
			}
		}
	}
}
