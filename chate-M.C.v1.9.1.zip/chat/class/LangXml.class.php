<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class LangXml extends EtChatConfig
{

	public $langXmlDoc;

	public function __construct ($path="./lang/", $xmlfile=""){	
		
		parent::__construct();
		
		$xmlfile = (empty($xmlfile)) ? $_SESSION['etchat_'.$this->_prefix.'lang_xml_file'] : $xmlfile;

		if (empty($xmlfile)) $xmlfile = "lang_en.xml";
		
		$xml = @file_get_contents($path.$xmlfile);
		
		$parser = new AAFParser($xml);
		$parser->Parse();
		$this->langXmlDoc = $parser->document;
	}

	public function getLang(){	
		return $this->langXmlDoc;
	}
}