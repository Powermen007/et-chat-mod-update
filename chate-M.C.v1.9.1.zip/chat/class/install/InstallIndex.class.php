<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class InstallIndex extends EtChatConfig
{

	public function __construct (){

		parent::__construct();

		$install_error = "";

		if ($this->_usedDatabaseExtension=="pdo"){
			if (!extension_loaded('pdo')) $install_error .= "<div style=\"color:red\"> Keine PDO-Erweiterung gefunden.(PDO-Erweiterung sollte installiert sein!)</div>";
			if (!extension_loaded('pdo_'.$this->_usedDatabase)) $install_error .= "<div style=\"color:red\"> Keine pdo_".$this->_usedDatabase."-Erweiterung gefunden.(pdo_".$this->_usedDatabase." sollte installiert sein!)</div>";
		}

		if ($this->_usedDatabaseExtension=="mysqli")
			if (!extension_loaded('mysqli')) $install_error .= "<div style=\"color:red\"> Keine MySQLi-Erweiterung gefunden.(MySQLi sollte installiert sein!)</div>";

		if (empty($install_error))
			$start_install = "<a href=\"./?InstallMake\">Update starten &gt;&gt;&gt;</a>";
		else
			$start_install = "<b>Das Update kann nicht durchgeführt werden.</b><br /><br /> Ursache/n:<br />".$install_error."<br /><br />Bitte korrigieren Sie die Einstellungen Ihres Webservers um das Update zu installieren.";


		if (file_exists("./install"))
			include_once("styles/install_tpl/index.tpl.html");
		else
			echo "Install directory was not found.";
	}
}
