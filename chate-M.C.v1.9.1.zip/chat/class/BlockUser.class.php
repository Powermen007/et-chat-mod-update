<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class BlockUser extends EtChatConfig
{

	public function __construct (){
	
		session_start();
		
		parent::__construct();
		
		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
		
		if(!is_array($_SESSION['etchat_'.$this->_prefix.'block_priv'])) $_SESSION['etchat_'.$this->_prefix.'block_priv'] = array();
		if(!is_array($_SESSION['etchat_'.$this->_prefix.'block_all'])) $_SESSION['etchat_'.$this->_prefix.'block_all'] = array();

		if (isset($_POST['block_all'])){

			if (in_array($_POST['block_all'], $_SESSION['etchat_'.$this->_prefix.'block_all'])){
				$key_from_all = array_search($_POST['block_all'], $_SESSION['etchat_'.$this->_prefix.'block_all']);
				$_SESSION['etchat_'.$this->_prefix.'block_all'][$key_from_all]=99999999999;

				$key_from_priv = array_search($_POST['block_all'], $_SESSION['etchat_'.$this->_prefix.'block_priv']);
				$_SESSION['etchat_'.$this->_prefix.'block_priv'][$key_from_priv]=99999999999;
			}

			else {
        	    $_SESSION['etchat_'.$this->_prefix.'block_all'][] = $_POST['block_all'];

				$key_from_priv = array_search($_POST['block_all'], $_SESSION['etchat_'.$this->_prefix.'block_priv']);
				$_SESSION['etchat_'.$this->_prefix.'block_priv'][$key_from_priv]=99999999999;
             }

		}
		if (isset($_POST['block_priv'])){
			if (in_array($_POST['block_priv'], $_SESSION['etchat_'.$this->_prefix.'block_priv'])){
				$key_from_priv = array_search($_POST['block_priv'], $_SESSION['etchat_'.$this->_prefix.'block_priv']);
				$_SESSION['etchat_'.$this->_prefix.'block_priv'][$key_from_priv]=99999999999;

				$key_from_all = array_search($_POST['block_priv'], $_SESSION['etchat_'.$this->_prefix.'block_all']);
				$_SESSION['etchat_'.$this->_prefix.'block_all'][$key_from_all]=99999999999;
			}
			else {
				$_SESSION['etchat_'.$this->_prefix.'block_priv'][] = $_POST['block_priv'];

				$key_from_all = array_search($_POST['block_priv'], $_SESSION['etchat_'.$this->_prefix.'block_all']);
				$_SESSION['etchat_'.$this->_prefix.'block_all'][$key_from_all]=99999999999;
			}
		}

		if (isset($_POST['show'])){
			if (in_array($_POST['show'], $_SESSION['etchat_'.$this->_prefix.'block_priv'])) echo "priv";
			if (in_array($_POST['show'], $_SESSION['etchat_'.$this->_prefix.'block_all'])) echo "all";
		}
	}
}