<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class RoomEntrance extends EtChatConfig
{

	private $dbObj;

	private $_lang;

	public function __construct ($dbObj, $lang){

		parent::__construct();

		$this->dbObj=$dbObj;
		$this->_lang=$lang;

		$room_message=$this->dbObj->sqlGet("SELECT etchat_room_message FROM {$this->_prefix}etchat_rooms where etchat_id_room = 1");

		if (!empty($_POST['status_invisible']) && ($_SESSION['etchat_'.$this->_prefix.'user_priv']=='admin' || $_SESSION['etchat_'.$this->_prefix.'user_priv']=='mod'))
			$_SESSION['etchat_'.$this->_prefix.'invisible_on_enter'] = true;
		else
			$_SESSION['etchat_'.$this->_prefix.'invisible_on_enter'] = false;

		if (empty($room_message[0][0])) $this->withoutRoomMessage();
		else $this->withRoomMessage($room_message[0][0]);

		$_SESSION['etchat_'.$this->_prefix.'last_id'] = 0;
	}

	private function withoutRoomMessage(){

		$an = (!empty($_POST['status_invisible']) && ($_SESSION['etchat_'.$this->_prefix.'user_priv']=='admin' || $_SESSION['etchat_'.$this->_prefix.'user_priv']=='mod')) ? $_SESSION['etchat_'.$this->_prefix.'user_id'] : 0;

		$user_color2 = $this->getUserColor($_SESSION['etchat_'.$this->_prefix.'user_priv']);

		$avataricon = $this->getAvatarIcon();
		$username_with_color = "<span style=\"$user_color2\">" . htmlentities($_SESSION['etchat_'.$this->_prefix.'username'], ENT_QUOTES, "UTF-8") . "</span>";

		$sysMessObj = new SysMessage($this->dbObj, "".$avataricon." <b>".$username_with_color."</b> ".$this->_lang->eintritt[0]->tagData, 0, $an );
		$_SESSION['etchat_'.$this->_prefix.'my_first_mess_id'] = $sysMessObj->lastInsertedId;
	}

	private function withRoomMessage($room_message){

		$an = (!empty($_POST['status_invisible']) && ($_SESSION['etchat_'.$this->_prefix.'user_priv']=='admin' || $_SESSION['etchat_'.$this->_prefix.'user_priv']=='mod')) ? $_SESSION['etchat_'.$this->_prefix.'user_id'] : 0;

		$user_color2 = $this->getUserColor($_SESSION['etchat_'.$this->_prefix.'user_priv']);

		$avataricon = $this->getAvatarIcon();
		$username_with_color = "<span style=\"$user_color2\">" . htmlentities($_SESSION['etchat_'.$this->_prefix.'username'], ENT_QUOTES, "UTF-8") . "</span>";

		$room_message_insert = str_replace("\r\n","<br />",$room_message);
		$room_message_insert = str_replace("\n","<br />",$room_message_insert);

		$sysMessObj = new SysMessage($this->dbObj, "<br /><div style=\"margin: 4px;\">".$room_message_insert."</div>", 1, $_SESSION['etchat_'.$this->_prefix.'user_id']);
		$_SESSION['etchat_'.$this->_prefix.'my_first_mess_id'] = $sysMessObj->lastInsertedId;
		new SysMessage($this->dbObj, "".$avataricon." <b>".$username_with_color."</b> ".$this->_lang->eintritt[0]->tagData, 0, $an );
	}

	private function getUserColor($priv) {
		switch($priv) {
			case 'admin': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
			case 'mod':	return "color: ".$_SESSION['etchat_'.$this->_prefix.'mod_color']."";
			case 'user': return "color: ".$_SESSION['etchat_'.$this->_prefix.'user_color']."";
			case 'gast': return "color: ".$_SESSION['etchat_'.$this->_prefix.'gast_color']."";
			default: return "color: #FFFFFF";
		}
	}
	private function getAvatarIcon() {
	
	if ($_SESSION['etchat_'.$this->_prefix.'chat_pic'] == '1'){
		$avatar = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_user WHERE etchat_username = '".$_POST['username']."'");
		$avatar1 = $avatar [0][7];
		return "<img src=\"avatar/$avatar1\" class=\"avatar_w\" alt=\"\" title=\"\">";
		}else{
		return "";
		}
	}
}
