<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class ExternUserView1 extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

			$feld=$this->dbObj->sqlGet("SELECT id, menu, link_text, image_active, image, url, target, gewicht FROM {$this->_prefix}etchat_menu WHERE menu = 1 ORDER BY gewicht");
			$this->dbObj->close();

			if (is_array($feld)){

				foreach($feld as $datasets){
				if ($datasets[3] == 1) {
						echo "<a href=\"".$datasets[5]."\" class=\"img_home\" target=\"".$datasets[6]."\"><img height=\"40\" border=\"0\" alt=\"".$datasets[2]."\" longdesc=\"".$datasets[2]."\" title=\"".$datasets[2]."\"src=\"img/menu/".$datasets[4]."\" /></a>&nbsp;";
						}
					else{
					echo "<a href=\"".$datasets[5]."\" class=\"img_home\" target=\"".$datasets[6]."\"><b><FONT SIZE=\"+1\">".$datasets[2]."</FONT></b></a>&nbsp;";
					}
				}
			}
	}
}

new ExternUserView1();

?>


