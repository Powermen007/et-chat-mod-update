<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

class Gallery extends DbConectionMaker{

	 private $desei;

    public function __construct()
    {
        parent::__construct();
        session_start();

        $this->desei = $this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Content-Type: text/html; charset=utf-8");

        $uploadDir = "./userpic/";
        $allowedExtensions = [
            "jpg",
            "jpeg",
            "png",
            "gif",
        ];

        $images = array_values(
            array_filter(scandir($uploadDir), function ($image) use (
                $allowedExtensions,
                $uploadDir
            ) {
                $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
                return in_array($extension, $allowedExtensions) &&
                    is_file($uploadDir . $image);
            })
        );

        $this->renderGallery($images, $uploadDir);
    }

    private function renderGallery($images, $uploadDir)
    {
        ?>
		<!DOCTYPE html>
		<html lang="de">
		<head>
			<meta charset="UTF-8">
			<title>Galerie</title>

<?php
echo '<link href="styles/';

        if (is_array($this->desei) && !empty($this->desei)) {
            foreach ($this->desei as $data) {
                echo $data[1];
            }
        } else {
            echo "desei ist leer oder kein Array.";
        }

$this->dbObj->close();

echo '/style.css" rel="stylesheet" type="text/css">';
?>

			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta name="robots" content="noindex, nofollow">
			<script>
				if (window.top === window.self) { window.location.replace('./'); }

				function sendToChat(imageUrl) {
					var imgCode = "[img]" + imageUrl.trim() + "[/img]";
					var chatInput = window.parent.document.getElementById("message");
					var sendButton = window.parent.document.getElementById("link_sagen");
					if (chatInput && sendButton) {
						chatInput.value = chatInput.value ? chatInput.value + " " + imgCode : imgCode;
						sendButton.click();
						window.close();
					} else {
						alert("Fehler: Chat-Eingabe oder Senden-Button nicht gefunden.");
					}
				}
			</script>
		</head>
		<body id="body_id" ondragstart="return false" onselectstart="return false" style="cursor: default;">
			<div class="gallery">
				<?php if (count($images) === 0): ?>
					<p style="text-align: center; width: 100%;">Zurzeit keine Bilder in der Galerie.</p>
				<?php
        // Sortiere die $images nach Datum (neueste zuerst) // Neueste zuerst
        else: ?>
	<?php usort($images, function ($a, $b) use ($uploadDir) {
     $metaFileA = $uploadDir . $a . ".txt";
     $metaFileB = $uploadDir . $b . ".txt";

     $dateA = $dateB = 0;

     if (file_exists($metaFileA)) {
         $metaPartsA = explode("|", file_get_contents($metaFileA));
         if (isset($metaPartsA[1])) {
             $dateA = strtotime(trim($metaPartsA[1]));
         }
     }

     if (file_exists($metaFileB)) {
         $metaPartsB = explode("|", file_get_contents($metaFileB));
         if (isset($metaPartsB[1])) {
             $dateB = strtotime(trim($metaPartsB[1]));
         }
     }

     return $dateB <=> $dateA;
 }); ?>

<?php foreach ($images as $image): ?>
    <?php
    $metaFile = $uploadDir . $image . ".txt";
    $uploader = "Unbekannt";
    $datum = "";
    $IP = "";

    if (file_exists($metaFile)) {
        $meta = file_get_contents($metaFile);
        $metaParts = explode("|", $meta);

        if (count($metaParts) >= 1) {
            $uploader = trim($metaParts[0]);
        }
        if (count($metaParts) >= 2) {
            $datum = trim($metaParts[1]);
        }
        if (count($metaParts) >= 3) {
            $IP = trim($metaParts[2]);
        }
    }
    ?>
    <div class="image-container">
        <div class="meta">Bild gepostet von<br>
            <?php echo htmlspecialchars($uploader); ?><br>
            <?php echo htmlspecialchars($datum); ?><br>
        </div>
        <div class="image-wrapper">
            <img class="imgg" src="<?php echo $uploadDir . $image; ?>" alt="Bild">
        </div>
        <div class="bottom">
            <button class="button" onclick="sendToChat('<?php echo $uploadDir .
                $image; ?>')" title="Bild in den Chat posten">Bild posten</button>
        </div>
    </div>
<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</body>
		</html>
		<?php
    }
}