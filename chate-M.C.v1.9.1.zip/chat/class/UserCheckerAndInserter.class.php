<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
*/

class UserCheckerAndInserter extends EtChatConfig
{
    private $dbObj;

    protected $_user_exists;
    protected $_user;
    protected $_pw;
    protected $_gender;
    protected $_lang;

    public $status;

    private $guestAccessAllowed;
    private $adminAccessAllowed;

    public function __construct(
        $dbObj,
        $user_exists,
        $user,
        $pw,
        $gender,
        $lang
    ) {
        parent::__construct();

        $this->dbObj = $dbObj;
        $this->_user_exists = $user_exists;
        $this->_user = $user;
        $this->_pw = $pw;
        $this->_gender = $gender;
        $this->_lang = $lang;

        // Initialisierung der Session-basierten Steuerung
        $this->guestAccessAllowed = isset(
            $_SESSION["etchat_" . $this->_prefix . "gast_zugang"]
        )
            ? (int) $_SESSION["etchat_" . $this->_prefix . "gast_zugang"]
            : 0;

        $this->adminAccessAllowed = isset(
            $_SESSION["etchat_" . $this->_prefix . "wartung"]
        )
            ? (int) $_SESSION["etchat_" . $this->_prefix . "wartung"]
            : 1;

        if (!is_array($this->_user_exists)) {
            // Wartungsmodus: nur Admins dürfen rein (keine neuen User!)
            if ($this->adminAccessAllowed == 1) {
                echo "Der Chat ist im Wartungsmodus. Nur Administratoren haben Zugriff.";
                $this->status = "maintenance_denied";
                exit();
            }

            // Gästezugang prüfen
            if ($this->guestAccessAllowed == 0) {
                echo "Chatzugang fÃœr GÃ¤ste zur Zeit gesperrt. Bitte registrieren Sie sich zuerst.";
                $this->status = "guest_denied";
                exit();
            }

            $this->createNewUser();
            return;
        }

        // Wartungsmodus aktiv: Nur Admins dürfen rein
        if ($this->adminAccessAllowed == 1 && $this->_user_exists[0][3] !== "admin") {
            echo "Der Chat befindet sich im Wartungsmodus. Nur Administratoren haben derzeit Zugriff.";
            $this->status = "maintenance_denied";
            exit();
        }

        // Benutzer existiert, Loginversuch
        $this->dbObj->sqlSet("UPDATE {$this->_prefix}etchat_user SET etchat_usersex = '" . $this->_gender[0] . "', etchat_logintime = " . date("U") . " WHERE etchat_user_id = " . $this->_user_exists[0][0]);

        if ($this->_pw == "") {$this->userWithoutPw();
        } else {
            $this->userWithPw();
        }
    }

    private function createNewUser()
    {
        $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_user (etchat_username, etchat_usersex, etchat_logintime) VALUES ('" . $this->_user . "', '" . $this->_gender[0] . "', '" . date("U") . "')");
        $user_neu = $this->dbObj->sqlGet("SELECT etchat_user_id, etchat_username, etchat_userprivilegien FROM {$this->_prefix}etchat_user WHERE etchat_username = '" . $this->_user . "' LIMIT 1" );

        $_SESSION["etchat_" . $this->_prefix . "user_id"] = $user_neu[0][0];
        $_SESSION["etchat_" . $this->_prefix . "username"] = $user_neu[0][1];
        $_SESSION["etchat_" . $this->_prefix . "user_priv"] = $user_neu[0][2];
        $this->status = 1;
    }

    private function userWithPw()
    {
        if ($this->_user_exists[0][2] == md5($this->_pw)) {
            $_SESSION["etchat_" . $this->_prefix . "user_id"] = $this->_user_exists[0][0];
            $_SESSION["etchat_" . $this->_prefix . "username"] = $this->_user_exists[0][1];
            $_SESSION["etchat_" . $this->_prefix . "user_priv"] = $this->_user_exists[0][3];

            if (
                $_SESSION["etchat_" . $this->_prefix . "user_priv"] == "admin" ||
                $_SESSION["etchat_" . $this->_prefix . "user_priv"] == "mod"
            ) {
                setcookie("cookie_anzahl_logins_in_XX_sek", 1, ["samesite" => "lax",]);
            }

            $this->status = 1;
        } else {
            $this->status = $this->_lang->pw_falsch[0]->tagData;
        }
    }

    private function userWithoutPw()
    {
        if (!empty($this->_user_exists[0][2])) {
            $this->status =
                $this->_user_exists[0][3] == "admin" ? "pw+invisible" : "pw";
        } else {
            // Alte Gäste blockieren
            if ($this->_user_exists[0][3] == "gast" && $this->guestAccessAllowed == 0) {
                echo "Chatzugang fÃœr GÃ¤ste zur Zeit gesperrt. Bitte registrieren Sie sich zuerst.";
                $this->status = "guest_denied";
                exit();
            }

            $_SESSION["etchat_" . $this->_prefix . "user_id"] = $this->_user_exists[0][0];
            $_SESSION["etchat_" . $this->_prefix . "username"] = $this->_user_exists[0][1];
            $_SESSION["etchat_" . $this->_prefix . "user_priv"] = $this->_user_exists[0][3];

            if (
                $_SESSION["etchat_" . $this->_prefix . "user_priv"] == "admin" ||
                $_SESSION["etchat_" . $this->_prefix . "user_priv"] == "mod"
            ) {
                setcookie("cookie_anzahl_logins_in_XX_sek", 1, ["samesite" => "lax",]);
            }

            $this->status = 1;
        }
    }
}

