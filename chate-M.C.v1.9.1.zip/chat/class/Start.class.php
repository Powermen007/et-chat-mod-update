<?php

/*
 
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
 
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
 
*/

class ExternUserView3 extends DbConectionMaker
{
	public function __construct (){

		// call parent Constructor from class DbConectionMaker
		parent::__construct();

			$feld=$this->dbObj->sqlGet("SELECT id, menu, link_text, image_active, image, url, target, gewicht FROM {$this->_prefix}etchat_menu WHERE menu = 2 ORDER BY gewicht");
			$this->dbObj->close();

			if (is_array($feld)){

				foreach($feld as $datasets){
				if ($datasets[3] == 1) {
						echo "<a class=\"start_text\" href=\"".$datasets[5]."\" target=\"".$datasets[6]."\"><img height=\"55\" border=\"0\" alt=\"".$datasets[2]."\" longdesc=\"".$datasets[2]."\" title=\"".$datasets[2]."\" src=\"img/menu/".$datasets[4]."\" /></a>&nbsp;&nbsp;&nbsp;";
						}
					else{
					echo "<a class=\"start_text\" href=\"".$datasets[5]."\" target=\"".$datasets[6]."\">".$datasets[2]."</a>&nbsp;&nbsp;&nbsp;";
					}
				}
			}
	}
}
new ExternUserView3();

?>


