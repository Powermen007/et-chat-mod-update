<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)
Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).
*/

class wuerfel extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

    // Schutz vor Direktaufruf (nur echte AJAX-POSTs erlaubt)
    if (
        !isset($_SERVER['HTTP_X_REQUESTED_WITH']) ||
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest' ||
        !isset($_POST['username']) ||
        !isset($_POST['room'])
    ) {
		http_response_code(403);
		header('Content-Type: text/html; charset=utf-8');
		echo '<h1>403 Verboten</h1><p>Diese Aktion ist nicht erlaubt.</p>';
		exit;
    }

		session_start();

		header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('content-type: application/json; charset=utf-8');


		$anz = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");
		$anz1 = $anz[0][8];

	 	$Wuerfelauge=rand(1,$anz1);

	 	$user_color2 = $this->getUserColor($_SESSION['etchat_'.$this->_prefix.'user_priv']);

		$avatar = $this->dbObj->sqlGet("SELECT * FROM {$this->_prefix}etchat_user WHERE etchat_username = '".$_POST['username']."'");
		$userId = $avatar [0][0];
		$avatar1 = $avatar [0][7];

       $this->dbObj->sqlSet("INSERT INTO {$this->_prefix}etchat_messages ( etchat_user_fid , etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat, etchat_user_ip)
       VALUES ( ".$userId.", '<img src=img/redwuerfel.png width=16 height=16 \>\<img src=img/redwuerfel.png width=16 height=16 \>\<img src=img/redwuerfel.png width=16 height=16 \>&nbsp; würfelt eine ".$Wuerfelauge." &nbsp;\<img src=img/redwuerfel.png width=16 height=16 \>\<img src=img/redwuerfel.png width=16 height=16 \>\<img src=img/redwuerfel.png width=16 height=16 \>', 'color:#".$_SESSION['etchat_'.$this->_prefix.'syscolor'].";font-weight:bold;font-style:normal;', ".date('U').", ".(int)$_POST['room'].", 0, '".$_SERVER['REMOTE_ADDR']."')", false);

}
	private function getUserColor($priv) {
		switch($priv) {
			case 'admin': return "color: ".$_SESSION['etchat_'.$this->_prefix.'admin_color']."";
			case 'mod':	return "color: ".$_SESSION['etchat_'.$this->_prefix.'mod_color']."";
			case 'user': return "color: ".$_SESSION['etchat_'.$this->_prefix.'user_color']."";
			case 'gast': return "color: ".$_SESSION['etchat_'.$this->_prefix.'gast_color']."";
			default: return "color: #FFFFFF";
		}
	}
}
