<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

$GLOBALS["path"] = "./";

// Autoload für Klassen
spl_autoload_register(function($class_name) {
    require_once($GLOBALS["path"] . 'class/' . $class_name . '.class.php');
});

class Info extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        unset($GLOBALS["path"]);

        // PDO Prepared Statement – config abrufen
        $configId = 1; // fix für Info-Seite
        $config = $this->dbObj->sqlGet(
            "SELECT etchat_config_id, etchat_config_style 
             FROM {$this->_prefix}etchat_config 
             WHERE etchat_config_id = :id",
            ['id' => $configId]
        );

        $this->dbObj->close();

        $style = $config[0]['etchat_config_style'] ?? 'default';

        $this->render($style);
    }

    private function render(string $style): void
    {
        ?>
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Info</title>
            <link href="styles/<?= htmlspecialchars($style) ?>/style.css" rel="stylesheet" type="text/css"/>
            <meta name="robots" content="noindex,nofollow">
            <meta name="viewport" content="width=300">
        </head>
        <body id="body" style="margin-left: 20px;margin-right: 20px;">

        <br>
        <strong>
        ET-Chat_T-FISH-MOD basiert auf dem ET-Chat V3.0.7 Realease 3 und unterliegt daher auch der License vom ET-Chat!<br><br>

        ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski<br><br>
        </strong>

        Der ursprünglich von SEDesign entwickelte ET-Chat, der im Jahr 2019 aufgegeben wurde, wurde von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte) weiterentwickelt und modernisiert.<br><br>

        Ein wesentlicher Bestandteil der Überarbeitung war die Anpassung an PHP 8, da der ursprüngliche Code ab PHP 7.4 nicht mehr funktionierte.<br>
        Darüber hinaus wurde der Chat um zahlreiche zusätzliche Module und Funktionen erweitert, die nicht im ursprünglichen Standardpaket enthalten waren.<br><br>

        Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn), Harlekin (Bernd Witte).<br><br>
		
		Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)<br>
		PHP 8+ und PHP9 Ready, XML Parser, (SQL Optimierung)PDO Prepared Statements Get Set, Prototyp befreit (alte JS-Hilfsdateinen aus dem Jahr 2005 entfernt) und Sicherheit usw.<br><br>

        Mitwirkende:<br>
        <ul>
            <li><strong>Powermen (Christian K.):</strong> Modulentwicklung - Programmierung - Betreuung</li>
            <li><strong>Chrno (Herman):</strong> Modulentwicklung - Programmierung</li>
            <li><strong>Micha (Michael Krissel):</strong> Mod-Entwicklung</li>
            <li><strong>FizzyLemmon:</strong> Modulentwicklung - Programmierung</li>
            <li><strong>Svensken:</strong> Programmierung</li>
            <li><strong>Sascha:</strong> Codebereinigung</li>
        </ul>

        <br><br>
        Copyright Hinweis verwendeter Fremdcode:<br><br>
        <a href="https://github.com/PHPMailer/PHPMailer?tab=readme-ov-file" target="_blank">Copyright &#169; 2025 PHPMailer</a><br>
        <a href="https://codemirror.net/" target="_blank">Copyright &#169; 2025 CodeMirror</a><br>
        <a href="https://www.tiny.cloud/get-tiny/" target="_blank">Copyright &#169; 2024 TinyMCE</a><br>
		<a href="https://bgrins.github.io/spectrum/" target="_blank">Copyright &#169; Spectrum Colorpicker</a><br><br>

        <a href="mailto:et-chat-mod@abwesend.de">Anfragen per E-Mail</a><br><br>

        <a href="#kontakt" class="popup_link">Kontakt per Formular</a>
        <div class="popup" id="kontakt">
            <div class="popup_text">
                <iframe class="info" src="kontakt.php" title="Kontaktformular" 
                        style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"></iframe>
            </div>
            <a class="popup_close" href="#">X</a>
        </div>

        <br><br>
        <a href="https://et-chat-mod.42web.io/forum/" target="_blank">Forum & Download</a><br>

        </body>
        </html>
        <?php
    }
}

// Initialisieren
new Info();