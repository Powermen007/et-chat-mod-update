<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

$style = htmlspecialchars(
    $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'default',
    ENT_QUOTES,
    'UTF-8'
);

$csrf_token = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

if (!function_exists('e')) {
    function e(string $value): string {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title><?= e($pageTitle ?? 'Admin Bereich') ?></title>

	<link rel="stylesheet" href="styles/admin_tpl/admin.css">

 

    <?php if (!empty($extraHead)): ?>
        <?= $extraHead ?>
    <?php endif; ?>
</head>

<body id="adminbereich_body">

<?php if (empty($hideNav)): ?>
<nav>
    <a href="./?AdminIndex">&lt;&lt;&lt; zurück zum Adminmenü</a>
</nav>
<hr>
<?php endif; ?>

<main>

    <?php if (!empty($pageTitle)): ?>
        <h2><?= e($pageTitle) ?></h2>
    <?php endif; ?>

    <!-- ===== CONTENT SLOT ===== -->
    <?= $content ?? '' ?>

</main>

<hr>

<?php if (!empty($backLink)): ?>
    <a href="<?= e($backLink) ?>">&lt;&lt;&lt; zurück</a><br>
<?php endif; ?>

<?php if (!empty($footerNote)): ?>
    <small><?= $footerNote ?></small>
<?php endif; ?>
 
<?php if (!empty($backLink) || !empty($footerNote)): ?>
 <hr>
<?php endif; ?>

<?php if (!empty($extraScripts)) echo $extraScripts; ?>
</body>
</html>