
ALTER TABLE `etchat_useronline` ADD `etchat_session_id` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL AFTER `etchat_last_ping`;