<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

$GLOBALS["path"] = "./../";

spl_autoload_register(function($class_name) {
    require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class LinkRadioIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session starten, damit $_SESSION Werte verfügbar sind
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        unset($GLOBALS["path"]);

        // 🔄 ASSOZIATIVE INDIZES
        $config = $this->dbObj->sqlGet(
            "SELECT etchat_config_id, etchat_config_radio_name, etchat_config_style 
             FROM {$this->_prefix}etchat_config 
             WHERE etchat_config_id = '1'"
        );
        
        $radioData = $this->dbObj->sqlGet(
            "SELECT etchat_radio_id, etchat_radio_horst, etchat_radio_port, etchat_radio_typ, 
                    etchat_radio_stream, etchat_radio_name, etchat_radio_color, etchat_radio_bit, 
                    etchat_radio_box, etchat_radio_player, etchat_on_air, etchat_system_titel_an,
                    etchat_titel_an 
             FROM {$this->_prefix}etchat_radio_box 
             WHERE etchat_radio_id = '1'"
        );

        // Style und Radio-Name aus Config
        $style = $config[0]['etchat_config_style'] ?? 'etchat_dino_styles';
        $radioName = $config[0]['etchat_config_radio_name'] ?? 'Radio';

        // Radio-Daten extrahieren
        $stream1 = '';
        $radio_player = 0;
        
        if (!empty($radioData[0])) {
            $stream1 = $radioData[0]['etchat_radio_stream'] ?? '';
            $radio_player = $radioData[0]['etchat_radio_player'] ?? 0;
        }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="de" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link href="player.css" rel="stylesheet" type="text/css">
<link href="../styles/<?php echo htmlspecialchars($style); ?>/style.css" rel="stylesheet" type="text/css"/>

<title><?php echo htmlspecialchars($radioName); ?></title>
</head>
<body id="body">

<?php
if ($radio_player == '1') {
?>
<div class="player_play" id="player">
  <button id="playPauseBtn">&#9654;</button>
  <div class="title">
    <div class="scroll-text" id="streamTitle">Dr&uuml;cke Play...</div>
  </div>
<div class="time" id="timeDisplay">00:00</div>
  <div class="volume-container" id="volumeContainer">
    <button class="volume" id="muteBtn">&#128266;</button>
    <div class="volume-slider above" id="volumeSlider">
      <input type="range" id="volumeControl" min="0" max="1" step="0.01" value="0.1">
    </div>
  </div>
</div>

<audio id="audio" preload="none" data-stream="<?php echo htmlspecialchars($stream1); ?>"></audio>

<script src="player.js"></script>

<?php
    }
    $this->dbObj->close();
}
}

new LinkRadioIndex();
?>
</body>
</html>at Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

$GLOBALS["path"] = "./../";

spl_autoload_register(function($class_name) {
	require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});

class LinkRadioIndex extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		// Session starten, damit $_SESSION Werte verfügbar sind
		if (session_status() === PHP_SESSION_NONE) {
			session_start();
		}

		unset($GLOBALS["path"]);

		$desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_radio_name, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");
		$radio=$this->dbObj->sqlGet("SELECT etchat_radio_id , etchat_radio_horst, etchat_radio_port, etchat_radio_typ, etchat_radio_stream, etchat_radio_name, etchat_radio_color, etchat_radio_bit, etchat_radio_box, etchat_radio_player, etchat_on_air, etchat_system_titel_an,
		etchat_titel_an FROM {$this->_prefix}etchat_radio_box WHERE etchat_radio_id = '1'");
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="de" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link href="player.css" rel="stylesheet" type="text/css">
<?php
	if (is_array($desei)){
		foreach($desei as $data){
			echo "<link href=\"../styles/$data[2]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
		}
	}
	if (is_array($radio)){
		foreach($radio as $data_radio){
			$horst1 = $data_radio[1];
			$port1 = $data_radio[2];
			$pass1 = $data_radio[3];
			$stream1 = $data_radio[4];
			$rname1 = $data_radio[5];
			$rcolor1 = $data_radio[6];
			$rbit1 = $data_radio[7];
			$radio_box = $data_radio[8];
			$radio_player = $data_radio[9];
			$radio_on_air = $data_radio[10];
		}
	}
?>

<title><?php echo $data[1]; ?></title>
</head>
<body id="body">


<?php

if ($radio_player == '1') {
?>
<div class="player_play" id="player">
  <button id="playPauseBtn">&#9654;</button>
  <div class="title">
    <div class="scroll-text" id="streamTitle">Dr&uuml;cke Play...</div>
  </div>
<div class="time" id="timeDisplay">00:00</div>
  <div class="volume-container" id="volumeContainer">
    <button class="volume" id="muteBtn">&#128266;</button>
    <div class="volume-slider above" id="volumeSlider">
      <input type="range" id="volumeControl" min="0" max="1" step="0.01" value="0.1">
    </div>
  </div>
</div>

<audio id="audio" preload="none" data-stream="<?php echo htmlspecialchars($stream1); ?>"></audio>

<script src="player.js"></script>

<?php
 }
}}
new LinkRadioIndex();
?>
</body>
</html>