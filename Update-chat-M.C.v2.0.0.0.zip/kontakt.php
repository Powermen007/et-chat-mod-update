<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

// Fehlerausgabe für Debug (später wieder auskommentieren)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 1. Config laden (VOR session_start)
require_once __DIR__ . "/config.php";

// 2. Session starten (NACH config)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. Klassen laden
require_once __DIR__ . "/class/EtChatConfig.class.php";
require_once __DIR__ . "/class/ConnectDB.class.php";
require_once __DIR__ . "/class/DbConectionMaker.class.php";
require_once __DIR__ . "/class/Kontakt.class.php";

// 4. Style aus Session oder Fallback
$style = $_SESSION['etchat_' . $prefix . 'style'] ?? 'etchat_dino_styles';
$meldung = '';

// 5. Kontakt-Objekt mit Fehlerbehandlung
try {
    $kontakt = new Kontakt();
    $meldung = '';
} catch (Exception $e) {
    $meldung = "Kontaktfunktion ist vorübergehend nicht verfügbar: " . $e->getMessage();
    $kontakt = null;
}

// Formularverarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') == 1) {
    if ($kontakt) {
        try {
            $meldung = $kontakt->senden($_POST);
        } catch (Exception $e) {
            $meldung = "Fehler beim Senden: " . $e->getMessage();
        }
    } else {
        $meldung = "Kontaktfunktion ist nicht verfügbar.";
    }
}

// Felder aus DB laden – mit Fehlerbehandlung
$fields = [];
if ($kontakt && $kontakt->getDb()) {
    try {
        $fields = $kontakt->getDb()->sqlGet(
            "SELECT *
             FROM {$prefix}etchat_kontakt_fields
             WHERE etchat_visible = 1
             ORDER BY etchat_sort_order ASC"
        );
    } catch (Exception $e) {
        $meldung = "Datenbankfehler: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Kontakt</title>
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style.css" rel="stylesheet">
    <link href="styles/<?php echo htmlspecialchars($style); ?>/style-mobil-index.css" rel="stylesheet">
</head>
<body id="body">

<center><h2>Kontakt</h2></center>

<?php if ($meldung): ?>
    <div class="meldung" style="background: <?= strpos($meldung, 'Fehler') !== false || strpos($meldung, 'nicht verfügbar') !== false ? '#ff4c4c' : '#4caf50' ?>; color: white; padding: 10px; margin: 10px; border-radius: 5px;">
        <?= htmlspecialchars($meldung) ?>
    </div>
<?php endif; ?>

<?php if (!empty($fields)): ?>
<form method="POST" action="" class="bewerbung-form">
    <input type="hidden" name="action" value="1">
    <input type="hidden" name="https_ceck" value="">
    <input type="hidden" name="www" value="">

    Bitte f&uuml;llen Sie die mit <span class="pflichthinweis">*</span> gekennzeichneten Felder aus (Pflichtfelder).

<?php
foreach ($fields as $f) {
    $rawName = $f['etchat_field_name'] ?? '';
    $name = preg_replace('/[^a-zA-Z0-9_]/', '_', $rawName);
    $label = htmlspecialchars($rawName);
    $required = !empty($f['etchat_required']) ? 'required' : '';
    $pflichthinweis = !empty($f['etchat_required']) ? ' <span class="pflichthinweis">*</span>' : '';
    $type = $f['etchat_field_type'] ?? 'text';
    $value = $_POST[$name] ?? '';

    switch ($type) {
        case 'text':
        case 'email':
        case 'date':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<input type='{$type}' name='{$name}' id='{$name}' {$required} value='" . htmlspecialchars($value) . "'><br><br>";
            break;

        case 'textarea':
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<textarea name='{$name}' id='{$name}' {$required}>" . htmlspecialchars($value) . "</textarea><br><br>";
            break;

        case 'select':
            $options = json_decode($f['etchat_options'] ?? '', true) ?: [];
            echo "<label for='{$name}'>{$label}:{$pflichthinweis}</label>";
            echo "<select name='{$name}' id='{$name}' {$required}>";
            echo "<option value=''>Bitte ausw&auml;hlen:</option>";
            foreach ($options as $opt) {
                $sel = ($value == $opt) ? 'selected' : '';
                echo "<option value='" . htmlspecialchars($opt) . "' {$sel}>" . htmlspecialchars($opt) . "</option>";
            }
            echo "</select><br><br>";
            break;

        case 'checkbox':
            $options = json_decode($f['etchat_options'] ?? '', true) ?: [];
            echo "<label>{$label}:{$pflichthinweis}</label>";
            echo '<div class="musikrichtungen">';
            foreach ($options as $opt) {
                $chk = in_array($opt, (array)$value, true) ? 'checked' : '';
                echo '<div class="musikrichtung-option">';
                echo "<label><input type='checkbox' name='{$name}[]' value='" . htmlspecialchars($opt) . "' {$chk}> " . htmlspecialchars($opt) . "</label>";
                echo '</div>';
            }
            echo '</div><br><br>';
            break;
    }
}
?>

    <label for="web_php_de">Bitte geben Sie die Zeichen ein:<span class="pflichthinweis">*</span></label>
    <div class="captcha-group">
        <img src="captcha.php" alt="Captcha" onclick="this.src='captcha.php?'+Math.random();" title="Klicken zum Neuladen">
        <input type="text" name="web_php_de" id="web_php_de" maxlength="5" required>
    </div>

    <button type="submit">Anfrage senden</button>
</form>
<?php else: ?>
    <p style="text-align: center; color: red;">Das Kontaktformular ist aktuell nicht verfügbar. Bitte versuchen Sie es später erneut.</p>
<?php endif; ?>

</body>
</html>