<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ReloaderUserOnline extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();
        session_start();

        $this->handleStatusRestore();
        $this->sendHeaders();
        $this->processReloadSequence();

		$feld = $this->dbObj->sqlGet(
			"SELECT
				uo.etchat_user_online_user_name,
				uo.etchat_user_online_room_name,
				uo.etchat_fid_room,
				uo.etchat_onlineuser_fid,
				uo.etchat_onlineip,
				uo.etchat_user_online_user_priv,
				uo.etchat_user_online_room_goup,
				uo.etchat_user_online_user_sex,
				uo.etchat_user_online_user_status_img,
				uo.etchat_user_online_user_status_text,
				uo.etchat_avatar,
				u.etchat_reg_timestamp
			FROM {$this->_prefix}etchat_useronline uo
			LEFT JOIN {$this->_prefix}etchat_user u
				ON u.etchat_user_id = uo.etchat_onlineuser_fid
			ORDER BY uo.etchat_fid_room, uo.etchat_user_online_user_name"
		);

        $roomarray = $this->dbObj->sqlGet(
            "SELECT etchat_id_room, etchat_roomname, etchat_room_goup
             FROM {$this->_prefix}etchat_rooms
             WHERE etchat_id_room NOT IN (
                 SELECT DISTINCT etchat_fid_room FROM {$this->_prefix}etchat_useronline
             )"
        );

        if (!$feld) {
            $this->makeJsonOutput([], $roomarray);
        } else {
            // 🔥 NEU: Prüfen ob force_load gesetzt ist (nach F5)
            $forceLoad = isset($_POST['force_load']) && $_POST['force_load'] == '1';
            
            if ($forceLoad) {
                // Bei Force Load: Hash ignorieren, immer JSON senden
                $this->makeJsonOutput($feld, $roomarray);
            } else if (!$this->anyChangesSinceLastPolling($feld, $roomarray)) {
                $this->dbObj->close();
            } else {
                $this->makeJsonOutput($feld, $roomarray);
            }
        }
    }


    private function handleStatusRestore(): void
    {
        if (!isset($_SESSION['etchat_'.$this->_prefix.'user_id'])) {
            return;
        }

        $userID = (int)$_SESSION['etchat_'.$this->_prefix.'user_id'];

        $result = $this->dbObj->sqlGet(
            "SELECT etchat_user_online_user_status_img,
                    etchat_user_online_user_status_text
             FROM {$this->_prefix}etchat_useronline
             WHERE etchat_onlineuser_fid = :uid
             LIMIT 1",
            [':uid' => $userID]
        );

        if ($result && ($result[0]['etchat_user_online_user_status_img'] ?? '') === 'status_off') {

            $oldImg  = $_SESSION['etchat_'.$this->_prefix.'old_status_img']  ?? '';
            $oldText = $_SESSION['etchat_'.$this->_prefix.'old_status_text'] ?? '';

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_useronline
                 SET etchat_user_online_user_status_img = :img,
                     etchat_user_online_user_status_text = :txt
                 WHERE etchat_onlineuser_fid = :uid
                   AND etchat_user_online_user_status_img = 'status_off'",
                [
                    ':img' => $oldImg,
                    ':txt' => $oldText,
                    ':uid' => $userID
                ]
            );

            unset($_SESSION['etchat_'.$this->_prefix.'old_status_img']);
            unset($_SESSION['etchat_'.$this->_prefix.'old_status_text']);
        }
    }


    private function sendHeaders(): void
    {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: application/json; charset=utf-8');
    }


    private function processReloadSequence(): void
    {
        if (empty($_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'])) {
            return;
        }

        $interval = (int)$_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] / 1000;

        $grenzzeit1 = time() - ($interval * 8);
        $grenzzeit2 = time() - ($interval * 16);

        $userID = (int)($_SESSION['etchat_'.$this->_prefix.'user_id'] ?? 0);

        $statusRes = $this->dbObj->sqlGet(
            "SELECT etchat_user_online_user_status_img,
                    etchat_user_online_user_status_text
             FROM {$this->_prefix}etchat_useronline
             WHERE etchat_onlineuser_fid = :uid
               AND etchat_user_online_user_status_img != 'status_off'
             LIMIT 1",
            [':uid' => $userID]
        );

        if ($statusRes) {
            $_SESSION['etchat_'.$this->_prefix.'old_status_img'] = $statusRes[0]['etchat_user_online_user_status_img'] ?? '';
            $_SESSION['etchat_'.$this->_prefix.'old_status_text'] = $statusRes[0]['etchat_user_online_user_status_text'] ?? '';
        }

        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_useronline
             SET etchat_user_online_user_status_img = 'status_off',
                 etchat_user_online_user_status_text = 'Verbindung verloren'
             WHERE etchat_onlinetimestamp < :t1",
            [':t1' => $grenzzeit1]
        );

        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_useronline
             WHERE etchat_onlinetimestamp < :t2",
            [':t2' => $grenzzeit2]
        );
    }


    private function anyChangesSinceLastPolling($feld, $roomarray): bool
    {
        $rel = '';

        if (is_array($feld)) {
            foreach ($feld as $row) {
                if (is_array($row)) {
                    // 🔥 NUR die stabilen Felder für den Hash
                    $rel .= ($row['etchat_onlineuser_fid'] ?? '') . '|';
                    $rel .= ($row['etchat_user_online_user_name'] ?? '') . '|';
                    $rel .= ($row['etchat_fid_room'] ?? '') . '|';
                    $rel .= ($row['etchat_user_online_user_priv'] ?? '') . '|';
                    $rel .= ($row['etchat_user_online_user_status_img'] ?? '') . '|';
                    $rel .= ($row['etchat_avatar'] ?? '') . ';';
                }
            }
        }

        if (is_array($roomarray)) {
            foreach ($roomarray as $row) {
                if (is_array($row)) {
                    $rel .= implode('', $row);
                }
            }
        }

        $blockAll = $_SESSION['etchat_'.$this->_prefix.'block_all'] ?? [];
        if (is_array($blockAll) && !empty($blockAll)) {
            $rel .= implode('-', $blockAll);
        }

        $blockPriv = $_SESSION['etchat_'.$this->_prefix.'block_priv'] ?? [];
        if (is_array($blockPriv) && !empty($blockPriv)) {
            $rel .= implode('-', $blockPriv);
        }

        $roomPw = $_SESSION['etchat_'.$this->_prefix.'roompw_array'] ?? [];
        if (is_array($roomPw) && !empty($roomPw)) {
            $rel .= implode('-', $roomPw);
        }

        // 🔥 NEU: Hash des gesamten Strings berechnen
        $currentHash = crc32($rel);
        
        $savedHash = $_SESSION['etchat_'.$this->_prefix.'reload_user_hash'] ?? '';
        
        if ($savedHash === $currentHash) {
            return false;  // Keine Änderung
        }

        $_SESSION['etchat_'.$this->_prefix.'reload_user_hash'] = $currentHash;
        return true;  // Hat sich geändert
    }


    private function makeJsonOutput($feld, $roomarray): void
    {
        $data = [
            'userOnline' => [],
            'all_empty_rooms' => []
        ];

        if (is_array($feld)) {

            foreach ($feld as $row) {
                // 🔄 ASSOZIATIVE INDIZES
                $user_id = (int)($row['etchat_onlineuser_fid'] ?? 0);
                $user_name = $row['etchat_user_online_user_name'] ?? '';
                $room_goup = $row['etchat_user_online_room_goup'] ?? 0;
                $fid_room = $row['etchat_fid_room'] ?? 0;
                $user_priv = $row['etchat_user_online_user_priv'] ?? '';
                $user_sex = $row['etchat_user_online_user_sex'] ?? '';
                $status_img = $row['etchat_user_online_user_status_img'] ?? '';
                $status_text = $row['etchat_user_online_user_status_text'] ?? '';
                $room_name = $row['etchat_user_online_room_name'] ?? '';
                $user_ip = $row['etchat_onlineip'] ?? '';
                $avatar = $row['etchat_avatar'] ?? '';

				// 🔥 Direkt aus dem JOIN-Ergebnis
				$timestamp = 0;
				if (!empty($row['etchat_reg_timestamp'])) {
					$timestamp = strtotime($row['etchat_reg_timestamp']);
				}

                $blockAll = $_SESSION['etchat_'.$this->_prefix.'block_all'] ?? [];
                $display_name = $user_name;
                
                if (is_array($blockAll) && in_array($user_id, $blockAll, true)) {
                    $display_name = '<strike>'.$user_name;
                }

                $blockPriv = $_SESSION['etchat_'.$this->_prefix.'block_priv'] ?? [];
                if (is_array($blockPriv) && in_array($user_id, $blockPriv, true)) {
                    $display_name = '<strike>'.$user_name;
                }

                $room_allowed = new RoomAllowed($room_goup, $fid_room);

                if (isset($_SESSION['etchat_'.$this->_prefix.'user_id']) &&
                    $_SESSION['etchat_'.$this->_prefix.'user_id'] == $user_id) {
                    $_SESSION['etchat_'.$this->_prefix.'userstatus'] = $status_img;
                }

                $data['userOnline'][] = [
                    'user'            => $display_name,
                    'user_id'         => $user_id,
                    'user_priv'       => $user_priv,
                    'user_sex'        => $user_sex,
                    'user_simg'       => $status_img,
                    'user_stext'      => $status_text,
                    'room_id'         => $fid_room,
                    'room_allowed'    => $room_allowed->room_status,
                    'room'            => $room_name,
                    'reg_timestamp'   => $timestamp,
                    'etchat_avatar'   => $avatar,
                    'user_ip'         => addslashes(str_replace("@", " - ", $user_ip))
                ];
            }
        }

        if (is_array($roomarray)) {

            foreach ($roomarray as $row) {
                // 🔄 ASSOZIATIVE INDIZES
                $room_id = $row['etchat_id_room'] ?? 0;
                $room_goup = $row['etchat_room_goup'] ?? 0;
                $room_name = $row['etchat_roomname'] ?? '';

                $room_allowed2 = new RoomAllowed($room_goup, $room_id);

                $data['all_empty_rooms'][] = [
                    'room_id' => $room_id,
                    'room_allowed' => $room_allowed2->room_status,
                    'room' => $room_name
                ];
            }
        }

        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    }
}