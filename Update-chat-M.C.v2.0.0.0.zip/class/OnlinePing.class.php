﻿<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class OnlinePing extends DbConectionMaker
{
    private ?string $cachedSystemColor = null;
    private ?array $cachedPrivColors   = null;

    public function __construct()
    {
        parent::__construct();

        $this->handlePing();
    }

    private function handlePing(): void
    {
        $userId = (int)($_POST['user_id'] ?? $_GET['user_id'] ?? 0);

        if ($userId <= 0) {
            return;
        }

        $prefix = $this->_prefix;

        // ✅ SICHER MIT PREPARED STATEMENT
        $this->dbObj->sqlSet("
            UPDATE {$prefix}etchat_useronline
            SET etchat_last_ping = NOW()
            WHERE etchat_onlineuser_fid = :user_id
        ", [':user_id' => $userId]);

        $this->checkOfflineUsers();
    }

    private function checkOfflineUsers(): void
    {
        $timeout = 60;
        $prefix  = $this->_prefix;

        // ✅ SICHER MIT PREPARED STATEMENT
        $offlineUsers = $this->dbObj->sqlGet("
            SELECT
                uo.etchat_onlineuser_fid AS user_id,
                uo.etchat_avatar AS online_avatar,
                uo.etchat_session_id AS session_id,
                u.etchat_username,
                u.etchat_userprivilegien,
                u.etchat_avatar AS user_avatar
            FROM {$prefix}etchat_useronline uo
            JOIN {$prefix}etchat_user u
                ON u.etchat_user_id = uo.etchat_onlineuser_fid
            WHERE TIMESTAMPDIFF(SECOND, uo.etchat_last_ping, NOW()) > :timeout
        ", [':timeout' => $timeout]);

        if (!$offlineUsers) {
            return;
        }

        // Farben aus Session oder DB holen (nicht aus CSS-Dateien)
        $sysColor = $this->getSystemColor();
        $privColors = $this->getAllPrivColors();

        foreach ($offlineUsers as $u) {
            $userId = (int)$u['user_id'];
            $sessionId = $u['session_id'] ?? null;
            
            if (!empty($sessionId)) {
                $this->destroyUserSession($sessionId);
            }
            
            $name = htmlspecialchars($u['etchat_username'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            $priv = $u['etchat_userprivilegien'] ?? 'user';
            $nameColor = $privColors[$priv] ?? 'color:#fff';

            $avatarFile = $u['online_avatar'] ?: $u['user_avatar'] ?: 'noavatar.jpg';
            $avatarPath = 'avatar/' . basename($avatarFile);

            $avatar = sprintf(
                '<img src="%s" class="avatar_w">',
                htmlspecialchars($avatarPath, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
            );

            $msg = $avatar .
                '<span style="' . $sysColor . '">' .
                '<span style="' . $nameColor . '"><b>' . $name . '</b></span>' .
                ' hat den Tab/Browser geschlossen.' .
                '</span>';

            new SysMessage($this->dbObj, $msg, 0, 0);

            // ✅ SICHER MIT PREPARED STATEMENT
            $this->dbObj->sqlSet("
                DELETE FROM {$prefix}etchat_useronline
                WHERE etchat_onlineuser_fid = :user_id
            ", [':user_id' => $userId]);
        }
    }

    private function destroyUserSession(string $sessionId): void
    {
        $sessionSavePath = session_save_path();
        if (empty($sessionSavePath)) {
            $sessionSavePath = ini_get('session.save_path');
        }
        
        if (empty($sessionSavePath)) {
            $sessionSavePath = sys_get_temp_dir();
        }
        
        $sessionFile = rtrim($sessionSavePath, '/') . '/sess_' . $sessionId;
        if (file_exists($sessionFile)) {
            @unlink($sessionFile);
        }
    }

    /* ==============================
       🔹 SYSTEMFARBE (aus Session/DB)
    ============================== */
    private function getSystemColor(): string
    {
        if ($this->cachedSystemColor !== null) {
            return $this->cachedSystemColor;
        }

        // Versuche zuerst aus der Session
        $sysColor = $_SESSION['etchat_' . $this->_prefix . 'syscolor'] ?? null;
        if ($sysColor) {
            return $this->cachedSystemColor = 'color:#' . ltrim($sysColor, '#');
        }

        // Fallback: Aus der Config-Datenbank
        $prefix = $this->_prefix;
        $config = $this->dbObj->sqlGet("
            SELECT etchat_config_style
            FROM {$prefix}etchat_config
            LIMIT 1
        ");

        // Standard-Farbe
        return $this->cachedSystemColor = 'color:#00ff02';
    }

    /* ==============================
       🔹 PRIVILEG-FARBEN (aus DB)
    ============================== */
    private function getAllPrivColors(): array
    {
        if ($this->cachedPrivColors !== null) {
            return $this->cachedPrivColors;
        }

        $prefix = $this->_prefix;

        $cfg = $this->dbObj->sqlGet("
            SELECT
                etchat_config_admin_color,
                etchat_config_mod_color,
                etchat_config_user_color,
                etchat_config_gast_color
            FROM {$prefix}etchat_config
            LIMIT 1
        ");

        if (!$cfg || empty($cfg[0])) {
            return $this->cachedPrivColors = [
                'admin' => 'color:#ff0000',
                'mod' => 'color:#00aaff',
                'user' => 'color:#cccccc',
                'gast' => 'color:#ffff00'
            ];
        }

        $row = $cfg[0];

        return $this->cachedPrivColors = [
            'admin' => $this->formatColor($row['etchat_config_admin_color'] ?? '#ff0000'),
            'mod'   => $this->formatColor($row['etchat_config_mod_color'] ?? '#00aaff'),
            'user'  => $this->formatColor($row['etchat_config_user_color'] ?? '#cccccc'),
            'gast'  => $this->formatColor($row['etchat_config_gast_color'] ?? '#ffff00'),
        ];
    }

    private function formatColor(string $color): string
    {
        if (empty($color)) {
            return 'color:#ffffff';
        }
        $color = ltrim($color, '#');
        return 'color:#' . strtolower($color);
    }
}