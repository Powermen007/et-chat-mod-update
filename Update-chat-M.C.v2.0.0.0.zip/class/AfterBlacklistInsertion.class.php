<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class AfterBlacklistInsertion extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        $this->configTabData2Session();

        $this->dbObj->close();

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->blacklist[0] ?? null;

        $this->initTemplate($lang);
    }

    private function initTemplate($lang): void
    {
        // 🔄 Fallback 'default' entfernt
        $style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'etchat_dino_styles';

        $template = "styles/" . $style . "/blacklisted.tpl.html";

        if (file_exists($template)) {
            include_once($template);
        }
    }
}