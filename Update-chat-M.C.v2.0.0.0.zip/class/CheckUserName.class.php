<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class CheckUserName extends DbConectionMaker
{
    public object $lang;
    protected bool $user_application;
    protected string $username = '';
    protected string $gender = 'n';

    // ========== VALIDIERUNGSMETHODEN ==========
    private function validateUsernameFormat(string $username): bool {
        if (preg_match('/^[\p{L}\p{N}\s&@\._\-+=#~€$%§]+$/u', $username) !== 1) {
            return false;
        }
    
        if (preg_match_all('/[&@\._\-+=#~€$%§]/u', $username, $matches) > 3) {
            return false;
        }
    
        return true;
    }

    private function hasDangerousPatterns(string $username): bool {
        $dangerous = [
            '../', '..\\', './', '.\\',
            '<!--', '-->', '<script', '</script',
            '<?php', '?>', '<%', '%>',
            'javascript:', 'vbscript:', 'onclick=', 'onload=',
            'union select', 'or 1=1', 'drop table', 'delete from',
            '--', '/*', '*/', ';--', "' or '", '" or "'
        ];
        
        $lowerUser = strtolower($username);
        foreach ($dangerous as $pattern) {
            if (str_contains($lowerUser, strtolower($pattern))) {
                return true;
            }
        }
        return false;
    }

    private function loadBannedWordsFromJson(): array {
        $jsonFile = dirname(__DIR__) . '/cache/verbotene_user_namen.json';
        
        if (!file_exists($jsonFile)) {
            return [];
        }
        
        $content = file_get_contents($jsonFile);
        $words = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($words)) {
            return [];
        }
        
        return $words;
    }

    private function isUsernameAllowed(string $username, array $bannedWords): bool {
        $usernameNorm = mb_strtolower($username, 'UTF-8');
        
        foreach ($bannedWords as $banned) {
            if (empty(trim($banned))) {
                continue;
            }
            
            $bannedNorm = mb_strtolower($banned, 'UTF-8');
            
            if ($usernameNorm === $bannedNorm) {
                return false;
            }
            
            if (mb_strpos($usernameNorm, $bannedNorm, 0, 'UTF-8') !== false) {
                return false;
            }
        }
        return true;
    }
    // ========== ENDE VALIDIERUNGSMETHODEN ==========

    public function __construct(bool $user_application = false, string $username = '', string $gender = '')
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
            if (!$user_application) {
                header('Content-Type: application/json; charset=utf-8');
            }
        }

        $this->user_application = $user_application;

        if (!$user_application) {
            $this->username = trim($_POST['username'] ?? '');
            $this->gender = trim($_POST['gender'] ?? 'n');
        } else {
            $this->username = $username;
            $this->gender = $gender ?: 'n';
        }

        if ($user_application) {
            $this->configTabData2Session();

            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_messages WHERE etchat_timestamp < ?", [
                time() - (($_SESSION['etchat_'.$this->_prefix.'loeschen_nach'] ?? 0) * 3600 * 24)
            ]);

            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_blacklist WHERE etchat_blacklist_time < ?", [time()]);
            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_kick_user WHERE etchat_kicked_user_time < ?", [time()]);
            $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_user 
                                  WHERE etchat_userprivilegien = 'gast' 
                                  AND etchat_logintime < ?", 
                                  [time() - (($_SESSION['etchat_'.$this->_prefix.'loeschen_nach'] ?? 0) * 3600 * 24 * 2)]);
        }

        if (!$user_application && !isset($_COOKIE[$this->_prefix.'cookie_test'])) {
            $this->errorMessage("Please activate your cookies.");
            return;
        }

        if (!$user_application) {
            $setCheckKey = $_SESSION[$this->_prefix.'set_check'] ?? null;
            if (!$setCheckKey || !isset($_POST[$setCheckKey])) {
                $this->errorMessage("no hacks and bots");
                return;
            }
        }

        $langObj = new LangXml();
        $this->lang = $langObj->getLang()->checkusername_php[0];

        if (!$user_application && !$this->loginCounter()) {
            return;
        }

        $this->loadColorsFromSession();

        $blackListObj = new Blacklist($this->dbObj);
        if ($blackListObj->userInBlacklist()) {
            setcookie("cookie_anzahl_logins_in_XX_sek", 1, ["samesite" => "lax", "httponly" => true]);
            if (!$user_application) $this->errorMessage("blacklist");
            $blackListObj->killUserSession();
            if ($user_application) header('Location: ./?AfterBlacklistInsertion');
            return;
        }

        $reloadSeq = $_SESSION['etchat_'.$this->_prefix.'config_reloadsequenz'] ?? 1000;
        $this->dbObj->sqlSet("DELETE FROM {$this->_prefix}etchat_useronline WHERE etchat_onlinetimestamp < ?", [
            time() - ($reloadSeq / 1000 * 4)
        ]);

        // ========== USERNAME-VALIDIERUNG ==========
        if (empty($this->username) || strlen($this->username) > 100) {
            $this->errorMessage("invalid username");
            return;
        }
        
        if (strlen($this->username) < 4 || strlen($this->username) > 25) {
            $this->errorMessage("Der Benutzername muss zwischen 4 und 25 Zeichen lang sein.");
            return;
        }
        
        if (!$this->validateUsernameFormat($this->username)) {
            $this->errorMessage("Der Benutzername enthält nicht erlaubte Zeichen ODER mehr als 3 Sonderzeichen.");
            return;
        }
        
        if ($this->hasDangerousPatterns($this->username)) {
            $this->errorMessage("Der Benutzername enthält ungültige Zeichenkombinationen.");
            return;
        }
        
        $bannedWords = $this->loadBannedWordsFromJson();
        if (!$this->isUsernameAllowed($this->username, $bannedWords)) {
            $this->errorMessage("Dieser Benutzername ist nicht erlaubt. Bitte wähle einen anderen Namen.");
            return;
        }
        
        if (preg_match('/^[\s&@\._\-+=#~€$%§]+$/u', $this->username)) {
            $this->errorMessage("Der Benutzername muss mindestens einen Buchstaben oder eine Zahl enthalten.");
            return;
        }
        
        $this->username = htmlspecialchars(str_replace("\\", "/", preg_replace('/[\x00-\x1F\x90\x8F\x81\xA0\x9D]/', '', $this->username)), ENT_QUOTES, "UTF-8");

        if (!$user_application && $this->userInChatNow($this->username)) {
            $this->errorMessage($this->lang->name_busy[0]->tagData ?? "Benutzername bereits vergeben");
            return;
        }

		$user_exists = $this->dbObj->sqlGet(
			"SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien, etchat_avatar
			FROM {$this->_prefix}etchat_user 
			WHERE etchat_username = :username 
			ORDER BY etchat_userpw DESC",
			[':username' => $this->username]
		);

        $pw = $_POST['pw'] ?? '';
        $userCheckerAndInserterObj = new UserCheckerAndInserter(
            $this->dbObj,
            $user_exists,
            $this->username,
            $pw,
            preg_replace("/[^a-z]/i", "n", $this->gender),
            $this->lang
        );

        if ($userCheckerAndInserterObj->status == 1) {
            $this->messageOnEnter();
        } else {
            $this->errorMessage($userCheckerAndInserterObj->status);
        }
    }

    private function loadColorsFromSession(): void
    {
        $textcolor = $_SESSION['etchat_' . $this->_prefix . 'textcolor'] ?? null;
        $syscolor = $_SESSION['etchat_' . $this->_prefix . 'syscolor'] ?? null;
        
        if ($textcolor === null || $syscolor === null) {
            $config = $this->dbObj->sqlGet(
                "SELECT etchat_config_style 
                 FROM {$this->_prefix}etchat_config 
                 WHERE etchat_config_id = 1 
                 LIMIT 1"
            );
            
            if ($textcolor === null) {
                $textcolor = 'ffffff';
                $_SESSION['etchat_' . $this->_prefix . 'textcolor'] = $textcolor;
            }
            if ($syscolor === null) {
                $syscolor = '00ff02';
                $_SESSION['etchat_' . $this->_prefix . 'syscolor'] = $syscolor;
            }
        }
    }

    private function loginCounter(): bool
    {
        $cookieLast = $_COOKIE['cookie_last_login'] ?? null;
        $cookieCount = (int)($_COOKIE['cookie_anzahl_logins_in_XX_sek'] ?? 0);

        if ($cookieLast === null) {
            setcookie("cookie_last_login", time(), ["samesite" => "lax", "httponly" => true]);
            setcookie("cookie_anzahl_logins_in_XX_sek", 1, ["samesite" => "lax", "httponly" => true]);
            return true;
        }

        if (time() - (int)$cookieLast < 180) {
            $cookieCount++;
            setcookie("cookie_anzahl_logins_in_XX_sek", $cookieCount, ["samesite" => "lax", "httponly" => true]);
            if ($cookieCount > ($this->_limit_logins_in_three_minutes - 1)) {
                setcookie("cookie_last_login", time(), ["samesite" => "lax", "httponly" => true]);
                $this->errorMessage($this->lang->many_logins[0]->tagData ?? "Zu viele Login-Versuche");
                return false;
            }
            return true;
        }

        setcookie("cookie_last_login", time(), ["samesite" => "lax", "httponly" => true]);
        setcookie("cookie_anzahl_logins_in_XX_sek", 1, ["samesite" => "lax", "httponly" => true]);
        return true;
    }

    private function userInChatNow(string $user): bool
    {
        $res = $this->dbObj->sqlGet(
            "SELECT etchat_username 
             FROM {$this->_prefix}etchat_useronline uo
             JOIN {$this->_prefix}etchat_user u ON u.etchat_user_id = uo.etchat_onlineuser_fid
             WHERE u.etchat_username = :username
             LIMIT 1",
            [':username' => $user]
        );
        
        if (is_array($res) && count($res) > 0) {
            setcookie("cookie_anzahl_logins_in_XX_sek", 1, ["samesite" => "lax", "httponly" => true]);
            return true;
        }
        return false;
    }

    private function errorMessage(string $message): bool
    {
        echo $message;
        $this->dbObj->close();
        return false;
    }

    private function messageOnEnter(): bool
    {
        new RoomEntrance($this->dbObj, $this->lang);
        unset($_SESSION[$this->_prefix.'set_check']);
        $this->dbObj->close();

        if (!$this->user_application) {
            echo "1";
        } else {
            header('Location: ./?Chat');
        }

        return true;
    }
}
?>