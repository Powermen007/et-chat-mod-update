<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ConnectDB extends EtChatConfig
{
    protected ?PDO $_connid = null;
    public int $lastId = 0;

    public function __construct()
    {
        parent::__construct();

        try {
            $dsn = "{$this->_usedDatabase}:host={$this->_sqlhost};dbname={$this->_database};charset=utf8mb4";

            $this->_connid = new PDO(
                $dsn,
                $this->_sqluser,
                $this->_sqlpass,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );

        } catch (PDOException $e) {
            // Einfacher Hinweis auf Fehler, keine sensiblen Infos
            echo "Datenbankverbindung fehlgeschlagen.";
            exit;
        }
    }

    /**
     * Führt ein SELECT-Statement aus und liefert das Ergebnis als Array.
     */
    public function sqlGet(string $sql, array $params = []): array|false
    {
        if ($sql === '') return false;

        try {
            $stmt = $this->_connid->prepare($sql);
            $stmt->execute($params);

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $result ?: false;

        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Führt ein INSERT/UPDATE/DELETE Statement aus.
     */
    public function sqlSet(string $sql, array $params = []): bool|int
    {
        try {
            $stmt = $this->_connid->prepare($sql);
            $stmt->execute($params);

            $this->lastId = (int)$this->_connid->lastInsertId();

            return $stmt->rowCount(); // Anzahl betroffener Zeilen

        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Liefert die PDO-Instanz direkt
     */
    public function getConnection(): ?PDO
    {
        return $this->_connid;
    }

    /**
     * Schließt die Verbindung
     */
    public function close(): void
    {
        $this->_connid = null;
    }
}