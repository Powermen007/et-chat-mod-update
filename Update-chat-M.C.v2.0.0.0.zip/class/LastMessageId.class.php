<?php
/**
 * LastMessageId.class.php
 * Gibt nur die letzte Message-ID zurück - SEHR LEICHTE Abfrage
 */

class LastMessageId extends DbConectionMaker
{
    private $roomId = 1;
    
    public function __construct($roomId = 1)
    {
        parent::__construct();
        $this->roomId = (int)$roomId;
    }
    
    public function getLastMessageId(): string
    {
        $result = $this->dbObj->sqlGet("
            SELECT MAX(etchat_id) as last_id 
            FROM {$this->_prefix}etchat_messages 
            WHERE etchat_fid_room = " . (int)$this->roomId . "
        ");
        
        if (is_array($result) && !empty($result) && isset($result[0]['last_id'])) {
            return (string)$result[0]['last_id'];
        }
        return '0';
    }
    
    public function render(): void
    {
        header('Content-Type: text/plain');
        header('Cache-Control: no-cache, must-revalidate');
        echo $this->getLastMessageId();
    }
}

// Aufruf
$roomId = isset($_GET['room']) ? (int)$_GET['room'] : 1;
$lastMessageId = new LastMessageId($roomId);
$lastMessageId->render();
?>