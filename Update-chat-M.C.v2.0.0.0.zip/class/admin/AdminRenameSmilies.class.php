<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRenameSmilies extends ConnectDB
{
    private array $request = [];
    private string $csrfToken = '';
    private array $smileyData = [];
    private array $categories = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // GET + POST unified
        $this->request = array_merge($_GET, $_POST);

        // CSRF Token
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0] ?? null;

        // Rechte prüfen
        if (!$this->isAllowed()) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // CSRF prüfen (nur bei POST!)
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->checkCsrf()) {
                echo "Ungültiger CSRF Token";
                return;
            }
        }

        // ID absichern
        $id = (int)($this->request['id'] ?? 0);
        if ($id <= 0) {
            echo "Ungültige ID";
            return;
        }

        // Smiley-Daten laden (mit sqlGet)
        $result = $this->sqlGet(
            "SELECT * FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_id = :id",
            [':id' => $id]
        );
        
        // Konvertiere numerisches Array in assoziatives Array
        if (is_array($result) && !empty($result)) {
            $row = $result[0];
            
            // Wenn es ein numerisches Array ist (0=>id, 1=>kat, 2=>sign, 3=>img, 4=>gewicht)
            if (isset($row[0]) && !isset($row['etchat_smileys_id'])) {
                $this->smileyData = [
                    'etchat_smileys_id' => $row[0] ?? 0,
                    'etchat_smileys_kat' => $row[1] ?? '',
                    'etchat_smileys_sign' => $row[2] ?? '',
                    'etchat_smileys_img' => $row[3] ?? '',
                    'etchat_smileys_gewicht' => $row[4] ?? 0
                ];
            } else {
                // Bereits assoziativ
                $this->smileyData = $row;
            }
        }
        
        if (empty($this->smileyData)) {
            echo "Smiley nicht gefunden";
            return;
        }

        // Kategorien laden
        $catsResult = $this->sqlGet("SELECT * FROM {$this->_prefix}etchat_smileys_cat");
        $this->categories = is_array($catsResult) ? $catsResult : [];

        $this->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    /**
     * Prüft die Benutzerberechtigung
     */
    private function isAllowed(): bool
    {
        $allowedRoles = ["admin", "co_admin", "grafik"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        
        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }
        
        return true;
    }

    /**
     * Prüft den CSRF-Token
     */
    private function checkCsrf(): bool
    {
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $token = $this->request['csrf_token'] ?? '';
        $sessionToken = $_SESSION[$csrfKey] ?? '';
        
        return $token !== '' && hash_equals($sessionToken, $token);
    }

    /**
     * Rendert das Template
     */
private function renderTemplate(?object $lang): void
{
    // Template-Variablen
    $feld = $this->smileyData;
    $cats = $this->categories;
    
    include_once("styles/admin_tpl/renameSmilies.tpl.html");
}
}