<?php

declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminRegUserIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private int $total = 0;
    private array $users = [];
    private string $currentSort = 'login_new';
    private string $currentSearch = '';
    private int $currentPage = 1;

    private array $allowedSorts = [
        'name'      => 'etchat_username ASC',
        'reg_new'   => 'etchat_reg_timestamp DESC',
        'reg_old'   => 'etchat_reg_timestamp ASC',
        'login_new' => 'etchat_logintime DESC',
        'login_old' => 'etchat_logintime ASC',
    ];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_reg_user[0] ?? null;

        // ROLE CHECK
        $allowedRoles = ["admin", "co_admin", "chatwache", "grafik"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Parameter laden
        $this->loadParams();

        // Gesamtanzahl laden
        $this->loadTotal();

        // User laden
        $this->loadUsers();

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    private function loadParams(): void
    {
        $this->currentSort = $_GET['sort'] ?? 'login_new';
        if (!isset($this->allowedSorts[$this->currentSort])) {
            $this->currentSort = 'login_new';
        }

        $this->currentSearch = trim($_GET['search'] ?? '');
        $this->currentPage = max(1, (int)($_GET['site'] ?? 1));
    }

    private function loadTotal(): void
    {
        $params = [];
        $searchSql = '';

        if ($this->currentSearch !== '') {
            $searchSql = "AND etchat_username LIKE :search";
            $params[':search'] = '%' . $this->currentSearch . '%';
        }

        $sql = "SELECT COUNT(etchat_user_id) AS cnt 
                FROM {$this->_prefix}etchat_user 
                WHERE etchat_userprivilegien='user' $searchSql";

        $result = $this->dbObj->sqlGet($sql, $params);
        $this->total = (int)($result[0]['cnt'] ?? 0);
    }

    private function loadUsers(): void
    {
        $perPage = 10;
        $offset = ($this->currentPage - 1) * $perPage;

        $params = [];
        $searchSql = '';

        if ($this->currentSearch !== '') {
            $searchSql = "AND etchat_username LIKE :search";
            $params[':search'] = '%' . $this->currentSearch . '%';
        }

        $orderBy = $this->allowedSorts[$this->currentSort];

        $sql = "SELECT etchat_user_id, etchat_username, etchat_userprivilegien,
                       etchat_reg_timestamp, etchat_reg_ip,
                       etchat_logintime, etchat_avatar,
                       etchat_email, etchat_last_ip
                FROM {$this->_prefix}etchat_user
                WHERE etchat_userprivilegien='user'
                $searchSql
                ORDER BY $orderBy
                LIMIT {$offset}, {$perPage}";

        $result = $this->dbObj->sqlGet($sql, $params);
        $this->users = is_array($result) ? $result : [];
    }

    private function renderTemplate(?object $lang): void
    {
        $print_sort_form = $this->buildSortForm();
        $print_sitemaker = $this->buildPagination($lang);
        $print_user_table = $this->buildUserTable();
        $print_user_extra = $this->buildInactiveForm();
        $total = $this->total;
        $csrfToken = $this->csrfToken;

        include "styles/admin_tpl/indexRegUser.tpl.html";
    }

    private function buildSortForm(): string
    {
        $sortOptions = [
            'name' => 'Name',
            'reg_new' => 'Registriert neu',
            'reg_old' => 'Registriert alt',
            'login_new' => 'Login neu',
            'login_old' => 'Login alt'
        ];

        $html = '<form method="get" action="./">
            <input type="hidden" name="AdminRegUserIndex" value="1">
            <label><b>Sortieren:</b>
            <select name="sort" onchange="this.form.submit()">';

        foreach ($sortOptions as $key => $label) {
            $selected = ($this->currentSort === $key) ? 'selected' : '';
            $html .= "<option value=\"{$key}\" {$selected}>" . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . "</option>";
        }

        $searchEscaped = htmlspecialchars($this->currentSearch, ENT_QUOTES, 'UTF-8');

        $html .= '</select>
            <b>Suche:</b></label>
            <input type="text" name="search" value="' . $searchEscaped . '">
            <input type="submit" value="🔍 Suchen">
            <button type="button" onclick="window.location.href=\'./?AdminRegUserIndex=1\'">🔄 Reset</button>
        </form>';

        return $html;
    }

    private function buildPagination(?object $lang): string
    {
        $perPage = 10;
        $totalPages = max(1, (int)ceil($this->total / $perPage));

        if ($totalPages <= 1) {
            return '';
        }

        $html = '<div class="pagination">';
        
        if ($this->currentPage > 1) {
            $url = $this->buildPaginationUrl($this->currentPage - 1);
            $html .= '<a href="' . $url . '">« Vorherige</a> ';
        }

        $html .= '<span>Seite ' . $this->currentPage . ' von ' . $totalPages . '</span> ';

        if ($this->currentPage < $totalPages) {
            $url = $this->buildPaginationUrl($this->currentPage + 1);
            $html .= '<a href="' . $url . '">Nächste »</a>';
        }

        $html .= '</div>';
        return $html;
    }

    private function buildPaginationUrl(int $page): string
    {
        $url = "./?AdminRegUserIndex&site={$page}";
        if ($this->currentSort !== 'login_new') {
            $url .= '&sort=' . urlencode($this->currentSort);
        }
        if ($this->currentSearch !== '') {
            $url .= '&search=' . urlencode($this->currentSearch);
        }
        return $url;
    }

    private function buildUserTable(): string
    {
        if (empty($this->users)) {
            return '<b>Keine Benutzer gefunden.</b>';
        }

        $html = '<form id="checkers" method="post" action="./?AdminRegUserEdit">
            <input type="hidden" name="csrf_token" value="' . htmlspecialchars($this->csrfToken, ENT_QUOTES, 'UTF-8') . '">
            <input type="hidden" id="userids" name="userids">

            <table border="1" cellpadding="5" cellspacing="0" class="user-table">
			<thead>
            <tr>
                <th></th>
                <th>Username</th>
                <th>Reg. Datum</th>
                <th>IP während Reg.</th>
                <th>Letzter Login</th>
                <th>Letzte IP</th>
                <th>E-Mail</th>
                <th>Avatar</th>
            </tr></thead><tbody>';

        foreach ($this->users as $user) {
            $id = (int)$user['etchat_user_id'];
            $name = htmlspecialchars($user['etchat_username'] ?? '', ENT_QUOTES, 'UTF-8');

            $reg = $this->formatTimestamp($user['etchat_reg_timestamp'] ?? null);
            $login = $this->formatTimestamp($user['etchat_logintime'] ?? null);

            $email = htmlspecialchars((string)($user['etchat_email'] ?? ''), ENT_QUOTES, 'UTF-8');
            $avatar = htmlspecialchars((string)($user['etchat_avatar'] ?? ''), ENT_QUOTES, 'UTF-8');
            $regIp = htmlspecialchars((string)($user['etchat_reg_ip'] ?? ''), ENT_QUOTES, 'UTF-8');
            $lastIp = htmlspecialchars((string)($user['etchat_last_ip'] ?? ''), ENT_QUOTES, 'UTF-8');

            $avatarDeleteLink = '<a href="./?AdminRegUserEdit&delavatar&csrf_token=' . urlencode($this->csrfToken) . '&id=' . $id . '"
                onclick="return confirm(\'Avatar wirklich löschen?\')">Löschen</a>';

            $html .= '<tr>
                <td><input type="checkbox" class="chk_user" value="' . $id . '"></td>
                <td><b><a href="./?AdminEditUserUser&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '">✏️ ' . $name . '</a></b></td>
                <td>' . $reg . '</td>
                <td>' . $regIp . '</td>
                <td>' . $login . '</td>
                <td>' . $lastIp . '</td>
                <td>' . $email . '</td>
                <td>' . $avatarDeleteLink . ' <img class="avatar_list_admin" src="avatar/' . $avatar . '" width="16" alt=""></a></td>
            </tr>';
        }

        $html .= '</tbody>
            </table>
            </form>
            <br>
            <input type="button" value="Alle markieren" id="mark_all_btn">
            &nbsp;
            <input type="button" value="Ausgewählte löschen" id="delete_selected_btn">';

        return $html;
    }

    private function formatTimestamp($timestamp): string
    {
        if (is_numeric($timestamp)) {
            return date("d.m.Y H:i:s", (int)$timestamp);
        }
        return (string)$timestamp;
    }

    private function buildInactiveForm(): string
    {
        return '<form method="get" action="./">
            <input type="hidden" name="AdminRegUserEdit" value="1">
            <input type="hidden" name="deleteinactive" value="1">
            <input type="hidden" name="csrf_token" value="' . htmlspecialchars($this->csrfToken, ENT_QUOTES, 'UTF-8') . '">
            <select name="inactive_months">
                <option value="3">3 Monate</option>
                <option value="6">6 Monate</option>
                <option value="12" selected>12 Monate</option>
                <option value="18">18 Monate</option>
                <option value="24">24 Monate</option>
            </select>
            <input type="submit" value="Löschen">
        </form>';
    }
}