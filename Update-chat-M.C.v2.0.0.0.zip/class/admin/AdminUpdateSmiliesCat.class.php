<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateSmiliesCat extends DbConectionMaker
{
    private string $message1 = '';
    private string $message2 = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_smilies[0] ?? null;

        // Rollen prüfen
        $role = (string)($_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '');
        $allowedRoles = ["admin", "grafik", "co_admin"];
        
        if (!in_array($role, $allowedRoles, true)) {
            $this->showError($lang->error[0]->tagData ?? '❌ Zugriff verweigert');
            exit;
        }

        // CSRF prüfen
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');
        if (!$this->isValidCsrfToken($token)) {
            $this->showError(($lang->error[0]->tagData ?? '❌ Fehler') . ' (CSRF)');
            exit;
        }

        // Eingaben validieren
        $id = (int)($_POST["id"] ?? 0);
        $newName = trim((string)($_POST["name"] ?? ''));
        $oldName = trim((string)($_POST["name_old"] ?? ''));
        $gw = (int)($_POST["gw"] ?? 0);
        $gwOld = (int)($_POST["gw_old"] ?? 0);

        if ($id <= 0 || $newName === '') {
            $this->showError('❌ Ungültige Daten: ID oder Name fehlt');
            exit;
        }

        // Kategorie-Name validieren
        if (mb_strlen($newName) > 100) {
            $newName = mb_substr($newName, 0, 100);
        }

        // Sichere Namen für Ordner
        $oldSafe = preg_replace("/[^a-zA-Z0-9_-]/", "_", $oldName);
        $newSafe = preg_replace("/[^a-zA-Z0-9_-]/", "_", $newName);

        try {
            // =========================
            // 1. KATEGORIE NAME
            // =========================
            $this->updateCategoryName($id, $newName, $oldName, $oldSafe, $newSafe, $lang);

            // =========================
            // 2. GEWICHT
            // =========================
            $this->updateWeight($id, $gw, $gwOld, $lang);

            $this->dbObj->close();

            // Erfolgsmeldung in Session speichern
            $_SESSION['smiley_cat_update_success'] = true;

            $this->renderTemplate($lang);

        } catch (PDOException $e) {
            error_log("AdminUpdateSmiliesCat Fehler: " . $e->getMessage());
            $this->showError($lang->error[0]->tagData ?? '❌ Datenbankfehler');
            exit;
        }
    }

    private function updateCategoryName(int $id, string $newName, string $oldName, string $oldSafe, string $newSafe, ?object $lang): void
    {
        if ($newName === $oldName) {
            $this->message1 = "📁 Kategorie nicht geändert<br>";
            return;
        }

        // Prüfen ob Name schon existiert
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id 
             FROM {$this->_prefix}etchat_smileys_cat 
             WHERE name = :name AND id != :id"
        );
        $stmt->execute([':name' => $newName, ':id' => $id]);
        
        if ($stmt->fetch()) {
            $this->message1 = "<span style='color:red;'>❌ Kategorie existiert bereits, keine Änderung</span><br>";
            return;
        }

        // Kategorie Namen in DB aktualisieren
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_smileys_cat
             SET name = :name
             WHERE id = :id",
            [':name' => $newName, ':id' => $id]
        );

        // Smileys Kategorie aktualisieren
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_smileys
             SET etchat_smileys_kat = :newName
             WHERE etchat_smileys_kat = :oldName",
            [':newName' => $newName, ':oldName' => $oldName]
        );

        // Bildpfade anpassen
        $oldPath = "./smilies/" . $oldSafe . "/";
        $newPath = "./smilies/" . $newSafe . "/";

        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_smileys
             SET etchat_smileys_img = REPLACE(etchat_smileys_img, :oldPath, :newPath)
             WHERE etchat_smileys_kat = :newName",
            [':oldPath' => $oldPath, ':newPath' => $newPath, ':newName' => $newName]
        );

        $this->message1 = "<span style='color:green;'>✅ Kategorie geändert, Smileys und Pfade aktualisiert</span><br>";

        // Ordner umbenennen
        $oldDir = "./smilies/" . $oldSafe;
        $newDir = "./smilies/" . $newSafe;

        if (is_dir($oldDir)) {
            if (!is_dir($newDir)) {
                if (rename($oldDir, $newDir)) {
                    $this->message1 .= "<span style='color:green;'>✅ Ordner wurde umbenannt</span><br>";
                } else {
                    $this->message1 .= "<span style='color:red;'>❌ Fehler: Ordner konnte nicht umbenannt werden</span><br>";
                }
            } else {
                $this->message1 .= "<span style='color:orange;'>⚠️ Neuer Ordner existiert bereits, Dateien wurden trotzdem aktualisiert</span><br>";
            }
        } else {
            $this->message1 .= "<span style='color:orange;'>⚠️ Alter Ordner nicht gefunden, Datenbank wurde trotzdem aktualisiert</span><br>";
        }
    }

    private function updateWeight(int $id, int $gw, int $gwOld, ?object $lang): void
    {
        if ($gw === $gwOld) {
            $this->message2 = "⚖️ Gewicht nicht geändert<br>";
            return;
        }

        $gw = max(1, min(99999, $gw));

        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_smileys_cat
             SET gewicht = :gw
             WHERE id = :id",
            [':gw' => $gw, ':id' => $id]
        );

        $this->message2 = "<span style='color:green;'>✅ Gewicht geändert</span><br>";
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $token !== '' && hash_equals($sessionToken, $token);
    }

    private function showError(string $message): void
    {
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '
              </div>';
        echo '<p><a href="./?AdminSmiliesCatIndex" class="admin-button">⬅️ Zurück zur Kategorie-Übersicht</a></p>';
        exit;
    }

    private function renderTemplate(?object $lang): void
    {
        $print_smil_edit_1 = $this->message1;
        $print_smil_edit_2 = $this->message2;
        
        include_once "styles/admin_tpl/errorSmileyCatExists.tpl.html";
    }
}