<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminSmiliesCatIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $categories = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0] ?? null;

        // Zugriff prüfen
        if (!$this->hasAccess()) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Kategorien holen
        $this->loadCategories();

        $this->dbObj->close();

        // Erfolgsmeldung
        $savedMsg = '';
        if (isset($_GET['saved']) && $_GET['saved'] === '1') {
            $savedMsg = '<div id="successBanner" class="success-banner">
                            <span>✅ Reihenfolge gespeichert</span>
                            <span class="close-btn" onclick="closeSuccessBanner()">✖</span>
                         </div>';
        }

        // Template anzeigen
        $this->renderTemplate($lang, $savedMsg);
    }

    private function hasAccess(): bool
    {
        $allowedRoles = ["admin", "co_admin", "grafik"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        return true;
    }

    private function loadCategories(): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id, name, aktiv, gewicht
             FROM {$this->_prefix}etchat_smileys_cat
             ORDER BY gewicht ASC"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->categories = is_array($result) ? $result : [];
    }

    private function renderTemplate(?object $lang, string $savedMsg): void
    {
        $print_cat_list = $this->buildCategoryRows($lang);
        $totalCategories = count($this->categories);
        $csrf = $this->csrfToken;
        
        include_once "styles/admin_tpl/indexSmiliesCat.tpl.html";
    }

    private function buildCategoryRows(?object $lang): string
    {
        if (empty($this->categories)) {
            return '<tr><td colspan="7">Keine Kategorien vorhanden.</tr></tr>';
        }

        $html = '';
        $i = 0;

        foreach ($this->categories as $row) {
            $i++;

            $id = (int)($row['id'] ?? 0);
            $name = htmlspecialchars($row['name'] ?? '', ENT_QUOTES, 'UTF-8');
            $aktivRaw = $row['aktiv'] ?? 'off';
            $gewicht = (int)($row['gewicht'] ?? 0);

            $currentStatus = ($aktivRaw === 'on') ? 'on' : 'off';
            $newStatus = ($currentStatus === 'on') ? 'off' : 'on';
            $statusDisplay = ($currentStatus === 'on') ? '🟢 An' : '🔴 Aus';
            $catUrl = urlencode($row['name'] ?? '');

            $bgclass = ($i % 2 === 0) ? "ungerade" : "gerade";

            $html .= '
                <tr class="' . $bgclass . '" data-id="' . $id . '">
                    <td align="center">
                        <img class="img_verschieben" src="./img/verschieben.png" alt="verschieben">
                    </td>
                    <td>' . $i . '.</td>
                    <td>' . $name . '</td>
                    <td>
                        <a href="./?AdminRenameSmiliesCat&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '">
                            ✏️ ' . ($lang->rename[0]->tagData ?? 'Umbenennen') . '
                        </a>
                    </td>
                    <td>
                        <a href="./?AdminDeleteSmiliesCat&id=' . $id . '&cat=' . $catUrl . '&csrf_token=' . urlencode($this->csrfToken) . '"
                           onclick="return confirm(\'Wirklich löschen?\\nEs werden auch alle Smilies aus der Kategorie mit gelöscht\');">
                            🗑️ ' . ($lang->delete[0]->tagData ?? 'Löschen') . '
                        </a>
                    </td>
                    <td>
                        <a href="./?AdminOnOffSmiliesCat&id=' . $id . '&on_on_off=' . $newStatus . '&csrf_token=' . urlencode($this->csrfToken) . '">
                            ' . $statusDisplay . '
                        </a>
                    </td>
                    <td>' . $gewicht . '</td>
                </tr>';
        }

        return $html;
    }
}