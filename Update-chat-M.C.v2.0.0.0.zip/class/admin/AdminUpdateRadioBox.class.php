<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateRadioBox extends DbConectionMaker
{
    // Erlaubte Radio-Typen
    private array $allowedTypes = ['shoutcast', 'icecast', 'lautfm'];
    
    // Feld-Mapping (POST-Key => DB-Feld)
    private array $fields = [
        'host'      => 'etchat_radio_horst',
        'port'      => 'etchat_radio_port',
        'radio_server_type' => 'etchat_radio_typ',
        'stream'    => 'etchat_radio_stream',
        'streamname' => 'etchat_radio_name',
        'color'     => 'etchat_radio_color',
        'bits'      => 'etchat_radio_bit',
        'radiobox'  => 'etchat_radio_box',
        'player'    => 'etchat_radio_player',
        'on_air'    => 'etchat_on_air',
        'sys_titel' => 'etchat_system_titel_an',
        'titel_hist' => 'etchat_titel_an'
    ];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache sicher laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_rooms[0] ?? null;

        // Eingaben
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // CSRF prüfen
        if (!$this->isValidCsrfToken($token)) {
            $this->showError(($lang->error[0]->tagData ?? '❌ Fehler') . ' (CSRF)');
            exit;
        }

        // Adminrechte prüfen (nur admin)
        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        if ($role !== 'admin' || $id <= 0) {
            $this->showError($lang->error[0]->tagData ?? '❌ Zugriff verweigert');
            exit;
        }

        // Daten sammeln und validieren
        $updates = [];
        $params = [];

        foreach ($this->fields as $postKey => $dbField) {
            if (isset($_POST[$postKey])) {
                $value = trim((string)$_POST[$postKey]);
                
                // Typ-spezifische Validierung
                if ($postKey === 'radio_server_type') {
                    if (!in_array($value, $this->allowedTypes, true)) {
                        $value = 'shoutcast';
                    }
                } elseif (in_array($postKey, ['radiobox', 'player', 'on_air', 'sys_titel', 'titel_hist'], true)) {
                    // Boolean-Felder (0/1)
                    $value = ($value === '1' || $value === 1) ? '1' : '0';
                } elseif ($postKey === 'port') {
                    // Port: nur Zahlen, max 65535
                    $value = preg_replace('/[^0-9]/', '', $value);
                    if ($value !== '' && (int)$value > 65535) {
                        $value = '8000';
                    }
                } elseif ($postKey === 'bits') {
                    // Bitrate: nur Zahlen
                    $value = preg_replace('/[^0-9]/', '', $value);
                    if ($value === '') $value = '128';
                } elseif ($postKey === 'host') {
                    // Host: keine http://, https://, keine Sonderzeichen
                    $value = preg_replace('/^https?:\/\//i', '', $value);
                    $value = preg_replace('/[^a-zA-Z0-9\-\.]/', '', $value);
                }
                
                // Längenbegrenzungen
                if ($postKey === 'host' && mb_strlen($value) > 100) {
                    $value = mb_substr($value, 0, 100);
                }
                if ($postKey === 'stream' && mb_strlen($value) > 255) {
                    $value = mb_substr($value, 0, 255);
                }
                if ($postKey === 'streamname' && mb_strlen($value) > 100) {
                    $value = mb_substr($value, 0, 100);
                }
                if ($postKey === 'color' && mb_strlen($value) > 20) {
                    $value = mb_substr($value, 0, 20);
                }
                
                $updates[] = "$dbField = :$postKey";
                $params[$postKey] = $value;
            }
        }

        // Update ausführen
        if (!empty($updates)) {
            try {
                $sql = "UPDATE {$this->_prefix}etchat_radio_box 
                        SET " . implode(", ", $updates) . " 
                        WHERE etchat_radio_id = :id";

                $params['id'] = $id;
                $this->dbObj->sqlSet($sql, $params);
                
                // Erfolgsmeldung in Session speichern
                $_SESSION['radio_update_success'] = true;
                
            } catch (PDOException $e) {
                error_log("AdminUpdateRadioBox Fehler: " . $e->getMessage());
                $this->showError($lang->error[0]->tagData ?? '❌ Datenbankfehler');
                exit;
            }
        }

        $this->dbObj->close();

        // Redirect nach Erfolg
        header("Location: ./?AdminRadioBoxIndex");
        exit;
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $sessionToken !== '' && hash_equals($sessionToken, $token);
    }

    private function showError(string $message): void
    {
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '
              </div>';
        echo '<p><a href="./?AdminRadioBoxIndex" class="admin-button">⬅️ Zurück zur Radio-Box Übersicht</a></p>';
        exit;
    }
}