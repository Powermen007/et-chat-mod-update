<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateSmilies extends DbConectionMaker
{
    private string $message1 = '';
    private string $message2 = '';
    private string $message3 = '';

    // Erlaubte Bildformate
    private array $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_smilies[0] ?? null;

        // Rollen prüfen
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        $allowedRoles = ['admin', 'grafik', 'co_admin'];
        
        if (!in_array($role, $allowedRoles, true)) {
            $this->showError($lang->error[0]->tagData ?? '❌ Zugriff verweigert');
            exit;
        }

        // CSRF prüfen
        $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
        if (!$this->isValidCsrfToken($token)) {
            $this->showError(($lang->error[0]->tagData ?? '❌ Fehler') . ' (CSRF)');
            exit;
        }

        // ID prüfen
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->showError($lang->error[0]->tagData ?? '❌ Ungültige ID');
            exit;
        }

        try {
            $pdo = $this->dbObj->getConnection();

            // 1. KÜRZEL AKTUALISIEREN
            $this->updateSign($id, $pdo, $lang);

            // 2. KATEGORIE + DATEI VERSCHIEBEN
            $this->updateCategoryAndFile($id, $pdo, $lang);

            // 3. GEWICHT AKTUALISIEREN
            $this->updateWeight($id, $pdo, $lang);

            $this->dbObj->close();

            // Erfolgsmeldung in Session speichern
            $_SESSION['smiley_update_success'] = true;

            $this->renderTemplate($lang);

        } catch (PDOException $e) {
            error_log("AdminUpdateSmilies Fehler: " . $e->getMessage());
            $this->showError($lang->error[0]->tagData ?? '❌ Datenbankfehler');
            exit;
        }
    }

    /**
     * Aktualisiert das Smiley-Kürzel
     */
    private function updateSign(int $id, PDO $pdo, ?object $lang): void
    {
        $newSign = trim($_POST['smileys_sing'] ?? '');
        $oldSign = trim($_POST['osing'] ?? '');

        // Kürzel validieren
        if ($newSign === '') {
            $this->message1 = "<span style='color:orange;'>⚠️ Kürzel darf nicht leer sein, daher nicht geändert</span><br>";
            return;
        }

        if ($newSign === $oldSign) {
            $this->message1 = "📝 Kürzel nicht geändert<br>";
            return;
        }

        // Längenbegrenzung
        if (mb_strlen($newSign) > 50) {
            $newSign = mb_substr($newSign, 0, 50);
            $this->message1 = "<span style='color:orange;'>⚠️ Kürzel wurde auf 50 Zeichen gekürzt</span><br>";
        }

        // Prüfen ob Kürzel bereits existiert
        $stmt = $pdo->prepare("
            SELECT etchat_smileys_id 
            FROM {$this->_prefix}etchat_smileys 
            WHERE etchat_smileys_sign = :sign 
            AND etchat_smileys_id <> :id
        ");
        $stmt->execute([':sign' => $newSign, ':id' => $id]);

        if ($stmt->fetch()) {
            $this->message1 = "<span style='color:red;'>❌ Kürzel nicht geändert (existiert bereits)</span><br>";
            return;
        }

        // Kürzel aktualisieren
        $stmt = $pdo->prepare("
            UPDATE {$this->_prefix}etchat_smileys 
            SET etchat_smileys_sign = :sign 
            WHERE etchat_smileys_id = :id
        ");
        $stmt->execute([':sign' => $newSign, ':id' => $id]);

        $this->message1 = "<span style='color:green;'>✅ Kürzel geändert</span><br>";
    }

    /**
     * Aktualisiert die Kategorie und verschiebt die Datei
     */
    private function updateCategoryAndFile(int $id, PDO $pdo, ?object $lang): void
    {
        $oldPath = $_POST['opfad'] ?? '';
        $oldName = $_POST['oname'] ?? '';
        $newName = trim($_POST['name'] ?? '');

        if ($oldPath === '' || $newName === '' || $newName === $oldName) {
            $this->message2 = "📁 Kategorie nicht geändert<br>";
            return;
        }

        $filename = basename($oldPath);
        
        // Dateiendung prüfen
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!in_array($ext, $this->allowedExtensions, true)) {
            $this->message2 = "<span style='color:red;'>❌ Ungültiges Dateiformat, Kategorie nicht geändert</span><br>";
            return;
        }
        
        $safeCat = preg_replace('/[^a-zA-Z0-9_-]/', '_', $newName);
        if ($safeCat === '') {
            $this->message2 = "<span style='color:red;'>❌ Ungültiger Kategoriename</span><br>";
            return;
        }

        $baseDir = realpath(__DIR__ . '/../../smilies/');
        if ($baseDir === false) {
            $this->message2 = "<span style='color:red;'>❌ Fehler: Smilies-Verzeichnis nicht gefunden</span><br>";
            return;
        }

        $newDir = $baseDir . '/' . $safeCat;
        if (!is_dir($newDir) && !mkdir($newDir, 0755, true)) {
            $this->message2 = "<span style='color:red;'>❌ Konnte Kategorie-Ordner nicht erstellen</span><br>";
            return;
        }

        $targetFile = $newDir . '/' . $filename;
        if (file_exists($targetFile)) {
            $targetFile = $newDir . '/' . time() . '_' . $filename;
        }

        $oldReal = realpath($oldPath);
        if ($oldReal === false || !str_starts_with($oldReal, $baseDir) || !file_exists($oldReal)) {
            $this->message2 = "<span style='color:red;'>❌ Kategorie geändert, Datei konnte nicht verschoben werden (Datei nicht gefunden)</span><br>";
            return;
        }

        if (!rename($oldReal, $targetFile)) {
            $this->message2 = "<span style='color:red;'>❌ Kategorie geändert, Datei konnte nicht verschoben werden</span><br>";
            return;
        }

        // Relativen Pfad für die Datenbank
        $relativePath = './smilies/' . $safeCat . '/' . basename($targetFile);
        $relativePath = str_replace(['\\', '//'], '/', $relativePath);

        // Datenbank aktualisieren
        $stmt = $pdo->prepare("
            UPDATE {$this->_prefix}etchat_smileys
            SET etchat_smileys_kat = :kat, etchat_smileys_img = :img
            WHERE etchat_smileys_id = :id
        ");
        $stmt->execute([
            ':kat' => $safeCat,
            ':img' => $relativePath,
            ':id'  => $id
        ]);

        $this->message2 = "<span style='color:green;'>✅ Kategorie geändert und Datei verschoben</span><br>";
    }

    /**
     * Aktualisiert das Gewicht
     */
    private function updateWeight(int $id, PDO $pdo, ?object $lang): void
    {
        $oldWeight = (int)($_POST['ogw'] ?? 0);
        $newWeight = (int)($_POST['gw'] ?? 0);

        if ($newWeight === $oldWeight) {
            $this->message3 = "⚖️ Gewicht nicht geändert<br>";
            return;
        }

        $newWeight = max(1, min(99999, $newWeight));

        $stmt = $pdo->prepare("
            UPDATE {$this->_prefix}etchat_smileys 
            SET etchat_smileys_gewicht = :weight 
            WHERE etchat_smileys_id = :id
        ");
        $stmt->execute([':weight' => $newWeight, ':id' => $id]);

        $this->message3 = "<span style='color:green;'>✅ Gewicht geändert</span><br>";
    }

    /**
     * Prüft den CSRF-Token
     */
    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $token !== '' && hash_equals($sessionToken, $token);
    }

    /**
     * Zeigt eine Fehlermeldung an
     */
    private function showError(string $message): void
    {
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '
              </div>';
        echo '<p><a href="./?AdminSmiliesIndex" class="admin-button">⬅️ Zurück zur Smiley-Übersicht</a></p>';
        exit;
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate(?object $lang): void
    {
        $print_smil_edit_1 = $this->message1;
        $print_smil_edit_2 = $this->message2;
        $print_smil_edit_3 = $this->message3;
        
        include_once "styles/admin_tpl/errorSmileySignExists.tpl.html";
    }
}