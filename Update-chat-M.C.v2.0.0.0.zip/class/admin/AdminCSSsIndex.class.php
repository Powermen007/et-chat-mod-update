<?php

declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminCSSsIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private string $fileContent = '';
    private string $fileName = '';
    private string $dataKey = '';
    private string $message = '';

    // Erlaubte Dateiendungen für den Editor
    private array $allowedExtensions = ['css', 'js', 'html', 'tpl.html'];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_menus[0] ?? null;

        // Rechtecheck
        $userPriv = $_SESSION["etchat_{$this->_prefix}user_priv"] ?? '';
        $allowedRoles = ["admin", "grafik", "co_admin"];
        
        if (!in_array($userPriv, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // CSRF Token
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Input
        $data = $_POST + $_GET;
        $this->dataKey = trim($data['data3'] ?? '');

        if ($this->dataKey === '') {
            $this->message = "Keine Datei angegeben.";
            $this->renderTemplate($lang);
            return;
        }

        // Datei validieren und laden
        if (!$this->validateAndLoadFile()) {
            $this->renderTemplate($lang);
            return;
        }

        // Speichern bei POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'], $_POST['text'])) {
            $this->saveFile();
            return;
        }

        $this->renderTemplate($lang);
    }

    /**
     * Validiert die Datei und lädt ihren Inhalt
     */
    private function validateAndLoadFile(): bool
    {
        $basePath = realpath(__DIR__ . "/../../");
        if ($basePath === false) {
            $this->message = "Base Path Fehler.";
            return false;
        }

        $styleFolder = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'default';

        // Pfad bestimmen
        if (str_starts_with($this->dataKey, 'styles/')) {
            $targetPath = realpath($basePath . "/" . $this->dataKey);
        } else {
            $targetPath = realpath($basePath . "/styles/{$styleFolder}/" . $this->dataKey);
        }

        if ($targetPath === false || !file_exists($targetPath)) {
            $this->message = "Datei nicht gefunden: " . htmlspecialchars($this->dataKey, ENT_QUOTES, 'UTF-8');
            return false;
        }

        // Prüfen ob Datei im Chat-Verzeichnis bleibt
        if (!str_starts_with($targetPath, $basePath)) {
            $this->message = "Zugriff auf Dateien außerhalb des Chat-Verzeichnisses nicht erlaubt.";
            return false;
        }

        // Dateiendung prüfen
        $extension = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
        if (!in_array($extension, $this->allowedExtensions, true)) {
            $this->message = "Dateityp '{$extension}' kann nicht bearbeitet werden. Erlaubt: " . implode(', ', $this->allowedExtensions);
            return false;
        }

        // Prüfen ob Datei lesbar ist
        if (!is_readable($targetPath)) {
            $this->message = "Datei nicht lesbar. Bitte Berechtigungen prüfen.";
            return false;
        }

        $this->fileName = $targetPath;
        
        // Dateiinhalt laden
        $content = file_get_contents($this->fileName);
        if ($content === false) {
            $this->message = "Datei konnte nicht gelesen werden.";
            return false;
        }
        
        $this->fileContent = $content;
        return true;
    }

    /**
     * Speichert die Datei
     */
    private function saveFile(): void
    {
        // CSRF prüfen
        $tokenPost = $_POST['csrf_token'] ?? '';
        if (!hash_equals($this->csrfToken, $tokenPost)) {
            $this->message = "CSRF Fehler – Ungültiger Token.";
            $this->renderTemplate(null);
            return;
        }

        // Prüfen ob Datei schreibbar ist
        if (!is_writable($this->fileName)) {
            $this->message = "Datei nicht schreibbar. Bitte Berechtigungen prüfen (CHMOD).";
            $this->renderTemplate(null);
            return;
        }

        // Inhalt speichern
        $newContent = $_POST['text'] ?? '';
        
        $bytes = file_put_contents($this->fileName, $newContent, LOCK_EX);
        
        if ($bytes === false) {
            $this->message = "Fehler beim Speichern der Datei.";
            $this->renderTemplate(null);
            return;
        }
        
        // Erfolg: Weiterleitung mit Erfolgsflag
        $url = urlencode($this->dataKey);
        header("Location: ./?AdminCSSsIndex&data3={$url}&saved=1");
        exit;
    }

    private function renderTemplate(?object $lang): void
    {
        // Template-Variablen (kompatibel mit bestehendem Template)
        $print_css_list3 = $this->dataKey;
        
        $print_css_list1 = '<form action="./?AdminCSSsIndex&data3=' . htmlspecialchars($this->dataKey, ENT_QUOTES, 'UTF-8') . '" method="post">
                                <textarea id="b" name="text">';
        
        $print_css_list2 = '</textarea>
            <input type="hidden" name="csrf_token" value="' . htmlspecialchars($this->csrfToken, ENT_QUOTES, 'UTF-8') . '">
            <div class="codemirror-save" id="editor-save">
                <input type="submit" value="Speichern" name="submit">
            </div>
        </form>';
        
        $print_css_list = $this->fileContent;
        
        include "styles/admin_tpl/indexCSSs.tpl.html";
        
        $this->dbObj->close();
    }
}