<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminHalloAnreden extends DbConectionMaker
{
    private const ALLOWED_ROLES = ['admin', 'co_admin'];
    private const TYPES = ['hallo' => 'anreden.txt', 'bye' => 'verabschieden.txt'];
    
    private string $csrfToken = '';
    private string $meldung = '';
    private string $currentType = 'hallo';
    private array $anreden = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Zugriff prüfen
        $this->checkAccess();

        // Typ validieren
        $this->currentType = $this->validateType($_REQUEST['typ'] ?? 'hallo');

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // POST verarbeiten
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        // Datei laden
        $this->loadAnreden();

        // Template anzeigen
        $this->renderTemplate();
    }

    /**
     * Prüft die Zugriffsberechtigung
     */
    private function checkAccess(): void
    {
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($role, self::ALLOWED_ROLES, true)) {
            header('Location: ./');
            exit;
        }
    }

    /**
     * Validiert den Dateityp
     */
    private function validateType(string $type): string
    {
        return isset(self::TYPES[$type]) ? $type : 'hallo';
    }

    /**
     * Gibt den Pfad zur Textdatei zurück
     */
    private function getFilePath(): string
    {
        return __DIR__ . '/../../cache/' . self::TYPES[$this->currentType];
    }

    /**
     * Verarbeitet POST-Request zum Speichern
     */
    private function handlePost(): void
    {
        // CSRF prüfen
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            $this->meldung = '<div class="error" style="color: red; background: #ffebee; padding: 10px; border-radius: 5px;">❌ Ungültiger CSRF Token!</div>';
            return;
        }

        if (isset($_POST['anreden'])) {
            $this->saveAnreden($_POST['anreden']);
        }
    }

    /**
     * Lädt die Anreden aus der Textdatei
     */
    private function loadAnreden(): void
    {
        $filePath = $this->getFilePath();

        if (!is_file($filePath)) {
            $this->anreden = [];
            return;
        }

        $content = file_get_contents($filePath);
        if ($content === false) {
            $this->anreden = [];
            return;
        }

        $lines = explode("\n", $content);
        $this->anreden = array_filter(array_map('trim', $lines), fn($line) => $line !== '');
    }

    /**
     * Speichert die Anreden in die Textdatei
     */
    private function saveAnreden(string $inhalt): void
    {
        $lines = array_filter(
            array_map('trim', explode("\n", $inhalt)),
            fn(string $line) => $line !== ''
        );

        $success = file_put_contents(
            $this->getFilePath(),
            implode(PHP_EOL, $lines),
            LOCK_EX
        );

        if ($success !== false) {
            $this->meldung = '<div class="success-banner" style="background: #4CAF50; color: white; padding: 10px; border-radius: 5px;">
                                ✅ Gespeichert erfolgreich!
                                <span style="float: right; cursor: pointer;" onclick="closeSuccessBanner()">✖</span>
                              </div>';
            $this->anreden = $lines;
        } else {
            $this->meldung = '<div class="error" style="color: red; background: #ffebee; padding: 10px; border-radius: 5px;">❌ Fehler beim Speichern!</div>';
        }
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate(): void
    {
        $csrfToken = $this->csrfToken;
        $meldung = $this->meldung;
        $typ = $this->currentType;
        $inhalt = implode("\n", $this->anreden);
        $titel = $typ === 'hallo' ? 'Hallo-Anreden' : 'Verabschiedungen';
        $style = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? 'default';

        include "styles/admin_tpl/indexHalloAnreden.tpl.html";
    }
}