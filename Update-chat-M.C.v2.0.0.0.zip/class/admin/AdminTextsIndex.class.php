<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminTextsIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $texts = [];

    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_menus[0] ?? null;

        // Rollenprüfung (nur admin)
        $allowedRoles = ["admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Texte laden
        $this->loadTexts();

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    private function loadTexts(): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id, ort, header_text 
             FROM {$this->_prefix}etchat_texte 
             ORDER BY id"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->texts = is_array($result) ? $result : [];
    }

    private function renderTemplate(?object $lang): void
    {
        $print_text_list = $this->buildTextList();
        
        include_once "styles/admin_tpl/indexTexts.tpl.html";
    }

    private function buildTextList(): string
    {
        if (empty($this->texts)) {
            return '<p>📭 Keine Texte vorhanden.</p>';
        }

        $html = '<table border="1" cellpadding="5" cellspacing="0" class="text-table">
                    <thead>
                    <tr>
                        <th>🆔 ID</th>
                        <th>📌 Bezeichnung</th>
                        <th>📝 Überschrift</th>
                        <th>✏️ Aktion</th>
                    </tr>
                    </thead>
                    <tbody>';

        foreach ($this->texts as $text) {
            $id = htmlspecialchars((string)($text['id'] ?? ''), ENT_QUOTES, 'UTF-8');
            $ort = htmlspecialchars((string)($text['ort'] ?? ''), ENT_QUOTES, 'UTF-8');
            $headerRaw = (string)($text['header_text'] ?? '');
            $header = htmlspecialchars(strip_tags($headerRaw), ENT_QUOTES, 'UTF-8');

            $html .= '<tr>
                        <td>' . $id . '</td>
                        <td>' . $ort . '</td>
                        <td>' . $header . '</td>
                        <td>
                            <a href="./?AdminEditText&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '">
                                ✏️ Editieren
                            </a>
                        </td>
                    </tr>';
        }

        $html .= '</tbody>
                </table>';
        
        return $html;
    }
}