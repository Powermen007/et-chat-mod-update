<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRoomsIndex extends ConnectDB
{
    private string $csrfToken = '';
    private array $rooms = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_rooms[0] ?? null;

        // Rechte prüfen
        if (!$this->isAllowed()) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // Räume laden
        $this->loadRooms();

        $this->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    private function isAllowed(): bool
    {
        $allowedRoles = ["admin", "co_admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        return true;
    }

    private function loadRooms(): void
    {
        $result = $this->sqlGet(
            "SELECT etchat_id_room, etchat_roomname, etchat_room_goup 
             FROM {$this->_prefix}etchat_rooms
             ORDER BY etchat_id_room ASC"
        );
        
        $this->rooms = is_array($result) ? $result : [];
    }

    private function renderTemplate(?object $lang): void
    {
        $print_room_list = $this->buildRoomList($lang);
        $csrf = $this->csrfToken;
        
        // Für das Template: Option für registrierte Benutzer (wenn aktiviert)
        $room4user_print = '';
        if ($this->_allow_nick_registration ?? false) {
            $room4user_print = '<option value="4">' . ($lang->room_priv[4]->tagData ?? 'Alle registrierten Benutzer') . '</option>';
        }
        
        include_once("styles/admin_tpl/indexRooms.tpl.html");
    }

    private function buildRoomList(?object $lang): string
    {
        if (empty($this->rooms)) {
            return '<p>Keine Räume vorhanden.</p>';
        }

        $html = '<table border="1" cellpadding="5" cellspacing="0" class="room-table">
            <thead>
                <tr>
                    <th>Raumname</th>
                    <th></th>
                    <th>Löschen</th>
                    <th>Bearbeiten</th>
                    <th>Berechtigung</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($this->rooms as $room) {
            $id = (int)($room['etchat_id_room'] ?? 0);
            $name = htmlspecialchars($room['etchat_roomname'] ?? '', ENT_QUOTES, 'UTF-8');
            $priv = (int)($room['etchat_room_goup'] ?? 0);
            
            // Privattext aus Sprache oder Fallback
            if ($lang && isset($lang->room_priv[$priv]->tagData)) {
                $privText = $lang->room_priv[$priv]->tagData;
            } else {
                $privText = match($priv) {
                    0 => 'offen für alle',
                    1 => 'Admins und Mods',
                    2 => 'nur Admins',
                    3 => 'passwortgeschützt',
                    4 => 'alle registrierten Benutzer',
                    default => 'Unbekannt'
                };
            }

            // Raum 1 (Standard-Raum) kann nicht gelöscht werden
            $isProtected = ($id === 1);
            
            $html .= '<tr>';
            $html .= '<td><b>' . $name . '</b></td>';
            $html .= '<td>&nbsp;&nbsp;&nbsp;</td>';
            
            if ($isProtected) {
                $html .= '<td style="color:#888;"><strike>🗑️ ' . ($lang->delete[0]->tagData ?? 'Löschen') . '</strike></td>';
            } else {
                $html .= '<td><a href="./?AdminDeleteRoom&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '"
                            onclick="return confirm(\'Raum wirklich löschen?\')">🗑️ ' 
                            . ($lang->delete[0]->tagData ?? 'Löschen') . '</a></td>';
            }
            
            $html .= '<td><a href="./?AdminEditRoom&id=' . $id . '">✏️ ' . ($lang->rename[0]->tagData ?? 'Bearbeiten') . '</a></td>';
            $html .= '<td>&nbsp;&nbsp;&nbsp;<i>' . htmlspecialchars($privText, ENT_QUOTES, 'UTF-8') . '</i></td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';
        return $html;
    }
}