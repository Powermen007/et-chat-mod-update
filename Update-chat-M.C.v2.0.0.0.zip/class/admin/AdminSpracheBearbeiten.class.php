<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminSpracheBearbeiten extends DbConectionMaker
{
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Zugriff prüfen (nur admin)
        $userRole = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        if ($userRole !== "admin") {
            $this->fail("🔒 Zugriff verweigert.");
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Config laden (mit Prepared Statement)
        $config = $this->loadConfig();

        // Template anzeigen
        $this->showEditor($config);
    }

    private function loadConfig(): array
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_config_id, etchat_config_style, etchat_config_lang
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = 1"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return is_array($result) ? $result : [];
    }

    private function showEditor(array $config): void
    {
        $langFile = 'lang_de.xml';
        $styles = [];

        $langBase = realpath(__DIR__ . '/../../lang/');

        foreach ($config as $data) {
            if (!empty($data['etchat_config_lang'])) {
                $safeFile = basename($data['etchat_config_lang']);
                $fullPath = realpath(__DIR__ . '/../../lang/' . $safeFile);

                if ($fullPath && $langBase && str_starts_with($fullPath, $langBase)) {
                    $langFile = $safeFile;
                }
            }

            if (!empty($data['etchat_config_style'])) {
                $styles[] = $data['etchat_config_style'];
            }
        }

        $styles = array_values(array_unique($styles));

        $langPath = __DIR__ . '/../../lang/' . $langFile;

        if (!file_exists($langPath)) {
            $this->fail("📄 XML-Datei nicht gefunden: " . htmlspecialchars($langFile));
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_file($langPath);

        if (!$xml instanceof SimpleXMLElement) {
            $this->fail("❌ XML Fehler in der Sprachdatei.");
        }

        // Backup löschen (POST)
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_backups'])) {
            $this->handleDeleteBackups($langFile);
        }

        $backupCount = $this->countBackups($langFile);

        $bereichsArray = iterator_to_array($xml);

        $bereich = $_GET['bereich'] ?? array_key_first($bereichsArray);

        if (!isset($bereichsArray[$bereich])) {
            $bereich = array_key_first($bereichsArray);
        }

        $this->dbObj->close();

        // Template Variablen
        $csrfToken = $this->csrfToken;
        $xmlData = $xml;
        
        include "styles/admin_tpl/indexSpracheBearbeiten.tpl.html";
    }

    private function handleDeleteBackups(string $langFile): void
    {
        // CSRF prüfen
        $token = $_POST['csrf'] ?? '';
        if (!hash_equals($this->csrfToken, $token)) {
            $this->fail("🔒 CSRF Fehler");
        }

        $this->deleteBackups($langFile);
        header("Location: ./?AdminSpracheBearbeiten");
        exit;
    }

    private function deleteBackups(string $langFile): void
    {
        $backupDir = __DIR__ . '/../../lang/old/';

        if (!is_dir($backupDir)) return;

        $files = glob($backupDir . basename($langFile) . '.bak.*');

        if ($files === false) return;

        usort($files, fn($a, $b) => filemtime($b) <=> filemtime($a));

        $toDelete = array_slice($files, 3);

        foreach ($toDelete as $file) {
            if (is_file($file) && !unlink($file)) {
                error_log("AdminSpracheBearbeiten: Konnte Backup nicht löschen: " . $file);
            }
        }
    }

    private function countBackups(string $langFile): int
    {
        $backupDir = __DIR__ . '/../../lang/old/';

        $files = is_dir($backupDir)
            ? glob($backupDir . basename($langFile) . '.bak.*')
            : [];

        return $files !== false ? count($files) : 0;
    }

    public function renderNodes($node, string $prefix = ''): void
    {
        $counts = [];

        foreach ($node as $k => $v) {
            $counts[$k] = ($counts[$k] ?? 0) + 1;
        }

        $indexCounter = [];

        foreach ($node as $key => $value) {
            $idx = $indexCounter[$key] ?? 0;
            $indexCounter[$key] = $idx + 1;

            $hasMultiple = ($counts[$key] ?? 0) > 1;
            $pfad = $prefix . $key . ($hasMultiple ? '_' . $idx : '');

            if ($value->children()->count() > 0) {
                echo "<fieldset><legend>📁 " . htmlspecialchars($key) . "</legend>";
                $this->renderNodes($value, $pfad . '/');
                echo "</fieldset>";
            } else {
                $val = (string)$value;
                $safeVal = htmlspecialchars($val, ENT_QUOTES, 'UTF-8');
                
                echo "<label>📝 " . htmlspecialchars($key) . ":</label><br>";
                
                if (mb_strlen($val) > 60) {
                    echo "<textarea class='admin-textarea-medium' name='eintraege[" . htmlspecialchars($pfad) . "]'>" . $safeVal . "</textarea>";
                } else {
                    echo "<input type='text' name='eintraege[" . htmlspecialchars($pfad) . "]' value='" . $safeVal . "'>";
                }
                echo "<br><br>";
            }
        }
    }

    private function fail(string $msg): void
    {
        http_response_code(400);
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px;">❌ ' . htmlspecialchars($msg) . '</div>';
        exit;
    }
}