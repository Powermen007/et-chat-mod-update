<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminInsertSmiliesCat extends DbConectionMaker
{
    private array $allowedRoles = ["admin", "grafik", "co_admin"];
    private string $message = '';

    public function __construct()
    {
        parent::__construct();
        
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0] ?? null;

        // Rollen prüfen
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($userRole, $this->allowedRoles, true)) {
            echo '<span style="color:red;">Zugriff verweigert</span>';
            exit;
        }

        // CSRF prüfen (Token NICHT löschen!)
        $csrfToken = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';

        if (empty($csrfToken) || empty($sessionToken) || !hash_equals($sessionToken, $csrfToken)) {
            echo '<span style="color:red;">Ungültiger CSRF-Token.</span>';
            exit;
        }
        // KEIN unset($_SESSION['...']) mehr!

        // Eingaben validieren
        $name = trim($_POST['name'] ?? '');
        $onOff = ($_POST['on_off'] ?? '') === 'on' ? 'on' : 'off';
        $gw = max(1, min(9999, (int)($_POST['gw'] ?? 100)));

        // Name bereinigen (Umlaute erlaubt)
        $name = preg_replace('/[^a-zA-Z0-9 _\-\x{00C0}-\x{017F}]/u', '', $name);
        
        // Längenbegrenzung
        if (mb_strlen($name) > 100) {
            $name = mb_substr($name, 0, 100);
        }

        if ($name === '') {
            $this->message = '<span style="color:red;">Name darf nicht leer sein.</span>';
            $this->showResult($lang);
            return;
        }

        $this->handleInsert($name, $onOff, $gw, $lang);
    }

    private function handleInsert(string $name, string $onOff, int $gw, ?object $lang): void
    {
        // Prüfen, ob Kategorie bereits existiert
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id FROM {$this->_prefix}etchat_smileys_cat WHERE name = :name"
        );
        $stmt->execute([':name' => $name]);
        $exists = $stmt->fetch();

        if ($exists) {
            $this->message = '<span style="color:red;">' . htmlspecialchars($lang->name_exists[0]->tagData ?? 'Diese Kategorie existiert bereits!') . '</span>';
            $this->showResult($lang);
            return;
        }

        // In DB speichern
        try {
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_smileys_cat (`name`, `aktiv`, `gewicht`) 
                 VALUES (:name, :aktiv, :gewicht)",
                [
                    ':name' => $name,
                    ':aktiv' => $onOff,
                    ':gewicht' => $gw
                ]
            );

            $this->message = '<span style="color:green;">' . htmlspecialchars($lang->isupload1[0]->tagData ?? 'Kategorie erfolgreich erstellt!') . '</span>';
            
        } catch (PDOException $e) {
            error_log("AdminInsertSmiliesCat Fehler: " . $e->getMessage());
            $this->message = '<span style="color:red;">Datenbankfehler beim Speichern!</span>';
        }

        $this->showResult($lang);
    }

    private function showResult(?object $lang): void
    {
        $message = $this->message;
        include_once "styles/admin_tpl/insertSmiliesCatMessage.tpl.html";
        $this->dbObj->close();
    }
}