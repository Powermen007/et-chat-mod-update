<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditRadioBox extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $radioData = [];

    public function __construct()
    {
        parent::__construct();

        // Session sicher starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_rooms[0] ?? null;

        // Rechte prüfen (nur admin)
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($role, ['admin'], true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // GET + POST kompatibel
        $data = $_GET + $_POST;

        // ID absichern (default 1)
        $id = (int)($data['id'] ?? 1);
        if ($id <= 0) {
            echo "Ungültige ID.";
            return;
        }

        // Radio-Daten laden
        $this->loadRadioData($id);

        if (empty($this->radioData)) {
            echo "Eintrag nicht gefunden.";
            return;
        }

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    /**
     * Lädt die Radio-Box Daten aus der Datenbank
     */
    private function loadRadioData(int $id): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT 
                etchat_radio_id,
                etchat_radio_horst,
                etchat_radio_port,
                etchat_radio_typ,
                etchat_radio_stream,
                etchat_radio_name,
                etchat_radio_color,
                etchat_radio_bit,
                etchat_radio_box,
                etchat_radio_player,
                etchat_on_air,
                etchat_system_titel_an,
                etchat_titel_an 
             FROM {$this->_prefix}etchat_radio_box 
             WHERE etchat_radio_id = :id"
        );
        $stmt->execute([':id' => $id]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->radioData = is_array($result) ? $result : [];
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate(?object $lang): void
    {
        // Template erwartet $feld[0] mit numerischen Indizes
        // Konvertiere assoziatives Array in numerisches Array
        $numericalData = [];
        
        if (!empty($this->radioData)) {
            $numericalData[0] = [
                $this->radioData['etchat_radio_id'] ?? 0,
                $this->radioData['etchat_radio_horst'] ?? '',
                $this->radioData['etchat_radio_port'] ?? '',
                $this->radioData['etchat_radio_typ'] ?? '',
                $this->radioData['etchat_radio_stream'] ?? '',
                $this->radioData['etchat_radio_name'] ?? '',
                $this->radioData['etchat_radio_color'] ?? '',
                $this->radioData['etchat_radio_bit'] ?? '',
                $this->radioData['etchat_radio_box'] ?? 0,
                $this->radioData['etchat_radio_player'] ?? 0,
                $this->radioData['etchat_on_air'] ?? 0,
                $this->radioData['etchat_system_titel_an'] ?? 0,
                $this->radioData['etchat_titel_an'] ?? 0
            ];
        }
        
        $feld = $numericalData;
        $csrfToken = $this->csrfToken;
        
        include __DIR__ . "/../../styles/admin_tpl/editRadioBox.tpl.html";
    }
}