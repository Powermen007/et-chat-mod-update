<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminMenusIndex extends DbConectionMaker
{
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_menus[0] ?? null;

        // Rollenprüfung (nur admin)
        $allowedRoles = ["admin"];
        $userRole = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Menü-Daten laden (mit Prepared Statement)
        $menuItems = $this->loadMenuItems();

        $this->dbObj->close();

        // Tabelle bauen
        $printMenuList = $this->buildMenuTable($menuItems);

        // Template anzeigen
        $this->renderTemplate($lang, $printMenuList);
    }

    private function loadMenuItems(): array
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id, menu, link_text, image_active, image, url, target, gewicht
             FROM {$this->_prefix}etchat_menu
             ORDER BY menu, gewicht"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return is_array($result) ? $result : [];
    }

    private function buildMenuTable(array $menuItems): string
    {
        if (empty($menuItems)) {
            return '<p>Keine Menüpunkte vorhanden.</p>';
        }

        $html = '<table border="1" cellpadding="5" cellspacing="0" class="menu-table">
            <thead>
                <tr>
                    <th>Link Name</th>
                    <th>URL</th>
                    <th>Fenster</th>
                    <th>Aktionen</th>
                    <th>Menu</th>
                    <th>Gewichtung</th>
                    <th>Bild</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($menuItems as $row) {
            $id = (int)($row['id'] ?? 0);
            $menu = (int)($row['menu'] ?? 0);
            $text = htmlspecialchars($row['link_text'] ?? '', ENT_QUOTES, 'UTF-8');
            $url = htmlspecialchars($row['url'] ?? '', ENT_QUOTES, 'UTF-8');
            $image = basename((string)($row['image'] ?? ''));
            $target = in_array($row['target'] ?? '', ['_top', '_blank'], true) ? $row['target'] : '_blank';
            $gewicht = (int)($row['gewicht'] ?? 0);
            $imgAktiv = (int)($row['image_active'] ?? 0);

            $ort = match($menu) {
                1 => 'Chat',
                2 => 'Index',
                3 => 'Banner',
                default => 'Unbekannt',
            };

            $urlShort = mb_strimwidth($url, 0, 75, '...', 'UTF-8');
            $fenster = ($target === '_top') ? 'Selbes Fenster' : 'Neues Fenster';

            $html .= '<tr>
                        <td><b>' . $text . '</b></td>
                        <td>' . $urlShort . '</td>
                        <td>' . htmlspecialchars($fenster, ENT_QUOTES, 'UTF-8') . '</td>
                        <td>
                            <a href="./?AdminEditMenu&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '">✏️Editieren</a><br><br>
                            <a href="./?AdminDeleteMenu&id=' . $id . '&csrf_token=' . urlencode($this->csrfToken) . '" onclick="return confirm(\'Wirklich löschen?\')">🗑 Löschen</a>
                         </td>
                        <td><i>' . htmlspecialchars($ort, ENT_QUOTES, 'UTF-8') . '</i></td>
                        <td>' . $gewicht . '</td>
                        <td>';
            
            if ($imgAktiv === 1 && $image !== '') {
                $html .= '<img height="30" src="img/menu/' . htmlspecialchars($image, ENT_QUOTES, 'UTF-8') . '" alt="">';
            }
            
            $html .= '</td>
                </tr>';
        }

        $html .= '</tbody></table>';
        return $html;
    }

    private function renderTemplate(?object $lang, string $printMenuList): void
    {
        $print_menu_list = $printMenuList;
        $csrfToken = $this->csrfToken;
        
        include_once("styles/admin_tpl/indexMenus.tpl.html");
    }
}