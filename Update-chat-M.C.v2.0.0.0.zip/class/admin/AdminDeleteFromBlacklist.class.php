<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteFromBlacklist extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_blacklist[0] ?? null;

        // Rollen prüfen
        $userPriv = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $allowedRoles = ["admin", "grafik", "chatwache", "co_admin"];
        
        if (!in_array($userPriv, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // CSRF Token prüfen
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$csrfKey] ?? '';
        $requestToken = (string)($_GET['csrf_token'] ?? '');
        
        if ($requestToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            echo "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            exit;
        }

        // ID absichern und löschen
        $id = (int)($_GET['id'] ?? 0);
        
        if ($id > 0) {
            $this->deleteBlacklistEntry($id);
        }

        $this->dbObj->close();

        // Redirect
        header("Location: ./?AdminBlacklistIndex");
        exit;
    }

    /**
     * Löscht einen Eintrag aus der Blacklist
     */
    private function deleteBlacklistEntry(int $id): void
    {
        try {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_blacklist WHERE etchat_blacklist_id = :id",
                [':id' => $id]
            );
        } catch (PDOException $e) {
            error_log("AdminDeleteFromBlacklist Fehler: " . $e->getMessage());
            // Fehler still behandeln, redirect trotzdem
        }
    }
}