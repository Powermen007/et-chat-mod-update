<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminCreateNewRoom extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // Sprache laden
        // -------------------------
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_rooms[0] ?? null;

        // -------------------------
        // Rollencheck
        // -------------------------
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $allowedRoles = ["admin", "co_admin"];
        
        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // CSRF prüfen
        // -------------------------
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';
        $requestToken = $_POST['csrf_token'] ?? '';
        
        if ($sessionToken === '' || $requestToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            echo "CSRF Fehler – Ungültige Anfrage.";
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // Eingaben holen und validieren
        // -------------------------
        $roomName = $this->validateRoomName($_POST['room'] ?? '');
        $roomPriv = $this->validateRoomPriv((int)($_POST['room_priv'] ?? 0));
        $roomPw   = trim($_POST['roompw'] ?? '');

        // -------------------------
        // Validierung
        // -------------------------
        if ($roomName === '') {
            echo "<p style='color:red;'>Raumname darf nicht leer sein.</p>";
            $this->dbObj->close();
            exit;
        }

        // Raumname auf 50 Zeichen begrenzen
        if (mb_strlen($roomName) > 50) {
            $roomName = mb_substr($roomName, 0, 50);
        }

        // Bei privatem Raum (3) muss ein Passwort vorhanden sein
        if ($roomPriv === 3 && $roomPw === '') {
            echo "<p style='color:red;'>Bei passwortgeschütztem Raum ist ein Passwort erforderlich.</p>";
            $this->dbObj->close();
            exit;
        }

        // Passwort auf 100 Zeichen begrenzen
        if ($roomPw !== '' && mb_strlen($roomPw) > 100) {
            $roomPw = mb_substr($roomPw, 0, 100);
        }

        // -------------------------
        // Prüfen ob Raum bereits existiert
        // -------------------------
        if ($this->roomExists($roomName)) {
            echo "<p style='color:red;'>Ein Raum mit dem Namen '{$roomName}' existiert bereits.</p>";
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // Insert in DB (mit oder ohne Passwort)
        // -------------------------
        try {
            if ($roomPriv === 3) {
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_rooms 
                     (etchat_roomname, etchat_room_goup, etchat_room_pw)
                     VALUES (:room, :priv, :pw)",
                    [
                        ':room' => $roomName,
                        ':priv' => $roomPriv,
                        ':pw'   => $roomPw
                    ]
                );
            } else {
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_rooms 
                     (etchat_roomname, etchat_room_goup)
                     VALUES (:room, :priv)",
                    [
                        ':room' => $roomName,
                        ':priv' => $roomPriv
                    ]
                );
            }
        } catch (PDOException $e) {
            error_log("AdminCreateNewRoom Fehler: " . $e->getMessage());
            echo "<p style='color:red;'>Fehler beim Erstellen des Raums.</p>";
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // DB schließen & Weiterleitung
        // -------------------------
        $this->dbObj->close();
        
        header("Location: ./?AdminRoomsIndex&saved=1");
        exit;
    }

    /**
     * Validiert den Raumnamen (nur erlaubte Zeichen)
     */
    private function validateRoomName(string $name): string
    {
        $name = trim($name);
        
        // Erlaubte Zeichen: Buchstaben, Zahlen, Leerzeichen, Bindestrich, Unterstrich
        // Deutsche Umlaute auch erlaubt
        $name = preg_replace('/[^a-zA-Z0-9äöüßÄÖÜ\s\-_]/u', '', $name);
        
        return $name;
    }

    /**
     * Validiert die Raum-Berechtigung
     * 0 = offen für alle (Gäste + registrierte)
     * 4 = alle registrierten Benutzer
     * 1 = Admins und Mods
     * 2 = nur Admins
     * 3 = passwortgeschützt
     */
    private function validateRoomPriv(int $priv): int
    {
        $allowed = [0, 1, 2, 3, 4];
        
        if (!in_array($priv, $allowed, true)) {
            return 0; // Default: öffentlich für alle
        }
        
        return $priv;
    }

    /**
     * Prüft ob ein Raum mit diesem Namen bereits existiert
     */
    private function roomExists(string $roomName): bool
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT COUNT(*) as cnt FROM {$this->_prefix}etchat_rooms 
             WHERE etchat_roomname = :name"
        );
        $stmt->execute([':name' => $roomName]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return ($result['cnt'] ?? 0) > 0;
    }
}