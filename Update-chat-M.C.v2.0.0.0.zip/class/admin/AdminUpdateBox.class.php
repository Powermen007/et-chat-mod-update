<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateBox extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_rooms[0] ?? null;

        // Eingaben (POST bevorzugt)
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // Berechtigung prüfen (nur admin)
        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');

        if ($role !== 'admin' || $id <= 0 || $token === '') {
            $this->showError($lang->error[0]->tagData ?? '❌ Zugriff verweigert');
            exit;
        }

        // CSRF prüfen
        if (!$this->isValidCsrfToken($token)) {
            $this->showError(($lang->error[0]->tagData ?? '❌ Fehler') . ' (CSRF)');
            exit;
        }

        // Eingaben holen
        $ueber = trim((string)($_POST['ueberschrift'] ?? ''));
        $cod = trim((string)($_POST['code'] ?? ''));

        if ($ueber === '' || $cod === '') {
            $this->showError($lang->error[0]->tagData ?? '❌ Überschrift und Inhalt sind Pflichtfelder');
            exit;
        }

        try {
            $pdo = $this->dbObj->getConnection();

            $stmt = $pdo->prepare("
                UPDATE {$this->_prefix}etchat_start_boxes
                SET header_text = :header_text,
                    content = :content
                WHERE id = :id
            ");

            $stmt->execute([
                ':header_text' => $ueber,
                ':content' => $cod,
                ':id' => $id
            ]);

            $this->dbObj->close();

            // Erfolgsmeldung in Session speichern
            $_SESSION['box_update_success'] = true;
            header("Location: ./?AdminBoxsIndex");
            exit;

        } catch (PDOException $e) {
            error_log("AdminUpdateBox Fehler: " . $e->getMessage());
            $this->showError($lang->error[0]->tagData ?? '❌ Datenbankfehler beim Speichern');
            exit;
        }
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        $sessionToken = $_SESSION[$key] ?? '';
        return $sessionToken !== '' && hash_equals($sessionToken, $token);
    }

    private function showError(string $message): void
    {
        echo '<div class="error" style="color: red; background: #ffebee; padding: 15px; border-radius: 5px; margin: 20px;">
                ❌ ' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '
              </div>';
        echo '<p><a href="./?AdminBoxsIndex" class="admin-button">⬅️ Zurück zur Box-Übersicht</a></p>';
    }
}