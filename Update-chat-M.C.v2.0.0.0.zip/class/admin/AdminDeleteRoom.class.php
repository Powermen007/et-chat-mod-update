<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteRoom extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_rooms[0] ?? null;

        // Rollen prüfen
        $allowedRoles = ["admin", "co_admin"];
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        
        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // GET + POST vorbereiten
        $data = $_GET + $_POST;

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $sessionToken = $_SESSION[$csrfKey];

        // ID absichern
        $id = (int)($data['id'] ?? 0);
        $requestToken = (string)($data['csrf_token'] ?? '');

        // ID Prüfung
        if ($id <= 0) {
            $this->dbObj->close();
            header("Location: ./?AdminRoomsIndex");
            exit;
        }

        // CSRF Prüfung
        if ($requestToken === '' || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            echo "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            exit;
        }

        // Raum löschen
        $this->deleteRoom($id);

        $this->dbObj->close();

        // Redirect
        header("Location: ./?AdminRoomsIndex");
        exit;
    }

    /**
     * Löscht einen Raum aus der Datenbank
     */
    private function deleteRoom(int $id): void
    {
        try {
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_rooms WHERE etchat_id_room = :id",
                [':id' => $id]
            );
        } catch (PDOException $e) {
            error_log("AdminDeleteRoom Fehler: " . $e->getMessage());
            // Fehler still behandeln, redirect trotzdem
        }
    }
}