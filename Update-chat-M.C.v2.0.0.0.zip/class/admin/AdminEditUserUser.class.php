<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditUserUser extends DbConectionMaker
{
    private const ALLOWED_ROLES = ['admin', 'chatwache', 'co_admin'];
    private string $csrfToken = '';
    private array $userData = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache
        $lang = (new LangXml())->getLang()->admin[0]->admin_user[0] ?? null;

        // Rechte prüfen
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($role, self::ALLOWED_ROLES, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // CSRF Token (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // ID validieren
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            echo 'Ungültige ID.';
            return;
        }

        // User-Daten laden
        $this->loadUserData($id);

        if (empty($this->userData)) {
            echo 'User nicht gefunden.';
            return;
        }

        $this->dbObj->close();

        // Template anzeigen
        $this->renderTemplate($lang);
    }

    /**
     * Lädt die User-Daten aus der Datenbank
     */
    private function loadUserData(int $id): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien, etchat_email 
             FROM {$this->_prefix}etchat_user 
             WHERE etchat_user_id = :id"
        );
        $stmt->execute([':id' => $id]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->userData = is_array($result) ? $result : [];
    }

    /**
     * Rendert das Template
     */
    private function renderTemplate(?object $lang): void
    {
        // Template erwartet $feld[0] mit numerischen Indizes
        $numericalData = [];
        
        if (!empty($this->userData)) {
            $numericalData[0] = [
                $this->userData['etchat_user_id'] ?? 0,
                $this->userData['etchat_username'] ?? '',
                $this->userData['etchat_userpw'] ?? '',
                $this->userData['etchat_userprivilegien'] ?? '',
                $this->userData['etchat_email'] ?? ''
            ];
        }
        
        $feld = $numericalData;
        $csrfToken = $this->csrfToken;
        
        include_once("styles/admin_tpl/editUserUser.tpl.html");
    }
}