<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Colorizer extends EtChatConfig
{
    public object|string|null $lang = null;

    public function __construct()
    {
        parent::__construct();

        // Session starten, falls noch nicht gestartet
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Header setzen, falls noch nichts gesendet
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Content-Type: text/html; charset=utf-8');
        }

        // Sprache laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();

        if (isset($langData->farben_fenster_php[0])) {
            $this->lang = $langData->farben_fenster_php[0];
        }

        // Template einbinden
        $template = dirname(__DIR__) . "/styles/colorizer.tpl.html";

        if (is_file($template)) {
            include $template;
        } else {
            throw new RuntimeException("Template colorizer.tpl.html nicht gefunden.");
        }
    }
}