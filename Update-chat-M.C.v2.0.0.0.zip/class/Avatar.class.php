<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Avatar extends DbConectionMaker
{
    private string $tempDir = 'avatar/temp';
    private string $avatarDir = 'avatar';
    private array $accepted = ['png', 'jpg', 'jpeg', 'gif', 'webp'];

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Content-Type: text/html; charset=utf-8');

        $task = $_POST['task'] ?? '';
        $userId = (int)($_POST['userid'] ?? 0);

        if ($task === "insert") {
            $this->insertAvatar($userId);
        }

        if ($task === "delete") {
            $this->deleteAvatar($userId);
        }
    }

    /* -------------------------------------------------- */
    /* AVATAR INSERT */
    /* -------------------------------------------------- */

    private function insertAvatar(int $userId): void
    {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            return;
        }

        // 🔄 ASSOZIATIVER INDEX
        $avatarfile = $this->dbObj->sqlGet(
            "SELECT etchat_avatar, etchat_username 
             FROM {$this->_prefix}etchat_user 
             WHERE etchat_user_id = :user_id",
            [':user_id' => $userId]
        );

        if (!$avatarfile || empty($avatarfile[0])) {
            return;
        }

        $currentAvatar = $avatarfile[0]['etchat_avatar'] ?? '';
        $username = $avatarfile[0]['etchat_username'] ?? '';
        
        if (empty($username)) {
            return;
        }

        $protectedAvatars = ['noavatar.jpg', 'mod_ohne_pic.png', 'autodj.jpg'];
        
        if (!in_array($currentAvatar, $protectedAvatars, true) && !empty($currentAvatar)) {
            $delfile = $this->avatarDir . "/" . basename($currentAvatar);
            if (file_exists($delfile)) {
                @unlink($delfile);
            }
        }

        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $this->accepted, true)) {
            return;
        }

        // Temporäre Verzeichnisse erstellen falls nicht vorhanden
        if (!is_dir($this->tempDir)) {
            mkdir($this->tempDir, 0755, true);
        }
        if (!is_dir($this->avatarDir)) {
            mkdir($this->avatarDir, 0755, true);
        }

        $newname = $username . '-' . time() . '.' . $ext;
        $newname = preg_replace('/[^a-zA-Z0-9\-_.]/', '', $newname); // Sicherheitshalber

        move_uploaded_file(
            $_FILES['file']['tmp_name'],
            $this->tempDir . '/' . $newname
        );

        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_user 
             SET etchat_avatar = :avatar 
             WHERE etchat_user_id = :user_id",
            [':avatar' => $newname, ':user_id' => $userId]
        );

        $this->resizeAvatar($newname);
    }

    /* -------------------------------------------------- */
    /* AVATAR DELETE */
    /* -------------------------------------------------- */

    private function deleteAvatar(int $userId): void
    {
        // 🔄 ASSOZIATIVER INDEX
        $avatarfile = $this->dbObj->sqlGet(
            "SELECT etchat_avatar 
             FROM {$this->_prefix}etchat_user 
             WHERE etchat_user_id = :user_id",
            [':user_id' => $userId]
        );

        if (!$avatarfile || empty($avatarfile[0])) {
            return;
        }

        $currentAvatar = $avatarfile[0]['etchat_avatar'] ?? '';
        $protectedAvatars = ['noavatar.jpg', 'mod_ohne_pic.png', 'autodj.jpg'];

        if (!in_array($currentAvatar, $protectedAvatars, true) && !empty($currentAvatar)) {
            $delfile = $this->avatarDir . "/" . basename($currentAvatar);
            if (file_exists($delfile)) {
                @unlink($delfile);
            }

            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_user 
                 SET etchat_avatar = 'noavatar.jpg'
                 WHERE etchat_user_id = :user_id",
                [':user_id' => $userId]
            );
        }
    }

    /* -------------------------------------------------- */
    /* IMAGE RESIZE (verbessert) */
    /* -------------------------------------------------- */

    private function resizeAvatar(string $filename): void
    {
        $filepath_old = $this->tempDir . '/' . $filename;
        $filepath_new = $this->avatarDir . '/' . $filename;

        if (!is_file($filepath_old)) {
            return;
        }

        $image_dimension = 100;

        $image_attributes = getimagesize($filepath_old);

        if (!$image_attributes) {
            return;
        }

        [$width_old, $height_old, $type] = $image_attributes;

        if ($width_old <= 0 || $height_old <= 0) {
            return;
        }

        $ratio = $width_old / $height_old;

        if ($ratio > 1) {
            $width_new = $image_dimension;
            $height_new = (int)round($image_dimension / $ratio);
        } else {
            $height_new = $image_dimension;
            $width_new = (int)round($image_dimension * $ratio);
        }

        // Mindestens 1x1 Pixel
        $width_new = max(1, $width_new);
        $height_new = max(1, $height_new);

        $image_new = imagecreatetruecolor($width_new, $height_new);
        
        // Transparenz erhalten (für PNG und GIF)
        $transparent = imagecolorallocatealpha($image_new, 0, 0, 0, 127);
        imagefill($image_new, 0, 0, $transparent);
        imagesavealpha($image_new, true);

        switch ($type) {
            case IMAGETYPE_GIF:
                $image_old = imagecreatefromgif($filepath_old);
                if (!$image_old) return;
                imagecopyresampled($image_new, $image_old, 0, 0, 0, 0, $width_new, $height_new, $width_old, $height_old);
                imagegif($image_new, $filepath_new);
                break;

            case IMAGETYPE_JPEG:
                $image_old = imagecreatefromjpeg($filepath_old);
                if (!$image_old) return;
                imagecopyresampled($image_new, $image_old, 0, 0, 0, 0, $width_new, $height_new, $width_old, $height_old);
                imagejpeg($image_new, $filepath_new, 85);
                break;

            case IMAGETYPE_PNG:
                $image_old = imagecreatefrompng($filepath_old);
                if (!$image_old) return;
                imagecopyresampled($image_new, $image_old, 0, 0, 0, 0, $width_new, $height_new, $width_old, $height_old);
                imagepng($image_new, $filepath_new, 6);
                break;

            case IMAGETYPE_WEBP:
                $image_old = imagecreatefromwebp($filepath_old);
                if (!$image_old) return;
                imagecopyresampled($image_new, $image_old, 0, 0, 0, 0, $width_new, $height_new, $width_old, $height_old);
                imagewebp($image_new, $filepath_new, 80);
                break;

            default:
                return;
        }

        if (isset($image_old)) {
            imagedestroy($image_old);
        }
        imagedestroy($image_new);

        if (is_file($filepath_old)) {
            unlink($filepath_old);
        }
    }
}