<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class RoomEntrance extends EtChatConfig
{
    private $dbObj;
    private $_lang;

    public function __construct($dbObj, $lang)
    {
        parent::__construct();

        $this->dbObj = $dbObj;
        $this->_lang = $lang;

        $sql = "SELECT etchat_room_message 
                FROM {$this->_prefix}etchat_rooms 
                WHERE etchat_id_room = :room_id";

        $room_message = $this->dbObj->sqlGet($sql, [
            ':room_id' => 1
        ]);

        $priv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        $_SESSION['etchat_' . $this->_prefix . 'invisible_on_enter'] =
            (!empty($_POST['status_invisible']) && $priv === 'admin');

        if (empty($room_message[0]['etchat_room_message'] ?? '')) {
            $this->withoutRoomMessage();
        } else {
            $this->withRoomMessage($room_message[0]['etchat_room_message']);
        }

        $_SESSION['etchat_' . $this->_prefix . 'last_id'] = 0;
    }

    private function withoutRoomMessage()
    {
        $an = $_SESSION['etchat_' . $this->_prefix . 'invisible_on_enter']
            ? ($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0)
            : 0;

        $user_color2 = $this->getUserColor($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        $avataricon = $this->getAvatarIcon();
        $username = $_SESSION['etchat_' . $this->_prefix . 'username'] ?? '';
        $username_with_color = "<span style=\"$user_color2\">" . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . "</span>";

        $sysMessObj = new SysMessage(
            $this->dbObj,
            $avataricon . " <b>" . $username_with_color . "</b> " . $this->_lang->eintritt[0]->tagData,
            0,
            $an
        );

        $_SESSION['etchat_' . $this->_prefix . 'my_first_mess_id'] = $sysMessObj->lastInsertedId;
    }

    private function withRoomMessage($room_message)
    {
        $an = $_SESSION['etchat_' . $this->_prefix . 'invisible_on_enter']
            ? ($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0)
            : 0;

        $user_color2 = $this->getUserColor($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');
        $avataricon = $this->getAvatarIcon();
        $username = $_SESSION['etchat_' . $this->_prefix . 'username'] ?? '';
        $username_with_color = "<span style=\"$user_color2\">" . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . "</span>";

        $room_message_insert = nl2br(htmlspecialchars($room_message, ENT_QUOTES, 'UTF-8'));

        $sysMessObj = new SysMessage(
            $this->dbObj,
            "<br /><div style=\"margin: 4px;\">" . $room_message_insert . "</div>",
            1,
            $_SESSION['etchat_' . $this->_prefix . 'user_id']
        );

        $_SESSION['etchat_' . $this->_prefix . 'my_first_mess_id'] = $sysMessObj->lastInsertedId;

        new SysMessage(
            $this->dbObj,
            $avataricon . " <b>" . $username_with_color . "</b> " . $this->_lang->eintritt[0]->tagData,
            0,
            $an
        );
    }

    private function getUserColor($priv)
    {
        switch ($priv) {
            case 'admin':
            case 'grafik':
            case 'chatwache':
            case 'co_admin':
                return "color: " . ($_SESSION['etchat_' . $this->_prefix . 'admin_color'] ?? '#ff0000');
            case 'mod':
                return "color: " . ($_SESSION['etchat_' . $this->_prefix . 'mod_color'] ?? '#00aaff');
            case 'user':
                return "color: " . ($_SESSION['etchat_' . $this->_prefix . 'user_color'] ?? '#cccccc');
            case 'gast':
                return "color: " . ($_SESSION['etchat_' . $this->_prefix . 'gast_color'] ?? '#ffff00');
            default:
                return "color: #ffffff";
        }
    }

    private function getAvatarIcon()
    {
        if (($_SESSION['etchat_' . $this->_prefix . 'chat_pic'] ?? '0') === '1') {
            $username = $_SESSION['etchat_' . $this->_prefix . 'username'] ?? '';

            if (empty($username)) {
                return "";
            }

            $sql = "SELECT etchat_avatar 
                    FROM {$this->_prefix}etchat_user 
                    WHERE etchat_username = :username
                    LIMIT 1";

            $avatar = $this->dbObj->sqlGet($sql, [':username' => $username]);

            // 🔄 Sicherer Zugriff mit Fallback
            $avatar1 = is_array($avatar) && isset($avatar[0]['etchat_avatar']) 
                ? $avatar[0]['etchat_avatar'] 
                : '';

            if (empty($avatar1)) {
                return "";
            }

            $avatarPath = 'avatar/' . htmlspecialchars($avatar1, ENT_QUOTES, 'UTF-8');
            
            // 🔄 Prüfen ob Datei existiert
            if (!is_file($avatarPath)) {
                return "";
            }

            return '<img src="' . $avatarPath . '"
                    class="avatar_w"
                    alt=""
                    title=""
                    loading="lazy">';
        }

        return "";
    }
}