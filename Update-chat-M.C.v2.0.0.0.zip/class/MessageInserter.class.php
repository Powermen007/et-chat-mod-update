<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class MessageInserter extends EtChatConfig
{
    private $dbObj;
    public $status = null;

    public function __construct($dbObj, $raum_array)
    {
        parent::__construct();
        $this->dbObj = $dbObj;

        /* ===== PHP 8 Absicherung ===== */
        $_POST["roomchange"] = $_POST["roomchange"] ?? "";
        $_POST["message"] = $_POST["message"] ?? "";
        $_POST["room"] = (int)($_POST["room"] ?? 0);
        $_POST["privat"] = (int)($_POST["privat"] ?? 0);
        $_POST["color"] = $_POST["color"] ?? "";
        $_POST["bold"] = $_POST["bold"] ?? "";
        $_POST["italic"] = $_POST["italic"] ?? "";

        $_SESSION["etchat_" . $this->_prefix . "spam"] = $_SESSION["etchat_" . $this->_prefix . "spam"] ?? [];
        $_SESSION["etchat_" . $this->_prefix . "spam_warn"] = $_SESSION["etchat_" . $this->_prefix . "spam_warn"] ?? 0;
        $_SESSION["etchat_" . $this->_prefix . "chek_user_ajax_getted_data"] = $_SESSION["etchat_" . $this->_prefix . "chek_user_ajax_getted_data"] ?? [];
        /* =============================== */

        // 🔄 ASSOZIATIVER INDEX
        $roomMessage = $raum_array[0]['etchat_room_message'] ?? '';
        
        if (isset($_POST["roomchange"]) && $_POST["roomchange"] == "true" && !empty($roomMessage)) {
            $room_message_insert = str_replace(["\r\n", "\n"], "<br />", $roomMessage);
            new SysMessage(
                $this->dbObj,
                "<br /><div style=\"margin: 4px;\">" . $room_message_insert . "<div>",
                (int) $_POST["room"],
                $_SESSION["etchat_" . $this->_prefix . "user_id"]
            );
        }

        if (isset($_POST["sysmess"])) {
            if ($this->spamTester()) {
                $this->status = "spam";
                return;
            }

            if (!in_array($_POST["message"], $_SESSION["etchat_" . $this->_prefix . "chek_user_ajax_getted_data"])) {
                return;
            }

            if ($_POST["roomchange"] == "true") {
                // 🔄 ASSOZIATIVER INDEX
                $raum_name = $this->dbObj->sqlGet(
                    "SELECT etchat_roomname FROM {$this->_prefix}etchat_rooms WHERE etchat_id_room = ?",
                    [(int) $_POST["room"]]
                );
                $roomName = $raum_name[0]['etchat_roomname'] ?? '';
                $_POST["message"] = $_POST["message"] . " " . $roomName;
            }

            $_POST["message"] = htmlspecialchars($_POST["message"], ENT_QUOTES, "UTF-8");
            $_POST["message"] = "<b>" . $_SESSION["etchat_" . $this->_prefix . "username"] . "</b> " . $_POST["message"];

            if ($_POST["roomchange"] == "true" && ($_SESSION["etchat_" . $this->_prefix . "userstatus"] ?? '') == "status_invisible") {
                $_POST["privat"] = $_SESSION["etchat_" . $this->_prefix . "user_id"];
            } else {
                if ($_POST["privat"] > 0) {
                    $_POST["privat"] = $_SESSION["etchat_" . $this->_prefix . "user_id"];
                }
            }

            new SysMessage($this->dbObj, $_POST["message"], (int) $_POST["room"], (int) $_POST["privat"]);
        } else {
            if ($this->spamTester()) {
                $this->status = "spam";
                return;
            }

            $this->messageTransformer();

            $_POST["color"] = substr($_POST["color"], 0, 7);
            $_POST["bold"] = substr($_POST["bold"], 0, 6);
            $_POST["italic"] = substr($_POST["italic"], 0, 6);

            $style = "color:" . htmlentities($_POST["color"], ENT_QUOTES, "UTF-8") .
                     ";font-weight:" . htmlentities($_POST["bold"], ENT_QUOTES, "UTF-8") .
                     ";font-style:" . htmlentities($_POST["italic"], ENT_QUOTES, "UTF-8") . ";";

            // Prüfen, ob es sich um einen Bot-/Systembefehl handelt
            $isCommand = preg_match("/^\\.(hallo|bye|time|version|chatregeln|reg)/i", $_POST["message"]);
            
            if (!$isCommand) {
                // ✅ SICHER MIT PREPARED STATEMENT
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_messages (
                        etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat, etchat_user_ip
                    ) VALUES (
                        :user_id, :message, :style, :timestamp, :room, :privat, :ip
                    )",
                    [
                        ':user_id' => $_SESSION["etchat_" . $this->_prefix . "user_id"],
                        ':message' => $_POST["message"],
                        ':style' => $style,
                        ':timestamp' => time(),
                        ':room' => (int) $_POST["room"],
                        ':privat' => (int) $_POST["privat"],
                        ':ip' => $_SERVER["REMOTE_ADDR"] ?? ''
                    ]
                );
            }

            // ---- CHATBOT START ------------------------------------------------------
            $botEnabled = (int) ($_SESSION["etchat_" . $this->_prefix . "etchat_bot"] ?? 0);

            if ($botEnabled && !$isCommand) {
                $messageText = strtolower($_POST["message"]);

                if (preg_match("/\b(bot|chatbot|caht-bot|ChatBot)\b/i", $messageText)) {
                    $jsonFile = dirname(__DIR__, 1) . "/cache/bot_answers.json";
                    $botAnswers = ["Ich bin kaputt… bitte mein JSON reparieren!"];

                    if (file_exists($jsonFile)) {
                        $botAnswers = json_decode(file_get_contents($jsonFile), true);
                        if (!is_array($botAnswers) || empty($botAnswers)) {
                            $botAnswers = ["Ich bin kaputt… bitte mein JSON reparieren!"];
                        }
                    }

                    $reply = $botAnswers[array_rand($botAnswers)];
                    $botStyle = "color:var(--Botfarbe);font-weight:normal;font-style:italic;";

                    usleep(rand(100000, 500000));

                    // ✅ SICHER MIT PREPARED STATEMENT
                    $this->dbObj->sqlSet(
                        "INSERT INTO {$this->_prefix}etchat_messages
                        (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                        VALUES (-1, :reply, :style, :timestamp, :room, 0)",
                        [
                            ':reply' => $reply,
                            ':style' => $botStyle,
                            ':timestamp' => time(),
                            ':room' => (int) $_POST["room"]
                        ]
                    );
                }
            }
            // ---- CHATBOT ENDE ------------------------------------------------------

            // BOT Befehle (.hallo, .bye, .time, .version, .chatregeln, .reg)
            $cmd = "";
            if (substr($_POST["message"], 0, 6) == ".hallo") $cmd = "hallo";
            elseif (substr($_POST["message"], 0, 4) == ".bye") $cmd = "bye";

            if ($cmd !== "") {
                $file_map = [
                    "hallo" => "./cache/anreden.txt",
                    "bye" => "./cache/verabschieden.txt",
                ];
                $txt_file = __DIR__ . "/" . $file_map[$cmd];

                if (file_exists($txt_file)) {
                    $lines = file($txt_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                    $texte = array_map("trim", $lines);
                } else {
                    $texte = $cmd === "hallo" ? ["Hallo", "Hi", "Servus", "Grüß dich"] : ["Tschüss", "Ciao", "Mach's gut", "Bis bald"];
                }

                $aktueller_user = $_SESSION["etchat_" . $this->_prefix . "username"] ?? "";
                $aktueller_user_norm = mb_strtolower(trim($aktueller_user), "UTF-8");

                // 🔄 ASSOZIATIVER INDEX
                $rows = $this->dbObj->sqlGet("SELECT etchat_user_online_user_name FROM {$this->_prefix}etchat_useronline");
                if (!is_array($rows)) $rows = [];

                $teile = [];
                foreach ($rows as $row) {
                    $user = trim($row['etchat_user_online_user_name'] ?? '');
                    if (mb_strtolower($user, "UTF-8") === $aktueller_user_norm) continue;

                    $text = $texte[array_rand($texte)];
                    $user_html = htmlspecialchars($user, ENT_QUOTES, "UTF-8");
                    $teile[] = "$text <span style=\"font-weight:bold; background-color:#ffff0052; padding:2px; border-radius:3px;\">$user_html</span>";
                }

                if (!empty($teile)) {
                    if ($cmd === "hallo") {
                        $schluss = count($teile) === 1 ? "! Schön, dass du online bist." : "! Schön, dass ihr online seid.";
                    } else {
                        $schluss = count($teile) === 1 ? "! Mach's gut." : "! Schön, mit euch gechattet zu haben.";
                    }

                    $nachricht = implode(", ", $teile) . $schluss;

                    // ✅ SICHER MIT PREPARED STATEMENT
                    $this->dbObj->sqlSet(
                        "INSERT INTO {$this->_prefix}etchat_messages
                        (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                        VALUES (:user_id, :message, :style, :timestamp, :room, 0)",
                        [
                            ':user_id' => $_SESSION["etchat_" . $this->_prefix . "user_id"],
                            ':message' => $nachricht,
                            ':style' => "color:#" . ($_SESSION["etchat_" . $this->_prefix . "syscolor"] ?? "00ff02") . ";font-weight:normal;font-style:normal;",
                            ':timestamp' => time(),
                            ':room' => (int) $_POST["room"]
                        ]
                    );
                }
            }

            if (substr($_POST["message"], 0, 5) == ".time") {
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_messages
                    (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                    VALUES (1, :message, :style, :timestamp, :room, 0)",
                    [
                        ':message' => date("d.m.Y - H:i"),
                        ':style' => "color:#" . ($_SESSION["etchat_" . $this->_prefix . "syscolor"] ?? "00ff02") . ";font-weight:normal;font-style:normal;",
                        ':timestamp' => time(),
                        ':room' => (int) $_POST["room"]
                    ]
                );
            }

            if (substr($_POST["message"], 0, 8) == ".version") {
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_messages
                    (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                    VALUES (1, :message, :style, :timestamp, :room, 0)",
                    [
                        ':message' => 'ET-Chat v3.0.7 r3 / M.C.v.2.0.0.0',
                        ':style' => "color:#" . ($_SESSION["etchat_" . $this->_prefix . "syscolor"] ?? "00ff02") . ";font-weight:normal;font-style:normal;",
                        ':timestamp' => time(),
                        ':room' => (int) $_POST["room"]
                    ]
                );
            }

            $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? "";
            $allowedRoles = ["admin", "mod", "co_admin", "grafik", "chatwache"];

            if (substr($_POST["message"], 0, 11) == ".chatregeln" && in_array($role, $allowedRoles)) {
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_messages
                    (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                    VALUES (1, :message, :style, :timestamp, :room, 0)",
                    [
                        ':message' => '<center><iframe src="?Text&id=4" width="70%" height="350px" max-hight="50vh"></iframe></center>',
                        ':style' => "color:#" . ($_SESSION["etchat_" . $this->_prefix . "syscolor"] ?? "00ff02") . ";font-weight:normal;font-style:normal;",
                        ':timestamp' => time(),
                        ':room' => (int) $_POST["room"]
                    ]
                );
            }

            if (substr($_POST["message"], 0, 4) == ".reg" && in_array($role, $allowedRoles)) {
                $this->dbObj->sqlSet(
                    "INSERT INTO {$this->_prefix}etchat_messages
                    (etchat_user_fid, etchat_text, etchat_text_css, etchat_timestamp, etchat_fid_room, etchat_privat)
                    VALUES (1, :message, :style, :timestamp, :room, 0)",
                    [
                        ':message' => '<center><iframe src="?Text&id=3" width="70%" height="250px" max-hight="50vh"></iframe></center>',
                        ':style' => "color:#" . ($_SESSION["etchat_" . $this->_prefix . "syscolor"] ?? "00ff02") . ";font-weight:normal;font-style:normal;",
                        ':timestamp' => time(),
                        ':room' => (int) $_POST["room"]
                    ]
                );
            }
        }
    }

    private function messageTransformer()
    {
        $_POST["message"] = substr($_POST["message"], 0, 1000);
        if (strlen($_POST["message"]) > 999) {
            $_POST["message"] .= "...";
        }

        $woerter_array = explode(" ", $_POST["message"]);
        foreach ($woerter_array as $wort) {
            if (strlen($wort) > 50 && 
                substr($wort, 0, 7) != "http://" && 
                substr($wort, 0, 8) != "https://" && 
                substr($wort, 0, 6) != "ftp://" && 
                stripos($wort, "]http://") === false && 
                stripos($wort, "]https://") === false) {
                $new_wort = wordwrap($wort, 50, " ", 1);
                $_POST["message"] = str_replace($wort, $new_wort, $_POST["message"]);
            }
        }
        $_POST["message"] = htmlspecialchars(str_replace("\\", "\\\\", $_POST["message"]), ENT_QUOTES, "UTF-8");
    }

    private function spamTester()
    {
        $_SESSION["etchat_" . $this->_prefix . "spam"][] = time();
        if (count($_SESSION["etchat_" . $this->_prefix . "spam"]) > 200) {
            unset($_SESSION["etchat_" . $this->_prefix . "spam"]);
            $_SESSION["etchat_" . $this->_prefix . "spam"] = [];
        }
        
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? null;
        $excludedRoles = ["admin", "mod", "chatwache", "co_admin"];

        if (count($_SESSION["etchat_" . $this->_prefix . "spam"]) > 3 && !in_array($role, $excludedRoles, true)) {
            $spamCount = count($_SESSION["etchat_" . $this->_prefix . "spam"]);
            $spam_interval = $_SESSION["etchat_" . $this->_prefix . "spam"][$spamCount - 1] - $_SESSION["etchat_" . $this->_prefix . "spam"][$spamCount - 4];
            
            if ($spam_interval < 6) {
                $langObj = new LangXml();
                $lang = $langObj->getLang()->reloader_php[0];
                new SysMessage(
                    $this->dbObj,
                    $lang->spam[0]->tagData ?? "Spam erkannt!",
                    (int) $_POST["room"],
                    (int) $_SESSION["etchat_" . $this->_prefix . "user_id"]
                );
                $_SESSION["etchat_" . $this->_prefix . "spam_warn"]++;
                
                if ($_SESSION["etchat_" . $this->_prefix . "spam_warn"] > 2) {
                    $blObj = new Blacklist($this->dbObj);
                    $blObj->insertUser($_SESSION["etchat_" . $this->_prefix . "user_id"], 300);
                    $blObj->userInBlacklist();
                    $blObj->allowedToAndSetCookie();
                    $blObj->killUserSession();
                    return true;
                }
                return false;
            }
        }
        return false;
    }
}
?>