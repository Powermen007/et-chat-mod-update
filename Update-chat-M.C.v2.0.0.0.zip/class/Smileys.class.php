<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Smileys extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");

        $cats = $this->dbObj->sqlGet(
            "SELECT name, gewicht
             FROM {$this->_prefix}etchat_smileys_cat
             WHERE aktiv LIKE 'on'
             ORDER BY gewicht ASC"
        );

        echo "<ul class=\"ul_cat\">";

        if (!empty($cats)) {

            foreach ($cats as $cat) {
                // 🔄 ASSOZIATIVER INDEX
                $catName = $cat['name'] ?? '';
                $name    = htmlspecialchars($catName, ENT_QUOTES, 'UTF-8');
                $id      = preg_replace('/[^a-zA-Z0-9_-]/', '_', $catName);

                echo "<li class=\"cat\">&#x2007;
                        <a href=\"#\" onclick=\"openCat(event, '{$id}'); return false;\" class=\"tablinks\">{$name}</a>
                      &#x2007;</li>";
            }
        }

        echo "</ul>";
        echo "<hr><div class=\"items\">";

        if (!empty($cats)) {

            foreach ($cats as $cat) {

                $catName = $cat['name'] ?? '';
                $id      = preg_replace('/[^a-zA-Z0-9_-]/', '_', $catName);

                $smileys = $this->dbObj->sqlGet(
                    "SELECT etchat_smileys_kat, etchat_smileys_sign, etchat_smileys_img, etchat_smileys_gewicht
                     FROM {$this->_prefix}etchat_smileys
                     WHERE etchat_smileys_kat = :kat
                     ORDER BY etchat_smileys_gewicht ASC, etchat_smileys_img ASC",
                    [":kat" => $catName]
                );

                echo "<div id=\"{$id}\" class=\"tabcontent\">";

                if (empty($smileys)) {
                    echo "Keine Smileys in dieser Kategorie vorhanden.";
                } else {
                    foreach ($smileys as $smil) {
                        // 🔄 ASSOZIATIVE INDIZES
                        $sign = htmlspecialchars($smil['etchat_smileys_sign'] ?? '', ENT_QUOTES, 'UTF-8');
                        $img  = htmlspecialchars($smil['etchat_smileys_img'] ?? '', ENT_QUOTES, 'UTF-8');

                        echo "
                        <div style='display:inline-block; text-align:center; margin:5px;'>
                            <img class='img_smiley' data-src='{$img}' id='{$sign}' style='cursor:pointer; display:block; margin:0 auto;' src='img/loading.gif'>
                            <div style='border:1px solid #ccc; padding:2px 4px; margin-top:5px;'>{$sign}</div>
                        </div>";
                    }
                }

                echo "</div>";
            }
        }

        echo "</div>";
        $this->dbObj->close();
    }
}