<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

// config.php laden
$configPath = __DIR__ . "/../config.php";
if (file_exists($configPath)) {
    require_once $configPath;
}

// PHPMailer einbinden
$phpmailerPath = __DIR__ . "/../PHPMailer/src/PHPMailer.php";
if (file_exists($phpmailerPath)) {
    require_once $phpmailerPath;
    require_once __DIR__ . "/../PHPMailer/src/SMTP.php";
    require_once __DIR__ . "/../PHPMailer/src/Exception.php";
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class ChangePw extends DbConectionMaker
{
    private const REGISTER_COOLDOWN_HOURS = 12;

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);

        if ($userId <= 0) {
            echo "No Session";
            $this->dbObj->close();
            return;
        }

        $userData = $this->dbObj->sqlGet("
            SELECT etchat_userprivilegien, etchat_reg_timestamp, etchat_reg_ip, etchat_username
            FROM {$this->_prefix}etchat_user
            WHERE etchat_user_id = :user_id
        ", [':user_id' => $userId]);

        if (empty($userData)) {
            echo "User not found";
            $this->dbObj->close();
            return;
        }

        $priv = $userData[0]['etchat_userprivilegien'] ?? '';
        $username = $userData[0]['etchat_username'] ?? '';

        if (!in_array($priv, ['admin', 'mod', 'user', 'gast'], true)) {
            echo "Permission denied";
            $this->dbObj->close();
            return;
        }

        // ==============================
        // Passwort ändern (normal)
        // ==============================
        if (!empty($_POST['modpw'])) {
            $newPw = trim($_POST['modpw']);

            if (!$this->validatePassword($newPw)) {
                $this->dbObj->close();
                echo "Passwort muss mindestens 8 Zeichen lang sein und 3 der 4 Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.";
                return;
            }

            $hash = password_hash($newPw, PASSWORD_DEFAULT);

            $this->dbObj->sqlSet("
                UPDATE {$this->_prefix}etchat_user
                SET etchat_userpw = :hash
                WHERE etchat_user_id = :user_id
            ", [
                ':hash' => $hash,
                ':user_id' => $userId
            ]);

            echo "1";
            $this->dbObj->close();
            return;
        }

        // ==============================
        // Gast -> interne Registrierung
        // ==============================
        if ($priv === "gast" && !empty($_POST['user_pw'])) {

            $currentIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

            $cooldownError = $this->checkRegistrationCooldownByIp($currentIp);
            if ($cooldownError !== null) {
                echo $cooldownError;
                $this->dbObj->close();
                return;
            }

            $newPw = trim($_POST['user_pw']);
            $email = trim($_POST['email'] ?? '');

            if (!$this->validatePassword($newPw)) {
                $this->dbObj->close();
                echo "Passwort muss mindestens 8 Zeichen lang sein und 3 der 4 Kriterien enthalten: Großbuchstaben, Kleinbuchstaben, Zahlen, Sonderzeichen.";
                return;
            }

            $hasEmail = ($email !== '');
            if ($hasEmail && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "Ungültige E-Mail-Adresse.";
                $this->dbObj->close();
                return;
            }

            // E-Mail-Doppelt-Prüfung
            if ($hasEmail) {
                $emailCheck = $this->dbObj->sqlGet("
                    SELECT etchat_user_id 
                    FROM {$this->_prefix}etchat_user 
                    WHERE etchat_email = :email AND etchat_user_id != :user_id
                ", [
                    ':email' => $email,
                    ':user_id' => $userId
                ]);
                
                if (!empty($emailCheck)) {
                    echo "Diese E-Mail-Adresse wird bereits von einem anderen Benutzer verwendet.";
                    $this->dbObj->close();
                    return;
                }
            }

            $hash = password_hash($newPw, PASSWORD_DEFAULT);
            $ip = $currentIp;

            if ($hasEmail) {
                // Mit E-Mail: Gast bleibt Gast, bekommt Bestätigungsmail
                $token = bin2hex(random_bytes(16));
                $token_expiry = date("Y-m-d H:i:s", strtotime("+30 minutes"));

                $this->dbObj->sqlSet("
                    UPDATE {$this->_prefix}etchat_user
                    SET
                        etchat_userpw = :hash,
                        etchat_userprivilegien = 'gast',
                        etchat_reg_timestamp = NOW(),
                        etchat_reg_ip = :ip,
                        etchat_email = :email,
                        etchat_reset_token = :token,
                        etchat_reset_token_expiry = :token_expiry
                    WHERE etchat_user_id = :user_id
                ", [
                    ':hash' => $hash,
                    ':ip' => $ip,
                    ':email' => $email,
                    ':token' => $token,
                    ':token_expiry' => $token_expiry,
                    ':user_id' => $userId
                ]);

                $this->sendConfirmationEmail($email, $username, $token);
                
                echo "email_sent";
                $this->dbObj->close();
                return;
                
            } else {
                // Ohne E-Mail: Sofort zu User
                $this->dbObj->sqlSet("
                    UPDATE {$this->_prefix}etchat_user
                    SET
                        etchat_userpw = :hash,
                        etchat_userprivilegien = 'user',
                        etchat_reg_timestamp = NOW(),
                        etchat_reg_ip = :ip
                    WHERE etchat_user_id = :user_id
                ", [
                    ':hash' => $hash,
                    ':ip' => $ip,
                    ':user_id' => $userId
                ]);

                echo "1";
                $this->dbObj->close();
                return;
            }
        }

        $this->dbObj->close();
    }

    private function sendConfirmationEmail(string $email, string $username, string $token): void
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
        $hosto = $_SERVER['SERVER_NAME'] ?? 'localhost';
        $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
        $domain = $protocol . "://" . $hosto . ($scriptDir !== '' && $scriptDir !== '/' ? $scriptDir : '') . "/";
        
        $confirmLink = $domain . "?token=" . $token;
        
        $configPath = __DIR__ . "/../config.php";
        if (file_exists($configPath)) {
            include $configPath;
        } else {
            return;
        }
        
        if (empty($host) || empty($sendemail) || empty($mailpass)) {
            return;
        }
        
        if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            return;
        }
        
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = $host;
            $mail->SMTPAuth = true;
            $mail->Username = $sendemail;
            $mail->Password = $mailpass;
            $mail->SMTPSecure = $smtpsecure;
            $mail->Port = $port;
            $mail->CharSet = "UTF-8";
            $mail->Encoding = "base64";
            $mail->setFrom($sendemail, "Chat-Registrierung");
            $mail->addAddress($email, $username);
            $mail->isHTML(true);
            $mail->Subject = "Bitte bestätige deine Registrierung";
            $mail->Body = "
                <html>
                <body>
                    <h2>Hallo {$username},</h2>
                    <p>bitte bestätige deine Registrierung durch Klick auf den folgenden Link:</p>
                    <p><a href='{$confirmLink}'>{$confirmLink}</a></p>
                    <p>Der Link ist <strong>30 Minuten</strong> gültig.</p>
                    <p><strong>Wichtig:</strong> Du bleibst solange Gast, bis du deine E-Mail bestätigt hast.</p>
                    <p>Solltest du dich nicht bei uns registriert haben, kannst du diese E-Mail ignorieren.</p>
                    <br>
                    <p>Viel Spaß im Chat!</p>
                </body>
                </html>
            ";
            $mail->send();
        } catch (Exception $e) {
            // Stille Fehlerbehandlung
        }
    }

    private function checkRegistrationCooldownByIp(string $ip): ?string
    {
        $result = $this->dbObj->sqlGet("
            SELECT etchat_reg_timestamp, etchat_username
            FROM {$this->_prefix}etchat_user
            WHERE etchat_reg_ip = :ip
            AND etchat_userprivilegien != 'gast'
            AND etchat_reg_timestamp IS NOT NULL
            AND etchat_reg_timestamp != '1980-01-01 00:00:00'
            ORDER BY etchat_reg_timestamp DESC
            LIMIT 1
        ", [':ip' => $ip]);

        if (empty($result)) {
            return null;
        }

        $regTimestamp = $result[0]['etchat_reg_timestamp'];
        $username = $result[0]['etchat_username'];

        try {
            $regTime = new DateTime($regTimestamp);
            $now = new DateTime();
            
            $diffSeconds = $now->getTimestamp() - $regTime->getTimestamp();
            $cooldownSeconds = self::REGISTER_COOLDOWN_HOURS * 3600;
            
            if ($diffSeconds < $cooldownSeconds) {
                $remainingSeconds = $cooldownSeconds - $diffSeconds;
                $remainingHours = floor($remainingSeconds / 3600);
                $remainingMinutes = floor(($remainingSeconds % 3600) / 60);
                
                $message = "Von dieser IP-Adresse wurde bereits der Benutzer '" . htmlspecialchars($username) . "' registriert.\n" .
                           "Bitte warten Sie noch ";
                
                if ($remainingHours > 0) {
                    $message .= $remainingHours . " Stunde" . ($remainingHours != 1 ? "n" : "") . " ";
                }
                if ($remainingMinutes > 0) {
                    $message .= $remainingMinutes . " Minute" . ($remainingMinutes != 1 ? "n" : "") . " ";
                }
                $message .= "bevor Sie sich erneut registrieren können.";
                
                return $message;
            }
        } catch (Exception $e) {
            // Stille Fehlerbehandlung
        }

        return null;
    }

    private function validatePassword(string $password): bool
    {
        if (strlen($password) < 8) {
            return false;
        }

        $criteriaMet = 0;
        $criteriaMet += preg_match('/[A-Z]/', $password) ? 1 : 0;
        $criteriaMet += preg_match('/[a-z]/', $password) ? 1 : 0;
        $criteriaMet += preg_match('/[0-9]/', $password) ? 1 : 0;
        $criteriaMet += preg_match('/[!@#$%^&*()_\-=\[\]{};\'":\\|,.<>\/?]/', $password) ? 1 : 0;

        return $criteriaMet >= 3;
    }
}