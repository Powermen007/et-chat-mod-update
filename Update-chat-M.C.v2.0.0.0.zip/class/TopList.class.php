<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class TopList extends DbConectionMaker
{
    private array $config = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        // Style + Sprache aus DB laden
        $this->config = $this->dbObj->sqlGet("
            SELECT etchat_config_lang,
                   etchat_config_style
            FROM {$this->_prefix}etchat_config
            LIMIT 1
        ") ?: [];

        $this->showTopList();
        $this->dbObj->close();
    }

    private function formatOnlineTime(int $seconds): string
    {
        $days    = floor($seconds / 86400);
        $hours   = floor(($seconds % 86400) / 3600);
        $minutes = floor(($seconds % 3600) / 60);

        $result = [];

        if ($days > 0) {
            $result[] = $days . " Tag" . ($days > 1 ? "e" : "");
        }
        if ($hours > 0) {
            $result[] = $hours . " Std.";
        }
        if ($minutes > 0) {
            $result[] = $minutes . " Min.";
        }

        return empty($result) ? "0 Min." : implode(" ", $result);
    }

    private function showTopList(): void
    {
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->toplist_php[0] ?? null;

        // 🔄 Fallback 'default' entfernt
        $style = $this->config[0]['etchat_config_style'] ?? 'etchat_dino_styles';

        // Limit aus Session
        $limit = (int)($_SESSION['etchat_' . $this->_prefix . 'top_user'] ?? 10);
        $limit = max(1, min(100, $limit)); // Sicherheitsgrenze: 1-100

        // ✅ Sicher mit Prepared Statement
        $excludePrivileges = ['gast', 'co_admin', 'admin', 'bot', 'grafik'];
        $placeholders = implode(',', array_fill(0, count($excludePrivileges), '?'));

        $sql = "
            SELECT 
                etchat_username,
                etchat_reg_timestamp,
                etchat_onlinetime,
                FLOOR(etchat_onlinetime / 600) + (FLOOR(etchat_onlinetime / 1800) * 50) AS points
            FROM {$this->_prefix}etchat_user
            WHERE etchat_userprivilegien NOT IN ({$placeholders}) 
              AND etchat_user_id != 1
            ORDER BY points DESC
            LIMIT {$limit}
        ";

        $rows = $this->dbObj->sqlGet($sql, $excludePrivileges) ?: [];

        echo "<link rel='stylesheet' type='text/css' href='styles/{$style}/style.css'>";
        echo "<style>
        @media only screen and (max-width: 600px) {
            .chat-table,
            .chat-table thead,
            .chat-table tbody,
            .chat-table th,
            .chat-table td,
            .chat-table tr {
                display: block;
                width: 100%;
                border-width: 1px;
                border-style: solid;
                border-color: blue;
                border-radius: 10px;
                border-collapse: separate;
                overflow: hidden;
                padding: 10px;
            }
            .chat-table tr {
                margin-bottom: 10px;
                border-bottom: 2px solid #444;
            }
            .chat-table th {
                display: none;
            }
            .chat-table td {
                text-align: right;
                padding-left: 50%;
                position: relative;
            }
            .chat-table td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: 45%;
                text-align: left;
                font-weight: bold;
            }
        }
        </style>";

        echo "<body id='body'>";
        echo "<h2 class='headline'>Top {$limit} – Aktivste User</h2>";
        echo "<div class='chat-content'>";
        echo "<table class='chat-table'>";
        echo "<thead><tr>
                <th>Platz</th>
                <th>Username</th>
                <th>Registriert seit</th>
                <th>Onlinezeit</th>
                <th>Punkte</th>
              </tr></thead><tbody>";

        $platz = 1;
        foreach ($rows as $row) {
            $username = htmlspecialchars($row['etchat_username'] ?? '', ENT_QUOTES, 'UTF-8');
            $regTime = date("d.m.Y H:i", strtotime($row['etchat_reg_timestamp'] ?? 'now'));
            $onlineTime = $this->formatOnlineTime((int)($row['etchat_onlinetime'] ?? 0));
            $points = (int)($row['points'] ?? 0);

            $topClass = match($platz) {
                1 => "top1",
                2 => "top2",
                3 => "top3",
                default => ""
            };
            $medaille = match($platz) {
                1 => "🥇",
                2 => "🥈",
                3 => "🥉",
                default => ""
            };

            echo "<tr class='{$topClass}'>
                    <td data-label='Platz'>{$platz} {$medaille}</td>
                    <td data-label='Username'>{$username}</td>
                    <td data-label='Registriert'>{$regTime}</td>
                    <td data-label='Onlinezeit'>{$onlineTime}</td>
                    <td data-label='Punkte'>{$points}</td>
                  </tr>";
            $platz++;
        }

        echo "</tbody></table>";
        echo "</div></body>";
    }
}