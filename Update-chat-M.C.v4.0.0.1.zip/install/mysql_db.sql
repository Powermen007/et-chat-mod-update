
ALTER TABLE `etchat_config` ADD `etchat_config_for_inactivity` INT(8) NOT NULL DEFAULT '1800000' AFTER `etchat_bot`;

ALTER TABLE `etchat_config` ADD `etchat_config_file_retention_days` INT(11) NOT NULL DEFAULT '30' AFTER `etchat_tab_away_delay`;