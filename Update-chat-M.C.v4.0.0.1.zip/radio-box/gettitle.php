<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

$GLOBALS["path"] = "./../";

// ============================================
// 1. RADIO-BOX CACHE FUNKTIONEN EINBINDEN
// ============================================

$CACHE_DIR = __DIR__ . "/cache";
$CACHE_TIME = 30; // Gleiche Cache-Zeit wie radio-box.php

function radio_getCacheFile(string $key): string
{
    global $CACHE_DIR;
    return $CACHE_DIR . "/radio_" . md5($key) . ".cache";
}

function radio_getCached(string $key): ?string
{
    global $CACHE_TIME;

    $file = radio_getCacheFile($key);
    if (!file_exists($file)) {
        return null;
    }

    $data = json_decode(file_get_contents($file), true);
    if (!$data || !isset($data["time"], $data["value"])) {
        return null;
    }

    if (time() - $data["time"] > $CACHE_TIME) {
        return null;
    }

    return $data["value"];
}

// ============================================
// 2. EIGENE CACHE-FUNKTIONEN FÜR gettitle.php
// ============================================

function getCacheFile($url) {
    global $CACHE_DIR;
    return $CACHE_DIR . '/title_' . md5($url) . '.cache';
}

function getCachedTitle($url) {
    global $CACHE_TIME;
    $file = getCacheFile($url);

    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        if ($data && time() - $data['time'] < $CACHE_TIME) {
            return $data['title'];
        }
    }
    return null;
}

function setCachedTitle($url, $title) {
    $file = getCacheFile($url);
    $data = [
        'time'  => time(),
        'title' => $title
    ];
    file_put_contents($file, json_encode($data));
}

// ============================================
// 3. NEUE METHODE: ICY-METADATEN AUS STREAM
// ============================================

function getTitleFromICY(string $url): ?string
{
    $parsed = parse_url($url);
    $host = $parsed['host'] ?? '';
    $scheme = $parsed['scheme'] ?? 'http';
    $path = $parsed['path'] ?? '/';
    $port = $parsed['port'] ?? ($scheme === 'https' ? 443 : 80);
    
    // SSL-Optionen für HTTPS
    $sslOptions = [];
    if ($scheme === 'https') {
        $sslOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];
    }
    
    // Verbindung mit ICY-Header
    $context = stream_context_create(array_merge([
        'http' => [
            'timeout' => 5,
            'header' => "Icy-MetaData: 1\r\n"
        ]
    ], $sslOptions));
    
    $fp = @fopen("{$scheme}://{$host}:{$port}{$path}", 'r', false, $context);
    if (!$fp) {
        return null;
    }
    
    // ICY-Metadaten-Intervall finden
    $metaInt = 0;
    $headers = stream_get_meta_data($fp);
    if (isset($headers['wrapper_data']) && is_array($headers['wrapper_data'])) {
        foreach ($headers['wrapper_data'] as $header) {
            if (stripos($header, 'icy-metaint:') === 0) {
                $metaInt = intval(trim(substr($header, 13)));
                break;
            }
        }
    }
    
    if ($metaInt <= 0) {
        fclose($fp);
        return null;
    }
    
    // Zum ersten Metadaten-Block springen
    $dataRead = 0;
    $title = null;
    
    while ($dataRead < $metaInt) {
        $chunk = fread($fp, min(8192, $metaInt - $dataRead));
        if ($chunk === false || strlen($chunk) === 0) {
            break;
        }
        $dataRead += strlen($chunk);
    }
    
    if ($dataRead >= $metaInt) {
        $metaByte = fread($fp, 1);
        if ($metaByte !== false && strlen($metaByte) === 1) {
            $metaLen = ord($metaByte) * 16;
            if ($metaLen > 0) {
                $metaData = fread($fp, $metaLen);
                if ($metaData !== false && strlen($metaData) > 0) {
                    if (preg_match('/StreamTitle=\'([^\']*)\'/', $metaData, $matches)) {
                        $title = $matches[1];
                    } elseif (preg_match('/StreamTitle="([^"]*)"/', $metaData, $matches)) {
                        $title = $matches[1];
                    }
                }
            }
        }
    }
    
    fclose($fp);
    
    if ($title && trim($title) !== '') {
        return trim($title);
    }
    
    return null;
}

// ============================================
// 4. TITEL HOLEN (MIT NEUER METHODE ALS ERSTE)
// ============================================

function getStreamTitle(string $url): string
{
    $parsed = parse_url($url);
    $host   = $parsed['host'] ?? '';
    $scheme = $parsed['scheme'] ?? 'http';
    $port   = $parsed['port'] ?? 80;

    if (empty($host)) {
        return "Ungültiger Host";
    }

    // ============================================
    // PRIORITÄT 1: EIGENER CACHE (gettitle.php)
    // ============================================
    $cached = getCachedTitle($url);
    if ($cached !== null) {
        return $cached;
    }

    // ============================================
    // PRIORITÄT 2: ICY-METADATEN (NEU)
    // ============================================
    $icyTitle = getTitleFromICY($url);
    if ($icyTitle !== null) {
        setCachedTitle($url, $icyTitle);
        return $icyTitle;
    }

    // ============================================
    // PRIORITÄT 3: RADIO-BOX CACHE (falls vorhanden)
    // ============================================
    
    // Typ erkennen
    if (str_contains($host, 'laut.fm')) {
        $type = 'lautfm';
    } elseif (str_contains($host, 'icecast')) {
        $type = 'icecast';
    } else {
        $type = 'shoutcast';
    }
    
    $cacheKey = "radio_metrics_" . $host . "_" . $port . "_" . $type;
    $radioCached = radio_getCached($cacheKey);
    
    if ($radioCached !== null) {
        $data = json_decode($radioCached, true);
        if (is_array($data) && isset($data['title'])) {
            $title = $data['title'];
            // Auch im eigenen Cache speichern für下次
            setCachedTitle($url, $title);
            return $title;
        }
    }

    // ============================================
    // PRIORITÄT 4: BISHERIGE METHODEN (Fallback)
    // ============================================

    // 🔹 Laut.fm
    if (str_contains($host, 'laut.fm')) {
        $path = trim($parsed['path'] ?? '', '/');
        if (!empty($path)) {
            $station = explode('/', $path)[0];
            $lautUrl = "https://api.laut.fm/station/{$station}/current_song";

            $json = @file_get_contents($lautUrl, false, stream_context_create([
                'http' => ['timeout' => 2]
            ]));

            if ($json) {
                $data = json_decode($json, true);
                if (isset($data['title'], $data['artist']['name'])) {
                    $title = $data['artist']['name'] . " - " . $data['title'];
                    setCachedTitle($url, $title);
                    return $title;
                }
            }
        }
    }

    // 🔹 Shoutcast /currentsong
    $shoutcastCurrent = "{$scheme}://{$host}:{$port}/currentsong";
    $title = @file_get_contents($shoutcastCurrent, false, stream_context_create([
        'http' => ['timeout' => 2]
    ]));

    if ($title && stripos($title, 'html') === false) {
        $title = trim(substr($title, 0, 200));
        setCachedTitle($url, $title);
        return $title;
    }

    // 🔹 Icecast /status-json.xsl
    $statusUrl = "{$scheme}://{$host}:{$port}/status-json.xsl";
    $json = @file_get_contents($statusUrl, false, stream_context_create([
        'http' => ['timeout' => 2]
    ]));

    if ($json && strlen($json) < 20000) {
        $data = json_decode($json, true);

        if (!empty($data['icestats']['source'])) {
            $source = $data['icestats']['source'];

            if (isset($source['title'])) {
                $title = $source['title'];
                setCachedTitle($url, $title);
                return $title;
            }

            if (is_array($source)) {
                foreach ($source as $mount) {
                    if (isset($mount['title'])) {
                        $title = $mount['title'];
                        setCachedTitle($url, $title);
                        return $title;
                    }
                }
            }
        }
    }

    return "Titel nicht verfügbar";
}

// ============================================
// 5. AUSGABE
// ============================================

if (isset($_GET['url'])) {
    header('Content-Type: text/plain; charset=utf-8');
    echo getStreamTitle(urldecode($_GET['url']));
} else {
    header('HTTP/1.0 400 Bad Request');
    echo "Keine Stream-URL angegeben";
}