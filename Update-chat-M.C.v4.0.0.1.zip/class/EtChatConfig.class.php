<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

abstract class EtChatConfig
{
	protected string $_database;
	protected string $_sqlhost;
	protected string $_sqluser;
	protected string $_sqlpass;
	protected string $_prefix;
	protected string $_usedDatabase;
	protected string $_usedDatabaseExtension;
	protected int $_messages_shown_on_entrance;
	protected int $_limit_logins_in_three_minutes;
	protected int $_allowed_privates_in_chat_win;
	protected int $_allowed_privates_in_separate_win;
	protected int $_show_history_all_user;
	protected int $_allow_nick_registration;
	protected string $_messages_sound;

    protected function __construct()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

        if (isset($GLOBALS["path"])) {
            require($GLOBALS["path"] . 'config.php');
        } else {
            require('./config.php');
        }

        $this->_database                  = $database;
        $this->_sqlhost                    = $sqlhost;
        $this->_sqluser                    = $sqluser;
        $this->_sqlpass                    = $sqlpass;
        $this->_prefix                     = $prefix;
        $this->_usedDatabase               = $usedDatabaseType;
        $this->_usedDatabaseExtension      = $usedDatabaseExtension;
        $this->_messages_shown_on_entrance  = $messages_shown_on_entrance;
        $this->_limit_logins_in_three_minutes = $limit_logins_in_three_minutes;
        $this->_allowed_privates_in_chat_win  = $allowed_privates_in_chat_win;
        $this->_allowed_privates_in_separate_win = $allowed_privates_in_separate_win;
        $this->_show_history_all_user       = $show_history_all_user;
        $this->_allow_nick_registration     = $allow_nick_registration;

        // Sound-Modus: String (Default 'all')
        $this->_messages_sound = (string)($messages_sound ?? 'all');

        if (!isset($_SESSION['etchat_'.$this->_prefix.'sys_messages'])) {
            $_SESSION['etchat_'.$this->_prefix.'sys_messages'] = $show_sys_messages;
        }
    }
}