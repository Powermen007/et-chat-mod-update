<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class History extends DbConectionMaker
{
    private ?object $lang = null;

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    public function __construct()
    {
        parent::__construct();

        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            header("Location: ./");
            exit();
        }

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION["etchat_" . $this->_prefix . "user_id"])) {
            exit();
        }

        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Content-Type: text/html; charset=utf-8");

        // ===== MODERNE SPRACHE LADEN =====
		$this->lang = new LangXml("./lang/");

        $userId = (int) $_SESSION["etchat_" . $this->_prefix . "user_id"];
        $userPriv = $_SESSION["etchat_" . $this->_prefix . "user_priv"];

        /* Raumlogik */
        $roomId = $_POST["roomid"] ?? 1;
        if ($roomId === "" || $roomId === null) {
            $roomId = 1;
        }

        $privates = $roomId === "priv";

        if (!$privates) {
            $roomId = (int) $roomId;
        }

        $_POST["roomid"] = $roomId;

        $includeLobby = !$privates && $roomId === 1;

        /* Pagination */
        $pro_seite = 40;

        $site = isset($_POST["site"]) ? (int) $_POST["site"] : 1;
        $site = max(0, $site - 1);

        $von = $site * $pro_seite;

        $limit =
            $this->_usedDatabase === "mysql"
                ? "LIMIT $von, $pro_seite"
                : "LIMIT $pro_seite OFFSET $von";

        /* Loginzeit */
        $zeit = 0;

        $tmp = $this->dbObj->sqlGet(
            "SELECT etchat_logintime 
             FROM {$this->_prefix}etchat_useronline 
             WHERE etchat_onlineuser_fid = ?",
            [$userId]
        );

        if (!empty($tmp)) {
            $zeit = (int) ($tmp[0]['etchat_logintime'] ?? 0) - 2;
        }

        /* Nachrichten laden */

        if ($privates) {
            $counted = $this->dbObj->sqlGet(
                "SELECT COUNT(etchat_id) as cnt
                 FROM {$this->_prefix}etchat_messages
                 WHERE (etchat_user_fid = ? AND etchat_privat > 0)
                 OR etchat_privat = ?",
                [$userId, $userId]
            );

            $feld = $this->dbObj->sqlGet(
                "SELECT
                    m.etchat_id,
                    sender.etchat_username AS sender_name,
                    receiver.etchat_username AS receiver_name,
                    m.etchat_text,
                    m.etchat_timestamp,
                    r.etchat_roomname,
                    m.etchat_privat,
                    m.etchat_user_fid,
                    m.etchat_text_css,
                    m.etchat_user_ip
                 FROM {$this->_prefix}etchat_messages m
                 LEFT JOIN {$this->_prefix}etchat_user sender
                     ON sender.etchat_user_id = m.etchat_user_fid
                 LEFT JOIN {$this->_prefix}etchat_user receiver
                     ON receiver.etchat_user_id = m.etchat_privat
                 LEFT JOIN {$this->_prefix}etchat_rooms r
                     ON r.etchat_id_room = m.etchat_fid_room
                 WHERE
                     (m.etchat_user_fid = ? AND m.etchat_privat > 0)
                     OR m.etchat_privat = ?
                 ORDER BY m.etchat_id DESC
                 $limit",
                [$userId, $userId]
            );
        } else {
            $where = "m.etchat_privat = 0 AND m.etchat_fid_room = ?";
            $params = [$roomId];

            if ($includeLobby) {
                $where =
                    "m.etchat_privat = 0 AND (m.etchat_fid_room = ? OR m.etchat_fid_room = 0)";
            }

            if ($userPriv !== "admin") {
                $where .= " AND m.etchat_timestamp >= ?";
                $params[] = $zeit;
            }

            $counted = $this->dbObj->sqlGet(
                "SELECT COUNT(etchat_id) as cnt
                 FROM {$this->_prefix}etchat_messages m
                 WHERE $where",
                $params
            );

            $feld = $this->dbObj->sqlGet(
                "SELECT
                    m.etchat_id,
                    sender.etchat_username,
                    NULL,
                    m.etchat_text,
                    m.etchat_timestamp,
                    r.etchat_roomname,
                    m.etchat_privat,
                    m.etchat_user_fid,
                    m.etchat_text_css,
                    m.etchat_user_ip
                 FROM {$this->_prefix}etchat_messages m
                 LEFT JOIN {$this->_prefix}etchat_user sender
                     ON sender.etchat_user_id = m.etchat_user_fid
                 LEFT JOIN {$this->_prefix}etchat_rooms r
                     ON r.etchat_id_room = m.etchat_fid_room
                 WHERE $where
                 ORDER BY m.etchat_id DESC
                 $limit",
                $params
            );
        }

        /* Seiten */

        echo "<div id='history_seiten' style='margin:2px;'>";

        $totalCount = isset($counted[0]['cnt']) ? (int) $counted[0]['cnt'] : 0;
        $sitemakerObj = new Sitemaker($pro_seite, $totalCount);

        // ===== MODERNISIERT: Site-Text aus XML =====
        $siteText = $this->getText('history_site', 'Seite:');
        $siteOfText = $this->getText('history_site_of', 'von');

        $sitemakerObj->make(
            $_POST["site"] ?? 1,
            "historysite_#site#",
            $siteText,
            $siteOfText
        );

        $sitemakerObj->show();

        // ===== MODERNISIERT: Raum-Auswahl =====
        $roomText = $this->getText('history_room', 'Raum');
        $privateText = $this->getText('history_private', 'private Nachrichten');

        echo "<form style='display:inline;'>&nbsp;&nbsp;&nbsp; " .
            $roomText .
            ": <select name='raum_in_history' id='raum_in_history'>";

        echo "<option value='priv' " .
            ($privates ? "selected" : "") .
            ">" .
            $privateText .
            "</option>";

        $rooms = $this->dbObj->sqlGet(
            "SELECT etchat_id_room, etchat_roomname, etchat_room_goup 
             FROM {$this->_prefix}etchat_rooms"
        );

        if (!empty($rooms)) {
            foreach ($rooms as $each_room) {
                $roomAllowed = new RoomAllowed($each_room['etchat_room_goup'] ?? 0, $each_room['etchat_id_room'] ?? 0);

                if ($roomAllowed->room_status == 1) {
                    $selected =
                        !$privates && $roomId == ($each_room['etchat_id_room'] ?? 0)
                            ? "selected"
                            : "";

                    echo "<option value='" .
                        ($each_room['etchat_id_room'] ?? 0) .
                        "' $selected>" .
                        htmlspecialchars($each_room['etchat_roomname'] ?? '') .
                        "</option>";
                }
            }
        }

        if ($userPriv === "admin") {
            // ===== MODERNISIERT: Export-Text aus XML =====
            $exportText = $this->getText('history_export', 'Exportiere Verlauf:');
            $excelText = $this->getText('history_export_excel', 'Excel');
            $csvText = $this->getText('history_export_csv', 'CSV');
            $xmlText = $this->getText('history_export_xml', 'XML');

            echo "</select>&nbsp;&nbsp;&nbsp;" .
                $exportText .
                "
<a href='#' id='export_excel'>" . $excelText . "</a> |
<a href='#' id='export_csv'>" . $csvText . "</a> |
<a href='#' id='export_xml'>" . $xmlText . "</a></form>";
        } else {
            echo "</select></form>";
        }

        /* Smileys */

        if (!isset($_SESSION["etchat_smileys"])) {
            $_SESSION["etchat_smileys"] = $this->dbObj->sqlGet(
                "SELECT etchat_smileys_sign, etchat_smileys_img
                 FROM {$this->_prefix}etchat_smileys"
            );
        }

        $sml = $_SESSION["etchat_smileys"];

        /* Tabelle */

        // ===== MODERNISIERT: Tabellen-Header =====
        $userText = $this->getText('history_user', 'User');
        $userIpText = $this->getText('history_user_ip', 'User-IP');
        $dateText = $this->getText('history_date', 'Datum');
        $textText = $this->getText('history_text', 'Text');
        $roomText = $this->getText('history_room', 'Raum');
        $emptyText = $this->getText('history_empty', 'Keine Einträge in der Datenbank.');
        $noDataText = $this->getText('history_no_data', 'Keine Daten gefunden oder DB-Fehler');
        $arrowText = $this->getText('history_arrow', '->');
        $windowText = $this->getText('history_window', '🪟');

        echo '<div class="table-container">';
        echo '<table class="table-fixed" cellpadding="5" cellspacing="0" border="0">';

        echo '<thead>
                <tr class="kopf">
                
                <th style="width:14%"><b>' . $userText . '</b></th>

                <th style="width:10.5%"><b>' . $userIpText . '</b></th>
                <th style="width:14.5%"><b>' . $dateText . '</b></th>
                <th style="width:51.5%"><b>' . $textText . '</b></th>
                <th style="width:9.5%"><b>' . $roomText . '</b></th>
                </tr>
                </thead>
            <tbody>';

        if (!empty($feld) && is_array($feld)) {

            foreach ($feld as $a => $row) {

                $class = $a % 2 == 0 ? "gerade" : "ungerade";

                // BENUTZERNAME - UNTERSCHEIDUNG PRIVAT / ÖFFENTLICH
                if ($privates) {
                    $sender = strip_tags($row['sender_name'] ?? '') ?: $this->getText('history_private_chat_sender', 'User') . " " . ($row['etchat_user_fid'] ?? 0);
                    $empfaenger = "";
                    if (($row['etchat_privat'] ?? 0) != 0) {
                        $empName = strip_tags($row['receiver_name'] ?? '') ?: $this->getText('history_private_chat_sender', 'User') . " " . ($row['etchat_privat'] ?? 0);
                        $empfaenger = "&nbsp;<span style='font-size:1.2em'><b>" . $arrowText . "</b></span>&nbsp;" . $empName;
                    }
                } else {
                    $sender = strip_tags($row['etchat_username'] ?? '') ?: $this->getText('history_private_chat_sender', 'User') . " " . ($row['etchat_user_fid'] ?? 0);
                    $empfaenger = "";
                }

                $message = StaticMethods::filtering($row['etchat_text'] ?? '', $sml, $this->_prefix);

                if (substr($message, 0, 8) == "/window:") {
                    $message = $windowText . " " . substr($message, 8);
                }

                echo "<tr class='$class'>
                    <td>" . htmlspecialchars($sender) . $empfaenger . "</td>
                    <td>" . htmlspecialchars($row['etchat_user_ip'] ?? '') . "</td>
                    <td><center>" . date("d.m.Y (H:i)", $row['etchat_timestamp'] ?? 0) . "</center></td>
                    <td>" . $message . "</td>
                    <td>" . htmlspecialchars($row['etchat_roomname'] ?? '') . "</td>
                    </tr>";
            }

        } else {

            echo "<tr><td colspan='5'><center>" . $noDataText . "</center></td></tr>";
        }

        echo '</tbody> </table></div>';

        $this->dbObj->close();
    }
}