<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class ChangeStatus extends DbConectionMaker
{
    private ?object $lang = null;

    public function __construct()
    {
        parent::__construct();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        // ===== MODERNE SPRACHE LADEN =====
        $this->lang = new LangXml("./lang/");

        // === Systemmeldungen speichern ===
        if (isset($_POST['sys_messages'])) {
            $_SESSION['etchat_' . $this->_prefix . 'sys_messages'] = (int)$_POST['sys_messages'];
            exit;
        }

        // === Session prüfen ===
        $userId = (int)($_SESSION['etchat_' . $this->_prefix . 'user_id'] ?? 0);
        if ($userId <= 0) {
            exit($this->getText('changestatus_invalid_session', 'Invalid session.'));
        }

        // === Input sicher lesen ===
        $img  = $_POST['img']  ?? '';
        $text = $_POST['text'] ?? '';

        // Nur erlaubte Zeichen für Bildnamen
        $img  = preg_replace("/[^a-zA-Z0-9_\-.]/", "", $img);
        
        // Steuerzeichen entfernen, Länge begrenzen
        $text = preg_replace('/[\x00-\x1F]/u', '', $text);
        $text = mb_substr($text, 0, 255);

        // === Rechte prüfen ===
        if (!$this->checkRightsOfStatus($img)) {
            exit($this->getText('changestatus_not_allowed', 'Not allowed operation.'));
        }

        // Neutraler Status (online)
        if ($img === "status_online") {
            $img = '';
            $text = '';
        }

        // Prüfen ob die Bilddatei existiert
        if (!empty($img)) {
            $imgPath = __DIR__ . "/../img/{$img}.png";
            if (!is_file($imgPath)) {
                $img = '';
                $text = '';
            }
        }

        // ✅ SICHER MIT PREPARED STATEMENT
        $this->dbObj->sqlSet("
            UPDATE {$this->_prefix}etchat_useronline SET
                etchat_user_online_user_status_img = :img,
                etchat_user_online_user_status_text = :text
            WHERE etchat_onlineuser_fid = :user_id
        ", [
            ':img' => $img,
            ':text' => $text,
            ':user_id' => $userId
        ]);

        $this->dbObj->close();
        echo "1";
    }

    private function getText(string $key, string $default = ''): string
    {
        if ($this->lang !== null) {
            return $this->lang->get($key, $default);
        }
        return $default;
    }

    /**
     * Prüft, ob der Benutzer die Rechte hat, einen Status zu setzen
     */
    private function checkRightsOfStatus(string $statusImagename): bool
    {
        // Prüfen ob es ein Status-Bild ist
        if (substr($statusImagename, 0, 7) !== 'status_') {
            return false;
        }

        // Leerer Status (kein Bild) ist immer erlaubt
        if (empty($statusImagename)) {
            return true;
        }

        try {
            $allStructs = $this->lang->getAllStructs();
            $allowedRights = [];

            foreach ($allStructs as $key => $struct) {
                // Prüfen ob es ein Status-Struct ist
                if (strpos($key, 'status_') === 0) {
                    $attrs = $struct->attributes ?? [];
                    
                    // Prüfen ob der Bildname übereinstimmt
                    if (($attrs['imagename'] ?? '') === $statusImagename) {
                        $rights = $attrs['rights'] ?? '';
                        
                        // "all" bedeutet: jeder darf diesen Status verwenden
                        if ($rights === 'all') {
                            return true;
                        }
                        
                        // Rechte als Array speichern (durch Kommas getrennt)
                        if (!empty($rights)) {
                            $rightsArray = array_map('trim', explode(',', $rights));
                            $allowedRights = array_merge($allowedRights, $rightsArray);
                        }
                    }
                }
            }
        } catch (Exception $e) {
            // Bei Fehler: Status erlauben (Fallback)
            return true;
        }

        // Keine speziellen Rechte gefunden? Status darf jeder verwenden
        if (empty($allowedRights)) {
            return true;
        }

        // Aktuelles Benutzerrecht aus der Session holen
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        // Prüfen ob das User-Recht in der Liste der erlaubten Rechte ist
        return in_array($userPriv, $allowedRights, true);
    }
}