<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminBoxsIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $boxes = [];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Rollen prüfen
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($userPriv !== 'admin') {
            // ✅ MODERN: get() verwenden statt tagData
            echo $lang->get('admin_access_denied', 'Zugriff verweigert');
            return;
        }

        // CSRF Token erzeugen
        $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

        // Boxen laden
        $this->loadBoxes();

        $this->dbObj->close();

        // Template einbinden
        $this->initTemplate($lang);
    }

    private function loadBoxes(): void
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT id, ort, header_text FROM {$this->_prefix}etchat_start_boxes ORDER BY id"
        );
        $stmt->execute();
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->boxes = is_array($result) ? $result : [];
    }

    private function initTemplate(object $lang): void
    {
        $boxes = $this->boxes;
        $csrfToken = $this->csrfToken;
        include __DIR__ . "/../../styles/admin_tpl/indexBoxs.tpl.html";
    }
}