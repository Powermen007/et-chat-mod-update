<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminPropertyIndex extends DbConectionMaker
{
    private string $csrfToken = '';
    private array $excludedStyleFolders = ['admin_tpl', 'install_tpl'];

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Session-Daten aus Config in $_SESSION laden
        $this->configTabData2Session();

        // DB schließen
        $this->dbObj->close();

        // Sprachobjekt laden
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // Benutzerrolle
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        // CSRF Token
        $sessionKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$sessionKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$sessionKey];

        // Styles laden
        $printStyles = $this->loadStyles();

        // Sprach-Ordner laden
        $printLangFolders = $this->loadLanguageFolders();

        // Erfolgsbanner prüfen
        $showBanner = false;
        if (isset($_SESSION['show_success_banner']) && $_SESSION['show_success_banner'] === true) {
            $showBanner = true;
            unset($_SESSION['show_success_banner']);
        }

        // Template laden – je nach Rolle
        $this->renderTemplate($role, $printStyles, $printLangFolders, $showBanner, $lang);
    }

    private function loadStyles(): string
    {
        $styleDir = "styles/";
        $html = '';
        
        if (!is_dir($styleDir)) {
            return $html;
        }

        $handle = opendir($styleDir);
        if ($handle === false) {
            return $html;
        }

        $currentStyle = $_SESSION['etchat_' . $this->_prefix . 'style'] ?? '';

        while (($file = readdir($handle)) !== false) {
            if ($file === '.' || $file === '..') continue;
            
            $fullPath = $styleDir . $file;
            if (is_dir($fullPath) && !in_array($file, $this->excludedStyleFolders, true)) {
                $selected = ($currentStyle === $file) ? ' selected' : '';
                $safeName = htmlspecialchars($file, ENT_QUOTES, 'UTF-8');
                $html .= "<option value=\"{$safeName}\"{$selected}>{$safeName}</option>\n";
            }
        }
        closedir($handle);

        return $html;
    }

    private function loadLanguageFolders(): string
    {
        $langDir = "lang/";
        $html = '';
        
        if (!is_dir($langDir)) {
            return $html;
        }

        $handle = opendir($langDir);
        if ($handle === false) {
            return $html;
        }

        $currentLang = $_SESSION['etchat_' . $this->_prefix . 'lang_xml_file'] ?? 'Deutsch';

        while (($folder = readdir($handle)) !== false) {
            if ($folder === '.' || $folder === '..') continue;
            
            $fullPath = $langDir . $folder;
            
            if (!is_dir($fullPath)) continue;
            
            $chatFile = $fullPath . '/lang_' . $this->getLangCode($folder) . '_v2.xml';
            $adminFile = $fullPath . '/lang_admin_' . $this->getLangCode($folder) . '_v2.xml';
            
            if (!file_exists($chatFile) || !file_exists($adminFile)) {
                continue;
            }

            $selected = ($currentLang === $folder) ? ' selected' : '';
            $safeFolder = htmlspecialchars($folder, ENT_QUOTES, 'UTF-8');

            $html .= "<option value=\"{$safeFolder}\"{$selected}>{$safeFolder}</option>";
        }
        closedir($handle);

        return $html;
    }

    private function getLangCode(string $folder): string
    {
        $map = [
            'Deutsch' => 'de',
            'Englisch' => 'en',
            'Polnisch' => 'pl',
            'Französisch' => 'fr',
            'Spanisch' => 'es',
            'Italienisch' => 'it',
            'Niederländisch' => 'nl',
            'Russisch' => 'ru',
            'Türkisch' => 'tr',
            'Arabisch' => 'ar',
            'Chinesisch' => 'zh',
            'Japanisch' => 'ja',
        ];
        
        return $map[$folder] ?? 'de';
    }

    private function renderTemplate(string $role, string $printStyles, string $printLangFolders, bool $showBanner, ?object $lang): void
    {
        $csrfToken = $this->csrfToken;
        $print_styles = $printStyles;
        $print_lang_files = $printLangFolders;
        $prefix = 'etchat_' . $this->_prefix;

        if ($role === "admin") {
            include("styles/admin_tpl/indexProperty.tpl.html");
        } elseif ($role === "co_admin") {
            include("styles/admin_tpl/indexPropertyCoAdmin.tpl.html");
        } else {
            // ✅ MODERN: get() verwenden statt tagData
            echo $lang->get('admin_access_denied', 'Zugriff verweigert');
        }
    }
}