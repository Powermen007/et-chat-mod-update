<?php
declare(strict_types=1);

/**
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.)
und wird unter der Namenserweiterung M.C.v.x.x.x. geführt. 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
 */

class AdminGallery extends DbConectionMaker
{
    private const UPLOAD_DIR = './userpic/';
    private const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif'];
    private const ALLOWED_ROLES = ['admin', 'grafik', 'co_admin', 'chatwache'];

    private string $csrfToken = '';
    private array $images = [];
    private int $imageCount = 0;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // NEU: Sprache laden - Admin XML
        // -------------------------
        $lang = new LangXml("./lang/", "lang_admin_de.xml");

        // CSRF Token zuerst setzen (PHP 8+ mit ??=)
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        $_SESSION[$csrfKey] ??= bin2hex(random_bytes(16));
        $this->csrfToken = $_SESSION[$csrfKey];

        // Config laden
        $style = $this->loadConfig();

        // Zugriff prüfen
        $this->checkAccess($lang);

        // Aktionen verarbeiten
        $this->handleActions($lang);

        // Bilder scannen
        $this->scanImages();

        // Template anzeigen
        $this->renderTemplate($style, $lang);
    }

    /**
     * Lädt die Style-Konfiguration
     */
    private function loadConfig(): string
    {
        $stmt = $this->dbObj->getConnection()->prepare(
            "SELECT etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = 1"
        );
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['etchat_config_style'] ?? 'default';
    }

    /**
     * Prüft die Zugriffsberechtigung
     */
    private function checkAccess($lang): void
    {
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($role, self::ALLOWED_ROLES, true)) {
            exit($lang->get('admin_gallery_error_access') ?? 'Zugriff verweigert');
        }
    }

    /**
     * Verarbeitet alle Aktionen (DELETE, CLEANUP)
     */
private function handleActions($lang): void
{
    // DELETE via POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
        $this->handleDelete($_POST['delete'], $_POST['csrf_token'] ?? '', $lang);
        exit;
    }

    // CLEANUP via GET - HIER WIRD DIE AUSGEWÄHLTE TAGEZAHL ÜBERGEBEN
    if (isset($_GET['cleanup'])) {
        $days = (int)($_GET['days'] ?? 7);
        $this->handleCleanup($_GET['csrf_token'] ?? '', $days, $lang);
        exit;
    }
    
    // Retention speichern (für User-Uploads)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_retention'])) {
        $this->handleSaveRetention($_POST, $lang);
        exit;
    }
}

    /**
     * Löscht ein einzelnes Bild
     */
    private function handleDelete(string $imageName, string $token, $lang): void
    {
        // CSRF prüfen
        if (!$token || !hash_equals($this->csrfToken, $token)) {
            http_response_code(403);
            echo $lang->get('admin_gallery_error_csrf') ?? "CSRF Fehler - Token ungültig";
            exit;
        }

        $imageName = basename($imageName);
        $imagePath = self::UPLOAD_DIR . $imageName;
        
        // Prüfen ob Datei existiert
        if (!file_exists($imagePath)) {
            echo $lang->get('admin_gallery_error_not_found') ?? "Datei nicht gefunden";
            exit;
        }
        
        // Prüfen ob es eine Datei ist (kein Ordner)
        if (!is_file($imagePath)) {
            echo $lang->get('admin_gallery_error_invalid') ?? "Keine gültige Datei";
            exit;
        }
        
        // Datei löschen
        if (unlink($imagePath)) {
            // Metadaten löschen falls vorhanden
            $metaPath = $imagePath . '.txt';
            if (is_file($metaPath)) {
                unlink($metaPath);
            }
            echo "success";
            exit;
        } else {
            echo $lang->get('admin_gallery_error_delete') ?? "Konnte Datei nicht löschen";
            exit;
        }
    }

/**
 * Speichert die Aufbewahrungsdauer für User-Uploads
 */
private function handleSaveRetention(array $post, $lang): void
{
    // CSRF prüfen
    $token = $post['csrf_token'] ?? '';
    if (!$token || !hash_equals($this->csrfToken, $token)) {
        http_response_code(403);
        echo $lang->get('admin_gallery_error_csrf') ?? "CSRF Fehler";
        exit;
    }

    $days = (int)($post['retention_days'] ?? 7);
    $allowed = [7, 14, 30, 60, 90, 180, 365];
    
    if (!in_array($days, $allowed, true)) {
        $_SESSION['gallery_retention_msg'] = $lang->get('admin_gallery_retention_invalid') ?? 'Ungültiger Wert!';
        header("Location: ./?AdminGallery");
        exit;
    }

    // In Datenbank speichern
    $stmt = $this->dbObj->getConnection()->prepare(
        "UPDATE {$this->_prefix}etchat_config 
         SET etchat_config_file_retention_days = ? 
         WHERE etchat_config_id = 1"
    );
    
if ($stmt->execute([$days])) {
	$_SESSION['etchat_' . $this->_prefix . 'file_retention_days'] = $days;
    $msgTemplate = $lang->get('admin_gallery_retention_success') ?? '✅ Aufbewahrungsdauer für User-Uploads auf {days} Tage geändert!';
    $_SESSION['gallery_retention_msg'] = str_replace('{days}', (string)$days, $msgTemplate);
} else {
    $_SESSION['gallery_retention_msg'] = $lang->get('admin_gallery_retention_error') ?? '❌ Fehler beim Speichern!';
}

    header("Location: ./?AdminGallery");
    exit;
}

/**
 * Lädt die aktuelle Aufbewahrungsdauer für User-Uploads
 */
private function loadRetentionDays(): int
{
    return (int)($_SESSION['etchat_' . $this->_prefix . 'file_retention_days'] ?? 7);
}


/**
* Löscht alle Bilder älter als X Tage
*/
private function handleCleanup(string $token, int $days, $lang): void
{
    // CSRF prüfen
    if (!$token || !hash_equals($this->csrfToken, $token)) {
        http_response_code(403);
        echo $lang->get('admin_gallery_error_csrf') ?? "CSRF Fehler - Token ungültig";
        exit;
    }

    $days = max(1, $days);
    $limitTime = time() - ($days * 86400);
    
    if (!is_dir(self::UPLOAD_DIR)) {
        $_SESSION['gallery_cleanup_msg'] = $lang->get('admin_gallery_error_dir') ?? "Fehler: Verzeichnis nicht gefunden.";
        header("Location: ./?AdminGallery");
        exit;
    }

    $files = scandir(self::UPLOAD_DIR);
    if ($files === false) {
        $_SESSION['gallery_cleanup_msg'] = $lang->get('admin_gallery_error_read') ?? "Fehler: Konnte Verzeichnis nicht lesen.";
        header("Location: ./?AdminGallery");
        exit;
    }

    $deleted = 0;
    $errors = 0;

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        $path = self::UPLOAD_DIR . $file;

        if (!is_file($path)) {
            continue;
        }

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($ext, self::ALLOWED_EXTENSIONS, true)) {
            continue;
        }

        if (filemtime($path) < $limitTime) {
            if (unlink($path)) {
                $deleted++;
                $metaPath = $path . '.txt';
                if (is_file($metaPath)) {
                    unlink($metaPath);
                }
            } else {
                $errors++;
            }
        }
    }

    // Erfolgsmeldung mit str_replace formatieren (für {deleted}, {errors}, {days})
    if ($deleted > 0 || $errors > 0) {
        $msgTemplate = $lang->get('admin_gallery_cleanup_deleted') ?? "🧹 {deleted} Bilder gelöscht, {errors} Fehler.";
        $_SESSION['gallery_cleanup_msg'] = str_replace(
            ['{deleted}', '{errors}'], 
            [(string)$deleted, (string)$errors],  // Wichtig: In Strings umwandeln!
            $msgTemplate
        );
    } else {
        $msgTemplate = $lang->get('admin_gallery_cleanup_none') ?? "Keine alten Bilder gefunden (älter als {days} Tage).";
        $_SESSION['gallery_cleanup_msg'] = str_replace(
            '{days}', 
            (string)$days,  // Wichtig: In String umwandeln!
            $msgTemplate
        );
    }
    
    header("Location: ./?AdminGallery");
    exit;
}

    /**
     * Scannt das Upload-Verzeichnis nach Bildern
     */
    private function scanImages(): void
    {
        if (!is_dir(self::UPLOAD_DIR)) {
            $this->images = [];
            $this->imageCount = 0;
            return;
        }

        $files = scandir(self::UPLOAD_DIR);
        if ($files === false) {
            $this->images = [];
            $this->imageCount = 0;
            return;
        }

        $images = array_filter($files, function ($file) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            return in_array($ext, self::ALLOWED_EXTENSIONS, true)
                && is_file(self::UPLOAD_DIR . $file);
        });

        $this->images = array_values($images);
        $this->imageCount = count($this->images);
    }

    /**
     * Liest die Metadaten einer Bilddatei
     */
    private function readMeta(string $image): array
    {
        $metaFile = self::UPLOAD_DIR . $image . '.txt';

        if (!is_file($metaFile)) {
            return [$this->lang?->get('admin_gallery_unknown') ?? 'Unbekannt', '', ''];
        }

        $content = file_get_contents($metaFile);
        if ($content === false) {
            return [$this->lang?->get('admin_gallery_unknown') ?? 'Unbekannt', '', ''];
        }

        $parts = explode('|', $content, 3);

        return [
            trim($parts[0] ?? ''),
            trim($parts[1] ?? ''),
            trim($parts[2] ?? '')
        ];
    }

    /**
     * Baut die Galerie HTML
     */
    private function buildGallery($lang): string
    {
        if (empty($this->images)) {
            return '<p>' . ($lang->get('admin_gallery_empty') ?? 'Keine Bilder vorhanden.') . '</p>';
        }

        $html = '';

        foreach ($this->images as $image) {
            $safe = htmlspecialchars($image, ENT_QUOTES, 'UTF-8');
            $url = self::UPLOAD_DIR . $safe;

            [$uploader, $datum, $ip] = $this->readMeta($image);

            $html .= '
            <div class="gallery-card" style="border:1px solid #444; padding:10px; background:rgba(0,0,0,0.3); display:flex; flex-direction:column;">
                <div style="margin-bottom:5px;">
                    <b>' . htmlspecialchars($uploader, ENT_QUOTES, 'UTF-8') . '</b><br>
                    ' . htmlspecialchars($datum, ENT_QUOTES, 'UTF-8') . '<br>
                    IP: ' . htmlspecialchars($ip, ENT_QUOTES, 'UTF-8') . '
                </div>
                <div style="text-align:center; margin:10px 0;">
                    <img src="' . $url . '" style="max-height:150px; max-width:95%;" alt="' . $safe . '">
                </div>
                <div style="text-align:center; margin-top:auto;">
                    <button type="button" onclick="sendToChat(\'' . addslashes($safe) . '\')">' . ($lang->get('admin_gallery_button_post') ?? '📤 posten') . '</button>
                    <button type="button" class="delete-btn" onclick="deleteImage(\'' . addslashes($safe) . '\')">' . ($lang->get('admin_gallery_button_delete') ?? '🗑️ X') . '</button>
                </div>
            </div>';
        }

        return $html;
    }

	/**
	* Rendert das Template
	*/
private function renderTemplate(string $style, $lang): void
{
    // Alle Übersetzungen vorbereiten
$translations = [
    'page_title' => $lang->get('admin_gallery_page_title') ?? 'Galerie',
    'images' => $lang->get('admin_gallery_images') ?? 'Bilder',
    'confirm_cleanup' => $lang->get('admin_gallery_confirm_cleanup') ?? 'Wirklich alle Bilder älter als {days} Tage löschen?',
    'cleanup_button' => $lang->get('admin_gallery_cleanup_button') ?? '🗑️ Alte Bilder löschen',
    'cleanup_select_label' => $lang->get('admin_gallery_cleanup_select_label') ?? 'Bilder älter als',
    'cleanup_select_days' => $lang->get('admin_gallery_cleanup_select_days') ?? 'Tage löschen',
    'confirm_delete' => $lang->get('admin_gallery_confirm_delete') ?? 'Wirklich löschen?',
    'error_delete_failed' => $lang->get('admin_gallery_error_delete_failed') ?? 'Fehler beim Löschen:',
    'error_network' => $lang->get('admin_gallery_error_network') ?? 'Netzwerkfehler:',
    // Menü 2
    'retention_title' => $lang->get('admin_gallery_retention_title') ?? '📅 Upload-Regel für User',
    'retention_days' => $lang->get('admin_gallery_retention_days') ?? 'Tage',
    'retention_save' => $lang->get('admin_gallery_retention_save') ?? '💾 Speichern',
    'retention_current' => $lang->get('admin_gallery_retention_current') ?? 'Aktuell',
    'retention_info' => $lang->get('admin_gallery_retention_info') ?? 'Diese Einstellung gilt für den automatischen Cleanup von User-Uploads.',
    'retention_success' => $lang->get('admin_gallery_retention_success') ?? '✅ Aufbewahrungsdauer für User-Uploads auf {days} Tage geändert!',
    'retention_error' => $lang->get('admin_gallery_retention_error') ?? '❌ Fehler beim Speichern!',
    'retention_invalid' => $lang->get('admin_gallery_retention_invalid') ?? '❌ Ungültiger Wert!'
];

    // Template-Variablen
    $vari1 = $this->buildGallery($lang);
    $vari2 = $this->csrfToken;
    $vari3 = htmlspecialchars($style, ENT_QUOTES, 'UTF-8');
    $vari4 = $this->imageCount;
    $vari5 = $this->loadRetentionDays(); // Aktuelle User-Retention
    $vari6 = [7, 14, 30, 60, 90, 180, 365]; // Optionen für beide Menüs
    
    $cleanupMessage = $_SESSION['gallery_cleanup_msg'] ?? '';
    unset($_SESSION['gallery_cleanup_msg']);
    
    $retentionMessage = $_SESSION['gallery_retention_msg'] ?? '';
    unset($_SESSION['gallery_retention_msg']);

    $tplPath = __DIR__ . '/../../styles/admin_tpl/indexGallery.tpl.html';

    if (!is_file($tplPath)) {
        exit($lang->get('admin_gallery_error_template') ?? 'Template fehlt: ' . $tplPath);
    }

    include $tplPath;
}
}