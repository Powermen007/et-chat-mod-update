<?php

/*

ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)

ET-Chat_T-FISH-MOD Weiterentwicklung des ET-Chats durch Tommy (Thomas Kuhn) und Harlekin (Bernd Witte)

Die Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

*/

$GLOBALS["path"] = "./";


spl_autoload_register(function($class_name) {
		require_once ($GLOBALS["path"].'class/'.$class_name.'.class.php');
});


class Weiterleitung extends DbConectionMaker
{

	public function __construct (){

		parent::__construct();

		unset($GLOBALS["path"]);

		$desei=$this->dbObj->sqlGet("SELECT etchat_config_id, etchat_config_style FROM {$this->_prefix}etchat_config WHERE etchat_config_id = '1'");

?>
<!DOCTYPE html>
<html lang="de">

<head>
<title>Weiterleitung</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php
 			if (is_array($desei)){
     			   foreach($desei as $data){
        				echo"<link href=\"styles/$data[1]/style.css\" rel=\"stylesheet\" type=\"text/css\"/>";
        		}
        	}
  $this->dbObj->close();
?>

</head>
<body id="body">

<center>
<div id="info">
<h1>WEITERLEITUNGSHINWEIS</h1><br/>
<p>Sie haben in unserem Chat einen Link angeklickt, der Sie auf fremde Seiten au&szlig;erhalb unseres Systems f&uuml;hrt. Auf Inhalte dieser Seiten haben wir keinen Einfluss und &uuml;bernehmen keinerlei Verantwortung. Sie benutzen diesen Link auf eigene Gefahr. Wenn Sie diesen Link ausf&uuml;hren m&ouml;chten, klicken sie auf <i>'Weiter zum Link'</i>, ansonsten schlie&szlig;en Sie einfach diesen Browsertab.</p><br/>
<?php

if (isset($_GET['url'])) {
    $link = $_GET['url'];
    echo "<a href=\"$link\"><h1>Weiter zum Link</h1></a>";
} else {
}

?>
<br/><br/>
</div>
</center>
</body>
</html>

<?php

	}
}

new Weiterleitung();

?>