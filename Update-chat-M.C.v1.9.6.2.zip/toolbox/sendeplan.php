<?php 
include 'box_config.php';
try {
    $pdo = new PDO("mysql:host=$dbhost;dbname=$dbname;charset=utf8", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die('<p style="color: red; font-weight: bold;">Datenbankverbindung zum Sendeplan fehlgeschlagen.<br>Bitte überprüfe deine Eingaben in der box_config.php.</p>');
}

$now = time();
$plugin_id = $web_php_id;
$domain = $web_php_domain;

function getThemaBild($thema) {
    $bildName = $thema . "_";
    $bilderVerzeichnis = '../thema/';
    include 'themenbild.php';
    return '../thema/' . $thema . '_' . (isset($bilder[$thema]) ? $bilder[$thema] : 'default.png');
}

if (isset($_GET['sendeplan'])) {
    $sql = "SELECT * FROM web_php_plugin_{$plugin_id}_radio_sendeplan 
            WHERE datum_time_von >= :now 
            ORDER BY datum_time_von ASC LIMIT 5";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':now', $now, PDO::PARAM_INT);
    $stmt->execute();
    $sendeplan = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sendeplan</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<style>body{font-family:Arial,sans-serif;color:#fff;background-color:black;margin:0;padding:20px}table{width:90%;max-width:900px;margin:auto;border-collapse:collapse}td,th{padding:15px;text-align:center;vertical-align:middle}th{border-bottom:2px solid #444}tr{border-bottom:1px solid #444}.avatar img,.thema img{width:auto;height:120px;object-fit:cover;border-radius:50%}.thema img{border-radius:0}i{color:orange;margin-right:5px;padding:5px 0;}</style>
</head>
<body>
	<table>
		<tbody>
			<?php foreach($sendeplan as $sendung):?>
			<tr>
				<td class="avatar">
					<img src="<?php
    echo (
        trim(
            html_entity_decode(
                $sendung['dj_name'], ENT_QUOTES, 'UTF-8'
            )
        ) == 'Auto DJ'  // prüft, ob der DJ-Name 'Auto DJ' ist
    )
    ? $auto_dj_bild  // wenn ja, dann Bild $auto_dj_bild anzeigen
    : $domain . '/dateien_upload/avatar/' .
      htmlspecialchars(
          html_entity_decode(
              $sendung['dj_bild'], ENT_QUOTES, 'UTF-8'
          )
      );  // sonst Pfad zum DJ-Bild zusammensetzen
?>" alt="<?php
    echo htmlspecialchars(
        html_entity_decode(
            $sendung['dj_name'], ENT_QUOTES, 'UTF-8'
        )
    );
?>">

				</td>
				<td class="info">
					<div><i class="fas fa-user"></i><?php echo htmlspecialchars(html_entity_decode($sendung['dj_name'], ENT_QUOTES, 'UTF-8')); ?></div>
					<div><i class="far fa-clock"></i><?php echo htmlspecialchars($sendung['zeit_von'] . ' - ' . $sendung['zeit_bis'], ENT_QUOTES, 'UTF-8'); ?></div>
					<div><i class="far fa-calendar-alt"></i><?php echo htmlspecialchars(date('d.m.Y', strtotime($sendung['datum']))); ?>
</div>
				</td>
				<td class="thema">
					<img src="<?php echo getThemaBild($sendung['thema']); ?>" alt="Thema Bild">
				</td>
			</tr>
			<?php endforeach;?>
		</tbody>
	</table>
</body>
</html>
<?php
// Aktuelle Sendung anzeigen
} elseif (isset($_GET['djonline'])) {
    $sql = "SELECT * FROM web_php_plugin_{$plugin_id}_radio_sendeplan 
            WHERE datum_time_von <= :now AND datum_time_bis >= :now 
            ORDER BY datum_time_von ASC LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':now', $now, PDO::PARAM_INT);
    $stmt->execute();
    $aktuelle_sendung = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>
<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="UTF-8" http-equiv="refresh" content="60">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Aktuelle Sendung</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<style>body{font-family:Arial,sans-serif;color:#fff;display:grid;place-items:center;height:100%}.center{text-align:center}.center img{width:70px;height:70px;border-radius:50%}i{color:orange;padding:5px 0}</style>
</head>
<body>
	<?php if($aktuelle_sendung):?>
	<div class="center">
		<img src="<?php echo (trim(html_entity_decode($aktuelle_sendung['dj_name'],ENT_QUOTES,'UTF-8'))=='Auto DJ')?$auto_dj_bild:$domain.'/dateien_upload/avatar/'.htmlspecialchars(html_entity_decode($aktuelle_sendung['dj_bild'],ENT_QUOTES,'UTF-8')); ?>">
		<br><i class="fas fa-user"></i> <?php echo htmlspecialchars($aktuelle_sendung['dj_name']); ?>
		<br><i class="far fa-clock"></i> <?php echo htmlspecialchars($aktuelle_sendung['zeit_von']).' - '.htmlspecialchars($aktuelle_sendung['zeit_bis']); ?>

	</div>
	<?php else:?>
	<div class="center" style="margin-top: 5px">Aktuell hören Sie den<br><br><b>AutoDJ</b><br><br>Nächste Live-Sendung<br>siehe Sendeplan.</div>
	<?php endif;?>
</body>
</html>
<?php }else{echo 'Ungültige Anfrage.';} ?>
