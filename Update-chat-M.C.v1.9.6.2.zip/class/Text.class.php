<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

class Text extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        $id = (int)($_GET['id'] ?? 0);

        // Text aus DB holen
        $feld = $this->dbObj->sqlGet(
            "SELECT id, ort, header_text, content
             FROM {$this->_prefix}etchat_texte
             WHERE id = :id
             LIMIT 1",
            [":id" => $id]
        );

        // Config laden (Style)
        $desei = $this->dbObj->sqlGet(
            "SELECT etchat_config_id, etchat_config_style
             FROM {$this->_prefix}etchat_config
             WHERE etchat_config_id = 1
             LIMIT 1"
        );

        $this->dbObj->close();

        // HTML Kopf
        echo "<!doctype html>
        <html lang=\"de\">
        <head>
            <meta charset=\"UTF-8\" />
            <title></title>
            <link href=\"styles/";

        if (!empty($desei[0]['etchat_config_style'])) {
            echo htmlspecialchars($desei[0]['etchat_config_style'], ENT_QUOTES | ENT_SUBSTITUTE);
        } else {
            echo 'default';
        }

        echo "/style.css\" rel=\"stylesheet\" type=\"text/css\">
        </head>
        <body id=\"body\">";

        // Inhalt ausgeben
        if (!empty($feld[0])) {
            $datasets = $feld[0];

            echo "<h1 style=\"margin-top:0.05px;margin-bottom:0.05px;\">";
            echo htmlspecialchars_decode($datasets['header_text']);
            echo "</h1><br>";
            echo htmlspecialchars_decode($datasets['content']);
        } else {
            echo "<p>Kein Inhalt gefunden.</p>";
        }

        echo "</body></html>";
    }
}