<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminCreateNewSmiliesCat extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // SESSION & HEADER
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // Sprache laden
        // -------------------------
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        // -------------------------
        // CSRF TOKEN erzeugen (wenn nicht vorhanden)
        // -------------------------
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';

		if (empty($_SESSION[$csrfKey])) {
			$_SESSION[$csrfKey] = bin2hex(random_bytes(16));
		}

		$csrf_token = $_SESSION[$csrfKey];

        // -------------------------
        // Rollen prüfen
        // -------------------------
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $allowedRoles = ["admin", "grafik", "co_admin"];
        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // Template initialisieren
        // -------------------------
        $this->initTemplate($lang, $csrf_token);
    }

    private function initTemplate(object $lang, string $csrf_token): void
    {
        // -------------------------
        // Smilies-Kategorien laden
        // -------------------------
        $cats = $this->dbObj->sqlGet("SELECT name FROM {$this->_prefix}etchat_smileys_cat") ?: [];

        // -------------------------
        // HTML-Sicherheit
        // -------------------------
        foreach ($cats as &$cat) {
            $cat['name'] = htmlspecialchars($cat['name'] ?? '', ENT_QUOTES, 'UTF-8');
        }
        unset($cat);

        // -------------------------
        // Template einbinden
        // -------------------------
        include __DIR__ . "/../../styles/admin_tpl/createNewSmiliesCat.tpl.html";

        // -------------------------
        // DB sauber schließen
        // -------------------------
        $this->dbObj->close();
    }
}