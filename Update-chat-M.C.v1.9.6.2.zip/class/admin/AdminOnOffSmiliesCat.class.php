<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

     declare(strict_types=1);

class AdminOnOffSmiliesCat extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // 🔐 Session starten, falls noch nicht aktiv
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔹 Sprachobjekt laden
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0] ?? (object)[
            'error' => [(object)['tagData' => 'Zugriff verweigert']]
        ];

        // Rollenprüfung
        $allowedRoles = ["admin", "co_admin", "grafik"];
        $userRole = isset($_SESSION['etchat_'.$this->_prefix.'user_priv'])
			? (string) $_SESSION['etchat_'.$this->_prefix.'user_priv']
			: '';
			
        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // 🔹 Request zusammenführen (POST + GET)
        $req = array_merge($_GET, $_POST);

        // 🔐 CSRF Token prüfen
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';
        $requestToken = $req["csrf_token"] ?? '';

        if (empty($requestToken) || empty($sessionToken) || !hash_equals((string)$sessionToken, (string)$requestToken)) {
            echo "Ungültiger Request (CSRF erkannt)";
            return;
        }

        // 🔹 ID validieren
        $id = isset($req["id"]) ? (int)$req["id"] : 0;
        if ($id <= 0) {
            header("Location: ./?AdminSmiliesCatIndex");
            exit;
        }

        // 🔹 Status validieren
        $allowed = ['on', 'off'];
        $current = $req["on_on_off"] ?? 'off';
        if (!in_array($current, $allowed, true)) {
            $current = 'off';
        }

        // 🔹 Update via PDO (prepared statement)
        $this->dbObj->sqlSet(
            "UPDATE {$this->_prefix}etchat_smileys_cat 
             SET aktiv = ? 
             WHERE id = ?",
            [
                $current,
                $id
            ]
        );

        $this->dbObj->close();

        // 🔹 Weiterleitung zurück zur Kategorie-Übersicht
        header("Location: ./?AdminSmiliesCatIndex");
        exit;
    }
}