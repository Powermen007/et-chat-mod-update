<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteSmiliesCat extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache
        $lang = (new LangXml())->getLang()->admin[0]->admin_smilies[0];

        // 🔐 Rollen prüfen
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';

        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // 🔥 GET + POST kompatibel
        $data = $_GET + $_POST;

        // 🔐 CSRF Tokens
        $sessionToken = (string)($_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '');
        $actionToken  = (string)($data['csrf_token'] ?? '');

        // 🔥 Eingaben absichern
        $cat = $data['cat'] ?? '';
        $id  = isset($data['id']) ? (int)$data['id'] : 0;

        // 🔐 CSRF prüfen, falls Aktion ausgeführt wird
        if ($cat !== '' && (!hash_equals($sessionToken, $actionToken))) {
            echo "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            exit;
        }

        if ($cat !== '') {
            // 🔹 Alle Smilies der Kategorie holen
            $smilies = $this->dbObj->sqlGet(
                "SELECT etchat_smileys_img FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_kat = ?",
                [$cat]
            );

            // 🔹 Pfade
            $projectRoot = realpath(__DIR__ . '/../../');
            $smilieRoot  = realpath($projectRoot . '/smilies');

            // 🔹 Dateien löschen
            if (is_array($smilies)) {
                foreach ($smilies as $row) {
                    $imgPath = $row[0] ?? '';
                    if ($imgPath !== '') {
                        $imgPath  = ltrim($imgPath, './');
                        $fullPath = $projectRoot . '/' . $imgPath;

                        if ($smilieRoot && strpos($fullPath, $smilieRoot) === 0 && is_file($fullPath)) {
                            @unlink($fullPath);
                        }
                    }
                }
            }

            // 🔹 DB-Einträge löschen
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_kat = ?",
                [$cat]
            );

            if ($id > 0) {
                $this->dbObj->sqlSet(
                    "DELETE FROM {$this->_prefix}etchat_smileys_cat WHERE id = ?",
                    [$id]
                );
            }

            // 🔹 Kategorie-Ordner löschen
            $safeFolder = preg_replace("/[^a-zA-Z0-9_-]/", "_", $cat);
            $catFolder  = $smilieRoot . '/' . $safeFolder;

            if (is_dir($catFolder)) {
                $files = glob($catFolder . '/*');
                if (is_array($files)) {
                    foreach ($files as $file) {
                        if (is_file($file)) {
                            @unlink($file);
                        }
                    }
                }
                @rmdir($catFolder);
            }
        }

        $this->dbObj->close();

        // 🔁 Redirect zurück zur Smilies-Kategorie Übersicht
        header("Location: ./?AdminSmiliesCatIndex");
        exit;
    }
}