<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.

Speichert die sortierreihenfolge der Smily
*/

declare(strict_types=1);

class AdminUpdateSmiliesOrder extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sicher starten
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Content-Type: application/json; charset=utf-8");

        // 🔐 Rechteprüfung
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($role, $allowedRoles, true)) {
            http_response_code(403);
            echo json_encode(["error" => "Keine Berechtigung"]);
            exit;
        }

        // 🔐 JSON lesen
        $raw  = file_get_contents("php://input");
        $data = json_decode($raw, true);

        if (!is_array($data)) {
            http_response_code(400);
            echo json_encode(["error" => "Ungültige JSON-Daten"]);
            exit;
        }

        // 🔐 CSRF prüfen (Header)
        $csrfHeader   = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? null;

        if (!is_string($csrfHeader) || !is_string($sessionToken) || !hash_equals($sessionToken, $csrfHeader)) {
            http_response_code(403);
            echo json_encode(["error" => "Ungültiger CSRF Token"]);
            exit;
        }

        try {
            $pdo = $this->dbObj->getConnection();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                UPDATE {$this->_prefix}etchat_smileys
                SET etchat_smileys_gewicht = :gewicht
                WHERE etchat_smileys_id = :id
            ");

            foreach ($data as $row) {
                if (!isset($row["id"], $row["weight"]) || !is_numeric($row["id"]) || !is_numeric($row["weight"])) {
                    continue;
                }

                $stmt->execute([
                    ':id'      => (int)$row["id"],
                    ':gewicht' => (int)$row["weight"]
                ]);
            }

            $pdo->commit();
            $this->dbObj->close();

            echo json_encode(["success" => true]);
            exit;

        } catch (PDOException $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            http_response_code(500);
            echo json_encode(["error" => "Datenbankfehler"]);
            exit;
        }
    }
}