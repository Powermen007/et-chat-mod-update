<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDelUserPriv extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache
        $lang = (new LangXml())->getLang()->admin[0]->admin_user[0];

        // 🔐 Rollen prüfen
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        $allowedRoles = ['admin', 'chatwache', 'co_admin'];

        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // 🔐 GET + CSRF absichern
        $id = (int)($_GET['id'] ?? 0);
        $csrfToken = (string)($_GET['csrf_token'] ?? '');
        $sessionToken = (string)($_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '');

        if ($id <= 0 || $csrfToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $csrfToken)) {
            echo "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            return;
        }

        // 🔥 Avatar aus DB holen
        $avatarData = $this->dbObj->sqlGet(
            "SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_user_id = :id",
            [':id' => $id]
        );

        $avatarFile = $avatarData[0][0] ?? '';

        // 🔥 Avatar-Datei löschen (geschützte Dateien ausnehmen)
        if ($avatarFile !== '') {
            $file = basename($avatarFile);
            $protectedFiles = ["noavatar.jpg", "mod_ohne_pic.png", "autodj.jpg"];

            if (!in_array($file, $protectedFiles, true)) {
                $avatarPath = dirname(__DIR__, 2) . '/avatar/' . $file;
                if (file_exists($avatarPath)) {
                    @unlink($avatarPath);
                }
            }
        }

        // 🔥 User aus DB löschen
        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_user WHERE etchat_user_id = :id",
            [':id' => $id]
        );

        $this->dbObj->close();

        // 🔁 Redirect zurück zur User-Übersicht
        header("Location: ./?AdminUserIndex");
        exit;
    }
}