<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteMenu extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_rooms[0];

        // 🔐 Rechte prüfen (nur admin)
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($role !== 'admin') {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // 🔐 CSRF Token
        $csrfKey = 'etchat_'.$this->_prefix.'csrf_token';
        if (empty($_SESSION[$csrfKey])) {
            $_SESSION[$csrfKey] = bin2hex(random_bytes(16));
        }
        $checksum = (string) $_SESSION[$csrfKey];

        // 🔥 GET + POST kompatibel
        $data = $_GET + $_POST;

        // 🔐 ID absichern
        $id = isset($data['id']) ? (int)$data['id'] : 0;
        $actionToken = (string)($data['csrf_token'] ?? '');

        // 🔐 CSRF Prüfung + ID
        if ($id > 0) {
            if (empty($actionToken) || !hash_equals($checksum, $actionToken)) {
                echo "Manipulationsversuch erkannt.";
                $this->dbObj->close();
                exit;
            }

            // 🔹 Menü löschen
            $this->dbObj->sqlSet(
                "DELETE FROM {$this->_prefix}etchat_menu WHERE id = :id",
                [':id' => $id]
            );

            $this->dbObj->close();

            // 🔁 Redirect
            header("Location: ./?AdminMenusIndex");
            exit;
        }

        $this->dbObj->close();
    }
}