<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteSmilies extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_smilies[0];

        // 🔐 Rollen prüfen
        $allowedRoles = ["admin", "grafik", "co_admin"];
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // 🔐 CSRF Token vorbereiten
        if (!isset($_SESSION['etchat_' . $this->_prefix . 'csrf_token'])) {
            $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] = bin2hex(random_bytes(16));
        }
        $checksum = (string)$_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

        // 🔥 Request-Daten
        $id         = (int)($_GET['id'] ?? 0);
        $csrf_token = (string)($_GET['csrf_token'] ?? '');
        $picRaw     = $_GET['pic'] ?? '';

        // 🔐 CSRF + ID prüfen
        if ($id <= 0 || empty($csrf_token) || !hash_equals($checksum, $csrf_token)) {
            echo "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            exit;
        }

        // 🔹 Smiley aus DB löschen
        $this->dbObj->sqlSet(
            "DELETE FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_id = :id",
            [':id' => $id]
        );

        // 🔹 Datei löschen (nur aus smilies-Ordner)
        if (!empty($picRaw)) {
            $picSafe = ltrim($picRaw, './'); // ./ entfernen
            $projectRoot = realpath(__DIR__ . '/../../');
            $fullPath = $projectRoot . '/' . $picSafe;
            $smiliesRoot = realpath($projectRoot . '/smilies/');

            if ($fullPath && $smiliesRoot && strpos($fullPath, $smiliesRoot) === 0 && is_file($fullPath)) {
                @unlink($fullPath);
            }
        }

        $this->dbObj->close();

        // 🔁 Redirect
        header("Location: ./?AdminSmiliesIndex");
        exit;
    }
}