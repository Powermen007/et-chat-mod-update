<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateRoom extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache sicher laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();

        $lang = $langData->admin[0]->admin_rooms[0] ?? (object)[
            'error' => [(object)['tagData' => 'Fehler']]
        ];

        // Eingaben
        $id    = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // 🔐 CSRF prüfen
        if ($token === '' || !$this->isValidCsrfToken($token)) {
            echo htmlspecialchars(($lang->error[0]->tagData ?? 'Fehler') . ' (CSRF)', ENT_QUOTES, 'UTF-8');
            exit;
        }

        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');

        // 🔐 Adminrechte prüfen
        if ($id > 0 && in_array($role, ['admin', 'co_admin'], true)) {

            $updates = [];
            $params  = [];

            // Raumname
            $updates[] = "etchat_roomname = :roomname";
            $params['roomname'] = trim((string)($_POST['room'] ?? ''));

            // Raumrechte
            $updates[] = "etchat_room_goup = :room_priv";
            $params['room_priv'] = (int)($_POST['room_priv'] ?? 0);

            // Passwort nur bei geschütztem Raum
            if ($params['room_priv'] === 3) {
                $updates[] = "etchat_room_pw = :roompw";
                $params['roompw'] = trim((string)($_POST['roompw'] ?? ''));
            } else {
                $updates[] = "etchat_room_pw = NULL";
            }

            // Raum-Nachricht
            $updates[] = "etchat_room_message = :roommessage";
            $params['roommessage'] = trim((string)($_POST['roommessage'] ?? ''));

            // === UPDATE ===
            $sql = "UPDATE {$this->_prefix}etchat_rooms 
                    SET " . implode(", ", $updates) . " 
                    WHERE etchat_id_room = :id";

            $params['id'] = $id;

            $this->dbObj->sqlSet($sql, $params);

            $this->dbObj->close();

            // 🔄 Redirect nach Erfolg
            header("Location: ./?AdminRoomsIndex");
            exit;

        } else {
            echo htmlspecialchars($lang->error[0]->tagData ?? 'Fehler', ENT_QUOTES, 'UTF-8');
            exit;
        }
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        return isset($_SESSION[$key]) && hash_equals($_SESSION[$key], $token);
    }
}