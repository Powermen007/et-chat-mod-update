<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminBoxsIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // Sprache laden
        // -------------------------
        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_menus[0] ?? (object)[
            'error' => [(object)['tagData' => 'Fehler: Sprachdatei unvollständig.']]
        ];

        // -------------------------
        // Rollen prüfen
        // -------------------------
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($userPriv !== 'admin') {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // -------------------------
        // CSRF Token erzeugen
        // -------------------------
        if (empty($_SESSION['etchat_' . $this->_prefix . 'csrf_token'])) {
            $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] = bin2hex(random_bytes(16));
        }
        $csrfToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

        // -------------------------
        // Boxen laden
        // -------------------------
        $felder = $this->dbObj->sqlGet("SELECT id, ort, header_text FROM {$this->_prefix}etchat_start_boxes ORDER BY id");
        $this->dbObj->close();

        $print_box_list = "";

        if (is_array($felder) && !empty($felder)) {
            $print_box_list = "<table border='1' cellpadding='5' cellspacing='0'>
                <tr>
                    <th>ID</th>
                    <th>Ort</th>
                    <th>&Uuml;berschrift</th>
                    <th>Bearbeiten</th>
                </tr>";

            foreach ($felder as $datasets) {
                $id = htmlspecialchars((string)$datasets[0], ENT_QUOTES, 'UTF-8');
                $ort = htmlspecialchars((string)$datasets[1], ENT_QUOTES, 'UTF-8');
                $header = strip_tags((string)$datasets[2], '<b><i><strong><em><center><font><small><span>');

                $print_box_list .= "<tr>
                    <td>{$id}</td>
                    <td>{$ort}</td>
                    <td>{$header}</td>
                    <td><a href=\"./?AdminEditBox&id={$id}\">Editieren</a></td>
                </tr>";
            }

            $print_box_list .= "</table>";
        }

        // -------------------------
        // Template einbinden
        // -------------------------
        $this->initTemplate($lang, $print_box_list);
    }

    private function initTemplate(object $lang, string $print_box_list): void
    {
        include __DIR__ . "/../../styles/admin_tpl/indexBoxs.tpl.html";
    }
}