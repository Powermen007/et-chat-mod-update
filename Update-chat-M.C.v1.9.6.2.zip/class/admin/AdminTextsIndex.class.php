<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminTextsIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        // Header setzen
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();

        $lang = $langData->admin[0]->admin_menus[0] ?? (object)[
            'error' => [(object)['tagData' => 'Fehler: Sprachdatei unvollständig.']]
        ];

        // Rollenprüfung
        $allowedRoles = ["admin"];
        $userRole = isset($_SESSION['etchat_'.$this->_prefix.'user_priv'])
            ? (string) $_SESSION['etchat_'.$this->_prefix.'user_priv']
            : '';

        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // CSRF Token erzeugen
        if (empty($_SESSION['etchat_'.$this->_prefix.'csrf_token'])) {
            $_SESSION['etchat_'.$this->_prefix.'csrf_token'] = bin2hex(random_bytes(16));
        }
        $csrfToken = $_SESSION['etchat_'.$this->_prefix.'csrf_token'];

        // Daten laden
        $felder = $this->dbObj->sqlGet("
            SELECT id, ort, header_text 
            FROM {$this->_prefix}etchat_texte 
            ORDER BY id
        ");

        $print_text_list = '';

        if (!empty($felder) && is_array($felder)) {

            $print_text_list .= "<table border='1' cellpadding='5' cellspacing='0'>";
            $print_text_list .= "
                <tr>
                    <th>ID</th>
                    <th>Bezeichnung</th>
                    <th>Überschrift</th>
                    <th>Bearbeiten</th>
                </tr>
            ";

            foreach ($felder as $datasets) {

                $id   = htmlspecialchars((string)($datasets['id'] ?? ''), ENT_QUOTES, 'UTF-8');
                $ort  = htmlspecialchars((string)($datasets['ort'] ?? ''), ENT_QUOTES, 'UTF-8');

                $headerRaw = (string)($datasets['header_text'] ?? '');
                $header = htmlspecialchars(strip_tags($headerRaw), ENT_QUOTES, 'UTF-8');

                $print_text_list .= "
                    <tr>
                        <td>{$id}</td>
                        <td>{$ort}</td>
                        <td>{$header}</td>
                        <td>
                            <a href=\"./?AdminEditText&id={$id}&csrf_token={$csrfToken}\">
                                Editieren
                            </a>
                        </td>
                    </tr>
                ";
            }

            $print_text_list .= "</table>";
        }

        $this->dbObj->close();

        $this->initTemplate($lang, $print_text_list);
    }

    private function initTemplate($lang, $print_text_list): void
    {
        include_once "styles/admin_tpl/indexTexts.tpl.html";
    }
}