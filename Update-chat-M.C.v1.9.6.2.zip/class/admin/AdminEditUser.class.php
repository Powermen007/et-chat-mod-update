<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditUser extends DbConectionMaker
{
    private const ALLOWED_ROLES = ['admin', 'chatwache', 'co_admin'];
    private string $csrfKey;

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_user[0];

        // 🔐 Rechte prüfen
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($role, self::ALLOWED_ROLES, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // 🔐 CSRF Token initialisieren, NICHT jedes Mal überschreiben
        $this->csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        if (empty($_SESSION[$this->csrfKey])) {
            $_SESSION[$this->csrfKey] = bin2hex(random_bytes(16));
        }

        // 🔥 User ID validieren
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            echo 'Ungültige ID.';
            return;
        }

        // 🔹 Userdaten mit PDO Prepared Statement laden
        $feld = $this->dbObj->sqlGet(
            "SELECT etchat_user_id, etchat_username, etchat_userpw, etchat_userprivilegien, etchat_email 
             FROM {$this->_prefix}etchat_user 
             WHERE etchat_user_id = ?",
            [$id]
        );

        $this->dbObj->close();

        if (!is_array($feld) || empty($feld[0])) {
            echo 'Benutzer nicht gefunden.';
            return;
        }

        // 🔹 Template laden – alte Struktur bleibt kompatibel
        $this->initTemplate($lang, $feld);
    }

    private function initTemplate(object $lang, array $feld): void
    {
        include_once("styles/admin_tpl/editUser.tpl.html");
    }
}