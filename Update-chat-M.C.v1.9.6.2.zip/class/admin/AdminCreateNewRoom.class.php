<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminCreateNewRoom extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // Sprache laden
        // -------------------------
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_rooms[0];

        // -------------------------
        // Rollencheck
        // -------------------------
        $role = $_SESSION["etchat_" . $this->_prefix . "user_priv"] ?? '';
        $allowedRoles = ["admin", "co_admin"];
        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // CSRF prüfen
        // -------------------------
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';
        $requestToken = $_POST['csrf_token'] ?? '';
        if (empty($sessionToken) || empty($requestToken) || !hash_equals($sessionToken, $requestToken)) {
            echo "CSRF Fehler – ungültige Anfrage.";
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // Eingaben holen
        // -------------------------
        $roomName = trim($_POST['room'] ?? '');
        $roomPriv = (int)($_POST['room_priv'] ?? 0);
        $roomPw   = trim($_POST['roompw'] ?? '');

        // -------------------------
        // Validierung
        // -------------------------
        if ($roomName === '' || ($roomPriv === 3 && $roomPw === '')) {
            echo "<p style='color:red;'>Raumname oder Passwort ungültig.</p>";
            $this->dbObj->close();
            exit;
        }

        // -------------------------
        // Insert in DB
        // -------------------------
        if ($roomPriv === 3) {
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_rooms (etchat_roomname, etchat_room_goup, etchat_room_pw)
                 VALUES (:room, :priv, :pw)",
                [
                    ':room' => $roomName,
                    ':priv' => $roomPriv,
                    ':pw'   => $roomPw
                ]
            );
        } else {
            $this->dbObj->sqlSet(
                "INSERT INTO {$this->_prefix}etchat_rooms (etchat_roomname, etchat_room_goup)
                 VALUES (:room, :priv)",
                [
                    ':room' => $roomName,
                    ':priv' => $roomPriv
                ]
            );
        }

        // -------------------------
        // DB schließen & Token entfernen
        // -------------------------
        $this->dbObj->close();
        unset($_SESSION['etchat_' . $this->_prefix . 'csrf_token']);

        // -------------------------
        // Weiterleitung
        // -------------------------
        header("Location: ./?AdminRoomsIndex");
        exit;
    }
}