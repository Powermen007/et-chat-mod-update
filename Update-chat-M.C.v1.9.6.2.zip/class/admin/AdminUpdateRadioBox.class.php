<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateRadioBox extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache sicher laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();

        $lang = $langData->admin[0]->admin_rooms[0] ?? (object)[
            'error' => [(object)['tagData' => 'Fehler']]
        ];

        // Eingaben
        $id    = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // 🔐 CSRF prüfen
        if ($token === '' || !$this->isValidCsrfToken($token)) {
            echo htmlspecialchars(($lang->error[0]->tagData ?? 'Fehler') . ' (CSRF)', ENT_QUOTES, 'UTF-8');
            exit;
        }

        // 🔐 Adminrechte prüfen
        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');

        if ($role !== 'admin' || $id <= 0) {
            echo htmlspecialchars($lang->error[0]->tagData ?? 'Fehler', ENT_QUOTES, 'UTF-8');
            exit;
        }

        $updates = [];
        $params  = [];

        // === FELDER ===
        $fields = [
            'host'      => 'etchat_radio_horst',
            'port'       => 'etchat_radio_port',
            'radio_server_type'  => 'etchat_radio_typ',
            'stream'     => 'etchat_radio_stream',
            'streamname' => 'etchat_radio_name',
            'color'      => 'etchat_radio_color',
            'bits'       => 'etchat_radio_bit',
            'radiobox'    => 'etchat_radio_box',
            'player'      => 'etchat_radio_player',
            'on_air'      => 'etchat_on_air',
            'sys_titel'   => 'etchat_system_titel_an',
            'titel_hist'  => 'etchat_titel_an'
        ];

        foreach ($fields as $postKey => $dbField) {
            if (isset($_POST[$postKey])) {
                $updates[] = "$dbField = :$postKey";
                $params[$postKey] = trim((string)$_POST[$postKey]);
            }
        }

        // === UPDATE ===
        if (!empty($updates)) {
            $sql = "UPDATE {$this->_prefix}etchat_radio_box 
                    SET " . implode(", ", $updates) . " 
                    WHERE etchat_radio_id = :id";

            $params['id'] = $id;

            $this->dbObj->sqlSet($sql, $params);
        }

        $this->dbObj->close();

        // 🔄 Redirect nach Erfolg
        header("Location: ./?AdminRadioBoxIndex");
        exit;
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        return isset($_SESSION[$key]) && hash_equals($_SESSION[$key], $token);
    }
}