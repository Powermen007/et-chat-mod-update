<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminBroadcast extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // -------------------------
        // Config Daten in Session laden
        // -------------------------
        $this->configTabData2Session();

        // -------------------------
        // DB Verbindung schließen
        // -------------------------
        $this->dbObj->close();

        // -------------------------
        // Sprache laden
        // -------------------------
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_prop[0];

        // -------------------------
        // Rollen prüfen
        // -------------------------
        $userPriv = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        $allowedRoles = ['admin', 'co_admin'];
        if (!in_array($userPriv, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // -------------------------
        // Backlink je Rolle
        // -------------------------
        $backlink = ($userPriv === 'co_admin') ? './?AdminIndexCoAdmin' : './?AdminIndex';

        // -------------------------
        // Template einbinden
        // -------------------------
        include __DIR__ . "/../../styles/admin_tpl/indexBroadcast.tpl.html";
    }
}