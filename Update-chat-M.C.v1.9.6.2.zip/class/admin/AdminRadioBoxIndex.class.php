<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRadioBoxIndex extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        $langObj = new LangXml();
        $langData = $langObj->getLang();
        $lang = $langData->admin[0]->admin_radio[0] ?? (object)[
            'error' => [(object)['tagData' => 'Fehler: Sprachdatei unvollständig.']]
        ];

        // Rollenprüfung
        $allowedRoles = ["admin", "co_admin"];
        $userRole = isset($_SESSION['etchat_'.$this->_prefix.'user_priv'])
			? (string) $_SESSION['etchat_'.$this->_prefix.'user_priv']
			: '';
			
        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        $csrfToken = $this->getCsrfToken();

        $radioList = $this->fetchRadioList();

        $this->initTemplate($lang, $radioList, $userRole, $csrfToken);
    }

    /**
     * CSRF Token sicher generieren oder zurückgeben
     */
    private function getCsrfToken(): string
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        if (empty($_SESSION[$key])) {
            $_SESSION[$key] = bin2hex(random_bytes(16));
        }
        return $_SESSION[$key];
    }

    /**
     * Radio Box Daten aus DB holen
     */
    private function fetchRadioList(): array
    {
        $feld = $this->dbObj->sqlGet(
            "SELECT 
                etchat_radio_id,
                etchat_radio_horst,
                etchat_radio_port,
                etchat_radio_typ,
                etchat_radio_stream,
                etchat_radio_name,
                etchat_radio_color,
                etchat_radio_bit,
                etchat_radio_box,
                etchat_radio_player,
                etchat_on_air,
                etchat_system_titel_an,
                etchat_titel_an
             FROM {$this->_prefix}etchat_radio_box
             ORDER BY etchat_radio_id ASC"
        );

        $this->dbObj->close();

        $radioList = [];
        if (!is_array($feld)) return $radioList;

        foreach ($feld as $row) {
			$radioList[] = [
				'id'        => (int)($row['etchat_radio_id'] ?? 0),

				'host'      => htmlspecialchars((string)($row['etchat_radio_horst'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'port'      => htmlspecialchars((string)($row['etchat_radio_port'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'typ'       => htmlspecialchars((string)($row['etchat_radio_typ'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'stream'    => htmlspecialchars((string)($row['etchat_radio_stream'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'name'      => htmlspecialchars((string)($row['etchat_radio_name'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'color'     => htmlspecialchars((string)($row['etchat_radio_color'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'bit'       => htmlspecialchars((string)($row['etchat_radio_bit'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'box'       => htmlspecialchars((string)($row['etchat_radio_box'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'player'    => htmlspecialchars((string)($row['etchat_radio_player'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'onAir'     => htmlspecialchars((string)($row['etchat_on_air'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'sysTitel'  => htmlspecialchars((string)($row['etchat_system_titel_an'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
				'titelHits' => htmlspecialchars((string)($row['etchat_titel_an'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
			];
		}

        return $radioList;
    }

    /**
     * Template laden
     */
    private function initTemplate(object $lang, array $radioList, string $userRole, string $csrfToken): void
    {
        include_once "styles/admin_tpl/indexRadioBox.tpl.html";
    }
}