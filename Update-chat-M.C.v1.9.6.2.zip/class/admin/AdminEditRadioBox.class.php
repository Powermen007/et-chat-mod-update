<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditRadioBox extends DbConectionMaker
{
    private string $csrfKey;

    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sicher starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_rooms[0];

        // 🔐 Rechte prüfen (nur admin)
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if (!in_array($role, ['admin'], true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            return;
        }

        // 🔐 CSRF Token initialisieren
        $this->csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        if (empty($_SESSION[$this->csrfKey])) {
            $_SESSION[$this->csrfKey] = bin2hex(random_bytes(16));
        }

        // 🔹 GET + POST kompatibel
        $data = $_GET + $_POST;

        // 🔥 ID absichern (default 1)
        $id = (int)($data['id'] ?? 1);
        if ($id <= 0) {
            echo "Ungültige ID.";
            return;
        }

        // 🔹 PDO Prepared Statement
        $feld = $this->dbObj->sqlGet(
            "SELECT 
                etchat_radio_id,
                etchat_radio_horst,
                etchat_radio_port,
                etchat_radio_typ,
                etchat_radio_stream,
                etchat_radio_name,
                etchat_radio_color,
                etchat_radio_bit,
                etchat_radio_box,
                etchat_radio_player,
                etchat_on_air,
                etchat_system_titel_an,
                etchat_titel_an 
             FROM {$this->_prefix}etchat_radio_box 
             WHERE etchat_radio_id = ?",
            [$id]
        );

        $this->dbObj->close();

        if (!is_array($feld) || empty($feld[0])) {
            echo "Eintrag nicht gefunden.";
            return;
        }

        // 🔹 Template laden
        $this->initTemplate($lang, $feld);
    }

    private function initTemplate(object $lang, array $feld): void
    {
        include __DIR__ . "/../../styles/admin_tpl/editRadioBox.tpl.html";
    }
}