<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRenameSmilies extends ConnectDB
{
    private array $request = [];
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔁 GET + POST unified
        $this->request = array_merge($_GET, $_POST);

        // 🔐 CSRF Token erzeugen / Präfix-System
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        if (empty($_SESSION[$csrfKey])) {
            $_SESSION[$csrfKey] = bin2hex(random_bytes(16));
        }
        $this->csrfToken = $_SESSION[$csrfKey];

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_smilies[0];

        // 🔐 Rechte prüfen
        if (!$this->isAllowed()) {
            echo $lang->error[0]->tagData;
            return;
        }

        // 🔐 CSRF prüfen (nur bei POST!)
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->checkCsrf()) {
                echo "Ungültiger CSRF Token";
                return;
            }
        }

        // 🔐 ID absichern
        $id = (int)($this->request['id'] ?? 0);
        if ($id <= 0) {
            echo "Ungültige ID";
            return;
        }

        // 🔐 Daten laden
		$feld = $this->sqlGet(
			"SELECT * FROM {$this->_prefix}etchat_smileys WHERE etchat_smileys_id = :id",
			[':id' => $id]
		);

		$cats = $this->sqlGet(
			"SELECT * FROM {$this->_prefix}etchat_smileys_cat"
		);

		$feld = is_array($feld) ? $feld : [];
		$cats = is_array($cats) ? $cats : [];

        $this->close();

        // 🔐 Token & Daten ans Template geben
        $this->initTemplate($lang, $feld, $cats, $this->csrfToken);
    }

    private function isAllowed(): bool
	{
		$allowedRoles = ["admin", "co_admin", "grafik"];
		$userRole = isset($_SESSION['etchat_'.$this->_prefix.'user_priv'])
			? (string) $_SESSION['etchat_'.$this->_prefix.'user_priv']
			: '';
        
		if (!in_array($userRole, $allowedRoles, true)) {
			header("Location: ./");
			exit;
		}

		return true;
	}

    private function checkCsrf(): bool
    {
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        return isset($this->request['csrf_token'], $_SESSION[$csrfKey]) &&
            hash_equals($_SESSION[$csrfKey], $this->request['csrf_token']);
    }

    private function initTemplate($lang, $feld, $cats, string $csrf): void
    {
        
        include_once("styles/admin_tpl/renameSmilies.tpl.html");
    }
} // <-- Korrektes Schließen der Klasse