<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminRoomsIndex extends ConnectDB
{
    private array $request = [];
    private string $csrfToken = '';

    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 CSRF Token erzeugen / Präfix-System
        $csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        if (empty($_SESSION[$csrfKey])) {
            $_SESSION[$csrfKey] = bin2hex(random_bytes(16));
        }
        $this->csrfToken = $_SESSION[$csrfKey];

        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_rooms[0];

        // 🔐 Rechte prüfen
        if (!$this->isAllowed()) {
            echo $lang->error[0]->tagData;
            return;
        }

        // 🔐 DB
        $feld = $this->sqlGet(
            "SELECT etchat_id_room, etchat_roomname, etchat_room_goup 
             FROM {$this->_prefix}etchat_rooms"
        );

        $this->close();

        // 🧠 Liste bauen
        $print_room_list = "";

        if (is_array($feld)) {

            $print_room_list = "<table>";

            foreach ($feld as $row) {

                $id   = (int)$row['etchat_id_room'];
                $name = htmlspecialchars((string)($row['etchat_roomname'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                $priv = (int)($row['etchat_room_goup'] ?? 0);
				$privText = $lang->room_priv[$priv]->tagData ?? '';

                if ($id !== 1) {

                    $print_room_list .= "
                        <tr>
                            <td><b>{$name}</b></td>
                            <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>
                                <a href=\"./?AdminDeleteRoom&id={$id}&csrf_token={$this->csrfToken}\"
											onclick=\"return confirm('Raum wirklich löschen?');\">
											{$lang->delete[0]->tagData}
								</a>
                            </td>
                            <td>
                                <a href=\"./?AdminEditRoom&id={$id}\">
                                    {$lang->rename[0]->tagData}
                                </a>
                            </td>
                            <td>&nbsp;&nbsp;&nbsp;<i>{$privText}</i></td>
                        </tr>";
                } else {

                    $print_room_list .= "
                        <tr>
                            <td><b>{$name}</b></td>
                            <td>&nbsp;&nbsp;&nbsp;</td>
                            <td style=\"color:#888;\">
                                <strike>{$lang->delete[0]->tagData}</strike>
                            </td>
                            <td>
                                <a href=\"./?AdminEditRoom&id={$id}\">
                                    {$lang->rename[0]->tagData}
                                </a>
                            </td>
                            <td>&nbsp;&nbsp;&nbsp;<i>{$privText}</i></td>
                        </tr>";
                }
            }

            $print_room_list .= "</table>";
        }

        // 🔐 Template laden
        $this->initTemplate($lang, $print_room_list, $this->csrfToken);
    }

    private function isAllowed(): bool
	{
		$allowedRoles = ["admin", "co_admin"];
		$userRole = isset($_SESSION['etchat_'.$this->_prefix.'user_priv'])
			? (string) $_SESSION['etchat_'.$this->_prefix.'user_priv']
			: '';
        
		if (!in_array($userRole, $allowedRoles, true)) {
			header("Location: ./");
			exit;
		}

		return true;
	}

    private function initTemplate($lang, $print_room_list, string $csrf): void
    {
        include_once("styles/admin_tpl/indexRooms.tpl.html");
    }
}