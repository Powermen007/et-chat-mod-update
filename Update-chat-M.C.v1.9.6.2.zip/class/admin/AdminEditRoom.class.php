<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminEditRoom extends DbConectionMaker
{
    private string $csrfKey;

    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sicher starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache laden
        $lang = (new LangXml())->getLang()->admin[0]->admin_rooms[0];

        // Rollenprüfung
        $allowedRoles = ["admin", "co_admin"];
        $userRole = isset($_SESSION['etchat_'.$this->_prefix.'user_priv'])
			? (string) $_SESSION['etchat_'.$this->_prefix.'user_priv']
			: '';
			
        if (!in_array($userRole, $allowedRoles, true)) {
            header("Location: ./");
            exit;
        }

        // 🔐 CSRF Token initialisieren
        $this->csrfKey = 'etchat_' . $this->_prefix . 'csrf_token';
        if (empty($_SESSION[$this->csrfKey])) {
            $_SESSION[$this->csrfKey] = bin2hex(random_bytes(16));
        }

        // 🔹 GET + POST kompatibel
        $data = $_GET + $_POST;

        // 🔥 ID absichern
        $id = (int)($data['id'] ?? 0);
        if ($id <= 0) {
            echo "Ungültige ID.";
            return;
        }

        // 🔹 PDO Prepared Statement für Raum-Daten
        $feld = $this->dbObj->sqlGet(
            "SELECT 
                etchat_id_room, 
                etchat_roomname, 
                etchat_room_goup, 
                etchat_room_pw, 
                etchat_room_message 
             FROM {$this->_prefix}etchat_rooms 
             WHERE etchat_id_room = ?",
            [$id]
        );

        $this->dbObj->close();

        if (!is_array($feld) || empty($feld[0])) {
            echo "Eintrag nicht gefunden.";
            return;
        }

        // 🔹 Template laden
        $this->initTemplate($lang, $feld);
    }

    private function initTemplate(object $lang, array $feld): void
    {
        include __DIR__ . "/../../styles/admin_tpl/editRoom.tpl.html";
    }
}