<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminCreateNewMenu extends ConnectDB
{
    public function __construct()
    {
        parent::__construct();

        // -------------------------
        // Session starten
        // -------------------------
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');
        // -------------------------
        // Sprache laden
        // -------------------------
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_rooms[0];

        // -------------------------
        // GET + POST kompatibel
        // -------------------------
        $data = $_POST + $_GET;

        // -------------------------
        // Rollenprüfung
        // -------------------------
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';
        if ($role !== "admin") {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            $this->close();
            exit;
        }

        // -------------------------
        // CSRF prüfen
        // -------------------------
        $sessionToken = $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] ?? '';
        $requestToken = $data['csrf_token'] ?? '';
        if (empty($sessionToken) || empty($requestToken) || !hash_equals($sessionToken, $requestToken)) {
            echo "CSRF Fehler – ungültige Anfrage.";
            $this->close();
            exit;
        }

        // -------------------------
        // Werte holen
        // -------------------------
        $menu         = trim($data['menu'] ?? '');
        $link_text    = trim($data['link_text'] ?? '');
        $image_active = trim($data['image_active'] ?? '');
        $image        = trim($data['image'] ?? '');
        $url          = trim($data['url'] ?? '');
        $target       = trim($data['target'] ?? '');
        $gewicht      = (int)($data['gewicht'] ?? 0);

        // -------------------------
        // DB Insert
        // -------------------------
        $this->sqlSet(
            "INSERT INTO {$this->_prefix}etchat_menu 
            (menu, link_text, image_active, image, url, target, gewicht) 
            VALUES 
            (:menu, :link_text, :image_active, :image, :url, :target, :gewicht)",
            [
                ':menu'         => $menu,
                ':link_text'    => $link_text,
                ':image_active' => $image_active,
                ':image'        => $image,
                ':url'          => $url,
                ':target'       => $target,
                ':gewicht'      => $gewicht
            ]
        );

        // -------------------------
        // DB schließen & Weiterleitung
        // -------------------------
        $this->close();
        header("Location: ./?AdminMenusIndex");
        exit;
    }
}