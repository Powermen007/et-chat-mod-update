<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminUpdateText extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // Sprache sicher laden
        $langObj = new LangXml();
        $langData = $langObj->getLang();

        $lang = $langData->admin[0]->admin_rooms[0] ?? (object)[
            'error' => [(object)['tagData' => 'Fehler']]
        ];

        // 🔐 Eingaben
        $id    = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $token = (string)($_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '');

        // 🔐 Admin + Pflichtfelder prüfen
        $role = (string)($_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '');

        if ($role !== 'admin' || $id <= 0 || $token === '') {
            echo htmlspecialchars($lang->error[0]->tagData ?? 'Fehler', ENT_QUOTES, 'UTF-8');
            exit;
        }

        // 🔐 CSRF prüfen
        if (!$this->isValidCsrfToken($token)) {
            echo htmlspecialchars(($lang->error[0]->tagData ?? 'Fehler') . ' (CSRF)', ENT_QUOTES, 'UTF-8');
            exit;
        }

        // 🔐 Eingaben
        $ueber = trim((string)($_POST['ueberschrift'] ?? ''));
        $cod   = trim((string)($_POST['code'] ?? ''));

        if ($ueber === '' || $cod === '') {
            echo htmlspecialchars($lang->error[0]->tagData ?? 'Fehler', ENT_QUOTES, 'UTF-8');
            exit;
        }

        try {
            $pdo = $this->dbObj->getConnection();

            if (!$pdo) {
                echo htmlspecialchars($lang->error[0]->tagData ?? 'Fehler', ENT_QUOTES, 'UTF-8');
                exit;
            }

            // ✅ PDO-Update
            $stmt = $pdo->prepare("
                UPDATE {$this->_prefix}etchat_texte
                SET header_text = :header,
                    content = :content
                WHERE id = :id
            ");

            $stmt->execute([
                ':header'  => $ueber,
                ':content' => $cod,
                ':id'      => $id
            ]);

            $this->dbObj->close();

            // 🔄 Redirect nach Erfolg
            header("Location: ./?AdminTextsIndex");
            exit;

        } catch (PDOException $e) {
            echo htmlspecialchars($lang->error[0]->tagData ?? 'Fehler', ENT_QUOTES, 'UTF-8');
            exit;
        }
    }

    private function isValidCsrfToken(string $token): bool
    {
        $key = 'etchat_' . $this->_prefix . 'csrf_token';
        return isset($_SESSION[$key]) && hash_equals($_SESSION[$key], $token);
    }
}