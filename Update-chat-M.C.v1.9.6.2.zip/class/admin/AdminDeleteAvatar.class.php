<?php

/*
ET-Chat Copyright by SEDesign | ET-Chat v3.x.x Lizenz: CCPL | Autor: Evgeni Tcherkasski (info@s-e-d.de)
ET-Chat_T-FISH-MOD Weiterentwicklungen, Optimierungen und Ergänzungen am Code sind das geistige Eigentum von Tommy (Thomas Kuhn) und Harlekin (Bernd Witte).

Die darauf folgende Optimierungen und Ergänzungen am Code sind das Geistige Eigentum von Powermen (Christian K.) 
PHP 8/9 Ready, XML Parser, PDO Prepared Statements Get Set sicherheit usw.
*/

declare(strict_types=1);

class AdminDeleteAvatar extends DbConectionMaker
{
    public function __construct()
    {
        parent::__construct();

        // 🔐 Session sauber starten
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Content-Type: text/html; charset=utf-8');

        // 🔐 Sprache
        $langObj = new LangXml();
        $lang = $langObj->getLang()->admin[0]->admin_reg_user[0];

        // 🔐 Rechte prüfen
        $allowedRoles = ["admin", "chatwache", "co_admin"];
        $role = $_SESSION['etchat_' . $this->_prefix . 'user_priv'] ?? '';

        if (!in_array($role, $allowedRoles, true)) {
            echo $lang->error[0]->tagData ?? 'Zugriff verweigert';
            exit;
        }

        // 🔐 CSRF Token
        if (!isset($_SESSION['etchat_' . $this->_prefix . 'csrf_token'])) {
            $_SESSION['etchat_' . $this->_prefix . 'csrf_token'] = bin2hex(random_bytes(16));
        }
        $checksum = (string) $_SESSION['etchat_' . $this->_prefix . 'csrf_token'];

        // 🔥 Request
        $id        = (int)($_GET['id'] ?? 0);
        $csrf_token = (string)($_GET['csrf_token'] ?? '');
        $delAvatar  = isset($_GET['delavatar']);

        // 🔐 CSRF prüfen nur bei Aktion
        if ($delAvatar && (empty($csrf_token) || !hash_equals($checksum, $csrf_token))) {
            echo "Manipulationsversuch erkannt.";
            $this->dbObj->close();
            exit;
        }

        // 🔥 Avatar löschen
        if ($delAvatar && $id > 0) {
            // 🔹 Avatar aus DB holen
            $avatarFile = $this->dbObj->sqlGet(
                "SELECT etchat_avatar FROM {$this->_prefix}etchat_user WHERE etchat_user_id = :id",
                [':id' => $id]
            );

            $file = $avatarFile[0][0] ?? '';

            if ($file !== '' && !in_array($file, ["noavatar.jpg", "mod_ohne_pic.png", "autodj.jpg"], true)) {
                $filePath = realpath(__DIR__ . '/../../avatar/' . $file);

                // 🔐 Sicherheitscheck: nur im Avatar-Ordner löschen
                $avatarRoot = realpath(__DIR__ . '/../../avatar/');
                if ($filePath && strpos($filePath, $avatarRoot) === 0 && is_file($filePath)) {
                    @unlink($filePath);
                }
            }

            // 🔹 DB Update
            $this->dbObj->sqlSet(
                "UPDATE {$this->_prefix}etchat_user 
                 SET etchat_avatar = 'noavatar.jpg' 
                 WHERE etchat_user_id = :id",
                [':id' => $id]
            );

            $this->dbObj->close();

            header("Location: ./?AdminUserIndex");
            exit;
        }

        $this->dbObj->close();
    }
}