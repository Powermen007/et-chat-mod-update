
<style>
.marquee-wrap{overflow:hidden;width:100%;border-radius:10px;margin:2px 0;}
.marquee{display:inline-block;white-space:nowrap;padding-left:100%;animation:marqueeAnim 30s linear infinite;}
@keyframes marqueeAnim{0%{transform:translateX(0);}100%{transform:translateX(-100%);}}
.marquee:hover{animation-play-state:paused;}
</style>
<div class="marquee-wrap" style="">
<div class="marquee">
<b class="rnb">✦ ✦ ✦ Der Neue Chat ist da !! nun auch Handy und Tablet tauglich !! ✦ ✦ ✦ Neu Sendeplan und Wunschbox mit Tagübrgreifenden Einträge Serienfunksion und großen Config Menü für den Admin ✦ ✦ ✦ Chat.js Optemieren (Insbesonder die Userliste) ✦ ✦ ✦ Sprache bearbeiten zu 50% fertig. ✦ ✦ ✦</b>
</div></div>
<style>
.rnb{background:linear-gradient(90deg, red, orange, yellow, green, cyan, blue, purple);
background-size:200% 100%;
-webkit-background-clip:text;
color:transparent;
animation:rainbowAnim 7s linear infinite;}
@keyframes rainbowAnim{0%{background-position:0%}50%{background-position:100%}100%{background-position:0%}}
</style>